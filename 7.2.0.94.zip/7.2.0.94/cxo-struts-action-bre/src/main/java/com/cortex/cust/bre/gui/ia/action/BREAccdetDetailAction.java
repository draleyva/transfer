package com.cortex.cust.bre.gui.ia.action;

import static com.cortex.common.constant.CortexConstants.ERROR_DB_CONNECT_FAILED_KEY;
import static com.cortex.common.constant.CortexConstants.ERROR_DB_UPDATE_FAILED_KEY;
import static com.cortex.common.constant.CortexConstants.ERROR_UNKNOWN_ERROR_KEY;
import static com.cortex.gui.StrutsConstants.DELETE_STATUS_PARAM;
import static com.cortex.gui.StrutsConstants.DELETE_STATUS_VALUE;

import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Locale;
import java.util.Vector;

import javax.ejb.CreateException;
import javax.rmi.PortableRemoteObject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cortex.common.constant.SQLConstants;
import com.cortex.common.constant.globalConstant;
import com.cortex.common.constant.serverConstant;
import com.cortex.common.entityejb.AccdetXInfo;
import com.cortex.common.entityejb.AcctypeInfo;
import com.cortex.common.exception.serverException;
import com.cortex.common.hook.HookFactory;
import com.cortex.common.hook.HookParam;
import com.cortex.common.interfaces.IResultInfo;
import com.cortex.common.lib.dbLib;
import com.cortex.common.lib.debugLib;
import com.cortex.common.valueobj.ResultInfo;
import com.cortex.cust.bre.common.constant.viewConstantBRE;
import com.cortex.cust.bre.gui.ia.formbean.BREAccdetDetailForm;
import com.cortex.gui.common.action.SessionDataAction;
import com.cortex.gui.common.action.mkc.EntityType;
import com.cortex.gui.common.action.mkc.MkcConstants;
import com.cortex.gui.common.action.mkc.Util;
import com.cortex.gui.common.constant.viewConstant;
import com.cortex.gui.common.lib.Co4MacroLib;
import com.cortex.gui.common.lib.CoGlobalFunctions;
import com.cortex.gui.common.lib.CommonGlobalFunctions;
import com.cortex.gui.common.lib.LocaleFormatConverter;
import com.cortex.gui.common.lib.UserInst;
import com.cortex.common.lib.FunctionLib;
import com.cortex.cust.bre.common.constant.serverConstantBre;
import com.cortex.cust.bre.gui.ia.sessionejb.BREAccdetMgr;
import com.cortex.cust.bre.gui.ia.sessionejb.BREAccdetMgrHome;
import com.cortex.gui.ia.sessionejb.AccdetMgr;
import com.cortex.gui.ia.sessionejb.AccdetMgrHome;
import com.cortex.gui.ia.valueobj.AccdetDetailInfo;
import com.cortex.gui.ia.valueobj.AccdetPKInfo;
import com.cortex.gui.ia.valueobj.ParentCardDetailsInfo;
import com.fis.mkc.domain.model.JobType;
import com.fis.mkc.domain.model.ServiceType;
import com.fis.mkc.domain.shared.JobAuthCallCollator;

/**
 *
 * @author e5706717
 */
public class BREAccdetDetailAction extends SessionDataAction {

  private static final String UPDATE_UNSENT_ACTION = "update_unsent";
  private static final String ACCDET_SUCCESS_REFRESH_MSG_KEY = "ia.msg.accdet.success.refresh";
  private static final String ACCDET_SUCCESS_DELETE_MSG_KEY = "ia.msg.accdet.success.delete";
  private static final String ACCDET_SUCCESS_UPDATE_MSG_KEY = "ia.msg.accdet.success.update";
  private static final String FROM_WHERE_6 = "6";
  private static final String FROM_WHERE_5 = "5";
  private static final String PARENT_CARD_DETAILS_INFO_ATTR = "ParentCardDetailsInfo";
  private static final String ACCOUNT_NUMBER_LENGTH_ERR_PTRN = "Length of Account number must be %d";
  private static final String ACCDET_SUCCESS_ADD_MSG_KEY = "ia.msg.accdet.success.add";
  private static final String BRN_NOT_FILE_ERR_KEY = "co.error.BRN_NOT_FILE";
  private static final String INVALID_CURR_ERR_KEY = "error.common.INVALID_CURR";
  private static final String AMOUNT_AND_ACCOUNT_TYPE_EDITABLE_PLUGIN = "com.cortex.gui.ia.plugins.accdetamountsacctype.AmountAndAccountTypeEditablePlugin";
  private static final String READONLY_AMOUNT_FIELDS_PLUGIN = "com.cortex.cust.stb.gui.ia.plugins.readonlyamountfields.ReadonlyAmountFieldsPlugin";
  private static final String DELETE_ACCDET_METHOD = "deleteAccdet";
  private static final String ADD_ACCDET_METHOD = "addAccdet";
  private static final String UPDATE_ACCDET_METHOD = "updateAccdet";
  private static final String CLASSNAME = BREAccdetDetailAction.class.getSimpleName();
  private static final String FORM_PARAM = "AccdetDetailForm";
  private static final String FORM_TYPE_INFO_PARAM = "FormTypeInfo";
  private static final String HAS_RIGHT_PARAM = "hasRights";
  private static final String ACCESS_ACSITEM_PARAM = "accessAcsitem";
  private static final String[] TRANSFERABLE_REQUEST_PARAMS = withMandatoryRedirectionParams(Action.ERROR_KEY,
          FORM_PARAM, FORM_TYPE_INFO_PARAM, HAS_RIGHT_PARAM, ACCESS_ACSITEM_PARAM, viewConstant.ACTION_SUCCESS_FLAG,
          viewConstant.ERROR_KEY_USER_DEFINED, DELETE_STATUS_PARAM);

  /**
   * {@inheritDoc}
   */
  @SuppressWarnings("unchecked")
  @Override
  public ActionForward perform(ActionMapping actionMapping, ActionForm actionForm, HttpServletRequest request,
          HttpServletResponse response) throws IOException, ServletException {

    logError(CLASSNAME, "ActionForward perform");

    appendMandatoryRedirectionParams(request);
    setUser((String) request.getSession(false).getAttribute(viewConstant.USERNAME));
    CoGlobalFunctions coGlobalFunctions = new CoGlobalFunctions();
    BREAccdetDetailForm accdetDetailForm = (BREAccdetDetailForm) actionForm;
    AccdetDetailInfo accdetDetailInfo = ((BREAccdetDetailForm) actionForm).getAccdetDetailInfo();
    AccdetXInfo accdetXInfo = ((BREAccdetDetailForm) actionForm).getAccdetXInfo();
    ActionErrors errors = new ActionErrors();
    Locale locale = request.getLocale();
    Vector<String> detailInfo = new Vector<String>();
    String result = viewConstant.RESULT_SUCCESS;
    HttpSession httpSession = request.getSession(false);
    String formAction = request.getParameter(viewConstant.PARAMETER_FORMACTION);
    Boolean mkcJobCreated = false;
    
    // CTXAPPSMAINT-1923: The "msReadonlyAmountAndAccountTypeFields" identifier define the default behaviour for all
    // amount fields and account type fields.
    String readonlyAmountAndAccountTypeFields = String.valueOf(Boolean.TRUE); // Default behaviour is 'readonly'.

    HookParam hookParam = new HookParam();
    hookParam.put(HookParam.PARAM1, readonlyAmountAndAccountTypeFields);
    try {
      // If this hook is available because of it's defined in the Hook XML file and its 'active' property is set
      // to "true", will define the amount fields and account type as 'readonly'.
      // If this hook is no available, the default behaviour will be used.
      hookParam = HookFactory
              .getPlugin(READONLY_AMOUNT_FIELDS_PLUGIN)
              .process(hookParam);
      readonlyAmountAndAccountTypeFields = (String) hookParam.get(HookParam.PARAM1);
    } catch (Exception e) {
      debugLib.logInfo(CLASSNAME, e.toString());
    }

    // CTXAPPSMAINT-1923: The "AmountAndAccountTypeEditablePlugin" hook makes the amount fields and account type
    // fields editable.
    HookParam hookParam2 = new HookParam();
    hookParam2.put(HookParam.PARAM1, readonlyAmountAndAccountTypeFields);
    try {
      hookParam2 = HookFactory
              .getPlugin(AMOUNT_AND_ACCOUNT_TYPE_EDITABLE_PLUGIN)
              .process(hookParam2);
      readonlyAmountAndAccountTypeFields = (String) hookParam2.get(HookParam.PARAM1);
    } catch (Exception e) {
      debugLib.logInfo(CLASSNAME, e.toString());
    }
    if ((formAction == viewConstant.PERFORM_NULL) || (formAction.length() == 0)) {
      try {
        accdetDetailInfo = new AccdetDetailInfo();
        request.getSession(false).setAttribute(viewConstant.VIEW_MODE, viewConstant.CREATE_VIEW_MODE);
        Object ref = FunctionLib.getLookup(serverConstant.VIEW_ACCDET_SESSION);
        AccdetMgrHome accdetMgrHome = (AccdetMgrHome) PortableRemoteObject.narrow(ref, AccdetMgrHome.class);
        AccdetMgr accdetMgr = accdetMgrHome.create();

        accdetMgr.setFormLabels(accdetXInfo);

        UserInst userInst = CommonGlobalFunctions.getUserInst(httpSession);
        long instId = userInst.getInst_id();
        String instcode = userInst.getInstcode();

        if (instId != viewConstant.NO_USER_INST_ID) {
          accdetDetailForm.setInstId(String.valueOf(instId));
        } else {
          accdetDetailForm.setFrmId(viewConstant.PERFORM_NOACTION);
        }
        accdetDetailInfo.setInstcode(instcode);
        accdetDetailInfo.setReadonlyAmountFields(readonlyAmountAndAccountTypeFields);
        accdetDetailForm.setAccdetDetailInfo(accdetDetailInfo);
        request.setAttribute(FORM_PARAM, accdetDetailForm);
        return cxoSuccessRedirect(actionMapping, TRANSFERABLE_REQUEST_PARAMS);
      } catch (RemoteException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_CONNECT_FAILED_KEY));
      } catch (CreateException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_CONNECT_FAILED_KEY));
      } catch (serverException ex) {
        if (StringUtils.isNotEmpty(ex.getErrorCode())) {
          errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ex.getErrorCode()));
        }
      } catch (Exception ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
        logError(CLASSNAME, ex.toString());
      }
    } else if (formAction.equals(viewConstant.BUTTON_ADD)) {
      try {
        Vector<String> addCurrcode = coGlobalFunctions.nameCurrFind(accdetDetailInfo.getCurrcode());
        String addAlphaCode = addCurrcode.elementAt(1);

        addAlphaCode = addAlphaCode.trim();

        if (StringUtils.isEmpty(addAlphaCode)) {
          throw new serverException(INVALID_CURR_ERR_KEY);
        }
        request.getSession(false).setAttribute(viewConstant.VIEW_MODE, viewConstant.CREATE_VIEW_MODE);
        detailInfo = CoGlobalFunctions.getAlphaCurrencyDescr(accdetDetailInfo.getCurrcode(),
                request.getLocale().getLanguage().toUpperCase());
        if (detailInfo.size() > 0) {
          accdetDetailForm.setCurrencyAlphaCode(detailInfo.elementAt(0));
          accdetDetailForm.setCurrencyDesc(detailInfo.elementAt(1));
        }
        Co4MacroLib co4MacroLib = new Co4MacroLib();
        String brnName = co4MacroLib.funSetBrnName(accdetDetailInfo.getInstcode(),
                accdetDetailInfo.getBrncode());
        if (StringUtils.isNotBlank(brnName)) {
          accdetDetailForm.setBranchDescr(brnName);
        } else {
          throw new serverException(BRN_NOT_FILE_ERR_KEY);
        }
        Object ref = FunctionLib.getLookup(serverConstant.VIEW_ACCDET_SESSION);
        AccdetMgrHome accdetMgrHome = (AccdetMgrHome) PortableRemoteObject.narrow(ref, AccdetMgrHome.class);
        AccdetMgr accdetMgr = accdetMgrHome.create();

        accdetDetailInfo.setClassid(accdetMgr
                .getAcctypeData(accdetDetailInfo.getInstcode(), accdetDetailInfo.getTypecode()).getClassid());
        boolean flag = true;
        int length = getAccLength(accdetDetailInfo);

        if (length > 0 && accdetDetailInfo.getAccno().trim().length() != length) {
          flag = false;
        }
        if (flag) {
          accdetDetailInfo = storeAmountToSQLFormat(accdetDetailInfo, locale);

          // Alvis 10/10/2007 CTXONLINE-88 : 2 new fields ACCDET.avlbal_unsent and ACCDET.blkamt_unsent added
          double avlbalUnsent = accdetMgr.CalculateAvlbalUnsent(accdetDetailInfo);
          double blkamtUnsent = accdetMgr.CalculateBlkamtUnsent(accdetDetailInfo);
          double unclrcreditUnsent = accdetMgr.CalculateUnclrcreditUnsent(accdetDetailInfo);

          // JFC 20/02/04: NMR010217: AT-0141: Set Locale to all the amounts
          accdetDetailInfo = convertAmountToLocaleFormat(accdetDetailInfo, locale, avlbalUnsent, blkamtUnsent,
                  unclrcreditUnsent);
          if (!createMkcAuthJob(request, accdetDetailInfo, accdetDetailInfo, null, null, accdetXInfo, null,
                  !Boolean.valueOf(readonlyAmountAndAccountTypeFields), EntityType.CUSTOMER, JobType.NEW_ONLY,
                  ADD_ACCDET_METHOD, accdetDetailInfo.getCustdet_id(), createCustomerEntityKey(accdetDetailInfo))) {
            accdetMgr.addAccdet(accdetDetailInfo, accdetXInfo,
                    !Boolean.valueOf(readonlyAmountAndAccountTypeFields));
            accdetDetailInfo.setReadonlyAmountFields(readonlyAmountAndAccountTypeFields);

            // Modified to Fix TR-1560 Vinay 30/12/2002
            accdetDetailForm.setAccdetDetailInfo(accdetDetailInfo);

            accdetDetailForm.setInstId(String.valueOf(
                    CommonGlobalFunctions.getInstIdByInstCode(accdetDetailInfo.getInstcode())));
            request.setAttribute(viewConstant.ACTION_SUCCESS_FLAG, ACCDET_SUCCESS_ADD_MSG_KEY);
            result = viewConstant.RESULT_SUCCESS;
          } else {
            request.setAttribute(viewConstant.ACTION_SUCCESS_FLAG,
                    viewConstant.RESULT_MKC_JOB_CREATION_SUCCESS);
            result = viewConstant.RESULT_SUCCESS;
          }
        } else {
          request.setAttribute(viewConstant.ERROR_KEY_USER_DEFINED,
                  String.format(ACCOUNT_NUMBER_LENGTH_ERR_PTRN, length));
        }

      } catch (RemoteException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_CONNECT_FAILED_KEY));
      } catch (CreateException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_CONNECT_FAILED_KEY));
      } catch (serverException ex) {
        if (!(ex.getErrorCode().equals(""))) {
          errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ex.getErrorCode()));
        }

      } catch (Exception ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
        logError(CLASSNAME, ex.toString());
      }
    } else if (formAction.equals(viewConstant.PERFORM_REPOPULATE)) {
      accdetDetailForm.setInstId(String.valueOf(
              CommonGlobalFunctions.getInstIdByInstCode(accdetDetailInfo.getInstcode())));
      result = viewConstant.RESULT_SUCCESS;
    } else if (formAction.equals(viewConstant.BUTTON_EDIT)) {
      try {
        request.getSession(false).setAttribute(viewConstant.VIEW_MODE, viewConstant.EDIT_VIEW_MODE);
        Object ref = FunctionLib.getLookup(serverConstant.VIEW_ACCDET_SESSION);
        AccdetMgrHome accdetMgrHome = (AccdetMgrHome) PortableRemoteObject.narrow(ref,
                AccdetMgrHome.class);
        AccdetMgr accdetMgr = accdetMgrHome.create();
        AccdetPKInfo accdetPKInfo = new AccdetPKInfo();
        ParentCardDetailsInfo parentCardDetailsInfo = new ParentCardDetailsInfo();
        accdetDetailForm.setFromwhere(request.getParameter(viewConstant.PARAMETER_KEY_4));
        int fromWhere = Integer.parseInt(request.getParameter(viewConstant.PARAMETER_KEY_4));

        switch (fromWhere) {
          case 0: {
            accdetPKInfo.setInstcode(request.getParameter(viewConstant.PARAMETER_KEY_1));
            accdetPKInfo.setAccno(request.getParameter(viewConstant.PARAMETER_KEY_2));
            accdetPKInfo.setCurrcode(request.getParameter(viewConstant.PARAMETER_KEY_3));
          }
          break;
          case 1: {
            parentCardDetailsInfo = ((ParentCardDetailsInfo) httpSession
                    .getAttribute(PARENT_CARD_DETAILS_INFO_ATTR));

            accdetPKInfo.setInstcode(parentCardDetailsInfo.getInstcode());
            accdetPKInfo.setAccno(parentCardDetailsInfo.getAccno());
            accdetPKInfo.setCurrcode(parentCardDetailsInfo.getCurrcode());
            accdetDetailForm.setFromwhere(viewConstant.ZERO);// for "0"
          }
          break;
          // from card maintenance
          case 2: {
            parentCardDetailsInfo = ((ParentCardDetailsInfo) httpSession
                    .getAttribute(PARENT_CARD_DETAILS_INFO_ATTR));

            accdetPKInfo.setInstcode(parentCardDetailsInfo.getInstcode());
            accdetPKInfo.setAccno(parentCardDetailsInfo.getAccno());
            accdetPKInfo.setCurrcode(parentCardDetailsInfo.getCurrcode());
            accdetDetailForm.setFromwhere(viewConstant.TWO);// for "1"
          }
          break;
          case 3: {
            accdetPKInfo.setInstcode(request.getParameter(viewConstant.PARAMETER_KEY_1));
            accdetPKInfo.setAccno(request.getParameter(viewConstant.PARAMETER_KEY_2));
            accdetPKInfo.setCurrcode(request.getParameter(viewConstant.PARAMETER_KEY_3));

            accdetDetailForm.setFromwhere(viewConstant.TWO);// for "2"
          }
          break;
          // for Card account screen(view cards button in card maintenance)
          case 4: {
            accdetPKInfo.setInstcode(request.getParameter(viewConstant.PARAMETER_KEY_1));
            accdetPKInfo.setAccno(request.getParameter(viewConstant.PARAMETER_KEY_2));
            accdetPKInfo.setCurrcode(request.getParameter(viewConstant.PARAMETER_KEY_3));

            accdetDetailForm.setFromwhere(viewConstant.THREE);// for "3"
          }
          break;
          case 5: {
            accdetPKInfo.setInstcode(request.getParameter(viewConstant.PARAMETER_KEY_1));
            accdetPKInfo.setAccno(request.getParameter(viewConstant.PARAMETER_KEY_2));
            accdetPKInfo.setCurrcode(request.getParameter(viewConstant.PARAMETER_KEY_3));

            /*
                     * NMR015984 if coming from the Card/Account relationship, check whether the card is linked to this
                     * account. If so display the crdacc button , to be able to set the role id.
             */
            String pan = request.getParameter(viewConstant.PARAMETER_KEY_5);
            String seqno = request.getParameter(viewConstant.PARAMETER_KEY_6);
            String isLinked = request.getParameter(viewConstant.PARAMETER_KEY_7);

            if (StringUtils.isNotEmpty(pan) && StringUtils.isNotEmpty(seqno) && isLinked != null
                    && isLinked.equals(viewConstant.CHAR_YES)) {
              // we are about to view an account that is linked to a card.
              accdetDetailForm.setPan(pan);
              accdetDetailForm.setSeqno(seqno);
              accdetDetailForm.setIsCrdaccLnk(Boolean.TRUE.toString());
            }

            accdetDetailForm.setFromwhere(FROM_WHERE_5);// for "5"
            break;
          }
          case 6: {
            parentCardDetailsInfo = ((ParentCardDetailsInfo) httpSession
                    .getAttribute(PARENT_CARD_DETAILS_INFO_ATTR));

            accdetPKInfo.setInstcode(parentCardDetailsInfo.getInstcode());
            accdetPKInfo.setAccno(parentCardDetailsInfo.getAccno());
            accdetPKInfo.setCurrcode(parentCardDetailsInfo.getCurrcode());
            accdetDetailForm.setFromwhere(FROM_WHERE_6);// for "1"
          }
        }
        AccdetDetailInfo tempAccdetDetailInfo = accdetMgr.getAccdet(accdetPKInfo);
        AccdetXInfo tempAccdetXInfo = accdetMgr.getAccdetX(tempAccdetDetailInfo.getId());

        if (StringUtils.isNotEmpty(tempAccdetDetailInfo.getInstcode())
                && StringUtils.isNotEmpty(tempAccdetDetailInfo.getCustcode())) {
          try {
            tempAccdetDetailInfo = accdetMgr.getCustName(tempAccdetDetailInfo);
            accdetDetailForm.setLastname(tempAccdetDetailInfo.getLastname());
            accdetDetailForm.setFirstname(tempAccdetDetailInfo.getFirstname());
            accdetDetailForm.setTitle(tempAccdetDetailInfo.getTitle());
          } catch (Exception ex) {
            debugLib.logError(CLASSNAME, ex);
          }

          try {
            int typeId = accdetMgr.getCustTypeid(tempAccdetDetailInfo.getInstcode(),
                    tempAccdetDetailInfo.getCustcode());
            tempAccdetDetailInfo.setCustTypeid(typeId);
            accdetDetailForm.setCustTypeid(typeId);
          } catch (Exception ex) {
            debugLib.logError(CLASSNAME, ex);
          }
        }

        accdetDetailForm.setInstId(String.valueOf(
                CommonGlobalFunctions.getInstIdByInstCode(tempAccdetDetailInfo.getInstcode())));

        detailInfo = CoGlobalFunctions.getAlphaCurrencyDescr(tempAccdetDetailInfo.getCurrcode(),
                request.getLocale().getLanguage().toUpperCase());

        if (detailInfo.size() > 0) {
          accdetDetailForm.setCurrencyAlphaCode(detailInfo.elementAt(0));
          accdetDetailForm.setCurrencyDesc(detailInfo.elementAt(1));
        }
        Co4MacroLib co4MacroLib = new Co4MacroLib();
        String brnName = co4MacroLib.funSetBrnName(tempAccdetDetailInfo.getInstcode(),
                tempAccdetDetailInfo.getBrncode());
        accdetDetailForm.setBranchDescr(brnName);

        // Alvis 10/10/2007 CTXONLINE-88 : 2 new fields ACCDET.avlbal_unsent and ACCDET.blkamt_unsent added
        double avlbalUnsent = accdetMgr.CalculateAvlbalUnsent(tempAccdetDetailInfo);
        double blkamtUnsent = accdetMgr.CalculateBlkamtUnsent(tempAccdetDetailInfo);
        double unclrcreditUnsent = accdetMgr.CalculateUnclrcreditUnsent(tempAccdetDetailInfo);

        // Convert the amount depending on the locale
        tempAccdetDetailInfo = convertAmountToLocaleFormat(tempAccdetDetailInfo, locale, avlbalUnsent,
                blkamtUnsent, unclrcreditUnsent);

        if (fromWhere == 0) {
          parentCardDetailsInfo.setInstcode(request.getParameter(viewConstant.PARAMETER_KEY_1));
          parentCardDetailsInfo.setAccno(request.getParameter(viewConstant.PARAMETER_KEY_2));
          parentCardDetailsInfo.setCurrcode(request.getParameter(viewConstant.PARAMETER_KEY_3));
          parentCardDetailsInfo.setCustcode(tempAccdetDetailInfo.getCustcode());
          httpSession.setAttribute(PARENT_CARD_DETAILS_INFO_ATTR, parentCardDetailsInfo);
        }

        tempAccdetDetailInfo.setReadonlyAmountFields(readonlyAmountAndAccountTypeFields);

        String statcode = tempAccdetDetailInfo.getStatcode();
        tempAccdetDetailInfo.setReadonlyStatcodeField(accdetMgr.isReadonlyStatcodeField(statcode));
        accdetDetailForm.setAcclogId(String.valueOf(getAccountLoggingId(tempAccdetDetailInfo, errors)));
        accdetDetailForm.setAccdetDetailInfo(tempAccdetDetailInfo);
        accdetDetailForm.setAccdetXInfo(tempAccdetXInfo);
        result = viewConstant.RESULT_SUCCESS;
      } catch (CreateException e) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_UPDATE_FAILED_KEY));
      } catch (RemoteException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_CONNECT_FAILED_KEY));
      } catch (serverException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ex.getErrorCode()));
      } catch (Exception ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
        logError(CLASSNAME, ex.toString());
      }
    } else if (formAction.equals(viewConstant.BUTTON_UPDATE)) {
      try {
        Vector<String> currcode = coGlobalFunctions.nameCurrFind(accdetDetailInfo.getCurrcode());
        String alphaCode = currcode.elementAt(1);
        alphaCode = alphaCode.trim();

        if (StringUtils.isEmpty(alphaCode)) {
          throw new serverException(INVALID_CURR_ERR_KEY);
        }
        request.getSession(false).setAttribute(viewConstant.VIEW_MODE, viewConstant.EDIT_VIEW_MODE);
        Object ref = FunctionLib.getLookup(serverConstant.VIEW_ACCDET_SESSION);
        AccdetMgrHome accdetMgrHome = (AccdetMgrHome) PortableRemoteObject.narrow(ref,
                AccdetMgrHome.class);
        AccdetMgr accdetMgr = accdetMgrHome.create();
        
        accdetDetailInfo.setClassid(accdetMgr
                .getAcctypeData(accdetDetailInfo.getInstcode(), accdetDetailInfo.getTypecode()).getClassid());
        accdetDetailInfo = storeAmountToSQLFormat(accdetDetailInfo, locale);
        AccdetDetailInfo accdetOriginal = getOriginalAccdetDetailInfo(accdetDetailInfo.getInstcode(),
                accdetDetailInfo.getAccno(), accdetDetailInfo.getCurrcode(), locale, accdetMgr);
        accdetDetailInfo.setId(accdetOriginal.getId());
        accdetOriginal.setStrPreauth_unclr(Double.toString(accdetOriginal.getPreauth_unclr()));
        AccdetXInfo originalmobjAccdetXInfo = accdetMgr
                .getAccdetX(accdetOriginal.getId());

        Boolean updateAmounts = !Boolean.valueOf(readonlyAmountAndAccountTypeFields);
        if (!createMkcAuthJob(request, accdetDetailInfo, accdetDetailInfo, accdetOriginal, accdetOriginal,
                accdetXInfo, originalmobjAccdetXInfo, updateAmounts, EntityType.ACCOUNT, JobType.OLD_NEW_DIFF,
                UPDATE_ACCDET_METHOD, accdetDetailInfo.getId(), createAccountEntityKey(accdetDetailInfo))) {
          IResultInfo resultInfo = accdetMgr.updateAccdet(accdetDetailInfo, accdetXInfo,
                  updateAmounts);
          
          ResultInfo.copyTo(resultInfo, accdetDetailInfo);

          double avlbalUnsent = accdetMgr.CalculateAvlbalUnsent(accdetDetailInfo);
          double blkamtUnsent = accdetMgr.CalculateBlkamtUnsent(accdetDetailInfo);
          double unclrcreditUnsent = accdetMgr.CalculateUnclrcreditUnsent(accdetDetailInfo);
          accdetDetailInfo = convertAmountToLocaleFormat(accdetDetailInfo, locale, avlbalUnsent,
                  blkamtUnsent, unclrcreditUnsent);

          accdetDetailForm.setInstId(String.valueOf(
                  CommonGlobalFunctions.getInstIdByInstCode(accdetDetailInfo.getInstcode())));
          accdetDetailInfo.setReadonlyAmountFields(readonlyAmountAndAccountTypeFields);
          String statcode = accdetDetailInfo.getStatcode();
          accdetDetailInfo.setReadonlyStatcodeField(accdetMgr.isReadonlyStatcodeField(statcode));
          accdetDetailForm.setAccdetDetailInfo(accdetDetailInfo);
          accdetDetailForm.setAcclogId(String.valueOf(getAccountLoggingId(accdetDetailInfo, errors)));
          request.setAttribute(viewConstant.ACTION_SUCCESS_FLAG, ACCDET_SUCCESS_UPDATE_MSG_KEY);
          result = viewConstant.RESULT_UPDATE_SUCCESS;
        } else {
          request.setAttribute(viewConstant.ACTION_SUCCESS_FLAG,
                  viewConstant.RESULT_MKC_JOB_CREATION_SUCCESS);
          result = viewConstant.RESULT_UPDATE_SUCCESS;
        }
      } catch (CreateException e) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_UPDATE_FAILED_KEY));
      } catch (RemoteException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_CONNECT_FAILED_KEY));
      } catch (serverException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ex.getErrorCode()));
      } catch (Exception ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
        logError(CLASSNAME, ex.toString());
      }
    } else if (formAction.equals(viewConstant.BUTTON_DELETE)) {
      try {
        request.getSession(false).setAttribute(viewConstant.VIEW_MODE, viewConstant.EDIT_VIEW_MODE);
        Object ref = FunctionLib.getLookup(serverConstant.VIEW_ACCDET_SESSION);
        AccdetMgrHome accdetMgrHome = (AccdetMgrHome) PortableRemoteObject.narrow(ref, AccdetMgrHome.class);
        AccdetMgr accdetMgr = accdetMgrHome.create();
        AccdetPKInfo accdetPKInfo = new AccdetPKInfo();
        accdetPKInfo.setInstcode(accdetDetailInfo.getInstcode());
        accdetPKInfo.setAccno(accdetDetailInfo.getAccno());
        accdetPKInfo.setCurrcode(accdetDetailInfo.getCurrcode());
        AccdetDetailInfo accdetOriginal = accdetMgr.getAccdet(accdetPKInfo);
        accdetDetailInfo.setId(accdetOriginal.getId());
        if (!createMkcAuthJob(request, null, null, accdetPKInfo, accdetDetailInfo, null, accdetXInfo, null,
                EntityType.ACCOUNT, JobType.OLD_ONLY, DELETE_ACCDET_METHOD, accdetDetailInfo.getId(),
                createAccountEntityKey(accdetDetailInfo))) {
          accdetMgr.deleteAccdet(accdetPKInfo, accdetXInfo);
          request.setAttribute(viewConstant.ACTION_SUCCESS_FLAG, ACCDET_SUCCESS_DELETE_MSG_KEY);
          accdetDetailForm.setAccdetDetailInfo(new AccdetDetailInfo());
          result = viewConstant.RESULT_DELETE_SUCCESS;
        } else {
          request.setAttribute(viewConstant.ACTION_SUCCESS_FLAG,
                  viewConstant.RESULT_MKC_JOB_CREATION_SUCCESS);
          result = viewConstant.RESULT_DELETE_SUCCESS;
        }
      } catch (RemoteException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_CONNECT_FAILED_KEY));
      } catch (CreateException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_CONNECT_FAILED_KEY));
      } catch (serverException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ex.getErrorCode()));
      } catch (Exception ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
        logError(CLASSNAME, ex.toString());
      } finally {
        if (errors.empty()) {
          if (mkcJobCreated != true) {
            request.setAttribute(viewConstant.ACTION_SUCCESS_FLAG, viewConstant.ACTION_SUCCESS);
          } else {
            request.setAttribute(viewConstant.ACTION_SUCCESS_FLAG,
                    viewConstant.RESULT_MKC_JOB_CREATED_SUCCESS);
            request.getSession(false).setAttribute(viewConstant.RESULT_MKC_JOB_CREATED_SUCCESS,
                    viewConstant.CHAR_YES);
          }
          accdetDetailForm.setFrmId(viewConstant.PERFORM_EDIT);
          request.getSession(false).setAttribute(viewConstant.DELETE_SUCCESS, viewConstant.CHAR_YES);
          request.setAttribute(DELETE_STATUS_PARAM, DELETE_STATUS_VALUE);
          return cxoRedirect(actionMapping, viewConstant.PERFORM_DEL_SUCCESS, TRANSFERABLE_REQUEST_PARAMS);
        } else {
          accdetDetailForm.setResultAction(viewConstant.PERFORM_ERROR);
          saveErrors(request, errors);
          accdetDetailForm.setFrmId(viewConstant.PERFORM_EDIT);
          accdetDetailForm.setResultAction(viewConstant.PERFORM_SUCCESS);
        }
      }
    } else if (formAction.equals(viewConstant.BUTTON_REFRESH)) {
      try {
        String viewMode = (String) request.getSession(false).getAttribute(viewConstant.VIEW_MODE);
        Object ref = FunctionLib.getLookup(serverConstant.VIEW_ACCDET_SESSION);
        AccdetMgrHome accdetMgrHome = (AccdetMgrHome) PortableRemoteObject.narrow(ref, AccdetMgrHome.class);
        AccdetMgr accdetMgr = accdetMgrHome.create();
        if (viewMode.equals(viewConstant.EDIT_VIEW_MODE)) {
          request.getSession(false).setAttribute(viewConstant.VIEW_MODE, viewConstant.EDIT_VIEW_MODE);
          AccdetPKInfo accdetPKInfo = new AccdetPKInfo();
          accdetPKInfo.setInstcode(accdetDetailInfo.getInstcode());
          accdetPKInfo.setAccno(accdetDetailInfo.getAccno());
          accdetPKInfo.setCurrcode(accdetDetailInfo.getCurrcode());

          AccdetDetailInfo tempAccdetDetailInfo = accdetMgr.getAccdet(accdetPKInfo);
          detailInfo = CoGlobalFunctions.getAlphaCurrencyDescr(tempAccdetDetailInfo.getCurrcode(),
                  request.getLocale().getLanguage().toUpperCase());

          if (detailInfo.size() > 0) {
            accdetDetailForm.setCurrencyAlphaCode(detailInfo.elementAt(0));
            accdetDetailForm.setCurrencyDesc(detailInfo.elementAt(1));
          }

          // Alvis 10/10/2007 CTXONLINE-88 : 2 new fields ACCDET.avlbal_unsent and ACCDET.blkamt_unsent added
          double avlbalUnsent = accdetMgr.CalculateAvlbalUnsent(tempAccdetDetailInfo);
          double blkamtUnsent = accdetMgr.CalculateBlkamtUnsent(tempAccdetDetailInfo);
          double unclrcreditUnsent = accdetMgr.CalculateUnclrcreditUnsent(tempAccdetDetailInfo);

          tempAccdetDetailInfo = convertAmountToLocaleFormat(tempAccdetDetailInfo, locale, avlbalUnsent,
                  blkamtUnsent, unclrcreditUnsent);

          accdetDetailForm.setInstId(String.valueOf(
                  CommonGlobalFunctions.getInstIdByInstCode(tempAccdetDetailInfo.getInstcode())));

          tempAccdetDetailInfo.setReadonlyAmountFields(readonlyAmountAndAccountTypeFields);

          String statcode = tempAccdetDetailInfo.getStatcode();
          tempAccdetDetailInfo.setReadonlyStatcodeField(accdetMgr.isReadonlyStatcodeField(statcode));

          accdetDetailForm.setAccdetDetailInfo(tempAccdetDetailInfo);

          if (StringUtils.isNotEmpty(tempAccdetDetailInfo.getInstcode())
                  && StringUtils.isNotEmpty(tempAccdetDetailInfo.getCustcode())) {
            try {
              tempAccdetDetailInfo = accdetMgr.getCustName(tempAccdetDetailInfo);

              accdetDetailForm.setLastname(tempAccdetDetailInfo.getLastname());
              accdetDetailForm.setFirstname(tempAccdetDetailInfo.getFirstname());
              accdetDetailForm.setTitle(tempAccdetDetailInfo.getTitle());
            } catch (Exception ex) {
              logError(CLASSNAME, ex.toString());
            }

            try {
              int typeId = accdetMgr.getCustTypeid(tempAccdetDetailInfo.getInstcode(),
                      tempAccdetDetailInfo.getCustcode());
              tempAccdetDetailInfo.setCustTypeid(typeId);
              accdetDetailForm.setCustTypeid(typeId);
            } catch (Exception ex) {
              logError(CLASSNAME, ex.toString());
            }
          }

          accdetDetailForm.setAcclogId(String.valueOf(getAccountLoggingId(accdetDetailInfo, errors)));
          request.setAttribute(viewConstant.ACTION_SUCCESS_FLAG, ACCDET_SUCCESS_REFRESH_MSG_KEY);
        } else {
          request.getSession(false).setAttribute(viewConstant.VIEW_MODE, viewConstant.CREATE_VIEW_MODE);
          AccdetDetailInfo tempAccdetDetailInfo = new AccdetDetailInfo();
          String tempInstcode = accdetDetailInfo.getInstcode();

          if (!tempInstcode.equals(viewConstant.NO_USER_INST) && StringUtils.isNotEmpty(tempInstcode)) {
            accdetDetailForm.setInstId(String.valueOf(CommonGlobalFunctions.getInstIdByInstCode(tempInstcode)));
          }

          if (StringUtils.isNotEmpty(accdetDetailInfo.getCustcode())
                  && StringUtils.isNotEmpty(accdetDetailInfo.getInstcode())) {
            try {
              tempAccdetDetailInfo = accdetMgr.getCustName(accdetDetailInfo);
              accdetDetailForm.setLastname(tempAccdetDetailInfo.getLastname());
              accdetDetailForm.setFirstname(tempAccdetDetailInfo.getFirstname());
              accdetDetailForm.setTitle(tempAccdetDetailInfo.getTitle());
            } catch (Exception ex) {
              logError(CLASSNAME, ex.toString());
            }
          }

          if (StringUtils.isNotEmpty(accdetDetailInfo.getTypecode())
                  && StringUtils.isNotEmpty(tempInstcode)) {
            AcctypeInfo acctypeInfo = accdetMgr.getAcctypeData(tempInstcode,
                    accdetDetailInfo.getTypecode());
            accdetDetailForm.setCurrcode(acctypeInfo.getCurrcode());
            accdetDetailForm.setClassid(acctypeInfo.getClassid());
          }

          if (StringUtils.isNotEmpty(accdetDetailInfo.getBrncode()) && StringUtils.isNotEmpty(tempInstcode)) {
            accdetDetailForm.setBranchDescr(accdetMgr.getBrnDescr(accdetDetailInfo));
          }
        }

        result = viewConstant.RESULT_SUCCESS;
      } catch (CreateException e) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_UPDATE_FAILED_KEY));
      } catch (RemoteException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_CONNECT_FAILED_KEY));
      } catch (serverException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ex.getErrorCode()));
      } catch (Exception ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
        logError(CLASSNAME, ex.toString());
      }
    }
    else if (formAction.equals(viewConstant.BUTTON_RESET)) 
    {
    }
    else if (formAction.equals(UPDATE_UNSENT_ACTION))
    {
      try {
        request.getSession(false).setAttribute(viewConstant.VIEW_MODE, viewConstant.EDIT_VIEW_MODE);
        Object ref = FunctionLib.getLookup(serverConstant.VIEW_ACCDET_SESSION);
        AccdetMgrHome accdetMgrHome = (AccdetMgrHome) PortableRemoteObject.narrow(ref, AccdetMgrHome.class);
        AccdetMgr accdetMgr = accdetMgrHome.create();

        double avlbalUnsent = accdetMgr.CalculateAvlbalUnsent(accdetDetailInfo);
        double blkamtUnsent = accdetMgr.CalculateBlkamtUnsent(accdetDetailInfo);
        double unclrcreditUnsent = accdetMgr.CalculateUnclrcreditUnsent(accdetDetailInfo);
        accdetDetailInfo = storeUnsentToSQLFormat(accdetDetailInfo, locale, avlbalUnsent, blkamtUnsent,
                unclrcreditUnsent);
        IResultInfo tobjResultInfo = accdetMgr.updateAccdetUnsentValues(accdetDetailInfo);
        ResultInfo.copyTo(tobjResultInfo, accdetDetailInfo);
        accdetDetailInfo = convertAmountToLocaleFormat(accdetDetailInfo, locale, avlbalUnsent, blkamtUnsent,
                unclrcreditUnsent);

        accdetDetailForm.setInstId(String.valueOf(
                CommonGlobalFunctions.getInstIdByInstCode(accdetDetailInfo.getInstcode())));

        String statcode = accdetDetailInfo.getStatcode();
        accdetDetailInfo.setReadonlyStatcodeField(accdetMgr.isReadonlyStatcodeField(statcode));

        // Modified to Fix TR-1560 Vinay 30/12/2002
        accdetDetailForm.setAccdetDetailInfo(accdetDetailInfo);
        request.setAttribute(viewConstant.ACTION_SUCCESS_FLAG, ACCDET_SUCCESS_UPDATE_MSG_KEY);
        result = viewConstant.RESULT_UPDATE_SUCCESS;
      } catch (CreateException e) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_UPDATE_FAILED_KEY));
      } catch (RemoteException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_CONNECT_FAILED_KEY));
      } catch (serverException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ex.getErrorCode()));
      } catch (Exception ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
        logError(CLASSNAME, ex.toString());
      }
    }
    else if (formAction.equals(viewConstantBRE.BUTTON_UNLINK)) 
    {      
      performUnlink(request, actionForm);
    }

    request.setAttribute(FORM_PARAM, accdetDetailForm);
    if (!errors.empty()) {
      return saveErrorsAndRedirect(request, errors, actionMapping, TRANSFERABLE_REQUEST_PARAMS);
    }

    return cxoRedirect(actionMapping, result, TRANSFERABLE_REQUEST_PARAMS);
  }

  private AccdetDetailInfo getOriginalAccdetDetailInfo(String instCode, String accno, String currCode, Locale locale,
          AccdetMgr accdetMgr) throws RemoteException, serverException, Exception {

    AccdetDetailInfo accdetOriginal;
    AccdetPKInfo accdetPKInfo = new AccdetPKInfo();

    accdetPKInfo.setInstcode(instCode);
    accdetPKInfo.setAccno(accno);
    accdetPKInfo.setCurrcode(currCode);

    accdetOriginal = accdetMgr.getAccdet(accdetPKInfo);

    double avlbalUnsentOriginal = accdetMgr.CalculateAvlbalUnsent(accdetOriginal);
    double blkamtUnsentOriginal = accdetMgr.CalculateBlkamtUnsent(accdetOriginal);
    double unclrcreditUnsentOriginal = accdetMgr.CalculateUnclrcreditUnsent(accdetOriginal);
    accdetOriginal = convertAmountToLocaleFormat(accdetOriginal, locale, avlbalUnsentOriginal, blkamtUnsentOriginal,
            unclrcreditUnsentOriginal);
    String tempInstcode = accdetOriginal.getInstcode();
    String custcode = accdetOriginal.getCustcode();

    if (StringUtils.isNotEmpty(tempInstcode) && StringUtils.isNotEmpty(custcode)) {
      try {
        accdetOriginal = accdetMgr.getCustName(accdetOriginal);
      } catch (Exception ex) {
        logError(CLASSNAME, ex.toString());
      }

      try {
        int typeId = accdetMgr.getCustTypeid(tempInstcode, custcode);
        accdetOriginal.setCustTypeid(typeId);
      } catch (Exception ex) {
        logError(CLASSNAME, ex.toString());
      }
    }
    accdetPKInfo = null;

    return accdetOriginal;
  }

  private AccdetDetailInfo convertAmountToLocaleFormat(AccdetDetailInfo accdetDetailInfo, Locale locale,
          double avlbalUnsent, double blkamtUnsent, double unclrcreditUnsent) throws serverException, Exception {
    try {
      accdetDetailInfo.setStrOpenbal(LocaleFormatConverter
              .displayToLocalCurrencysymb(accdetDetailInfo.getAvlbal(), locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setStrBlkamt(LocaleFormatConverter.displayToLocalCurrencysymb(accdetDetailInfo.getBlkamt(),
              locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setStrClrbal(LocaleFormatConverter.displayToLocalCurrencysymb(accdetDetailInfo.getClrbal(),
              locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setStrUnclrbal(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getUnclrbal(), locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setStrCredit_limit(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getCredit_limit(), locale, accdetDetailInfo.getCurrcode()));
      // JFC 30/09/03: NMR010264: Override field added to the screen and fixed Available balance
      accdetDetailInfo
              .setStrAvlbal(LocaleFormatConverter.displayToLocalCurrencysymb(
                      (accdetDetailInfo.getAvlbal() - accdetDetailInfo.getBlkamt()
                      + accdetDetailInfo.getOverride() + accdetDetailInfo.getUnclrcredit()),
                      locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setStrOverride(LocaleFormatConverter
              .convertCurrencyToLocale(accdetDetailInfo.getOverride(), locale, accdetDetailInfo.getCurrcode()));

      // Alvis 10/10/2007 CTXONLINE-88 : 2 new fields ACCDET.avlbal_unsent and ACCDET.blkamt_unsent added
      accdetDetailInfo.setStrAvlbal_unsent(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getAvlbal_unsent(), locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setStrBlkamt_unsent(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getBlkamt_unsent(), locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setStrAvlbal_unsent_upload(LocaleFormatConverter.displayToLocalCurrencysymb(avlbalUnsent,
              locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setStrBlkamt_unsent_upload(LocaleFormatConverter.displayToLocalCurrencysymb(blkamtUnsent,
              locale, accdetDetailInfo.getCurrcode()));

      accdetDetailInfo.setStrShdwAuthOv(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getShdwAuthOv(), locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setStrUnclrcredit(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getUnclrcredit(), locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setStrUnclrcredit_unsent(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getUnclrcredit_unsent(), locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setStrUnclrcredit_unsent_upload(LocaleFormatConverter
              .displayToLocalCurrencysymb(unclrcreditUnsent, locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setStrUnclrlocredit(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getUnclrlocredit(), locale, accdetDetailInfo.getCurrcode()));
    } catch (serverException se) {
      throw se;
    } catch (Exception e) {
      throw e;
    }

    return accdetDetailInfo;
  }

  private AccdetDetailInfo storeAmountToSQLFormat(AccdetDetailInfo accdetDetailInfo, Locale locale)
          throws serverException, Exception {
    try {
      // JFC 30/09/03: NMR010264: Set Avlbal from StrOpenbal!! not from the Available that is = avlbal - blkamt +
      // override
      accdetDetailInfo.setAvlbal(LocaleFormatConverter.storeToSqlCurrencysymb(accdetDetailInfo.getStrOpenbal(),
              locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setBlkamt(LocaleFormatConverter.storeToSqlCurrencysymb(accdetDetailInfo.getStrBlkamt(),
              locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setClrbal(LocaleFormatConverter.storeToSqlCurrencysymb(accdetDetailInfo.getStrClrbal(),
              locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setUnclrbal(LocaleFormatConverter.storeToSqlCurrencysymb(accdetDetailInfo.getStrUnclrbal(),
              locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setCredit_limit(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrCredit_limit(), locale, accdetDetailInfo.getCurrcode()));

      // Alvis 10/10/2007 CTXONLINE-88 : 2 new fields ACCDET.avlbal_unsent and ACCDET.blkamt_unsent added
      accdetDetailInfo.setAvlbal_unsent(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrAvlbal_unsent(), locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setBlkamt_unsent(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrBlkamt_unsent(), locale, accdetDetailInfo.getCurrcode()));

      accdetDetailInfo.setShdwAuthOv(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrShdwAuthOv(), locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setUnclrcredit(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrUnclrcredit(), locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setUnclrcredit_unsent(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrUnclrcredit_unsent(), locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setUnclrlocredit(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrUnclrlocredit(), locale, accdetDetailInfo.getCurrcode()));
    } catch (serverException se) {
      throw se;
    } catch (Exception e) {
      throw e;
    }
    return accdetDetailInfo;
  }

  private int getAccLength(AccdetDetailInfo accdetDetailInfo) throws serverException {
    int length = 0;
    Connection connection = null;
    PreparedStatement statement = null;
    ResultSet resultSet = null;
    try {
      connection = dbLib.getConnection(globalConstant.DATA_SOURCE);
      statement = connection.prepareStatement(SQLConstants.GET_IA_ACCLEN_DETAILS_SQL);
      statement.setString(1, accdetDetailInfo.getInstcode());
      statement.setString(2, accdetDetailInfo.getTypecode());
      resultSet = statement.executeQuery();
      while (resultSet.next()) {
        length = resultSet.getInt(1);
      }
    } catch (Exception e) {
      logError(CLASSNAME, e.toString());
      return -1;
    } finally {
      dbLib.closeResultSet(resultSet);
      dbLib.closeStatement(statement);
      dbLib.closeConnection(connection);
    }
    return length;
  }

  private AccdetDetailInfo storeUnsentToSQLFormat(AccdetDetailInfo accdetDetailInfo, Locale locale,
          double avlbalUnsent, double blkamtUnsent, double unclrcreditUnsent) throws serverException, Exception {
    try {
      accdetDetailInfo.setAvlbal(LocaleFormatConverter.storeToSqlCurrencysymb(accdetDetailInfo.getStrOpenbal(),
              locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setBlkamt(LocaleFormatConverter.storeToSqlCurrencysymb(accdetDetailInfo.getStrBlkamt(),
              locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setClrbal(LocaleFormatConverter.storeToSqlCurrencysymb(accdetDetailInfo.getStrClrbal(),
              locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setUnclrbal(LocaleFormatConverter.storeToSqlCurrencysymb(accdetDetailInfo.getStrUnclrbal(),
              locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setCredit_limit(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrCredit_limit(), locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setAvlbal_unsent(LocaleFormatConverter.storeToSqlCurrencysymb(LocaleFormatConverter
              .displayToLocalCurrencysymb(avlbalUnsent, locale, accdetDetailInfo.getCurrcode()), locale,
              accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setBlkamt_unsent(LocaleFormatConverter.storeToSqlCurrencysymb(LocaleFormatConverter
              .displayToLocalCurrencysymb(blkamtUnsent, locale, accdetDetailInfo.getCurrcode()), locale,
              accdetDetailInfo.getCurrcode()));

      accdetDetailInfo.setShdwAuthOv(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrShdwAuthOv(), locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setUnclrcredit(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrUnclrcredit(), locale, accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setUnclrcredit_unsent(LocaleFormatConverter.storeToSqlCurrencysymb(LocaleFormatConverter
              .displayToLocalCurrencysymb(unclrcreditUnsent, locale, accdetDetailInfo.getCurrcode()), locale,
              accdetDetailInfo.getCurrcode()));
      accdetDetailInfo.setUnclrlocredit(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrUnclrlocredit(), locale, accdetDetailInfo.getCurrcode()));
    } catch (serverException se) {
      throw se;
    } catch (Exception e) {
      throw e;
    }
    return accdetDetailInfo;
  }

  private int getAccountLoggingId(AccdetDetailInfo accdetDetailInfo, ActionErrors errors) {
    int acclogId = 1;
    try {
      Object ref = FunctionLib.getLookup(serverConstant.VIEW_ACCDET_SESSION);
      AccdetMgrHome accdetMgrHome = (AccdetMgrHome) PortableRemoteObject.narrow(ref, AccdetMgrHome.class);
      AccdetMgr accdetMgr = accdetMgrHome.create();

      AcctypeInfo acctypeInfo = accdetMgr.getAcctypeData(accdetDetailInfo.getInstcode(),
              accdetDetailInfo.getTypecode());

      acclogId = acctypeInfo.getAcclogId();

    } catch (CreateException e) {
      errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_UPDATE_FAILED_KEY));
    } catch (RemoteException ex) {
      errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_DB_CONNECT_FAILED_KEY));
    } catch (serverException ex) {
      errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ex.getErrorCode()));
    } catch (Exception ex) {
      errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
      logError(CLASSNAME, ex.toString());
    }

    return acclogId;
  }

  private Boolean createMkcAuthJob(HttpServletRequest request, AccdetDetailInfo info, AccdetDetailInfo displayInfo,
          Object originalInfo, AccdetDetailInfo displayOriginalInfo, AccdetXInfo infoX, AccdetXInfo originalInfoX,
          Boolean readonlyAmountAndAccountTypeFields, EntityType entityType,
          JobType jobType, String methodName, long entityId, String entityKey) throws Exception {
    AccdetDetailInfo keyInfo = displayInfo != null ? displayInfo : displayOriginalInfo;
    return Util.getMakerCheckerStatus(false, (String) request.getSession(false).getAttribute(viewConstant.USERNAME),
            request.getParameter(viewConstant.FORMACSITEM), keyInfo.getBrncode(), keyInfo.getInstcode(),
            globalConstant.SOURCE_ID_CTX,
            String.format(MkcConstants.ACCOUNT_REC_ID_FMT_PTRN, keyInfo.getInstcode(), keyInfo.getAccno(),
                    keyInfo.getCurrcode()),
            createJobAuthCallCollator(methodName, info, displayInfo, originalInfo, displayOriginalInfo, infoX,
                    originalInfoX, readonlyAmountAndAccountTypeFields, entityType, entityId, entityKey),
            jobType);
  }

  private JobAuthCallCollator createJobAuthCallCollator(String methodName, AccdetDetailInfo info,
          AccdetDetailInfo displayInfo, Object originalInfo, AccdetDetailInfo displayOriginalInfo,
          AccdetXInfo infoX, AccdetXInfo originalInfoX, Boolean readonlyAmountAndAccountTypeFields,
          EntityType entityType, long entityId, String entityKey) {
    JobAuthCallCollator jobAuthCallCollator = new JobAuthCallCollator(
            FunctionLib.getJNDIPrefix(serverConstant.VIEW_ACCDET_SESSION), ServiceType.JNDI_NAME, methodName, info,
            originalInfo, displayInfo, displayOriginalInfo, entityType.getCode(), entityId, entityKey,
            AccdetDetailInfo.aliasesMap);

    jobAuthCallCollator.addParameter(infoX, originalInfoX, entityType.getCode(), entityId, entityKey,
            AccdetXInfo.aliasesMap);

    if (readonlyAmountAndAccountTypeFields != null) {
      jobAuthCallCollator.addParameter(readonlyAmountAndAccountTypeFields, null, null);
    }

    return jobAuthCallCollator;
  }

  private String createAccountEntityKey(AccdetDetailInfo keyInfo) {
    return String.format(ENTITY_KEY_THREE_FMT_PTRN, keyInfo.getInstcode(), keyInfo.getAccno(),
            keyInfo.getCurrcode());
  }

  private String createCustomerEntityKey(AccdetDetailInfo keyInfo) {
    return String.format(ENTITY_KEY_TWO_FMT_PTRN, keyInfo.getInstcode(), keyInfo.getCustcode());
  }
  
  protected void performUnlink(HttpServletRequest request, ActionForm actionForm)
  {
    logInfo(CLASSNAME, "performUnlink");
    
    try
    {
      AccdetDetailInfo accdetDetailInfo = ((BREAccdetDetailForm) actionForm).getAccdetDetailInfo();
      
      Object ref = FunctionLib.getLookup(serverConstantBre.VIEW_BREACCDET_SESSION);
      BREAccdetMgrHome accdetMgrHome = (BREAccdetMgrHome) PortableRemoteObject.narrow(ref, BREAccdetMgrHome.class);
      BREAccdetMgr accdetMgr = accdetMgrHome.create();

      accdetMgr.unlinkAccdet(accdetDetailInfo);
    }
    catch (Exception e)
    {     
      logError(CLASSNAME, e.toString());
    }
  }
}
