package com.cortex.cust.bre.gui.ia.formbean;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import com.cortex.common.lib.debugLib;
import com.cortex.cust.bre.common.entityejb.CustIdCodeInfo;
import com.cortex.gui.common.formbean.PagingForm;
import com.cortex.gui.common.lib.LocaleFormatConverter;

/**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project No           : 1103  <br>
 * Module Name          : Ia<br>
 * Global Use Case      : N/A<br>
 * Business Use case    : N/A<br>
 * Maintenance Use case : N/A<br>
 * @author                j2eegen
 *
 *  The Struts framework generally assumes that
 *  you have created an ActionForm bean (that is,
 *  a Java class extending the ActionForm class)
 *  for each input form required in your application
 *
 * Date   Author     Reviewer    Description of change<br>
 *
 * @version 1.0
 */
public class CustIdCodeDetailForm extends PagingForm
{
    private final static String CLASSNAME = "CustIdCodeDetailForm";
    private CustIdCodeInfo mobjCust_idcodeInfo;


    /**
     * Constructor that accepts an Cust_idcodeInfo object
     *
     * @param     pobjCust_idcodeInfo  the info object of the form
     */
    public CustIdCodeDetailForm(CustIdCodeInfo pobjCust_idcodeInfo)
    {
        mobjCust_idcodeInfo = pobjCust_idcodeInfo;
    }

    /**
     * Default constructor.  It will create a new Cust_idcodeInfo object.
     * All the values of this info object are set to default.
     */
    public CustIdCodeDetailForm()
    {
        // The info object is no longer created in the constructor
        // It is created in the reset() method instead
    }


    /**
     * Get the info object of the form
     *
     * @return   the current info object of the form
     */
    public CustIdCodeInfo getCustIdCodeInfo()
    {
        return mobjCust_idcodeInfo;
    }

    /**
     * Sets the info object of the form
     *
     * @param pobjCust_idcodeInfo the info object
     */
    public void setCustIdCodeInfo(CustIdCodeInfo pobjCust_idcodeInfo)
    {
        mobjCust_idcodeInfo = pobjCust_idcodeInfo;
    }

                                                            // verno_ctx
    /**
     * Get the verno_ctx field from the form
     *
     * @return the verno_ctx value
     */
    public long getVerno_ctx()
    {
        return mobjCust_idcodeInfo.getVerno_ctx();
    }
    /**
     * Set the verno_ctx field into the form
     *
     * @param psId the verno_ctx value
     */
    public void setVerno_ctx(long psVerno_ctx)
    {
        mobjCust_idcodeInfo.setVerno_ctx (psVerno_ctx);
    }

        
                                                            // Locale long: id
    /**
     * Get the id long in the locale date format
     *
     * @return the id value
     */
    public String getId()
    {
        return LocaleFormatConverter.convertLongToLocale(mobjCust_idcodeInfo.getId(), getLocale());
    }
    /**
     * Set the id field given a string in the locale int format
     *
     * @param pobjId the id value
     */
    public void setId(String psLocaleId)
    {
        try
        {
            mobjCust_idcodeInfo.setId(LocaleFormatConverter.convertLocaleToLong(psLocaleId, getLocale()));
        }
        catch(java.text.ParseException e)
        {
            debugLib.logDetail(CLASSNAME, e, getUser());
            getActionErrors().add(ActionErrors.GLOBAL_ERROR, new ActionError("ia.label.cust_idcode.id.notvalidnumber"));
        }
    }
                
        
                                                            // Locale long: idtype_id
    /**
     * Get the idtype_id long in the locale date format
     *
     * @return the idtype_id value
     */
    public String getIdtype_id()
    {
        return LocaleFormatConverter.convertLongToLocale(mobjCust_idcodeInfo.getIdtype_id(), getLocale());
    }
    /**
     * Set the idtype_id field given a string in the locale int format
     *
     * @param pobjIdtype_id the idtype_id value
     */
    public void setIdtype_id(String psLocaleIdtype_id)
    {
        try
        {
            mobjCust_idcodeInfo.setIdtype_id(LocaleFormatConverter.convertLocaleToLong(psLocaleIdtype_id, getLocale()));
        }
        catch(java.text.ParseException e)
        {
            debugLib.logDetail(CLASSNAME, e, getUser());
            getActionErrors().add(ActionErrors.GLOBAL_ERROR, new ActionError("ia.label.cust_idcode.idtype_id.notvalidnumber"));
        }
    }
                
            
    // Locale long: custdet_id
    /**
     * Get the custdet_id long in the locale date format
     *
     * @return the custdet_id value
     */
    public String getCustdet_id()
    {
        return LocaleFormatConverter.convertLongToLocale(mobjCust_idcodeInfo.getCustdet_id(), getLocale());
    }
    /**
     * Set the custdet_id field given a string in the locale int format
     *
     * @param pobjCustdet_id the custdet_id value
     */
    public void setCustdet_id(String psLocaleCustdet_id)
    {
        try
        {
            mobjCust_idcodeInfo.setCustdet_id(LocaleFormatConverter.convertLocaleToLong(psLocaleCustdet_id, getLocale()));
        }
        catch(java.text.ParseException e)
        {
            debugLib.logDetail(CLASSNAME, e, getUser());
            getActionErrors().add(ActionErrors.GLOBAL_ERROR, new ActionError("ia.label.cust_idcode.custdet_id.notvalidnumber"));
        }
    }
        
    /**
     * 
     * @return
     */
    public String getInstCode() {
		return mobjCust_idcodeInfo.getInstCode();
	}
    /**
     * 
     * @param msInstCode
     */
	public void setInstCode(String msInstCode) {
		mobjCust_idcodeInfo.setInstCode(msInstCode);
	}
	/**
	 * 
	 * @return
	 */
	public String getCustCode() {
		return mobjCust_idcodeInfo.getCustCode();
	}
	/**
	 * 
	 * @param msCustCode
	 */
	public void setCustCode(String msCustCode) {
		mobjCust_idcodeInfo.setCustCode(msCustCode);
	}
	/**
	 * 
	 * @return
	 */
	public String getCustName() {
		return mobjCust_idcodeInfo.getCustName();
	}
	/**
	 * 
	 * @param msCustName
	 */
	public void setCustName(String msCustName) {
		mobjCust_idcodeInfo.setCustName(msCustName);
	}
	/**
	 * 
	 * @return
	 */
	public String getIdentificationCode() {
		return mobjCust_idcodeInfo.getIdentificationCode();
	}
	/**
	 * 
	 * @param indentificationCode
	 */
	public void setIdentificationCode(String identificationCode) {
		mobjCust_idcodeInfo.setIdentificationCode(identificationCode) ;
	}

    /**
     * This method performs extra validation in the form
     * It is typically called from the action class
     *
     * @return ActionErrors
     */
    public ActionErrors validateForm(ActionErrors errors)
    {
        // Please add here any extra validation

        return errors;
    }


    /**
     * Ensures that the class gets cleared when reused by the ActionServlet
     * It also calls super class to setup the locale, user name, action errors
     * and other values that will be used for this request/session.
     *
     * This method is called by the struts controller before start using the form.
     *
     * @param ActionMapping
     * @param HttpServletRequest
     * 
     * @return ActionErrors
     */
    public void reset(ActionMapping mapping,HttpServletRequest request)
    {
        // Please do not remove call to super
        super.reset(mapping, request);
        
        // Info object initialisation
        mobjCust_idcodeInfo = new CustIdCodeInfo();

        // Locale currency fields initialisation   
        //mobjCust_idcodeInfo.set(null);

        //No currency fields for this form

    }

}
