package com.cortex.cust.bre.gui.ia.formbean;

import java.util.Iterator;
import java.util.List;

import com.cortex.common.exception.serverException;
import com.cortex.common.lib.debugLib;
import com.cortex.cust.bre.gui.ia.valueobj.CustIdCodeSearchInfo;
import com.cortex.gui.common.formbean.PagingForm;

/**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project No           : 1103  <br>
 * Module Name          : Ia<br>
 * Global Use Case      : N/A<br>
 * Business Use case    : N/A<br>
 * Maintenance Use case : N/A<br>
 * @author                j2eegen
 *
 *  The Struts framework generally assumes that
 *  you have created an ActionForm bean (that is,
 *  a Java class extending the ActionForm class)
 *  for each input form required in your application
 *
 * Date   Author     Reviewer    Description of change<br>
 *
 * @version 1.0
 */
public class CustIdCodeSearchForm extends PagingForm
{
    private static final String CLASSNAME="CustIdCodeSearchForm";
    private CustIdCodeSearchInfo mobjCust_idcodeSearchInfo;
    private List mobjCust_idcodeSearchInfoList;

    /**
     * Constructor that accepts an Cust_idcodeSearchInfo object
     *
     * @param     pobjCust_idcodeSearchInfo  The info object of the form
     */
    public CustIdCodeSearchForm(CustIdCodeSearchInfo pobjCust_idcodeSearchInfo)
    {
        mobjCust_idcodeSearchInfo = pobjCust_idcodeSearchInfo;
    }

    /**
     * Default constructor.  It creates a new Cust_idcodeSearchInfo object.
     * All the values of this info object are set to default.
     */
    public CustIdCodeSearchForm()
    {
        mobjCust_idcodeSearchInfo = new CustIdCodeSearchInfo();
    }


    /**
     * Return the info object of the form
     *
     * @return   the current info object of the form
     */
    public CustIdCodeSearchInfo getCustIdCodeSearchInfo()
    {
        return mobjCust_idcodeSearchInfo;
    }
    /**
     * Return the info object of the form
     *
     * @return   the current info object of the form
     */
    public void setCustIdCodeSearchInfo(CustIdCodeSearchInfo pobjCust_idcodeSearchInfo)
    {
        mobjCust_idcodeSearchInfo = pobjCust_idcodeSearchInfo;
    }
    
    
    /**
     * Get the list of info object of the form.  This list contains the items
     * to be displayed in the search results list.
     *
     * @return   the current info object list of the form
     */
    public List getCustIdCodeSearchInfoList()
    {
        return mobjCust_idcodeSearchInfoList;
    }

    /**
     * Sets the list of info objects of the form.  This list contains the items
     * to be displayed in the search results list.
     *
     * @param pobjCust_idcodeSearchInfoList the array of Cust_idcodeSearchInfo objects
     */
    public void setCustIdCodeSearchInfoList(List pobjCust_idcodeSearchInfoList)
        throws serverException
    {
        mobjCust_idcodeSearchInfoList = pobjCust_idcodeSearchInfoList;

        try
        {
            Iterator tobjIterator = mobjCust_idcodeSearchInfoList.iterator();
            CustIdCodeSearchInfo tobjInfo = null;
            while(tobjIterator.hasNext())
            {
                tobjInfo = (CustIdCodeSearchInfo) tobjIterator.next();
                // Perform below any extra processing required for each record of the list
                // End of extra processing
            }
        }
        catch(Exception e)
        {
            debugLib.logError (CLASSNAME,e,getUser());
            throw new serverException("error.validation.ejbformat");
        }
    }

                                                            // idcode
    /**
     * Get the idcode field from the form
     *
     * @return the idcode value
     */
    public String getIdcode()
    {
        return mobjCust_idcodeSearchInfo.getIdcode();
    }
    /**
     * Set the idcode field into the form
     *
     * @param pobjIdcode the idcode value
     */
    public void setIdcode(String pobjIdcode)
    {
        mobjCust_idcodeSearchInfo.setIdcode (pobjIdcode);
    }

                                                            // id
    /**
     * Get the id field from the form
     *
     * @return the id value
     */
    public String getId()
    {
        return mobjCust_idcodeSearchInfo.getId();
    }
    /**
     * Set the id field into the form
     *
     * @param pobjId the id value
     */
    public void setId(String pobjId)
    {
        mobjCust_idcodeSearchInfo.setId (pobjId);
    }

                                                            // idtype_id
    /**
     * Get the idtype_id field from the form
     *
     * @return the idtype_id value
     */
    public String getIdtype_id()
    {
        return mobjCust_idcodeSearchInfo.getIdtype_id();
    }
    /**
     * Set the idtype_id field into the form
     *
     * @param pobjIdtype_id the idtype_id value
     */
    public void setIdtype_id(String pobjIdtype_id)
    {
        mobjCust_idcodeSearchInfo.setIdtype_id (pobjIdtype_id);
    }

                                                            // custdet_id
    /**
     * Get the custdet_id field from the form
     *
     * @return the custdet_id value
     */
    public String getCustdet_id()
    {
        return mobjCust_idcodeSearchInfo.getCustdet_id();
    }
    /**
     * Set the custdet_id field into the form
     *
     * @param pobjCustdet_id the custdet_id value
     */
    public void setCustdet_id(String pobjCustdet_id)
    {
        mobjCust_idcodeSearchInfo.setCustdet_id (pobjCustdet_id);
    }
    
    /**
     * get inst code
     * 
     * @return
     */
	public String getInstCode() {
		return mobjCust_idcodeSearchInfo.getInstCode();
	}
	/**
	 * set inst code
	 * 
	 * @param msInstCode
	 */
	public void setInstCode(String msInstCode) {
		mobjCust_idcodeSearchInfo.setInstCode(msInstCode);
	}
	/**
	 * get cust code
	 * 
	 * @return
	 */
	public String getCustCode() {
		return mobjCust_idcodeSearchInfo.getCustCode();
	}
	/**
	 * set cust code
	 * 
	 * @param msCustCode
	 */
	public void setCustCode(String msCustCode) {
		mobjCust_idcodeSearchInfo.setCustCode(msCustCode);
	}
	/**
	 * get customer name 
	 * 
	 * @return
	 */
	public String getCustName() {
		return mobjCust_idcodeSearchInfo.getCustName();
	}
	/**
	 * set customer name 
	 * 
	 * @param msCustName
	 */
	public void setCustName(String msCustName) {
		mobjCust_idcodeSearchInfo.setCustName(msCustName);
	}
	/**
	 * @return the msCustId
	 */
	public int getCustId() {
		return mobjCust_idcodeSearchInfo.getCustId();
	}
	/**
	 * @param msCustId the msCustId to set
	 */
	public void setCustId(int msCustId) {
		mobjCust_idcodeSearchInfo.setCustId(msCustId);
	}
	
	/**
	 * 
	 * @return
	 */
	public String getIndentificationCode() {
		return mobjCust_idcodeSearchInfo.getIndentificationCode();
	}
	/**
	 * 
	 * @param indentificationCode
	 */
	public void setIndentificationCode(String indentificationCode) {
		mobjCust_idcodeSearchInfo.setIndentificationCode(indentificationCode);
	}
	/**
	 * 
	 * @return
	 */
	public String getIndentificationTypeCode() {
		return mobjCust_idcodeSearchInfo.getIndentificationTypeCode();
	}
	/**
	 * 
	 * @param indentificationTypeCode
	 */
	public void setIndentificationTypeCode(String indentificationTypeCode) {
		mobjCust_idcodeSearchInfo.setIndentificationTypeCode(indentificationTypeCode);
	}
	/**
	 * 
	 * @return
	 */
	public String getIndentificationTypeDesc() {
		return mobjCust_idcodeSearchInfo.getIndentificationTypeDesc();
	}
	/**
	 * 
	 * @param indentificationTypeDesc
	 */
	public void setIndentificationTypeDesc(String indentificationTypeDesc) {
		mobjCust_idcodeSearchInfo.setIndentificationTypeDesc(indentificationTypeDesc);
	}
	
	public String getIndentificationTypeCodeAndDesc()
	{
		return mobjCust_idcodeSearchInfo.getIndentificationTypeCode() + " " + mobjCust_idcodeSearchInfo.getIndentificationTypeDesc();
	}

}
