package com.cortex.cust.bre.gui.ia.action;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import javax.ejb.CreateException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cortex.common.constant.serverConstant;
import com.cortex.common.exception.ServiceLocatorException;
import com.cortex.common.exception.serverException;
import com.cortex.common.lib.ServiceLocator;
import com.cortex.common.lib.debugLib;
import com.cortex.cust.bre.gui.ia.formbean.CustIdCodeSearchForm;
import com.cortex.cust.bre.gui.ia.sessionejb.CustIdCodeMgr;
import com.cortex.cust.bre.gui.ia.sessionejb.CustIdCodeMgrHome;
import com.cortex.cust.bre.gui.ia.valueobj.CustIdCodeSearchInfo;
import com.cortex.gui.common.action.PagingAction;
import com.cortex.gui.common.constant.viewConstant;
import com.cortex.gui.common.formbean.PagingForm;
import com.cortex.gui.common.valueobj.PagingContextInfo;
import com.cortex.gui.common.valueobj.SessionDataInfo;
import com.cortex.cust.bre.common.constant.SQLConstantsBre;
import com.cortex.cust.bre.common.constant.serverConstantBre;


/**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project No           : 1103  <br>
 * Module Name          : Aa<br>
 * Global Use Case      : N/A<br>
 * Business Use case    : N/A<br>
 * Maintenance Use case : N/A<br>
 * @author                j2eegen
 *
 * This is the Action class of the search screen for cust_idcode table
 *
 * Date   Author     Reviewer    Description of change<br>
 *
 * @version 1.0
 */
public class CustIdCodeSearchAction extends PagingAction
{

    private static final String CLASSNAME="CustIdCodeSearchAction";

    /**
     * This method is called when a new action is initiated from the form (i.e. user
     * presses a button).  This action will be decoded and processed.
     * When appropriate, a successfull processing will displayed a success message in
     * the screen.  Similarly, an error message will be displayed when processing fails.
     *
     * Below the actions supported by this perform method:
     * <UL>
     * <LI>
     * <default>:   This action happens when the user request showing the search screen.
     *              All the fields from the screen will be empty.
     * </LI>
     * <LI>
     * SEARCH:      This action happens when the user enters the search criteria and
     *              presses the search button.  The system will retrieve a list
     *              of the matching records from the database.
     * </LI>
     * </UL>
     *
     * @param pobjActionMapping The ActionMapping used to select this instance
     * @param pobjActionForm The optional ActionForm bean for this request (if any)
     * @param pobjRequest The HTTP request we are processing
     * @param pobjResponse The HTTP response we are creating
     *
     * @return ActionForward The ActionForward used to forward the request.
     *
     * @throws IOException thrown if an input/output error occurs
     * @throws ServletException thron if a servlet exception occurs
     */
   public ActionForward perform(ActionMapping pobjActionMapping, ActionForm pobjActionForm,
                                HttpServletRequest pobjRequest,  HttpServletResponse pobjResponse)
       throws IOException, ServletException
   {
        /*
         *  Set up variables
         */
        // Get user name for auditing purposes
        String tsUser = (String)pobjRequest.getSession().getAttribute(viewConstant.USERNAME);         
         
        // Store the ActionForm and info object in local variables for simplicity of the code
        CustIdCodeSearchForm tobjCust_idcodeSearchForm = (CustIdCodeSearchForm) pobjActionForm;
        CustIdCodeSearchInfo tobjCust_idcodeSearchInfo = tobjCust_idcodeSearchForm.getCustIdCodeSearchInfo();

        // Create ActionErrors variable used to store errors to be reported back to the client
        ActionErrors errors = new ActionErrors();

        // This variable contains the forwarding name that will be used to display
        // the next screen.
        String tsResult=viewConstant.RESULT_SUCCESS;

        // This variable contains the action to carry out (ie Add, Edit, Update or Delete)
        String tsFormAction = pobjRequest.getParameter(viewConstant.PARAMETER_FORMACTION);

        // Obtain paging context info object, used for paging search results list
        PagingContextInfo tobjPagingContextInfo = ((CustIdCodeSearchForm) pobjActionForm).getPagingContextInfo();

        // Obtain session data info object
        SessionDataInfo tobjSessionDataInfo = ((CustIdCodeSearchForm) pobjActionForm).getSessionDataInfo();

        // Get the Http Session from the request
        HttpSession tobjHttpSession = pobjRequest.getSession(true);

        // Check for the validity of the session information
        // This is required because if a subform uses paging, the SEARCH_DATA_INFO_KEY attribute
        // for this page will be invalidated
        if(tsFormAction!=null && (tsFormAction.equals(viewConstant.BUTTON_BACK) || tsFormAction.equals(viewConstant.BUTTON_DELETE))) {
           Object tobj = tobjHttpSession.getAttribute(serverConstant.SEARCH_DATA_INFO_KEY);
           if (tobj==null || !(tobj instanceof CustIdCodeSearchInfo)) {
               tsFormAction=null;    // session data corrupt.  Force empty search screen
           }
        }

        /*
         *  Display empty search screen
         */
        if((tsFormAction == null)||(tsFormAction.length() ==0))
        {
    
            tobjCust_idcodeSearchForm.setResultAction(viewConstant.RESULT_INIT);
        }

        /*
         *  Display search screen after coming back from detail screen
         */
        else if(tsFormAction.equals(viewConstant.BUTTON_BACK) || tsFormAction.equals(viewConstant.BUTTON_DELETE)) 
        {
            try
            {

                // Get screen information from session 
                tobjCust_idcodeSearchInfo = (CustIdCodeSearchInfo)tobjHttpSession.getAttribute(serverConstant.SEARCH_DATA_INFO_KEY);
                tobjPagingContextInfo = (PagingContextInfo)tobjHttpSession.getAttribute(serverConstant.SEARCH_PAGE_INFO_KEY);
                PagingContextInfo tobjRetPagingContextInfo = performSearch(tobjCust_idcodeSearchForm, tobjCust_idcodeSearchInfo, tobjPagingContextInfo);
                pobjRequest.setAttribute(viewConstant.PARAMETER_PAGEFORM,new PagingForm(tobjRetPagingContextInfo));

                // Set info object in form
                tobjCust_idcodeSearchForm.setCustIdCodeSearchInfo(tobjCust_idcodeSearchInfo);

                // Set success flag
                tobjCust_idcodeSearchForm.setResultAction(viewConstant.RESULT_SUCCESS);
                if(tsFormAction.equals(viewConstant.BUTTON_DELETE))
                {
                	pobjRequest.setAttribute(viewConstant.ACTION_SUCCESS_FLAG,"ia.msg.cust_idcode.success.delete");
                }

            }
            catch (serverException e) {
                errors.add (ActionErrors.GLOBAL_ERROR, new ActionError(e.getErrorCode()));
            }
            catch (RemoteException e)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.unknownerror"));
                debugLib.logError (CLASSNAME,e,tsUser);
            }
            catch (CreateException e)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.unknownerror"));
                debugLib.logError (CLASSNAME,e,tsUser);
            }

            catch (Exception e) {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError("error.unknownerror"));
                debugLib.logError (CLASSNAME,e,tsUser);
            }

        }

        /*
         *  Perform search given the search criteria entered (Search button pressed)
         */
        else if(tsFormAction.equals(viewConstant.BUTTON_SEARCH))
        {
            try
            {
                tobjCust_idcodeSearchInfo = tobjCust_idcodeSearchForm.getCustIdCodeSearchInfo();
                tobjPagingContextInfo = tobjCust_idcodeSearchForm.getPagingContextInfo();
                tobjSessionDataInfo = tobjCust_idcodeSearchForm.getSessionDataInfo();

                // Set various info objects for use of the JSP
                tobjHttpSession.setAttribute(serverConstant.SEARCH_DATA_INFO_KEY,tobjCust_idcodeSearchInfo);
                tobjHttpSession.setAttribute(serverConstant.SEARCH_PAGE_INFO_KEY,tobjPagingContextInfo);
                tobjCust_idcodeSearchForm.setCustCode(pobjRequest.getParameter(serverConstantBre.GET_CUSTOMER_CUST_CODE));
                tobjCust_idcodeSearchForm.setInstCode(pobjRequest.getParameter(serverConstantBre.GET_CUSTOMER_INST_CODE));
                // Perform search
                PagingContextInfo tobjRetPagingContextInfo = performSearch(tobjCust_idcodeSearchForm, tobjCust_idcodeSearchInfo, tobjPagingContextInfo);

                // Set page details object in the form to display search results list
                pobjRequest.setAttribute(viewConstant.PARAMETER_PAGEFORM, new PagingForm(tobjRetPagingContextInfo));
                tobjCust_idcodeSearchForm.setResultAction(viewConstant.RESULT_SUCCESS);
            }
            catch (serverException e) {
                errors.add (ActionErrors.GLOBAL_ERROR, new ActionError(e.getErrorCode()));
            }
            catch (RemoteException e)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.unknownerror"));
                debugLib.logError (CLASSNAME,e,tsUser);
            }
            catch (CreateException e)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.unknownerror"));
                debugLib.logError (CLASSNAME,e,tsUser);
            }
            catch (Exception e) {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError("error.unknownerror"));
                debugLib.logError (CLASSNAME,e,tsUser);
            }
        }


        // Check for errors
        if (!errors.empty())
        {
            tobjCust_idcodeSearchForm.setResultAction(viewConstant.RESULT_ERROR);
            tsResult=viewConstant.RESULT_ERROR;
            saveErrors(pobjRequest, errors);
        }
        else
        {
            tsResult=viewConstant.RESULT_SUCCESS;
        }

        // Attach new form to request and forward result
        pobjRequest.setAttribute("Cust_idcodeSearchForm",tobjCust_idcodeSearchForm);
        return pobjActionMapping.findForward(tsResult);
    }
    
    /**
     * Method Used to perform the search operation.
     * @param pobjCust_idcodeSearchForm of type Cust_idcodeSearchForm
     * @param pobjCust_idcodeSearchInfo of type Cust_idcodeSearchInfo
     * @param pobjPagingContextInfo of type PagingContextInfo
     * @return PagingContextInfo
     * @throws Exception
     */
    private PagingContextInfo performSearch(CustIdCodeSearchForm pobjCust_idcodeSearchForm,
                                         CustIdCodeSearchInfo pobjCust_idcodeSearchInfo, PagingContextInfo pobjPagingContextInfo)
      throws serverException, RemoteException, CreateException, ServiceLocatorException
    {
    	CustIdCodeMgrHome tobjCust_idcodeMgrHome = (CustIdCodeMgrHome) 
                        ServiceLocator.getInstance().getRemoteHome(serverConstantBre.VIEW_CUST_IDCODE_SESSION, CustIdCodeMgrHome.class);
    	CustIdCodeMgr tobjCust_idcodeMgr = tobjCust_idcodeMgrHome.create();
    	//
    	//getting customer details
    	Map customerDetails = tobjCust_idcodeMgr.getCustomerDetails(pobjCust_idcodeSearchForm.getCustCode(), pobjCust_idcodeSearchForm.getInstCode());
    	pobjCust_idcodeSearchForm.setCustName((String)customerDetails.get(SQLConstantsBre.GET_CUSTOMER_NAME));
    	pobjCust_idcodeSearchForm.setCustId(((Integer)customerDetails.get(SQLConstantsBre.GET_CUSTOMER_ID)).intValue());
    	
        // IMPORTANT: The list returned contains all the elements to be displayed in the
        //            search results list (positions 0 to size()-2), and the paging info
        //            in the last element! (position size()-1)
        List pobjList = tobjCust_idcodeMgr.searchCustIdCode(pobjCust_idcodeSearchInfo,pobjPagingContextInfo);

        // Set paging context info to form        
        PagingContextInfo tobjPagingContextInfo = (PagingContextInfo)pobjList.remove(pobjList.size() - 1);
        pobjCust_idcodeSearchForm.setPagingContextInfo(tobjPagingContextInfo);

        // Set results list to form
        pobjCust_idcodeSearchForm.setCustIdCodeSearchInfoList(pobjList);

        return tobjPagingContextInfo;
    }


}
