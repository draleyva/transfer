package com.cortex.cust.bre.gui.ia.formbean;

import javax.servlet.http.HttpServletRequest;
import com.cortex.common.entityejb.AccdetXInfo;
import com.cortex.gui.common.formbean.SessionDataForm;
import com.cortex.gui.ia.valueobj.AccdetDetailInfo;
import com.cortex.common.constant.globalConstant;
import com.cortex.common.lib.dbLib;
import com.cortex.common.lib.debugLib;
import com.cortex.gui.common.lib.LocaleFormatConverter;
import org.apache.struts.action.ActionMapping;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author e5706717
 */
public class BREAccdetDetailForm extends SessionDataForm {

  private static final String CLASSNAME = "BREAccdetDetailForm";
  private AccdetDetailInfo mobjAccdetDetailInfo;
  private AccdetXInfo mobjAccdetXInfo;

  private String msCurrencyAlphaCode = "";
  private String msCurrencyDesc = "";
  private String msInstId = "";
  private String msFrmId = "--";
  private String msFromwhere = "";
  private String msBranchDescr = "";
  private String msIsCrdaccLnk = "false";
  private String msPan = "";
  private String msSeqno = "";
  private String acclogId = "1";

  /**
   * Constructor that accepts an AccdetDetailInfo object
   *
   * @param pobjAccdetDetailInfo the info object of the form
   */
  public BREAccdetDetailForm(AccdetDetailInfo pobjAccdetDetailInfo) {
    mobjAccdetDetailInfo = pobjAccdetDetailInfo;
  }

  /**
   * Default constructor. It will create a new AccdetDetailInfo object. All the
   * values of this info object are set to default.
   */
  public BREAccdetDetailForm() {
    mobjAccdetDetailInfo = new AccdetDetailInfo();
    mobjAccdetXInfo = new AccdetXInfo();
  }

  /**
   * Get the info object of the form
   *
   * @return the current info object of the form
   */
  public AccdetDetailInfo getAccdetDetailInfo() {
    return mobjAccdetDetailInfo;
  }

  /**
   * Sets the info object of the form
   *
   * @param pobjAccdetDetailInfo the info object
   */
  public void setAccdetDetailInfo(AccdetDetailInfo pobjAccdetDetailInfo) {
    mobjAccdetDetailInfo = pobjAccdetDetailInfo;
  }

  // verno_ctx
  /**
   * Get the verno_ctx field from the form
   *
   * @return the verno_ctx value
   */
  public long getVerno_ctx() {
    return mobjAccdetDetailInfo.getVerno_ctx();
  }

  /**
   * Set the verno_ctx field into the form
   *
   * @param plVerno_ctx the verno_ctx value
   */
  public void setVerno_ctx(long plVerno_ctx) {
    mobjAccdetDetailInfo.setVerno_ctx(plVerno_ctx);
  }

  // instcode
  /**
   * Get the instcode field from the form
   *
   * @return the instcode value
   */
  public String getInstcode() {
    return mobjAccdetDetailInfo.getInstcode();
  }

  /**
   * Set the instcode field into the form
   *
   * @param psInstcode the instcode value
   */
  public void setInstcode(String psInstcode) {
    mobjAccdetDetailInfo.setInstcode(psInstcode);
  }

  // accno
  /**
   * Get the accno field from the form
   *
   * @return the accno value
   */
  public String getAccno() {
    return mobjAccdetDetailInfo.getAccno();
  }

  /**
   * Set the accno field into the form
   *
   * @param psAccno the accno value
   */
  public void setAccno(String psAccno) {
    mobjAccdetDetailInfo.setAccno(psAccno);
  }

  // currcode
  /**
   * Get the currcode field from the form
   *
   * @return the currcode value
   */
  public String getCurrcode() {

    if (mobjAccdetDetailInfo.getCurrcode() != null) {
      String tsCurrcode = mobjAccdetDetailInfo.getCurrcode();
      try {
        // no exception thrown if currcode is empty string
        msCurrencyAlphaCode = LocaleFormatConverter.getAlphacode(tsCurrcode);
        msCurrencyDesc = LocaleFormatConverter.
                getCurrencyDescription(tsCurrcode, getLocale().getLanguage().toUpperCase());
      } catch (Exception e) {
        debugLib.logDetail(CLASSNAME, e, getUser());
        msCurrencyAlphaCode = "";
        msCurrencyDesc = "";
      }
    }
    return mobjAccdetDetailInfo.getCurrcode();

  }

  /**
   * Set the currcode field into the form
   *
   * @param psCurrcode the currcode value
   */
  public void setCurrcode(String psCurrcode) {
    mobjAccdetDetailInfo.setCurrcode(psCurrcode);

    try {
      // no exception thrown if currcode is empty string
      msCurrencyAlphaCode = LocaleFormatConverter.getAlphacode(psCurrcode);
      msCurrencyDesc = LocaleFormatConverter.
              getCurrencyDescription(psCurrcode, getLocale().getLanguage().toUpperCase());
    } catch (Exception e) {
      debugLib.logDetail(CLASSNAME, e, getUser());
      msCurrencyAlphaCode = "";
      msCurrencyDesc = "";
    }
  }

  // custcode
  /**
   * Get the custcode field from the form
   *
   * @return the custcode value
   */
  public String getCustcode() {
    return mobjAccdetDetailInfo.getCustcode();
  }

  /**
   * Set the custcode field into the form
   *
   * @param psCustcode the custcode value
   */
  public void setCustcode(String psCustcode) {
    mobjAccdetDetailInfo.setCustcode(psCustcode);
  }

  /**
   * Gets the Lastname value
   *
   * @return String
   */
  public String getLastname() {
    return mobjAccdetDetailInfo.getLastname();
  }

  /**
   * Sets the Lastname value
   *
   * @param psLastname last name
   */
  public void setLastname(String psLastname) {
    mobjAccdetDetailInfo.setLastname(psLastname);
  }

  /**
   * Gets the Firstname value
   *
   * @return String
   */
  public String getFirstname() {
    return mobjAccdetDetailInfo.getFirstname();
  }

  /**
   * Sets the Firstname value
   *
   * @param psFirstname first name
   */
  public void setFirstname(String psFirstname) {
    mobjAccdetDetailInfo.setFirstname(psFirstname);
  }

  /**
   * Gets the Title value
   *
   * @return String
   */
  public String getTitle() {
    return mobjAccdetDetailInfo.getTitle();
  }

  /**
   * Sets the Title value
   *
   * @param psTitle title
   */
  public void setTitle(String psTitle) {
    mobjAccdetDetailInfo.setTitle(psTitle);
  }
  // brncode

  /**
   * Get the brncode field from the form
   *
   * @return the brncode value
   */
  public String getBrncode() {
    return mobjAccdetDetailInfo.getBrncode();
  }

  /**
   * Set the brncode field into the form
   *
   * @param psBrncode the brncode value
   */
  public void setBrncode(String psBrncode) {
    mobjAccdetDetailInfo.setBrncode(psBrncode);
  }

  // typecode
  /**
   * Get the typecode field from the form
   *
   * @return the typecode value
   */
  public String getTypecode() {
    return mobjAccdetDetailInfo.getTypecode();
  }

  /**
   * Set the typecode field into the form
   *
   * @param psTypecode the typecode value
   */
  public void setTypecode(String psTypecode) {
    mobjAccdetDetailInfo.setTypecode(psTypecode);
  }

  // classid
  /**
   * Get the classid field from the form
   *
   * @return the classid value
   */
  public int getClassid() {
    return mobjAccdetDetailInfo.getClassid();
  }

  /**
   * Set the classid field into the form
   *
   * @param piClassid the classid value
   */
  public void setClassid(int piClassid) {
    mobjAccdetDetailInfo.setClassid(piClassid);
  }

  // statcode
  /**
   * Get the statcode field from the form
   *
   * @return the statcode value
   */
  public String getStatcode() {
    return mobjAccdetDetailInfo.getStatcode();
  }

  /**
   * Set the statcode field into the form
   *
   * @param psStatcode the statcode value
   */
  public void setStatcode(String psStatcode) {
    mobjAccdetDetailInfo.setStatcode(psStatcode);
  }

  // vipflag
  /**
   * Get the vipflag field from the form
   *
   * @return the vipflag value
   */
  public String getVipflag() {
    return mobjAccdetDetailInfo.getVipflag();
  }

  /**
   * Set the vipflag field into the form
   *
   * @param psVipflag the vipflag value
   */
  public void setVipflag(String psVipflag) {
    mobjAccdetDetailInfo.setVipflag(psVipflag);
  }

  // blkamt
  /**
   * Get the blkamt field from the form
   *
   * @return the blkamt value
   */
  public double getBlkamt() {
    return mobjAccdetDetailInfo.getBlkamt();
  }

  /**
   * Set the blkamt field into the form
   *
   * @param pdBlkamt the blkamt value
   */
  public void setBlkamt(double pdBlkamt) {
    mobjAccdetDetailInfo.setBlkamt(pdBlkamt);
  }

  //public double getOpenbal()
  //{
  //    return mobjAccdetDetailInfo.getOpenbal() ; //(mobjAccdetDetailInfo.getAvlbal() - mobjAccdetDetailInfo.getBlkamt());
  //}
  /**
   * Set the Openbal field into the form
   *
   * @param pdOpenbal the blkamt value
   */
  public void setOpenbal(double pdOpenbal) {
    mobjAccdetDetailInfo.setBlkamt(pdOpenbal);
  }

  // avlbal
  /**
   * Get the avlbal field from the form
   *
   * @return the avlbal value
   */
  public double getAvlbal() {
    return mobjAccdetDetailInfo.getAvlbal();
  }

  /**
   * Set the avlbal field into the form
   *
   * @param pdAvlbal the avlbal value
   */
  public void setAvlbal(double pdAvlbal) {
    mobjAccdetDetailInfo.setAvlbal(pdAvlbal);
  }

  // clrbal
  /**
   * Get the clrbal field from the form
   *
   * @return the clrbal value
   */
  public double getClrbal() {
    return mobjAccdetDetailInfo.getClrbal();
  }

  /**
   * Set the clrbal field into the form
   *
   * @param pdClrbal the clrbal value
   */
  public void setClrbal(double pdClrbal) {
    mobjAccdetDetailInfo.setClrbal(pdClrbal);
  }

  // unclrbal
  /**
   * Get the unclrbal field from the form
   *
   * @return the unclrbal value
   */
  public double getUnclrbal() {
    return mobjAccdetDetailInfo.getUnclrbal();
  }

  /**
   * Set the unclrbal field into the form
   *
   * @param pdUnclrbal the unclrbal value
   */
  public void setUnclrbal(double pdUnclrbal) {
    mobjAccdetDetailInfo.setUnclrbal(pdUnclrbal);
  }

  // credit_limit
  /**
   * Get the credit_limit field from the form
   *
   * @return the credit_limit value
   */
  public double getCredit_limit() {
    return mobjAccdetDetailInfo.getCredit_limit();
  }

  /**
   * Set the credit_limit field into the form
   *
   * @param pdCredit_limit the credit_limit value
   */
  public void setCredit_limit(double pdCredit_limit) {
    mobjAccdetDetailInfo.setCredit_limit(pdCredit_limit);
  }

  /**
   * Set the Strblkamt field into the form
   *
   * @param psStrBlkamt the Strblkamt value
   */
  public void setStrBlkamt(String psStrBlkamt) {
    mobjAccdetDetailInfo.setStrBlkamt(psStrBlkamt);
  }

  /**
   * Get the Stravlbal field from the form
   *
   * @return the Stravlbal value
   */
  public String getStrBlkamt() {
    return mobjAccdetDetailInfo.getStrBlkamt();
  }
  // avlbal

  /**
   * Get the Stravlbal field from the form
   *
   * @return the Stravlbal value
   */
  public String getStrAvlbal() {
    return mobjAccdetDetailInfo.getStrAvlbal();
  }

  /**
   * Set the Stravlbal field into the form
   *
   * @param psStrAvlbal the Stravlbal value
   */
  public void setStrAvlbal(String psStrAvlbal) {
    mobjAccdetDetailInfo.setStrAvlbal(psStrAvlbal);
  }

  // clrbal
  /**
   * Get the Strclrbal field from the form
   *
   * @return the Strclrbal value
   */
  public String getStrClrbal() {
    return mobjAccdetDetailInfo.getStrClrbal();
  }

  /**
   * Set the Strclrbal field into the form
   *
   * @param psStrClrbal the Strclrbal value
   */
  public void setStrClrbal(String psStrClrbal) {
    mobjAccdetDetailInfo.setStrClrbal(psStrClrbal);
  }

  // unclrbal
  /**
   * Get the Strunclrbal field from the form
   *
   * @return the Strunclrbal value
   */
  public String getStrUnclrbal() {
    return mobjAccdetDetailInfo.getStrUnclrbal();
  }

  /**
   * Set the Strunclrbal field into the form
   *
   * @param psStrUnclrbal the Strunclrbal value
   */
  public void setStrUnclrbal(String psStrUnclrbal) {
    mobjAccdetDetailInfo.setStrUnclrbal(psStrUnclrbal);
  }

  // credit_limit
  /**
   * Get the Strcredit_limit field from the form
   *
   * @return the Strcredit_limit value
   */
  public String getStrCredit_limit() {
    return mobjAccdetDetailInfo.getStrCredit_limit();
  }

  /**
   * Set the Strcredit_limit field into the form
   *
   * @param psStrCredit_limit the Strcredit_limit value
   */
  public void setStrCredit_limit(String psStrCredit_limit) {
    mobjAccdetDetailInfo.setStrCredit_limit(psStrCredit_limit);
  }

  /**
   * Gets the StrCurrencyAlphaCode value
   *
   * @return String
   */
  public String getCurrencyAlphaCode() {
    return msCurrencyAlphaCode;
  }

  /**
   * Sets the StrCurrencyAlphaCode value
   *
   * @param psCurrencyAlphaCode currency alpha code
   */
  public void setCurrencyAlphaCode(String psCurrencyAlphaCode) {
    /* 
         * Set by setCurrcode
     */
    //msCurrencyAlphaCode = psCurrencyAlphaCode;
  }

  /**
   * Gets the StrcurrencyDesc value
   *
   * @return String
   */
  public String getCurrencyDesc() {
    return msCurrencyDesc;
  }

  /**
   * Sets the StrcurrencyDesc value
   *
   * @param psCurrencyDesc Currency Description
   */
  public void setCurrencyDesc(String psCurrencyDesc) {
    /* 
         * Set by setCurrcode
     */
    //msCurrencyDesc = psCurrencyDesc;
  }

  /**
   * Gets the InstId value
   *
   * @return String
   */
  public String getInstId() {
    return msInstId;
  }

  /**
   * Sets the psInstId value
   *
   * @param psInstId institution in where clause
   */
  public void setInstId(String psInstId) {
    msInstId = psInstId;
  }

  /**
   * Gets the FrmId value
   *
   * @return String
   */
  public String getFrmId() {
    return msFrmId;
  }

  /**
   * Sets the FrmId value
   *
   * @param psFrmId set frmid
   */
  public void setFrmId(String psFrmId) {
    msFrmId = psFrmId;
  }

  /**
   * Gets the Fromwhere value
   *
   * @return String
   */
  public String getFromwhere() {
    return msFromwhere;
  }

  /**
   * Sets the Fromwhere value
   *
   * @param psFromwhere from where
   */
  public void setFromwhere(String psFromwhere) {
    msFromwhere = psFromwhere;
  }

  public String getStrOpenbal() {
    return mobjAccdetDetailInfo.getStrOpenbal();
  }

  public void setStrOpenbal(String psmsopenbal) {
    mobjAccdetDetailInfo.setStrOpenbal(psmsopenbal);
  }

  public String getBranchDescr() {
    return msBranchDescr;
  }

  public void setBranchDescr(String psBranchDescr) {
    this.msBranchDescr = psBranchDescr;
  }

  // JFC 30/09/03: NMR010264: Adding the override field to the form
  // StrOverride
  /**
   * Get the StrOverride field from the form
   *
   * @return the StrOverride value
   */
  public String getStrOverride() {
    return mobjAccdetDetailInfo.getStrOverride();
  }

  /**
   * Set the StrOverride field into the form
   *
   * @param psStrOverride the StrOverride value
   */
  public void setStrOverride(String psStrOverride) {
    mobjAccdetDetailInfo.setStrOverride(psStrOverride);
  }

  /**
   * Get the IsCrdaccLnk field from the form
   *
   * @return the IsCrdaccLnk value
   */
  public String getIsCrdaccLnk() {
    return msIsCrdaccLnk;
  }

  /**
   * Set the IsCrdaccLnk field into the form
   *
   * @param psIsCrdaccLnk the IsCrdaccLnk value
   */
  public void setIsCrdaccLnk(String psIsCrdaccLnk) {
    msIsCrdaccLnk = psIsCrdaccLnk;
  }

  /**
   * Get the Pan field from the form
   *
   * @return the Pan value
   */
  public String getPan() {
    return msPan;
  }

  /**
   * Set the Pan field into the form
   *
   * @param psPan the Pan value
   */
  public void setPan(String psPan) {
    msPan = psPan;
  }

  /**
   * Get the Seqno field from the form
   *
   * @return the Seqno value
   */
  public String getSeqno() {
    return msSeqno;
  }

  /**
   * Set the Seqno field into the form
   *
   * @param psSeqno the Seqno value
   */
  public void setSeqno(String psSeqno) {
    msSeqno = psSeqno;
  }

  public String getReadonlyAmountFields() {
    return mobjAccdetDetailInfo.getReadonlyAmountFields();
  }

  public void setReadonlyAmountFields(String psReadonlyAmountFields) {
    mobjAccdetDetailInfo.setReadonlyAmountFields(psReadonlyAmountFields);
  }

  // avlbal_unsent
  public double getAvlbal_unsent() {
    return mobjAccdetDetailInfo.getAvlbal_unsent();
  }

  public void setAvlbal_unsent(double pdAvlbal_unsent) {
    mobjAccdetDetailInfo.setAvlbal_unsent(pdAvlbal_unsent);
  }

  // blkamt_unsent
  public double getBlkamt_unsent() {
    return mobjAccdetDetailInfo.getBlkamt_unsent();
  }

  public void setBlkamt_unsent(double pdBlkamt_unsent) {
    mobjAccdetDetailInfo.setBlkamt_unsent(pdBlkamt_unsent);
  }

  public String getStrAvlbal_unsent() {
    return mobjAccdetDetailInfo.getStrAvlbal_unsent();
  }

  public void setStrAvlbal_unsent(String psStrAvlbal_unsent) {
    mobjAccdetDetailInfo.setStrAvlbal_unsent(psStrAvlbal_unsent);
  }

  public String getStrBlkamt_unsent() {
    return mobjAccdetDetailInfo.getStrBlkamt_unsent();
  }

  public void setStrBlkamt_unsent(String psStrBlkamt_unsent) {
    mobjAccdetDetailInfo.setStrBlkamt_unsent(psStrBlkamt_unsent);
  }

  public String getStrAvlbal_unsent_upload() {
    return mobjAccdetDetailInfo.getStrAvlbal_unsent_upload();
  }

  public void setStrAvlbal_unsent_upload(String psStrAvlbal_unsent_upload) {
    mobjAccdetDetailInfo.setStrAvlbal_unsent_upload(psStrAvlbal_unsent_upload);
  }

  public String getStrBlkamt_unsent_upload() {
    return mobjAccdetDetailInfo.getStrBlkamt_unsent_upload();
  }

  public void setStrBlkamt_unsent_upload(String psStrBlkamt_unsent_upload) {
    mobjAccdetDetailInfo.setStrBlkamt_unsent_upload(psStrBlkamt_unsent_upload);
  }

  public String getStrPreauth_blk() {
    return mobjAccdetDetailInfo.getStrPreauth_blk();
  }

  public void setPreauth_blk(String mspreauth_blk) {
    this.mobjAccdetDetailInfo.setStrPreauth_blk(mspreauth_blk);
  }

  public String getStrPreauth_unclr() {
    return mobjAccdetDetailInfo.getStrPreauth_unclr();
  }

  public void setStrPreauth_unclr(String mspreauth_unclr) {
    this.mobjAccdetDetailInfo.setStrPreauth_unclr(mspreauth_unclr);
  }

  public String getStrPreauth_exp_blk() {
    return mobjAccdetDetailInfo.getStrPreauth_exp_blk();
  }

  public void setStrPreauth_exp_blk(String mspreauth_exp_blk) {
    this.mobjAccdetDetailInfo.setStrPreauth_exp_blk(mspreauth_exp_blk);
  }

  public String getStrPreauth_exp_unclr() {
    return mobjAccdetDetailInfo.getStrPreauth_exp_unclr();
  }

  public void setStrPreauth_exp_unclr(String mspreauth_exp_unclr) {
    this.mobjAccdetDetailInfo.setStrPreauth_exp_unclr(mspreauth_exp_unclr);
  }

  public int getCustTypeid() {
    return mobjAccdetDetailInfo.getCustTypeid();
  }

  public void setCustTypeid(int piCustTypeid) {
    mobjAccdetDetailInfo.setCustTypeid(piCustTypeid);
  }

  public double getShdwAuthOv() {
    return mobjAccdetDetailInfo.getShdwAuthOv();
  }

  public void setShdwAuthOv(double shdwAuthOv) {
    mobjAccdetDetailInfo.setShdwAuthOv(shdwAuthOv);
  }

  public String getStrShdwAuthOv() {
    return mobjAccdetDetailInfo.getStrShdwAuthOv();
  }

  public void setStrShdwAuthOv(String msshdwAuthOv) {
    mobjAccdetDetailInfo.setStrShdwAuthOv(msshdwAuthOv);
  }

  public boolean getReadonlyStatcodeField() {
    return mobjAccdetDetailInfo.getReadonlyStatcodeField();
  }

  public void setReadonlyStatcodeField(boolean psReadonlyStatcodeField) {
    mobjAccdetDetailInfo.setReadonlyStatcodeField(psReadonlyStatcodeField);
  }

  /**
   * Get the unclrcredit field from the form
   *
   * @return the unclrcredit value
   */
  public double getUnclrcredit() {
    return mobjAccdetDetailInfo.getUnclrcredit();
  }

  /**
   * Set the unclrcredit field into the form
   *
   * @param psUnclrcredit the unclrcredit value
   */
  public void setUnclrcredit(double psUnclrcredit) {
    mobjAccdetDetailInfo.setUnclrcredit(psUnclrcredit);
  }

  /**
   * Get the StrUnclrcredit field from the form
   *
   * @return the StrUnclrcredit value
   */
  public String getStrUnclrcredit() {
    return mobjAccdetDetailInfo.getStrUnclrcredit();
  }

  /**
   * Set the StrUnclrcredit field into the form
   *
   * @param psunclrcredit the StrUnclrcredit value
   */
  public void setStrUnclrcredit(String psunclrcredit) {
    mobjAccdetDetailInfo.setStrUnclrcredit(psunclrcredit);
  }

  /**
   * Get the StrUnclrcredit_unsent field from the form
   *
   * @return the StrUnclrcredit_unsent value
   */
  public String getStrUnclrcredit_unsent() {
    return mobjAccdetDetailInfo.getStrUnclrcredit_unsent();
  }

  /**
   * Set the StrUnclrcredit_unsent field into the form
   *
   * @param psnclrcredit_unsent the StrUnclrcredit_unsent value
   */
  public void setStrUnclrcredit_unsent(String psnclrcredit_unsent) {
    mobjAccdetDetailInfo.setStrUnclrcredit_unsent(psnclrcredit_unsent);
  }

  /**
   * Get the StrUnclrcredit_unsent_upload field from the form
   *
   * @return the StrUnclrcredit_unsent_upload value
   */
  public String getStrUnclrcredit_unsent_upload() {
    return mobjAccdetDetailInfo.getStrUnclrcredit_unsent_upload();
  }

  /**
   * Set the StrUnclrcredit_unsent_upload field into the form
   *
   * @param psUnclrcredit_unsent_upload the StrUnclrcredit_unsent_upload value
   */
  public void setStrUnclrcredit_unsent_upload(String psUnclrcredit_unsent_upload) {
    mobjAccdetDetailInfo.setStrUnclrcredit_unsent_upload(psUnclrcredit_unsent_upload);
  }

  public double getUnclrlocredit() {
    return mobjAccdetDetailInfo.getUnclrlocredit();
  }

  public void setUnclrlocredit(double newUnclrlocredit) {
    mobjAccdetDetailInfo.setUnclrlocredit(newUnclrlocredit);
  }

  public String getStrUnclrlocredit() {
    return mobjAccdetDetailInfo.getStrUnclrlocredit();
  }

  public void setStrUnclrlocredit(String psunclrlocredit) {
    mobjAccdetDetailInfo.setStrUnclrlocredit(psunclrlocredit);
  }

  /**
   * TODO description.
   *
   * @return AccdetXInfo
   */
  public AccdetXInfo getAccdetXInfo() {
    return mobjAccdetXInfo;
  }

  /**
   * TODO description.
   *
   * @param mobjAccdetXInfo accdetx info
   */
  public void setAccdetXInfo(AccdetXInfo mobjAccdetXInfo) {
    this.mobjAccdetXInfo = mobjAccdetXInfo;
  }

  /**
   * TODO description.
   *
   * @return TODO description
   */
  public String getUsrdata1Label() {
    return mobjAccdetXInfo.getUsrdata1Label();
  }

  /**
   * TODO description.
   *
   * @param label TODO description
   */
  public void setUsrdata1Label(String label) {
    mobjAccdetXInfo.setUsrdata1Label(label);
  }

  /**
   * TODO description.
   *
   * @return TODO description
   */
  public String getUsrdata2Label() {
    return mobjAccdetXInfo.getUsrdata2Label();
  }

  /**
   * TODO description.
   *
   * @param label TODO description
   */
  public void setUsrdata2Label(String label) {
    mobjAccdetXInfo.setUsrdata2Label(label);
  }

  /**
   * TODO description.
   *
   * @return TODO description
   */
  public String getUsrdata3Label() {
    return mobjAccdetXInfo.getUsrdata3Label();
  }

  /**
   * TODO description.
   *
   * @param label TODO description
   */
  public void setUsrdata3Label(String label) {
    mobjAccdetXInfo.setUsrdata3Label(label);
  }

  /**
   * TODO description.
   *
   * @return TODO description
   */
  public String getUsrdata4Label() {
    return mobjAccdetXInfo.getUsrdata4Label();
  }

  /**
   * TODO description.
   *
   * @param label TODO description
   */
  public void setUsrdata4Label(String label) {
    mobjAccdetXInfo.setUsrdata4Label(label);
  }

  /**
   * TODO description.
   *
   * @return TODO description
   */
  public String getUsrdata5Label() {
    return mobjAccdetXInfo.getUsrdata5Label();
  }

  /**
   * TODO description.
   *
   * @param label TODO description
   */
  public void setUsrdata5Label(String label) {
    mobjAccdetXInfo.setUsrdata5Label(label);
  }

  // usrdata1
  /**
   * Get the usrdata1 field from the form
   *
   * @return the usrdata1 value
   */
  public String getUsrdata1() {
    return mobjAccdetXInfo.getUsrdata1();
  }

  /**
   * Set the usrdata1 field into the form
   *
   * @param psUsrdata1 the usrdata1 value
   */
  public void setUsrdata1(String psUsrdata1) {
    mobjAccdetXInfo.setUsrdata1(psUsrdata1);
  }

  // usrdata2
  /**
   * Get the usrdata2 field from the form
   *
   * @return the usrdata2 value
   */
  public String getUsrdata2() {
    return mobjAccdetXInfo.getUsrdata2();
  }

  /**
   * Set the usrdata2 field into the form
   *
   * @param psUsrdata2 the usrdata2 value
   */
  public void setUsrdata2(String psUsrdata2) {
    mobjAccdetXInfo.setUsrdata2(psUsrdata2);
  }

  // usrdata3
  /**
   * Get the usrdata3 field from the form
   *
   * @return the usrdata3 value
   */
  public String getUsrdata3() {
    return mobjAccdetXInfo.getUsrdata3();
  }

  /**
   * Set the usrdata3 field into the form
   *
   * @param psUsrdata3 the usrdata3 value
   */
  public void setUsrdata3(String psUsrdata3) {
    mobjAccdetXInfo.setUsrdata3(psUsrdata3);
  }

  // usrdata4
  /**
   * Get the usrdata4 field from the form
   *
   * @return the usrdata4 value
   */
  public String getUsrdata4() {
    return mobjAccdetXInfo.getUsrdata4();
  }

  /**
   * Set the usrdata4 field into the form
   *
   * @param psUsrdata4 the usrdata4 value
   */
  public void setUsrdata4(String psUsrdata4) {
    mobjAccdetXInfo.setUsrdata4(psUsrdata4);
  }

  // usrdata5
  /**
   * Get the usrdata5 field from the form
   *
   * @return the usrdata5 value
   */
  public String getUsrdata5() {
    return mobjAccdetXInfo.getUsrdata5();
  }

  /**
   * Set the usrdata5 field into the form
   *
   * @param psUsrdata5 the usrdata5 value
   */
  public void setUsrdata5(String psUsrdata5) {
    mobjAccdetXInfo.setUsrdata5(psUsrdata5);
  }

  /**
   * Ensures that the class gets cleared when reused by the ActionServlet It
   * also calls super class to setup the locale, user name, action errors and
   * other values that will be used for this request/session.
   *
   * This method is called by the struts controller before start using the form.
   *
   * @param mapping ActionMapping
   * @param request HttpServletRequest
   *
   */
  public void reset(ActionMapping mapping, HttpServletRequest request) {
    // Please do not remove call to super
    super.reset(mapping, request);

    // clear specific values not coming from info object
    msPan = "";
    msSeqno = "";
    msIsCrdaccLnk = "false";
  }

  public String getAcclogId() {
    return acclogId;
  }

  public void setAcclogId(String acclogId) {
    this.acclogId = acclogId;
  }

  /*
  * Custom code.
  */

  public void setEnabledPermission(String s)
  {
  }
  
  protected static final String UNLINK_PERMISSION_ACSITEM = "breaccdetunlink";
  
  protected static final String UNLINK_PERMISSION_SELECT = "select count(1) from USR U, GRPPERM GP where U.USRGRP=GP.usrgrp and gp.acsitem=? and U.USR= ?";
  
  public String getEnabledPermission()
  {
    Connection connection = null;
    PreparedStatement statement = null;
    ResultSet resultset = null;
    
    try
    {
      connection = dbLib.getConnection(globalConstant.DATA_SOURCE);
      statement = connection.prepareStatement(UNLINK_PERMISSION_SELECT);
      statement.setString(1, UNLINK_PERMISSION_ACSITEM);
      statement.setString(2, getUser());
      
      resultset = statement.executeQuery();
      resultset.next();
      
      return resultset.getInt(1)>0?"1":"0";
    }
    catch (Exception ex)
    {
      logError(getClass().getName(), ex.toString());
      return "0";
    }
    finally
    {  
      dbLib.closeResultSet(resultset);
      dbLib.closeStatement(statement);
      dbLib.closeConnection(connection);
    }
  }
  
  protected static final String COUNT_ACTIVE_CARD = "select count(1) from accdet a inner join crdacc ca on a.id=ca.accdet_id "+
    "inner join crddet c on c.id=ca.crddet_id " +
    "inner join crdaccupl u " +
    "on c.id=u.crddet_id and a.id=u.accdet_id " +
    "inner join custdet cu on c.custdet_id=cu.id " +
    "where c.statcode=? and a.inst_id=? and a.accno=?";
  
  protected static final String CRD_STATUS_ACTIVE = "00";
  
  public boolean isUnlinkDisabled()
  {
    logInfo(CLASSNAME, "isUnlinkDisabled:" + mobjAccdetDetailInfo.getAccno());

    Connection connection = null;
    PreparedStatement statement = null;
    ResultSet resultset = null;
    
    try
    {
      connection = dbLib.getConnection(globalConstant.DATA_SOURCE);
      statement = connection.prepareStatement(COUNT_ACTIVE_CARD);
      statement.setString(1, CRD_STATUS_ACTIVE);
      statement.setLong(2, mobjAccdetDetailInfo.getInst_id());
      statement.setString(3, mobjAccdetDetailInfo.getAccno());
      
      
      resultset = statement.executeQuery();
      resultset.next();
      return resultset.getInt(1) != 0;
    }
    catch (Exception ex)
    {
      logError(getClass().getName(), ex.toString());
      
      return true;
    }
    finally
    {  
      dbLib.closeResultSet(resultset);
      dbLib.closeStatement(statement);
      dbLib.closeConnection(connection);
    }
  }
}
