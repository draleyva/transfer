package com.cortex.gui.common.action;

import com.cortex.common.constant.serverConstant;
import com.cortex.common.exception.serverException;
import com.cortex.gui.common.constant.viewConstant;
import com.cortex.gui.common.formbean.PagingForm;
import com.cortex.gui.common.formbean.PannamelsSearchForm;
import com.cortex.gui.common.lib.CommonGlobalFunctions;
import com.cortex.gui.common.lib.LocaleFormatConverter;
import com.cortex.gui.common.lib.UserInst;
import com.cortex.gui.common.security.obfuscation.FieldObfuscator;
import com.cortex.gui.common.sessionejb.PannamelsMgr;
import com.cortex.gui.common.sessionejb.PannamelsMgrHome;
import com.cortex.gui.common.valueobj.PagingContextInfo;
import com.cortex.gui.common.valueobj.PannamelsInfo;
import com.cortex.gui.common.valueobj.SessionDataInfo;
import java.io.IOException;
import java.sql.Date;
import java.util.Locale;
import javax.rmi.PortableRemoteObject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import com.cortex.gui.common.lib.BasicPanCryptor;

/**
 * <hr><h3> Copyright &copy Nomad Software Ltd.</h3><h4> Project No : 1103<br>
 * Module Name : <br> File Name: PannamelsSearchAction.java <br> Use case ref :
 * <br> Use case name: <br> Version No : 1.0<br> Date created : 05/06/2002 <br>
 *
 * This action class is used to perform action by the search criteria.
 *
 * Date Author Reviewer Description of change
 *
 * @author Poornima
 */
public class PannamelsSearchAction extends PagingAction {

    private static final String CLASSNAME = "PannamelsSearchAction";

    /**
     * Gets the searh data from the form and populates that data into the
     * PannamelsInfo object and then calls the searchPanname method in the
     * session bean, which in return returns the Vector of PannamelsInfo objects
     * which matches the search criteria. Then based on the results it will
     * re-populate the same form with search criteria as well as the search
     * results in the form of a table.
     *
     * If no results are found for the search criteria, then No Records found
     * will be displayed on the screen.
     *
     * @param pobjActionMapping The ActionMapping used to select this instance
     * @param pobjActionForm The optional ActionForm bean for this request (if
     * any)
     * @param pobjRequest The HTTP request we are processing
     * @param pobjResponse The HTTP response we are creating
     *
     * @return ActionForward The ActionForward used to forward the request.
     *
     * @throws IOException if an input/output error occurs
     * @throws ServletException if a servlet exception occurs
     */
    public ActionForward perform(ActionMapping pobjActionMapping, ActionForm pobjActionForm,
            HttpServletRequest pobjRequest, HttpServletResponse pobjResponse)
            throws IOException, ServletException {
        setUser((String) pobjRequest.getSession().getAttribute(viewConstant.USERNAME));
        Locale tobjLocale = pobjRequest.getLocale();

        // Nomad V.K. 05/12/2003: NMR010431: AT-0004 Adding comments to the fixes. 
        // This screen was redeveloped. Removed tabs from ia_pannamels. 
        // Search criteria contains just 'First name', 'Last Name', 'Card Number' and 'Date of Birth'. 
        // None of the fields are mandatory. 
        // If any of the fields are left blank, this is treated has a wildcard character, e.g. showing 
        // the warning message. Please see all these changes in previous submit.

        PannamelsInfo mobjPannamelsInfo = new PannamelsInfo();
        HttpSession session = pobjRequest.getSession(true);

        ActionErrors errors = new ActionErrors();
        PannamelsSearchForm tobjPannamelsSearchForm = new PannamelsSearchForm();
        PagingContextInfo tobjPagingContextInfo = null;
        SessionDataInfo tobjSessionDataInfo = null;
        PannamelsInfo tobjPannamelsInfo = null;
        String tsFormAction = pobjRequest.getParameter(viewConstant.PERFORM_FORMACTION);
        UserInst userInst = CommonGlobalFunctions.getUserInst(session);
        String tsinstcode = userInst.getInstcode();
        if (!(tsinstcode != null && !tsinstcode.equals(viewConstant.NO_USER_INST))) {
            tsinstcode = "";
        }


        if ((tsFormAction == viewConstant.PERFORM_NULL) || (tsFormAction.length() == 0)) {
            try {
                tobjPannamelsInfo = ((PannamelsSearchForm) pobjActionForm).getPannamelsInfo();
                tobjPagingContextInfo = ((PannamelsSearchForm) pobjActionForm).getPagingContextInfo();
                tobjSessionDataInfo = ((PannamelsSearchForm) pobjActionForm).getSessionDataInfo();
                tobjPannamelsInfo.setInstcode(tsinstcode);
                tobjPannamelsInfo.recalculateAccIdCustIdBranchId();
            } catch (Exception e) {
                logError(CLASSNAME, e.toString());
            }
        } else if (tsFormAction.equals(viewConstant.PERFORM_SEARCH)) {
            try {
                tobjPannamelsInfo = ((PannamelsSearchForm) pobjActionForm).getPannamelsInfo();
                tobjPagingContextInfo = ((PannamelsSearchForm) pobjActionForm).getPagingContextInfo();
                tobjSessionDataInfo = ((PannamelsSearchForm) pobjActionForm).getSessionDataInfo();

                if (tobjPannamelsInfo.getFirstname() != null && !tobjPannamelsInfo.getFirstname().trim().equals("")) {
                    mobjPannamelsInfo.setFirstname(tobjPannamelsInfo.getFirstname());
                }
                if (tobjPannamelsInfo.getLastname() != null && !tobjPannamelsInfo.getLastname().trim().equals("")) {
                    mobjPannamelsInfo.setLastname(tobjPannamelsInfo.getLastname());
                }
                if (tobjPannamelsInfo.getPan() != null && !tobjPannamelsInfo.getPan().trim().equals("")) {
                    String strPAN = tobjPannamelsInfo.getPan();
                    if (!BasicPanCryptor.getInstance().isPanEncrypted(strPAN)) {
                        strPAN = BasicPanCryptor.getInstance().encryptPan(tobjPannamelsInfo.getPan());
                    }
                   // mobjPannamelsInfo.setPan(tobjPannamelsInfo.getPan());
                    mobjPannamelsInfo.setPan(strPAN);
                }
                if (tobjPannamelsInfo.getVirtualPan() != null && !tobjPannamelsInfo.getVirtualPan().trim().equals("")) {
                    mobjPannamelsInfo.setVirtualPan(tobjPannamelsInfo.getVirtualPan());
                }
                if (tobjPannamelsInfo.getDob() != null && !tobjPannamelsInfo.getDob().trim().equals("")) {
                    Date tsDob = LocaleFormatConverter.convertLocaleToSqlDate(tobjPannamelsInfo.getDob(), pobjRequest.getLocale());
                    mobjPannamelsInfo.setDob(LocaleFormatConverter.convertToStandardFormat(tsDob));
                }
                mobjPannamelsInfo.setInstcode(tsinstcode);
                mobjPannamelsInfo.recalculateAccIdCustIdBranchId();

                PagingContextInfo tobjRetPagingContextInfo = performSearch(tobjPannamelsSearchForm, mobjPannamelsInfo, tobjPagingContextInfo, tobjLocale);
                pobjRequest.setAttribute("pageForm", new PagingForm(tobjRetPagingContextInfo));
                tobjPannamelsSearchForm.setResultAction(viewConstant.PERFORM_SUCCESS);

            } catch (serverException se) {
                errors.add("newDate", new ActionError(se.getErrorCode()));
            } catch (Exception e) {
                tobjPannamelsSearchForm.setResultAction(viewConstant.PERFORM_ERROR);
            } finally {
                tobjPannamelsSearchForm.setPannamelsInfo(tobjPannamelsInfo);
                if (!errors.empty()) {
                    saveErrors(pobjRequest, errors);
                }
            }
        } else if (tsFormAction.equals(viewConstant.PERFORM_UNMASK)) {
            try {
                tobjPannamelsSearchForm = (PannamelsSearchForm) pobjActionForm;
                tobjPannamelsInfo = ((PannamelsSearchForm) pobjActionForm).getPannamelsInfo();

                FieldObfuscator tobjFieldObfuscator = new FieldObfuscator();
                String tsUnmaskedValue = tobjFieldObfuscator.unmaskField("pannamelsInfoList.pan",
                        tobjPannamelsSearchForm.getIndex_returned(), pobjRequest);
                if ((tsUnmaskedValue != null) && !tsUnmaskedValue.equals("")) {
                    tobjPannamelsSearchForm.setPan_returned(tsUnmaskedValue);
                }
                tobjPannamelsSearchForm.setFormActionUnmask("true");
            } catch (Exception e) {
                tobjPannamelsSearchForm.setResultAction(viewConstant.PERFORM_ERROR);
            } finally {
                tobjPannamelsSearchForm.setPannamelsInfo(tobjPannamelsInfo);
                if (!errors.empty()) {
                    saveErrors(pobjRequest, errors);
                }
            }
        }

        tobjPannamelsSearchForm.setInstCode(tsinstcode);
        pobjRequest.getSession().setAttribute(viewConstant.TABID, "0");
        pobjRequest.setAttribute("pannamelsSearchForm", tobjPannamelsSearchForm);
        pobjRequest.setAttribute("PannamelsSearchForm", tobjPannamelsSearchForm);
        pobjRequest.setAttribute(Action.ERROR_KEY, errors);

        return pobjActionMapping.findForward(viewConstant.PERFORM_SUCCESS);
    }

    /**
     * Method Used to perform the search operation.
     *
     * @param tobjPannamelsSearchForm of type PannamelsSearchForm.
     * @param pobjPannamelsInfo of type PannamelsInfo
     * @param pobjPagingContextInfo of type PagingContextInfo
     * @return PagingContextInfo
     * @throws Exception
     */
    private PagingContextInfo performSearch(PannamelsSearchForm tobjPannamelsSearchForm,
            PannamelsInfo pobjPannamelsInfo,
            PagingContextInfo pobjPagingContextInfo,
            Locale tobjLocale)
            throws Exception {

        Object objRef = getLookup(serverConstant.VIEW_PANNAME_SESSION);
        PannamelsMgrHome objPannamelsMgrHome =
                (PannamelsMgrHome) PortableRemoteObject.narrow(objRef, PannamelsMgrHome.class);


        PannamelsMgr objPannamelsMgr = objPannamelsMgrHome.create();
        java.util.ArrayList objSearchInfo = objPannamelsMgr.searchPanname(pobjPannamelsInfo, pobjPagingContextInfo);


        PannamelsInfo objPannamelsInfoList[] = new PannamelsInfo[(objSearchInfo.size() - 1)];
        for (int n = 0; n < (objSearchInfo.size() - 1); n++) {
            PannamelsInfo tobjPannamelsInfo = (PannamelsInfo) objSearchInfo.get(n);
            tobjPannamelsInfo.setExpiryDate(convertSQLToLocaleStringDate(tobjPannamelsInfo.getExpiryDate(), tobjLocale));
            tobjPannamelsInfo.setDob(convertSQLToLocaleStringDate(tobjPannamelsInfo.getDob(), tobjLocale));
            objPannamelsInfoList[n] = tobjPannamelsInfo;
        }
        tobjPannamelsSearchForm.setPannamelsInfoList(objPannamelsInfoList);
        PagingContextInfo tobjPagingContextInfo = (PagingContextInfo) objSearchInfo.get(objSearchInfo.size() - 1);
        tobjPannamelsSearchForm.setPagingContextInfo(tobjPagingContextInfo);

        return tobjPagingContextInfo;
    }
}