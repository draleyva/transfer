package com.cortex.cust.bre.gui.ia.formbean;

import com.cortex.cust.bre.gui.ia.valueobj.BREReplaceLostOrStolenCardsInfo;
import com.cortex.gui.common.formbean.PagingForm;

/**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project No           : 1103  <br>
 * Module Name          : Ia<br>
 * Global Use Case      : N/A<br>
 * Business Use case    : N/A<br>
 * Maintenance Use case : N/A<br>
 * @author                j2eegen
 *
 *  The Struts framework generally assumes that
 *  you have created an ActionForm bean (that is,
 *  a Java class extending the ActionForm class)
 *  for each input form required in your application
 *
 * Date   Author     Reviewer    Description of change<br>
 *
 * @version 1.0
 */
public class BREReplaceLostOrStolenCardsForm extends PagingForm
{
    private static final String CLASSNAME="BREReplaceLostOrStolenCardsForm";
    private BREReplaceLostOrStolenCardsInfo replaceLostOrStolenCardsInfo;
   
    /**
     * Constructor that accepts an Cust_idcodeSearchInfo object
     *
     * @param     pobjCust_idcodeSearchInfo  The info object of the form
     */
    public BREReplaceLostOrStolenCardsForm(BREReplaceLostOrStolenCardsInfo pReplaceLostOrStolenCardsInfo)
    {
    	replaceLostOrStolenCardsInfo = pReplaceLostOrStolenCardsInfo;
    }

    /**
     * Default constructor.  It creates a new Cust_idcodeSearchInfo object.
     * All the values of this info object are set to default.
     */
    public BREReplaceLostOrStolenCardsForm()
    {
    	replaceLostOrStolenCardsInfo = new BREReplaceLostOrStolenCardsInfo();
    }


    /**
     * Return the info object of the form
     *
     * @return   the current info object of the form
     */
    public BREReplaceLostOrStolenCardsInfo getBREReplaceLostOrStolenCardsInfo()
    {
        return replaceLostOrStolenCardsInfo;
    }
    /**
     * Return the info object of the form
     *
     * @return   the current info object of the form
     */
    public void setBREReplaceLostOrStolenCardsInfo(BREReplaceLostOrStolenCardsInfo pReplaceLostOrStolenCardsInfo)
    {
    	replaceLostOrStolenCardsInfo = pReplaceLostOrStolenCardsInfo;
    }
    
    
    /**
	 * @return the crdproduct
	 */
	public String getCrdproduct() {
		return replaceLostOrStolenCardsInfo.getCrdproduct();
	}
	/**
	 * @param crdproduct the crdproduct to set
	 */
	public void setCrdproduct(String crdproduct) {
		replaceLostOrStolenCardsInfo.setCrdproduct(crdproduct);
	}
	/**
	 * @return the batch
	 */
	public String getBatch() {
		return replaceLostOrStolenCardsInfo.getBatch();
	}
	/**
	 * @param batch the batch to set
	 */
	public void setBatch(String batch) {
		replaceLostOrStolenCardsInfo.setBatch(batch);
	}
	/**
	 * @return the instcode
	 */
	public String getInstcode() {
		return replaceLostOrStolenCardsInfo.getInstcode();
	}
	/**
	 * @param instcode the instcode to set
	 */
	public void setInstcode(String instcode) {
		replaceLostOrStolenCardsInfo.setInstcode(instcode);
	}
	/**
	 * @return the oldSeqno
	 */
	public String getOldSeqno() {
		return replaceLostOrStolenCardsInfo.getOldSeqno();
	}
	/**
	 * @param oldSeqno the oldSeqno to set
	 */
	public void setOldSeqno(String oldSeqno) {
		replaceLostOrStolenCardsInfo.setOldSeqno(oldSeqno);
	}
	/**
	 * @return the oldPan
	 */
	public String getOldPan() {
		return replaceLostOrStolenCardsInfo.getOldPan();
	}
	/**
	 * @param oldPan the oldPan to set
	 */
	public void setOldPan(String oldPan) {
		replaceLostOrStolenCardsInfo.setOldPan(oldPan);
	}
	/**
	 * @return the newPan
	 */
	public String getNewPan() {
		return replaceLostOrStolenCardsInfo.getNewPan();
	}
	/**
	 * @param newPan the newPan to set
	 */
	public void setNewPan(String newPan) {
		replaceLostOrStolenCardsInfo.setNewPan(newPan);
	}
	/**
	 * @return the newSeqno
	 */
	public String getNewSeqno() {
		return replaceLostOrStolenCardsInfo.getNewSeqno();
	}
	/**
	 * @param newSeqno the newSeqno to set
	 */
	public void setNewSeqno(String newSeqno) {
		replaceLostOrStolenCardsInfo.setNewSeqno(newSeqno);
	}
    
	/**
	 * @return the panDisplay
	 */
	public String getPanDisplay() {
		return replaceLostOrStolenCardsInfo.getPanDisplay();
	}
	/**
	 * @param panDisplay the panDisplay to set
	 */
	public void setPanDisplay(String panDisplay) {
		replaceLostOrStolenCardsInfo.setPanDisplay(panDisplay);
	}
	/**
	 * @return the virtualPan
	 */
	public String getVirtualPan() {
		return replaceLostOrStolenCardsInfo.getVirtualPan();
	}
	/**
	 * @param virtualPan the virtualPan to set
	 */
	public void setVirtualPan(String virtualPan) {
		replaceLostOrStolenCardsInfo.setVirtualPan(virtualPan);
	}
	/**
	 * @return the custName
	 */
	public String getCustName() {
		return replaceLostOrStolenCardsInfo.getCustName();
	}
	/**
	 * @param custName the custName to set
	 */
	public void setCustName(String custName) {
		replaceLostOrStolenCardsInfo.setCustName(custName);
	}
	/**
	 * @return the statCode
	 */
	public String getStatCode() {
		return replaceLostOrStolenCardsInfo.getStatCode();
	}
	/**
	 * @param statCode the statCode to set
	 */
	public void setStatCode(String statCode) {
		replaceLostOrStolenCardsInfo.setStatCode(statCode);
	}
	
	/**
	 * @return the statCodeDescr
	 */
	public String getStatCodeDescr() {
		return replaceLostOrStolenCardsInfo.getStatCodeDescr();
	}
	/**
	 * @param statCodeDescr the statCodeDescr to set
	 */
	public void setStatCodeDescr(String statCodeDescr) {
		replaceLostOrStolenCardsInfo.setStatCodeDescr(statCodeDescr);
	}
	
	/**
	 * @return the replacementDone
	 */
	public boolean getReplacementDone() {
		return replaceLostOrStolenCardsInfo.getReplacementDone();
	}
	/**
	 * @param replacementDone the replacementDone to set
	 */
	public void setReplacementDone(boolean replacementDone) {
		replaceLostOrStolenCardsInfo.setReplacementDone(replacementDone);
	}

}
