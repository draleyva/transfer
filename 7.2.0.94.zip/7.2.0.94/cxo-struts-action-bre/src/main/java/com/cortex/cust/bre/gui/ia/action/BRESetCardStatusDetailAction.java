package com.cortex.cust.bre.gui.ia.action;

import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale;

import javax.ejb.CreateException;
import javax.rmi.PortableRemoteObject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cortex.common.constant.SQLConstants;
import com.cortex.common.constant.globalConstant;
import com.cortex.common.constant.serverConstant;
import com.cortex.common.exception.serverException;
import com.cortex.common.hook.HookFactory;
import com.cortex.common.hook.HookParam;
import com.cortex.common.lib.FunctionLib;
import com.cortex.common.lib.dateTimeLib;
import com.cortex.common.lib.dbLib;
import com.cortex.common.lib.debugLib;
import com.cortex.common.startup.StartupData;
import com.cortex.common.startup.StartupXmlConfigData;
import com.cortex.gui.common.action.SessionDataAction;
import com.cortex.gui.common.bean.Usr;
import com.cortex.gui.common.constant.viewConstant;
import com.cortex.gui.common.lib.AccessPermissions;
import com.cortex.gui.common.lib.CommonGlobalFunctions;
import com.cortex.gui.common.lib.UserInst;
import com.cortex.cust.bre.gui.ia.formbean.BRESetCardStatusDetailForm;
import com.cortex.gui.ia.sessionejb.CardStatusMgr;
import com.cortex.cust.bre.gui.ia.sessionejb.BRECardStatusMgrHome;
import com.cortex.gui.ia.valueobj.OperatorActionInfo;
import com.cortex.gui.ia.valueobj.ParentCardDetailsInfo;
import com.cortex.gui.ia.valueobj.SetCardStatusDetailInfo;
import com.fis.mkc.domain.model.JobType;
import com.fis.mkc.domain.model.ServiceType;
import com.fis.mkc.domain.shared.JobAuthCallCollator;
import com.cortex.gui.ia.sessionejb.CardMaintenanceMgr;
import com.cortex.gui.ia.sessionejb.CardMaintenanceMgrHome;
import com.cortex.gui.ia.valueobj.CardMaintDetailInfo;
import com.cortex.gui.ia.valueobj.CrddetPKInfo;
import com.cortex.gui.common.action.mkc.Util;
import com.cortex.gui.ia.sessionejb.CrdstatusMgr;
import com.cortex.gui.ia.sessionejb.CrdstatusMgrHome;
import com.cortex.gui.ia.valueobj.CrdstatusPKInfo;
import com.cortex.cust.bre.gui.ia.sessionejb.BRECardStatusMgr;
import com.cortex.cust.bre.common.constant.serverConstantBre;

/**
 * <hr><h3>
 * Copyright & copy Nomad Software Ltd.</h3><h4>
 * Project No : 1103 <br>
 * Module Name : Issuer Authorizer <br>
 * Use case ref : UC0070<br>
 * Use case name : changeCardStatus<br>
 * Version No : 1.0 <br>
 * Date created : 06/09/2002 <br>
 *
 * This is the Action class of Batch for Application Input Detail screen<br>
 *
 * Date Author Reviewer Description of change 06/09/2002 Sunandha
 * Ramasamy/Nithila S. 09/12/2002 Chandu AT-0934
 *
 *
 * @author Sunandha Ramasamy/Nithila S. Modified to fix the TR-1002 :by Vinay
 *
 * 25/11/2002 Rajkumar.A.S To Fix AT-TR TR# AT-0896
 */
public class BRESetCardStatusDetailAction extends SessionDataAction {

    private static final String CLASSNAME = "BRESetCardStatusDetailAction";

    /**
     * This method is called when a new action is initiated from the form (i.e.
     * user presses a button). This action will be decoded and processed. When
     * appropriate, a successfull processing will displayed a success message in
     * the screen. Similarly, an error message will be displayed when processing
     * fails.
     *
     * Below the actions supported by this perform method:
     * <UL>
     * <LI>
     * <default>: This action happens when the user request adding a new record.
     * An empty form will be displayed.
     * </LI>
     * <LI>
     * ADD: This action happens when the user fills in all the required fields
     * from the add/creation form and presses the ADD button. The info object
     * containing the entered information is read and the system attempts to
     * create a new record in the database.
     * </LI>
     * </UL>
     *
     * @param pobjActionMapping The ActionMapping used to select this instance
     * @param pobjActionForm The optional ActionForm bean for this request (if
     * any)
     * @param pobjRequest The HTTP request we are processing
     * @param pobjResponse The HTTP response we are creating
     *
     * @return ActionForward The ActionForward used to forward the request.
     *
     * @throws IOException thrown if an input/output error occurs
     * @throws ServletException thron if a servlet exception occurs
     */
    public ActionForward perform(ActionMapping pobjActionMapping, ActionForm pobjActionForm,
            HttpServletRequest pobjRequest, HttpServletResponse pobjResponse)
            throws IOException, ServletException {
        String tsUsername = (String) pobjRequest.getSession().getAttribute(viewConstant.USERNAME);

        /*
		 *  Set up variables
         */
        Locale mobjLocale = pobjRequest.getLocale();

        // Store the ActionForm and info object in local variables for simplicity of the code
        BRESetCardStatusDetailForm mobjSetCardStatusDetailForm = (BRESetCardStatusDetailForm) pobjActionForm;
        SetCardStatusDetailInfo mobjSetCardStatusDetailInfo = ((BRESetCardStatusDetailForm) pobjActionForm).getSetCardStatusDetailInfo();
        // Create ActionErrors variable used to store errors to be reported back to the client
        ActionErrors tobjErrors = new ActionErrors();
        HttpSession tobjHttpSession = pobjRequest.getSession();

        // This variable contains the forwarding name that will be used to display
        // the next screen.
        String tsResult = viewConstant.PERFORM_SUCCESS;
        // This variable contains the action to carry out (ie Add, Edit, Update or Delete)
        String tsFormAction = pobjRequest.getParameter(viewConstant.PERFORM_FORMACTION);
        String tsFromWhere = pobjRequest.getParameter(viewConstant.FROMWHERE);
        int updateResult = 0;

        pobjRequest.removeAttribute(viewConstant.ERROR_KEY_USER_DEFINED);

        // Alvis 11/09/2011: CTXAPPSMAINT-745 : Add option to disable VISA Exception File prompt
        String msDisablePrompt = "false";
        HookParam hookParam = new HookParam();
        hookParam.put(HookParam.PARAM1, msDisablePrompt);
        try {
            // (If this param returns true, then VISA Exception File prompt will not be displayed)
            hookParam = HookFactory.getPlugin("com.cortex.gui.ia.plugins.VisaExceptionFilePromptPlugin").process(hookParam);
            msDisablePrompt = (String) hookParam.get(HookParam.PARAM1);
        } catch (Exception e) {
            debugLib.logInfo(CLASSNAME, e.toString());
        }

        try {
            if (tsFormAction == null || tsFormAction.equals("")) {
                // mobjSetCardStatusDetailForm = new SetCardStatusDetailForm();

                if (tsFromWhere == null) {
                    tsFromWhere = mobjSetCardStatusDetailForm.getFromwhere();
                }

                mobjSetCardStatusDetailForm.setFromwhere(tsFromWhere);
                mobjSetCardStatusDetailForm.setPrompt("false");
                // setting the logged in user's User Institution

                UserInst userInst = CommonGlobalFunctions.getUserInst(tobjHttpSession);
                String InstCode = userInst.getInstcode();

                mobjSetCardStatusDetailInfo.setDateset(dateTimeLib.getCurrentDate());
                // mobjSetCardStatusDetailForm.setStrdateset(displayTOLocaleDate( dateTimeLib.getCurrentDate(),mobjLocale));

                //  AT-0934
                mobjSetCardStatusDetailInfo.setTime_set(dateTimeLib.getCurrentTime());
                mobjSetCardStatusDetailInfo.setStrTime_set(dateTimeLib.convertLongToStringTime(mobjSetCardStatusDetailInfo.getTime_set()));
                // mobjSetCardStatusDetailForm.setStrTimeset(displayTime(dateTimeLib.getCurrentTime()));
                String tsUsrname = (String) tobjHttpSession.getAttribute(viewConstant.USERNAME);

                mobjSetCardStatusDetailForm.setWhoset(tsUsrname);
                //nouserinst
                if (InstCode != null && !InstCode.equals(viewConstant.NO_USER_INST)) {
                    mobjSetCardStatusDetailForm.setInstcode(InstCode);
                }
            } else if (tsFormAction.equals(viewConstant.PERFORM_REFRESH)) {
                // Explore the code to get the user
                //mobjSetCardStatusDetailForm.setUser(pobjRequest.getUserName());
                performRefresh(mobjSetCardStatusDetailForm, mobjSetCardStatusDetailInfo);
                //mobjSetCardStatusDetailForm.setSetCardStatusDetailInfo(mobjSetCardStatusDetailInfo);
            } else if (tsFormAction.equals(viewConstant.PERFORM_ADD)) {
                // Explore the code to get the user
                //mobjSetCardStatusDetailForm.setUser(pobjRequest.getUserName());
                mobjSetCardStatusDetailInfo.setWho_set(tsUsername);
                // Alvis 30/05/2006: NMR015614
                mobjSetCardStatusDetailInfo.setDateset(dateTimeLib.getCurrentDate());
                mobjSetCardStatusDetailInfo.setTime_set(dateTimeLib.getCurrentTime());
                mobjSetCardStatusDetailInfo.setStrTime_set(dateTimeLib.convertLongToStringTime(mobjSetCardStatusDetailInfo.getTime_set()));
                if (allowStatusChange(mobjSetCardStatusDetailInfo, pobjRequest)) {
                    updateResult = performAdd(mobjSetCardStatusDetailForm, mobjSetCardStatusDetailInfo, msDisablePrompt, (String) tobjHttpSession.getAttribute(viewConstant.USERNAME), pobjRequest.getParameter(viewConstant.FORMACSITEM));
                } else {
                    tobjErrors.add(ActionErrors.GLOBAL_ERROR, new ActionError("ia.msg.cardstatus.errorflag1"));
                }

                if (updateResult == globalConstant.MAKER_CHECKER_CONSTANT_PENDING_REQUEST) {
                    tobjErrors.add(ActionErrors.GLOBAL_ERROR, new ActionError("ia.msg.jobauth.errorflagPendingRequest"));
                    pobjRequest.setAttribute(viewConstant.ERROR_KEY_USER_DEFINED, viewConstant.ERROR_CREATE_JOBAUTH_REQUEST);
                }

            } else if (tsFormAction.equals(viewConstant.PERFORM_EDIT)) {
                if (tsFromWhere.equals("2")) {
                    OperatorActionInfo tobjOperatorActionInfo = (OperatorActionInfo) tobjHttpSession.getAttribute("OperatorActionInfo");
                    if (tobjOperatorActionInfo != null) {
                        tobjHttpSession.removeAttribute("OperatorActionInfo");
                        if (tobjOperatorActionInfo.getAction() == OperatorActionInfo.ACTIVATE_CARD) {
                            mobjSetCardStatusDetailForm.setStatcode("00");  // normal
                        } else {
                            mobjSetCardStatusDetailForm.setStatcode("04");  // stolen
                        }
                    }
                }

                if (!tsFromWhere.equals("0")) {
                    mobjSetCardStatusDetailForm.setFromwhere(tsFromWhere);

                    //Added to fix the TR-1002 :Vinay
                    mobjSetCardStatusDetailInfo.setDateset(dateTimeLib.getCurrentDate());
                    //  AT-0934
                    long tlTime = dateTimeLib.getCurrentTime();
                    mobjSetCardStatusDetailInfo.setTime_set(tlTime);
                    mobjSetCardStatusDetailInfo.setStrTime_set(dateTimeLib.convertLongToStringTime(mobjSetCardStatusDetailInfo.getTime_set()));
                    mobjSetCardStatusDetailForm.setWhoset(tsUsername);

                    if (tsFromWhere.equals("3")) {
                        mobjSetCardStatusDetailInfo.setPan(pobjRequest.getParameter(viewConstant.KEY1));
                        mobjSetCardStatusDetailInfo.setSeqno(Integer.parseInt(pobjRequest.getParameter(viewConstant.KEY2)));
                        mobjSetCardStatusDetailInfo.setInstcode(pobjRequest.getParameter(viewConstant.KEY3));
                    } else {
                        ParentCardDetailsInfo tobjParentCardDetailsInfo = new ParentCardDetailsInfo();
                        tobjParentCardDetailsInfo = ((ParentCardDetailsInfo) tobjHttpSession.getAttribute("ParentCardDetailsInfo"));
                        mobjSetCardStatusDetailInfo.setInstcode(tobjParentCardDetailsInfo.getInstcode());
                        mobjSetCardStatusDetailInfo.setPan(tobjParentCardDetailsInfo.getPan());
                        mobjSetCardStatusDetailInfo.setSeqno(tobjParentCardDetailsInfo.getSeqno());
                    }
                }

                performEdit(mobjSetCardStatusDetailForm, mobjSetCardStatusDetailInfo);

                if (tsFromWhere.equals("3")) {
                    Object tobjRef = FunctionLib.getLookup(serverConstantBre.VIEW_BRE_CRDSTHST_SESSION);
                    BRECardStatusMgrHome tobjCardStatusMgrHome
                            = (BRECardStatusMgrHome) PortableRemoteObject.narrow(tobjRef, BRECardStatusMgrHome.class);
                    BRECardStatusMgr mobjCardStatusMgr = tobjCardStatusMgrHome.create();

                    String statusCode = mobjCardStatusMgr.getConfiguredStatusCode();
                    mobjSetCardStatusDetailForm.setStatcode(statusCode != null ? statusCode : "00");
                }
            } else if (tsFormAction.equals(viewConstant.PERFORM_PROMPT)) {
                //Redirect the user to VISA Exception File Maintenance screen.
            }
        } catch (RemoteException re) {
            debugLib.logError(CLASSNAME, re, tsUsername);
            tobjErrors.add(ActionErrors.GLOBAL_ERROR, new ActionError("error.db.connectfailed"));
        } catch (CreateException ce) {
            debugLib.logError(CLASSNAME, ce, tsUsername);
            tobjErrors.add(ActionErrors.GLOBAL_ERROR, new ActionError("error.db.connectfailed"));
        } catch (serverException se) {
            debugLib.logError(CLASSNAME, se, tsUsername);
            if (null != se.getValue0() && se.getValue0().length() > 0 && null != se.getValue1() && se.getValue1().length() > 0) {
                tobjErrors.add(ActionErrors.GLOBAL_ERROR, new ActionError(se.getErrorCode(), se.getValue0(), se.getValue1()));
            } else {
                tobjErrors.add(ActionErrors.GLOBAL_ERROR, new ActionError(se.getErrorCode()));
            }
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e, tsUsername);
            tobjErrors.add(ActionErrors.GLOBAL_ERROR, new ActionError("error.unknownerror"));
        } finally {
            if (tobjErrors.empty()) {

                if (tsFormAction != null && !tsFormAction.equals(viewConstant.PERFORM_EDIT) && !tsFormAction.equals(viewConstant.PERFORM_REFRESH)) {

                    try {
                        if (!mobjSetCardStatusDetailForm.getPrompt().equals("true")) {
                            // NMR013724 make sure date/time are populated always even after add
                            SetCardStatusDetailInfo tobjSetCardStatusDetailInfo = new SetCardStatusDetailInfo();
                            tobjSetCardStatusDetailInfo.setDateset(dateTimeLib.getCurrentDate());
                            tobjSetCardStatusDetailInfo.setTime_set(dateTimeLib.getCurrentTime());
                            mobjSetCardStatusDetailInfo.setStrTime_set(dateTimeLib.convertLongToStringTime(mobjSetCardStatusDetailInfo.getTime_set()));

                            mobjSetCardStatusDetailForm
                                    = new BRESetCardStatusDetailForm(tobjSetCardStatusDetailInfo, pobjRequest);

                            if (tsFromWhere == null) {
                                tsFromWhere = mobjSetCardStatusDetailForm.getFromwhere();
                            }
                            mobjSetCardStatusDetailForm.setFromwhere(tsFromWhere);

                            // setting the logged in user's User Institution
                            UserInst userInst = CommonGlobalFunctions.getUserInst(tobjHttpSession);
                            String InstCode = userInst.getInstcode();

                            String tsUsrname = (String) tobjHttpSession.getAttribute(viewConstant.USERNAME);
                            mobjSetCardStatusDetailForm.setWhoset(tsUsrname);
                            //nouserinst
                            if (InstCode != null && !InstCode.equals(viewConstant.NO_USER_INST)) {
                                mobjSetCardStatusDetailForm.setInstcode(InstCode);
                            }
                        }
                    } catch (Exception e) {
                        debugLib.logError(CLASSNAME, e, tsUsername);
                        tobjErrors.add(ActionErrors.GLOBAL_ERROR, new ActionError("error.unknownerror"));
                    }

                    if (updateResult == 0) {
                        pobjRequest.setAttribute(viewConstant.ACTION_SUCCESS_FLAG, viewConstant.ACTION_SUCCESS);
                    } else if (updateResult == 1) {
                        pobjRequest.setAttribute(viewConstant.ACTION_SUCCESS_FLAG, "ia.msg.cardstatus.successflag1");
                    } else if (updateResult == 2) {
                        pobjRequest.setAttribute(viewConstant.ACTION_SUCCESS_FLAG, "ia.msg.cardstatus.successflag2");
                    } else if (updateResult == globalConstant.MAKER_CHECKER_CONSTANT_SUCCESS) {
                        pobjRequest.setAttribute(viewConstant.ACTION_SUCCESS_FLAG, viewConstant.RESULT_MKC_JOB_CREATION_SUCCESS);
                        if (tsFromWhere != null && tsFromWhere.equals("1")) {
                            pobjRequest.getSession().setAttribute(viewConstant.RESULT_MKC_JOB_CREATED_SUCCESS, viewConstant.CHAR_YES);
                        }
                    }

                    mobjSetCardStatusDetailForm.setResultAction(tsResult);
                }
            } else {
                // Otherwise return the error to the jsp.
                saveErrors(pobjRequest, tobjErrors);
                mobjSetCardStatusDetailForm.setResultAction(viewConstant.PERFORM_ERROR);
            }
        }
        // Attach new form to request and forward result
        mobjSetCardStatusDetailForm.setWhoset(tsUsername);

        pobjRequest.setAttribute("BRESetCardStatusDetailForm", mobjSetCardStatusDetailForm);
        return pobjActionMapping.findForward(tsResult);
    }

    /**
     * This function invokes the session bean to add a new Batch for Application
     * Input<br>
     *
     * @throws RemoteException
     * @throws CreateException
     * @throws serverException
     * @throws Exception
     */
    private int performAdd(BRESetCardStatusDetailForm pobjSetCardStatusDetailForm,
            SetCardStatusDetailInfo pobjSetCardStatusDetailInfo, String psDisablePrompt, String usrName, String acsitem)
            throws RemoteException, CreateException, serverException, Exception {
        int updateRes = 0;
        //MKC parameters initialze
        Object execData = null;
        Object originalExecData = null;
        Object displayData = null;
        Object originalDisplayData = null;
        SetCardStatusDetailInfo tmpObjSetCardStatusDetailInfo = null;

        StringBuilder recIdBuilder = new StringBuilder();
        recIdBuilder.append("Pan:").append(pobjSetCardStatusDetailInfo.getPan());
        recIdBuilder.append(",");
        recIdBuilder.append("Seq no:").append(pobjSetCardStatusDetailInfo.getSeqno());

        try {
            Boolean jobAuthrizationPendingRequest = false;

            try {
                jobAuthrizationPendingRequest = Util.getMakerCheckerPendingRequestStatus(false, acsitem, recIdBuilder.toString(), String.valueOf(globalConstant.SOURCE_ID_CTX));
            } catch (Exception e) {
                debugLib.logInfo(CLASSNAME, e.toString());
            }

            if (jobAuthrizationPendingRequest) {
                return globalConstant.MAKER_CHECKER_CONSTANT_PENDING_REQUEST;
            }

            Object tobjRef = FunctionLib.getLookup(serverConstantBre.VIEW_BRE_CRDSTHST_SESSION);
            BRECardStatusMgrHome tobjCardStatusMgrHome
                    = (BRECardStatusMgrHome) PortableRemoteObject.narrow(tobjRef, BRECardStatusMgrHome.class);
            BRECardStatusMgr mobjCardStatusMgr = tobjCardStatusMgrHome.create();

            //get the expdate for card status history changes
            pobjSetCardStatusDetailInfo = mobjCardStatusMgr.getExpiryDate(pobjSetCardStatusDetailInfo);
            tmpObjSetCardStatusDetailInfo = copyCardStatusDetail(mobjCardStatusMgr.editSetCardStatus(pobjSetCardStatusDetailInfo));

            // TODO: Customise the 
            mobjCardStatusMgr.isTransitionAllowed(pobjSetCardStatusDetailInfo.getCrdproduct(), pobjSetCardStatusDetailInfo.getStatcode(),
                    pobjSetCardStatusDetailInfo.getOldcardstat(), pobjSetCardStatusDetailInfo.getOldstat(), pobjSetCardStatusDetailInfo.getUpdateoldcardstat(), pobjSetCardStatusDetailInfo.getHasOldCard());

            if (pobjSetCardStatusDetailInfo.getHasOldCard()) {
                if ("0".equals(pobjSetCardStatusDetailInfo.getUpdateoldcardstat())) {
                    /*
					 * portion of C-code from 
					 * /share/homes/mvitolin/curtiz/project/hypo/base/crdbase/src/cbstmglib/crdstatupd.c
            		if (NDATE_NEVER!=p_statupd->p_crddet->old_expdate
            				&& (curdate<=old_dbdate
            				     ---|| 0==strcmp(p_statupd->p_crddet->old_statcode,--- changed according Madars 
            				     || 0==strcmp(p_statupd->p_crddet->statcode, 
            							CRDSTAT_EXPIRED))
            			   )
            			{
            				p_statupd->update_mode|=CRDSTATUPD_MODE_OLD_CARD;
            			}
                     */
                    pobjSetCardStatusDetailInfo = mobjCardStatusMgr.editSetCardStatus(pobjSetCardStatusDetailInfo);
                    if ("03".equals(pobjSetCardStatusDetailInfo.getStatcode())) {
                        // always change status of the old card to "EXPIRED"
                        pobjSetCardStatusDetailInfo.setOldcardstat(pobjSetCardStatusDetailInfo.getStatcode());
                        pobjSetCardStatusDetailInfo.setDateExpdate(pobjSetCardStatusDetailInfo.getOldcardexpdate());
                        updateRes = 1;
                    } else if (pobjSetCardStatusDetailInfo.getOldcardexpdate() != null
                            && !pobjSetCardStatusDetailInfo.getOldcardexpdate().equals(globalConstant.NEVER_DATE)) {
                        Date now = new Date(System.currentTimeMillis());
                        if (now.compareTo(pobjSetCardStatusDetailInfo.getOldcardexpdate()) <= 0) {
                            pobjSetCardStatusDetailInfo.setOldcardstat(pobjSetCardStatusDetailInfo.getStatcode());
                            pobjSetCardStatusDetailInfo.setDateExpdate(pobjSetCardStatusDetailInfo.getOldcardexpdate());
                            updateRes = 1;
                        } else {
                            updateRes = 2;
                        }
                    }
                } else if ("1".equals(pobjSetCardStatusDetailInfo.getUpdateoldcardstat())) {
                    // update status only of new card
                } else if ("2".equals(pobjSetCardStatusDetailInfo.getUpdateoldcardstat())) {
                    // If status of the old card is used - update it
                    pobjSetCardStatusDetailInfo.setOldcardstat(pobjSetCardStatusDetailInfo.getStatcode());
                    // Do not update status of the new card
                    pobjSetCardStatusDetailInfo.setStatcode(pobjSetCardStatusDetailInfo.getOldstat());

                    pobjSetCardStatusDetailInfo.setDateExpdate(pobjSetCardStatusDetailInfo.getOldcardexpdate());

                }
            }
            //Prepare data for Maker Checker Plugin Start
            debugLib.logInfo(CLASSNAME, viewConstant.PREPARE_MKC_DATA_START);

            //MKC parameters manipulation
            execData = pobjSetCardStatusDetailInfo;
            originalExecData = tmpObjSetCardStatusDetailInfo;
            displayData = pobjSetCardStatusDetailInfo;
            originalDisplayData = originalExecData;

            // Obtain Session Bean reference
            CrdstatusMgrHome mobjCrdstatusMgrHome
                    = (CrdstatusMgrHome) PortableRemoteObject.narrow(FunctionLib.getLookup(serverConstant.VIEW_CRDSTATUS_SESSION), CrdstatusMgrHome.class);
            CrdstatusMgr mobjCrdstatusMgr = mobjCrdstatusMgrHome.create();

            CrdstatusPKInfo tobjCrdstatusPKInfo = new CrdstatusPKInfo();
            tobjCrdstatusPKInfo.setStatcode(pobjSetCardStatusDetailInfo.getStatcode());
            pobjSetCardStatusDetailInfo.setStatcodedescr(mobjCrdstatusMgr.getCrdstatus(tobjCrdstatusPKInfo).getDescr());

            tmpObjSetCardStatusDetailInfo.setStatcodedescr(pobjSetCardStatusDetailInfo.getOldstatdescr());

            JobAuthCallCollator jobAuthCallCollator = new JobAuthCallCollator(FunctionLib.getJNDIPrefix(serverConstantBre.VIEW_BRE_CRDSTHST_SESSION), ServiceType.JNDI_NAME, "addCardStatus", execData, originalExecData, displayData, originalDisplayData, SetCardStatusDetailInfo.aliasesMap);
            jobAuthCallCollator.addParameter(acsitem, null, null);
            // Obtain Session Bean reference
            CardMaintenanceMgrHome mobjCardMaintenanceMgrHome = (CardMaintenanceMgrHome) PortableRemoteObject.narrow(FunctionLib.getLookup(serverConstant.VIEW_CRDCUSTDET_SESSION), CardMaintenanceMgrHome.class);
            CardMaintenanceMgr mobjCardMaintenanceMgr = mobjCardMaintenanceMgrHome.create();

            // Get crddet details from Session Bean
            CrddetPKInfo tobjCrddetPKInfo = new CrddetPKInfo();
            CardMaintDetailInfo tobjCardMaintDetailInfo = new CardMaintDetailInfo();

            tobjCrddetPKInfo.setPan(pobjSetCardStatusDetailInfo.getPan());
            tobjCrddetPKInfo.setSeqno(pobjSetCardStatusDetailInfo.getSeqno());
            tobjCardMaintDetailInfo = mobjCardMaintenanceMgr.getCrddet(tobjCrddetPKInfo);
            String locationCode = tobjCardMaintDetailInfo.getBrncode();

            //clean up code
            tobjCrddetPKInfo = null;
            tobjCardMaintDetailInfo = null;
            mobjCardMaintenanceMgr = null;
            mobjCardMaintenanceMgrHome = null;
            tobjCrdstatusPKInfo = null;
            mobjCrdstatusMgr = null;

            debugLib.logInfo(CLASSNAME, viewConstant.PREPARE_MKC_DATA_END);

            Boolean mkcJobCreated = (Boolean) Util.getMakerCheckerStatus(false, usrName, acsitem, locationCode, pobjSetCardStatusDetailInfo.getInstcode(), globalConstant.SOURCE_ID_CTX, recIdBuilder.toString(), jobAuthCallCollator, JobType.OLD_NEW_DIFF);
            if (!mkcJobCreated) {
                // Add new SetCardStatus record to database
                SetCardStatusDetailInfo tobjSetCardStatusDetailInfo
                        = mobjCardStatusMgr.addCardStatus(pobjSetCardStatusDetailInfo, acsitem);
                if (!tobjSetCardStatusDetailInfo.getStatcode().equals("00")
                        && tobjSetCardStatusDetailInfo.getScheme() != null
                        && tobjSetCardStatusDetailInfo.getScheme().equals(viewConstant.VISA)
                        && psDisablePrompt.equals("false")) {
                    //This formAction should be captured and a confirmation message "ia.msg.VISA_EXCEPTION_FILE"
                    //from the user should be obtained.
                    // Please Check
                    pobjSetCardStatusDetailForm.setPrompt("true");
                    //               String formAction=viewConstant.PERFORM_PROMPT;
                }
                // Please Check
                String tsResult = viewConstant.PERFORM_SUCCESS;
                return updateRes;
            } else {
                return globalConstant.MAKER_CHECKER_CONSTANT_SUCCESS;
            }
        } catch (serverException se) {
            throw se;
        } catch (Exception e) {
            throw new serverException("co.error.unknownerror");
        } finally {
            //MKC parameters cleanup
            execData = null;
            originalExecData = null;
            displayData = null;
            originalDisplayData = null;
        }
    }

    /**
     * This function invokes the session bean to update the CRDDET for the
     * selected Batch for Application Input<br>
     *
     * @throws RemoteException
     * @throws CreateException
     * @throws serverException
     * @throws Exception
     */
    private void performEdit(BRESetCardStatusDetailForm pobjSetCardStatusDetailForm,
            SetCardStatusDetailInfo pobjSetCardStatusDetailInfo)
            throws RemoteException, CreateException, serverException, Exception {
        try {
            Object tobjRef = FunctionLib.getLookup(serverConstantBre.VIEW_BRE_CRDSTHST_SESSION);
            BRECardStatusMgrHome tobjCardStatusMgrHome
                    = (BRECardStatusMgrHome) PortableRemoteObject.narrow(tobjRef, BRECardStatusMgrHome.class);
            BRECardStatusMgr mobjCardStatusMgr = tobjCardStatusMgrHome.create();
            // Alvis 14/04/2010 CTXAPPSMAINT-164 : VISA: Exception File Maintenace (correct values filled when old_statcode non existent)
            if (pobjSetCardStatusDetailInfo.getHasOldCard() && "0".equals(pobjSetCardStatusDetailInfo.getUpdateoldcardstat())) {
                pobjSetCardStatusDetailForm.setSetCardStatusDetailInfo(mobjCardStatusMgr.editSetCardStatus(pobjSetCardStatusDetailInfo));
            } else {
                pobjSetCardStatusDetailForm.setSetCardStatusDetailInfo(mobjCardStatusMgr.getCrdCustInfo(pobjSetCardStatusDetailInfo.getPan(),
                        pobjSetCardStatusDetailInfo.getSeqno()));
            }
        } catch (serverException se) {
            throw se;
        } catch (Exception e) {
            throw new serverException("co.error.unknownerror");
        }
    }

    /**
     * This function invokes the session bean to update the CRDDET for the
     * selected Batch for Application Input<br>
     *
     * @throws RemoteException
     * @throws CreateException
     * @throws serverException
     * @throws Exception
     */
    private void performRefresh(BRESetCardStatusDetailForm pobjSetCardStatusDetailForm,
            SetCardStatusDetailInfo pobjSetCardStatusDetailInfo)
            throws RemoteException, CreateException, serverException, Exception {
        try {
            Object tobjRef = FunctionLib.getLookup(serverConstantBre.VIEW_BRE_CRDSTHST_SESSION);
            BRECardStatusMgrHome tobjCardStatusMgrHome = (BRECardStatusMgrHome) PortableRemoteObject.narrow(tobjRef, BRECardStatusMgrHome.class);
            BRECardStatusMgr mobjCardStatusMgr = tobjCardStatusMgrHome.create();

            // JFC: 21/06/05: Ensuring that the dateset/timeset are preserved as they are required for later-on
            java.sql.Date tobjSetDate = pobjSetCardStatusDetailInfo.getDateset();
            long tlSetTime = pobjSetCardStatusDetailInfo.getTime_set();

            pobjSetCardStatusDetailInfo = mobjCardStatusMgr.getCrdCustInfo(pobjSetCardStatusDetailInfo.getPan(), pobjSetCardStatusDetailInfo.getSeqno());

            pobjSetCardStatusDetailInfo.setDateset(tobjSetDate);
            pobjSetCardStatusDetailInfo.setTime_set(tlSetTime);
            pobjSetCardStatusDetailInfo.setStrTime_set(dateTimeLib.convertLongToStringTime(pobjSetCardStatusDetailInfo.getTime_set()));
            pobjSetCardStatusDetailInfo.setPanDisplay(pobjSetCardStatusDetailInfo.getPanDisplay());
            pobjSetCardStatusDetailForm.setSetCardStatusDetailInfo(pobjSetCardStatusDetailInfo);
        } catch (serverException se) {
            throw se;
        } catch (Exception e) {
            throw new serverException("co.error.unknownerror");
        }
    }

    /**
     * This function check permission of setting card status<br>
     *
     * @throws RemoteException
     * @throws CreateException
     * @throws serverException
     * @throws Exception
     */
    private boolean allowStatusChange(SetCardStatusDetailInfo pobjSetCardStatusDetailInfo, HttpServletRequest pobjRequest)
            throws RemoteException, CreateException, serverException, Exception {
        StartupXmlConfigData startupXmlData = StartupXmlConfigData.getInstance();
        boolean changeStatusAllowed = false;
        Boolean allowUndefStatusChange = false;
        try {
            allowUndefStatusChange = !(new Boolean(startupXmlData.getParameterFileItem(globalConstant.DENY_UNDEF_STATUS_CHANGE)));
        } catch (Exception e) {
            allowUndefStatusChange = new Boolean("true");
        }
        String fromStatus = pobjSetCardStatusDetailInfo.getOldstat();
        String toStatus = pobjSetCardStatusDetailInfo.getStatcode();
        String acsItem = CommonGlobalFunctions.getStatusChangeAcsItemValue(fromStatus, toStatus);
        if (acsItem == null) {
            changeStatusAllowed = allowUndefStatusChange;
        } else {
            String userName = (String) pobjRequest.getSession().getAttribute(viewConstant.USERNAME);
            AccessPermissions accessPermissions = new AccessPermissions();

            boolean userPermissionsSet = AccessPermissions.getUserPermissionsSet(acsItem, userName);
            if (userPermissionsSet) {
                changeStatusAllowed = accessPermissions.checkUpdatePermission(userName, acsItem);
            } else {
                StartupData instance = StartupData.getInstance();
                Usr usr = instance.getUsr(userName);
                String groupName = usr.getUsrgrp();
                boolean groupPermissionsSet = AccessPermissions.getGroupPermissionsSet(acsItem, groupName);
                if (groupPermissionsSet) {
                    changeStatusAllowed = accessPermissions.checkUpdatePermission(userName, acsItem);
                } else {
                    changeStatusAllowed = allowUndefStatusChange;
                }
            }
        }
        return changeStatusAllowed;
    }

    private SetCardStatusDetailInfo copyCardStatusDetail(SetCardStatusDetailInfo pobjSetCardStatusDetailInfo) {
        SetCardStatusDetailInfo setCardStatusDetailInfo = new SetCardStatusDetailInfo();

        setCardStatusDetailInfo.setAccno(pobjSetCardStatusDetailInfo.getAccno());
        setCardStatusDetailInfo.setAdditionalno(pobjSetCardStatusDetailInfo.getAdditionalno());
        setCardStatusDetailInfo.setAddrl1(pobjSetCardStatusDetailInfo.getAddrl1());
        setCardStatusDetailInfo.setAddrl2(pobjSetCardStatusDetailInfo.getAddrl2());
        setCardStatusDetailInfo.setBatch(pobjSetCardStatusDetailInfo.getBatch());
        setCardStatusDetailInfo.setCardBlockOnly(pobjSetCardStatusDetailInfo.getCardBlockOnly());
        setCardStatusDetailInfo.setChargedata(pobjSetCardStatusDetailInfo.getChargedata());
        setCardStatusDetailInfo.setChargetype(pobjSetCardStatusDetailInfo.getChargetype());
        setCardStatusDetailInfo.setClassid(pobjSetCardStatusDetailInfo.getClassid());
        setCardStatusDetailInfo.setCorp(pobjSetCardStatusDetailInfo.getCorp());
        setCardStatusDetailInfo.setCrdproduct(pobjSetCardStatusDetailInfo.getCrdproduct());
        setCardStatusDetailInfo.setCurrcode(pobjSetCardStatusDetailInfo.getCurrcode());
        setCardStatusDetailInfo.setCustcode(pobjSetCardStatusDetailInfo.getCustcode());
        setCardStatusDetailInfo.setDatebirth(pobjSetCardStatusDetailInfo.getDatebirth());
        setCardStatusDetailInfo.setDateExpdate(pobjSetCardStatusDetailInfo.getDateExpdate());
        setCardStatusDetailInfo.setDateset(new java.sql.Date(1000) {
            public String toString() {
                return " ";
            }
        });
        setCardStatusDetailInfo.setDisplayname(pobjSetCardStatusDetailInfo.getDisplayname());
        setCardStatusDetailInfo.setEmbossname(pobjSetCardStatusDetailInfo.getEmbossname());
        setCardStatusDetailInfo.setExpdate(pobjSetCardStatusDetailInfo.getExpdate());
        setCardStatusDetailInfo.setFirstname(pobjSetCardStatusDetailInfo.getFirstname());
        setCardStatusDetailInfo.setHasOldCard(pobjSetCardStatusDetailInfo.getHasOldCard());
        setCardStatusDetailInfo.setHome_city(pobjSetCardStatusDetailInfo.getHome_city());
        setCardStatusDetailInfo.setHome_tel(pobjSetCardStatusDetailInfo.getHome_tel());
        setCardStatusDetailInfo.setInstcode(pobjSetCardStatusDetailInfo.getInstcode());
        setCardStatusDetailInfo.setLastname(pobjSetCardStatusDetailInfo.getLastname());
        setCardStatusDetailInfo.setOldcardexpdate(pobjSetCardStatusDetailInfo.getOldcardexpdate());
        setCardStatusDetailInfo.setOldstat(pobjSetCardStatusDetailInfo.getOldstat());
        setCardStatusDetailInfo.setOldstatdescr(pobjSetCardStatusDetailInfo.getOldstatdescr());
        setCardStatusDetailInfo.setPan(pobjSetCardStatusDetailInfo.getPan());
        setCardStatusDetailInfo.setPanDisplay(pobjSetCardStatusDetailInfo.getPanDisplay());
        setCardStatusDetailInfo.setScheme(pobjSetCardStatusDetailInfo.getScheme());
        setCardStatusDetailInfo.setSeqno(pobjSetCardStatusDetailInfo.getSeqno());
        setCardStatusDetailInfo.setStatcode(pobjSetCardStatusDetailInfo.getOldstat());
        setCardStatusDetailInfo.setOldcardstat(pobjSetCardStatusDetailInfo.getOldcardstat());
        setCardStatusDetailInfo.setStrdatebirth(pobjSetCardStatusDetailInfo.getStrdatebirth());
        setCardStatusDetailInfo.setTypeid(pobjSetCardStatusDetailInfo.getTypeid());
        setCardStatusDetailInfo.setUpdateoldcardstat(pobjSetCardStatusDetailInfo.getUpdateoldcardstat());
        setCardStatusDetailInfo.setUsrdata(pobjSetCardStatusDetailInfo.getUsrdata());
        setCardStatusDetailInfo.setVerno_ctx(pobjSetCardStatusDetailInfo.getVerno_ctx());
        setCardStatusDetailInfo.setWho_set(pobjSetCardStatusDetailInfo.getWho_set());
        setCardStatusDetailInfo.setWhy_set("");

        return setCardStatusDetailInfo;

    }

}
