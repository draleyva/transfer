package com.cortex.cust.bre.gui.ia.formbean;

import com.cortex.common.lib.Resource;
import com.cortex.common.lib.debugLib;
import com.cortex.gui.common.formbean.SessionDataForm;
import com.cortex.gui.common.lib.LocaleFormatConverter;
import com.cortex.gui.ia.valueobj.SetCardStatusDetailInfo;
import java.sql.Date;
import java.text.ParseException;
import java.util.PropertyResourceBundle;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

/**
 * <hr><h3> Copyright & copy Nomad Software Ltd.</h3><h4> Project No : 1103 <br>
 * Module Name : Issuer Authorizer <br> Use case ref : UC0070<br> Use case name
 * : changeCardStatus<br> Version No : 1.0 <br> Date created : 6/09/2002 <br>
 * 
* This is the Form class of Set Card Status Detail screen<br>
 * 
* Date Author Reviewer Description of change 6/09/2002 Sunandha
 * Ramasamy/Nithila S. 09/12/2002 Chandu AT-0934
 * 
* @author Sunandha Ramasamy/Nithila S.
 */
public class BRESetCardStatusDetailForm extends SessionDataForm {

    private SetCardStatusDetailInfo mobjSetCardStatusDetailInfo;
    private String msFromwhere = "0";
    private String msPrompt = "false";
    private final static String CLASSNAME = "BRESetCardStatusDetailForm";

    public boolean getCardBlockOnly() {
        return mobjSetCardStatusDetailInfo.getCardBlockOnly();
    }

    public void setCardBlockOnly(boolean mbCardBlockOnly) {
        mobjSetCardStatusDetailInfo.setCardBlockOnly(mbCardBlockOnly);
    }

    /**
     * Default constructor. It will create a new SetCardStatusDetailInfo object.
     * All the values of this info object are set to default.
     */
    public BRESetCardStatusDetailForm() {
        mobjSetCardStatusDetailInfo = new SetCardStatusDetailInfo();
    }

    /**
     * Constructor that accepts an SetCardStatusnfo object
     *
     * @param pobjSetCardStatusDetailInfo the info object of the form
     */
    public BRESetCardStatusDetailForm(SetCardStatusDetailInfo pobjSetCardStatusDetailInfo) {
        mobjSetCardStatusDetailInfo = pobjSetCardStatusDetailInfo;
    }

    /**
     * Constructor that accepts an SetCardStatusnfo object
     *
     * @param pobjSetCardStatusDetailInfo the info object of the form
     */
    public BRESetCardStatusDetailForm(SetCardStatusDetailInfo pobjSetCardStatusDetailInfo, HttpServletRequest request) {
        // passing request ensures locale is set up, for hack use of new Form in action class. 
        this.reset(null, request);
        mobjSetCardStatusDetailInfo = pobjSetCardStatusDetailInfo;
    }

    /**
     * @param pobjSetCardStatusDetailInfo
     * @return Void
     */
    public void setSetCardStatusDetailInfo(SetCardStatusDetailInfo pobjSetCardStatusDetailInfo) {

        mobjSetCardStatusDetailInfo = pobjSetCardStatusDetailInfo;
        try {
            mobjSetCardStatusDetailInfo.setExpdate(convertSQLToLocaleStringDate(mobjSetCardStatusDetailInfo.getExpdate(), getLocale()));
        } catch (Exception e) {
            debugLib.logDetail(CLASSNAME, e, getUser());
            getActionErrors().add(ActionErrors.GLOBAL_ERROR, new ActionError("ia.error.invaliddate"));
        }
    }

    /**
     * @return SetCardStatusDetailInfo
     */
    public SetCardStatusDetailInfo getSetCardStatusDetailInfo() {
        return mobjSetCardStatusDetailInfo;
    }

    /**
     * Access method for the msInstcode property.
     *
     * @return the current value of the msInstcode property
     */
    public String getInstcode() {
        return mobjSetCardStatusDetailInfo.getInstcode();
    }

    /**
     * Sets the value of the msInstcode property.
     *
     * @param psInstcode the new value of the msInstcode property
     */
    public void setInstcode(String psInstcode) {
        mobjSetCardStatusDetailInfo.setInstcode(psInstcode);
    }

    /**
     * Access method for the msPan property.
     *
     * @return the current value of the msPan property
     */
    public String getPan() {
        return mobjSetCardStatusDetailInfo.getPan();
    }

    /**
     * Sets the value of the msPan property.
     *
     * @param psPan the new value of the msPan property
     */
    public void setPan(String psPan) {
        mobjSetCardStatusDetailInfo.setPan(psPan);
    }

    /**
     * Access method for the miSeqno property.
     *
     * @return the current value of the miSeqno property
     */
    public int getSeqno() {
        return mobjSetCardStatusDetailInfo.getSeqno();
    }

    /**
     * Sets the value of the miSeqno property.
     *
     * @param piSeqno the new value of the miSeqno property
     */
    public void setSeqno(int piSeqno) {
        mobjSetCardStatusDetailInfo.setSeqno(piSeqno);
    }

    /**
     * Access method for the msEmbossname property.
     *
     * @return the current value of the msEmbossname property
     */
    public String getEmbossname() {
        return mobjSetCardStatusDetailInfo.getEmbossname();
    }

    /**
     * Sets the value of the msEmbossname property.
     *
     * @param psEmbossname the new value of the msEmbossname property
     */
    public void setEmbossname(String psEmbossname) {
        mobjSetCardStatusDetailInfo.setEmbossname(psEmbossname);
    }

    /**
     * Access method for the msCustcode property.
     *
     * @return the current value of the msCustcode property
     */
    public String getCustcode() {
        return mobjSetCardStatusDetailInfo.getCustcode();
    }

    /**
     * Sets the value of the msCustcode property.
     *
     * @param psCustcode the new value of the msCustcode property
     */
    public void setCustcode(String psCustcode) {
        mobjSetCardStatusDetailInfo.setCustcode(psCustcode);
    }

    /**
     * Access method for the msDisplayname property.
     *
     * @return the current value of the msDisplayname property
     */
    public String getDisplayname() {
        return mobjSetCardStatusDetailInfo.getDisplayname();
    }

    /**
     * Sets the value of the msDisplayname property.
     *
     * @param psDisplayname the new value of the msDisplayname property
     */
    public void setDisplayname(String psDisplayname) {
        mobjSetCardStatusDetailInfo.setDisplayname(psDisplayname);
    }

    /**
     * Access method for the msUsrdata property.
     *
     * @return the current value of the msUsrdata property
     */
    public String getUsrdata() {
        return mobjSetCardStatusDetailInfo.getUsrdata();
    }

    /**
     * Sets the value of the msUsrdata property.
     *
     * @param psUsrdata the new value of the msUsrdata property
     */
    public void setUsrdata(String psUsrdata) {
        mobjSetCardStatusDetailInfo.setUsrdata(psUsrdata);
    }

    /**
     * Access method for the msAddrl1 property.
     *
     * @return the current value of the msAddrl1 property
     */
    public String getAddrl1() {
        return mobjSetCardStatusDetailInfo.getAddrl1();
    }

    /**
     * Sets the value of the msAddrl1 property.
     *
     * @param psAddrl1 the new value of the msAddrl1 property
     */
    public void setAddrl1(String psAddrl1) {
        mobjSetCardStatusDetailInfo.setAddrl1(psAddrl1);
    }

    /**
     * Access method for the msAddrl2 property.
     *
     * @return the current value of the msAddrl2 property
     */
    public String getAddrl2() {
        return mobjSetCardStatusDetailInfo.getAddrl2();
    }

    /**
     * Sets the value of the msAddrl2 property.
     *
     * @param psAddrl2 the new value of the msAddrl2 property
     */
    public void setAddrl2(String psAddrl2) {
        mobjSetCardStatusDetailInfo.setAddrl2(psAddrl2);
    }

    /**
     * Access method for the msAddrl3 property.
     *
     * @return the current value of the msAddrl3 property
     */
    public String getAddrl3() {
        return mobjSetCardStatusDetailInfo.getAddrl3();
    }

    /**
     * Sets the value of the msAddrl3 property.
     *
     * @param psAddrl3 the new value of the msAddrl3 property
     */
    public void setAddrl3(String psAddrl3) {
        mobjSetCardStatusDetailInfo.setAddrl3(psAddrl3);
    }

    /**
     * Access method for the msHome_city property.
     *
     * @return the current value of the msHome_city property
     */
    public String getHome_city() {
        return mobjSetCardStatusDetailInfo.getHome_city();
    }

    /**
     * Sets the value of the msHome_city property.
     *
     * @param psHome_city the new value of the msHome_city property
     */
    public void setHome_city(String psHome_city) {
        mobjSetCardStatusDetailInfo.setHome_city(psHome_city);
    }

    /**
     * Access method for the msHome_tel property.
     *
     * @return the current value of the msHome_tel property
     */
    public String getHome_tel() {
        return mobjSetCardStatusDetailInfo.getHome_tel();
    }

    /**
     * Sets the value of the msHome_tel property.
     *
     * @param psHome_tel the new value of the msHome_tel property
     */
    public void setHome_tel(String psHome_tel) {
        mobjSetCardStatusDetailInfo.setHome_tel(psHome_tel);
    }

    /**
     * Access method for the msOldstat property.
     *
     * @return the current value of the msOldstat property
     */
    public String getUpdateoldcardstat() {
        return mobjSetCardStatusDetailInfo.getUpdateoldcardstat();
    }

    /**
     * Sets the value of the msOldstat property.
     *
     * @param psOldstat the new value of the msOldstat property
     */
    public void setUpdateoldcardstat(String psUpdateoldcardstat) {
        mobjSetCardStatusDetailInfo.setUpdateoldcardstat(psUpdateoldcardstat);
    }

    /**
     * Access method for the msOldstat property.
     *
     * @return the current value of the msOldstat property
     */
    public Date getOldcardexpdate() {
        return mobjSetCardStatusDetailInfo.getOldcardexpdate();
    }

    /**
     * Sets the value of the msOldstat property.
     *
     * @param psOldstat the new value of the msOldstat property
     */
    public void setOldcardexpdate(Date psOldcardexpdate) {
        mobjSetCardStatusDetailInfo.setOldcardexpdate(psOldcardexpdate);
    }

    /**
     * Access method for the msOldstat property.
     *
     * @return the current value of the msOldstat property
     */
    public String getOldcardstat() {
        return mobjSetCardStatusDetailInfo.getOldcardstat();
    }

    /**
     * Sets the value of the msOldstat property.
     *
     * @param psOldstat the new value of the msOldstat property
     */
    public void setOldcardstat(String psOldcardstat) {
        mobjSetCardStatusDetailInfo.setOldcardstat(psOldcardstat);
    }

    /**
     * Access method for the msOldstat property.
     *
     * @return the current value of the msOldstat property
     */
    public String getOldstat() {
        return mobjSetCardStatusDetailInfo.getOldstat();
    }

    /**
     * Sets the value of the msOldstat property.
     *
     * @param psOldstat the new value of the msOldstat property
     */
    public void setOldstat(String psOldstat) {
        mobjSetCardStatusDetailInfo.setOldstat(psOldstat);
    }

    /**
     * Access method for the msOldstatdescr property.
     *
     * @return the current value of the msOldstatdescr property
     */
    public String getOldstatdescr() {
        return mobjSetCardStatusDetailInfo.getOldstatdescr();
    }

    /**
     * Sets the value of the msOldstatdescr property.
     *
     * @param psOldstatdescr the new value of the msOldstatdescr property
     */
    public void setOldstatdescr(String psOldstatdescr) {
        mobjSetCardStatusDetailInfo.setOldstatdescr(psOldstatdescr);
    }

    /**
     * Access method for the msStatcode property.
     *
     * @return the current value of the msStatcode property
     */
    public String getStatcode() {
        return mobjSetCardStatusDetailInfo.getStatcode();
    }

    /**
     * Sets the value of the msStatcode property.
     *
     * @param psStatcode the new value of the msStatcode property
     */
    public void setStatcode(String psStatcode) {
        mobjSetCardStatusDetailInfo.setStatcode(psStatcode);
    }

    /**
     * Sets the value of the msStrDate_birth property.
     *
     * @param psTime_set the new value of the msDate_birth property
     */
    public void setStrdatebirth(String psDate_birth) {
        mobjSetCardStatusDetailInfo.setStrdatebirth(psDate_birth);
    }

    /**
     * Access method for the msStrDate_birth property.
     *
     * @return the current value of the msDate_birth property
     */
    public String getStrdatebirth() {
        return mobjSetCardStatusDetailInfo.getStrdatebirth();
    }

    /**
     * Sets the value of the msStrDate_set property.
     *
     * @param psStrdate_set the new value of the msStrDate_set property
     */
    public void setStrdateset(String psStrdate_set) {
        try {
            mobjSetCardStatusDetailInfo.setDateset(LocaleFormatConverter.convertLocaleToDate(psStrdate_set, getLocale()));
        } catch (ParseException e) {
            Resource mobjResource = new Resource();
            PropertyResourceBundle tobjRb = (PropertyResourceBundle) mobjResource.getPropertiesFile();
            String tsFieldName = tobjRb.getString("ia.label.date");

            debugLib.logDetail(CLASSNAME, e, getUser());
            getActionErrors().add(ActionErrors.GLOBAL_ERROR, new ActionError("error.locale.default", tsFieldName));
        }
    }

    /**
     * Access method for the msStrDate_set property.
     *
     * @return the current value of the msDate_set property
     */
    public String getStrdateset() {
        return LocaleFormatConverter.convertDateToLocale(mobjSetCardStatusDetailInfo.getDateset(), getLocale());
    }

    /**
     * Access method for the mlTime_set property.
     *
     * @return the current value of the mlTime_set property
     */
    public long getTimeset() {
        return mobjSetCardStatusDetailInfo.getTime_set();
    }

    /**
     * Sets the value of the mlTime_set property.
     *
     * @param plTime_set the new value of the mlTime_set property
     */
    public void setTimeset(long plTime_set) {
        mobjSetCardStatusDetailInfo.setTime_set(plTime_set);
    }

    /**
     * Access method for the msWhy_set property.
     *
     * @return the current value of the msWhy_set property
     */
    public String getWhyset() {
        return mobjSetCardStatusDetailInfo.getWhy_set();
    }

    /**
     * Sets the value of the msWhy_set property.
     *
     * @param psWhy_set the new value of the msWhy_set property
     */
    public void setWhyset(String psWhy_set) {
        mobjSetCardStatusDetailInfo.setWhy_set(psWhy_set);
    }

    /**
     * Access method for the msWho_set property.
     *
     * @return the current value of the msWho_set property
     */
    public String getWhoset() {
        return mobjSetCardStatusDetailInfo.getWho_set();
    }

    /**
     * Sets the value of the msWho_set property.
     *
     * @param psWho_set the new value of the msWho_set property
     */
    public void setWhoset(String psWho_set) {
        mobjSetCardStatusDetailInfo.setWho_set(psWho_set);
    }

    /**
     * Access method for the miClassid property.
     *
     * @return the current value of the miClassid property
     */
    public int getClassid() {
        return mobjSetCardStatusDetailInfo.getClassid();
    }

    /**
     * Sets the value of the miClassid property.
     *
     * @param piClassid the new value of the miClassid property
     */
    public void setClassid(int piClassid) {
        mobjSetCardStatusDetailInfo.setClassid(piClassid);
    }

    /**
     * Access method for the mcCorp property.
     *
     * @return the current value of the mcCorp property
     */
    public String getCorp() {
        return mobjSetCardStatusDetailInfo.getCorp();
    }

    /**
     * Sets the value of the mcCorp property.
     *
     * @param pcCorp the new value of the mcCorp property
     */
    public void setCorp(String pcCorp) {
        if (pcCorp.length() > 0) {
            mobjSetCardStatusDetailInfo.setCorp(pcCorp);
        }
    }

    /**
     * Access method for the miAdditionalno property.
     *
     * @return the current value of the miAdditionalno property
     */
    public int getAdditionalno() {
        return mobjSetCardStatusDetailInfo.getAdditionalno();
    }

    /**
     * Sets the value of the miAdditionalno property.
     *
     * @param piAdditionalno the new value of the miAdditionalno property
     */
    public void setAdditionalno(int piAdditionalno) {
        mobjSetCardStatusDetailInfo.setAdditionalno(piAdditionalno);
    }

    /**
     * Access method for the msAccno property.
     *
     * @return the current value of the msAccno property
     */
    public String getAccno() {
        return mobjSetCardStatusDetailInfo.getAccno();
    }

    /**
     * Sets the value of the msAccno property.
     *
     * @param psAccno the new value of the msAccno property
     */
    public void setAccno(String psAccno) {
        mobjSetCardStatusDetailInfo.setAccno(psAccno);
    }

    /**
     * Access method for the miBatch property.
     *
     * @return the current value of the miBatch property
     */
    public int getBatch() {
        return mobjSetCardStatusDetailInfo.getBatch();
    }

    /**
     * Sets the value of the miBatch property.
     *
     * @param piBatch the new value of the miBatch property
     */
    public void setBatch(int piBatch) {
        mobjSetCardStatusDetailInfo.setBatch(piBatch);
    }

    /**
     * Access method for the msCrdproduct property.
     *
     * @return the current value of the msCrdproduct property
     */
    public String getCrdproduct() {
        return mobjSetCardStatusDetailInfo.getCrdproduct();
    }

    /**
     * Sets the value of the msCrdproduct property.
     *
     * @param psCrdproduct the new value of the msCrdproduct property
     */
    public void setCrdproduct(String psCrdproduct) {
        mobjSetCardStatusDetailInfo.setCrdproduct(psCrdproduct);
    }

    /**
     * Access method for the miTypeid property.
     *
     * @return the current value of the miTypeid property
     */
    public int getTypeid() {
        return mobjSetCardStatusDetailInfo.getTypeid();
    }

    /**
     * Sets the value of the miTypeid property.
     *
     * @param piTypeid the new value of the miTypeid property
     */
    public void setTypeid(int piTypeid) {
        mobjSetCardStatusDetailInfo.setTypeid(piTypeid);
    }

    /**
     * Access method for the msScheme property.
     *
     * @return the current value of the msScheme property
     */
    public String getScheme() {
        return mobjSetCardStatusDetailInfo.getScheme();
    }

    /**
     * Sets the value of the msScheme property.
     *
     * @param psScheme the new value of the msScheme property
     */
    public void setScheme(String psScheme) {
        mobjSetCardStatusDetailInfo.setScheme(psScheme);
    }

    /**
     * Access method for the msChargedata property.
     *
     * @return the current value of the msChargedata property
     */
    public String getChargedata() {
        return mobjSetCardStatusDetailInfo.getChargedata();
    }

    /**
     * Sets the value of the msChargedata property.
     *
     * @param psChargedata the new value of the msChargedata property
     */
    public void setChargedata(String psChargedata) {
        mobjSetCardStatusDetailInfo.setChargedata(psChargedata);
    }

    /**
     * Access method for the miChargetype property.
     *
     * @return the current value of the miChargetype property
     */
    public int getChargetype() {
        return mobjSetCardStatusDetailInfo.getChargetype();
    }

    /**
     * Sets the value of the miChargetype property.
     *
     * @param piChargetype the new value of the miChargetype property
     */
    public void setChargetype(int piChargetype) {
        mobjSetCardStatusDetailInfo.setChargetype(piChargetype);
    }

    /**
     * Access method for the msCurrcode property.
     *
     * @return the current value of the msCurrcode property
     */
    public String getCurrcode() {
        return mobjSetCardStatusDetailInfo.getCurrcode();
    }

    /**
     * Sets the value of the msCurrcode property.
     *
     * @param psCurrcode the new value of the msCurrcode property
     */
    public void setCurrcode(String psCurrcode) {
        mobjSetCardStatusDetailInfo.setCurrcode(psCurrcode);
    }

    public String getPanDisplay() {
        return mobjSetCardStatusDetailInfo.getPanDisplay();
    }

    public void setPanDisplay(String psPanDisplay) {
        mobjSetCardStatusDetailInfo.setPanDisplay(psPanDisplay);
    }

    /**
     * Gets the Fromwhere value
     *
     * @return String
     */
    public String getFromwhere() {
        return msFromwhere;
    }

    /**
     * Sets the Fromwhere value
     *
     * @param psFromwhere
     */
    public void setFromwhere(String psFromwhere) {
        msFromwhere = psFromwhere;
    }

    /**
     * Gets the strTimeset value
     *
     * @return String
     */
    public String getStrTimeset() {
        return LocaleFormatConverter.convertTimeToLocale(mobjSetCardStatusDetailInfo.getTime_set());
    }

    /**
     * Sets the strTimeset value
     *
     * @param pStrTimeset
     */
    public void setStrTimeset(String pStrTimeset) {
        try {
            mobjSetCardStatusDetailInfo.setTime_set(LocaleFormatConverter.convertLocaletoTime(pStrTimeset));
        } catch (ParseException e) {
            Resource mobjResource = new Resource();
            PropertyResourceBundle tobjRb = (PropertyResourceBundle) mobjResource.getPropertiesFile();
            String tsFieldName = tobjRb.getString("ia.label.timeadded");

            debugLib.logDetail(CLASSNAME, e, getUser());
            getActionErrors().add(ActionErrors.GLOBAL_ERROR, new ActionError("error.locale.default", tsFieldName));
        }
    }

    /**
     * Gets the Prompt value
     *
     * @return String
     */
    public String getPrompt() {
        return msPrompt;
    }

    /**
     * Sets the Prompt value
     *
     * @param psPrompt
     */
    public void setPrompt(String psPrompt) {
        msPrompt = psPrompt;
    }

    /**
     * Access method for the msExpdate property.
     *
     * @return the current value of the msExpdate property
     */
    public String getExpdate() {
        return mobjSetCardStatusDetailInfo.getExpdate();
    }

    /**
     * Sets the value of the msExpdate property.
     *
     * @param psExpdate the new value of the msExpdate property
     */
    public void setExpdate(String psExpdate) {
        mobjSetCardStatusDetailInfo.setExpdate(psExpdate);
    }

    public boolean getHasOldCard() {
        return mobjSetCardStatusDetailInfo.getHasOldCard();
    }

    public void setHasOldCard(boolean value) {
        mobjSetCardStatusDetailInfo.setHasOldCard(value);
    }

    /**
     * Access method for the ext_custnum property.
     *
     * @return the current value of the ext_custnum property
     */
    public String getExt_custnum() {
        return mobjSetCardStatusDetailInfo.getExt_custnum();
    }

    /**
     * Sets the value of the ext_custnum property.
     *
     * @param ext_custnum the new value of the ext_custnum property
     */
    public void setExt_custnum(String ext_custnum) {
        mobjSetCardStatusDetailInfo.setExt_custnum(ext_custnum);
    }

    public void reset(ActionMapping mapping, HttpServletRequest request) {
        // Please do not remove call to super
        super.reset(mapping, request);

        // Info object initialisation
        mobjSetCardStatusDetailInfo = new SetCardStatusDetailInfo();

        // Locale currency fields initialisation   
        //mobjAmxbtchexcInfo.set(null);

        //No currency fields for this form

    }
}
