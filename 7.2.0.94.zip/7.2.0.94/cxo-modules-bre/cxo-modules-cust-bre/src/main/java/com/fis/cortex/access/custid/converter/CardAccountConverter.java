package com.fis.cortex.access.custid.converter;

import java.util.HashMap;
import java.util.Map;

import com.fis.cortex.access.custid.view.CardAccount;
import com.fis.cortex.transport.core.converter.EntityTransportConverter;
import com.fis.cortex.transport.core.dataholder.TransportObject.Id;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/converter/CardAccountConverter.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class CardAccountConverter extends EntityTransportConverter<com.nomadsoft.cortex.domain.card.CardAccount, CardAccount>{
	
	private AccountConverter accountConverter;
	private CardConverter cardConverter;
	
	public CardAccount convertRealToTransport(com.nomadsoft.cortex.domain.card.CardAccount cardAcount){
		CardAccount  cardAccountDTO =  new CardAccount();
		cardAccountDTO.setAccount(accountConverter.convertRealToTransport(cardAcount.getId().getAccount()));
		cardAccountDTO.setCard(cardConverter.convertRealToTransport(cardAcount.getId().getCard()));
		cardAccountDTO.setIsoCode(cardAcount.getIsoCode());
		cardAccountDTO.setRoleId(cardAcount.getRoleId());
		cardAccountDTO.setTypeCode(cardAcount.getTypeCode());		
		return cardAccountDTO;
		
	}
	
	public void setAccountConverter(AccountConverter accountConverter){
		this.accountConverter =accountConverter;
	}
	public void setCardConverter(CardConverter cardConverter){
		this.cardConverter =cardConverter;
	}	
	
	public com.nomadsoft.cortex.domain.card.CardAccount findReal(Id cardAccountId, Integer version) {
		return null;
	}
	
	
	public com.nomadsoft.cortex.domain.card.CardAccount findCardAccount(CardAccount cardAccountId, Integer version) {
		com.nomadsoft.cortex.domain.card.CardAccount out = null;		
			Map<String, Object> criteria = new HashMap<String, Object>();
			criteria.put("id.card", cardAccountId.getCard());
			criteria.put("id.account", cardAccountId.getAccount());
			if(version != null) {
				criteria.put("versionNumber", version);
			}
			out = (com.nomadsoft.cortex.domain.card.CardAccount)getDomainCommonServicesX().findAtMostOne(
					"com.nomadsoft.cortex.domain.card.CardAccount", criteria);
		
		return out;
		
		
		
	}
	
	protected void updateRealFromTransport(com.nomadsoft.cortex.domain.card.CardAccount cardAccount, CardAccount cardAccountDTO){
			
	}
	

}
