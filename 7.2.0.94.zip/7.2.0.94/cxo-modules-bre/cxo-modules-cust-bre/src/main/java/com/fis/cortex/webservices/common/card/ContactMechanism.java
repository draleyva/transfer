package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "ContactMech")
@XmlAccessorType(XmlAccessType.FIELD)
public class ContactMechanism {
	
	@XmlElement(name = "Telcom", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private TeleCommunication telcom;
	@XmlElement(name = "Address", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Address address;
	@XmlElement(name = "DeliveryRef", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private DeliveryReference deliveryReference;
	@XmlElement(name = "EAddr", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Email eAddr; 
	public TeleCommunication getTelcom() {
		return telcom;
	}
	public void setTelcom(TeleCommunication telcom) {
		this.telcom = telcom;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Email geteAddr() {
		return eAddr;
	}
	public void seteAddr(Email eAddr) {
		this.eAddr = eAddr;
	}
	public DeliveryReference getDeliveryReference() {
		return deliveryReference;
	}
	public void setDeliveryReference(DeliveryReference deliveryReference) {
		this.deliveryReference = deliveryReference;
	}
	
	

}
