package com.fis.cortex.webservices.common.card;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "AddCrdRetDataResponse")
@XmlAccessorType(XmlAccessType.FIELD)
public class AdditionalCardReturnDataResponse {
	
	@XmlElement(name = "PIN", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String pin;
	
	@XmlElementWrapper( name = "CardProDataLst", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	@XmlElement( name = "AppProData", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private List<ApplicationProductionData> applicationProductionDataList;

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public List<ApplicationProductionData> getApplicationProductionDataList() {
		return applicationProductionDataList;
	}

	public void setApplicationProductionDataList(
			List<ApplicationProductionData> applicationProductionDataList) {
		this.applicationProductionDataList = applicationProductionDataList;
	}

	

}
