package com.metavante.cortexonline.wicket.content.cust.components;

import java.util.List;

import org.apache.wicket.AttributeModifier;
import org.apache.wicket.RequestCycle;
import org.apache.wicket.ajax.AbstractDefaultAjaxBehavior;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.behavior.AbstractAjaxBehavior;
import org.apache.wicket.behavior.AttributeAppender;
import org.apache.wicket.markup.ComponentTag;
import org.apache.wicket.markup.html.IHeaderResponse;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.markup.transformer.NoopOutputTransformerContainer;
import org.apache.wicket.model.AbstractReadOnlyModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fis.cortex.transport.core.dataholder.TransportObject;
import com.fis.cortex.wicket.base.CortexAjaxLink;
import com.metavante.cortexonline.wicket.content.cust.components.CustomizedAjaxSearcher.Column;
import com.metavante.cortexonline.wicket.content.cust.components.CustomizedAjaxSearcher.Converter;


/**
 * This panel is used to display  results for a Account search
 * 
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/components/CustomizedAjaxResultPanel.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class CustomizedAjaxResultPanel<T extends TransportObject> extends Panel {

	private static final long serialVersionUID = 1L;

	private static final Logger LOG = LoggerFactory
			.getLogger(CustomizedAjaxResultPanel.class);

	private CustomizedAjaxSearcher<T> searcher;
	private List<Column<T>> columns;
	private CortexAjaxLink cortexLinkBtn;

	private int totalPages;

	@SuppressWarnings("deprecation")
	public CustomizedAjaxResultPanel(String id, CustomizedAjaxSearcher<T> searcher) {
		super(id);

		this.searcher = searcher;
		this.columns = searcher.getColumns();

		this.searcher.setOutputMarkupId(true);
		this.searcher.setOutputMarkupPlaceholderTag(true);
		this.setOutputMarkupId(true);
		this.setOutputMarkupPlaceholderTag(true);

		this.createTitles();
		this.createDataBreakLines();
		this.createRows();
		this.addLinkButtons();

		this.add(new AbstractAjaxBehavior() {
			private static final long serialVersionUID = 1L;

			public void onRequest() {
				// TODO Auto-generated method stub
			}

			public void renderHead(IHeaderResponse response) {
				String javaScript = "$$(\".searchResultsContainer\").each(function(container) {"
						+ "var i = 0;"
						+ "container.select(\".resultRow\").each(function(row) {"
						+ "row.index = i;"
						+ "row.observe(\"mouseover\", function(e1) {"
						+ "this.addClassName(\"hovering\");"
						+ "}.bindAsEventListener(row));"
						+ "row.observe(\"mouseout\", function(e1) {"
						+ "this.removeClassName(\"hovering\");"
						+ "}.bindAsEventListener(row));"
						+ "i++;"
						+ "});"
						+ "});";

				response.renderOnLoadJavascript(javaScript);

			}
		});
	}

	@Override
	protected void onBeforeRender() {

		if (this.isVisible()) {
			this.totalPages = this.searcher.getTransport().getAllResultsSize()
					/ this.searcher.getTransport().getPageSize();
			if (this.searcher.getTransport().getAllResultsSize()
					% this.searcher.getTransport().getPageSize() != 0) {
				this.totalPages++;
			}
			if(this.searcher.getTransport().getAllResultsSize()>0){
				this.cortexLinkBtn.setEnabled(true);
			}else{
				this.cortexLinkBtn.setEnabled(false);
			}
		}

		super.onBeforeRender();
	}

	@Override
	public boolean isVisible() {
		return this.searcher.getTransport() != null;
	}



	private void createDataBreakLines() {
		AttributeModifier behaviour = new AttributeModifier("colspan",
				new Model<String>(String.format("%d", this.columns.size())));
		this.add(new NoopOutputTransformerContainer("dataBreakLine1")
				.add(behaviour));
		this.add(new NoopOutputTransformerContainer("dataBreakLine2")
				.add(behaviour));
	}

	private void createTitles() {
		this.add(new ListView<Column<?>>("resultFieldTitle", this.columns) {
			private static final long serialVersionUID = 1L;

			@Override
			protected void populateItem(ListItem<Column<?>> item) {
				item.add(new Label("resultFieldTitleText",
						new PropertyModel<String>(item.getModel(), "title")));
			}
		});
	}

	private void createRows() {
		this.add(new ListView<T>("resultRow", new PropertyModel<List<T>>(this,
				"searcher.transport.results")) {
			private static final long serialVersionUID = 1L;

			@Override
			protected void populateItem(final ListItem<T> lineItem) {

				lineItem.add(new ListView<Column<T>>("resultField",
						CustomizedAjaxResultPanel.this.columns) {
					private static final long serialVersionUID = 1L;

					@Override
					protected void populateItem(
							final ListItem<Column<T>> fieldItem) {
						final Converter<T> converter = fieldItem
								.getModelObject().getConverter();
						fieldItem.add(new Label("resultFieldContent", converter
								.getModel(lineItem.getModelObject())));
					}
				});
				// ... the modifier to alternate the row colours
				lineItem.add(new AttributeAppender("class",
						new AbstractReadOnlyModel<String>() {
							private static final long serialVersionUID = 1L;

							@Override
							public String getObject() {
								return lineItem.getIndex() % 2 == 0 ? "a" : "b";
							}
						}, " "));				
				lineItem.setOutputMarkupId(true);
			}
		});
	}
	
    private void addLinkButtons() {
			this.add(this.cortexLinkBtn=new CortexAjaxLink<Object>("link_card") {
				private static final long serialVersionUID = 1L;
		
				@Override
				public void onClick(AjaxRequestTarget target) {			
					target.addComponent(CustomizedAjaxResultPanel.this);
					CustomizedAjaxResultPanel.this.searcher.onLinkCard(target);
					target.addComponent(CustomizedAjaxResultPanel.this.searcher);
				}
			});
			this.cortexLinkBtn.setOutputMarkupId(true);
			this.cortexLinkBtn.setOutputMarkupPlaceholderTag(true);
			this.add(new CortexAjaxLink<Object>("link_back") {
				private static final long serialVersionUID = 1L;
				@Override
				public void onClick(AjaxRequestTarget target) {			
					CustomizedAjaxResultPanel.this.searcher.onCancel(target);
				}
			});
     }
	
}
