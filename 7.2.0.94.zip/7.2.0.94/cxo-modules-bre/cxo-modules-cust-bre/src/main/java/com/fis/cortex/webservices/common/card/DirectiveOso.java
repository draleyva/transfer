package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * @author rmura
 *
 */
@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "DirectiveOso")
@XmlAccessorType(XmlAccessType.FIELD)
public class DirectiveOso
{

	@XmlElement(name = "RecId", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String recId;
	@XmlElement(name = "Action", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String action;
	@XmlElement(name = "InstCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String instCode;
	@XmlElement(name = "ActionCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String actionCode;
	@XmlElement(name = "CrdDetResponse", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private CreditDetailResponse creditDetailResponse;
	@XmlElement(name = "AddCrdRetDataResponse", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private AdditionalCardReturnDataResponse additionalCardReturnDataResponse;
	
	public AdditionalCardReturnDataResponse getAdditionalCardReturnDataResponse() {
		return additionalCardReturnDataResponse;
	}
	public void setAdditionalCardReturnDataResponse(
			AdditionalCardReturnDataResponse additionalCardReturnDataResponse) {
		this.additionalCardReturnDataResponse = additionalCardReturnDataResponse;
	}
	public String getRecId() {
		return recId;
	}
	public void setRecId(String recId) {
		this.recId = recId;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getInstCode() {
		return instCode;
	}
	public void setInstCode(String instCode) {
		this.instCode = instCode;
	}
	public String getActionCode() {
		return actionCode;
	}
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}
	public CreditDetailResponse getCreditDetailResponse() {
		return creditDetailResponse;
	}
	public void setCreditDetailResponse(CreditDetailResponse creditDetailResponse) {
		this.creditDetailResponse = creditDetailResponse;
	}
}
