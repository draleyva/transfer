package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;

/**
 * 
 * @author jricha
 * 
 */

@SuppressWarnings("restriction")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {"dataValue"})

@XmlRootElement(name = "EvalData", namespace = "http://crdbase.cortex.fis.com/getFee")
public class EvalData {

    @XmlValue
    protected String dataValue;
    @XmlAttribute(name = "DataType", required = true)
    protected String dataTypeValue;
	
    public String getDataValue() {
		return dataValue;
	}
	public void setDataValue(String dataValue) {
		this.dataValue = dataValue;
	}
	public String getDataTypeValue() {
		return dataTypeValue;
	}
	public void setDataTypeValue(String dataTypeValue) {
		this.dataTypeValue = dataTypeValue;
	}
}
