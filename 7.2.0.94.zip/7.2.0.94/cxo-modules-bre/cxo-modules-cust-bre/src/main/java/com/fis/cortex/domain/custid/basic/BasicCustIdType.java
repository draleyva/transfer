package com.fis.cortex.domain.custid.basic;


import java.io.Serializable;

import com.nomadsoft.cortex.domain.institution.Institution;
import com.fis.cortex.domain.custid.CustIdType;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/domain/custid/basic/BasicCustIdType.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class BasicCustIdType implements CustIdType,Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private int  versionNumber;
	private Institution institution;
	private String  code;
	private String description;
	
	public long getId(){
		return id;
	}

    public void setId(long id){
    	this.id = id;
    }

    public int getVersionNumber(){
    	return  this.versionNumber;
    }

   public  void setVersionNumber(int versionNumber){
	   this.versionNumber=versionNumber;
   }

   public Institution getInstitution(){
    	return this.institution;
    }

   public  void setInstitution(Institution institution){
	   this.institution =institution;
   }

   public  String getCode(){
    	return code;
    }

   public  void setCode(String code){
    	this.code =code;
    }

   public  String getDescription(){
	  return this.description;
   }

   public void setDescription(String description){
	   this.description =description;
   }


	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result
				+ ((institution == null) ? 0 : institution.hashCode());
		return result;
	}
	
	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BasicCustIdType other = (BasicCustIdType) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (institution == null) {
			if (other.institution != null)
				return false;
		} else if (!institution.equals(other.institution))
			return false;
		return true;
	}
   

}
