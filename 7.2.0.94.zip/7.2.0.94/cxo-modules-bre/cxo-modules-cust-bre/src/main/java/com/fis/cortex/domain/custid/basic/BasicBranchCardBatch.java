package com.fis.cortex.domain.custid.basic;

import com.nomadsoft.cortex.domain.branch.Branch;
import com.nomadsoft.cortex.domain.cardbatch.CardBatch;

import com.fis.cortex.domain.custid.BranchCardBatch;

public class BasicBranchCardBatch implements BranchCardBatch{
	
	 private static final long serialVersionUID = -2637046633379956487L;
	 
     private Long id;	

	 private int versionNumber;
	 
	 private Branch branch;
	 
	 private CardBatch cardBatch;	 

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}
	public CardBatch getCardBatch() {
		return cardBatch;
	 }

	public void setCardBatch(CardBatch cardBatch) {
		this.cardBatch = cardBatch;
	}
	
 

}
