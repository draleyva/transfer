package com.fis.cortex.transport.custid.exception;

import com.metavante.cortex.transport.exceptions.BusinessException;

/**
 * This class is used to throw exception Customer(AccountHolder) entity not found in DB
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/transport/custid/exception/CustomerNotFoundException.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public class CustomerNotFoundException extends BusinessException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4779060380643655387L;

	public CustomerNotFoundException() {
		super();
		
	}

	public CustomerNotFoundException(String message) {
		super(message);
		
	}

}
