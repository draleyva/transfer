package com.fis.cortex.webservices.common.card.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.fis.cortex.webservices.common.card.serviceparameter.ServiceParametersList;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "http://wscore.cortex.fis.com/ctxCommonRspHdr", name = "RspHdr")
public class ResponseHeader {
	
	public ResponseHeader(){}
	
	@XmlElement(required = true, name = "RspHdrVer", namespace = "http://wscore.cortex.fis.com/ctxCommonRspHdr")
	private String rspHdrVer;

	@XmlElement(required = true, name = "RtnCde", namespace = "http://wscore.cortex.fis.com/ctxCommonRspHdr")
	private String rtnCde;

	@XmlElement(required = true, name = "MsgUuid", namespace = "http://wscore.cortex.fis.com/ctxCommonRspHdr")
	private String msgUuid;

	@XmlElement(required = true, name = "Lcl", namespace = "http://wscore.cortex.fis.com/ctxCommonRspHdr")
	private String lcl;
	
	@XmlElement(required = true, name = "ServPrmtrsLst", namespace = "http://wscore.cortex.fis.com/ctxCommon")
	private ServiceParametersList servPrmtrsLst;

	@XmlElement(required = true, name = "MsgLst", namespace = "http://wscore.cortex.fis.com/ctxCommonRspHdr")
	private MessageList msgLst;


	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(namespace = "http://wscore.cortex.fis.com/ctxCommonRqstHdr", name = "MsgLst")
	public static class MessageList{
		
		@XmlElement(required = true, name = "msg", namespace = "http://wscore.cortex.fis.com/ctxCommonRspHdr")
		private Message msg;
				
		public Message getMsg() {
			return msg;
		}

		public void setMsg(Message msg) {
			this.msg = msg;
		}


		@XmlAccessorType(XmlAccessType.FIELD)
		@XmlType(namespace = "http://wscore.cortex.fis.com/ctxCommonRqstHdr", name = "msg")
		public static class Message{
			
			@XmlElement(required = true, name = "MsgCde", namespace = "http://wscore.cortex.fis.com/ctxCommonRspHdr")
			private String msgCde;

			@XmlElement(required = true, name = "Typ", namespace = "http://wscore.cortex.fis.com/ctxCommonRspHdr")
			private String typ;
			
			@XmlElement(required = false, name = "MsgLcl", namespace = "http://wscore.cortex.fis.com/ctxCommonRspHdr")
			private String msgLcl;

			@XmlElement(required = false, name = "Txt", namespace = "http://wscore.cortex.fis.com/ctxCommonRspHdr")
			private String txt;

			public String getMsgCde() {
				return msgCde;
			}

			public void setMsgCde(String msgCde) {
				this.msgCde = msgCde;
			}

			public String getTyp() {
				return typ;
			}

			public void setTyp(String typ) {
				this.typ = typ;
			}

			public String getMsgLcl() {
				return msgLcl;
			}

			public void setMsgLcl(String msgLcl) {
				this.msgLcl = msgLcl;
			}

			public String getTxt() {
				return txt;
			}

			public void setTxt(String txt) {
				this.txt = txt;
			}
		}
	}


	public String getRspHdrVer() {
		return rspHdrVer;
	}


	public void setRspHdrVer(String rspHdrVer) {
		this.rspHdrVer = rspHdrVer;
	}


	public String getRtnCde() {
		return rtnCde;
	}


	public void setRtnCde(String rtnCde) {
		this.rtnCde = rtnCde;
	}


	public String getMsgUuid() {
		return msgUuid;
	}


	public void setMsgUuid(String msgUuid) {
		this.msgUuid = msgUuid;
	}


	public String getLcl() {
		return lcl;
	}


	public void setLcl(String lcl) {
		this.lcl = lcl;
	}


	public ServiceParametersList getServPrmtrsLst() {
		return servPrmtrsLst;
	}


	public void setServPrmtrsLst(ServiceParametersList servPrmtrsLst) {
		this.servPrmtrsLst = servPrmtrsLst;
	}


	public MessageList getMsgLst() {
		return msgLst;
	}


	public void setMsgLst(MessageList msgLst) {
		this.msgLst = msgLst;
	}
	
}