package com.fis.cortex.access.custid.view;

import java.util.Date;

import com.fis.cortex.transport.core.dataholder.TransportList;
import com.fis.cortex.transport.core.dataholder.TransportObject;
import com.metavante.cortex.transport.objects.common.Branch;


/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/view/Card.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public class Card extends TransportObject {
	
	private static final long serialVersionUID = -5541759053337962763L;		
	private TransportList<Account> accounts;
	private TransportList<Account> linkedAccounts;	
	private String pan;
	private String panDisplay;	
	private short sequenceNumber;
	private String currency;
    private String virtualPan;
    private Branch branch;
    private AccountHolder accountHolder;
    private String accessCode;
    private Account account;
    private boolean authCharsIndicator;
    private short additionalNumber;
    private short addrind;  
    private int applicationNumber;
    private int appTransactionCounter;   
    private Short cardClass;
    private boolean corporateCard;
    private int cardDesignId;
    private CardProduct cardProduct;    
    private short cardsMade;
    private String cscString;
    private String cardVerificationCode;
    private String cardVerificationValue;  
    private short cycleLen;    
    private String discretionaryData;
    private char deliveryMethod;   
    private String embossedName;  
    private short fallbackCount;
    private String kinshipToPrimary;
    private char languageCode;
    private char nopin;
    private short pinsMade;
    private char pinVerificationKeyIndex;
    private String pinVerificationValue;
    private String recid;
    private boolean renewalFlag;
    private short scriptStatus;   
    private String serviceCode;
    private String userDefinedData;
    private CardHolder cardHolder;
    private Date expiresOn;
    private CardStatus cardStatus;
    private String cardBatch;
	
	
	
	public String getCardBatch() {
		return cardBatch;
	}
	public void setCardBatch(String cardBatch) {
		this.cardBatch = cardBatch;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getPanDisplay() {
		return panDisplay;
	}
	public void setPanDisplay(String panDisplay) {
		this.panDisplay = panDisplay;
	}
	public short getSequenceNumber() {
		return sequenceNumber;
	}
	public void setSequenceNumber(short sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getVirtualPan() {
		return virtualPan;
	}
	public void setVirtualPan(String virtualPan) {
		this.virtualPan = virtualPan;
	}
	public Branch getBranch() {
		return branch;
	}
	public void setBranch(Branch branch) {
		this.branch = branch;
	}
	public AccountHolder getAccountHolder() {
		return accountHolder;
	}
	public void setAccountHolder(AccountHolder accountHolder) {
		this.accountHolder = accountHolder;
	}
	public String getAccessCode() {
		return accessCode;
	}
	public void setAccessCode(String accessCode) {
		this.accessCode = accessCode;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public boolean isAuthCharsIndicator() {
		return authCharsIndicator;
	}
	public void setAuthCharsIndicator(boolean authCharsIndicator) {
		this.authCharsIndicator = authCharsIndicator;
	}
	public short getAdditionalNumber() {
		return additionalNumber;
	}
	public void setAdditionalNumber(short additionalNumber) {
		this.additionalNumber = additionalNumber;
	}
	public short getAddrind() {
		return addrind;
	}
	public void setAddrind(short addrind) {
		this.addrind = addrind;
	}
	public int getApplicationNumber() {
		return applicationNumber;
	}
	public void setApplicationNumber(int applicationNumber) {
		this.applicationNumber = applicationNumber;
	}
	public int getAppTransactionCounter() {
		return appTransactionCounter;
	}
	public void setAppTransactionCounter(int appTransactionCounter) {
		this.appTransactionCounter = appTransactionCounter;
	}
	public Short getCardClass() {
		return cardClass;
	}
	public void setCardClass(Short cardClass) {
		this.cardClass = cardClass;
	}
	public boolean isCorporateCard() {
		return corporateCard;
	}
	public void setCorporateCard(boolean corporateCard) {
		this.corporateCard = corporateCard;
	}
	public int getCardDesignId() {
		return cardDesignId;
	}
	public void setCardDesignId(int cardDesignId) {
		this.cardDesignId = cardDesignId;
	}
	public CardProduct getCardProduct() {
		return cardProduct;
	}
	public void setCardProduct(CardProduct cardProduct) {
		this.cardProduct = cardProduct;
	}
	public short getCardsMade() {
		return cardsMade;
	}
	public void setCardsMade(short cardsMade) {
		this.cardsMade = cardsMade;
	}
	public String getCscString() {
		return cscString;
	}
	public void setCscString(String cscString) {
		this.cscString = cscString;
	}
	public String getCardVerificationCode() {
		return cardVerificationCode;
	}
	public void setCardVerificationCode(String cardVerificationCode) {
		this.cardVerificationCode = cardVerificationCode;
	}
	public String getCardVerificationValue() {
		return cardVerificationValue;
	}
	public void setCardVerificationValue(String cardVerificationValue) {
		this.cardVerificationValue = cardVerificationValue;
	}
	public short getCycleLen() {
		return cycleLen;
	}
	public void setCycleLen(short cycleLen) {
		this.cycleLen = cycleLen;
	}
	public String getDiscretionaryData() {
		return discretionaryData;
	}
	public void setDiscretionaryData(String discretionaryData) {
		this.discretionaryData = discretionaryData;
	}
	public char getDeliveryMethod() {
		return deliveryMethod;
	}
	public void setDeliveryMethod(char deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}
	public String getEmbossedName() {
		return embossedName;
	}
	public void setEmbossedName(String embossedName) {
		this.embossedName = embossedName;
	}
	public short getFallbackCount() {
		return fallbackCount;
	}
	public void setFallbackCount(short fallbackCount) {
		this.fallbackCount = fallbackCount;
	}
	public String getKinshipToPrimary() {
		return kinshipToPrimary;
	}
	public void setKinshipToPrimary(String kinshipToPrimary) {
		this.kinshipToPrimary = kinshipToPrimary;
	}
	public char getLanguageCode() {
		return languageCode;
	}
	public void setLanguageCode(char languageCode) {
		this.languageCode = languageCode;
	}
	public char getNopin() {
		return nopin;
	}
	public void setNopin(char nopin) {
		this.nopin = nopin;
	}
	public short getPinsMade() {
		return pinsMade;
	}
	public void setPinsMade(short pinsMade) {
		this.pinsMade = pinsMade;
	}
	public char getPinVerificationKeyIndex() {
		return pinVerificationKeyIndex;
	}
	public void setPinVerificationKeyIndex(char pinVerificationKeyIndex) {
		this.pinVerificationKeyIndex = pinVerificationKeyIndex;
	}
	public String getPinVerificationValue() {
		return pinVerificationValue;
	}
	public void setPinVerificationValue(String pinVerificationValue) {
		this.pinVerificationValue = pinVerificationValue;
	}
	public String getRecid() {
		return recid;
	}
	public void setRecid(String recid) {
		this.recid = recid;
	}
	public boolean isRenewalFlag() {
		return renewalFlag;
	}
	public void setRenewalFlag(boolean renewalFlag) {
		this.renewalFlag = renewalFlag;
	}
	public short getScriptStatus() {
		return scriptStatus;
	}
	public void setScriptStatus(short scriptStatus) {
		this.scriptStatus = scriptStatus;
	}
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public String getUserDefinedData() {
		return userDefinedData;
	}
	public void setUserDefinedData(String userDefinedData) {
		this.userDefinedData = userDefinedData;
	}
	public TransportList<Account> getAccounts() {
		return accounts;
	}
	public void setAccounts(TransportList<Account> accounts) {
		this.accounts = accounts;
	}	
	public CardHolder getCardHolder() {
		return cardHolder;
	}
	public void setCardHolder(CardHolder cardHolder) {
		this.cardHolder = cardHolder;
	}
	public TransportList<Account> getLinkedAccounts() {
		return linkedAccounts;
	}
	public void setLinkedAccounts(TransportList<Account> linkedAccounts) {
		this.linkedAccounts = linkedAccounts;
	}
	
	public Date getExpiresOn() {
		return expiresOn;
	}
	public void setExpiresOn(Date expiresOn) {
		this.expiresOn = expiresOn;
	}
	
	public CardStatus getCardStatus() {
		return cardStatus;
	}
	public void setCardStatus(CardStatus cardStatus) {
		this.cardStatus = cardStatus;
	}

    

}
