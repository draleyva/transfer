package com.metavante.cortexonline.wicket.content.cust.additionalaccounts.panels;

import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.spring.injection.annot.SpringBean;

import com.fis.cortex.access.custid.view.AdditionalAccountsContextSummary;
import com.fis.cortex.transport.custid.services.CustomerService;
import com.fis.cortex.wicket.CortexSession;
import com.metavante.cortex.transport.objects.core.Institution;
import com.metavante.cortexonline.wicket.CortexRequestCycle;
import com.metavante.cortexonline.wicket.BasePage.PageInfo;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowManager;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowResult;
import com.metavante.cortexonline.wicket.content.rules.panels.AbstractMainPanel;
import com.metavante.cortexonline.wicket.metadata.AcsInfo;
/**
 * Amend Accounts main panel which redirect the user to appropriate screen based
 * on user action.
 *  
 *  
 * 
 * @author schinnas
 * @version
 * 
 */

@AcsInfo(acsItem = "amend_acc_main")
public class AmendAccountsMainPanel extends AbstractMainPanel {

	private static final long serialVersionUID = 1L;
	private static final int STATE_FAILURE = -1;
	private static final int STATE_START = 0;
	private static final int STATE_AFTERHOME = 1;
	private static final String AMEND_ACCOUNT_PATH = "/wicket/customer/amendaccounts";

	@SpringBean(name = "transportCustomerIdService")
	private CustomerService customerService;

	public AmendAccountsMainPanel(Institution institution) {
		super(institution);
		this.getPanel().setWorkFlow(this, STATE_START);
		this.setOutputMarkupId(true);
		this.setOutputMarkupPlaceholderTag(true);
	}

	public static class GoCardSearchResult extends WorkFlowResult {
		private static final long serialVersionUID = 1L;
		AdditionalAccountsContextSummary additionalAccContextSummary;
		transient AjaxRequestTarget target;

		public GoCardSearchResult(AdditionalAccountsContextSummary additionalAccountsContextSummary) {
			super(Status.REDIRECT);
			this.additionalAccContextSummary = additionalAccountsContextSummary;
		}

		public GoCardSearchResult(
				AdditionalAccountsContextSummary additionalAccountsContextSummary,
				AjaxRequestTarget requestTarget) {
			super(Status.REDIRECT);
			this.additionalAccContextSummary = additionalAccountsContextSummary;
			this.target = requestTarget;
		}

		public void setAjaxRequestTarget(AjaxRequestTarget target) {
			this.target = target;
		}

		public AjaxRequestTarget getAjaxRequestTarget() {
			return this.target;
		}
	}

	public static class GoSearchCardPanel extends WorkFlowResult {
		private static final long serialVersionUID = 1L;
		AdditionalAccountsContextSummary additionalAccContextSummary;

		public GoSearchCardPanel(
				AdditionalAccountsContextSummary additionalAccountsContextSummary) {
			super(Status.REDIRECT);
			this.additionalAccContextSummary = additionalAccountsContextSummary;
		}
	}

	public static class GoInstitutionSelectionPanel extends WorkFlowResult {
		private static final long serialVersionUID = 1L;

		public GoInstitutionSelectionPanel() {
			super(Status.REDIRECT);
		}
	}

	// workflow
	public void process(WorkFlowManager manager) {
		switch (manager.getState()) {
		case STATE_START:
			this.doHome(manager);
			break;
		case STATE_AFTERHOME:
			if (manager.getLastResult() instanceof GoCardSearchResult)
				this.showAmendAccounts(manager);
			else if (manager.getLastResult() instanceof GoSearchCardPanel)
				this.doHome(manager);
			else if (manager.getLastResult() instanceof GoInstitutionSelectionPanel) {
				manager.terminate();
				try {
					StringBuilder urlBuilder = new StringBuilder();
					urlBuilder.append(
							CortexRequestCycle.get().getWebRequest()
									.getHttpServletRequest().getContextPath())
							.append(AMEND_ACCOUNT_PATH);
					CortexRequestCycle.get().getWebResponse()
							.getHttpServletResponse()
							.sendRedirect(urlBuilder.toString());
				} catch (Exception exp) {
					this.error(exp.getMessage());
				}
			}
			break;
		default:
			manager.terminate();
			this.setResponsePage(com.metavante.cortexonline.wicket.HomePage.class);
			break;
		}
	}

	
	public PageInfo getPageInfo() {
		PageInfo pageInfo = super.getPageInfo();
		pageInfo.addTitle("Institution: " + this.institution.getCode());
		return pageInfo;
	}

	private void doHome(WorkFlowManager manager) {
		AdditionalAccountsContextSummary additionalAccountContextSummary = new AdditionalAccountsContextSummary(
				this.institution, null,null);
		manager.setPanel(new AmendAccountsHomePanel(
				additionalAccountContextSummary), STATE_FAILURE, STATE_FAILURE,
				STATE_FAILURE, STATE_AFTERHOME, true);
	}

	private void showAmendAccounts(WorkFlowManager manager) {
		if(CortexSession.exists()){
			GoCardSearchResult result = (GoCardSearchResult) manager
					.getLastResult();
			AmendAccountsPanel panel = new AmendAccountsPanel(
					result.additionalAccContextSummary);
			AjaxRequestTarget target = result.getAjaxRequestTarget();
			manager.setPanel(panel, STATE_FAILURE, STATE_FAILURE, STATE_FAILURE,
					STATE_AFTERHOME, true);
			if (target != null) {
				target.addComponent(panel);
				target.addComponent(this);
			}
		}else{
			manager.terminate();
			this.setResponsePage(com.metavante.cortexonline.wicket.HomePage.class);
		}
	}

}
