package com.fis.cortex.access.custid.view;
import com.fis.cortex.transport.core.dataholder.TransportObject;
/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/view/CustIdType.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public class CustIdType extends TransportObject implements Cloneable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long instId;
	private  String code;
	private String  description;
	private long custId;

	public long getCustId() {
		return custId;
	}
	public void setCustId(long custId) {
		this.custId = custId;
	}
	public long getInstId() {
		return instId;
	}
	public void setInstId(long instId) {
		this.instId = instId;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
