package com.fis.cortex.access.custid.view;

import com.fis.cortex.transport.core.dataholder.TransportObject;

/**
 * 
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/view/CardStatus.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 * 
 */

public class CardStatus extends TransportObject{

	private static final long serialVersionUID = 440879954040167958L;
	private String statusCode;
	private char actionCode;
	private String description;
	private String responseCode;
	private boolean cancelled;
	private boolean systemDefined;
	

	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public char getActionCode() {
		return actionCode;
	}
	public void setActionCode(char actionCode) {
		this.actionCode = actionCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public boolean isCancelled() {
		return cancelled;
	}
	public void setCancelled(boolean cancelled) {
		this.cancelled = cancelled;
	}
	public boolean isSystemDefined() {
		return systemDefined;
	}
	public void setSystemDefined(boolean systemDefined) {
		this.systemDefined = systemDefined;
	}
	

}
