package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "crdDetResponse")
@XmlAccessorType(XmlAccessType.FIELD)
public class CreditDetailResponse {
	
	@XmlElement(name = "PAN", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String pan;
	@XmlElement(name = "CardAlias", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String cardAlias;
	@XmlElement(name = "PANDisplay", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String panDisplay;
	@XmlElement(name = "CrdProduct", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String cardProduct;
	
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getCardAlias() {
		return cardAlias;
	}
	public void setCardAlias(String cardAlias) {
		this.cardAlias = cardAlias;
	}
	public String getPanDisplay() {
		return panDisplay;
	}
	public void setPanDisplay(String panDisplay) {
		this.panDisplay = panDisplay;
	}
	public void setCardProduct(String cardProduct) {
		this.cardProduct = cardProduct;
	}
	public String getCardProduct() {
		return cardProduct;
	}
	

}
