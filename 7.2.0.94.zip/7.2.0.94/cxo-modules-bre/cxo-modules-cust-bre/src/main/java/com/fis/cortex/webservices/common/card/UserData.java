package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "UserData")
@XmlAccessorType(XmlAccessType.FIELD)
public class UserData 
{
	@XmlElement(name = "Occ", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Integer occurance;
	@XmlElement(name = "Data", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String data;
	
	public Integer getOccurance() {
		return occurance;
	}
	public void setOccurance(Integer occurance) {
		this.occurance = occurance;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}

}
