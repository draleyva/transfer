package com.fis.cortex.webservices.common.card.request;

import javax.xml.bind.annotation.XmlElement;

public class AbstractRequest {

	private RequestHeader rqstHdr;

	@XmlElement(required = true, name = "RqstHdr", namespace = "http://wscore.cortex.fis.com/ctxCommonRqstHdr")
	public RequestHeader getRqstHdr() {
		return rqstHdr;
	}

	public void setRqstHdr(RequestHeader rqstHdr) {
		this.rqstHdr = rqstHdr;
	}

}
