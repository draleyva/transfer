package com.fis.cortex.webservices.common.card;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "AccDet")
@XmlAccessorType(XmlAccessType.FIELD)
public class AccountDetail 
{
	@XmlElement(name = "DuplicateMng", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String duplicateMng;
	
	@XmlElement(name = "AccLnkAction", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Short accountLinkAction;
	
	@XmlElement(name = "AccNo", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String accNo;
	@XmlElement(name = "CurrCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String currCode;
	@XmlElement(name = "TypeCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String typeCode;
	@XmlElement(name = "BrnCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String branchCode;
	@XmlElement(name = "CustCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String customerCode;
	@XmlElement(name = "StatCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String statusCode;
	@XmlElement(name = "VIPFlag", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String vipFlag;
	@XmlElementWrapper( name = "UserDataLst", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	@XmlElement( name = "UserData", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private List<UserData> UserDataLst;
	
	
	public String getDuplicateMng() {
		return duplicateMng;
	}
	public void setDuplicateMng(String duplicateMng) {
		this.duplicateMng = duplicateMng;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getCurrCode() {
		return currCode;
	}
	public void setCurrCode(String currCode) {
		this.currCode = currCode;
	}
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getVipFlag() {
		return vipFlag;
	}
	public void setVipFlag(String vipFlag) {
		this.vipFlag = vipFlag;
	}
	public void setAccountLinkAction(Short accountLinkAction) {
		this.accountLinkAction = accountLinkAction;
	}
	public Short getAccountLinkAction() {
		return accountLinkAction;
	}

	public void setUserDataLst(List<UserData> userDataLst) {
		UserDataLst = userDataLst;
	}
	public List<UserData> getUserDataLst() {
		return UserDataLst;
	}
}
