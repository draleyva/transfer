package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "CrdNotify")
@XmlAccessorType(XmlAccessType.FIELD)
public class CardNotify {

	@XmlElement(name = "MobTel", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String mobileTelephone;
	@XmlElement(name = "Email", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String email;

	/**
	 * @return the mobileTelephone
	 */
	public String getMobileTelephone() {
		return mobileTelephone;
	}
	/**
	 * @param mobileTelephone the mobileTelephone to set
	 */
	public void setMobileTelephone(String mobileTelephone) {
		this.mobileTelephone = mobileTelephone;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
}
