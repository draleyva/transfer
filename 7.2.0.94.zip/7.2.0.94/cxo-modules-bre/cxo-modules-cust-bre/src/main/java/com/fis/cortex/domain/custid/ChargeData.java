package com.fis.cortex.domain.custid;

import java.util.Date;
import com.nomadsoft.cortex.domain.card.Card;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/domain/custid/ChargeData.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public interface ChargeData {
	
	long getId();
	
	void setId(long id);
	
	int getVersionNumber();
	
	void setVersionNumber(int versionNumber);
	
	Card getCard();
	
	void setCard(Card card);
	
	Date getTransactionDate();
	
	void setTransactionDate(Date transactionDate);
	
	long getChargeType();
	
    void setChargeType(long chargeType);
    
    String getChargeData();
    
    void setChargeData(String chargeData);
    
    String getChargeCurrency();
    
    void setChargeCurrency(String currency);
    
    long getCustomerType();
    
    void setCustomerType(long custType);
    
    String getOpdata();
    
    void setOpdata(String opdata);
    
    String getProcessed();
    
    void setProcessed(String processed);
    
	

}
