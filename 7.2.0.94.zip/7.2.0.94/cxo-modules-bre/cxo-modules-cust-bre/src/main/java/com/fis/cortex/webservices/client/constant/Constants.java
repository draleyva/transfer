package com.fis.cortex.webservices.client.constant;

public class Constants {
	public static final short ADDR_IND=0;
	public static final int  INT_ZERO=0;
	public static final int INT_ONE=1;	
	public static final String STRING_ONE = "1";
	public static final String STRING_ZERO = "1";
	public static final String GENERATE_CARD="1";
	public static final String DUPLICATE_MNG = "1";
	public static final String PREF_LANG="en_US";
	public static final String MSG_UUID="00000000-0000-0000-0000-000000000000";
	public static final String REQUEST_HDR_VER="3.0.0";
	public static final String SRC_ID="SYS1";
	public static final String SERVICE_ID="IssuerDirectives";
	public static final String APP_ID="CTX";
	public static final String FE_ID="123";
	public static final String SERVICE_VERSION="1.0.0";
	public static final String DATE_PATTERN="yyyy-MM-dd";
	public static final String ADDRESS_LINE1="addressline1";
	public static final String CITY="city";	
	public static final String REF_ID="001";
	public static final String EMAIL="test@test.com";
	public static final String COUNTRY_PREFIX="91";
	public static final String TELEPHONE_HOME="123456789";
	public static final String ACTION_CREATE = "1";
	public static final Short BTCH_CLASS_STANDARD = 1;
	public static final String NEVERDATE="22630831";
	public static final String NEVERDATE_DATE_PATTERN="yyyyMMdd";
	public static final String USER_CARD_CREATOR="Ctx user";
	public static final int CBTCH_ISSUE = 1;
	public static final int MAX_CARDS_IN_BATCHES = 100;
	public static final String NEXT_CARD_BATCH_TAG = "nextcrdbtch";
	public static final String MSC_MAXNUMCARDS = "maxnumcard";
	public static final String STRING_ONE_SPACE = " ";
	public static final String STRING_HYPEN = "-";
	public static final String DUMMY_COUNTRY_CODE="123";
	public static final int INT_TEN=10;
	public static final String  VALID_ACTION_CODE="000";
	public static final String  INVALID_ACTION_CODE="909";
	public static final int    EMBOSS_NAME_LENGTH=51;

}
