package com.metavante.cortexonline.wicket.content.cust.additionalaccounts.panels;

import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.wicket.Component;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.extensions.ajax.markup.html.modal.ModalWindow;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.model.CompoundPropertyModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.spring.injection.annot.SpringBean;
import com.cortex.common.exception.serverException;
import com.cortex.gui.common.lib.BasicPanCryptor;
import com.cortex.gui.common.lib.PanCryptor;
import com.fis.cortex.access.custid.view.AdditionalAccountsContextSummary;
import com.fis.cortex.access.custid.view.Card;
import com.fis.cortex.access.custid.view.Message;
import com.fis.cortex.transport.custid.exception.CardNotFoundException;
import com.fis.cortex.transport.custid.exception.GeneralSqlException;
import com.fis.cortex.transport.custid.services.CustomerService;
import com.fis.cortex.wicket.base.CortexAjaxButton;
import com.fis.cortex.wicket.base.CortexModalWindow;
import com.metavante.cortex.transport.objects.core.Institution;
import com.metavante.cortexonline.wicket.components.ContextPanel;
import com.metavante.cortexonline.wicket.components.buttonbox.BoxedSubmitButton;
import com.metavante.cortexonline.wicket.components.buttonbox.ButtonBox;
import com.metavante.cortexonline.wicket.components.componentline.TextFieldLine;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowPanel;
import com.metavante.cortexonline.wicket.content.cust.components.MessageDisplayPanel;
import com.metavante.cortexonline.wicket.metadata.AcsInfo;

/**
 * Amend Accounts home screen
 * User can search for a Card to which user wants to link/unlink accounts
 *  
 * 
 * @author schinnas
 * @version
 * 
 */

@AcsInfo(acsItem = "amend_acc_home")
public class AmendAccountsHomePanel extends WorkFlowPanel {

	private static Log logger = LogFactory
			.getLog(AmendAccountsHomePanel.class);
	private static final long serialVersionUID = 1L;
	private static final String DUMMY_CUST_CODE = "99999999";
	private static final String CARD_EXPIRED = "amend_acc_card_expired";
	private static final String ENCRYPTION_FAILED = "amend_acc_card_encryption_failed";
	private static final String CARD_NOT_ISSUED = "amend_acc_card_not_issued";
	private static final String INVALID_CARD_STATUS = "amend_acc_invalid_card_status";
	private static final String CARD_STATUS_NORMAL = "00";
	

	protected Institution institution;
	private String accPan;
	private Card card;
	private TextFieldLine<String> tlf;
	private AdditionalAccountsContextSummary additionalAccountsContextSummary;
	@SpringBean(name = "transportCustomerIdService")
	private CustomerService customerService;
	private CortexModalWindow msgModelWindow;
	private MessageDisplayPanel msgDisplayPanel;
	private Message amendAccountHomeMsg;
	private Form<Void> form;
	private CortexAjaxButton accHomeAjaxButton;
	private String cardNumber;
	private ButtonBox homePanelButtonBox;
	private BoxedSubmitButton cancelSubmitButton;

	// construction
	public AmendAccountsHomePanel(
			AdditionalAccountsContextSummary additionalAccountsContextSummary) {
		this.setDefaultModel(new CompoundPropertyModel<AmendAccountsHomePanel>(
				this));
		this.institution = additionalAccountsContextSummary.getInstitution();
		this.amendAccountHomeMsg = new Message();
		if (additionalAccountsContextSummary.getCard() != null) {
			this.card = additionalAccountsContextSummary.getCard();
		}
		form = new Form<Void>("form") {
			private static final long serialVersionUID = 1L;
			
			protected void onSubmit() {
				AmendAccountsHomePanel.this.cardNumber = new PropertyModel<String>(
						AmendAccountsHomePanel.this, "accPan").getObject();
			}
		};
		this.add(form);
		this.addContext(this);
		this.addControls(this.form);
		addMessageModelWindow(this.form);
		this.addButtons(this.form);
	}

	private void addContext(WebMarkupContainer parent) {
		parent.add(new ContextPanel("context").addInstitution(this.institution));
	}

	private void addControls(WebMarkupContainer parent) {
		PropertyModel<String> model = new PropertyModel<String>(this, "accPan");
		parent.add(this.tlf = new TextFieldLine<String>("cardNumber", this
				.getString("amend_acc_card_number"), model));
		this.tlf.setMaxLength(32);
		this.tlf.setMandatory(true);
	}

	private void addButtons(WebMarkupContainer parent) {
		this.homePanelButtonBox = new ButtonBox("searchButtonBox",false);
		this.accHomeAjaxButton = new CortexAjaxButton("button",
				new Model<String>(this.getString("amend_acc_search_btn")),
				AmendAccountsHomePanel.this.form) {
			private static final long serialVersionUID = 1L;

			
			protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
				AmendAccountsHomePanel.this.goSearchCardDetails(target);
			}

			
			protected void onError(AjaxRequestTarget target, Form<?> form) {
				if (AmendAccountsHomePanel.this
						.isEmpty(AmendAccountsHomePanel.this.cardNumber)) {
					target.appendJavascript("alert('"
							+ this.getString("amend_acc_card_empty") + "')");
				}
			}
		};
		
		this.homePanelButtonBox.addButton(this.accHomeAjaxButton);
		this.cancelSubmitButton=new BoxedSubmitButton(new Model<String>(this.getString("amend_acc_home_cancel_btn"))){
			private static final long serialVersionUID = 1L;
			
			public void onSubmit(){					
				AmendAccountsHomePanel.this.complete(new AmendAccountsMainPanel.GoInstitutionSelectionPanel());
			}
			
		};	
		this.cancelSubmitButton.setDefaultFormProcessing(false);
		this.homePanelButtonBox.addButton(this.cancelSubmitButton);
		this.homePanelButtonBox.setOutputMarkupId(true);
		this.homePanelButtonBox.setOutputMarkupPlaceholderTag(true);
		parent.add(this.homePanelButtonBox);

	}

	private void addMessageModelWindow(WebMarkupContainer parent) {
		this.msgModelWindow = new CortexModalWindow("zoomAmendAccMsgPanel",
				new PropertyModel<Message>(AmendAccountsHomePanel.this,
						"amendAccountHomeMsg"),
				this.getString("amend_acc_card_validation_msg")) {
			private static final long serialVersionUID = 1L;

			protected Component createContent(String id) {
				if (getDefaultModelObject() == null) {
					return null;
				} else {
					return AmendAccountsHomePanel.this.msgDisplayPanel = new MessageDisplayPanel(
							AmendAccountsHomePanel.this,
							AmendAccountsHomePanel.this.msgModelWindow,
							new PropertyModel<Message>(
									AmendAccountsHomePanel.this,
									"amendAccountHomeMsg"), id);
				}
			}
		};
		this.msgModelWindow.setInitialHeight(150);
		this.msgModelWindow.setInitialWidth(400);
		this.msgModelWindow
				.setWindowClosedCallback(new ModalWindow.WindowClosedCallback() {
					private static final long serialVersionUID = 1L;

					public void onClose(AjaxRequestTarget target) {

					}
				});

		parent.add(this.msgModelWindow);
	}

	// validate Card Details
	private void goSearchCardDetails(AjaxRequestTarget target) {
		try {
			PanCryptor panCryptor = BasicPanCryptor.getInstance();
			cardNumber = panCryptor.encryptPan(cardNumber);
			this.card = customerService.getLinkedAccountsForCard(
					this.cardNumber, this.institution.getRealId());
			if(this.card!=null&&this.card.getExpiresOn()!=null){
				Calendar expiryCalendar = Calendar.getInstance();
				expiryCalendar.setTimeInMillis(card.getExpiresOn().getTime());
				Calendar curCalendar = Calendar.getInstance();
				curCalendar.setTime(new Date());
				if (expiryCalendar.before(curCalendar)) {
					this.refreshModelWindow(target, this.getString(CARD_EXPIRED));
					logger.debug(this.getString(CARD_EXPIRED));
					return;
				}
			}
			if (this.card.getAccountHolder().getCustomerCode()
					.equalsIgnoreCase(DUMMY_CUST_CODE)) {
				this.refreshModelWindow(target, this.getString(CARD_NOT_ISSUED));
				logger.debug(this.getString(CARD_NOT_ISSUED));
				return;
			}

			if (!this.card.getCardStatus().getStatusCode().equalsIgnoreCase(CARD_STATUS_NORMAL)) {
				this.refreshModelWindow(target,
						this.getString(INVALID_CARD_STATUS));
				logger.debug(this.getString(INVALID_CARD_STATUS));
				return;
			}
			AmendAccountsHomePanel.this.additionalAccountsContextSummary = new AdditionalAccountsContextSummary(
					this.institution, this.card,null);
			AmendAccountsHomePanel.this
					.complete(new AmendAccountsMainPanel.GoCardSearchResult(
							additionalAccountsContextSummary, target));
		} catch (serverException exp) {
			logger.debug(exp.getMessage());
			this.refreshModelWindow(target, this.getString(ENCRYPTION_FAILED));
		} catch (CardNotFoundException exp) {
			logger.debug(exp.getMessage());
			this.refreshModelWindow(target, this.getString("card_not_found"));
		} catch (GeneralSqlException exp) {
			logger.debug(exp.getMessage());
			this.refreshModelWindow(target, this.getString(exp.getMessage()));
		}
	}

	private boolean isEmpty(String str) {
		return (str == null||str.trim().equals(""))?true:false;
	}

	private void refreshModelWindow(AjaxRequestTarget target, String msg) {
		this.msgDisplayPanel.setDisplayMessage(msg);
		this.msgModelWindow.refreshContent();
		this.msgModelWindow.show(target);
	}

}
