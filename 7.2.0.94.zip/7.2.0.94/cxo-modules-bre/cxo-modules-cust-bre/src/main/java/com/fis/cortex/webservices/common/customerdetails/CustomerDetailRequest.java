package com.fis.cortex.webservices.common.customerdetails;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/customerDetailRequest", name = "CustomerDetailRequest")
@XmlAccessorType(XmlAccessType.FIELD)
public class CustomerDetailRequest {
	
	@XmlElement(required = true, name = "InstCode", namespace = "http://crdbase.cortex.fis.com/customerDetailRequest")
	private String institutionCode;
	
	@XmlElement(required = true, name = "CustCode", namespace = "http://crdbase.cortex.fis.com/customerDetailRequest")
	private String customerCode;

	public CustomerDetailRequest() {
	}

	public CustomerDetailRequest(String institutionCode, String customerCode) {
		this.institutionCode = institutionCode;
		this.customerCode = customerCode;
	}

	public String getInstitutionCode() {
		return institutionCode;
	}

	public void setInstitutionCode(String institutionCode) {
		this.institutionCode = institutionCode;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	
}
