package com.fis.cortex.access.custid.view;
import com.fis.cortex.transport.core.dataholder.TransportObject;
import com.metavante.cortex.transport.objects.core.Institution;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/view/AdditionalCardsContextSummary.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class AdditionalCardsContextSummary  extends TransportObject implements Cloneable {	
	
	private static final long serialVersionUID = 1L;
	private Institution institution;
	private String pan;
	private Card primaryCard;
	private Card additionalCard;
	
	
	public AdditionalCardsContextSummary(Institution institution,Card primaryCard){		
		this.institution = institution;
		this.primaryCard = primaryCard;
	}
	public Institution getInstitution() {
		return institution;
	}
	public void setInstitution(Institution institution) {
		this.institution = institution;
	}
	public Card getPrimaryCard() {
		return primaryCard;
	}
	public void setPrimaryCard(Card primaryCard) {
		this.primaryCard = primaryCard;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public Card getAdditionalCard() {
		return additionalCard;
	}
	public void setAdditionalCard(Card additionalCard) {
		this.additionalCard = additionalCard;
	}

}
