package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "Answer")
@XmlAccessorType(XmlAccessType.FIELD)
public class Answer {
	
	@XmlElement(name = "CheckName", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String checkName;
	@XmlElement(name = "Value", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String value;
	
	public String getCheckName() {
		return checkName;
	}
	public void setCheckName(String checkName) {
		this.checkName = checkName;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}

}
