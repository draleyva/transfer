package com.fis.cortex.webservices.common.card;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "SecurityVerification")
@XmlAccessorType(XmlAccessType.FIELD)
public class SecurityVerification 
{
	@XmlElementWrapper( name = "SecurityAnswers", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	@XmlElement(name = "Answer", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private List<Answer> securityAnswersList;

	public List<Answer> getSecurityAnswersList() {
		return securityAnswersList;
	}

	public void setSecurityAnswersList(List<Answer> securityAnswersList) {
		this.securityAnswersList = securityAnswersList;
	}


}
