package com.fis.cortex.webservices.common.card.response;

import javax.xml.bind.annotation.XmlElement;

public class AbstractResponse {

	private ResponseHeader rspHdr;

	@XmlElement(required = true, name = "RspHdr", namespace = "http://wscore.cortex.fis.com/ctxCommonRspHdr")
	public ResponseHeader getRspHdr() {
		return rspHdr;
	}

	public void setRspHdr(ResponseHeader rspHdr) {
		this.rspHdr = rspHdr;
	}

}
