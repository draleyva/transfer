package com.fis.cortex.access.custid.converter;


import com.fis.cortex.access.custid.view.AccountType;
import com.fis.cortex.transport.core.converter.EntityTransportConverter;
import com.fis.cortex.transport.core.dataholder.TransportObject.Id;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/converter/AccountTypeConverter.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class AccountTypeConverter extends EntityTransportConverter<com.nomadsoft.cortex.domain.account.AccountType, AccountType>{
	

	
	public AccountType convertRealToTransport(com.nomadsoft.cortex.domain.account.AccountType acountType){
		AccountType  acntType =  new AccountType();		
		acntType.setISOCode(acountType.getISOCode());
		acntType.setInstId(acountType.getId().getInstId());
		acntType.setTypeCode(acountType.getId().getAccountType());
		acntType.setDescription(acountType.getDescription());
		acntType.setBankAccCode(acountType.getBankAccCode());		
		return acntType;
		
	}
	
	public com.nomadsoft.cortex.domain.account.AccountType findReal(Id accountId, Integer version) {
		return null;
	}
	
	protected void updateRealFromTransport(com.nomadsoft.cortex.domain.account.AccountType acc, AccountType account){
			
	}
	

}
