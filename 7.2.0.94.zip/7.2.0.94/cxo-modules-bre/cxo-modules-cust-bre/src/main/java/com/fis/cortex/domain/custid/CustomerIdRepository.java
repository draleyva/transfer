package com.fis.cortex.domain.custid;

import java.util.List;
import java.util.Map;



import com.nomadsoft.cortex.domain.branch.Branch;
import com.nomadsoft.cortex.domain.card.CardAccount;
import com.nomadsoft.cortex.domain.card.Card;
import com.nomadsoft.cortex.domain.card.CardProduct;
import com.nomadsoft.cortex.domain.cardbatch.CardBatch;
import com.nomadsoft.cortex.domain.cardbatch.CardBatchPriority;
import com.nomadsoft.cortex.domain.cardbatch.CardBatchStatus;
import com.nomadsoft.cortex.domain.institution.Institution;
import com.nomadsoft.cortex.domain.msc.Msc;
import com.nomadsoft.cortex.domain.accountholder.AccountHolder;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/domain/custid/CustomerIdRepository.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public interface CustomerIdRepository {
	
	List<CustIdType>  getIdTypes(String institutionCode);
	CustIdCode findCustIdCodeById(String cutIdCode);
	CustIdCode getCustIdCode(long custIdTypeId,String custIdCode);
	CustIdCode getCustIdCodeByCust(long customerId);
	AccountHolder getAccountHolderById(long id);
	Card getCard(String cardNumber,long instId) throws Exception;
	void deleteCardAccount(CardAccount cardAccount);
	Object findById(long id, String className, String[] dependencies);
	Object findAtMostOne(String className, Map<String, Object> values);
	void save(Object object,String className);
	void update(Object object,String className);	
	CardBatch findByInstcodeBatchtypeCrdproductstatusandDelvaddr(Institution institution, int batchType,
			CardProduct cardProduct,CardBatchStatus batchStatus,char deliveryAddress, CardBatchPriority cardBatchPriority);
	Msc findByTagAndIndex(String tag,short  index);
	BranchCardBatch getBranchCardBatch(String branchCode,Institution institution, int batchType,
			CardProduct cardProduct,CardBatchStatus batchStatus,char deliveryAddress, CardBatchPriority cardBatchPriority);
    List<Branch> getBranchesByInstitution(Institution institution);

	
	
}