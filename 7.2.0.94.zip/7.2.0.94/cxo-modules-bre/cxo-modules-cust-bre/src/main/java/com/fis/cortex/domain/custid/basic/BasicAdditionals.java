package com.fis.cortex.domain.custid.basic;

import java.io.Serializable;

import com.fis.cortex.domain.custid.Additionals;
import com.fis.cortex.domain.custid.AdditionalsId;
/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/domain/custid/basic/BasicAdditionals.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class BasicAdditionals implements Additionals, Serializable {	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int versionNumber;
	private int additionalsno;
	private AdditionalsId id;
	
	public int getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}
	public int getAdditionalsno() {
		return additionalsno;
	}
	public void setAdditionalsno(int additionalsno) {
		this.additionalsno = additionalsno;
	}
	public AdditionalsId getId() {
		return this.id;
	}
	public void setId(AdditionalsId id) {
		this.id =id;
	}

}
