package com.metavante.cortexonline.wicket.content.cust;

public class CustTable {
	
	private long id;
	private String custField;

	public String getCustField() {
		return custField;
	}

	public void setCustField(String custField) {
		this.custField = custField;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	

}
