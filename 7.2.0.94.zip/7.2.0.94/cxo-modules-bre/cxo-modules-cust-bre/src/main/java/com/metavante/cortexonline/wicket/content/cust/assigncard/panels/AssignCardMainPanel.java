/**
 * <hr>
 * <h4>Copyright Metavante Technologies Ltd.</h4>
 */
package com.metavante.cortexonline.wicket.content.cust.assigncard.panels;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.wicket.spring.injection.annot.SpringBean;

import com.fis.cortex.access.custid.view.Card;
import com.fis.cortex.access.custid.view.CustomerContextSummary;
import com.fis.cortex.transport.custid.services.CustomerService;
import com.metavante.cortex.transport.objects.core.Institution;
import com.metavante.cortexonline.wicket.BasePage.PageInfo;
import com.metavante.cortexonline.wicket.CortexRequestCycle;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowManager;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowResult;
import com.metavante.cortexonline.wicket.content.cust.additionalaccounts.panels.AmendAccountsPanel;
import com.metavante.cortexonline.wicket.content.cust.assigncard.panels.AssignCardHomePanel;
import com.metavante.cortexonline.wicket.content.rules.panels.AbstractMainPanel;
import com.metavante.cortexonline.wicket.metadata.AcsInfo;

/**
 * Assign Card main workflow panel.
 * 
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/assigncard/panels/AssignCardMainPanel.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
@AcsInfo(acsItem = "agn_crd_main")
public class AssignCardMainPanel extends AbstractMainPanel {
	private static Log logger = LogFactory.getLog(AssignCardMainPanel.class);

	private static final long serialVersionUID = 1L;

	private static final int STATE_FAILURE = -1;
	private static final int STATE_START = 0;
	private static final int STATE_AFTERHOME = 1;
	
	@SpringBean(name = "transportCustomerIdService")
	private CustomerService customerService;
	

	
	public static class GoSearchCustomerResult extends WorkFlowResult {
		private static final long serialVersionUID = 1L;
		CustomerContextSummary customerContextSummary;
		public GoSearchCustomerResult(CustomerContextSummary contextSummary) {
			super(Status.REDIRECT);
            this.customerContextSummary =contextSummary;
		}
	}	
	
	public static class GoSearchCriteriaPanel extends WorkFlowResult {
		private static final long serialVersionUID = 1L;
		CustomerContextSummary customerContextSummary;
		public GoSearchCriteriaPanel(CustomerContextSummary contextSummary) {
			super(Status.REDIRECT);
			this.customerContextSummary =contextSummary;
		}
	}
	
	public static class GoGenerateCard extends WorkFlowResult {
		private static final long serialVersionUID = 1L;
		CustomerContextSummary customerContextSummary;
		public GoGenerateCard(CustomerContextSummary contextSummary) {
			super(Status.REDIRECT); 
			this.customerContextSummary =contextSummary;
		}
	}	
	
	public static class GoDisplayCard extends WorkFlowResult {
		private static final long serialVersionUID = 1L;
		Card displayDetailsCard;
		public GoDisplayCard(Card card) {
			super(Status.REDIRECT); 
			this.displayDetailsCard =card;
		}
	}	
	
	
	public static class GoAdditionalCards extends WorkFlowResult {
		private static final long serialVersionUID = 1L;
		CustomerContextSummary customerContextSummary;
		public GoAdditionalCards(CustomerContextSummary contextSummary) {
			super(Status.REDIRECT); 
			this.customerContextSummary =contextSummary;
		}
	}
	
	
	public static class GoInstitutionSelection extends WorkFlowResult {
		private static final long serialVersionUID = 1L;		
		public GoInstitutionSelection() {
			super(Status.REDIRECT); 
		}
	}	
	



	public AssignCardMainPanel(Institution institution) {
		super(institution);
		this.getPanel().setWorkFlow(this, STATE_START);
	}

	// workflow

	public void process(WorkFlowManager manager) {
		switch (manager.getState()) {
		case STATE_START:
			this.doHome(manager);
			break;	
		case STATE_AFTERHOME:
			WorkFlowResult result = manager.getLastResult();
			if(result instanceof GoSearchCustomerResult){
			    this.getCustomerDetails(manager);
			}else if(result instanceof GoSearchCriteriaPanel){
				this.doHome(manager);
			}else if(result instanceof GoAdditionalCards){
				this.gotoAdditionalCard(manager);				
			}else if(result instanceof GoGenerateCard){
				this.showGenerateCard(manager);	
			}else if(result instanceof GoDisplayCard){
				this.displayCardDetails(manager);	
			}else if(result instanceof GoInstitutionSelection){
				this.doInstitutionSelection(manager);	
			}else{
				this.getCustomerDetails(manager);
			}
				
			break;		
		default:
			manager.terminate();
			this.setResponsePage(com.metavante.cortexonline.wicket.HomePage.class);
			break;
		}
	}

	@Override
	public PageInfo getPageInfo() {
		PageInfo pageInfo = super.getPageInfo();
		pageInfo.addTitle("Institution: " + this.institution.getCode());
		return pageInfo;
	}

	private void doHome(WorkFlowManager manager) {
		CustomerContextSummary contextSummary = new CustomerContextSummary(this.institution,null,null);
		manager.setPanel(new AssignCardHomePanel(contextSummary), STATE_FAILURE, STATE_FAILURE, STATE_FAILURE,
				STATE_AFTERHOME, true);
	}
	private void gotoAdditionalCard(WorkFlowManager manager) {		
		manager.terminate();
		try{
		   String url =null;
		   GoAdditionalCards result = (GoAdditionalCards) manager.getLastResult();
		   CustomerContextSummary contextSummary=result.customerContextSummary;		  
		   String contextPath = (String)CortexRequestCycle.get().getWebRequest().getHttpServletRequest().getContextPath();
		   if(contextSummary!=null){
               url = contextPath+"/wicket/customer/addadditionalcards?inst_id="+contextSummary.getInstitution().getRealId()+"&pan="+contextSummary.getPan();
		   }else{
			   url = contextPath+"/wicket/customer/addadditionalcards";  
		   }
           CortexRequestCycle.get().getWebResponse().getHttpServletResponse().sendRedirect(url);
		}catch(Exception exp){
			
		}
	}
	private void getCustomerDetails(WorkFlowManager manager) {
		GoSearchCustomerResult result = (GoSearchCustomerResult) manager.getLastResult();		
		manager.setPanel(new CustomerDetailsPanel(result.customerContextSummary), STATE_FAILURE, STATE_FAILURE, STATE_FAILURE,
				STATE_AFTERHOME, true);
	}
	
	private void showGenerateCard(WorkFlowManager manager) {
		GoGenerateCard result = (GoGenerateCard) manager.getLastResult();
		manager.setPanel(new GenerateCardPanel(result.customerContextSummary), STATE_FAILURE, STATE_FAILURE, STATE_FAILURE,
				STATE_AFTERHOME, true);
	}	
	
	private void displayCardDetails(WorkFlowManager manager) {
		GoDisplayCard result = (GoDisplayCard) manager.getLastResult();
		manager.setPanel(new DisplayCardDetailsPanel(result.displayDetailsCard), STATE_FAILURE, STATE_FAILURE, STATE_FAILURE,
				STATE_AFTERHOME, true);
	}	
	
	private void doInstitutionSelection(WorkFlowManager manager) {
		manager.terminate();
		try
		{
			 StringBuilder stringBuilder=new StringBuilder();
			 stringBuilder.append((String)CortexRequestCycle.get().getWebRequest().getHttpServletRequest().getContextPath());
			 stringBuilder.append("/wicket/customer/assigncard");		  
	         CortexRequestCycle.get().getWebResponse().getHttpServletResponse().sendRedirect(stringBuilder.toString());
		}catch(Exception exp){
			logger.error(exp.getMessage());
        }
	}	
	
	
	
	
	
}
