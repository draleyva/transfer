package com.fis.cortex.domain.custid.basic;

import java.io.Serializable;
import java.util.Date;

import com.fis.cortex.domain.custid.ChargeData;
import com.nomadsoft.cortex.domain.card.Card;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/domain/custid/basic/BasicChargeData.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class BasicChargeData implements ChargeData,Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private int versionNumber;
	private Card card;
	private Date transactionDate;
	private long chargeType;
	private String chargeCurrency;
	private String chargeData;	
	private long customerType;
	private String opdata;
	private String processed;

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	public int getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}
	public Card getCard() {
		return card;
	}
	public void setCard(Card card) {
		this.card = card;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public long getChargeType() {
		return chargeType;
	}
	public void setChargeType(long chargeType) {
		this.chargeType = chargeType;
	}
	public String getChargeCurrency() {
		return chargeCurrency;
	}
	public void setChargeCurrency(String chargeCurrency) {
		this.chargeCurrency = chargeCurrency;
	}
	public long getCustomerType() {
		return customerType;
	}
	public void setCustomerType(long customerType) {
		this.customerType = customerType;
	}
	public String getOpdata() {
		return opdata;
	}
	public void setOpdata(String opdata) {
		this.opdata = opdata;
	}
	public String getProcessed() {
		return processed;
	}
	public void setProcessed(String processed) {
		this.processed = processed;
	}
	
	public String getChargeData() {
		return chargeData;
	}
	public void setChargeData(String chargeData) {
		this.chargeData = chargeData;
	}
	
	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((card == null) ? 0 : card.hashCode());
		result = prime * result
				+ ((chargeCurrency == null) ? 0 : chargeCurrency.hashCode());
		result = prime * result
				+ ((chargeData == null) ? 0 : chargeData.hashCode());
		result = prime * result + (int) (chargeType ^ (chargeType >>> 32));
		result = prime * result + (int) (customerType ^ (customerType >>> 32));
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + ((opdata == null) ? 0 : opdata.hashCode());
		result = prime * result
				+ ((processed == null) ? 0 : processed.hashCode());
		result = prime * result
				+ ((transactionDate == null) ? 0 : transactionDate.hashCode());
		return result;
	}
	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BasicChargeData other = (BasicChargeData) obj;
		if (card == null) {
			if (other.card != null)
				return false;
		} else if (!card.equals(other.card))
			return false;
		if (chargeCurrency == null) {
			if (other.chargeCurrency != null)
				return false;
		} else if (!chargeCurrency.equals(other.chargeCurrency))
			return false;
		if (chargeData == null) {
			if (other.chargeData != null)
				return false;
		} else if (!chargeData.equals(other.chargeData))
			return false;
		if (chargeType != other.chargeType)
			return false;
		if (customerType != other.customerType)
			return false;
		if (id != other.id)
			return false;
		if (opdata == null) {
			if (other.opdata != null)
				return false;
		} else if (!opdata.equals(other.opdata))
			return false;
		if (processed == null) {
			if (other.processed != null)
				return false;
		} else if (!processed.equals(other.processed))
			return false;
		if (transactionDate == null) {
			if (other.transactionDate != null)
				return false;
		} else if (!transactionDate.equals(other.transactionDate))
			return false;
		return true;
	}
	

}
