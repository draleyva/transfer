package com.fis.cortex.domain.custid;

import com.nomadsoft.cortex.domain.institution.Institution;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/domain/custid/CustIdType.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public interface CustIdType {
	
	long getId();

    void setId(long id);

    int getVersionNumber();

    void setVersionNumber(int versionNumber);

    Institution getInstitution();

    void setInstitution(Institution institution);

    String getCode();

    void setCode(String code);

    String getDescription();

    void setDescription(String description);
    
   
}
