package com.fis.cortex.access.custid.converter;

import com.metavante.cortex.transport.objects.common.Branch;
import com.metavante.cortex.transport.objects.converter.BranchConvertor;

public class CustomBranchConvertor extends BranchConvertor{
	
	public Branch convertRealToTransport(
			com.nomadsoft.cortex.domain.branch.Branch realBranch) {
		Branch branch = super.convertRealToTransport(realBranch);
	    branch.setBranchId(realBranch.getId());		
		return branch;
	}

}
