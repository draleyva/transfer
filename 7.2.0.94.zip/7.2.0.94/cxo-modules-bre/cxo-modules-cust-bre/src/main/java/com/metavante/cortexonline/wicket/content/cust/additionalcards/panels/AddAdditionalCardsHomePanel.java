package com.metavante.cortexonline.wicket.content.cust.additionalcards.panels;

import java.util.Calendar;
import java.util.Date;

import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.model.CompoundPropertyModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.spring.injection.annot.SpringBean;
import com.cortex.common.exception.serverException;
import com.cortex.gui.common.lib.BasicPanCryptor;
import com.cortex.gui.common.lib.PanCryptor;
import com.fis.cortex.access.custid.view.AccountHolder;
import com.fis.cortex.access.custid.view.AdditionalCardsContextSummary;
import com.fis.cortex.access.custid.view.Card;
import com.fis.cortex.access.custid.view.CardProduct;
import com.fis.cortex.access.custid.view.CardStatus;
import com.fis.cortex.transport.custid.exception.CardNotFoundException;
import com.fis.cortex.transport.custid.services.CustomerService;
import com.metavante.cortex.transport.objects.core.Institution;
import com.metavante.cortexonline.wicket.components.ContextPanel;
import com.metavante.cortexonline.wicket.components.buttonbox.BoxedSubmitButton;
import com.metavante.cortexonline.wicket.components.buttonbox.ButtonBox;
import com.metavante.cortexonline.wicket.components.componentline.TextFieldLine;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowPanel;
import com.metavante.cortexonline.wicket.content.cust.additionalcards.panels.AddAdditionalCardsMainPanel;
import com.metavante.cortexonline.wicket.metadata.AcsInfo;


@AcsInfo(acsItem = "addin_crd_home")
public class AddAdditionalCardsHomePanel extends WorkFlowPanel {
	
    private static final long serialVersionUID = 1L;
    private static final String DUMMY_CUST_CODE="99999999";
    private static final String CARD_STATUS_CODE="02";	
	private String primaryPan;
	private Card primaryCard;	
	private ButtonBox buttons;	
	@SpringBean(name = "transportCustomerIdService")
	private CustomerService customerService;	
	private AdditionalCardsContextSummary additionalCardsContextSummary;
	private String pan;
	private TextFieldLine<String> tlf;

	// data
	protected Institution institution;
	
	

	

	

	// construction	
	public AddAdditionalCardsHomePanel(AdditionalCardsContextSummary additionalCardsContextSummary) {
		this.setDefaultModel(new CompoundPropertyModel<AddAdditionalCardsHomePanel>(this));
		this.institution = additionalCardsContextSummary.getInstitution();
		if(additionalCardsContextSummary.getPrimaryCard()!=null){
			this.primaryCard=additionalCardsContextSummary.getPrimaryCard();
		}
			
		Form<Void> form = new Form<Void>("form") {
			private static final long serialVersionUID = 1L;
			@Override
			protected void onSubmit() {
				AddAdditionalCardsHomePanel.this.goSearchPrimaryCardDetails();
			}
		};
		this.add(form);
		this.addContext(this);
		this.addControls(form,true);
		this.addButtons(form);
    }
	
	public AddAdditionalCardsHomePanel(AdditionalCardsContextSummary additionalCardsContextSummary,String pan) {
		this.pan=pan;
		this.setDefaultModel(new CompoundPropertyModel<AddAdditionalCardsHomePanel>(this));
		this.institution = additionalCardsContextSummary.getInstitution();
		if(additionalCardsContextSummary.getPrimaryCard()!=null){
			this.primaryCard=additionalCardsContextSummary.getPrimaryCard();
			
		}	
		this.primaryPan=pan;
		Form<Void> form = new Form<Void>("form") {
			private static final long serialVersionUID = 1L;
			@Override
			protected void onSubmit() {
				AddAdditionalCardsHomePanel.this.goSearchPrimaryCardDetails();
			}
		};
		this.add(form);
		this.addContext(this);
		this.addControls(form,false);
		this.addButtons(form);
		
		
    }
	

	protected void addContext(WebMarkupContainer parent) {
		parent.add(new ContextPanel("context").addInstitution(this.institution));
	}
	
	private void addControls(WebMarkupContainer parent,boolean isEnabled) {	
		PropertyModel<String> model=new PropertyModel<String>(this,"primaryPan");
		parent.add(this.tlf =new TextFieldLine<String>("primaryCardNum",this.getString("additional_card_prim_card"),model));
		this.tlf .setMaxLength(32);
		this.tlf.setMandatory(true);
		this.tlf.setEnabled(isEnabled);
		if(this.pan!=null)
		{
		  model.setObject(this.pan);
		}
	}

	
    protected void addButtons(WebMarkupContainer parent) {		
    	this.buttons = new ButtonBox("buttons");
		this.buttons.addButton(new BoxedSubmitButton(new Model<String>(this.getString("additional_card_search_btn"))));
	    parent.add(this.buttons);
		
	}

	// actions

	protected void goSearchPrimaryCardDetails() { 
	    String cardNumber=new PropertyModel<String>(AddAdditionalCardsHomePanel.this,"primaryPan").getObject(); 
		try
		{
		     PanCryptor panCryptor =BasicPanCryptor.getInstance();
			 cardNumber =panCryptor.encryptPan(cardNumber);
			 this.primaryCard =customerService.getCard(cardNumber,this.institution.getRealId());
			 if(validatePrimaryCard(this.primaryCard)){
		       AddAdditionalCardsHomePanel.this.additionalCardsContextSummary = new AdditionalCardsContextSummary(this.institution,this.primaryCard);
		       AddAdditionalCardsHomePanel.this.complete(new AddAdditionalCardsMainPanel.GoPrimaryCardSearchResult(AddAdditionalCardsHomePanel.this.additionalCardsContextSummary));
			 }
		     
		}catch(serverException e){
			this.error(this.getString("agn_card_encryption_failed"));		
		}catch(CardNotFoundException exp){
			this.error(this.getString("card_not_found"));
		}
	}
	
	private boolean validatePrimaryCard(Card card) {
		boolean isValidCard = true;
		if (card != null && card.getAccountHolder() != null
				&& card.getExpiresOn() != null) {
			AccountHolder accountHolder = card.getAccountHolder();
			CardStatus cardStatus = card.getCardStatus();
			Date expiryDate = card.getExpiresOn();
			Calendar expiryCalendar = Calendar.getInstance();
			expiryCalendar.setTimeInMillis(expiryDate.getTime());
			Calendar curCalendar = Calendar.getInstance();
			curCalendar.setTime(new Date());
			if (expiryCalendar.before(curCalendar)) {
				this.error(this
						.getString("additional_card_primary_card_expired"));
				isValidCard = false;
			} else if (card.getAdditionalNumber() != 0) {
				this.error(this.getString("additional_card_not_a_primary_card"));
				isValidCard = false;
			} else if (cardStatus.isCancelled()) {
				this.error(this.getString("additional_card_status_not_valid"));
				isValidCard = false;
			} else if (DUMMY_CUST_CODE.equalsIgnoreCase(accountHolder
					.getCustomerCode())) {
				this.error(this
						.getString("additional_card_primary_card_not_issued"));
				isValidCard = false;
			}
		} else {
			this.error(this.getString("card_not_found"));
			isValidCard = false;
		}
		return isValidCard;
	}

}
