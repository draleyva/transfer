package com.metavante.cortexonline.wicket.content.cust.components;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.util.lang.PropertyResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fis.cortex.transport.core.dataholder.TransportObject;
import com.fis.cortex.wicket.base.CortexAjaxButton;
import com.metavante.cortex.transport.SearchTransport;
import com.metavante.cortexonline.wicket.Application;
import com.metavante.cortexonline.wicket.components.buttonbox.ButtonBox;
import com.metavante.cortexonline.wicket.components.searcher.AjaxSearcher;
import com.metavante.cortexonline.wicket.components.searcher.CriteriaPanel;

/**
 * This Panel is used to display the Search button and Search results
 * 
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/components/CustomizedAjaxSearcher.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public abstract class CustomizedAjaxSearcher<T extends TransportObject> extends Panel {

	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unused")
	private static final Logger LOG = LoggerFactory
			.getLogger(CustomizedAjaxSearcher.class);

	public static class ColumnConfiguration<T extends TransportObject> {

		private List<Column<T>> columns = new ArrayList<Column<T>>();

		public ColumnConfiguration<T> addColumn(String title, String property) {
			Column<T> column = new Column<T>(title, new PropertyConverter<T>(
					property));
			this.columns.add(column);
			return this;
		}

		public ColumnConfiguration<T> addColumn(String title,
				Converter<T> converter) {
			Column<T> column = new Column<T>(title, converter);
			this.columns.add(column);
			return this;
		}

		public List<Column<T>> getColumns() {
			return columns;
		}
	}

	/**
	 * Turns some object into some text value. T should be the same T as the
	 * {@link AjaxSearcher} you want to use it with.
	 * 
	 * @author sgilhor
	 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/components/CustomizedAjaxSearcher.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
	 */
	public static abstract class Converter<T extends TransportObject>
			implements Serializable {

		private static final long serialVersionUID = 1L;

		public abstract IModel<?> getModel(T object);
	}

	/**
	 * Gets a property of the object, and return its toString.
	 * 
	 * @author sgilhor
	 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/components/CustomizedAjaxSearcher.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
	 */
	public static class PropertyConverter<T extends TransportObject> extends
			Converter<T> {

		private static final long serialVersionUID = 1L;

		private String property;

		public PropertyConverter(String property) {
			this.property = property;
		}

		@Override
		public IModel<?> getModel(T object) {
			return new PropertyModel<String>(object, this.property);
		}
	}

	/**
	 * Gets a property of a date object, and return its toString.
	 * 
	 * @author sgilhor
	 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/components/CustomizedAjaxSearcher.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
	 */
	public static class DateConverter<T extends TransportObject> extends
			Converter<T> {

		private static final long serialVersionUID = 1L;

		private String property;
		private Locale locale;

		public DateConverter(String property, Locale locale) {
			this.property = property;
			this.locale = locale;
		}

		@Override
		public IModel<?> getModel(T object) {
			return new PropertyModel<String>(object, this.property) {

				private static final long serialVersionUID = 1L;

				@Override
				public String getObject() {

					final String expression = super.propertyExpression();
					final Object target = super.getTarget();
					if (target != null) {
						Date dateValue = (Date) PropertyResolver.getValue(
								expression, target);
						if (locale == null) {
							locale = Locale.getDefault();
						}
						SimpleDateFormat dateFormat = new SimpleDateFormat(
								"dd/MM/yyyy", locale);
						return dateFormat.format(dateValue);
					}
					return super.getObject();
				}
			};
		}
	}

	/**
	 * A column in a result table, has a title, and has a converter that can
	 * turn a result object into the correct text to display under that title. T
	 * should be the same T as the {@link AjaxSearcher} you want to use it with.
	 * 
	 * @author sgilhor
	 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/components/CustomizedAjaxSearcher.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
	 */
	public static class Column<T extends TransportObject> implements
			Serializable {

		private static final long serialVersionUID = 1L;

		private String title;
		private Converter<T> converter;

		public Column(String title, Converter<T> converter) {
			this.title = title;
			this.converter = converter;
		}

		public String getTitle() {
			return this.title;
		}

		public Converter<T> getConverter() {
			return this.converter;
		}
	}

	// business data

	private List<Column<T>> columns;
	private SearchTransport<T> transport;

	// Wicket data

	private Form<T> form;
	private CriteriaPanel criteriaPanel;
	private Map<String, Object> searchValues;
	private ButtonBox buttons;

	private ButtonBox buttonsLeft;
	CustomizedAjaxResultPanel<T> comp;


	// construction

	/**
	 * @param model
	 */
	public CustomizedAjaxSearcher(String id, IModel<T> model, List<Column<T>> columns) {
		super(id, model);

		this.columns = columns;

		this.add(this.form = new Form<T>("form") {
			private static final long serialVersionUID = 1L;

			@Override
			protected void onSubmit() {
				CustomizedAjaxSearcher.this.transport = null;
				CustomizedAjaxSearcher.this.onSubmit();
			}

			@Override
			protected void onError() {
				CustomizedAjaxSearcher.this.transport = null;
				
			}
		});

		this.setOutputMarkupId(true);
		this.setOutputMarkupPlaceholderTag(true);

		this.add(this.form);
		this.addButtonsLeft(this.form);
		this.addAjaxButton(this.form);
		comp = new CustomizedAjaxResultPanel<T>("results", CustomizedAjaxSearcher.this);
		comp.setOutputMarkupId(true);
		comp.setOutputMarkupPlaceholderTag(true);
		this.add(comp);
	

	}

	private void addButtonsLeft(WebMarkupContainer parent) {
		this.buttonsLeft = new ButtonBox("buttonsLeft");
		parent.add(this.buttonsLeft);
	}

	private void addAjaxButton(WebMarkupContainer parent) {

		this.buttons = new ButtonBox("buttons");
		this.buttons.addButton(new CortexAjaxButton("button",
				new Model<String>(this.getString("find_account")),
				CustomizedAjaxSearcher.this.form) {
			private static final long serialVersionUID = 1L;

			@Override
			protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
				target.addComponent(CustomizedAjaxSearcher.this);
				target.addComponent(CustomizedAjaxSearcher.this.comp);
			}
			
			protected void onError(AjaxRequestTarget target, Form<?> form) {
				target.appendJavascript("alert('"+this.getString("amend_acc_account_empty")+"')");
			}
		});
		this.buttons.addButton(new CortexAjaxButton("button",
				new Model<String>(this.getString("assign_card_cancel")),
				CustomizedAjaxSearcher.this.form) {
			private static final long serialVersionUID = 1L;
			@Override
			protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
				CustomizedAjaxSearcher.this.onCancel(target);
				
			}
			
		}.setDefaultFormProcessing(false));
		
		parent.add(this.buttons);

	}

	// internal methods

	protected void onSubmit() {
		SearchTransport<T> transport = new SearchTransport<T>(this.searchValues);
		transport.setPageSize(Application.get().getConfiguration()
				.getSearchResultsPerPage());
		this.transport = this.search(transport);
	}

	// setup methods

	public final void setCriteriaPanel(CriteriaPanel criteriaPanel) {
		this.criteriaPanel = criteriaPanel;
		this.criteriaPanel.configure(new PropertyModel<Map<String, Object>>(
				this, "searchValues"));
		this.form.add(this.criteriaPanel);
	}

	/**
	 * Add another button to the left {@link ButtonBox} contained in this
	 * {@link AjaxSearcher}.
	 * 
	 * @param button
	 */
	public void addButtonLeft(Button button) {
		this.buttonsLeft.addButton(button);
	}

	/**
	 * Run the search on demand. This should only ever be called when you know
	 * that the searcher is ready configured with its search criteria.
	 */
	public void refresh() {
		this.onSubmit();
	}

	// abstract methods

	/**
	 * Override this to do the actual search.
	 * 
	 * @param transport
	 * @return
	 */
	protected abstract SearchTransport<T> search(SearchTransport<T> transport);

	/**
	 * Override this to pick up the selection event.
	 * 
	 * @param item
	 */
	public abstract void onLinkCard(AjaxRequestTarget target);
	
	
	/**
	 * Override this to pick up the selection event.
	 * 
	 * @param item
	 */
	public abstract void onCancel(AjaxRequestTarget target);

	// results panel methods

	List<Column<T>> getColumns() {
		return this.columns;
	}

	SearchTransport<T> getTransport() {
		return this.transport;
	}

	void pageTo(int page) {
		this.transport.clearResults();
		this.transport.setPageNumber(page);
		this.transport = this.search(this.transport);
	}
}
