package com.fis.cortex.access.custid.view;

import com.fis.cortex.transport.core.dataholder.TransportObject;
import com.metavante.cortex.transport.objects.core.Institution;
import com.metavante.cortex.transport.objects.money.Currency;
import com.metavante.cortex.transport.objects.common.Branch;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/view/Account.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public class Account extends TransportObject {
	
	private static final long serialVersionUID = -5541759053337962763L;	
    private Institution institution;
    private String accountNumber;
    private Branch branch;
    private String accountType;
    private Short accountClass;
    private String status;
    private String catParams;	   
    private char vip;
    private Currency currency;
    private AccountHolder accountHolder;
    private String accountTypeDescription;
    private boolean selected=false;
    private boolean linked=false;
	   
	public boolean isLinked() {
		return linked;
	}
	public void setLinked(boolean linked) {
		this.linked = linked;
	}
	public boolean isSelected() {
		return selected;
	}
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	public String getAccountTypeDescription() {
		return accountTypeDescription;
	}
	public void setAccountTypeDescription(String accountTypeDescription) {
		this.accountTypeDescription = accountTypeDescription;
	}
	public AccountHolder getAccountHolder() {
		return accountHolder;
	}
	public void setAccountHolder(AccountHolder accountHolder) {
		this.accountHolder = accountHolder;
	}
	public Institution getInstitution() {
		return institution;
	}
	public void setInstitution(Institution institution) {
		this.institution = institution;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Branch getBranch() {
		return branch;
	}
	public void setBranch(Branch branch) {
		this.branch = branch;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public Short getAccountClass() {
		return accountClass;
	}
	public void setAccountClass(Short accountClass) {
		this.accountClass = accountClass;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}	
	public String getCatParams() {
		return catParams;
	}
	public void setCatParams(String catParams) {
		this.catParams = catParams;
	}
	public char getVip() {
		return vip;
	}
	public void setVip(char vip) {
		this.vip = vip;
	}
	public Currency getCurrency() {
		return currency;
	}
	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

}
