package com.fis.cortex.transport.custid.services;

import java.util.List;

import com.fis.cortex.access.custid.view.Account;
import com.fis.cortex.access.custid.view.AccountHolder;
import com.fis.cortex.access.custid.view.Card;
import com.fis.cortex.access.custid.view.CardProduct;
import com.fis.cortex.access.custid.view.CustIdCode;
import com.fis.cortex.access.custid.view.CustIdType;

import com.fis.cortex.transport.custid.exception.AdditionalsConstraintViolationException;
import com.fis.cortex.transport.custid.exception.CardAccountLinkingException;
import com.fis.cortex.transport.custid.exception.CardNotFoundException;
import com.fis.cortex.transport.custid.exception.CortexWebServiceException;
import com.fis.cortex.transport.custid.exception.CustomerIdTypeNotFoundException;
import com.fis.cortex.transport.custid.exception.CustomerNotFoundException;
import com.fis.cortex.transport.custid.exception.GeneralSqlException;
import com.metavante.cortex.transport.objects.common.Branch;
import com.metavante.cortex.transport.objects.core.Institution;

/**
 *
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/transport/custid/services/CustomerService.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 * 
 */

public interface CustomerService {
	List<CustIdType> getCustIdTypes(String institutionCode) throws CustomerIdTypeNotFoundException;	
	CustIdType convertCustIdType(com.fis.cortex.domain.custid.CustIdType type);
	CustIdCode getCustIdCode(long instId,long custIdTypeId,String custIdCode,String userName) throws CortexWebServiceException;
	void getAccounts(long instCode,long custId,long custTypeId,String custCodeId,String userName)throws CortexWebServiceException;
	AccountHolder getAccountHolder(long CustomerId) throws CustomerNotFoundException;
	com.nomadsoft.cortex.domain.account.Account getAdditionalAccounts(long instId,String accountNumber,String custIdCode,long custIdType,String user)throws CortexWebServiceException;
	Account getAccount(com.nomadsoft.cortex.domain.account.Account account);
	void saveAdditionalAccount(com.nomadsoft.cortex.domain.account.Account account); 
	Card getCard(String panNumber,long instId)throws CardNotFoundException;
	void deleteCardLink(Card card);
	void updateCard(Card cardTransport,Account accountTransport,long customerId);
	void updateLinkForAccounts(Card card,List<Account>accounts);
	long  getCustomerById(long custIdType,String custIdCode)throws CustomerNotFoundException;
	void  updateAdditionalCard(Card primaryCard,Card additionalCard) throws AdditionalsConstraintViolationException,GeneralSqlException;
	Institution getInstitution(String instId);
	Card getLinkedAccountsForCard(String panNumber,long instId)throws CardNotFoundException,GeneralSqlException;
	void updateCardAccountLinks(Card card,List<Account> linkAccounts) throws CardAccountLinkingException;
	void deleteCardAccountLinks(Card card,List<Account> linkAccounts) throws CardAccountLinkingException;
	CustIdCode convertCustIdCode(com.fis.cortex.domain.custid.CustIdCode code);
	CustIdCode getCustIdCodeByCustomer(long customerId);
	Card getGeneratedCard(Institution institution,String cardProduct,AccountHolder accountHolder,Account dlftAccount,Branch deliveryBranch,String username) throws CortexWebServiceException;
	void updateAccountHolder(AccountHolder accountHolder);
	List<Branch> getBranchesByInstitution(Institution institution);
}
