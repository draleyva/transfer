package com.fis.cortex.webservices.common.card;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "AppProData")
@XmlAccessorType(XmlAccessType.FIELD)
public class ApplicationProductionData {
 	@XmlElement(name = "AppType", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private String applicationType;
 	@XmlElement(name = "PAN", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private String pan;
 	@XmlElement(name = "SeqNo", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private int sequenceNumber;
 	@XmlElement(name = "CustomerName", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private String customerName;
 	@XmlElement(name = "Trk1", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private String trackOne;
 	
 	@XmlElement(name = "Trk1Disc", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private String trackOneDiscretionary;
 	
 	@XmlElement(name = "Tk2", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private String trackTwo;
 	@XmlElement(name = "Tk3", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private String trackThree;
	@XmlElement( name = "EffDate", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String effectDate;
	@XmlElement( name = "ExpDate", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String expirypDate;
	@XmlElement( name = "SvcCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String serviceCode;
	@XmlElement( name = "CVV2", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String cvv2;

	@XmlElement( name = "EmA1Data", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String embossingAreaOneData;
	@XmlElement( name = "EmA21Data", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String embossingAreaTwoLineOneData;
	@XmlElement( name = "EmA22Data", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String embossingAreaTwoLineTwoData;
	@XmlElement( name = "EmA23Data", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String embossingAreaTwoLineThreeData;
	@XmlElement( name = "EmA3Data", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String embossingAreaThree;

	@XmlElementWrapper( name = "AddAppDataLst", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	@XmlElement( name = "AppTag", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private List<ApplicationTag> applicationTag;
	
	public String getApplicationType() {
		return applicationType;
	}
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public int getSequenceNumber() {
		return sequenceNumber;
	}
	public void setSequenceNumber(int sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getTrackOne() {
		return trackOne;
	}
	public void setTrackOne(String trackOne) {
		this.trackOne = trackOne;
	}
	public String getTrackTwo() {
		return trackTwo;
	}
	public void setTrackTwo(String trackTwo) {
		this.trackTwo = trackTwo;
	}
	public String getTrackThree() {
		return trackThree;
	}
	public void setTrackThree(String trackThree) {
		this.trackThree = trackThree;
	}
	public String getEffectDate() {
		return effectDate;
	}
	public void setEffectDate(String effectDate) {
		this.effectDate = effectDate;
	}
	public String getExpirypDate() {
		return expirypDate;
	}
	public void setExpirypDate(String expirypDate) {
		this.expirypDate = expirypDate;
	}
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public String getCvv2() {
		return cvv2;
	}
	public void setCvv2(String cvv2) {
		this.cvv2 = cvv2;
	}
	public void setEmbossingAreaOneData(String embossingAreaOneData) {
		this.embossingAreaOneData = embossingAreaOneData;
	}
	public String getEmbossingAreaOneData() {
		return embossingAreaOneData;
	}
	public void setEmbossingAreaTwoLineOneData(
			String embossingAreaTwoLineOneData) {
		this.embossingAreaTwoLineOneData = embossingAreaTwoLineOneData;
	}
	public String getEmbossingAreaTwoLineOneData() {
		return embossingAreaTwoLineOneData;
	}
	public void setEmbossingAreaTwoLineTwoData(
			String embossingAreaTwoLineTwoData) {
		this.embossingAreaTwoLineTwoData = embossingAreaTwoLineTwoData;
	}
	public String getEmbossingAreaTwoLineTwoData() {
		return embossingAreaTwoLineTwoData;
	}
	public void setEmbossingAreaTwoLineThreeData(
			String embossingAreaTwoLineThreeData) {
		this.embossingAreaTwoLineThreeData = embossingAreaTwoLineThreeData;
	}
	public String getEmbossingAreaTwoLineThreeData() {
		return embossingAreaTwoLineThreeData;
	}
	public void setEmbossingAreaThree(String embossingAreaThree) {
		this.embossingAreaThree = embossingAreaThree;
	}
	public String getEmbossingAreaThree() {
		return embossingAreaThree;
	}
	public void setTrackOneDiscretionary(String trackOneDiscretionary) {
		this.trackOneDiscretionary = trackOneDiscretionary;
	}
	public String getTrackOneDiscretionary() {
		return trackOneDiscretionary;
	}
	public List<ApplicationTag> getApplicationTag() {
		return applicationTag;
	}
	public void setApplicationTag(List<ApplicationTag> applicationTag) {
		this.applicationTag = applicationTag;
	}
	
 }

