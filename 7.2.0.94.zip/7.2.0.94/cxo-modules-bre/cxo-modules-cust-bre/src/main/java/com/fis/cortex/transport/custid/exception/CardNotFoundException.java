package com.fis.cortex.transport.custid.exception;

import com.metavante.cortex.transport.exceptions.BusinessException;

/**
 * This class throws exceptio when Card not found
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/transport/custid/exception/CardNotFoundException.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class CardNotFoundException extends BusinessException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CardNotFoundException() {
		super();
		
	}

	public CardNotFoundException(String message) {
		super(message);
	
	}

}
