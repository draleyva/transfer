/**
 * <hr>
 * <h4>Copyright Metavante Technologies Ltd.</h4>
 */
package com.metavante.cortexonline.wicket.content.cust.additionalaccounts.panels;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.apache.wicket.AttributeModifier;
import org.apache.wicket.Component;
import org.apache.wicket.MarkupContainer;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.extensions.ajax.markup.html.modal.ModalWindow;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Check;
import org.apache.wicket.markup.html.form.CheckGroup;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.Radio;
import org.apache.wicket.markup.html.form.RadioGroup;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.transformer.NoopOutputTransformerContainer;
import org.apache.wicket.model.CompoundPropertyModel;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.model.util.CollectionModel;
import org.apache.wicket.spring.injection.annot.SpringBean;
import com.fis.cortex.access.custid.view.Account;
import com.fis.cortex.access.custid.view.AccountHolder;
import com.fis.cortex.access.custid.view.AdditionalAccountsContextSummary;
import com.fis.cortex.access.custid.view.Card;
import com.fis.cortex.access.custid.view.CardProduct;
import com.fis.cortex.access.custid.view.Message;
import com.fis.cortex.transport.custid.exception.CardAccountLinkingException;
import com.fis.cortex.transport.custid.exception.CardNotFoundException;
import com.fis.cortex.transport.custid.exception.GeneralSqlException;
import com.fis.cortex.transport.custid.services.CustomerService;
import com.fis.cortex.wicket.base.CortexAjaxButton;
import com.fis.cortex.wicket.base.CortexModalWindow;
import com.metavante.cortex.transport.objects.core.Institution;
import com.metavante.cortexonline.wicket.components.ContextPanel;
import com.metavante.cortexonline.wicket.components.buttonbox.BoxedSubmitButton;
import com.metavante.cortexonline.wicket.components.buttonbox.ButtonBox;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowPanel;
import com.metavante.cortexonline.wicket.content.cust.components.AdditionalAccountsZoomPanel;
import com.metavante.cortexonline.wicket.content.cust.components.MessageDisplayPanel;
import com.metavante.cortexonline.wicket.metadata.AcsInfo;

import com.cortex.common.startup.StartupXmlConfigData;
import com.cortex.cust.bre.common.constant.serverConstantBre;

import com.cortex.common.lib.debugLib;

import org.apache.wicket.behavior.AttributeAppender;

/**
 * Amend Accounts screen. This is the main screen from which user will
 * link/unlink(amend) accounts to the card
 * 
 * @author schinnas
 * @version
 * 
 */
@AcsInfo(acsItem = "amend_acc_det")
public class AmendAccountsPanel extends WorkFlowPanel {

	private static Log logger = LogFactory.getLog(AmendAccountsPanel.class);
	public static final String LINK = "amend_acc_link";
	public static final String UNLINK = "amend_acc_unlink";
	private static final long serialVersionUID = 1L;
	private static final String AMEND_CARD = "amend_acc_card_number";
	private static final String ACCOUNT_HOLDER_NAME = "amend_acc_crdholder_name";
	private static final String CARD_PRODUCT = "amend_acc_crd_product";
	private static final String PARENT_WEB_MARKUP_CONTAINER = "table_area";
	private static final String CHILD_WEB_MARKUP_CONTAINER = "table";
	private static final String COLSPAN = "colspan";
	private static final String ACCOUNT_LIST = "account_list";
	private static final String DEFAULT_ACCOUNT = "amend_acc_dlft";
	private static final String ACCOUNT_LINK = "amend_acc_link";
	private static final String ACCOUNT_CURRENCY = "amend_acc_currency";
	private static final String ACCOUNT_TYPE = "amend_acc_type";
	private static final String ACCOUNT_STATUS = "amend_acc_status";
	private static final String AMEND_ACCOUNT = "amend_acc_account";
	private static final String ACTION_ON_ACCOUNT = "amend_acc_action";
	private static final String BREAK_LINE1 = "databreakline1";
	private static final String BREAK_LINE2 = "databreakline2";
	private static final String SAVE_BUTTON = "amend_acc_save_btn";
	private static final String CANCEL_BUTTON = "amend_acc_cancel_btn";
	private static final String AMEND_BUTTON_BOX = "amendAccs";
	private static final String LINK_UNLINK_BUTTON = "link_unlink";
	private static final String EMPTY = " ";
	private static final String HYPEN = "-";
	private static final String OPERATION_SUCCESS_MSG = "amend_acc_operation_success";
	private static final String AMEND_ACC_CARD_LIST_TITLE="amend_acc_card_list";
	private static final String AMEND_ACC_ACCOUNT_LIST_TITLE="amend_acc_account_list";
	
	private boolean custAllowSecondaryCards;	

	private final static String CLASSNAME = "AmendAccountsPanel";	

	protected Institution institution;
	@SpringBean(name = "transportCustomerIdService")
	private CustomerService customerService;
	private AdditionalAccountsContextSummary additionalAccountsContextSummary;
	private Card card;
	private AccountHolder accountHolder;
	private CardProduct cardProduct;
	private WebMarkupContainer outputArea;
	private WebMarkupContainer c;
	private CortexModalWindow additionalAccountZoom;
	private CortexModalWindow msgZoom;
	private ButtonBox additionalAccBtnBox;
	private CortexAjaxButton additionalAccAjaxButton;
	private MessageDisplayPanel msgDisplayPanel;

	Form<Void> form;
	Label cardListTitle;
	Label cardNumberLabel;
	Label cardHolderNameLabel;
	Label cardProductLabel;
	Label cardNumberValue;
	Label cardHolderNameValue;
	Label cardProductValue;
	Label accountListTitle;
	ButtonBox amendAccButtonBox;
	BoxedSubmitButton amendAccSaveBtn;
	BoxedSubmitButton amendAccCancelBtn;
	RadioGroup<Account> accListRadioGroup;
	CheckGroup<Account> checkGroup;
	Account radioGroupModel;
	Collection<Account> listAccount;
	ListView<Account> listView;
	AdditionalAccountsZoomPanel amendAccountZoomPanel;
	Message popupMsg;
	Account popupAdditionalAccount;

	// construction
	public AmendAccountsPanel(
			AdditionalAccountsContextSummary additionalAccountsContextSummary) {
			
		/*
		Evaluate AllowSecondaryCards parameter in cortexOnlineCfg.xml
		*/
		try
		{
			debugLib.logDetail(CLASSNAME, "AmendAccountsPanel start");
			// Ensure that the path to the runner script is set in the configuration file
			StartupXmlConfigData startupXmlData = StartupXmlConfigData.getInstance();
			debugLib.logDetail(CLASSNAME, "StartupXmlConfigData instance created");
			String tsRemoteRunner = startupXmlData.getParameterFileItem(serverConstantBre.ALLOW_SECONDARY_CARDS);
			debugLib.logDetail(CLASSNAME, "serverConstantBre ALLOW_SECONDARY_CARDS " + serverConstantBre.ALLOW_SECONDARY_CARDS);
			debugLib.logDetail(CLASSNAME, "tsRemoteRunner " + tsRemoteRunner);
			
			this.custAllowSecondaryCards = (tsRemoteRunner!=null && "true".equalsIgnoreCase(tsRemoteRunner.trim()));	
			
			debugLib.logDetail(CLASSNAME, "custAllowSecondaryCards " + custAllowSecondaryCards);
		}
		catch (Exception e)
		{
			this.error(this.getString(e.getMessage()));
		}				
			
		this.setDefaultModel(new CompoundPropertyModel<AmendAccountsPanel>(this));
		this.additionalAccountsContextSummary = additionalAccountsContextSummary;
		this.listAccount = new ArrayList<Account>();
		this.institution = this.additionalAccountsContextSummary
				.getInstitution();
		this.popupAdditionalAccount = new Account();
		this.popupMsg = new Message();
		this.popupAdditionalAccount.setInstitution(institution);
		if (this.additionalAccountsContextSummary != null) {
			this.institution = this.additionalAccountsContextSummary
					.getInstitution();
			this.card = this.additionalAccountsContextSummary.getCard();
			if (this.card != null) {
				this.accountHolder = this.card.getAccountHolder();
				this.listAccount.addAll(this.card.getLinkedAccounts());
			}
			if (this.additionalAccountsContextSummary.getMessage() != null) {
				this.info(this.getString(this.additionalAccountsContextSummary
						.getMessage()));
			}

		}
		if (this.accountHolder == null) {
			this.accountHolder = new AccountHolder();
		}
		this.form = new Form<Void>("form") {
			private static final long serialVersionUID = 1L;

			protected void onSubmit() {
			}

			protected void onError() {
			}
		};
		this.add(form);
		this.addContext(this);
		this.addControls(form);
		this.addAccountTables(form);
		this.addAdditionalAccountButton(form);
		this.addActionButtons(form,
				this.accountHolder.getAccounts().size() > 0 ? true : false);
		this.form.setOutputMarkupId(true);
		this.form.setOutputMarkupPlaceholderTag(true);
		this.setOutputMarkupId(true);
		this.setOutputMarkupPlaceholderTag(true);
	}

	private void addContext(WebMarkupContainer parent) {
		parent.add(new ContextPanel("context").addInstitution(this.institution)
				.setEnabled(false));
	}

	private void addControls(WebMarkupContainer parent) {
		parent.add(this.cardListTitle=new Label("cardListTitle", this.getString(AMEND_ACC_CARD_LIST_TITLE)));
		parent.add(this.cardNumberLabel = new Label("cardNumber", this
				.getString(AMEND_CARD)));
		parent.add(this.cardNumberValue = new Label("cardNumberText",
				this.card != null ? this.card.getPan() : EMPTY));
		parent.add(this.cardHolderNameLabel = new Label("cardHolderName", this
				.getString(ACCOUNT_HOLDER_NAME)));
		StringBuilder strBuilder = new StringBuilder();
		if (this.accountHolder != null) {
			strBuilder.append(accountHolder.getTitle() != null ? accountHolder
					.getTitle() + EMPTY : EMPTY);
			strBuilder
					.append(accountHolder.getFirstName() != null ? accountHolder
							.getFirstName() + EMPTY
							: EMPTY);
			strBuilder
					.append(accountHolder.getLastName() != null ? accountHolder
							.getLastName() : EMPTY);
			parent.add(this.cardHolderNameValue = new Label(
					"cardHolderNameText", strBuilder.toString()));
		} else {
			parent.add(this.cardHolderNameValue = new Label(
					"cardHolderNameText", EMPTY));
		}

		parent.add(this.cardProductLabel = new Label("cardProductName", this
				.getString(CARD_PRODUCT)));
		strBuilder.setLength(0);
		if (this.cardProduct != null) {
			strBuilder.append(this.cardProduct.getCardProduct()).append(HYPEN)
					.append(this.cardProduct.getDescription());
			parent.add(this.cardProductValue = new Label("cardProductNameText",
					strBuilder.toString()));
		} else {
			if (this.card != null && this.card.getCardProduct() != null) {
				strBuilder.append(this.card.getCardProduct().getCardProduct())
						.append(HYPEN)
						.append(this.card.getCardProduct().getDescription());
				parent.add(this.cardProductValue = new Label(
						"cardProductNameText", strBuilder.toString()));
			} else {
				parent.add(this.cardProductValue = new Label(
						"cardProductNameText", EMPTY));
			}
		}
		parent.add(this.accountListTitle = new Label("accountListTitle", this.getString(AMEND_ACC_ACCOUNT_LIST_TITLE)));
	}

	private void addAccountTables(final MarkupContainer parent) {
		this.outputArea = new WebMarkupContainer(PARENT_WEB_MARKUP_CONTAINER);
		this.outputArea.setOutputMarkupId(true);
		this.outputArea.setOutputMarkupPlaceholderTag(true);
		parent.add(this.outputArea);

		this.outputArea.add(this.c = new WebMarkupContainer(
				CHILD_WEB_MARKUP_CONTAINER) {
			private static final long serialVersionUID = 1L;

			@Override
			public boolean isVisible() {
				return true;
			}
		});
		this.c.setOutputMarkupId(true);
		this.c.setOutputMarkupPlaceholderTag(true);
		this.addActionsTable(this.c);
	}

	private void addActionsTable(MarkupContainer parent) {		
		AttributeModifier behaviour = new AttributeModifier(COLSPAN,
				new Model<String>(String.format("%d", 7)));
		parent.add(new Label("accountList", this.getString(ACCOUNT_LIST))
				.add(behaviour));
		parent.add(new Label("default", this.getString(DEFAULT_ACCOUNT)));
		parent.add(new Label("link", this.getString(ACCOUNT_LINK)));
		parent.add(new Label("type", this.getString(ACCOUNT_TYPE)));
		parent.add(new Label("status", this.getString(ACCOUNT_STATUS)));
		parent.add(new Label("currency", this.getString(ACCOUNT_CURRENCY)));
		parent.add(new Label("account", this.getString(AMEND_ACCOUNT)));
		parent.add(new Label("link_unlink", this.getString(ACTION_ON_ACCOUNT)));
		parent.add(new NoopOutputTransformerContainer(BREAK_LINE1)
				.add(behaviour));
		parent.add(new NoopOutputTransformerContainer(BREAK_LINE2)
				.add(behaviour));
		this.accListRadioGroup = new RadioGroup<Account>("accountListRg",
				new PropertyModel<Account>(this, "radioGroupModel"));
		this.radioGroupModel = this.card.getAccount();
		/*
		if (AmendAccountsPanel.this.custAllowSecondaryCards == false) {
			if (this.radioGroupModel!=null) {
				listAccount.add(radioGroupModel);
			}
		}
		*/
		this.accListRadioGroup.setDefaultModelObject(this.radioGroupModel);
		this.accListRadioGroup.setOutputMarkupId(true);
		this.accListRadioGroup.setOutputMarkupPlaceholderTag(true);
		parent.add(this.accListRadioGroup);
		this.checkGroup = new CheckGroup<Account>("checkGroup",
				new PropertyModel<ArrayList<Account>>(this, "listAccount"));
		this.checkGroup.setOutputMarkupId(true);
		this.checkGroup.setOutputMarkupPlaceholderTag(true);
		this.listView = new ListView<Account>(
				"tablerow",
				new PropertyModel<List<Account>>(this.accountHolder, "accounts")) {
			private static final long serialVersionUID = 1L;

			protected void populateItem(final ListItem<Account> item) {
				Radio<Account> radio = new Radio<Account>("accDlft",
						item.getModel());
						
				if (AmendAccountsPanel.this.custAllowSecondaryCards == false) {
					debugLib.logDetail(CLASSNAME, "AllowSecondaryCards false: activating onselectAccount function ...");
					radio.add(new AttributeAppender("onclick", new Model("onselectAccount(this)"), ""));
				}
				radio.setOutputMarkupId(true);
				radio.setOutputMarkupPlaceholderTag(true);
				item.add(radio);
				Check<Account> accountCheck = new Check<Account>("acclink",
						item.getModel());
				accountCheck.setOutputMarkupId(true);
				accountCheck.setOutputMarkupPlaceholderTag(true);
				accountCheck.setEnabled(false);
				item.add(accountCheck);
				item.add(new Label("accType", new PropertyModel<String>(item
						.getModel(), "accountType")));
				item.add(new Label("accStatus", new PropertyModel<String>(item
						.getModel(), "status")));
				item.add(new Label("accCurrency", new PropertyModel<String>(
						item.getModelObject().getCurrency(), "code")));
				item.add(new Label("custAccount", new PropertyModel<String>(
						item.getModel(), "accountNumber")));
				if (!AmendAccountsPanel.this.listAccount.contains(item
						.getModelObject())) {
					setAjaxButtons(
							new Model<String>(
									this.getString(AmendAccountsPanel.LINK)),
							item);
				} else {
					setAjaxButtons(
							new Model<String>(
									this.getString(AmendAccountsPanel.UNLINK)),
							item);
					item.getModelObject().setSelected(true);
				}
			}
		};

		this.listView.setReuseItems(true);
		this.listView.setOutputMarkupId(true);
		this.listView.setOutputMarkupPlaceholderTag(true);
		this.checkGroup.add(this.listView);
		this.accListRadioGroup.add(this.checkGroup);

	}

	private void addAdditionalAccountButton(WebMarkupContainer parent) {
		this.additionalAccBtnBox = new ButtonBox("amendAccButton", false);
		this.additionalAccAjaxButton = new CortexAjaxButton("button",
				new Model<String>(this
						.getString("amend_acc_additional_acc_btn")),
				AmendAccountsPanel.this.form) {
			private static final long serialVersionUID = 1L;

			protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
				AmendAccountsPanel.this.additionalAccountZoom.refreshContent();
				AmendAccountsPanel.this.additionalAccountZoom.show(target);
				AmendAccountsPanel.this.amendAccountZoomPanel
						.setCustomerId(AmendAccountsPanel.this.accountHolder
								.getRealId());
				AmendAccountsPanel.this.card
						.setAccount(AmendAccountsPanel.this.accListRadioGroup
								.getModelObject());
			}

			@Override
			protected void onError(AjaxRequestTarget target, Form<?> form) {
				target.addComponent(AmendAccountsPanel.this.form);
			}
		};
		this.additionalAccBtnBox.addButton(additionalAccAjaxButton);
		parent.add(this.additionalAccBtnBox);
		this.additionalAccountZoom = new CortexModalWindow(
				"zoomAdditionalAccounts", new PropertyModel<Account>(
						AmendAccountsPanel.this, "popupAdditionalAccount"),
				this.getString("amend_acc_get_additional_account")) {
			private static final long serialVersionUID = 1L;

			protected Component createContent(String id) {
				if (getDefaultModelObject() == null) {
					return null;
				} else {
					return AmendAccountsPanel.this.amendAccountZoomPanel = new AdditionalAccountsZoomPanel(
							AmendAccountsPanel.this,
							AmendAccountsPanel.this.additionalAccountZoom,
							new PropertyModel<Account>(AmendAccountsPanel.this,
									"popupAdditionalAccount"), id);
				}
			}
		};
		this.additionalAccountZoom
				.setWindowClosedCallback(new ModalWindow.WindowClosedCallback() {
					private static final long serialVersionUID = 1L;

					public void onClose(AjaxRequestTarget target) {
						try {
							Account returnedAcc = (Account) new PropertyModel<Account>(
									AmendAccountsPanel.this,
									"popupAdditionalAccount").getObject()
									.clone();
							if (returnedAcc.getCurrency().getCode()!=null&&returnedAcc.getRealId() > 0
									&& returnedAcc.getAccountNumber() != null) {
								List<Account> accounts = AmendAccountsPanel.this.accountHolder.getAccounts();
								for (Account acc : accounts) {
									if (returnedAcc.getCurrency().getCode().equalsIgnoreCase(acc.getCurrency().getCode())
											&& returnedAcc.getInstitution().getRealId() == acc.getInstitution().getRealId()
											&& returnedAcc.getAccountNumber().equalsIgnoreCase(acc.getAccountNumber())) {
										refreshModelWindow(target,AmendAccountsPanel.this.getString("amend_acc_account_exist_msg"));
										return;
									}
								}
								returnedAcc.setSelected(true);
								AmendAccountsPanel.this.accountHolder
										.getAccounts().add(returnedAcc);
								setAccountsSelection();
								target.addComponent(AmendAccountsPanel.this.outputArea);
								target.addComponent(AmendAccountsPanel.this.amendAccSaveBtn);

							}

						} catch (CloneNotSupportedException exp) {
							AmendAccountsPanel.this.error(AmendAccountsPanel.this
									.getString("amend_acc_adding_additional_acc_error"));
						}
						
					}
				});

		this.additionalAccountZoom.setOutputMarkupId(true);
		this.additionalAccountZoom.setOutputMarkupPlaceholderTag(true);
		parent.add(this.additionalAccountZoom);
		this.msgZoom = new CortexModalWindow("zoomAmendAccMsgPanel",new PropertyModel<Message>(AmendAccountsPanel.this, "popupMsg"),this.getString("amend_acc_account_validation_msg")) {
			private static final long serialVersionUID = 1L;
			protected Component createContent(String id) {
				if (getDefaultModelObject() == null) {
					return null;
				} else {
					return AmendAccountsPanel.this.msgDisplayPanel = new MessageDisplayPanel(AmendAccountsPanel.this,AmendAccountsPanel.this.msgZoom,new PropertyModel<Message>(AmendAccountsPanel.this,"popupMsg"), id);
				}
			}
		};
		this.msgZoom.setInitialHeight(150);
		this.msgZoom.setInitialWidth(400);
		this.msgZoom.setWindowClosedCallback(new ModalWindow.WindowClosedCallback() {
					private static final long serialVersionUID = 1L;

					public void onClose(AjaxRequestTarget target) {

					}
				});

		parent.add(this.msgZoom);

	}

	private void addActionButtons(WebMarkupContainer parent, boolean enabled) {
		this.amendAccButtonBox = new ButtonBox(AMEND_BUTTON_BOX, false);
		this.amendAccSaveBtn = new BoxedSubmitButton(new Model<String>(
				this.getString(SAVE_BUTTON))) {
			private static final long serialVersionUID = 1L;

			public void onSubmit() {
				try {
					/*
					Linking default account
					*/
					
					if (AmendAccountsPanel.this.custAllowSecondaryCards == false) {
						debugLib.logDetail(CLASSNAME, "AllowSecondaryCards: false");
						
						Collection<Account> listLinkedAcc = AmendAccountsPanel.this.checkGroup.getModelObject();	
						Account acc = AmendAccountsPanel.this.radioGroupModel;
						
						debugLib.logDetail(CLASSNAME, "accountHolder "  + AmendAccountsPanel.this.accountHolder.getAccounts().size());
						debugLib.logDetail(CLASSNAME, "Remove linking...");
						
						listLinkedAcc.removeAll(listLinkedAcc);
						debugLib.logDetail(CLASSNAME, "linked accounts "  + listLinkedAcc.size());
						
						listLinkedAcc.add(acc); 
						debugLib.logDetail(CLASSNAME, "Linking default account...");
						debugLib.logDetail(CLASSNAME, "linked accounts "  + listLinkedAcc.size());
						
						for (Account acc2 : AmendAccountsPanel.this.accountHolder.getAccounts()) {
							acc2.setSelected(false);
						}							
						acc.setSelected(true); 
					}
					else {
						debugLib.logDetail(CLASSNAME, "AllowSecondaryCards: true");
					}
					
					if (AmendAccountsPanel.this.accListRadioGroup
							.getModelObject() != null) {
						AmendAccountsPanel.this.card
								.setAccount(AmendAccountsPanel.this.accListRadioGroup
										.getModelObject());
						AmendAccountsPanel.this.customerService
						.deleteCardAccountLinks(
								AmendAccountsPanel.this.card,
								AmendAccountsPanel.this.accountHolder
										.getAccounts());
						AmendAccountsPanel.this.customerService
						.updateCardAccountLinks(
								AmendAccountsPanel.this.card,
								AmendAccountsPanel.this.accountHolder
										.getAccounts());
												
						AmendAccountsPanel.this.card = customerService
								.getLinkedAccountsForCard(
										AmendAccountsPanel.this.card.getPan(),
										AmendAccountsPanel.this.institution
												.getRealId());
						AmendAccountsPanel.this.additionalAccountsContextSummary = new AdditionalAccountsContextSummary(
								AmendAccountsPanel.this.institution,
								AmendAccountsPanel.this.card,AmendAccountsPanel.OPERATION_SUCCESS_MSG);
					    AmendAccountsPanel.this
								.complete(new AmendAccountsMainPanel.GoCardSearchResult(
										AmendAccountsPanel.this.additionalAccountsContextSummary));
					} else {
						this.error(this.getString("amend_acc_select_dlft_acc"));
					}
				} catch (CardAccountLinkingException exp) {
					logger.error(exp.getMessage());
					setAccountsSelection();
					this.error(this.getString("amend_acc_linking_error"));
				} catch (GeneralSqlException exp) {
					logger.error(exp.getMessage());
					this.error(this.getString(exp.getMessage()));
				} catch (CardNotFoundException exp) {
					logger.error(exp.getMessage());
					this.error(this.getString("card_not_found"));
				}
			}
		};
		this.amendAccSaveBtn.setOutputMarkupId(true);
		this.amendAccSaveBtn.setOutputMarkupPlaceholderTag(true);
		this.amendAccSaveBtn.setEnabled(enabled);
		this.amendAccButtonBox.addButton(amendAccSaveBtn);
		this.amendAccCancelBtn = new BoxedSubmitButton(new Model<String>(this.getString(CANCEL_BUTTON))) {
			
			private static final long serialVersionUID = 1L;
			public void onSubmit() {
				AmendAccountsPanel.this.additionalAccountsContextSummary = new AdditionalAccountsContextSummary(AmendAccountsPanel.this.institution, null,null);
				AmendAccountsPanel.this.complete(new AmendAccountsMainPanel.GoSearchCardPanel(AmendAccountsPanel.this.additionalAccountsContextSummary));
			}
		};
		this.amendAccCancelBtn.setDefaultFormProcessing(false);
		this.amendAccCancelBtn.setOutputMarkupId(true);
		this.amendAccCancelBtn.setOutputMarkupPlaceholderTag(true);
		this.amendAccButtonBox.addButton(this.amendAccCancelBtn);
		this.amendAccButtonBox.setOutputMarkupId(true);
		this.amendAccButtonBox.setOutputMarkupPlaceholderTag(true);
		parent.add(this.amendAccButtonBox);
	}

	private void setActionLabel(AjaxButton ajaxButton, ListItem<Account> item,AjaxRequestTarget target) {
		
		Collection<Account> listLinkedAcc = this.checkGroup.getModelObject();
		Account acc = item.getModelObject();
                ajaxButton.setEnabled(false);
                
		if (ajaxButton.getModelObject().equals(this.getString(LINK))) {
			if (!listLinkedAcc.contains(acc))
				listLinkedAcc.add(acc);
			acc.setSelected(true);
			ajaxButton.setDefaultModel(new Model<String>(this.getString(UNLINK)));
		} else {
			if (listLinkedAcc.contains(item.getModelObject()))
				listLinkedAcc.remove(item.getModelObject());
			ajaxButton.setDefaultModel(new Model<String>(this.getString(LINK)));
			acc.setSelected(false);
		}

	}

    private void setAjaxButtons(IModel<String> model,final ListItem<Account> item) {
        CortexAjaxButton ajaxButton = new CortexAjaxButton(LINK_UNLINK_BUTTON, model,AmendAccountsPanel.this.form) {            
            private static final long serialVersionUID = 1L;
            
            protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
                AmendAccountsPanel.this.setActionLabel(this, item, target);
                Component component = item.get(1);
                target.addComponent(component);
                target.addComponent(this);
            }

            protected void onError(AjaxRequestTarget target, Form<?> form) {
                target.addComponent(AmendAccountsPanel.this.outputArea);
            }
                        
        };
		
		debugLib.logDetail(CLASSNAME, "AmendAccountsPanel.this.custAllowSecondaryCards " + AmendAccountsPanel.this.custAllowSecondaryCards);
		
		if (AmendAccountsPanel.this.custAllowSecondaryCards) {
			debugLib.logDetail(CLASSNAME, "AllowSecondaryCards true");
			ajaxButton.setEnabled(true);
		}				
		else {
			debugLib.logDetail(CLASSNAME, "AllowSecondaryCards false");
			ajaxButton.setEnabled(false);
		}		
		
        item.add(ajaxButton);
                
    }
	

	private void setAccountsSelection() {
		this.accListRadioGroup.setModel(new Model<Account>(this.card.getAccount()));

		for (Account acc : this.accountHolder.getAccounts()) {
			if (acc.isSelected()) {
				this.listAccount.add(acc);
			}
		}
		if (this.card.getAccount() == null&& this.accountHolder.getAccounts().size() == 1) {
			this.accListRadioGroup.setModel(new Model<Account>(this.accountHolder.getAccounts().get(0)));
			this.amendAccSaveBtn.setEnabled(true);
		}
		this.checkGroup.setModel(new CollectionModel<Account>(this.listAccount));
	}

	private void refreshModelWindow(AjaxRequestTarget target, String msg) {
		this.msgDisplayPanel.setDisplayMessage(msg);
		this.msgZoom.refreshContent();
		this.msgZoom.show(target);
	}

}
