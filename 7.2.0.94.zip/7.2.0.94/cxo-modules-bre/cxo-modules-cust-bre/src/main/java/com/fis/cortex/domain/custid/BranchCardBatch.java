package com.fis.cortex.domain.custid;

import com.nomadsoft.cortex.domain.branch.Branch;
import com.nomadsoft.cortex.domain.cardbatch.CardBatch;

public interface BranchCardBatch extends java.io.Serializable{
	
  Long getId();
  
  void setId(Long id);
	
  int getVersionNumber();
	
  void setVersionNumber(int versionNumber);
  
  Branch getBranch();
  
  void setBranch(Branch branch);
  
  CardBatch getCardBatch();
 
  void setCardBatch(CardBatch cardBatch);  

}
