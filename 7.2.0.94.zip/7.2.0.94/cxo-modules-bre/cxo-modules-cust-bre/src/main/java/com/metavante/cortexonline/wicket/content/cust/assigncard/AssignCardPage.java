/**
 * <hr>
 * <h4>Copyright Metavante Technologies Ltd.</h4>
 */
package com.metavante.cortexonline.wicket.content.cust.assigncard;

import org.apache.wicket.PageParameters;
import org.apache.wicket.model.PropertyModel;

import com.metavante.cortex.transport.objects.core.Institution;
import com.metavante.cortexonline.wicket.BasePage;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlow;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowHolderPanel;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowManager;
import com.metavante.cortexonline.wicket.content.common.panels.SimpleSelectInstitutionPanel;
import com.metavante.cortexonline.wicket.content.cust.assigncard.panels.AssignCardMainPanel;


/**
 * Main Assign card page
 * 
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/assigncard/AssignCardPage.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class AssignCardPage extends BasePage implements WorkFlow {

	private static final int STATE_FAILURE = -1;
	private static final int STATE_START = 0;
	private static final int STATE_INSTSELECTED = 1;

	// services

	// data

	protected Institution institution;

	// components

	private WorkFlowHolderPanel panel;

	// construction

	public AssignCardPage(PageParameters parameters) {
		super(parameters);

		this.add(this.panel = new WorkFlowHolderPanel("c"));
		this.panel.setWorkFlow(this, STATE_START);
	}

	@Override
	public PageInfo getPageInfo() {
		BasePage.PageInfo pageInfo = this.panel.getPageInfo();
		pageInfo.setPageTitle(getString("assign_card_title"));
		pageInfo.addAcsItem("agn_card");
		pageInfo.addTitle(getString("assign_card"));
		return pageInfo;
	}

	// workflow

	public void process(WorkFlowManager manager) {
		switch (manager.getState()) {
		case STATE_START:
			this.doSelectInstitution(manager);
			break;
		case STATE_INSTSELECTED:
			this.doMain(manager);
			break;
		default:
			manager.terminate();
			this.setResponsePage(com.metavante.cortexonline.wicket.HomePage.class);
			break;
		}
	}

	private void doSelectInstitution(WorkFlowManager manager) {
		manager.setPanel(new SimpleSelectInstitutionPanel(new PropertyModel<Institution>(this, "institution")),
				STATE_INSTSELECTED, STATE_FAILURE);
	}

	private void doMain(WorkFlowManager manager) {
		manager.setPanel(new AssignCardMainPanel(this.institution), STATE_FAILURE, STATE_FAILURE);
	}
}
