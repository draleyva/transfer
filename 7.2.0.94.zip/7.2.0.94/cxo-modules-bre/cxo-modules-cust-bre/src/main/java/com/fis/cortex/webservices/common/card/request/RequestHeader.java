package com.fis.cortex.webservices.common.card.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.fis.cortex.webservices.common.card.serviceparameter.ServiceParametersList;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "http://wscore.cortex.fis.com/ctxCommonRqstHdr", name = "RqstHdr")
public class RequestHeader {
	
	public RequestHeader(){}
	
	@XmlElement(required = true, name = "RqstHdrVer", namespace = "http://wscore.cortex.fis.com/ctxCommonRqstHdr")
	private String rqstHdrVer;

	@XmlElement(required = true, name = "MsgUuid", namespace = "http://wscore.cortex.fis.com/ctxCommonRqstHdr")
	private String msgUuid;

	@XmlElement(required = true, name = "SrcId", namespace = "http://wscore.cortex.fis.com/ctxCommonRqstHdr")
	private String srcId;

	@XmlElement(required = true, name = "LclPrf", namespace = "http://wscore.cortex.fis.com/ctxCommonRqstHdr")
	private String lclPrf;

	@XmlElement(required = false, name = "Sec", namespace = "http://wscore.cortex.fis.com/ctxCommonRqstHdr")
	private SecurityData sec;
	
	@XmlElement(required = true, name = "ServPrmtrsLst", namespace = "http://wscore.cortex.fis.com/ctxCommon")
	private ServiceParametersList servPrmtrsLst;

	public String getRqstHdrVer() {
		return rqstHdrVer;
	}

	public void setRqstHdrVer(String rqstHdrVer) {
		this.rqstHdrVer = rqstHdrVer;
	}

	public String getMsgUuid() {
		return msgUuid;
	}

	public void setMsgUuid(String msgUuid) {
		this.msgUuid = msgUuid;
	}

	public String getSrcId() {
		return srcId;
	}

	public void setSrcId(String srcId) {
		this.srcId = srcId;
	}

	public String getLclPrf() {
		return lclPrf;
	}

	public void setLclPrf(String lclPrf) {
		this.lclPrf = lclPrf;
	}

	public SecurityData getSec() {
		return sec;
	}

	public void setSec(SecurityData sec) {
		this.sec = sec;
	}

	public ServiceParametersList getServPrmtrsLst() {
		return servPrmtrsLst;
	}

	public void setServPrmtrsLst(ServiceParametersList servPrmtrsLst) {
		this.servPrmtrsLst = servPrmtrsLst;
	}

}