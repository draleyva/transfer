package com.metavante.cortexonline.wicket.content.cust.components;

import java.util.ArrayList;
import java.util.List;

import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.markup.html.form.IChoiceRenderer;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.spring.injection.annot.SpringBean;

import com.metavante.cortex.transport.objects.core.Institution;
import com.fis.cortex.transport.custid.services.CustomerService;
import com.metavante.cortexonline.wicket.components.componentline.SelectFieldLine;
import com.metavante.cortex.transport.objects.common.Branch;

public class BranchSelectLine extends SelectFieldLine<Branch> {
	private static final long serialVersionUID = 1L;
	@SpringBean(name = "transportCustomerIdService")
	private CustomerService customerService;	
    private Institution  institution;
	public BranchSelectLine(String id, String label, Institution institution, IModel<Branch> model) {
		super(id, label);
		this.institution =institution;	
		List<Branch> choices = this.getChoices();

		DropDownChoice<Branch> field = new DropDownChoice<Branch>(
				"select_field", model,choices,new IChoiceRenderer<Branch>() {
					private static final long serialVersionUID = 1L;

					public Object getDisplayValue(Branch object) {
						return object.getBranchCode()+"-"+object.getDescription();
					}

					public String getIdValue(Branch object, int index) {
						return object.getBranchId()+"";
					}
					
					
				}){
    		    private static final long serialVersionUID = 1L;
    		   
		   };		
		
		field.setLabel(new Model<String>(label));

		this.addComponent(field);
	}
	
	protected List<Branch> getChoices()
	{
		List<Branch> branchList=null;	
		try
		{
			branchList = this.customerService.getBranchesByInstitution(this.institution);
		}catch(Exception exp){
			branchList= new ArrayList<Branch>();
		  this.error(this.getString(exp.getMessage()));		
		}		
		return branchList;
	 }

}
