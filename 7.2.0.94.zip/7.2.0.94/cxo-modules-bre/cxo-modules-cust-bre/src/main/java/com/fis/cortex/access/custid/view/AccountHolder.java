package com.fis.cortex.access.custid.view;
import java.util.Date;
import com.fis.cortex.transport.core.dataholder.TransportList;
import com.fis.cortex.transport.core.dataholder.TransportObject;
import com.fis.cortex.transport.core.dataholder.core.Institution;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/view/AccountHolder.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class AccountHolder extends TransportObject {
	
	private static final long serialVersionUID = -5541759053337962763L;	
	private TransportList<Account> accounts=new TransportList<Account>();
	private Short addressIndicator;	
	private short collectionZone;	
	private Date dateAccepted;
	private Date dateOfBirth;	
	private String email;	
	private String firstName;	
	private String homeTelephoneNumber;	
	private String idNumber;	
	private String lastName;	
	private char mailShots;	
	private char maritalStatus;	
	private String memo;	
	private String mobileTelephoneNumber;	
	private String numberBouncedChequesPrimaryCurrency;	
	private String numberBouncedChequesSecondaryCurrency;	
	private String pOBox;	
	private String preferredLanguage;	
	private short professionCode;	
	private char refuseCheque;	
	private char sex;	
	private short statementCode;	
	private String title;	
	private short customerType;	
	private String userData1;	
	private String userData2;	
	private String userData3;
	private String userData4;	
	private String workTelephoneNumber;	
	private String faxNumber;	
	private String homeCountryIso;	
	private String workCountryIso;	
	private String customerCode;
	private Institution institution;
	private String nationalityId;
	private String catParams;
	private String latinTitle;
	private String latinFirstName;
	private String latinLastName;
	private String ucFirstName;
	private String ucLastName;
	private String name;
	private String embossName;	
	private String workAddressPostCode;
	private Address homeAddress;
	private Address workAddress;
	
	

	public String getEmbossName() {
		return embossName;
	}

	public void setEmbossName(String embossName) {
		this.embossName = embossName;
	}

	public String getName() {
		name = getTitle()+"  "+getFirstName()+"  "+getLastName();
		return name;
	}

	public void setName(String name) {
		this.name = getTitle()+"  "+getFirstName()+" "+getLastName();
	}

	public TransportList<Account> getAccounts() {
		return accounts;
	}
	
	public void setAccounts(TransportList<Account> accounts) {
		this.accounts = accounts;
	}
	public Short getAddressIndicator() {
		return addressIndicator;
	}
	public void setAddressIndicator(Short addressIndicator) {
		this.addressIndicator = addressIndicator;
	}
	public short getCollectionZone() {
		return collectionZone;
	}
	public void setCollectionZone(short collectionZone) {
		this.collectionZone = collectionZone;
	}
	public Date getDateAccepted() {
		return dateAccepted;
	}
	public void setDateAccepted(Date dateAccepted) {
		this.dateAccepted = dateAccepted;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getHomeTelephoneNumber() {
		return homeTelephoneNumber;
	}
	public void setHomeTelephoneNumber(String homeTelephoneNumber) {
		this.homeTelephoneNumber = homeTelephoneNumber;
	}
	public String getIdNumber() {
		return idNumber;
	}
	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getMailShots() {
		return mailShots;
	}
	public void setMailShots(char mailShots) {
		this.mailShots = mailShots;
	}
	public char getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(char maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public String getMobileTelephoneNumber() {
		return mobileTelephoneNumber;
	}
	public void setMobileTelephoneNumber(String mobileTelephoneNumber) {
		this.mobileTelephoneNumber = mobileTelephoneNumber;
	}
	public String getNumberBouncedChequesPrimaryCurrency() {
		return numberBouncedChequesPrimaryCurrency;
	}
	public void setNumberBouncedChequesPrimaryCurrency(
			String numberBouncedChequesPrimaryCurrency) {
		this.numberBouncedChequesPrimaryCurrency = numberBouncedChequesPrimaryCurrency;
	}
	public String getNumberBouncedChequesSecondaryCurrency() {
		return numberBouncedChequesSecondaryCurrency;
	}
	public void setNumberBouncedChequesSecondaryCurrency(
			String numberBouncedChequesSecondaryCurrency) {
		this.numberBouncedChequesSecondaryCurrency = numberBouncedChequesSecondaryCurrency;
	}
	public String getPOBox() {
		return pOBox;
	}
	public void setPOBox(String pOBox) {
		this.pOBox = pOBox;
	}
	public String getPreferredLanguage() {
		return preferredLanguage;
	}
	public void setPreferredLanguage(String preferredLanguage) {
		this.preferredLanguage = preferredLanguage;
	}
	public short getProfessionCode() {
		return professionCode;
	}
	public void setProfessionCode(short professionCode) {
		this.professionCode = professionCode;
	}
	public char getRefuseCheque() {
		return refuseCheque;
	}
	public void setRefuseCheque(char refuseCheque) {
		this.refuseCheque = refuseCheque;
	}
	public char getSex() {
		return sex;
	}
	public void setSex(char sex) {
		this.sex = sex;
	}
	public short getStatementCode() {
		return statementCode;
	}
	public void setStatementCode(short statementCode) {
		this.statementCode = statementCode;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public short getCustomerType() {
		return customerType;
	}
	public void setCustomerType(short customerType) {
		this.customerType = customerType;
	}
	public String getUserData1() {
		return userData1;
	}
	public void setUserData1(String userData1) {
		this.userData1 = userData1;
	}
	public String getUserData2() {
		return userData2;
	}
	public void setUserData2(String userData2) {
		this.userData2 = userData2;
	}
	public String getUserData3() {
		return userData3;
	}
	public void setUserData3(String userData3) {
		this.userData3 = userData3;
	}
	public String getUserData4() {
		return userData4;
	}
	public void setUserData4(String userData4) {
		this.userData4 = userData4;
	}
	public String getWorkTelephoneNumber() {
		return workTelephoneNumber;
	}
	public void setWorkTelephoneNumber(String workTelephoneNumber) {
		this.workTelephoneNumber = workTelephoneNumber;
	}
	public String getFaxNumber() {
		return faxNumber;
	}
	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}
	public String getHomeCountryIso() {
		return homeCountryIso;
	}
	public void setHomeCountryIso(String homeCountryIso) {
		this.homeCountryIso = homeCountryIso;
	}
	public String getWorkCountryIso() {
		return workCountryIso;
	}
	public void setWorkCountryIso(String workCountryIso) {
		this.workCountryIso = workCountryIso;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public Institution getInstitution() {
		return institution;
	}
	public void setInstitution(Institution institution) {
		this.institution = institution;
	}
	public String getNationalityId() {
		return nationalityId;
	}
	public void setNationalityId(String nationalityId) {
		this.nationalityId = nationalityId;
	}
	public String getCatParams() {
		return catParams;
	}
	public void setCatParams(String catParams) {
		this.catParams = catParams;
	}
	public String getLatinTitle() {
		return latinTitle;
	}
	public void setLatinTitle(String latinTitle) {
		this.latinTitle = latinTitle;
	}
	public String getLatinFirstName() {
		return latinFirstName;
	}
	public void setLatinFirstName(String latinFirstName) {
		this.latinFirstName = latinFirstName;
	}
	public String getLatinLastName() {
		return latinLastName;
	}
	public void setLatinLastName(String latinLastName) {
		this.latinLastName = latinLastName;
	}
	public String getUcFirstName() {
		return ucFirstName;
	}
	public void setUcFirstName(String ucFirstName) {
		this.ucFirstName = ucFirstName;
	}
	public String getUcLastName() {
		return ucLastName;
	}
	public void setUcLastName(String ucLastName) {
		this.ucLastName = ucLastName;
	}
	public Address getHomeAddress() {
		return homeAddress;
	}

	public void setHomeAddress(Address homeAddress) {
		this.homeAddress = homeAddress;
	}
	public Address getWorkAddress() {
		return workAddress;
	}

	public void setWorkAddress(Address workAddress) {
		this.workAddress = workAddress;
	}
	public String getWorkAddressPostCode() {
		return workAddressPostCode;
	}

	public void setWorkAddressPostCode(String workAddressPostCode) {
		this.workAddressPostCode = workAddressPostCode;
	}
	
}
