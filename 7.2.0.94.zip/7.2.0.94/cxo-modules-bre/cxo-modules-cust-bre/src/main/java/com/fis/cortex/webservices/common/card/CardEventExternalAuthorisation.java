package com.fis.cortex.webservices.common.card;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "CrdEventExtAuth")
@XmlAccessorType(XmlAccessType.FIELD)
public class CardEventExternalAuthorisation {
	
	@XmlElement(required = false, name = "MakerId", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String makerId 	 ;
	
	@XmlElement(required = false, name = "CheckerId", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String checkerId ;
	
	@XmlElement(required = false, name = "DeptId", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String deptId 	 ;
	
	@XmlElement(required = false, name = "ExtRef", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String extRef	 ;
	
	@XmlElement(required = false, name = "Channel", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String channel	 ;
	
	@XmlElement(required = false, name = "SvcName", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String svcName	 ;
	
	@XmlElement(required = false, name = "DateCreation", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Date dateCreation;
	
	@XmlElement(required = false, name = "TimeCreation", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String timeCreation;

	public String getMakerId() {
		return makerId;
	}

	public void setMakerId(String makerId) {
		this.makerId = makerId;
	}

	public String getCheckerId() {
		return checkerId;
	}

	public void setCheckerId(String checkerId) {
		this.checkerId = checkerId;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getExtRef() {
		return extRef;
	}

	public void setExtRef(String extRef) {
		this.extRef = extRef;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getSvcName() {
		return svcName;
	}

	public void setSvcName(String svcName) {
		this.svcName = svcName;
	}

	public Date getDateCreation() {
		return dateCreation;
	}

	public void setDateCreation(Date dateCreation) {
		this.dateCreation = dateCreation;
	}

	public String getTimeCreation() {
		return timeCreation;
	}

	public void setTimeCreation(String timeCreation) {
		this.timeCreation = timeCreation;
	}

}
