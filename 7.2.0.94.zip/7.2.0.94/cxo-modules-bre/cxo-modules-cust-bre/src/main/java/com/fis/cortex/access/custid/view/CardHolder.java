package com.fis.cortex.access.custid.view;

import java.util.Date;

import com.fis.cortex.transport.core.dataholder.TransportObject;

public class CardHolder extends TransportObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5345194870378970479L;
	private String title;
    private String firstName;
    private String lastName;
    private String firstNameUpperCase;
    private String lastNameUpperCase;
    private String idNumber;
    private Date dateOfBirth;
	
    public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstNameUpperCase() {
		return firstNameUpperCase;
	}
	public void setFirstNameUpperCase(String firstNameUpperCase) {
		this.firstNameUpperCase = firstNameUpperCase;
	}
	public String getLastNameUpperCase() {
		return lastNameUpperCase;
	}
	public void setLastNameUpperCase(String lastNameUpperCase) {
		this.lastNameUpperCase = lastNameUpperCase;
	}
	public String getIdNumber() {
		return idNumber;
	}
	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


}
