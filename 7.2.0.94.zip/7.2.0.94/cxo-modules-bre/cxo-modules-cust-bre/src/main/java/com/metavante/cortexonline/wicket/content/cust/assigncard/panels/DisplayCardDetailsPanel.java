/**
 * <hr>
 * <h4>Copyright Metavante Technologies Ltd.</h4>
 */
package com.metavante.cortexonline.wicket.content.cust.assigncard.panels;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.model.CompoundPropertyModel;
import org.apache.wicket.model.Model;
import com.fis.cortex.access.custid.view.Card;
import com.metavante.cortexonline.wicket.components.buttonbox.BoxedSubmitButton;
import com.metavante.cortexonline.wicket.components.buttonbox.ButtonBox;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowPanel;
import com.metavante.cortexonline.wicket.metadata.AcsInfo;

/**
 * Display Generated and Issued Card screen.
 * 
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/assigncard/panels/DisplayCardDetailsPanel.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
@AcsInfo(acsItem = "agn_crd_gen_display_card")
public class DisplayCardDetailsPanel extends WorkFlowPanel {

	private static final long serialVersionUID = -2913993034229551239L;
	private static Log logger = LogFactory.getLog(DisplayCardDetailsPanel.class);
	private static final String PAN_NUMBER="display_card_pan";
	private static final String CARD_PROD_LABEL="display_card_product";
	private static final String CARD_BATCH="display_card_batch";
	private static final String CONTINUE="display_card_continue";	
	
	private Card displayCardDetail;
	private Form<Void> form;
	private ButtonBox buttons;	
	private BoxedSubmitButton continueButton;
	private Label panNumberLabel;
	private Label panValue;
	private Label cardProductLabel;
	private Label  cardProductValue;
	private Label batchLabel;
	private Label batchValue;	

	// construction
	public DisplayCardDetailsPanel(Card card) {		
		this.setDefaultModel(new CompoundPropertyModel<DisplayCardDetailsPanel>(this));
		this.displayCardDetail=card;		
		this.form = new Form<Void>("form") {
			private static final long serialVersionUID = 1L;
			
			protected void onSubmit() {				
			}
		};
		this.form.setOutputMarkupId(true);
		this.form.setOutputMarkupPlaceholderTag(true);
		this.add(this.form);		
		this.addControls(this.form);
		this.addButtons(this.form);
		this.info(this.getString("display_card_msg"));
		logger.debug("Generated card details displayed");
		
	}
	
	private void addControls(WebMarkupContainer parent) {	
		this.panNumberLabel= new Label("panText",this.getString(PAN_NUMBER));
		parent.add(this.panNumberLabel);
		this.panValue= new Label("panValue",this.displayCardDetail.getPan());
		parent.add(this.panValue);				
		this.cardProductLabel= new Label("cardProductDisplayLabel", this.getString(DisplayCardDetailsPanel.CARD_PROD_LABEL));
		parent.add(this.cardProductLabel);		
		this.cardProductValue= new Label("cardProductValue", this.displayCardDetail.getCardProduct().getCardProduct());
		parent.add(this.cardProductValue);
		this.batchLabel= new Label("displayBatch", this.getString(DisplayCardDetailsPanel.CARD_BATCH));
		parent.add(this.batchLabel);		
		this.batchValue= new Label("displayBatchValue", this.displayCardDetail.getCardBatch());
		parent.add(this.batchValue);

	}

	private void addButtons(WebMarkupContainer parent)
	{
		this.buttons = new ButtonBox("buttons");		
		this.continueButton =new BoxedSubmitButton(new Model<String>(this.getString(CONTINUE))){
			private static final long serialVersionUID = 1L;			
			public void onSubmit(){
				DisplayCardDetailsPanel.this.complete(new AssignCardMainPanel.GoInstitutionSelection());
		     }		
		};
		this.continueButton.setOutputMarkupId(true);
		this.continueButton.setOutputMarkupPlaceholderTag(true);
		this.buttons.addButton(continueButton);		
		
		this.buttons.setOutputMarkupId(true);
		this.buttons.setOutputMarkupPlaceholderTag(true);
		parent.add(this.buttons);
	}	
	
}
