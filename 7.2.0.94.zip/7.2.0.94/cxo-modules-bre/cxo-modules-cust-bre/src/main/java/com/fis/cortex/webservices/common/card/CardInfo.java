package com.fis.cortex.webservices.common.card;

import java.util.Date;

public class CardInfo {
	
	private long cardId;
	private String PAN;
	private short seqNo;
	private String PANAlias;
	private Date expiryDate;
	
	public long getCardId() {
		return cardId;
	}
	public void setCardId(long cardId) {
		this.cardId = cardId;
	}
	public String getPAN() {
		return PAN;
	}
	public void setPAN(String pAN) {
		PAN = pAN;
	}
	public short getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(short seqNo) {
		this.seqNo = seqNo;
	}
	public String getPANAlias() {
		return PANAlias;
	}
	public void setPANAlias(String pANAlias) {
		PANAlias = pANAlias;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

}
