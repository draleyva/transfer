package com.fis.cortex.webservices.common.card;

import java.util.List;

public class CardAccounts {
	
	private CardInfo cardInfo;
	private List<AccountInfo> accountInfoList;
	
	public CardInfo getCardInfo() {
		return cardInfo;
	}
	public void setCardInfo(CardInfo cardInfo) {
		this.cardInfo = cardInfo;
	}
	public List<AccountInfo> getAccountInfoList() {
		return accountInfoList;
	}
	public void setAccountInfoList(List<AccountInfo> accountInfoList) {
		this.accountInfoList = accountInfoList;
	}

}
