package com.fis.cortex.transport.custid.exception;

public class CardAccountLinkingException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6125870709839977655L;
	
	
	public CardAccountLinkingException(){
		super();
	}
	
	public CardAccountLinkingException(String message){
		super(message);
	}


}
