/**
 * <hr>
 * <h4>Copyright Metavante Technologies Ltd.</h4>
 */
package com.metavante.cortexonline.wicket.content.cust.additionalcards;

import org.apache.wicket.PageParameters;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.spring.injection.annot.SpringBean;

import com.fis.cortex.transport.custid.services.CustomerService;
import com.metavante.cortex.transport.objects.core.Institution;
import com.metavante.cortexonline.wicket.BasePage;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlow;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowHolderPanel;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowManager;
import com.metavante.cortexonline.wicket.content.common.panels.SimpleSelectInstitutionPanel;
import com.metavante.cortexonline.wicket.content.cust.additionalcards.panels.AddAdditionalCardsMainPanel;
import com.metavante.cortexonline.wicket.metadata.AcsInfo;




/**
 * Add Additional Card Main Page
 * 
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/additionalcards/AdditionalCardsInstSelectionPage.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public class AdditionalCardsInstSelectionPage extends BasePage implements WorkFlow {

	private static final int STATE_FAILURE = -1;
	private static final int STATE_START = 0;
	private static final int STATE_INSTSELECTED = 1;
	

	// services

	// data
	protected Institution institution;

	// components
	private WorkFlowHolderPanel panel;
	private String institutionId;
	private String pan;
	@SpringBean(name = "transportCustomerIdService")
	private CustomerService customerService;
	

	// construction
	public AdditionalCardsInstSelectionPage(PageParameters parameters) {
		super(parameters);		
	    this.institutionId =parameters.getString("inst_id");
		this.pan =parameters.getString("pan");	
		this.add(this.panel = new WorkFlowHolderPanel("c"));
		this.panel.setWorkFlow(this, STATE_START);
	}

	@Override
	public PageInfo getPageInfo() {
		BasePage.PageInfo pageInfo = this.panel.getPageInfo();
		pageInfo.setPageTitle(getString("add_additional_card_pg"));
		pageInfo.addAcsItem("add_addin_card");
		pageInfo.addTitle(getString("add_additional_card_tl"));
		return pageInfo;
	}

	// workflow

	public void process(WorkFlowManager manager) {
		switch (manager.getState()) {
		case STATE_START:
			if(this.institutionId!=null&&this.pan!=null){
			  this.doMainWithInstitutionId(manager);
			}else{
			  this.doSelectInstitution(manager);
			}			
			break;
		case STATE_INSTSELECTED:
			this.doMain(manager);			
			break;
		default:
			manager.terminate();
			this.setResponsePage(com.metavante.cortexonline.wicket.HomePage.class);
			break;
		}
	}

	private void doSelectInstitution(WorkFlowManager manager) 
	{
		manager.setPanel(new SimpleSelectInstitutionPanel(new PropertyModel<Institution>(this, "institution")),
				STATE_INSTSELECTED, STATE_FAILURE);
	}
	
	private void doMainWithInstitutionId(WorkFlowManager manager) 
	{	
		
	    this.institution=customerService.getInstitution(this.institutionId);		
		manager.setPanel(new AddAdditionalCardsMainPanel(this.institution,this.pan), STATE_FAILURE, STATE_FAILURE);
	}

	private void doMain(WorkFlowManager manager) {
		manager.setPanel(new AddAdditionalCardsMainPanel(this.institution), STATE_FAILURE, STATE_FAILURE);
	}
}
