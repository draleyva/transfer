package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "AppTag")
@XmlAccessorType(XmlAccessType.FIELD)
public class ApplicationTag {
	
	@XmlElement(name = "TagId", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String tagId;
	@XmlElement(name = "TagValue", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String tagValue;

	public String getTagId() {
		return tagId;
	}
	public void setTagId(String tagId) {
		this.tagId = tagId;
	}
	public String getTagValue() {
		return tagValue;
	}
	public void setTagValue(String tagValue) {
		this.tagValue = tagValue;
	}
}
