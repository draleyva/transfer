package com.fis.cortex.transport.custid.exception;

import com.metavante.cortex.transport.exceptions.BusinessException;

public class GeneralSqlException extends BusinessException {
	
	/**
	 * This class throws exception when Hibernate Sql Exception is thrown
	 * @author schinnas
	 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/transport/custid/exception/GeneralSqlException.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
	 */
	private static final long serialVersionUID = 1L;
	
	public GeneralSqlException() {
		super();
	}


	public GeneralSqlException(String exception) {
		super(exception);
	}


}
