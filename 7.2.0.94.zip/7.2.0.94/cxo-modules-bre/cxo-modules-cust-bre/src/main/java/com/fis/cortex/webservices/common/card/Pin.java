package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "PIN")
@XmlAccessorType(XmlAccessType.FIELD)
public class Pin {
	
	@XmlElement(name = "KeyRef", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String keyReference;
	@XmlElement(name = "PINBlkFrmt", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private int pinBlockFormat;
	
	public String getKeyReference() {
		return keyReference;
	}
	public void setKeyReference(String keyReference) {
		this.keyReference = keyReference;
	}
	public int getPinBlockFormat() {
		return pinBlockFormat;
	}
	public void setPinBlockFormat(int pinBlockFormat) {
		this.pinBlockFormat = pinBlockFormat;
	}

}
