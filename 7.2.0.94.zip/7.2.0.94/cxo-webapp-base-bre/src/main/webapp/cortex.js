/*-------------------------------------------------------------
 *
 * File         : cortex.js
 *
 * Author       : James Noe / John Wilson
 *
 * Created      : April 2000
 *
 * Purpose      : Javascript functions for Cortex online.
 *
 * Comments     :
 *
 *-------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------*/

/*------------------------- CONSTANTS -----------------------*/

/*------------------------- GLOBALS -------------------------*/

// Message seperator for javascript intenationalization.
var messageSeparatorString = "|";
// Key seperator for javascript intenationalization.
var keySeparatorString = ":";
// Message string which carry the messages.
var messageString = "";

// Behaves as an associative array of open child windows
var childWins = new Object();

// turn on row highlights

var rowHighlight = true

// Dimensions of any child windows opened
var childWidth  = 845;
var childHeight = 500;

// Points to message window if open
var msgWin;

// Flags whether a page has finished loading completely
var loaded = false;

// Variable used to store the previous value of entered text

var currencyval = "";
//Variable to redefine the confirm and alert. Don't use this variable.
var cortex_confirm=window.confirm; //use just "confirm"
var cortex_alert=window.alert; // use just "alert"


/*------------------------- ALWAYS RUN ----------------------*/

// The following section of code is execute when the file is
// sourced
//if (!isAboveIE4())
//{
//    // If not using IE, then display this message
//    top.location.href="../interface/error.php3?code=netscape";
//}


/*------------------------- FUNCTIONS -----------------------*/

/*-------------------------------------------------------------
 *
 * Function     :  isNetscape
 *
 * Purpose      :  Checks to see if the browser is Netscape
 *
 * Parameters   :
 *
 * Returns      :  true if Netscape, false otherwise
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function isNetscape()
{
    return (navigator.appName.indexOf("Netscape") >= 0)?true:false;
}

/*-------------------------------------------------------------
 *
 * Function     :  isAboveIE4
 *
 * Purpose      :  Checks to see if browser is IE4, IE5 or above
 *
 * Parameters   :
 *
 * Returns      :  true if > IE4 false if <=IE3 or Netscape
 *
 * Comments     :  We use this as we only support IE - and IE3
 *                 isn't powerful enough
 *
 *-----------------------------------------------------------*/
function isAboveIE4()
{
    if (!isNetscape())
    {
        if (parseInt(navigator.appVersion) >= 4)
        {
            return true;
        }
    }
    return false;
}
/*-------------------------------------------------------------
*
* Function     :  Window.Confirm
*
* Purpose      :  Sets the mouse icon to default value if user click "cancel"
*
* Parameters   :  msg - the message to display
*
* Returns      :  Value of response of confirm
*
* Comments     :  
*
*-----------------------------------------------------------*/
window.confirm = function(msg)
{
  ret =cortex_confirm(msg);
  if(!ret)
	 {
		setDefaultCursor();
	 }
	return ret;
}
/*-------------------------------------------------------------
*
* Function     :  Window.Alert
*
* Purpose      :  Sets the mouse icon to default value if alert appears
*
* Parameters   :  msg - the message to display
*
* Returns      :  
*
* Comments     :  
*
*-----------------------------------------------------------*/
window.alert = function(msg)
{
	   cortex_alert(msg);
	   setDefaultCursor();
}

/*-------------------------------------------------------------
 *
 * Function     :  showStat
 *
 * Purpose      :  Puts a message in the status bar
 *
 * Parameters   :  str - the message to display
 *
 * Returns      :
 *
 * Comments     :  If the function is called with an empty string
 *                 then the function just displays "Nomad Software"
 *
 *-----------------------------------------------------------*/

function showStat(str)
{
    if(str == "")
    {
         str = "Fidelity National Information Services";
    }

    window.status = str;
}

/*-------------------------------------------------------------
 *
 * Function     :  automove
 *
 * Purpose      :  Moves the user to the next field
 *
 * Parameters   :  len    - the length of the string
 *                          upon which a move should take place
 *                 fld    - the field we're looking at
 *                 frm    - the form we're using
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function automove(len, fld, frm)
{
    var str = fld.value;

    if (str.length >= len)
    {
        var nextItem = getNextTabIndex(fld, frm);
        frm.elements[nextItem].focus();
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  getNextTabIndex
 *
 * Purpose      :  To find out the next tabbing element
 *
 * Parameters   :  fld    - the field we're looking at
 *                 frm    - the forme we're using
 *
 * Returns      :  next element (int elements[] array) for the
 *                 next tabindex = or 0
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function getNextTabIndex(fld, frm)
{
    var tab = fld.tabIndex + 1;

    for(count = 0; count < frm.elements.length; count++)
    {
        if (frm.elements[count].tabIndex == tab)
        {
            return count;
        }
    }
    return 0;
}

/*-------------------------------------------------------------
 *
 * Function     :  breakout_of_frame
 *
 * Purpose      :  Ensures that document is loaded in top frame
 *
 * Parameters   : 
 *
 * Returns      : boolean (false if window is already in top frame)
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
 
function breakout_of_frame()
{
  if (top.location != location) 
  {
	top.location.href = document.location.href ;
	return true;
  } else
  {
  	return false;
  }
}

/*-------------------------------------------------------------
 *
 * Function     :  addEl
 *
 * Purpose      :  Adds an element to a dropdown
 *
 * Parameters   :  dropdown - the field we're looking at
 *                 newText  - the text to add
 *                 newVal   - the value to add
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function addEl(dropdown, newText, newVal)
{
    var mySize = dropdown.length;

    dropdown.options[mySize] = new Option(newText, newVal);
}

/*-------------------------------------------------------------
 *
 * Function     :  delEl
 *
 * Purpose      :  Removes an element to a dropdown
 *
 * Parameters   :  dropdown - the field we're looking at
 *                 del      - the item to remove
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function delEl(dropdown, del)
{
    var len = dropdown.length - 1;

    if (len < 0)
    {
        alert("Error - the drop down is empty, you cannot perform " +
          "this action!");
        return false;
    }

    for (count = del; count < len; count++)
    {
        var theName = dropdown.options[count + 1].text;

        var theVal  = dropdown.options[count + 1].value;

        dropdown.options[count] = new Option(theName, theVal);
    }

    dropdown.options.length = len;

}

/*-------------------------------------------------------------
 *
 * Function     :  emptyDD
 *
 * Purpose      :  Empties a dropdown
 *
 * Parameters   :  dropdown - the field we're looking at
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function emptyDD(dropdown)
{
    dropdown.length = 0;
}

/*-------------------------------------------------------------
*
* Function     :  setWait
*
 * Purpose      :  Sets the mouse icon to waiting 
*
* Parameters   :  
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/
function setWaitCursor()
{
	document.body.style.cursor="wait";
}

/*-------------------------------------------------------------
*
* Function     :  setDefault
*
 * Purpose      :  Sets the mouse icon to default 
*
* Parameters   :  
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/
function setDefaultCursor()
{
	document.body.style.cursor="default";
}
/*-------------------------------------------------------------
 *
 * Function     : disableSelect
 *
 * Purpose      :  Disables a drop down
 *
 * Parameters   :  dropdown id
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function disableSelect(dropid)
{
    for (var i=0; i < document.all(dropid).options.length;
     i++)
        {
        if (document.all(dropid).options[i].value ==
        document.all(dropid).value)
                {
            /*Store the initial value and text descr */
            storeval = document.all(dropid).value;
            textval = document.all(dropid).options[i].text;
            /*Empty all from drop down */
            emptyDD(document.all(dropid));
            /*Put initial value and text back */
            addEl(document.all(dropid), textval, storeval);
            break;
                }
    }
    return;

}

/*-------------------------------------------------------------
 *
 * Function     :  highlight
 *
 * Purpose      :  Higlights the current field
 *
 * Parameters   :  fld - the field we're looking at
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function highlight(fld)
{
    switch (fld.className)
    {
    case "tabInput":
    case "tabSelect":
        // Hilight tabbed form inputs
        fld.className = "tabInputSelect";
        break;
    case "opSel":
        // Special case for hilighting report output options
        fld.className = "opSel";
        break;
    case "maskedfield":
    	// if the field is masked do not change anything
    	break;
    default:
        // Hilight untabbed form inputs
        fld.className = "inputSelect";
        break;
    }
    return;
}

/*-------------------------------------------------------------
 *
 * Function     :  unHighlight
 *
 * Purpose      :  Un Higlights the current field
 *
 * Parameters   :  fld - the field we're looking at
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function unHighlight(fld)
{
    switch (fld.className)
    {
    case "inputSelect":
        // Un-hilight untabbed form inputs
        fld.className = "INPUT";
        break;
    case "tabInputSelect":
        // Un-hilight tabbed form inputs
        fld.className = "tabInput";
        break;
    case "opSel":
        // Un-hilight report output option inputs
        fld.className = "opUnSel";
        break;
    case "maskedfield":
    	// if the field is masked do not change anything
    	break;
    }
    return;
}

/*-------------------------------------------------------------
 *
 * Function     :  changeRadio
 *
 * Purpose      :  Greys out the non-selected fields on the output
 *                 options for reports
 *
 * Parameters   :  activate - the to activate (unactivate the others)
 *
 * Returns      :
 *
 * Comments     :  Not generic - the fields have to have the names
 *                 specified in the function below....
 *
 *-----------------------------------------------------------*/
function changeRadio(activate)
{
    var pos=0;
    if(activate.indexOf("reset") >= 0)
    {
      while(pos < 3 && !document.forms[0].output[pos].checked) pos++;
      if(pos < 3)
      {
          activate = document.forms[0].output[pos].value;
      }
      else
      {
          activate = "printer";
      }
    }
    if (activate.indexOf("printer") >= 0)
    {
        document.forms[0].outputFile.disabled = true;
        document.forms[0].outputFile.readonly = true;
        document.forms[0].printer.disabled = false;
        document.forms[0].printer.readonly = false;
        document.forms[0].background.disabled = false;
        document.forms[0].background.readonly = false;
        mnd["printer"] = "true";
        mnd["outputFile"] = "false";
    }
    else if (activate.indexOf("file") >= 0)
    {
        document.forms[0].outputFile.disabled = false;
        document.forms[0].outputFile.readonly = false;
        document.forms[0].printer.disabled = true;
        document.forms[0].printer.readonly = true;
        document.forms[0].background.disabled = false;
        document.forms[0].background.readonly = false;
        mnd["printer"] = "false";
        mnd["outputFile"] = "true";
    }
    else
    {
        document.forms[0].outputFile.disabled = true;
        document.forms[0].outputFile.readonly = true;
        document.forms[0].printer.disabled = true;
        document.forms[0].printer.readonly = true;
        document.forms[0].background.disabled = true;
        document.forms[0].background.readonly = true;
        document.forms[0].background.checked = false;
        mnd["printer"] = "false";
        mnd["outputFile"] = "false";
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  statWindow
 *
 * Purpose      :  Opens a new window to display messages
 *
 * Parameters   :  op  - the data to go in the window
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function statWindow(op, close)
{
    var currentTime = new Date();
    var screenName = "msgWin" + currentTime.getHours() + "" + currentTime.getMinutes() + "" + currentTime.getSeconds();

    msgWin = window.open("", screenName, "toolbar=no,location=no," +
             "directories=no,status=no,menubar=no,scrollbars=no," +
             "resizable=no,width=200,height=310");
    msgWin.document.open()
    msgWin.document.write(header)

    var msg = "<SCRIPT language='JavaScript'>" +
    "document.title='CORTEX'</SCRIPT>";
    msgWin.document.write(msg);

    msgWin.document.write("<CENTER>");
    msgWin.document.write(op);
    msgWin.document.write("<BR><BR></B>");
    msgWin.document.write("<A HREF=\"javascript:window.close()\">");
    if (close)
    {
        msgWin.document.write("<CENTER>Close Window</CENTER></A>");
    }
    //  msgWin.document.close();
    msgWin.name = screenName;

    top.logo.msgWin = msgWin;
}

/*-------------------------------------------------------------
*  Function     :  showReport
*
* Purpose      :  Verifies if the result window should be shown
*
* Parameters   :  showReportFlag  - flag to verify if is to show the result window
*       reportContent   - report content
*
* Returns      :
*
* Comments     :
*  
*-----------------------------------------------------------*/
function showReport(showReportFlag,reportContent){
	if(showReportFlag==1){
		resWindow(reportContent);
	}
}

/*-------------------------------------------------------------
*
* Function     :  resWindow
*
* Purpose      :  Opens a new window to display results
*
* Parameters   :  op  - the data to go in the window
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/
function resWindow(op)
{
   var outputResults;
   var separator="/";
   var strarr;
   var contexroot;
   var command;
   var reportCommand = document.getElementsByName("rpCommand")[0].value;
   var reportEnvVars = document.getElementsByName("rpEnvVars")[0].value;   
   var reportParameters = document.getElementsByName("rpParameters")[0].value;   
   var reportOutputFile = document.getElementsByName("outputFile")[0].value;   
   var base= new String(document.URL);
   if(base){
	 strarr = base.split(separator,6);	   
	 contexroot=strarr[3];
	 if(strarr.length==5)
	 {
	    command =strarr[4];
	 }
	 else if(strarr.length>5)
	 {
		command =strarr[4]+separator+strarr[5];
	 }  
   }
   outputResults= new String(op);	
   outputResults=encodeURI(outputResults);   
   resWin = window.open("", "resWin", "toolbar=no,location=no," +
            "directories=no,status=yes,menubar=no,scrollbars=yes," +
            "resizable=yes,width=900,height=700");
   resWin.document.open();
   // when using wickets the context changes this validation is to get the
   // legacy resouces
   if (strarr[4]=="wicket"){ 
	   var rootUrl = "http://"+ strarr[2] + separator +  strarr[3] + separator; 
	   resWin.document.write("<HTML><HEAD><LINK REL=\"stylesheet\" HREF=" + rootUrl + "cortex.css ></HEAD>");
	   resWin.document.write("<script type=\"text/javascript\" src=" + rootUrl + "cortex.js ></script>");
   }else{ 
	   resWin.document.write(header);
	   resWin.document.write("<script type=\"text/javascript\" src=\"cortex.js\"></script>");
   }
   resWin.document.write("<BODY>");
   resWin.document.write("<FORM action=\""+separator+contexroot+separator+"saveToFile.do\">");
   resWin.document.write("<input type=\"hidden\" name=\"opResult\">");
   resWin.document.write("<input type=\"hidden\" name=\"rpCommand\">");
   resWin.document.write("<input type=\"hidden\" name=\"rpEnvVars\">");   
   resWin.document.write("<input type=\"hidden\" name=\"rpParameters\">");   
   resWin.document.write("<input type=\"hidden\" name=\"outputFile\">");   
   resWin.document.write("<input type=\"hidden\" name=\"acsitemCommand\" value=\""+command+"\" >");
   resWin.document.write("<H1>Results:</H1>");
   resWin.document.write("<CENTER><A HREF=\"javascript:window.print()\""
       + " onMouseOver=\"window.status='Print Results';return true;\""
       + " onMouseOut=\"window.status='CORTEX -  Results View';return true;\">"
       + "Print Results</A> &nbsp;&nbsp;"
       + "<A HREF=\"javascript:void(0);\" onclick=\"saveToFileReport('"+reportOutputFile+"','"+reportCommand+"','"+reportEnvVars+"','"+reportParameters+"');\""
		        + " onMouseOver=\"window.status='Save to File';return true;\""
		        + " onMouseOut=\"window.status='CORTEX -  Results View';return;\">"
       + " Save to File</A>"
       +"  <CENTER><HR></CENTER><PRE class='reportOutput'>");
   resWin.document.write(op);
   resWin.document.write("</PRE><P><HR><A HREF=\"javascript:window.print()\""
       + " onMouseOver=\"window.status='Print Results';return true;\""
       + " onMouseOut=\"window.status='CORTEX - Results View';return true;\">");
   resWin.document.write("<CENTER>");
   resWin.document.write("<A HREF=\"javascript:window.print()\" " +
             "onMouseOver=\"window.status='Print Results';" +
             "return true;\" onMouseOut=\"window.status='CORTEX -  " +
             "Results View';" +
             "return true;\">");
   resWin.document.write("<CENTER>Print Results</A>");

   // After JJA's complaining, the close window link at the top of
   // the results has been taken off to circumvent users prematurely
   // closing the window
   /*  resWin.document.write("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
   resWin.document.write("<A HREF=\"javascript:window.close()\" " +
   "onMouseOver=\"window.status='Close This Window';" +
   "return true;\" onMouseOut=\"window.status='CORTEX -  " +
   "Results View';" +
   "return true;\">");
   resWin.document.write("Close Window</CENTER></A><HR>");
   //resWin.document.close();
   */
   resWin.document.write("</CENTER><HR>");
   resWin.document.write("</FORM>");
   resWin.document.write("</BODY>");
   resWin.document.write("</HTML>");
   //Workaround to avoid IE to get frozen
   if((navigator.appVersion.indexOf("MSIE 7")!=-1) || (navigator.appVersion.indexOf("MSIE 8")!=-1) || (strarr[4]=="wicket")){
	   alert("Report generated successfully");
   }
   resWin.document.title = "CORTEX - Results";
   resWin.status = "CORTEX - Results View";
   resWin.document.close();
   resWin.focus();
}

/*-----------------------------------------------------------
 * Function :saveToFileReport
 * 
 * Purpose  : Clicking on link open a report output in the rpt file
 * 
 * Parameters : saves the reports output in a file
 * 
 * Returns :
 * 
 * Comments :
 */

function saveToFileReport(reportOutputFile, reportCommand, reportEnvVars, reportParameters){	
	document.forms[0].rpCommand.value=reportCommand;
	document.forms[0].rpEnvVars.value=reportEnvVars;
	document.forms[0].rpParameters.value=reportParameters;
	document.forms[0].outputFile.value=reportOutputFile;
	document.forms[0].method="post";
	document.forms[0].submit();
}

/*-----------------------------------------------------------
 * Function :saveToFile
 * 
 * Purpose  : Clicking on link open a report output in the rpt file
 * 
 * Parameters : saves the reports output in a file
 * 
 * Returns :
 * 
 * Comments :
 */

function saveToFile(op){	
	document.forms[0].opResult.value=decodeURI(op);	
	document.forms[0].method="post";
	document.forms[0].submit();
}
/*-------------------------------------------------------------
 *
 * Function     :  helpWindow
 *
 * Purpose      :  Opens a new window to display help
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function helpWindow(helpvar)
{
    // To Fix AT-0691
    var varHelpWin = helpvar + "Help.htm";
    helpWin = window.open(varHelpWin, "helpWin", "toolbar=no,location=no," +
              "directories=no,status=yes,menubar=no,scrollbars=yes," +
              "resizable=no,width=400,height=550");
    // The line below has been changed for the JSP version.
    //helpWin.location.href= helpvar + "Help.htm";
    helpWin.name = helpvar;


}

/*-------------------------------------------------------------
 *
 * Function     :  helpWindowLarge
 *
 * Purpose      :  Opens a new window to display help
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :  DMG NMR008656 - For main NovusHelp.htm
 *
 *-----------------------------------------------------------*/
function helpWindowLarge(helpvar, width, height)
{
    var varHelpWin = helpvar;
    var posX             = (screen.availWidth - width)/2;
    var posY       = (screen.availHeight - height)/2;
    helpWin = window.open(varHelpWin, "helpWin", "toolbar=no,location=no," +
             "directories=no,status=yes,menubar=no,scrollbars=yes," +
             "resizable=yes,width=" + width + ",height=" + height +
             ",left=" + posX + ",top=" + posY);
    // The line below has been changed for the JSP version.
    //helpWin.location.href= helpvar + "Help.htm";
    helpWin.name = helpvar;
}

/*-------------------------------------------------------------
 *
 * Function     :  logout
 *
 * Purpose      :  Logs out of cortex
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function logout(logoutpage)
{
    if (confirm("Are you sure you wish to logout of CORTEX-ONLINE ?"))
    {
        //tidyUp(true);
        top.location.href=logoutpage;
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  panseqrefresh
 *
 * Purpose      :  refresh screen if pan & seq is entered
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function panseqrefresh()
{
  var ar = panseqrefresh.arguments;
  var frm = window.document.forms[0];
  var actionpath = ar[0];
  var store = ar[1];
  
    if(store)
    {
     self.prevpan=frm.pan.value;
     self.prevseq=frm.seqno.value;
    } 
    else
    {
       if(self.prevpan!=frm.pan.value || self.prevseq!=frm.seqno.value || self.zoom)
       {
         self.zoom=0;
         var act = 'key1=&key2='+frm.pan.value+'&key3='+frm.seqno.value;
         var loc=document.location.href;
         var subloc=loc.lastIndexOf("/");
         redirectWithPostMethod(loc.substring(0,subloc) + "/" + actionpath, act);
       }
    }
}

/*-------------------------------------------------------------
 *
 * Function     : addkeys
 *
 * Purpose      : add keys to the given action
 *
 * Parameters   : first parameter is action itself (can be null or ''),
 *                second parameter is a screen to call, remaining parameters are keys
 * Returns      : redirects to specified screen with specified keys
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function addkeys()
{
  var ar = addkeys.arguments;
   var frm = window.document.forms[0];
   var act = (ar[0]!=null && ar[0]!='')?('formAction='+ar[0]):'';
   if(ar.length>1)
    {
      act = act + (act.length>0?('&key1='+ encodeURIComponent(ar[2])):('?key1='+ encodeURIComponent(ar[2])));
    }
   for(i=3;i<ar.length;i++)
    {
        act = act + ("&key" + (i-1)) + "=" + encodeURIComponent(ar[i]);
    }
    redirectWithPostMethod(ar[1], act);
}

/*-------------------------------------------------------------
 *
 * Function     :  home
 *
 * Purpose      :  Puts the user back to the home page
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function home()
{
    top.leftmenu.location.href="menu.jsp";
    top.main.location.href="welcome.html";
}

/*-------------------------------------------------------------
 *
 * Function     :  home
 *
 * Purpose      :  Puts the user back to the home page on the current frame only.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function goHome()
{
    window.location.href = "wicket/home";
}

/*-------------------------------------------------------------
 *
 * Function     :  tidyUp
 *
 * Purpose      :  Called when logging out to delete all
 *         cookies and close all child windows
 *
 * Parameters   :  logout   true if the logout button has
 *              been pressed, flase if this is
 *              being called due to the main
 *              window being closed
 *
 * Returns      :
 *
 * Comments     :  If you make any additions/changes here then
 *         change the php equivalent in logout.php3
 *
 *-----------------------------------------------------------*/
function tidyUp(logout)
{
    // close all child windows
    for (win in top.logo.childWins)
    {
        top.logo.childWins[win].close();
    }

    // close message window if open
    if (!(null == msgWin))
    {
        msgWin.close();
    }

    return;
}

/*-------------------------------------------------------------
 *
 * Function     :  warnReadonly
 *
 * Purpose      :  Called for readonly fields.  Allow copying
 *         of field but warn if editing
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function warnReadonly()
{
    if (!window.event.ctrlKey)
    {
        alert("Sorry, this field is protected - you cannot edit it");
    }

    return;
}

/*-------------------------------------------------------------
 *
 * Function     :  recDefVals
 *
 * Purpose      :  Called onLoad of a form to record the default
 *         values of all form fields.  This is used later
 *         on by the reset button and also by update btn
 *         to check which fields the user has changed
 *
 *         Also called if a DB update is successful
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function recDefVals()
{
    for (var i=0; i<non_hidden_types.length; i++)
    {
        if(document.forms[0][non_hidden_types[i]].type == "text" || document.forms[0][non_hidden_types[i]].type == "textarea")
        {
            document.forms[0][non_hidden_types[i]].value = RTrim(document.forms[0][non_hidden_types[i]].value);
        }
        
        /* DMG 2003/10/29 Treat select-multiple specially, record selected items
           in a seperate array
        */
        if(document.forms[0][non_hidden_types[i]].type == "select-multiple")
        {                  
            var multisel = new Array();
            var o = document.forms[0][non_hidden_types[i]];
            for (var n = 0; n < o.length; n++) {
                if (o[n].selected) {
                    multisel.push(o[n].value);
                }
            }           
            defVal[non_hidden_types[i]] = multisel;
        }
        else
        {
            if(document.forms[0][non_hidden_types[i]].type == "checkbox" || document.forms[0][non_hidden_types[i]].type == "radio")
        {
            //alert("here");
            defVal[non_hidden_types[i]] = document.forms[0][non_hidden_types[i]].checked;
            //alert("defVal for checkbox" + defVal[non_hidden_types[i]]);
        }
            else
            {
                defVal[non_hidden_types[i]] = document.forms[0][non_hidden_types[i]].value;
                //alert("defVal for others" + defVal[non_hidden_types[i]]);
            }
            
        }
        
    }
    
    return;
}


/*-------------------------------------------------------------
 *
 * Function     :  setValue
 *
 * Purpose      :  Used to set the value of form fields
 *
 * Parameters   :  name  - the name of the element who's
 *             value we're setting
 *
 *         val   - the value to set
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function setValue(name, val)
{
    obj = document.forms[0].all[name];

    // Set the value on the actual form
    if (obj.type == 'select_one')
    {
        // Set the selected option to the one passed in
        for (var i=0; i < obj.options.length; i++)
        {
            if (obj.options[i].value == val)
            {
                obj.options[i].selected = true;
                break;
            }
        }
    }
    else        // Normal input field
    {
       if (!obj.disabled)
        {
        obj.value = val;
         }
    }

    return;
}

/*-------------------------------------------------------------
 *
 * Function     :  updateBtn
 *
 * Purpose      :  This is the default fn called when the 'update' button
 *         on a form is pressed (or activated via its shortcut).
 *
 *         We first validate the form; if successful we
 *         flag all the fields which have actually been changed
 *         by the user the ask the user to confirm the operation
 *
 * Parameters   :
 *
 * Returns      :  true if form data is valid and user confirms the operation
 *         false otherwise
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function updateBtn()
{
    var ret = false;

    if (checkForm(document.forms[0]) && checkChanges(true))
    {
        // double check
        ret = confirm("Are you sure you want to update this record?");

        if (ret)
        {
            flagChanges();
        }
    }
    return ret;
}

/*-------------------------------------------------------------
 *
 * Function     :  addBtn
 *
 * Purpose      :  This is the default fn called when the 'add' button
 *         on a form is pressed (or activated via its shortcut).
 *
 *         We first validate the form and if successful ask the
 *         user to confirm the operation
 *
 * Returns      :  true if form data is valid and user confirms the operation
 *                  false otherwise
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function addBtn()
{
    var ret = false;

    if (checkForm(document.forms[0]))
    {
        // double check
        ret = confirm("Are you sure you want to add this record?");
    }
    return ret;
}

/*-------------------------------------------------------------
 *
 * Function     :  deleteBtn
 *
 * Purpose      :  This is the default fn called when the 'delete' button
 *                  on a form is pressed (or activated via its shortcut).
 *
 *                  Get the user to confirm the operation
 *
 * Parameters   :
 *
 * Returns      :  true if user confirms the operation
 *                  false otherwise
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function deleteBtn()
{
    var ret = false;

    // double check
    ret = confirm("Are you sure you want to permanently " +
                "delete this record?");

    return ret;
}

/*-------------------------------------------------------------
 *
 * Function     :  refreshBtn
 *
 * Purpose      :  This is the default fn called when the 'refresh' button
 *         on a form is pressed (or activated via its shortcut).
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function refreshBtn()
{
    var statusMsg=getMessage('keyconfirmrefresh');
    var actionMsg=getMessage('keyconfirmchanges');
    var msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;

    if (confirm(msg))
    {
        location.reload(true);
    }

    return;
}

/*-------------------------------------------------------------
 *
 * Function     :  searchBtn
 *
 * Purpose      :  This is the default fn called when the 'search' button
 *                  on a form is pressed (or activated via its shortcut).
 *
 *                  We first validate the form; if successful we
 *                  submit the form.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function searchBtn()
{
    if (checkForm(document.forms[0]))
    {
        document.forms[0].submit();
    }
    return;
}

/*-------------------------------------------------------------
 *
 * Function     :  gobackBtn
 *
 * Purpose      :  This is the default fn called when a button of
 *                  type 'go_back' is activated
 *
 * Parameters   :  inChildWin   true if button is activated from
 *              a form in a child browser window
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function gobackBtn(inChildWin)
{
    // check for changes
    if (confirmDirty())
    {
        if (inChildWin)
        {
            // close this window
            top.close();
        }
        else
        {
            document.forms[0].submit();
        }
    }
    return;
}

/*-------------------------------------------------------------
 *
 * Function     :  initWin
 *
 * Purpose      :  Called onLoad for windows being opened in a child
 *         window (BUTTON.action_newwin = "true")
 *
 *         Center the window on the screen
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function initWin()
{
    // center the window
    var x = (screen.availWidth - document.body.clientWidth)/2;
    var y = (screen.availHeight -document.body.clientHeight)/2;


    self.moveTo(x, y);
    /*JJA deleted this coz it was moving my windows to stupid positions*/

    return;
}

/*-------------------------------------------------------------
 *
 * Function     :  ctxAlert
 *
 * Purpose      :  Display a formatted alert to the user
 *
 * Parameters   :  statusMsg    a description of 'what has happened'
 *
 *         actionMsg    a description of 'what is about to
 *              happen' or 'what to do next'
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function ctxAlert(statusMsg, actionMsg)
{
    if (statusMsg != '' && actionMsg != '')
    {
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;
        alert(msg);
    }
    else if (statusMsg != '' || actionMsg != '')
    {
        msg = statusMsg + actionMsg;
        alert(msg);
    }

    return;
}
/*-------------------------------------------------------------
 *
 * Function     :  resetToDefaults
 *
 * Purpose      :  Reset search form fields to default values.
 *
 * Parameters   :  none
 *
 * Returns      :
 *
 * Comments     :  Assumes that the form has an array called
 *         defaults.
 *
 *-----------------------------------------------------------*/
function resetToDefaults()
{
    var elementLength = document.forms[0].elements.length;
    var arrayLength = defVal.length;
   
    for (var i=0; i<non_hidden_types.length; i++)
    {
        // DMG 2003/10/29 For multiple selection to replace original values
        if((document.forms[0][non_hidden_types[i]].type != "select-multiple") && (document.forms[0][non_hidden_types[i]].type != "checkbox") && (document.forms[0][non_hidden_types[i]].type != "radio"))
        {
            document.forms[0][non_hidden_types[i]].value = defVal[non_hidden_types[i]];
        }
		else if ((document.forms[0][non_hidden_types[i]].type == "checkbox") || (document.forms[0][non_hidden_types[i]].type == "radio"))
		{
   			document.forms[0][non_hidden_types[i]].checked = defVal[non_hidden_types[i]];	
		}
        else 
        {
            // new selections
            var nmsel = document.forms[0][non_hidden_types[i]];
            // original selections
            var omsel = defVal[non_hidden_types[i]];
            
            for (var j=0; j<nmsel.length; j++)
            {
                for (var k=0; k<omsel.length; k++)
                {                           
                    if(nmsel[j].value == omsel[k])
                    {
                        nmsel[j].selected = true;
                        break;
                    }                           
                }
                // Not found then deselect
                if(k == omsel.length)
                {
                    nmsel[j].selected = false;
                }
            }        
        }
    }
}


/*-------------------------------------------------------------
 *
 * Function     :  changeto
 *
 * Purpose      :  Used for the change the Row color on mouse over.
 *
 * Parameters   :  highlightcolor Variable which holds the color.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function changeto(highlightcolor)
{
    source=event.srcElement

    if (source.tagName=="TR"||source.tagName=="TABLE")
        return
    while(source.tagName!="TR")
        source=source.parentElement
    if (source.style.backgroundColor!=highlightcolor&&source.id!="ignore")
    {
        source.style.backgroundColor=highlightcolor
        source.style.cursor="hand"
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  changeback
 *
 * Purpose      :  Used for the change the Row color back to original color on mouse out.
 *
 * Parameters   :  originalcolor Variable which holds the color.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function changeback(originalcolor)
{
    if (event.fromElement.contains(event.toElement)||source.contains(event.toElement)||source.id=="ignore")
        return
    if (event.toElement!=source)
        source.style.backgroundColor=originalcolor
}

/*-------------------------------------------------------------
 *
 * Function     :  ZoomSearch
 *
 * Purpose      :  Used to popup the Zoom  Search window
 *
 * Parameters   :  textboxname Variable which holds the textbox name.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function ZoomSearch(parentformname,textboxname1,textboxname2,jspname)
{
    ZoomPanScreenSearch(parentformname,textboxname1,textboxname2,jspname);
}

/*-------------------------------------------------------------
 *
 * Function     :  zoomSelect
 *
 * Purpose      :  Used to populate the parent field with the selected value
 *
 * Parameters   :  formname Variable that holds the parent form name.
 *              :  textboxname Variable that holds the parent text box name.
 *              :  var1 Variable that holds the data value.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function zoomSelect(parentformname,textboxname1,textboxname2,var1,var2)
{
    var parentTextBox1 = eval("window.opener.document."+parentformname+"."+textboxname1);
    parentTextBox1.value = var1;
    var parentTextBox2 = eval("window.opener.document."+parentformname+"."+textboxname2);
    parentTextBox2.value = var2;
    parentTextBox1.focus();
    window.close();
}
/*-------------------------------------------------------------
 *
 * Function     :  zoomSelectTerm
 *
 * Purpose      :  Used to populate the parent field with the selected value
 *
 * Parameters   :  formname Variable that holds the parent form name.
 *              :  textboxname Variable that holds the parent text box name.
 *              :  var1 Variable that holds the data value.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function zoomSelectTerm(parentformname,textboxname1,var1,textboxname2,var2)
{
     var params = "";
     if(textboxname2 == null)
     {
        params = "parentFormName="+parentformname+"&parentTextBoxName1="+textboxname1;
     }
     else
     {
        params = "parentFormName="+parentformname+"&parentTextBoxName1="+textboxname1+"&parentTextBoxName2="+textboxname2;
     }
     screenZoomWin = openWindowWithPostMethod("zoomatmterminalssearchon.do", "zoomatmterminalssearchon", params, 
    		 "toolbar=no,location=no," + "directories=no,status=yes,menubar=no,scrollbars=yes," +
             "resizable=no,width=600,height=400");
     screenZoomWin.name = "zoomatmterminalssearchon";
}
/*-------------------------------------------------------------
 *
 * Function     :  zoomSelectTermret
 *
 * Purpose      :  Used to populate the parent field with the selected value
 *
 * Parameters   :  formname Variable that holds the parent form name.
 *              :  textboxname Variable that holds the parent text box name.
 *              :  var1 Variable that holds the data value.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function zoomSelectTermret(parentformname,textboxname,var1,textboxname1,var2)
{
    var parentTextBox = eval("window.opener.document."+parentformname+"."+textboxname);
    parentTextBox.value = var1;
    parentTextBox.focus();
    if (textboxname1 != "null")
    {
	   // Modified by Hari for EQA TR-01457
	    if(textboxname1 != "" && textboxname1 != undefined )
	    {
	        var parentTextBox1 = eval("window.opener.document."+parentformname+"."+textboxname1);
	        parentTextBox1.value = var2;
	        parentTextBox1.focus();
	    }
    }
    window.close();
}




/*-------------------------------------------------------------
 *
 * Function     :  Is Alpha Numeric
 *
 * Purpose      :  Checks for validity of data entered into the text
 *         fields in the Add/Update screens
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/



function isDigit(c)
{
    return ((c>="0") && (c<="9"));
}

// This Function checks whether the input is alphabetic or not
function isAlphabetic(c)
{
    //alert("return = " +  return ( ((c >= "a") && (c <= "z")) || ((c >= "A") && (c <= "Z")) ));
    return ( ((c >= "a") && (c <= "z")) || ((c >= "A") && (c <= "Z")) );
}



// This Function checks whether the input is alphanumeric or not

function isAlphaNumeric(s,f)
{
    statusMsg=getMessage('keyincorrectvals');
    var eValue = document.atmstatetbldetailfrm[f].value;
    var eValue1 = "";

    var eArr = eValue.split(" ");

    for(i=0;i<eArr.length;i++)
    {
        eValue1 = eValue1 + eArr[i];
    }

    if(eValue1 == "" && isNaN(eValue1))
    {
        actionMsg=getMessage('keyenternumeric');
        msg = "___________________________________________________" +
                    "\n\n" + statusMsg + "\n" +
                    "___________________________________________________" +
            "\n\n" + actionMsg;
        alert(msg);
        return false;
    }

    if(eValue1.length<3)
    {

        actionMsg=getMessage('keyenter3dignumeric');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;
        alert(msg);
        return false;
    }
}




/*-------------------------------------------------------------
 *
 * Function     :  navig_page().
 *
 * Purpose      :  Used for page navigation
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function navig_page(varaction)
 {
     enableDropdown();
     document.forms[0].formAction.value = 'search';
     document.forms[0].pageAction.value = varaction;
     document.forms[0].submit();
 }


/*-------------------------------------------------------------
 *
 * Function     :  confirm_navig().
 *
 * Purpose      :  Used for confirm navigation
 *
 * Parameters   :
 *
 * Returns      :  returns true if the navigation is valid else return false.
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function confirm_navig(varaction)
 {
    if(document.forms[0].totalItems.value == 0)
    {
       statusMsg=getMessage('keypageitemsnotfound');
       alert(statusMsg);
        return false;
    }
    if((varaction == 1) || (varaction == 3))
    {
        if(document.forms[0].pageBegin.value == 1)
        {
            statusMsg=getMessage('keypageitemsfirst');
            alert(statusMsg);
            return false;
        }

    }
    if((varaction == 2) || (varaction == 4))
    {
        if(document.forms[0].pageEnd.value == document.forms[0].totalItems.value)
        {
            statusMsg=getMessage('keypageitemslast');
            alert(statusMsg);
            return false;
        }

    }
    return true;
 }

/*-------------------------------------------------------------
 *
 * Function     :  confirm_navig_filtered().
 *
 * Purpose      :  Used for confirm navigation on filtered screens
 *
 * Parameters   :
 *
 * Returns      :  returns true if the navigation is valid else return false.
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function confirm_navig_filtered(varaction)
 {
    if(document.forms[0].totalItemsFiltered.value == 0)
    {
        statusMsg=getMessage('keypageitemsnotfound');
        alert(statusMsg);
        return false;
    }
    if((varaction == 1) || (varaction == 3))
    {
        if(document.forms[0].pageBeginFiltered.value == 1)
        {
            statusMsg=getMessage('keypageitemsfirst');
            alert(statusMsg);
            return false;
        }
    }
    if((varaction == 2) || (varaction == 4))
    {
        if(document.forms[0].pageEndFiltered.value == document.forms[0].totalItemsFiltered.value)
        {
            statusMsg=getMessage('keypageitemslast');
            alert(statusMsg);
            return false;
        }
    }
    return true;
 }

/*-------------------------------------------------------------
 *
 * Function     :  Cancel the operation
 *
 * Purpose      :
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
 function cancel(formname,operation)
 {
    enableDropdown();
    document.forms[formname].formAction.value = operation;
    document.forms[formname].submit();
 }



/*-------------------------------------------------------------
 *
 * Function     :  To go to the child detail screen.
 *
 * Purpose      : Will take to the specified field.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added for Iteration 3
 *
 *-----------------------------------------------------------*/
function gotoChildDetail(jspname)
{
    window.location.href=jspname;
}


/*-------------------------------------------------------------
 *
 * Function     :  To Go Back To Previous Screen
 *
 * Purpose      :  On Clicking on 'BACK' button user taken back to previous page
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function isback()
{
  
    var ar = isback.arguments;
    var ret = false;
    var str = ar[0];
    
    var param_add = ar[0].indexOf("?")==-1 ? "?": "&";
    
    
    // force conversion of element names to key1..keyn after unmasking
    str = str + param_add + "namesToKeys=true";
    
    // add the formAcsitem
    str = str + "&formAcsitem=" + document.forms[0].formAcsitem.value;
    
    if (DirtyFormcheck(true))
    {
        statusMsg=getMessage('keyrecsresetwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

        ret = confirm(msg);
    }
    else
    {
            for(i=1;i<ar.length;i++)
            {
            	if(!ar[i].name)
            	{
            		// we have a string
                	str = str + ("&key" + i) + "=" + encodeURIComponent(ar[i]);
                }
                else
                {
                	// we have an element
                	str = str + "&" + ar[i].name + "=" + encodeURIComponent(ar[i].value);
                }
            }
        redirectWithPostMethodUrl(str);
    }

    if(ret)
    {
        for(i=1;i<ar.length;i++)
            {
            	if(!ar[i].name)
            	{
            		// we have a string
                	str = str + ("&key" + i) + "=" + encodeURIComponent(ar[i]);
                }
                else
                {
                	// we have an element
                	str = str + "&" + ar[i].name + "=" + encodeURIComponent(ar[i].value);
                }
            }
        redirectWithPostMethodUrl(str);
    }
    else
    {
        return false;
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  SwMemberSwitchSelect
 *
 * Purpose      :  Used only in Fees Caluculated detail screen.
 *                 This is specific to this screen only.
 * Parameters   :  dofile,action,var1,var2,var3
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function SwMemberSwitchSelect(dofile,action,var1,var2,var3)
{
    var ret = false;
    var fe = eval("document.forms[0]."+var1+".value");
    var ferole = eval("document.forms[0]."+var2+".value");
    var sysdate = eval("document.forms[0]."+var3+".value");
    
   	// convert elements to keys after unmasking
   	var str = dofile+"?formAction="+action+"&fe="+fe+"&ferole="+ferole+"&sysdate="+sysdate;
   	str = str + "&namesToKeys=true&formAcsitem=" + document.forms[0].formAcsitem.value;
    
    if (DirtyFormcheck(true))
    {
        statusMsg=getMessage('keyrecsresetwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

        ret = confirm(msg);
    }
    else
    {  	
    	redirectWithPostMethodUrl(str);
    }

    if(ret)
    {
    	redirectWithPostMethodUrl(str);
    }
    else
    {
        return false;
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  BacktoFeesCal
 *
 * Purpose      :  Used to get back to Fee Cals scrren.
 *                 This is specific to Member and switch fees only.
 * Parameters   :  dofile,var1,var2,var3
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function BacktoFeesCal(dofile,var1,var2,var3)
{
    var ret = false;
    var fe = eval("document.forms[0]."+var1+".value");
    var ferole = eval("document.forms[0]."+var2+".value");
    var sysdate = eval("document.forms[0]."+var3+".value");
    
    // convert elements to keys after unmasking
    var str = dofile+"?formAction=edit&fe="+fe+"&ferole="+ferole+"&sysdate="+sysdate;
    str = str + "&namesToKeys=true&formAcsitem=" + document.forms[0].formAcsitem.value;
    
    if (DirtyFormcheck(true))
    {
        statusMsg=getMessage('keyrecsresetwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

        ret = confirm(msg);
    }
    else
    {
    	redirectWithPostMethodUrl(str);
    }

    if(ret)
    {
    	redirectWithPostMethodUrl(str);
    }
    else
    {
        return false;
    }
}



/*-------------------------------------------------------------
 *
 * Function     :  DirtyFormCheck
 *
 * Purpose      :  Compares the default record values with new values
 *                 if they mismatch true is returned
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function DirtyFormcheck()
{
    
    var elementLength = document.forms[0].elements.length;
    var j = 0;
    var popup = false;
    var checkbox = false;
    var list = 0;
    var my_message = "";
    
    if (!!window.formRepopulated)
    {
    	return true;
    }
    
    for (var i=0; i<non_hidden_types.length; i++)
    {
     	 
        //my_message = my_message + "[" + non_hidden_types[i] + "] = <" + defVal[non_hidden_types[i]] + "|" + document.forms[0][non_hidden_types[i]].value + ">\n";
    if((document.forms[0][non_hidden_types[i]].type != "select-multiple") && (document.forms[0][non_hidden_types[i]].type != "checkbox") && (document.forms[0][non_hidden_types[i]].type != "radio"))
    {
           
      	   //if (i > 30) {
           //	alert("Inside for loop");
           //	alert("DEF VAL=" +  defVal[non_hidden_types[i]]);
           //	alert("CURRENT VAL=" +  document.forms[0][non_hidden_types[i]].value);
        //   }
           if ( defVal[non_hidden_types[i]] != document.forms[0][non_hidden_types[i]].value)
           {
                popup = true;
            break;
            }
    }
    else if ((document.forms[0][non_hidden_types[i]].type == "checkbox") || (document.forms[0][non_hidden_types[i]].type == "radio"))
    {
           
           if ( defVal[non_hidden_types[i]] != document.forms[0][non_hidden_types[i]].checked)
           {
        popup = true;
        break;
       }
                  
       }
       else if(document.forms[0][non_hidden_types[i]].type == "select-multiple")
       {
            /* DMG 2003/10/29 check for dirty multiple selection */
            var o = defVal[non_hidden_types[i]]; 
            /*      
            for (var j = 0; j < o.length; j++) {
                my_message = my_message + "orig selected: " + (o[j]) + "\n";
            } 
            */
          
            var n = document.forms[0][non_hidden_types[i]]; 
            /*
            for (var j = 0; j < n.length; j++) {
                if (n[j].selected) 
                {
                    my_message = my_message + "new selected: " + (n[j].value) + "\n";
                }
            }
            */
            
            // create new array for the new selection
            var nmsel = new Array();
            for (var j = 0; j < n.length; j++) {
                if (n[j].selected) 
                {
                    nmsel.push(n[j].value);
                }
            }           
            
            // if different sizes then different selections
            if(o.length != nmsel.length) 
            {
                popup = true;
                break;
            } 
            else {
                // run through arrays to make sure they both have the same items selected
                for (var j = 0; j < o.length; j++) {
                    if(o[j] != nmsel[j]) 
                    {
                        popup = true;
                        break;
                    }
                }
            }
       
       }
       
       //alert("POPUP="+popup);
    }

    //alert("FINAL POPUP="+popup);
    
    return popup;
}
/*-------------------------------------------------------------
 *
 * Function     :  srchDirtyFormCheck
 *
 * Purpose      :  Compares the default search record values with new values
 *                 if they mismatch true is returned
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function srchDirtyFormcheck()
{

    var elementLength = document.forms[0].elements.length;
    var j = 0;
    var popup = false;


    for (name in srchdefaults)
    {
       if (srchdefaults[name] != document.forms[0][name].value)
       {
           popup = true;
       }
    }
    return popup;
}


/*-------------------------------------------------------------
 *
 * Function     :  SearchSelect
 *
 * Purpose      :  Used for the Edit window.
 *
 * Parameters   :  var Variable that holds the info of the selected row.
 *
 * Returns      :
 *
 * Comments     :  may receive Strings or Input elements
 *
 *-----------------------------------------------------------*/
function SearchSelect()
{
    var ar = SearchSelect.arguments;
    var param_add = ar[0].indexOf("?")==-1 ? "?": "&";
	var str = param_add+"formAction=edit";
	// force conversion of element names to key1 ... keyn after unmasking
    str = str + "&namesToKeys=true";

    for(i=1;i<ar.length;i++)
    {
    	// we need to check if the argument passed is a string or an element
    	if(!ar[i].name)
    	{    		
    		// we have a string
    		str = str + ("&key" + i) + "=" + encodeURIComponent(ar[i]);
    	}
    	else
    	{
    		// We have an element
    		str = str + "&" + ar[i].name + "=" + encodeURIComponent(ar[i].value);
    	}
    
    }
    
    if(document.forms[0].formAcsitem)
    {
    	// add on the acsitem passed 
    	str = str + "&formAcsitem=" + document.forms[0].formAcsitem.value;
    }
    setWaitCursor();
	redirectWithPostMethod(ar[0], str);
}

function backToAtmMaintenance()
{
    var ar = backToAtmMaintenance.arguments;
    var str = ar[0] + "?formAction=edit";
    
    // convert elements to keys after unmasking
    str = str + "&refcode="+ encodeURIComponent(document.forms[ar[1]].refcode.value);
    str = str + "&key2=backtoatm";
    str = str + "&namesToKeys=true&formAcsitem=" + document.forms[ar[1]].formAcsitem.value;
    redirectWithPostMethodUrl(str);
}

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Delete
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *                 when user clicks on Delete.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function delrec(formname,operation)
 {
    statusMsg=getMessage('keyrecsdelwishcont');
    actionMsg=getMessage('keydoyouwancontinue');
    msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;
    if(confirm(msg))
    {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
    else
        return false;
 }

   /*-------------------------------------------------------------
    *
    * Function     :  Confirmation On Add
    *
    * Purpose      :  Confirmation Message is displayed on the screen
    *                 when user clicks on Add.
    *                 This enables the Dropdown before Adding records as
    *                 values from the Disabled dropdowns cannot be submitted.
    *                 This is specific to Group decripsion detail screen only.
    *
    * Parameters   :
    *
    * Returns      :
    *
    * Comments     :
    *
    *-----------------------------------------------------------*/

    function updateusrrec(formname,operation,usrid)
    {
        var ret = false;
        //Added for AT-0152
        if(!DirtyFormcheck(true))
        {
            statusMsg=getMessage('keydirtyreadnot');
            alert(statusMsg);
        }


        if (checkForm(document.forms[0]) && DirtyFormcheck(true))
        {
            statusMsg=getMessage('keyrecsupdwishcont');
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
                "\n\n" + statusMsg + "\n" +
                "___________________________________________________" +
                "\n\n" + actionMsg;

            ret = confirm(msg);
       }
       document.usrgrpdescrfrm.usrgrp.value=usrid;
       if(ret)
       {
          enableDropdown();
          document.forms[formname].formAction.value = operation;
          document.forms[formname].submit();
       }
  }


/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Adding new record after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *         when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function newrec(formname,operation)
 {
    var ret = false;

   if (checkForm(document.forms[0]))
    {

        statusMsg=getMessage('keyrecsaddwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;
     ret = confirm(msg);
     }
    if(ret)
       {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
       }
 }
 
 function virtualPanNewrec(formname,operation)
 {
    var ret = false;
    document.forms[0].formAction.value = operation;
    if (virtualPanCheckForm(document.forms[0]))
    {
	    
        statusMsg=getMessage('keyrecsaddwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;
     ret = confirm(msg);
     }
    if(ret)
       {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
       }
 }
 
 /*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Delete
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *                 when user clicks on Bulk ATM Open, Bulk ATM Close.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function bulkatmconfirm(msg, operation)
 {
    if(confirm(msg))
    {
        enableDropdown();
        document.forms[0].formAction.value = operation;
        document.forms[0].submit();
    }
    else
        return false;
 }

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Adding new record after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *         when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function addCardLimitOverride(formname,operation)
 {
    var ret = false;
    var currVal = document.forms[formname].amount.value;
    if (checkForm(document.forms[0]) && currencyGtZero(currVal,document.forms[formname].amount))
    {
        statusMsg=getMessage('keyrecsaddwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;
     ret = confirm(msg);
     }
    if(ret)
       {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
       }
 }

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Adding new record after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *         when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function cancelCardLimitOverride(formname,operation)
 {
    var ret = false;

    statusMsg=getMessage('keycanceloverride');
    actionMsg=getMessage('keydoyouwancontinue');
    msg = "___________________________________________________" +
    "\n\n" + statusMsg + "\n" +
    "___________________________________________________" +
    "\n\n" + actionMsg;

    ret = confirm(msg);

    if(ret)
       {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
       }
 }

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Adding new record after checking the mandatory field and
                    checking amount Greater than 0.
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *         when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function newrecAmountGt0(formname,operation,amountfield)
{
    var field = eval("document.forms[0]."+amountfield);
    var ret = false;
        if (checkForm(document.forms[0]))
        {
            statusMsg=getMessage('keyrecsaddwishcont');
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n" +
            "___________________________________________________" +
            "\n\n" + actionMsg;
            ret = confirm(msg);
        }
        if(ret)
        {
            enableDropdown();
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
}

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Adding new record after checking the mandatory field

 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *         when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added for AT-TR180
 *
 *-----------------------------------------------------------*/

 function addZMK(formname,operation)
 {
    var ret = false;
    if (checkForm(document.forms[0]))
    {
        if(document.forms[0].keyPart1.value.length == 0 || document.forms[0].keyPart2.value.length == 0 || document.forms[0].keyPart3.value.length == 0)
        {
            statusMsg=getMessage('keyrecsgenwishcont');
            statusMsg2=getMessage('keyrecsgenwishcont2') + "\n";
        }
        else
        {
            statusMsg=getMessage('keyrecsaddwishcont');
            statusMsg2="";
        }
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" + statusMsg2 +
        "___________________________________________________" +
        "\n\n" + actionMsg;
        ret = confirm(msg);
    }
    if(ret)
    {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
 }


/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Adding new record for the key forms after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added for AT-TR180
 *
 *-----------------------------------------------------------*/

 function newZPKkeys(formname,operation,keylength,keyval)
 {
    var useExtTR31KeyBlocks = document.forms[0].useExtTR31KeyBlocks.value;
    if(("true"==useExtTR31KeyBlocks) ? checklengthWithTR31KBH(keylength,keyval) : checklength(keylength,keyval))
    {
    	addZPK(formname,operation);
    }
 }
/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Updating record for the key forms after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added for TR31 key block
 *
 *-----------------------------------------------------------*/

function updateZPKkeys(formname,operation,keylength,keyval)
{
    var useExtTR31KeyBlocks = document.forms[0].useExtTR31KeyBlocks.value;
    if(("true"==useExtTR31KeyBlocks) ? checklengthWithTR31KBH(keylength,keyval) : checklength(keylength,keyval))
    {
    	updateZPK(formname,operation);
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Adding new record for the key forms after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added for AT-TR180
 *
 *-----------------------------------------------------------*/

function newTMKTPKkeys(formname,operation,keylength,keyval)
{
   var flag = checklength(keylength,keyval);
   if(flag)
   {
       addTMKTPK(formname,operation);
   }
}

 /*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Adding new record after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *         when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added for AT-TR180
 *
 *-----------------------------------------------------------*/

 function addTMKTPK(formname,operation)
 {
    var ret = false;

    if (checkForm(document.forms[0]))
    {
        if(document.forms[0].tmkzmk.value.length == 0)
        {
            statusMsg=getMessage('keyrecsgenwishcont');
        }
        else
        {
            statusMsg=getMessage('keyrecsaddwishcont');
        }
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;
        ret = confirm(msg);
    }
    if(ret)
    {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
 }

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Adding new record for the key forms after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added for AT-TR180
 *
 *-----------------------------------------------------------*/

 function newTPKkeys(formname,operation,keylength,keyval)
 {
    var flag = checklength(keylength,keyval);
    if(flag)
    {
        addTPK(formname,operation);
    }
 }

 /*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Adding new record after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *         when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added for AT-TR180
 *
 *-----------------------------------------------------------*/

 function addTPK(formname,operation)
 {
    var ret = false;

    if (checkForm(document.forms[0]))
    {
        if(document.forms[0].tmkzmk.value.length == 0)
        {
            statusMsg=getMessage('keyrecsgenwishcont');
        }
        else
        {
            statusMsg=getMessage('keyrecsaddwishcont');
        }
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;
        ret = confirm(msg);
    }
    if(ret)
    {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
 }

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Updating record for the key forms after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added for AT-TR180
 *
 *-----------------------------------------------------------*/

 function updateTMKTPKkeys(formname,operation,keylength,keyval)
 {
     var flag = checklength(keylength,keyval);
     if(flag)
     {
         updateTMKTPK(formname,operation);
     }
 }

 /*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Update
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on update.
  *                 This enables the Dropdown before updating records as
  *                 values from the Disabled dropdowns cannot be submitted
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     : Added for AT-TR180
  *
  *-----------------------------------------------------------*/

  function updateTMKTPK(formname,operation)
  {
    var ret = false;

    if (checkForm(document.forms[0]))
    {
        if(document.forms[0].tmkzmk.value.length == 0)
        {
            statusMsg=getMessage('keyrecsgenwishcont');
        }
        else
        {
            statusMsg=getMessage('keyrecsupdwishcont');
        }
         actionMsg=getMessage('keydoyouwancontinue');
         msg = "___________________________________________________" +
             "\n\n" + statusMsg + "\n" +
             "___________________________________________________" +
             "\n\n" + actionMsg;

         ret = confirm(msg);
    }
    if(ret)
    {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
}

 /*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Update
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on update.
  *                 This enables the Dropdown before updating records as
  *                 values from the Disabled dropdowns cannot be submitted
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     : Added for AT-TR180
  *
  *-----------------------------------------------------------*/

  function updateZPK(formname,operation)
  {
    var ret = false;

    if (checkForm(document.forms[0]) && DirtyFormcheck(true))
    {
        if(document.forms[0].ZPKUnderKey.value.length == 0)
        {
            statusMsg=getMessage('keyrecsgenwishcont');
        }
        else
        {
            statusMsg=getMessage('keyrecsupdwishcont');
        }
         actionMsg=getMessage('keydoyouwancontinue');
         msg = "___________________________________________________" +
             "\n\n" + statusMsg + "\n" +
             "___________________________________________________" +
             "\n\n" + actionMsg;

         ret = confirm(msg);

    }
    if(ret)
    {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
}

/*-------------------------------------------------------------
    *
    * Function     :  SearchSelectATMStatuses
    *
    * Purpose      :  This method is Used for ATM Statuses Search Screen to Edit a record
                      by selecting the Primary keys.
    *
    * Parameters   :  var Variable that holds the info of the selected row.
    *
    * Returns      :
    *
    * Comments     : This can be used for other approp.screens also.
    *
    *-----------------------------------------------------------*/
    function SearchSelectATMStatuses()
    {
        var ar = SearchSelectATMStatuses.arguments;
        var str = ar[0] + "&formAction=edit";

        for(i=1;i<ar.length;i++)
        {
          str = str + ("&key" + i) + "=" + encodeURIComponent(ar[i]);
        }
        redirectWithPostMethodUrl(str);
    }

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Adding new record after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *         when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added for AT-TR180
 *
 *-----------------------------------------------------------*/

 function addZPK(formname,operation)
 {
    var ret = false;

    if (checkForm(document.forms[0]))
    {
        if(document.forms[0].ZPKUnderKey.value.length == 0)
        {
            statusMsg=getMessage('keyrecsgenwishcont');
        }
        else
        {
            statusMsg=getMessage('keyrecsaddwishcont');
        }
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;
        ret = confirm(msg);
    }
    if(ret)
    {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
 }

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Adding new record for the key forms after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function newreckeys(formname,operation,keylength,keyval)
 {
	var useKeyblocks = document.forms[0].useKeyBlocks.value;
    if(("true"==useKeyblocks) ? checklengthWithKBH(keylength,keyval) : checklength(keylength,keyval))
    {
        newrec(formname,operation);
    }
 }
/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Updating record for the key forms after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function updatereckeys(formname,operation,keylength,keyval)
{
	var useKeyblocks = document.forms[0].useKeyBlocks.value;
    if(("true"==useKeyblocks) ? checklengthWithKBH(keylength,keyval) : checklength(keylength,keyval))
    {
        updaterec(formname,operation);
    }
}
/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Authorising new record after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *                 when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function authorise(formname,operation)
{
    if(currencyGraterZero(document.forms[0].amount))
    {

        var ret = false;
        if (checkForm(document.forms[0]))
        {
            statusMsg=getMessage('keyrecsauthwishcont');
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n" +
            "___________________________________________________" +
            "\n\n" + actionMsg;
            ret = confirm(msg);
        }
        if(ret)
        {
            enableDropdown();
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
    }
}
/*-------------------------------------------------------------
 *
 * Function     :  currencyGraterZero
 *
 * Purpose      :  checks if thevalue is greater than zero.
 *
 * Parameters   :  vField
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function currencyGraterZero(vField)
{
    var vFieldVal = vField.value;

    for(var i=0;i<vFieldVal.length;i++)
    {
        if(!isDigit(vFieldVal.charAt(i)))
        {
            vFieldVal = vFieldVal.replace(vFieldVal.charAt(i) ,'');
        }
    }
   if(parseFloat(vFieldVal) <= 0)
   {
       //alert(getMessage('keyshouldbegreaterthanzero'));
       errMsg =  getMessage('keytexttag1')
                 + vFieldVal
                 + getMessage('keytexttag2');
       alertErr(errMsg);

       return false;

   }
   else
   {
       return true;
   }

}

 /*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Update
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on update.
  *                 This enables the Dropdown before updating records as
  *                 values from the Disabled dropdowns cannot be submitted
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function updaterecNoDirtyCheck(formname,operation)
  {
    var ret = false; 

    //Added for AT-0152
    if (checkForm(document.forms[0]))
    {
     statusMsg=getMessage('keyrecsupdwishcont');
     actionMsg=getMessage('keydoyouwancontinue');
     msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

     ret = confirm(msg);

     }
    if(ret)
       {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
       }
  }

 /*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Update
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on update.
  *                 This enables the Dropdown before updating records as
  *                 values from the Disabled dropdowns cannot be submitted
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function updaterec(formname,operation)
  {
    var ret = false;

    //Added for AT-0152
    if(!DirtyFormcheck(true))
    {
    statusMsg=getMessage('keydirtyreadnot');
    alert(statusMsg);
    }
    if (checkForm(document.forms[0]) && DirtyFormcheck(true))
    {
     statusMsg=getMessage('keyrecsupdwishcont');
     actionMsg=getMessage('keydoyouwancontinue');
     msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

     ret = confirm(msg);

     }
    if(ret)
       {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
       }
  }

  function updaterecVirtualPan()
  {
    var ret = false;

    //Added for AT-0152
    if(!DirtyFormcheck(true))
    {
    statusMsg=getMessage('keydirtyreadnot');
    alert(statusMsg);
    }
    if (virtualPanCheckForm(document.forms[0]) && DirtyFormcheck(true))
    {
     statusMsg=getMessage('keyrecsupdwishcont');
     actionMsg=getMessage('keydoyouwancontinue');
     msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

     ret = confirm(msg);

     }
    if(ret)
       {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
       }
  }

 /*-------------------------------------------------------------
  *
  * Function     :  Alert On User maintanance Update
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on update.
  *
  * Parameters   : formname
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function updateusrmaint(formname)
  {
   if((document.forms[formname].curruser.value==document.forms[formname].usr.value)&&(document.forms[formname].currgroup.value!=document.forms[formname].usrgrp.value))
   alert(getMessage('keyalertmess1'));
  }


 /*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Update
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on update.
  *                 This enables the Dropdown before updating records as
  *                 values from the Disabled dropdowns cannot be submitted
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function updateCardLimitOverride(formname,operation)
  {
    var ret = false;
    var currVal = document.forms[formname].amount.value;
    //Added for AT-0152
    if(!DirtyFormcheck(true))
    {
    statusMsg=getMessage('keydirtyreadnot');
    alert(statusMsg);
    }
    if (checkForm(document.forms[0]) && DirtyFormcheck(true) && currencyGtZero(currVal,document.forms[formname].amount))
    {
     statusMsg=getMessage('keyrecsupdwishcont');
     actionMsg=getMessage('keydoyouwancontinue');
     msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

     ret = confirm(msg);

     }
    if(ret)
       {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
       }
  }

 /*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Update for customer maintenance
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on update.
  *                 This enables the Dropdown before updating records as
  *                 values from the Disabled dropdowns cannot be submitted
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function updatereccustmaint(formname,operation)
  {
    var ret = false;

    //Added for AT-0152
    if(!DirtyFormcheck(true))
    {
    statusMsg=getMessage('keydirtyreadnot');
    alert(statusMsg);
    }
    var type=document.forms[0].typeid.value;
    if(type==2)
      {
            addFormData('dropdown', 'false', -1, 'Marital status', -1, 'married', '');
            addFormData('dropdown', 'false', -1, 'Sex', -1, 'sex', '');
      }

    if (checkForm(document.forms[0]) && DirtyFormcheck(true))
    {
     statusMsg=getMessage('keyrecsupdwishcont');
     actionMsg=getMessage('keydoyouwancontinue');
     msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

     ret = confirm(msg);

     }
    if(ret)
       {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
       }
  }


/*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Update
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on update.
  *                 This enables the Dropdown before updating records as
  *                 values from the Disabled dropdowns cannot be submitted
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     : Added for AT-TR180
  *
  *-----------------------------------------------------------*/

  function updateZMK(formname,operation)
  {
    var ret = false;

    //Added for AT-0152
    if(!DirtyFormcheck(true))
    {
    statusMsg=getMessage('keydirtyreadnot');
    alert(statusMsg);
    }


    if (checkForm(document.forms[0]) && DirtyFormcheck(true))
    {
        if(document.forms[0].keyPart1.value.length == 0 || document.forms[0].keyPart2.value.length == 0 || document.forms[0].keyPart3.value.length == 0)
        {
            statusMsg=getMessage('keyrecsgenwishcont');
            statusMsg2=getMessage('keyrecsgenwishcont2') + "\n";
        }
        else
        {
            statusMsg=getMessage('keyrecsupdwishcont');
            statusMsg2="";
        }
         actionMsg=getMessage('keydoyouwancontinue');
         msg = "___________________________________________________" +
             "\n\n" + statusMsg + "\n" + statusMsg2 +
             "___________________________________________________" +
             "\n\n" + actionMsg;

         ret = confirm(msg);

    }
    if(ret)
    {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
}


  /*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Update
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on update. This function checks
                    whether the amount is greater than 0
  *                 This enables the Dropdown before updating records as
  *                 values from the Disabled dropdowns cannot be submitted
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

function updateAmountGt0(formname,operation,amountfield)
{
    var field = eval("document.forms[0]."+amountfield);
    if(currencyGraterZero(field))
    {
        var ret = false;
        //Added for AT-0152
        if(!DirtyFormcheck(true))
        {
        statusMsg=getMessage('keydirtyreadnot');
        alert(statusMsg);
        }

        if (checkForm(document.forms[0]) && DirtyFormcheck(true))
        {
            statusMsg=getMessage('keyrecsupdwishcont');
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
             "\n\n" + statusMsg + "\n" +
             "___________________________________________________" +
             "\n\n" + actionMsg;

            ret = confirm(msg);

        }
        if(ret)
        {
            enableDropdown();
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
    }
}



    /*--------------------------------------------------------------------
    *
    * Function     :  Confirmation On Update for Host Interface Management.
    *                 It performs extra validation for date if Balance Import is choosen.
    *
    * Purpose      :  Confirmation Message is displayed on the screen
    *                 when user clicks on update.
    *                 This enables the Dropdown before updating records as
    *                 values from the Disabled dropdowns cannot be submitted
    *
    * Parameters   :  formname - form name,operation - like add,update
    *                  and optionimpordate - option number for import date.
    *
    * Returns      :
    *
    * Comments     :
    *
    *----------------------------------------------------------------------*/

    function updatehostinterfmgmtrecord(formname,operation,enableLogSignOffEvents)
    {
        var ret = false;

        var menuopt = eval("document." + formname + ".menuopt");
        var importdate = eval("document." + formname + ".importdate");
        var hostname = document.forms[formname].hostname.value;

        var sendtomsg = (menuopt[2].checked || menuopt[6].checked || menuopt[7].checked || menuopt[8].checked);

        //Check for menu option selected, If Balance Import is choosen then
        //force the user to enter Balance Import date.
        if(menuopt[1].checked == true)
        {
            if(importdate.value == "")
            {
                alert(getMessage('keyenterimportdate'));
                importdate.focus();
                return;
            }
        }

        if (checkForm(document.forms[0]) )
        {

            if(menuopt[3].checked == true)
            {
                statusMsg=getMessage('keynavigatetowishcont');
            }
            else if(sendtomsg)
            {
                statusMsg=getMessage('keyrecsupdwishcont2') + " " + hostname ;
            }
            else
            {
                statusMsg=getMessage('keyrecsupdwishcont');
            }
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n" +
            "___________________________________________________" +
            "\n\n" + actionMsg;

            ret = confirm(msg);

        }
        if(ret)
        {
            enableDropdown();

            document.forms[formname].formAction.value = operation;

            if(menuopt[3].checked == true)                      //If View upload table
            {
                var hostname = document.forms[formname].hostname.value;
                document.forms[formname].action = "IaUploadTransactionsSearch.jsp?fromwhere=fromhost&HostName="+hostname;
            }

            if(menuopt[8].checked == true)
            {
                if(enableLogSignOffEvents == true)
                {
                    var acceptLogSignOffEvents = false;
                    promptMsg = "Is this ok to timestamp current operation?";
                    acceptLogSignOffEvents = confirm(promptMsg);
                    if(acceptLogSignOffEvents)
                    {
                        document.forms[formname].formAction.value = "update1";
                    }
                }
            }

            document.forms[formname].submit();
        }
    }

    /*----------------------------------------------------------------------------
    *
    * Function     :  isUploadback
    *
    * Purpose      :  Function called from upload transactions screen
    *
    * Parameters   :
    *
    * Returns      :
    *
    * Comments     :  Back button functionality implemented by Vinay on 23/12/2002
    *
    *-----------------------------------------------------------------------------*/
    function isUploadback()
    {
        var Hostname = document.forms[0].hostname.value;
        redirectWithPostMethod("iahostinterfacemgmtdetailson.do", "formAction=edit&hostname="+Hostname);
    }


    /*----------------------------------------------------------------------------
    *
    * Function     :  To change the button label at run time for host interface mgmt.
    *
    * Purpose      :  This function is used to change the label from "Update"
    *                 to "ViewUpload" and vise versa. ViewUpload to
    *                 navigate to IaUploadTransactionsSearch.jsp.
    *
    * Parameters   : 0 - Updaet and 1 - ViewUpload
    *
    * Returns      :
    *
    * Comments     :
    *
    *-----------------------------------------------------------------------------*/
    function callviewupload(yes)
    {

        if(yes == 0)
        {

            document.forms[0].updatebutton.value="Update";

        }
        else
        {
            document.forms[0].updatebutton.value="ViewUpload";
        }


    }

    /*--------------------------------------------------------------------
    *
    * Function     :  Custom update which displayes custom message with
    *                 host name taken from the form.
    * Purpose      :  Confirmation Message is displayed on the screen
    *                 when user clicks on update.
    *                 This enables the Dropdown before updating records as
    *                 values from the Disabled dropdowns cannot be submitted
    *
    * Parameters   :
    *
    * Returns      :
    *
    * Comments     :
    *
    *----------------------------------------------------------------------*/
    function updatehostdetailrecord(formname,operation)
    {
        var ret = false;
        var hostname = document.forms[formname].hostname.value;
        if (checkForm(document.forms[0]) )
        {
            statusMsg=getMessage('keyrecsupdwishcont');
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
            "\n\n" + statusMsg + " " + hostname + "\n" +
            "___________________________________________________" +
            "\n\n" + actionMsg;
            ret = confirm(msg);
        }
        if(ret)
        {
            enableDropdown();
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
    }

  /*-------------------------------------------------------------
  *
  * Function     :  No confirm and Update
  *
  * Purpose      :  No confirm and Update
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function updaterecnoconfirm(formname,operation)
  {
    var ret = false;
    if (checkForm(document.forms[0]) )
    {
         statusMsg1=getMessage('keyopercomplete');
         statusMsg2=getMessage('keydonotleave');
         actionMsg=getMessage('keydoyouwancontinue');
         msg = "___________________________________________________" +
             "\n\n" + statusMsg1 + "\n" +
             "\n" + statusMsg2 + "\n" +
             "___________________________________________________" +
             "\n\n" + actionMsg;
         ret = confirm(msg);
    }
    if(ret)
    {
    	 enableDropdown();
         document.forms[formname].formAction.value = operation;
         document.forms[formname].submit();
    }
  }


 /*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Reset
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *         when user clicks on update.
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function resetchk()
  {
    var ret = false;
    if (DirtyFormcheck(true))
    {
         statusMsg=getMessage('keyrecsresetwishcont');
         actionMsg=getMessage('keydoyouwancontinue');
         msg = "___________________________________________________" +
             "\n\n" + statusMsg + "\n" +
             "___________________________________________________" +
             "\n\n" + actionMsg;

         ret = confirm(msg);
     }
     if(ret)
     {
            var elementLength = document.forms[0].elements.length;
            var arrayLength = defVal.length;
           
            for (var i=0; i<non_hidden_types.length; i++)
            {
                // DMG 2003/10/29 For multiple selection to replace original values
                if((document.forms[0][non_hidden_types[i]].type != "select-multiple") && (document.forms[0][non_hidden_types[i]].type != "checkbox") && (document.forms[0][non_hidden_types[i]].type != "radio"))
                {
                    document.forms[0][non_hidden_types[i]].value = defVal[non_hidden_types[i]];
                }
    			else if ((document.forms[0][non_hidden_types[i]].type == "checkbox") || (document.forms[0][non_hidden_types[i]].type == "radio"))
    			{
           			document.forms[0][non_hidden_types[i]].checked = defVal[non_hidden_types[i]];	
				}
                else 
                {
                    // new selections
                    var nmsel = document.forms[0][non_hidden_types[i]];
                    // original selections
                    var omsel = defVal[non_hidden_types[i]];
                    
                    for (var j=0; j<nmsel.length; j++)
                    {
                        for (var k=0; k<omsel.length; k++)
                        {                           
                            if(nmsel[j].value == omsel[k])
                            {
                                nmsel[j].selected = true;
                                break;
                            }                           
                        }
                        // Not found then deselect
                        if(k == omsel.length)
                        {
                            nmsel[j].selected = false;
                        }
                    }        
                }
            }
      }
      else
      {
            return false;
      }
  }

  /*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Reset to blank values
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *         when user clicks on update.
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function resetToBlankValues()
  {
	     var ret = false;
	     statusMsg=getMessage('keyrecsresetwishcont');
	     actionMsg=getMessage('keydoyouwancontinue');
	     msg = "___________________________________________________" +
	         "\n\n" + statusMsg + "\n" +
	         "___________________________________________________" +
	         "\n\n" + actionMsg;

	     ret = confirm(msg);
	     if(ret)
	     {
            for (var i=0; i<non_hidden_types.length; i++)
            {
                if((document.forms[0][non_hidden_types[i]].type != "select-multiple") && (document.forms[0][non_hidden_types[i]].type != "checkbox") && (document.forms[0][non_hidden_types[i]].type != "radio"))
                {
                    document.forms[0][non_hidden_types[i]].value = "";
                    defVal[non_hidden_types[i]]="";
                }
    			else if ((document.forms[0][non_hidden_types[i]].type == "checkbox") || (document.forms[0][non_hidden_types[i]].type == "radio"))
    			{
           			document.forms[0][non_hidden_types[i]].checked = "";	
                    defVal[non_hidden_types[i]]="";
				}
                else 
                {
           			document.forms[0][non_hidden_types[i]].checked = false;	
                    defVal[non_hidden_types[i]]="";
                }
            }
         }
  }

  /*-------------------------------------------------------------
  *
  * Function     :  Will Reset the data.
  *
  * Purpose      :  Will Reset the data.
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function resetsearch()
  {

     var elementLength = document.forms[0].elements.length;
     var arrayLength = defVal.length;
     var j = 0;

     for (var i=0; i<non_hidden_types.length; i++)
     {
        document.forms[0][non_hidden_types[i]].value = defVal[non_hidden_types[i]];
     }

  }


 /*-------------------------------------------------------------
  *
  * Function     :  Enable the Drop downs
  *
  * Purpose      :  This functions enables the drop downs
  *
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function enableDropdown()
  {
     for (var i=0; i<non_hidden_types.length; i++)
     {
        if (document.forms[0].elements[non_hidden_types[i]].disabled)
        {
            document.forms[0].elements[non_hidden_types[i]].disabled = false;
        }
     }
     
  }

  /*-------------------------------------------------------------
  *
  * Function     :  Custom update which displayes custom message with
  *                 host name taken from the form.
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on update.
  *                 This enables the Dropdown before updating records as
  *                 values from the Disabled dropdowns cannot be submitted
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/
  function updatescreen(formname,operation)
  {
        var ret = false;
        if (checkForm(document.forms[0]))
        {
            statusMsg=getMessage('keyrecsupdwishcont');
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
             "\n\n" + statusMsg + "\n" +
             "___________________________________________________" +
             "\n\n" + actionMsg;

            ret = confirm(msg);
        }
        if(ret)
        {
            enableDropdown();
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
 }

  function gotoTmkScreen(formname)
  {
	  	redirectWithPostMethod("aatmkmaintsearchon.do", "formAction=fromatm&termcode="+document.forms[formname].termcode.value);
  }


  /*-------------------------------------------------------------
   *
   * Function     :  For Highlighting the particular record

   * Purpose      :

   * Parameters   :
   *
   * Returns      :
   *
   * Comments     :
   *
   *-----------------------------------------------------------*/

    function getElement(el)

   {
        var tagList = new Object
        for (var i = 1; i < arguments.length; i++)
        tagList[arguments[i]] = true
        while ((el!=null) && (tagList[el.tagName]==null))
        el = el.parentElement
        return el
    }

    function checkHighlight(which)
    {
        var el = getElement(event.srcElement,"TH","TD")
        if (el==null) return
        if ((el.tagName=="TH") && (colHighlight))

            {

            var idx = el.cellIndex
            var table = getElement(el, "TABLE")
            var column = table.all.tags("COL")[idx]
            if (which)
            column.className="cover"
            else
            column.className=""

            }
        if ((el.tagName=="TD") && (rowHighlight))

            {

            var row = getElement(el, "TR")
            var table = getElement(row, "TABLE")
            if (which)
            row.className = "rover"
            else
            row.className = ""
            cache = row

            }
    }

  /*-------------------------------------------------------------
   *
   * Function     :  For separating the messages.

   * Purpose      :

   * Parameters   :
   *
   * Returns      :
   *
   * Comments     :
   *
   *-----------------------------------------------------------*/

    function MessageSeparator()
    {
        var messageToSeparate = messageString;
        var message = "";
        var ar = MessageSeparator.arguments;
        if(ar.length > 0)
        {
            messageToSeparate = ar[0];
        }
        else
        {
            messageToSeparate = messageString;
        }
        if((window.messageSeparatorString) && (messageSeparatorString != null) && (messageSeparatorString != ""))
        {
            message = messageToSeparate.split(messageSeparatorString);
        }
        else
        {
            message = messageToSeparate.split("|");
        }
        for(i=0;i<message.length;i++)
        {
            if((message[i] != null) && (message[i] != ""))
            {
                KeySeparator(message[i]);
            }
        }
    }

  /*-------------------------------------------------------------
   *
   * Function     :  For separating the key and messages..

   * Purpose      :

   * Parameters   :
   *
   * Returns      :
   *
   * Comments     :
   *
   *-----------------------------------------------------------*/
    function KeySeparator()
    {
        var keys = "";
        var ar = KeySeparator.arguments;
        if(ar.length <= 0)
        {
            return;
        }
        else
        {
            if((window.keySeparatorString) && (keySeparatorString != null) && (keySeparatorString != ""))
            {
                keys = ar[0].split(keySeparatorString);
            }
            else
            {
                keys = ar[0].split(":");
            }

            eval('window.' + keys[0] + ' = "' + keys[1] + '"');
        }
    }


  /*-------------------------------------------------------------
   *
   * Function     :  For getting the messages for the given key.

   * Purpose      :

   * Parameters   :
   *
   * Returns      :
   *
   * Comments     :
   *
   *-----------------------------------------------------------*/
    function getMessage()
    {
        var ar = getMessage.arguments;
        if(eval('window.' + ar[0]))
        {
            return(eval(ar[0]));
        }
        else
        {
            return( ar[0] +" : Key does not have message provided.");
        }
    }

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Adding new record after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *         when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function newkeyrec(formname,operation)
 {
    var ret = false;
    var value = '';

           var len = document.forms[formname].elements.length;
             for(i=0;i<len;i++)
             {
                 if(document.forms[formname].elements[i].name == "tmkzmk")
                 {
                     value = document.forms[formname].elements[i].value;
                 }
             }

      if (checkForm(document.forms[0]))
       {
            if (value =="")
            {
                msg = getMessage('keynewkeygeneration');
                msg = msg + "\n\n" +"___________________________________________________"
            }
            else
            {
                statusMsg=getMessage('keyrecsaddwishcont');
                actionMsg=getMessage('keydoyouwancontinue');
                msg = "___________________________________________________" +
                "\n\n" + statusMsg + "\n" +
                "___________________________________________________" +
                "\n\n" + actionMsg;
            }
            ret = confirm(msg);
       }

    if(ret)
       {
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
       }
 }


/*-------------------------------------------------------------
 *
 * Function     :  zoomSelectAcs
 *
 * Purpose      :  Used to populate the parent field with the selected value
 *                  This is made redundant and internally will call ZoomSearchEncoderConf().
 * Parameters   :  formname Variable that holds the parent form name.
 *              :  textboxname Variable that holds the parent text box name.
 *              :  var1 Variable that holds the data value.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function zoomSelectAcs(parentformname,textboxname,var1)
{
    ZoomSearchEncoderConf(parentformname,textboxname,'ZoomAccessItems.jsp');
}



/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Searching
 *
 * Purpose      :
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function searchrec()
 {
    if (checkForm(document.forms[0]))
    {
      enableDropdown();
      document.forms[0].formAction.value = 'search';
      document.forms[0].submit();
     }
 }


 function searchrecVirtualPan()
 {
    if (virtualPanCheckForm(document.forms[0]))
    {
      enableDropdown();
      document.forms[0].formAction.value = 'search';
      document.forms[0].submit();
     }
 }
 
 /*-------------------------------------------------------------
 *
 * Function     :  searchActionRspCheck
 *
 * Purpose      :  Used to search after performing a check on the action code and Responce code
 *
 * Parameters   :  
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function searchCriteriaCheck()
{
	//indexed columns sysdate, id, pan, aiid, indaterec, outdaterec, rrn, acnum1 ,afe
	// strid ,sysDate, pan,msAcqierId,rrn,termcode,strdatelocal,msCardAcceptorCode
	
	var indexcolsVals = new Array(5);
	var empty = true;
	var ret = true;
	indexcolsVals[0] = Trim(document.forms[0].strid.value);
	indexcolsVals[1] = Trim(document.forms[0].sysDate.value);
	indexcolsVals[2] = Trim(document.forms[0].pan.value);
	indexcolsVals[3] = Trim(document.forms[0].msAcqierId.value);
	indexcolsVals[4] = Trim(document.forms[0].rrn.value);
    indexcolsVals[5] = Trim(document.forms[0].virtualPan.value);
	
	for(i=0;i<indexcolsVals.length;i++)
    {
		if ( indexcolsVals[i].length != 0 )
        {   
        	empty = false;
        	break;
        }
    }
	
	if (empty)
	{
		ret = confirm(getMessage('keyindexcolsempty'));
	}

	if (ret)
	{
		searchActionRspCheck();
    }
}

function searchActionRspCheck()
{
	    if( Trim(document.forms[0].rspcode.value) !=  '' )
	    {
	        if(Trim(document.forms[0].actioncode.value) !=  '' && Trim(document.forms[0].actioncode.value) !=  '-1' )
	        {
	            if( Trim(document.forms[0].rspcode.value).charAt(0) != Trim(document.forms[0].actioncode.value).charAt(0))
	            {
	                statusmsg=getMessage('keyplstryagain1');
	                statusmsg1=getMessage('keyplstryagain2');
	                statusmsg2=getMessage('keyactionrsp');
	                msg = "___________________________________________________" +
	                      "\n\n" + statusmsg + "\n" + statusmsg1 + "\n" +
	                      "___________________________________________________" +
	                      "\n\n" + statusmsg2;
	
	                alert(msg);
	                return false;
	            }
	        }
	    }
	    searchrec();
}

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Batch Searching
 *
 * Purpose      :
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function batchsearchrec()
 {
    if (checkForm(document.forms[0]))
    {
      document.forms[0].formAction.value = 'search';
      document.forms[0].submit();
     }
 }


/*-------------------------------------------------------------
 *
 * Function     :  cardAccount
 *
 * Purpose      :  Used for checking condition & displaying message.
 *
 * Parameters   :  var Variable that holds the check conditions.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function cardAccount(var1,var2)
{

    if(var1 == '3' && var2 == '2')
        alert(getMessage('keycorpchrgacc'));
    else if(var1 == '3' && var2 != '2')
        alert(getMessage('keychaccenq'));
    else if(var1 != '3')
        alert(getMessage('keyaccdet'));

}


/*-------------------------------------------------------------
  *
  * Function     :  ZoomCardAccnoSearch
  *
  * Purpose      :  Used to popup the Zoom  Search window
  *
  * Parameters   :  textboxname Variable which holds the textbox name.
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/
  function ZoomCardAccnoSearch(parentFormName,parentTextBoxName1,formAction,jspname,fromwhere)
  {

      var screenName = jspname;
      var dec = screenName.indexOf(".");
      if(dec > 0)
      {
          screenName =  screenName.substring(0,dec);
      }
      var params = "parentFormName=" + parentFormName + "&parentTextBoxName1=" + parentTextBoxName1 
      				+ "&formAction=" + formAction + "&fromwhere=" + fromwhere;
      screenZoomWin = openWindowWithPostMethod(jspname, screenName, params, "toolbar=no,location=no," +
              "directories=no,status=yes,menubar=no,scrollbars=yes," + "resizable=no,width=600,height=400");
      screenZoomWin.name = screenName;
  }

  
  /*-------------------------------------------------------------   TO ADD A CURRCODE HIDDEN TEXTBOX
  *
  * Function     :  ZoomCardAccnoSearch
  *
  * Purpose      :  Used to popup the Zoom  Search window
  *
  * Parameters   :  textboxname Variable which holds the textbox name.
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/
  function ZoomCardAccnoCurrcodeSearch(parentFormName,parentTextBoxName1,parentTextBoxName2,formAction,jspname,fromwhere)
  {
	  
      var screenName = jspname;
      var dec = screenName.indexOf(".");
      if(dec > 0)
      {
          screenName =  screenName.substring(0,dec);
      }
      var params = "parentFormName=" + parentFormName + "&parentTextBoxName1=" + parentTextBoxName1 
      				+ "&parentTextBoxName2=" + parentTextBoxName2 + "&formAction=" + formAction + "&fromwhere=" + fromwhere;
      screenZoomWin = openWindowWithPostMethod(jspname, screenName, params, "toolbar=no,location=no," +
              "directories=no,status=yes,menubar=no,scrollbars=yes," + "resizable=no,width=600,height=400");
      screenZoomWin.name = screenName;
  }
  
  

/*-------------------------------------------------------------
 *
 * Function     :  ZoomSearchpan
 *
 * Purpose      :  Used to popup the Zoom  Search window
 *
 * Parameters   :  textboxname Variable which holds the textbox name.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function ZoomSearchpan(parentformname,textboxname1,jspname)
{
    ZoomPanScreenSearch(parentformname,textboxname1,jspname);
}

/*-------------------------------------------------------------
 *
 * Function     :  zoomSelectpan
 *
 * Purpose      :  Used to populate the parent field with the selected value
 *
 * Parameters   :  formname Variable that holds the parent form name.
 *              :  textboxname Variable that holds the parent text box name.
 *              :  var1 Variable that holds the data value.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function zoomSelectpan(parentformname,textboxname1,var1)
{
    var parentTextBox1 = eval("window.opener.document."+parentformname+"."+textboxname1);
    parentTextBox1.value = var1;
    window.close();
}


/*-------------------------------------------------------------
 *
 * Function     :  .
 *
 * Purpose      :  Used to populate the parent field with the selected value
 *
 * Parameters   :  formname Variable that holds the parent form name.
 *              :  textboxname Variable that holds the parent text box name.
 *              :  var1 Variable that holds the data value.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function zoomSelectcurr(parentformname,textboxname1,textboxname2,textboxname3,var1,var2,var3)
{
    var parentTextBox1 = eval("window.opener.document."+parentformname+"."+textboxname1);
    parentTextBox1.value = var1;
   
    var parentTextBox2 = eval("window.opener.document."+parentformname+"."+textboxname2);
    parentTextBox2.value = var2;
    var parentTextBox3 = eval("window.opener.document."+parentformname+"."+textboxname3);
    parentTextBox3.value = var3;

    window.close();
}

/*-------------------------------------------------------------
 *
 * Function     :  ZoomSearchcurr
 *
 * Purpose      :  Used to popup the Zoom  Search window
 *
 * Parameters   :  textboxname Variable which holds the textbox name.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function ZoomSearchcurr(parentformname,textboxname1,textboxname2,textboxname3,jspname)
{
    ZoomPanScreenSearch(parentformname,textboxname1,textboxname2,textboxname3,jspname);
}

/*-------------------------------------------------------------
 *
 * Function     :  ZoomSearchBranch
 *
 * Purpose      :  Used to popup the Zoom  Search window
 *
 * Parameters   :  textboxname Variable which holds the textbox name.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function ZoomSearchBranch(parentformname,textboxname1,textboxname2,jspname)
{
    ZoomScreenSearchWithInstCaps(parentformname,textboxname1,textboxname2,jspname);
}

/*-------------------------------------------------------------
  *
  * Function     :  ZoomPanScreenSearch
  *
  * Purpose      :  Used to popup the Zoom  Search window
  *
  * Parameters   :  textboxname Variable which holds the textbox name.
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/
function ZoomScreenSearchWithInst()
{
    // To Fix AT-0691
      var ar = ZoomScreenSearchWithInst.arguments;
      var screenName = ar[ar.length-1];
      var dec = screenName.indexOf(".");
      if(dec > 0)
      {
          screenName =  screenName.substring(0,dec);
      }
      var params = "parentFormName=" + ar[0];
      
      for(i=1;i<ar.length-1;i++)
      {
      	params = params + ("&parentTextBoxName" + i) + "=" + ar[i];
      }
      var droppdownval = eval("document."+ar[0]+".instcode.value");
      params = params + "&instCode=" + droppdownval;
      screenZoomWin = openWindowWithPostMethod(ar[ar.length-1], screenName, params, "toolbar=no,location=no," +
                                  "directories=no,status=yes,menubar=no,scrollbars=yes," +
                                  "resizable=no,width=600,height=400");
    screenZoomWin.name = screenName;
}

/*-------------------------------------------------------------
  *
  * Function     :  ZoomPanScreenSearch
  *
  * Purpose      :  Used to popup the Zoom  Search window
  *
  * Parameters   :  textboxname Variable which holds the textbox name.
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/
  function ZoomScreenSearchWithInstCaps()
  {
      // To Fix AT-0691
        var ar = ZoomScreenSearchWithInstCaps.arguments;
        var screenName = ar[ar.length-1];
        var dec = screenName.indexOf(".");
        if(dec > 0)
        {
            screenName =  screenName.substring(0,dec);
        }
        var params = "parentFormName=" + ar[0];
        for(i=1;i<ar.length-1;i++)
        {
            params = params + ("&parentTextBoxName" + i) + "=" + ar[i];
        }
        var droppdownval = eval("document."+ar[0]+".instCode.value");
        params = params + "&instCode=" + droppdownval;
        screenZoomWin = openWindowWithPostMethod(ar[ar.length-1], screenName, params, "toolbar=no,location=no," +
                "directories=no,status=yes,menubar=no,scrollbars=yes," + "resizable=no,width=600,height=400");
        
      screenZoomWin.name = screenName;
  }

/*-------------------------------------------------------------
 *
 * Function     :  ZoomSearchEncoderConf
 *
 * Purpose      :  Used to popup the Zoom  Search window
 *
 * Parameters   :  textboxname Variable which holds the textbox name.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function ZoomSearchEncoderConf(parentformname,textboxname,jspname)
{
    // To Fix AT-0691
    var  screenName = jspname;
    var dec = screenName.indexOf(".");
    if(dec > 0)
    {
        screenName =  screenName.substring(0,dec);
    }
    var params = "parentFormName="+parentformname+"&parentTextBoxName="+textboxname;
    screenZoomWin = openWindowWithPostMethod(jspname, screenName, params, "toolbar=no,location=no," +
            "directories=no,status=yes,menubar=no,scrollbars=yes," + "resizable=no,width=600,height=400");
    stateZoomWin.name = screenName;
}

/*-------------------------------------------------------------
 *
 * Function     :  zoomSelectEncoderConf
 *
 * Purpose      :  Used to populate the parent field with the selected value
 *
 * Parameters   :  formname Variable that holds the parent form name.
 *              :  textboxname Variable that holds the parent text box name.
 *              :  var1 Variable that holds the data value.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function zoomSelectEncoderConf(parentformname,textboxname,val)
{
    var parentTextBox = eval("window.opener.document."+parentformname+"."+textboxname);
    parentTextBox.value = val;

    window.close();
}




/*-------------------------------------------------------------
  *
  * Function     :  Populates the descriptino on change of dropdown
  *
  * Purpose      :
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :  Used only for User Group Description
  *
  *-----------------------------------------------------------*/

function populateDescr(obj)
{
    var innerval = obj.options[obj.selectedIndex].text;
    var OutletArr;
    OutletArr = (innerval).split("-");
    document.usrgrpdescrfrm.descr.value=Trim(OutletArr[1]);
}

/*-------------------------------------------------------------
  *
  * Function     :  Trims the spaces on either side of the text
  *
  * Purpose      :
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :  Method Called from populateDescr()
  *
  *-----------------------------------------------------------*/

function Trim(varr)
{
    var ret = "";

    for(i=0;i<varr.length;i++)
    {
        if(varr.charAt(0) != ' ')
        {
            break;
        }
        else
        {
            varr = varr.substring(1);
        }
    }

    for(i=(varr.length-1);i>=0;i--)
    {
        if(varr.charAt(i) != ' ')
        {
            break;
        }
        else
        {
            varr = varr.substring(0,i);
        }
    }

    return varr;
}

/*-------------------------------------------------------------
  *
  * Function     :  ZoomPanScreenSearch
  *
  * Purpose      :  Used to popup the Zoom  Search window
  *
  * Parameters   :  textboxname Variable which holds the textbox name.
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/
function ZoomPanScreenSearch()
{
    // To Fix AT-0691
    var ar = ZoomPanScreenSearch.arguments;
    var screenName = ar[ar.length-1];
    var dec = screenName.indexOf(".");
    if(dec > 0)
    {
        screenName =  screenName.substring(0,dec);
    }
    var params = "parentFormName=" + ar[0];
    for(i=1;i<ar.length-1;i++)
    {
        params = params + ("&parentTextBoxName" + i) + "=" + ar[i];
    }
    screenZoomWin = openWindowWithPostMethod(ar[ar.length-1], screenName, params, "toolbar=no,location=no," +
                                "directories=no,status=yes,menubar=no,scrollbars=yes," + "width=750,height=500");
    screenZoomWin.name = screenName;
}

/*-------------------------------------------------------------
 *
 * Function     :  zoomSelect
 *
 * Purpose      :  Used to populate the parent field with the selected value
 *
 * Parameters   :  formname Variable that holds the parent form name.
 *              :  textboxname Variable that holds the parent text box name.
 *              :  var1 Variable that holds the data value.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function zoomPanSelect(parentformname,textboxname1,textboxname2,textboxname3,var1,var2,var3)
{

    var parentTextBox1 = eval("window.opener.document."+parentformname+"."+textboxname1);
    parentTextBox1.value = var1;
    var parentTextBox2 = eval("window.opener.document."+parentformname+"."+textboxname2);
    parentTextBox2.value = var2;
    var parentTextBox3 = eval("window.opener.document."+parentformname+"."+textboxname3);
    parentTextBox3.value = var3;
    window.close();
}



/*-------------------------------------------------------------
 *
 * Function     :  TransZoomScreen
 *
 * Purpose      :  Used to popup the Zoom Limits Profile window
 *
 * Parameters   :  textboxname Variable which holds the textbox name.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function TransZoomScreen(parentformname,textboxname,jspname)
{
    // To Fix AT-0691
    var screenName = jspname;
    var dec = screenName.indexOf(".");
    if(dec > 0)
    {
        screenName =  screenName.substring(0,dec);
    }
    var parent = "child";
    var params = "parentFormName="+parentformname+"&parentTextBoxName="+textboxname + "&parent="+ parent;
    screenZoomWin = openWindowWithPostMethod(jspname, screenName, params, "toolbar=no,location=no," +
            "directories=no,status=yes,menubar=no,scrollbars=yes," + "width=700,height=480")
    screenZoomWin.name = screenName;
}


/*-------------------------------------------------------------
 *
 * Function     :  zoomSelectLimits
 *
 * Purpose      :  Used to populate the parent field with the selected value
 *
 * Parameters   :  formname Variable that holds the parent form name.
 *              :  textboxname Variable that holds the parent text box name.
 *              :  var1 Variable that holds the data value.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function zoomSelectLimits(parentformname,textboxname,var1)
{
  document.forms[0].formAction.value="search";
  var var1 = document.forms[0].parentTextBoxresval.value;
}

/*-------------------------------------------------------------
 *
 * Function     :  zoomSelectLimitsClose
 *
 * Purpose      :  Used to populate the parent field with the selected value
 *
 * Parameters   :  formname Variable that holds the parent form name.
 *              :  textboxname Variable that holds the parent text box name.
 *              :  var1 Variable that holds the data value.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function zoomSelectLimitsClose(parentformname,textboxname,var1)
{
  var parentTextBox = eval("window.opener.document."+parentformname+"."+textboxname);
  parentTextBox.value = var1;
  window.close();
}


/*-------------------------------------------------------------
 *
 * Function     :  genkey
 *
 * Purpose      :  Used to generate keys through taxedo
 *
 * Parameters   :  formname Variable that holds the parent form name.
 *              :  formAction variable
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function genkey(formname,operation)
 {

     if(Trim(document.forms[0].strExpiry.value)=='')
     {
        err='"Expiry date"' + getMessage('keyismandatory');
        alertErr(err);
        focusEl(document.forms[0].strExpiry);
        return false;
     }
     else
     {
        statusMsg=getMessage('keyrecsgeneratewishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;

        if(confirm(msg))
        {
            enableDropdown();
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
        else
        return false;
    }
 }
 /*-------------------------------------------------------------
  *
  * Function     :  Refresh the current record
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on Refresh.
  *
  *
  * Parameters   :  null
  *
  * Returns      :
  *
  * Comments     : Added by Sanjay Datta on 15/06/2002 for Refresh button
  *                in update/Edit screen
  *
  *-----------------------------------------------------------*/

  function refreshrec()
  {
    var ret = true;
    if (DirtyFormcheck(true))
    {

     statusMsg=getMessage('keyrecsrefwishcont');
     actionMsg=getMessage('keydoyouwancontinue');
     msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

     ret = confirm(msg);
     }

    if(ret)
       {
        enableDropdown();
        document.forms[0].formAction.value = 'refresh';
        document.forms[0].submit();
       }
  }

  /*-------------------------------------------------------------
  *
  * Function     :  Refresh the current record
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on Refresh.
  *
  *
  * Parameters   :  null
  *
  * Returns      :
  *
  * Comments     : Added by G.Md.Javeed on 28/06/2002 for Refresh buttons
  *                in update/Edit screen.This has custome messages related to
  *                Dynamic Host Monitoring.
  *
  *-----------------------------------------------------------*/

  function refreshhostdynmontrec()
  {
    var ret = true;
    if (DirtyFormcheck(true))
    {

     statusMsg=getMessage('keyrecsrefwishcont');
     actionMsg=getMessage('keydoyouwancontinue');
     msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

     ret = confirm(msg);
     }
     if(ret)
       {
        enableDropdown();
        document.forms[0].formAction.value = 'refresh';
        document.forms[0].submit();
       }
  }



  /*-------------------------------------------------------------
   *
   * Function     :  CardActivationZoomSearch
   *
   * Purpose      :  Used to popup the Zoom Search window
   *
   * Parameters   :  textboxname Variable which holds the textbox name.
   *
   * Returns      :
   *
   * Comments     :
   *
   *-----------------------------------------------------------*/
  function CardActivationZoomSearch(parentformname,textboxname1,textboxname2,textboxname3,jspname)
  {
      ZoomScreenSearchWithInst(parentformname,textboxname1,textboxname2,textboxname3,jspname);
  }


/*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Update
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on update.
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function updaterecnodirty(formname,operation)
  {
    var ret = false;


     statusMsg=getMessage('keyrecsupdwishcont');
     actionMsg=getMessage('keydoyouwancontinue');
     msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

     ret = confirm(msg);

    if(ret)
       {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
       }
  }

  /*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Update
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on update.
  *                 +
  *                 Button hidden when pressed.
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function updaterecnodirty_hide_generatebutton(formname,operation)
  {
    var ret = false;

    statusMsg=getMessage('keyrecsupdwishcont');
    actionMsg=getMessage('keydoyouwancontinue');
    msg = "___________________________________________________" +
          "\n\n" + statusMsg + "\n" +
          "___________________________________________________" +
          "\n\n" + actionMsg;

    ret = confirm(msg);

    if(ret)
       {
    	document.forms[formname].generatebutton.style.visibility = 'hidden';
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
       }
  }

    //For Additional Application
    function adnlApp()
    {
        var fieldMaxlength = document.forms[0].embossnamemaxlength.value;
        var firstName = document.forms[0].firstname.value;
        var lastName = document.forms[0].lastname.value;
        var embossName = firstName + " " + lastName;
        document.forms[0].embossname.value = embossName.substring(0, parseInt(fieldMaxlength));
    }

    //Modified to fix TR-0997,0999 :Vinay
    function test123()
    {
        if(document.forms[0].pri_pan.value == '')
        {
            document.forms[0].pannumber.focus();
            return false;
        }
        else
        {
            if((document.forms[0].prvpan.value == document.forms[0].pri_pan.value) && document.forms[0].repStatus.value == 'true')
            {
                return false;
            }
            else
            {
                document.additionalapplicationfrm.formAction.value="repopulate";
                document.additionalapplicationfrm.submit();
            }
            if(document.forms[0].repStatus.value == 'true')
            {
                return false;
            }
        }
        document.additionalapplicationfrm.formAction.value="repopulate";
        document.additionalapplicationfrm.submit();
     }

/*-------------------------------------------------------------
 *
 * Function     :  editmenu
 *
 * Purpose      :  Confirmation On clicking Edit Menu. Confirmation Message is displayed on the screen
 *         when user clicks on Edit menu.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Modified to fix Back functionality on 19/12/2002 :Vinay
 *
 *-----------------------------------------------------------*/

function editmenu(jspname,where)
 {
        var ret = false;
        statusMsg=getMessage('keydoeditmenu');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;

        ret = confirm(msg);
        var usrgrp = encodeURIComponent(document.forms[0].usrgrp.value);
        if(ret)
        {
        	redirectWithPostMethod(jspname, "key2="+where+"&usrgrp="+usrgrp);
        }

 }


 /*-------------------------------------------------------------
 *
 * Function     :  editmenudet
 *
 * Purpose      :  Confirmation On clicking Edit Menu. Confirmation Message is displayed on the screen
 *         when user clicks on Edit menu.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Modified to fix Back functionality on 19/12/2002 :Vinay
 *
 *-----------------------------------------------------------*/

function editmenudet(jspname,username,where)
 {
        var ret = false;
        statusMsg=getMessage('keydoeditmenu');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;

        ret = confirm(msg);

        if(ret)
        {
        	redirectWithPostMethod(jspname, "menuuser="+username.value+"&key2="+where);
        }

 }
  /*-------------------------------------------------------------
 *
 * Function     :  usrgrpeditmenudet
 *
 * Purpose      :  Confirmation On clicking Edit Menu. Confirmation Message is displayed on the screen
 *         when user clicks on Edit menu.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : 
 *
 *-----------------------------------------------------------*/

function usrgrpeditmenudet(jspname,usrgrp,where)
 {
        var ret = false;
        statusMsg=getMessage('keydoeditmenu');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;

        ret = confirm(msg);

        if(ret)
        {
        	redirectWithPostMethod(jspname, "formAction=edit&usrgrp="+usrgrp+"&key1="+ encodeURIComponent(usrgrp) +"&key2="+ encodeURIComponent(usrgrp) +"&key3=menusearch");
        }
 }

    /*-------------------------------------------------------------------- 
    *
    * Function     :  Custom Navigation with custom message.
    *
    * Purpose      :  Confirmation Message is displayed on the screen
    *                 when user clicks on appropriate button.
    *                 This enables the Dropdown before submiting records as
    *                 values from the Disabled dropdowns cannot be submitted
    *
    * Parameters   :actionfile,formname,operation,keycustommsg
    *
    * Returns      :
    *
    * Comments     :
    *
    *----------------------------------------------------------------------*/

    function customnavigate(actionfile,formname,operation,keycustommsg)
    {
        var ret = false;

        if (checkForm(document.forms[0]) )
        {
            statusMsg=getMessage(keycustommsg);
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n" +
            "___________________________________________________" +
            "\n\n" + actionMsg;

            ret = confirm(msg);

        }
        if(ret)
        {
            enableDropdown();

            document.forms[formname].action = actionfile + "?formAction=" + operation;
            document.forms[formname].submit();
        }
    }

    /*--------------------------------------------------------------------
    *
    * Function     :  Custom Navigation with custom message.
    *
    * Purpose      :  Confirmation Message is displayed on the screen
    *                 when user clicks on appropriate button.
    *                 This enables the Dropdown before submiting records as
    *                 values from the Disabled dropdowns cannot be submitted
    *
    * Parameters   :actionfile,formname,operation,keycustommsg
    *
    * Returns      :
    *
    * Comments     :
    *
    *----------------------------------------------------------------------*/

    function closebatch(actionfile,formname)
    {
        var ret = false;

        statusMsg=getMessage('keymsgclosebtch');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;

        ret = confirm(msg);

        if(ret)
        {
            enableDropdown();

            document.forms[formname].action = actionfile + "?formAction=closeBatch";
            document.forms[formname].submit();
        }
    }

 /*-------------------------------------------------------------
 *
 * Function     :  To refresh Card activtiy detail screen.
 *
 * Purpose      :  On Clicking on 'Refresh' button refreshes the current record.
 *
 * Parameters   : formname,frmaction
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function cardactivityrefresh(formname,frmaction)
{

    var ret = false;

    var menu = eval(formname + '.menu.value');
    var instcode = eval(formname + '.instcode.value');
    var pan = eval(formname + '.pan.value');
    var seqno = eval(formname + '.seqno.value');
    var accno = eval(formname + '.accno.value');
    var authfunction = false;
    var destination = null;

    if(menu == 0)
    {
        authfunction = true;
        destination = frmaction + "&authfunction=" + authfunction + "&instcode=" + instcode + "&pan=" + pan + "&seqno=" + seqno + "&accno=" +accno;
    }
    else
    {
        // convert elements to keys after unmasking
        destination = frmaction + "&instcode=" + instcode + "&pan=" + pan + "&accno=" +accno;
        destination = destination + "&namesToKeys=true&formAcsitem=" + document.forms[formname].formAcsitem.value;
    }


    if (DirtyFormcheck(true))
    {
        statusMsg=getMessage('keyrecsresetwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

        ret = confirm(msg);
    }
    else
    {
    		redirectWithPostMethodUrl(destination);
    }
    if(ret)
    {
    		redirectWithPostMethodUrl(destination);
    }
    else
    {
        return false;
    }
}



   /*-------------------------------------------------------------
    *
    * Function     :  Confirmation On Adding new record after checking the radio button
    *
    * Purpose      :  Confirmation Message is displayed on the screen
    *         when user clicks on add
    *
    * Parameters   :
    *
    * Returns      :
    *
    * Comments     :
    *
    *-----------------------------------------------------------*/

    function addnewrec(formname,formdo)
    {
       var ret = false;
       var sFromWhere = "|add";

      if (modify_onClick())
       {

           var IdVal =checkall();
           IdVal=IdVal+sFromWhere;
           document.forms[0].Iid.value=IdVal;
           TransZoomScreen(formname,IdVal,formdo);
       }
    }



   /*-------------------------------------------------------------
    *
    * Function     :  Confirmation On Adding new record after checking the radio button
    *
    * Purpose      :  Confirmation Message is displayed on the screen
    *         when user clicks on add
    *
    * Parameters   :
    *
    * Returns      :
    *
    * Comments     :
    *
    *-----------------------------------------------------------*/

    function updatenewrec(formname,formdo)
    {
       var ret = false;
       var sFromWhere = "|update";

      if (modify_onClick())
        {

           var IdVal =checkall();
           IdVal=IdVal+sFromWhere;
           document.forms[0].Iid.value=IdVal;
           TransZoomScreen(formname,IdVal,formdo);
        }
    }


/*-------------------------------------------------------------
 *
 * Function     :  function Called  on click of Delete button
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *                 when user clicks on Delete.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :   used for batch
 *
 *-----------------------------------------------------------*/

 function delbatchrec(formname,operation)
  {
      var ret = false;
     if (modify_onClick())
     {
         statusMsg=getMessage('keyrecsdelwishcont');
         actionMsg=getMessage('keydoyouwancontinue');
         msg = "___________________________________________________" +
             "\n\n" + statusMsg + "\n" +
             "___________________________________________________" +
             "\n\n" + actionMsg;
             ret = confirm(msg);
     }
     if(ret)
         {
             enableDropdown();
             var IdVal =checkall();
             document.forms[0].Iid.value = IdVal;
             document.forms[0].formAction.value = operation;
             document.forms[0].submit();
         }

     else
         return false;

 }




/*-------------------------------------------------------------
 *
 * Function     :  function Called  from addnewrec,updatenewrec and delbatchrec
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *                 when user clicks add, update and delete buttons.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :   used for batch
 *
 *-----------------------------------------------------------*/

    function modify_onClick()
    {
     var len = document.forms[0].elements.length;
     var count = getCount();
     if((count ==0))
     {
        msg=getMessage('keycheckdelete');
        alertErr(msg);

           return false;
     }
     else
     return true;

    }

/*-------------------------------------------------------------
 *
 * Function     :  function Called  from modify_onClick
 *
 * Purpose      :  gets the count of the records selected
 *
 *
 * Parameters   :
 *
 * Returns      :   int
 *
 * Comments     :   used for batch
 *
 *-----------------------------------------------------------*/

    function getCount()
    {
     var len = document.forms[0].elements.length;
     var count = 0;
     for(i=0;i<len;i++)
     {
       if(document.forms[0].elements[i].name == 'radio')
          {

            if(document.forms[0].elements[i].checked == true)
              count++;

          }

      }

      return count;
    }

/*-------------------------------------------------------------
 *
 * Function     :  function Called  from  addnewrec,updatenewrec and delbatchrec methods
 *
 * Purpose      :  gets the id for the selected radio button
 *
 *
 * Parameters   :
 *
 * Returns      :   int
 *
 * Comments     :   used for batch
 *
 *-----------------------------------------------------------*/

    function checkall(frm)
    {
     var len= document.forms[0].elements.length;
     var j=0;
     var checkValue="";

         for(var i=0;i<len;i++)
         {
          if(document.forms[0].elements[i].name == 'radio')
             {
              if(document.forms[0].elements[i].checked == true)
              {
                 var Id =""
                 Id = document.forms[0].elements[i].value;
                 break;
              }
         }
    }
     return Id;
    }

 /*
 * function to close the child window
 */

 function Close()
 {
    window.close();
 }


 /*-------------------------------------------------------------
  *
  * Function     :  AddZoomSelect
  *
  * Purpose      :  Used for the ADD window in batch to replace.
  *
  * Parameters   :  var Variable that holds the info of the selected row.
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/
 function AddZoomSelect()
 {
	 var str;
	 var ar = AddZoomSelect.arguments;
     var token_key = document.getElementsByName("TOKEN_KEY")[0].value;
     if(token_key !=''){
    	 str = ar[0] + "?formAction=add&fromPopup=1&TOKEN_KEY="+token_key;
     }else{
    	 str = ar[0] + "?formAction=add";
     }
     
     for(i=1;i<ar.length;i++)
     {
         str = str + ("&key" + i) + "=" + encodeURIComponent(ar[i]);
     }
     redirectWithPostMethodUrl(str);

 }


 /*-------------------------------------------------------------
  *
  * Function     :  UpdZoomSelect
  *
  * Purpose      :  Used for the Update window.
  *
  * Parameters   :  var Variable that holds the info of the selected row.
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/
 function UpdZoomSelect()
 {
     var ar = UpdZoomSelect.arguments;
     var str = ar[0] + "?formAction=edit";
     for(i=1;i<ar.length;i++)
     {
           str = str + ("&key" + i) + "=" + encodeURIComponent(ar[i]);
     }
     redirectWithPostMethodUrl(str);

 }



/*-------------------------------------------------------------
 *
 * Function     :  To Go Back To Previous Screen
 *
 * Purpose      :  On Clicking on 'BACK' button user taken back to previous page
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function isMenuback()
{

    var ar = isMenuback.arguments;
    var ret = false;

        statusMsg=getMessage('keyrecsresetwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

        ret = confirm(msg);

    if(ret)
    {
            document.menusrcfrm.formAction.value="back";
            document.menusrcfrm.submit();
    }
    else
    {
        return false;
    }
}
/*-------------------------------------------------------------
*
* Function     :  onAcsitemrefresh()
*
* Purpose      :  To call a repopulate method in the menudetails
*
* Parameters   :  arg1
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/

function onAcsitemrefresh(arg1,arg2)
{
     var varacsitem = document.forms[0].elements[arg1].value;
     var varheader = document.forms[0].elements[arg2].value;
     if(Trim(varacsitem) != '' && Trim(varheader) == '')
    {
        document.menudetailsfrm.formAction.value="repopulate";
        document.menudetailsfrm.submit();
    }


}
/*-------------------------------------------------------------
 *
 * Function     :  MenuAdd
 *
 * Purpose      :  Used to get values of user group and submenu from
                   search screen to add screen
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function MenuAdd(parentformname,jspname)
{

    var usrgrp = eval("document."+parentformname+".usrgrp.value");
    var submenu = eval("document."+parentformname+".submenu.value");
    var morder = eval("document."+parentformname+".morder.value");
    redirectWithPostMethod(jspname, "usrgrp="+usrgrp+"&submenu="+submenu+"&morder="+morder);

}

 /*-------------------------------------------------------------
     *
     * Function     :  Populating record
     *
     * Purpose      :
     *
     * Parameters   :
     *
     * Returns      :
     *
     * Comments     :
     *
     *-----------------------------------------------------------*/

   function populaterec(formname,operation)
   {
     var ret = false;
     var valid = true;

     if(checkForm(document.forms[0]))
     {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
     }
  }

 /*-------------------------------------------------------------
     *
     * Function     :  Populating record
     *
     * Purpose      :
     *
     * Parameters   :
     *
     * Returns      :
     *
     * Comments     :
     *
     *-----------------------------------------------------------*/

   function populaterecnotcheck(formname,operation)
   {
     var ret = false;
     var valid = true;

     enableDropdown();
     document.forms[formname].formAction.value = operation;
     document.forms[formname].submit();
  }

  /*-------------------------------------------------------------
     *
     * Function     :  Populating record
     *
     * Purpose      :
     *
     * Parameters   :
     *
     * Returns      :
     *
     * Comments     :
     *
     *-----------------------------------------------------------*/

   function populatepinmailerrec(formname,operation)
   {
     var ret = false;
     var valid = true;

     if(checkForm(document.forms[0]))
     {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].buttonclick.value = "true";
        document.forms[formname].submit();
     }
  }

  /*-------------------------------------------------------------
     *
     * Function     :  Populating record
     *
     * Purpose      : This is used only while producing the cards for Produce cards search
     *                screen as the Encoder code value should be made mandatory only
     *                 when user choose produce selection.
     *
     * Parameters   : formname,operation
     *
     * Returns      :
     *
     * Comments     : used in produce cards search screen.
     *
     *-----------------------------------------------------------*/

   function produceCards(formname,operation)
   {
     var ret = false;
     var valid = true;
     if(Trim(document.forms[formname].encode.value) ==  "")
     {

         statusMsg=getMessage('keyplstryagain1');
         statusMsg1=getMessage('keyplstryagain2');
         actionMsg=getMessage('keyismandatory');
         msg = "___________________________________________________" +
               "\n\n" + statusMsg + "\n" + statusMsg1 + "\n" +
               "___________________________________________________" +
               "\n\n" + "\"Encoder label\" "+ actionMsg;
         alert(msg);
         document.forms[formname].encode.focus();
         return true;
     }

     if(checkForm(document.forms[0]))
     {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
     }
  }

/*-------------------------------------------------------------
  *
  * Function     :  isbackfordo
  *
  * Purpose      :  When a search screen is called through .do that is
  *                 when we have a functionality to be performed before
  *                 the search screen is displayed  we cannot get the
  *                 search criteria from the null block again. This function
  *                 is used to go to another block on the search action class
  *                 other than the null block
  *
  * Parameters   :  parentformname and operator
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function isbackfordo(parentformname,operation)
  {
    var ret = false;
    if (DirtyFormcheck(true))
    {
        statusMsg=getMessage('keyrecsresetwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

        ret = confirm(msg);
    }
    else
    {
    	redirectWithPostMethod(parentformname, "formAction="+operation);
    }
    if(ret)
    {
    	  redirectWithPostMethod(parentformname, "formAction="+operation);
    }
    else
    {
        return false;
    }
  }

/*-------------------------------------------------------------
  *
  * Function     :  updatestmtcylce
  *
  * Purpose      :
  *
  * Parameters   :  parentformname and operator and hidden variable
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function updatestmtcylce(formname,operation,var1)
  {
        var ret = false;
        var count1=document.forms[0].count.value;

        if(document.forms[0].pan.value == null || document.forms[0].pan.value == "")
        {
                statusMsg=getMessage('keyforsearch');
                alertErr(statusMsg);

                 return;
        }
        if(document.forms[0].custcode.value == null || document.forms[0].custcode.value == "")
        {
                statusMsg=getMessage('keyforsearch');
                alertErr(statusMsg);

                 return;
        }


        if (checkForm(document.forms[0]))
        {
            statusMsg=getMessage('keyrecsupdwishcont');
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
             "\n\n" + statusMsg + "\n" +
             "___________________________________________________" +
             "\n\n" + actionMsg;

               ret = confirm(msg);

         }
         if(ret)
         {
              enableDropdown();
              document.forms[formname].formAction.value = operation;
              document.forms[formname].submit();
         }
  }


/*-------------------------------------------------------------
   *
   * Function     :  AddZoomRefresh
   *
   * Purpose      :  Used for the ADD window in batch for Input
   *
   * Parameters   :  var Variable that holds the info of the selected row.
   *
   * Returns      :
   *
   * Comments     :
   *
   *-----------------------------------------------------------*/
  function AddZoomRefresh()
  {
      var ar = AddZoomRefresh.arguments;
      var str = ar[0] + "?formAction=refresh";
      for(i=1;i<ar.length;i++)
      {
          str = str + ("&key" + i) + "=" + encodeURIComponent(ar[i]);
      }
      redirectWithPostMethodUrl(str);
  }

 /*-------------------------------------------------------------
   *
   * Function     :  ZoomPinSearchSelect() used populating the Pin search zoom screen.
   *
   * Purpose      : Used specific to populating the Pin search zoom screen in batch screens
   *
   * Parameters   : parentformname,InstCode,BatchType,Batch,CardProduct,jspname
   *
   * Returns      : Nothing
   *
   * Comments     :
   *
   -----------------------------------------------------------*/
   function ZoomPinSearchSelect(parentformname,InstCode,BatchType,Batch,CardProduct,jspname)
   {
        // To Fix AT-0691
        var screenName = jspname;
        var dec = screenName.indexOf(".");
        if(dec > 0)
        {
            screenName =  screenName.substring(0,dec);
        }
        var parent ="search"
        
        var params = "parentFormName="+parentformname+"&InstCode="+InstCode+"&BatchType="+BatchType+"&Batch="+Batch+"&CardProduct="+CardProduct+"&parent="+parent+"&fromPopup=1";
        screenZoomWin = openWindowWithPostMethod(jspname, screenName, params, "toolbar=no,location=no," +
                "directories=no,status=yes,menubar=no,scrollbars=yes," + "resizable=no,width=800,height=400")
        screenZoomWin.name = screenName;
   }

   /*-------------------------------------------------------------
     *
     * Function     :  searchTab() used for access log.
     *
     * Purpose      :
     *
     * Parameters   :
     *
     * Returns      :
     *
     * Comments     :
     *
     *-----------------------------------------------------------*/

   function searchTab()
   {
       if(document.forms[0].tabid.value == 1)
       {
           if(Trim(document.forms[0].accessUser.value)=='')
           {
               err='"Access User"' + getMessage('keyismandatory');
               alertErr(err);
               focusEl(document.forms[0].accessUser);
               return false;
           }
       }
       enableDropdown();
       document.forms[0].tabCheck.value = 'tab';
       document.forms[0].formAction.value = 'search';
       document.forms[0].submit();
}


 /*-------------------------------------------------------------
  *
  * Function     :  isWildcards() used for Pannamesls.
  *
  * Purpose      :
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/
  function isWildcards(str,wildc)
  { var ret=false;
    for(var i=0; i < wildc.length; i++) {
      if(str.indexOf(wildc.charAt(i)) > -1){
       ret=true;
       break;
      }
   }
    return ret;
  }
  
 /*-------------------------------------------------------------
  *
  * Function     :  checkPannamels() used for Pannamesls.
  *
  * Purpose      :
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/
  
  function checkPannamels(formname,formaction,keymsg,wildc)
  { 
    var mess=true;
    var ret=false;
    var msg=getMessage(keymsg);
  //  var wildc = '*<>~,!';
    var form = document.forms[formname];
    if(Trim(form.pan.value)!='' && !isWildcards(form.pan.value,wildc))
     mess=false;
    if(mess && Trim(form.firstName.value)!='' && Trim(form.lastName.value)!='' && Trim(form.dob.value)!='' && !isWildcards(form.firstName.value,wildc) && !isWildcards(form.lastName.value,wildc) && !isWildcards(form.dob.value,wildc))
     mess=false;
    if(mess){
     ret = confirm(msg);
      if(ret){
       form.formAction.value=formaction;
       form.submit();
      }
    } else {
       form.formAction.value=formaction;
       form.submit();   
    }
  }

/*-------------------------------------------------------------
 *
 * Function     :  GenericSubmitConfirmation
 *
 * Purpose      :  Used to confirm some action
 *
 * Parameters   : 1. Form name
 *                2. action (e.g. 'search')
 *                3. confirmation message                 
 *
 * Returns      : Submit/not submit form
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function GenericSubmitConfirmation(formname,formaction,keymsg)
{
	var msg=getMessage(keymsg);
    var form = document.forms[formname];
    var ret = confirm(msg);
    if(ret){
     form.formAction.value=formaction;
     form.submit();
    }
}

/*-------------------------------------------------------------
    *
    * Function     :  searchTabCustMaint() used for Customer Maintenance.
    *
    * Purpose      :
    *
    * Parameters   :
    *
    * Returns      :
    *
    * Comments     :
    *
    *-----------------------------------------------------------*/
    function searchTabCustMaint()
    {
        if(document.forms[0].tabid.value == 0)
        {
            if(Trim(document.forms[0].instcode.value)=='')
            {
                err='"Institution code"' + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].instcode);
                return false;
            }
            if(Trim(document.forms[0].lastname.value)=='')
            {
                err='"Last name"' + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].lastname);
                return false;
            }
        }
        if(document.forms[0].tabid.value == 1)
        {
            if(Trim(document.forms[0].instcode1.value)=='')
            {
                err='"Institution code"' + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].instcode1);
                return false;
            }
            if(Trim(document.forms[0].custcode.value)=='')
            {
                err='"Customer code"' + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].custcode);
                return false;
            }
        }
        enableDropdown();
        document.forms[0].tabCheck.value = 'tab';
        document.forms[0].formAction.value = 'search';
        document.forms[0].submit();
  }

 /*-------------------------------------------------------------
  *
  * Function     :  searchTabAuth() used for Authorisation functions.
  *
  * Purpose      :
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function searchTabAuth()
  {
      if(document.forms[0].tabid.value == 0)
      {
          if(Trim(document.forms[0].pan.value)=='' && Trim(document.forms[0].virtualPan.value)=='')
          {
              err='"Card Reference" or ' + getMessage('keyismandatory');
              alertErr(err);
              focusEl(document.forms[0].pan);
              return false;

          }
          if(!isValidSearchInteger(document.forms[0].strSeqno.value,document.forms[0].strSeqno))
          {
               var Seqname="Sequence number";
               errMsg = "The \"" + Seqname + "\" is a search field for "
                                 +"number only - your entry of "
                  + document.forms[0].strSeqno.value +" is not allowed";

               errMsg =   getMessage('keyauth1')
                        + Seqname
                        + getMessage('keyauth2')
                        + getMessage('keyauth3')
                        + document.forms[0].strSeqno.value
                        + getMessage('keyauth4');

               alertErr(errMsg);
               document.forms[0].strSeqno.select();
               document.forms[0].strSeqno.focus();
               return false;
          }

      }
      if(document.forms[0].tabid.value == 1)
      {
          if(Trim(document.forms[0].instcode2.value)=='')
          {
              err='"Institution code"' + getMessage('keyismandatory');
              alertErr(err);
              focusEl(document.forms[0].instcode2);
              return false;
          }
      }
      if(document.forms[0].tabid.value == 1)
      {
         if(Trim(document.forms[0].accno.value)=='')
         {
             err='"Account number"' + getMessage('keyismandatory');
             alertErr(err);
             focusEl(document.forms[0].accno);
             return false;
         }
      }
      enableDropdown();
      document.forms[0].tabCheck.value = 'tab';
      document.forms[0].formAction.value = 'search';
      document.forms[0].submit();
  }
  /*-------------------------------------------------------------
  *
  * Function     :  ZoomSearchPannamels
  *
  * Purpose      :  Used to popup the Zoom  Search window
  *
  * Parameters   :  textboxname Variable which holds the textbox name.
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function ZoomSearchPannamels(parentformname,textboxname1,textboxname2,textboxname3, jspname)
  {
      ZoomScreenSearchWithInst(parentformname,textboxname1,textboxname2,textboxname3, jspname);
  }

  /*-------------------------------------------------------------
   *
   * Function     :  ZoomPanScreenSearchForBatch
   *
   * Purpose      :  Used to popup the Zoom Screen Search window
   *
   * Parameters   :  textboxname1,textboxname2,textboxname3 Variable which holds the textbox name to be populated.
   *
   * Returns      :
   *
   * Comments     :
   *
   *-----------------------------------------------------------*/
    function ZoomPanScreenSearchForBatch(parentformname,textboxname1,textboxname2,textboxname3, textboxname4,textboxname5, jspname)
    {
        ZoomPanScreenSearch(parentformname,textboxname1,textboxname2,textboxname3, textboxname4,textboxname5, jspname);
    }
  /*-------------------------------------------------------------
  *
  * Function     :  ZoomSearchPannamelscurr
  *
  * Purpose      :  Used to popup the Zoom  Search window
  *
  * Parameters   :  textboxname Variable which holds the textbox name.
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function ZoomSearchPannamelscurr(parentformname,textboxname1,textboxname2,textboxname3, textboxname4,textboxname5,jspname)
  {
      ZoomScreenSearchWithInstCaps(parentformname,textboxname1,textboxname2,textboxname3, textboxname4,textboxname5,jspname);
  }



/*-------------------------------------------------------------
   *
   * Function     :  resetAmt(vFldName) used for Currency Formatting.
   *
   * Purpose      :  This method restores the earlier value entered by the User
   *
   * Parameters   : vFldName Name of the currency field
   *
   * Returns      :
   *
   * Comments     :
   *
   *-----------------------------------------------------------*/



    function resetAmt(vFldName)
    {

        var vFldboj = eval("document.forms[0]."+vFldName);
        vFldboj.value = currencyval;

    }

    /* -------------------------------------------------------------
    *
    * Function     :  numToAmount() used for Currency Formatting.
    *
    * Purpose      :  This method Converts the number to the Loacle currency format
    *
    * Parameters   : vDecimalSep,vGroupSep,vNumDeci,vNumber,vFldName
    *
    * Returns      :
    *
    * Comments     :
    *
    *-----------------------------------------------------------*/

  function numToAmount(vDecimalSep,vGroupSep,vNumDeci,vNumber,vFldName)
    {
        var tmp1 = cents = dollars = "";
        var dec = -1;
        var num = i = 0;

        num = eval("document.forms[0]."+ vFldName+".value");
        var vObjFldName;
        vObjFldName = eval("document.forms[0]."+ vFldName);

        currencyval = num;
        for(var j=0;j<num.length;j++)
        {
            num = num.replace(vGroupSep, '');
        }
        // The Decimal seperator for the currency
        deci = vDecimalSep;
        // The Currency Symbol for the currency
        // The Group Saperator for the currency
        grp  = vGroupSep;
        // No of Decimal places for rounding for the currency
        var numdec = vNumDeci;

        if (checkNum(num,deci,vObjFldName))
        {
            var decisepEntered = "";
            decisepEntered = getDeciSep(num);
            if(decisepEntered == undefined)
            {
                decisepEntered = deci;
            }
            var deciplace = num.indexOf(deci);

            if(deciplace == 0)
            {
                num = "0"+num;
            }
            if(decisepEntered == deci)
            {
                num = num.replace(deci,".");
                dec = num.indexOf(".");
                if(dec > 0)
                {
                    cents =  num.substring(dec,num.length);
                }
                cents = cents.replace(".",deci);
                if(Trim(num)=="")
                {
                   num="0";
                }
                dollars = "" + parseInt(num,10);

                tmp1 = insComma(dollars,grp);
                num = "";
                for (i = tmp1.length-1; i >= 0; i--)
                {
                    num += tmp1.charAt(i);;
                }
                num +=cents;
                var vFldboj = eval("document.forms[0]."+vFldName);
                vFldboj.value = num;
                return(true);
            }
            else
            {
                msg =   getMessage('keydeci1')
                      + deci
                      + getMessage('keydeci2');
                alertErr(msg);
                vObjFldName.focus();
            }
        }
        else
        {
            vObjFldName.focus();
        }
    }
  /*-------------------------------------------------------------
   *
   * Function     :  getDeciSep() used for Currency Formatting.
   *
   * Purpose      :  This method returns the Decimal saperator of the Locale
   *
   * Parameters   : Entered number
   *
   * Returns      :
   *
   * Comments     :
   *
   *-----------------------------------------------------------*/


function getDeciSep(s)
{
    var i=0;
    var spass = s;
    for(i=0;i<spass.length;i++)
    {
        var c = spass.charAt(i)
        if (!isDigit(c))
        {
            return c;
        }
    }
}


/*-------------------------------------------------------------
   *
   * Function     :  insComma() used for Currency Formatting.
   *
   * Purpose      :  This method returns the Group saperated Number
   *
   * Parameters   :  Entered number and Group saperator
   *
   * Returns      :
   *
   * Comments     :
   *
   *-----------------------------------------------------------*/


function insComma(data,grp)
{

   var count = i = 0;
   var tmpStr = "";
   var comma = grp;
   for (i = data.length-1; i >= 0; i--)
   {
      if (count == 3)
      {
         tmpStr += comma;
         count = 1;
      }
      else  count ++;
      tmpStr += data.charAt(i);
   }
   return(tmpStr);
}


/*-------------------------------------------------------------
   *
   * Function     :  alertBadNum() used for Currency Formatting.
   *
   * Purpose      :  This method Checks for the Valid entry
   *
   * Parameters   :
   *
   * Returns      :
   *
   * Comments     :
   *
   *-----------------------------------------------------------*/
function alertBadNum(errType,vObjFldName)
{
   var errMsg = "";
   switch (errType)
   {
      case 1:
         errMsg = getMessage('keyblankspace');
         vObjFldName.value = defVal[vObjFldName.name];
         break;
      case 2:
         errMsg =  getMessage('keytexttag1')
                 + vObjFldName.value
                 + getMessage('keytexttag2');
         vObjFldName.value = defVal[vObjFldName.name];
         break;
      case 3:
         errMsg = getMessage('key2ormoredec');
         vObjFldName.value = defVal[vObjFldName.name];
   }
   alertErr(errMsg);
   return(false);
}


/*-------------------------------------------------------------
   *
   * Function     :  checkNum() used for Currency Formatting.
   *
   * Purpose      :  This method Checks for the Valid entry
   *
   * Parameters   :
   *
   * Returns      :
   *
   * Comments     :
   *
   *-----------------------------------------------------------*/




function checkNum(data,decimal,vObjFldName)
{
   var validNum = " 0123456789"+decimal;
   var i = count = 0;
   var dec = decimal;
   var space = " ";

   //for (i = 0; i < data.length; i++)
   //   if (data.substring(i, i+1) == space)
   //     return(alertBadNum(1,vObjFldName));

   for (i = 0; i < data.length; i++)
      if (validNum.indexOf(data.substring(i, i+1)) == "-1")
         return(alertBadNum(2,vObjFldName));

  if (data == decimal)
         return(alertBadNum(2));

   for (i = 0; i < data.length; i++)
      if (data.substring(i, i+1) == dec)   count++;
   if (count > 1)      return(alertBadNum(3,vObjFldName));

   return true;
}


/*-------------------------------------------------------------
 *
 * Function     :  ZoomSearchProfile
 *
 * Purpose      :  Used to popup the Zoom  Search window
 *
 * Parameters   :  textboxname Variable which holds the textbox name.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function ZoomSearchProfile(parentformname,textboxname1,jspname)
{
    // To Fix AT-0691
    var screenName = jspname;
    var dec = screenName.indexOf(".");
    if(dec > 0)
    {
        screenName =  screenName.substring(0,dec);
    }
    var services =eval("document."+parentformname+"."+textboxname1+".value");
    
    var params = "parentFormName="+parentformname+"&parentTextBoxName1="+textboxname1+"&services="+services;
    stateZoomWin = openWindowWithPostMethod(jspname, screenName, params, "toolbar=no,location=no," +
            "directories=no,status=yes,menubar=no,scrollbars=yes," + "resizable=no,width=800,height=400")
    stateZoomWin.name = screenName;
}



/*
 * Function to refresh parent window from child window
 * the form action is set to 'search' in action class
 */

function RefreshParent(parentformname,parentformdo)
{
    parentForm = eval("window.opener.document."+parentformname);
    document.forms[0].formAction.value = 'search';
    parentForm.action = parentformdo;
    parentForm.submit();
    window.close();
 }


function checkallBtch(frm)
{
     var len= document.forms[0].elements.length;
     var j=0;
     var checkValue="";

         for(var i=0;i<len;i++)
         {
          if(document.forms[0].elements[i].name == 'radio')
             {
              if(document.forms[0].elements[i].checked == true)
              {
                 var Id =""
                 Id = document.forms[0].elements[i].value;
                 break;
              }
         }
    }
     return Id;
}

function addnewCard(formname,formdo)
{
    if (modify_onClick())
    {

       var ret = false;

       var IdVal = checkallBtch(formname);
       var BatchVal = IdVal.split(",");
       var InstCode    = BatchVal[0];
       var BatchType   = BatchVal[1];
       var Batch       = BatchVal[2];
       var CardProduct = BatchVal[3];

       ZoomPinSearchSelect(formname,InstCode,BatchType,Batch,CardProduct,formdo);
   }
}
function modifyCardApp(formname,formdo)
{
    var ret = false;
    if (modify_onClick())
    {
        statusMsg=getMessage('keyrecsupdwishcont');
         actionMsg=getMessage('keydoyouwancontinue');
         msg = "___________________________________________________" +
             "\n\n" + statusMsg + "\n" +
             "___________________________________________________" +
             "\n\n" + actionMsg;
             ret = confirm(msg);
     }
     if(ret)
     {
       var IdVal = checkallBtch(formname);
       var BatchVal = IdVal.split(",");
       var crdprod    = BatchVal[0];
       var batch   = BatchVal[1];
       var instcode       = BatchVal[2];

       SelectCrdapp(formdo,crdprod,batch,instcode);
   }
}

function produceCardApp(formname,formdo)
{
    var ret = false;
    if (modify_onClick())
    {
        statusMsg=getMessage('keyrecsupdwishcont');
         actionMsg=getMessage('keydoyouwancontinue');
         msg = "___________________________________________________" +
             "\n\n" + statusMsg + "\n" +
             "___________________________________________________" +
             "\n\n" + actionMsg;
             ret = confirm(msg);
     }
     if(ret)
     {
       var IdVal = checkallBtch(formname);
       var BatchVal = IdVal.split(",");
       var batch   = BatchVal[1];
       var priority       = BatchVal[3];

       var str = formdo + "?formAction=producecard&key1="+batch+"&key2="+priority;
       redirectWithPostMethodUrl(str);
   }
}

function insertCrdapp()
{
    var ar = insertCrdapp.arguments;
    var str = ar[0] + "?formAction=beforeadd";

    // force conversion of element names to key1 ... keyn after unmasking
    str = str + "&namesToKeys=true";

    for(i=1;i<ar.length;i++)
    {
        // we need to check if the argument passed is a string or an element
    	if(!ar[i].name)
    	{    		
    		// we have a string
    		str = str + ("&key" + i) + "=" + encodeURIComponent(ar[i]);
    	}
    	else
    	{
    		// We have an element
    		str = str + "&" + ar[i].name + "=" + encodeURIComponent(ar[i].value);
    	}
    }
    
    if(document.forms[0].formAcsitem)
    {
    	// add on the acsitem passed 
    	str = str + "&formAcsitem=" + document.forms[0].formAcsitem.value;
    }
    redirectWithPostMethodUrl(str);
}

function clearToAdd()
{
    var args = clearToAdd.arguments;
    var dofile = args[0];
    var crdprod = args[1];
    var batch = args[2];
    var instcode = args[3];

    var str = dofile + "?formAction=beforeadd";
    
    // force conversion of element names to key1 ... keyn after unmasking
    str = str + "&namesToKeys=true";
    
    // convert elements to keys after unmasking
    str = str + "&"+crdprod.name+"="+crdprod.value+"&"+batch.name+"="+batch.value+"&"+instcode.name+"="+instcode.value;

    if(args.length > 4)
    {
        str = str + "&"+args[4].name+"="+args[4].value;
    }
    
    // add on the acsitem passed 
    str = str + "&formAcsitem=" + document.forms[0].formAcsitem.value;
    redirectWithPostMethodUrl(str);
}

function zoomCustAcc(parentform,dofile,parentTexbox,custcode,instcode)
{
    var ar = zoomCustAcc.arguments;
    var screenName = dofile;
    var dec = screenName.indexOf(".");
    if(dec > 0)
    {
        screenName =  screenName.substring(0,dec);
    }
    
    var params = "parentFormName=" + parentform+"&parentTextBoxName="+parentTexbox+"&userinst="+instcode.value+"&customerCode="+custcode.value+"&fromwhere="+2;
    screenZoomWin = openWindowWithPostMethod(dofile, screenName, params, "toolbar=no,location=no," +
    		"directories=no,status=yes,menubar=no,scrollbars=yes," + "resizable=no,width=600,height=400")
    screenZoomWin.name = screenName;
}

function zoomSelectCustAcc(parentformname,textboxname,var1)
{
    var parentTextBox1 = eval("window.opener.document."+parentformname+"."+textboxname);
    parentTextBox1.value = var1;
    parentTextBox1.focus();
    window.close();
}

function crdAppAdd(formname,formdo)
{
    var ret = false;
    if (modify_onClick())
    {
        statusMsg=getMessage('keyrecsaddwishcont');
         actionMsg=getMessage('keydoyouwancontinue');
         msg = "___________________________________________________" +
             "\n\n" + statusMsg + "\n" +
             "___________________________________________________" +
             "\n\n" + actionMsg;
             ret = confirm(msg);
     }
     if(ret)
     {
       var IdVal = checkallBtch(formname);
       var BatchVal = IdVal.split(",");
       var crdprod    = BatchVal[0];
       var batch   = BatchVal[1];
       var instcode       = BatchVal[2];

       insertCrdapp(formdo,crdprod,batch,instcode,'search');
   }
}


function unmark(formname,formdo)
{
    var ret = false;
    if (modify_onClick())
    {
        statusMsg=getMessage('keyrecsaddwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
             "\n\n" + statusMsg + "\n" +
             "___________________________________________________" +
             "\n\n" + actionMsg;
        ret = confirm(msg);
    }
    if(ret)
    {
        var IdVal = checkallBtch(formname);
        var BatchVal = IdVal.split(",");
        var pan = BatchVal[0];
        var seqno = BatchVal[1];
        var allocdate = BatchVal[2];
        var code = BatchVal[3];
        document.forms[formname].formAction.value = "unmark";
        document.forms[formname].pan.value = pan;
        document.forms[formname].seqno.value = seqno;
        document.forms[formname].allocdate.value = allocdate;
        document.forms[formname].code.value = code;
        document.forms[formname].submit();       
   }
}

function closeAppinputBatch()
{
    var ret = false;
    var args = closeAppinputBatch.arguments;
    var formname = args[0];
    var formdo = args[1];
    var batch = "";
    
    var btchType = "";
    if (args.length>3)
    {
        btchType = args[3];
    }
    
    if(args.length > 2)
    {
        batch = eval("document.forms[formname]." + args[2] + ".value");
    }

    if(batch != "")
    {
        ret = true;
    }
    else
    {
        ret = modify_onClick();
    }
    
    if (ret)
    {
        statusMsg=getMessage('keymsgclosebtch');
         actionMsg=getMessage('keydoyouwancontinue');
         msg = "___________________________________________________" +
             "\n\n" + statusMsg + "\n" +
             "___________________________________________________" +
             "\n\n" + actionMsg;
             ret = confirm(msg);
     }
     if(ret)
     {
         if(batch == "")
         {
             var IdVal = checkallBtch(formname);
             var BatchVal = IdVal.split(",");
             var crdprod    = BatchVal[0];
             batch   = BatchVal[1];
             var instcode       = BatchVal[2];
         }
		 var str;
         var popup="1"; 
         var token_key = document.getElementsByName("TOKEN_KEY")[0].value;
         if(token_key !=''){
        	 str = formdo + "?formAction=batchClosed&key1="+batch+"&btchType="+btchType+"&fromPopup="+popup+"&TOKEN_KEY="+token_key;
         }else{
        	 str = formdo + "?formAction=batchClosed&key1="+batch+"&btchType="+btchType+"&fromPopup="+popup;
         }
      
       // var str = formdo + "?formAction=batchClosed&key1="+batch+"&btchType="+btchType+"&fromPopup="+popup;
        //var popup="1"; 
        //var str = formdo + "?formAction=batchClosed&key1="+batch+"&btchType="+btchType+"&fromPopup="+popup;
        redirectWithPostMethodUrl(str);
    }
}

function populateCustdet(formname,operation)
{
    enableDropdown();
    document.forms[formname].formAction.value = operation;
    document.forms[formname].submit();
}

function delbatchpinrec(formname,operation)
{

    if (modify_onClick())
    {

        var IdVal = checkallBtch(formname);
        var BatchVal = IdVal.split(",");

        var Batch       = BatchVal[2];

        statusMsg=getMessage('keyrecsdelwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;
        if(confirm(msg))
        {
            enableDropdown();
            var IdVal = Batch;
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
        else
            return false;
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  Activate Conform
 *
 * Purpose      :  Activate Conform
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function activateconform(formname,operation)
 {
    document.forms[formname].formAction.value = operation;
    document.forms[formname].submit();
 }

 /*-------------------------------------------------------------
   *
   * Function     :  Confirmation On Update
   *
   * Purpose      :  Confirmation Message is displayed on the screen
   *                 when user clicks on update.
   *                 This enables the Dropdown before updating records as
   *                 values from the Disabled dropdowns cannot be submitted
   *
   * Parameters   :
   *
   * Returns      :
   *
   * Comments     :   Used for CVK and PVK
   *
   *-----------------------------------------------------------*/

   function updateCVKPVKrec(formname,operation,tmp)
   {
	   var ret = false;
	   var useExtTR31KeyBlocks = document.forms[0].useExtTR31KeyBlocks.value;
	   if(("true"==useExtTR31KeyBlocks) ? checklengthCVKPVKCSCWithTR31KBH(tmp) : checklengthCVKPVKCSC(tmp)) {
		   if (checkForm(document.forms[0]) && DirtyFormcheck(true))
		   {
			   statusMsg=getMessage('keyrecsupdwishcont');
			   actionMsg=getMessage('keydoyouwancontinue');
			   msg = "___________________________________________________" +
	              	"\n\n" + statusMsg + "\n" +
	              	"___________________________________________________" +
	              	"\n\n" + actionMsg;

			   ret = confirm(msg);
		   }
		   if(ret)
		   {
			   enableDropdown();
			   document.forms[formname].formAction.value = operation;
			   document.forms[formname].submit();
		   }
	   }
   }
   
   function newCVKPVKrec(formname,operation,tmp) {
	   var useExtTR31KeyBlocks = document.forms[0].useExtTR31KeyBlocks.value;
	   if(("true"==useExtTR31KeyBlocks) ? checklengthCVKPVKCSCWithTR31KBH(tmp) : checklengthCVKPVKCSC(tmp)) {
		   newrec(formname,operation);
	   }
   }
   
   function checklengthCVKPVKCSC(tmp) {
	   var keylength = document.forms[0].encrType.value;
	   	if(tmp==1)
	     {
	         var frChkname = document.forms[0].firstCVK;
	         var frChk = document.forms[0].firstCVK.value;
	         var FirstTextbox ="First CVK under ZMK ";
	         var scChk = "";
	         if(keylength == 16) {
	        	 var scChkname = document.forms[0].secondCVK;
	        	 scChk = document.forms[0].secondCVK.value;
	        	 var SecondTextbox ="Second CVK under ZMK ";
	         }
	     }

	     if(tmp==2)
	     {
	         var frChkname = document.forms[0].firstPVK;
	         var frChk = document.forms[0].firstPVK.value;
	         var FirstTextbox ="First PVK under ZMK";
	         var scChk = "";
	         if(keylength == 16) {
	        	 var scChkname = document.forms[0].secondPVK;
	        	 scChk = document.forms[0].secondPVK.value;
	        	 var SecondTextbox ="Second PVK under ZMK";
	         }
	     }
	     if(tmp==3)
	     {
	         var frChkname = document.forms[0].keyvalue;
	         var frChk = document.forms[0].keyvalue.value;
	         var FirstTextbox ="CSC under ZMK";
	         var scChk = "";
	     }
	     

	     if(keylength==16)
	     {
	         if(Trim(frChk) !='' && frChk.length!=16)
	         {


	            errMsg =  getMessage('keycvkpvk1')
	                    + FirstTextbox
	                    + getMessage('keycvkpvk2')
	                    + getMessage('keycvkpvk3')
	                    + frChk
	                    + getMessage('keycvkpvk4');

	            alertErr(errMsg);
	            frChkname.select();
	            frChkname.focus();
	            return false;
	         }
	         if(Trim(scChk) !='' && scChk.length!=16)
	         {

	             errMsg =  getMessage('keycvkpvk1')
	                    + SecondTextbox
	                    + getMessage('keycvkpvk2')
	                    + getMessage('keycvkpvk3')
	                    + scChk
	                    + getMessage('keycvkpvk4');

	            alertErr(errMsg);
	            scChkname.select();
	            scChkname.focus();
	            return false;
	         }
	     }
	     if(keylength==32)
	     {
	         if(Trim(frChk) !='' && frChk.length!=32)
	         {


	            errMsg =  getMessage('keycvkpvk1')
	                    + FirstTextbox
	                    + getMessage('keycvkpvk5')
	                    + getMessage('keycvkpvk3')
	                    + frChk
	                    + getMessage('keycvkpvk4');


	            alertErr(errMsg);
	            frChkname.select();
	            frChkname.focus();
	            return false;
	         }
	         if(Trim(scChk) !='' && scChk.length!=32)
	         {


	            errMsg =  getMessage('keycvkpvk1')
	                    + SecondTextbox
	                    + getMessage('keycvkpvk5')
	                    + getMessage('keycvkpvk3')
	                    + scChk
	                    + getMessage('keycvkpvk4');


	            alertErr(errMsg);
	            scChkname.select();
	            scChkname.focus();
	            return false;
	         }
	     }
	     return true;
   }
   
   
   function checklengthCVKPVKCSCWithTR31KBH(tmp) {
	   var keylength = document.forms[0].encrType.value;
	   	if(tmp==1)
	     {
	         var frChkname = document.forms[0].firstCVK;
	         var frChk = document.forms[0].firstCVK.value;
	         var FirstTextbox ="First CVK under ZMK ";
	         var scChk = "";
	         
	     }

	     if(tmp==2)
	     {
	         var frChkname = document.forms[0].firstPVK;
	         var frChk = document.forms[0].firstPVK.value;
	         var FirstTextbox ="First PVK under ZMK";
	         var scChk = "";
	         
	     }
	     if(tmp==3)
	     {
	         var frChkname = document.forms[0].keyvalue;
	         var frChk = document.forms[0].keyvalue.value;
	         var FirstTextbox ="CSC under ZMK";
	         var scChk = "";
	     }
	     
	     if(keylength==32)
	     {
	         if(Trim(frChk) !='' && (frChk.length!=73 && frChk.length!=81))
	         {


	            errMsg =  getMessage('keycvkpvk1')
	                    + FirstTextbox
	                    + getMessage('keycvkpvk32')
	                    + getMessage('keycvkpvk3')
	                    + frChk
	                    + getMessage('keycvkpvk4');


	            alertErr(errMsg);
	            frChkname.select();
	            frChkname.focus();
	            return false;
	         }
	     }
	     return true;
   }


   /*-------------------------------------------------------------
    *
    * Function     :  To Go Back To Previous Screen
    *
    * Purpose      :  On Clicking on 'BACK' button user taken back to previous page
    *
    * Parameters   :
    *
    * Returns      :
    *
    * Comments     :
    *
    *-----------------------------------------------------------*/
    function visaBack()
    {
        var ar = visaBack.arguments;
        var ret = false;

        alert(ar[0] + ", " + ar[1]);

        statusMsg=getMessage('keyrecsresetwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

        ret = confirm(msg);

        if(ret)
        {
            //window.location.href = ar[0] + "?formAction=" + ar[1];
        }
        else
        {
            return false;
        }

    }

/*-------------------------------------------------------------
 *
 * Function     :  VisaNetMgmtRePopulate
 *
 * Purpose      :  Repopulate the form.
 *
 * Parameters   :  formName and opt
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function VisaNetMgmtRePopulate(formName,opt)
{
    if(opt.selectedIndex == 0)
    {
        return ;
    }
    document.visanetworkmanagementdetailfrm.formAction.value="repopulate";
    document.visanetworkmanagementdetailfrm.submit();
}

/*-------------------------------------------------------------
 *
 * Function     :  updatevisanetworkrec
 *
 * Purpose      :  Updates the visa network management records.
 *
 * Parameters   :  frm and operation
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function updatevisanetworkrec(frm,operation)
 {
    if(checkForm(document.forms[0]))
    {
        statusMsg=getMessage('keyrecsupdwishcontinue');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n" +
            "___________________________________________________" +
            "\n\n" + actionMsg;
        if(confirm(msg))
        {
            document.forms[0].formAction.value=operation;
            document.forms[0].submit();
        }
        else
        return false;
    }
}
/*-------------------------------------------------------------
 *
 * Function     :  isValidArn
 *
 * Purpose      :  Validates the ARN and then populate RRN
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function isValidArn(arg1,arg2)
  {
     var flag = true;
     var ipVal = document.forms[0].elements[arg1].value;
     var ret=parseInt(ipVal.substring(7,11),10);
     if(ipVal =='')
     {
       document.forms[0].elements[arg2].disabled=false;
       return;
      }else if((ipVal.charAt(0) != '2') && (ipVal.charAt(0) != '7'))
      {
        statusMsg=getMessage('keyarn1');
        flag=false;
     }else if (ipVal.length != 23)
     {
        statusMsg=getMessage('keyarn2');
        flag=false;
     }else if ((ret < 1) || (ret > 9366))
     {
        statusMsg=getMessage('keyarn3');
        flag=false;
     }
     if (flag)
     {
         document.forms[0].elements[arg2].value = ipVal.substring(7,8) + ipVal.substring(11,22);
         addFormData('', 'false', -1, 'RRN', -1, 'rrn', '');
         document.forms[0].elements[arg2].disabled=true;
     }
     else
     {
        msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n"
        alert(msg)
        document.forms[0].elements[arg1].focus();
     }
}

/*-------------------------------------------------------------
 *
 * Function     :  disableField
 *
 * Purpose      :  Diables the Card type list fileds
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function disableCrdtyplst(arg1,arg2)
{
    var ipVal1 = document.forms[0].elements[arg1].value;
    var ipVal2 = document.forms[0].elements[arg2].value;
    if(ipVal2 == '')
    {
        document.forms[0].elements[arg1].disabled=false;
        return;
    }
    if(ipVal2 != "")
    {
        document.forms[0].elements[arg1].disabled=true;
        return;
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  disableField
 *
 * Purpose      :  Diables the Card product list
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function disableCrdprodlst(arg1,arg2)
{
    var ipVal1 = document.forms[0].elements[arg1].value;
    var ipVal2 = document.forms[0].elements[arg2].value;
    if(ipVal1 == '')
    {
        document.forms[0].elements[arg2].disabled=false;
        return;
    }
    if(ipVal1 != "")
    {
        document.forms[0].elements[arg2].disabled=true;
        return;
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  disableField
 *
 * Purpose      :  Diables the Card product list
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function disableFields(arg1,arg2)
{
    var ipVal1 = document.forms[0].elements[arg1].value;
    var ipVal2 = document.forms[0].elements[arg2].value;
    if(ipVal1 != "")
    {
        document.forms[0].elements[arg2].disabled=true;
        return;
    }
    if(ipVal2 != "")
    {
        document.forms[0].elements[arg1].disabled=true;
        return;
    }
}


/*-------------------------------------------------------------
 *
 * Function     :  ValidateCPS ACI
 *
 * Purpose      :  Validates the CPS ACI
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function isValidCPSACI(arg1,arg2,arg3)
  {
    var varcpsaci = document.forms[0].elements[arg1].value;


    if ((Trim(varcpsaci) == '' ) || (Trim(varcpsaci) == 'N' ))
    {

          addFormData('', 'false', -1, 'CPS ID', arg3, arg2, '');
          document.forms[0].elements[arg2].disabled=true;
          document.forms[0].elements[arg2].value='';
          document.forms[0].elements[arg2].style.backgroundColor='rgb(205,205,205)';
    }
    else
    {
          document.forms[0].elements[arg2].disabled=false;
          // Modified for AT-0492
          document.forms[0].elements[arg2].style.backgroundColor='';
          addFormData('eq15', 'true', -1, 'CPS ID', arg3, arg2, '');
    }
 }

 /*-------------------------------------------------------------
  *
  * Function     :  validateVirspCodeAndAddNewRec()
  *
  * Purpose      :
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :  The VISA Action Code
  *                 should be within the (04,05,07,11,41,43) list
  *                 and adds new records
  *
  *-----------------------------------------------------------*/

  function validateVirspCodeAndAddNewRec(arg1,arg2,arg3)
  {
    enableDropdown();
    var virsValue = arg1;
    var virspCodeArray = new Array("04","05","07","11","41","43");
    var flag = false;
    for (var i=0; i<virspCodeArray.length; i++)
    {
        if(virspCodeArray[i]==Trim(virsValue))
            flag=true;
    }
    if (!flag && virsValue!="")
    {
        var statusMsg = getMessage('keyplstryagain1') + "\n" + getMessage('keyplstryagain2');
        var actionMsg = getMessage('keyForVisaActionCode');
        msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n"+
            "___________________________________________________" +
            "\n\n" + actionMsg + "\n";

        alert(msg)
        document.forms[0].virspCode.focus();
    }
    else
    {
        newrec(arg2,arg3);
    }
  }

 /*-------------------------------------------------------------
  *
  * Function     :  tabbedSearch()
  *
  * Purpose      :
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function tabbedSearch()
  {
     var ret = false;
     if (checkForm(document.forms[0]))
     {
        enableDropdown();
        document.forms[0].tabCheck.value = 'tab';
        document.forms[0].formAction.value = 'search';
        document.forms[0].submit();
     }
  }

/*-------------------------------------------------------------
 *
 * Function     :  Validate MCCRange
 *
 * Purpose      :  Validates the MCC Range
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function isValidMccRange(arg1,arg2,arg3)
  {

    var varrectyp = document.forms[0].elements[arg1].value;
    var varmccstart = document.forms[0].elements[arg2].value;

    if ( (Trim(varrectyp) == 'VNATELEC' ) && ( (Trim(varmccstart) == 6010) || (Trim(varmccstart) == 6011) ) )
    {
          addFormData('money', 'false', -1, 'Limit in US dollars', -1, 'strVal', '');
          document.forms[0].elements[arg3].disabled=true;
          document.forms[0].elements[arg3].value='';
          document.forms[0].elements[arg3].style.backgroundColor='rgb(205,205,205)';
    }
    else
    {
         addFormData('money', 'true', -1, 'Limit in US dollars', -1, 'strVal', '');
          document.forms[0].elements[arg3].disabled=false;
          document.forms[0].elements[arg3].style.backgroundColor='#FFFFCC';
    }
 }


//Added for Visa Flags Zoom
function zoomvisaflags()
{

   var parentformname= document.forms[0].parentFormName.value;
    var textboxname= document.forms[0].parentTextBoxName.value;

    var f1 = document.forms[0].floorLimit.value ;
    var f2 = document.forms[0].cardRecov.value ;
    var f3 = document.forms[0].authSource.value ;
    var f4 = document.forms[0].mail.value ;
    var f5 = document.forms[0].spChgbk.value ;
    var f6 = document.forms[0].spCond1.value ;
    var f7 = document.forms[0].spCond2.value ;

    var flag = f1+f2+f3+f4+f5+f6+f7;
    var parentTextBox = eval("window.opener.document."+parentformname+"."+textboxname);
    parentTextBox.value = flag;
    window.close();
}

/*-------------------------------------------------------------
 *
 * Function     :  checkTranslength
 *
 * Purpose      :  Checks string to see if it's a valid digit
 *
 * Parameters   :  ip       - the string to test
 *                 fldName  - the name of the field on the form
 *                            (the name of the label)
 *
 * Returns      :  true     - if input is valid
 *                 false    - otherwise
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function checkTranslength(parentformname,textboxname1,jspname)
    {
       var c=eval("document."+parentformname+"."+textboxname1+".value");

        var count=0;
        for(i=0; i<c.length;i++)
        {
            if(!((c.charAt(i) >= '0') && (c.charAt(i) <= '9')))
              {
                alert(getMessage('keyval0to9'));
                return false;
              }
              count++;
        }
         if(count != 100)
         {
            alert(getMessage('keylen100'));
            return false;
         }
         if(count == 100)
         {
            ZoomSearchProfile(parentformname, textboxname1,jspname);
         }
         return true;


    }

/*-------------------------------------------------------------
 *
 * Function     :  isValidAuthdet
 *
 * Purpose      :  Validates the MCC Range
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
 function isValidAuthdet(arg1)
  {
    var varhostname = document.forms[0].elements[arg1].value;
    if ( (Trim(varhostname) != '' ) )
    {
          addFormData('string', 'true', -1, 'Host service name', -1, 'hostsvc', '')
    }
    else
    {
          addFormData('string', 'false', -1, 'Host service name', -1, 'hostsvc', '')
    }
 }

/*-------------------------------------------------------------
 *
 * Function     :  newreccurr
 *
 * Purpose      :  Validates the MCC Range
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
  function newreccurr(formname,operation,arg1,arg2)
  {
     var ret = false;
     var varbasecurr = document.forms[0].elements[arg1].value;
     var varcurr = document.forms[0].elements[arg2].value;
     if(varbasecurr == varcurr)
     {
        statusMsg=getMessage('keyplstryagain');
        actionMsg=getMessage('keybasecurrequal');
        msg = "___________________________________________________" +
                 "\n\n" + statusMsg + "\n" +
                 "___________________________________________________" +
                "\n\n" + actionMsg;
        alert(msg);
     }
     else if (checkForm(document.forms[0]))
     {
         statusMsg=getMessage('keyrecsaddwishcont');
         actionMsg=getMessage('keydoyouwancontinue');
         msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;
      ret = confirm(msg);
      }
     if(ret)
        {
         enableDropdown();
         document.forms[formname].formAction.value = operation;
         document.forms[formname].submit();
        }
 }


/*-------------------------------------------------------------
 *
 * Function     :  updateCardAmount
 *
 * Purpose      :  Updates the Updates Card Amount records.
 *
 * Parameters   :  formname and operation
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function updateCardAmount(formname,operation)
{
    if(currencyGraterZero(document.forms[0].strNewAmt))
    {
        var ret = false;
        //Added for AT-0152
        if(!DirtyFormcheck(true))
        {
        statusMsg=getMessage('keydirtyreadnot');
        alert(statusMsg);
        }

        if (checkForm(document.forms[0]) && DirtyFormcheck(true))
        {
            statusMsg=getMessage('keyrecsupdwishcont');
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n" +
            "___________________________________________________" +
            "\n\n" + actionMsg;
            ret = confirm(msg);
        }
        if(ret)
        {
            enableDropdown();
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
    }
}

    /*-------------------------------------------------------------
     *
     * Function     :
     *
     * Purpose      :
     *
     * Parameters   :  parentformname,formaction,value
     *
     * Returns      :
     *
     * Comments     :  called from ATMControlStatusDetail
     *
     *-----------------------------------------------------------*/

     function performrec(psform,psaction,psvalue)
     {
         enableDropdown();
         document.atmcontrolstatusdetailfrm.detailAction.value = psvalue;
         document.atmcontrolstatusdetailfrm.formAction.value = psaction;
         document.atmcontrolstatusdetailfrm.submit();
     }

/*-------------------------------------------------------------
 *
 * Function     :  ZoomCustListSearch
 *
 * Purpose      :  Used to popup the Zoom  Search window
 *
 * Parameters   :  textboxname Variable which holds the textbox name.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function ZoomCustListSearch(parentformname,textboxname1,textboxname2,textboxname3,textboxname4,textboxname5,textboxname6,textboxname7,textboxname8,textboxname9,textboxname10,textboxname11,jspname)
{
    ZoomPanScreenSearch(parentformname,textboxname1,textboxname2,textboxname3,textboxname4,textboxname5,textboxname6,textboxname7,textboxname8,textboxname9,textboxname10,textboxname11,jspname);
}

/*-------------------------------------------------------------
 *
 * Function     :  ZoomCustListSelect
 *
 * Purpose      :  Used to populate the parent field with the selected value
 *
 * Parameters   :  formname Variable that holds the parent form name.
 *              :  textboxname Variable that holds the parent text box name.
 *              :  var1 Variable that holds the data value.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function ZoomCustListSelect(parentformname,textboxname1,textboxname2,textboxname3,textboxname4,textboxname5,textboxname6,textboxname7,textboxname8,textboxname9,textboxname10,textboxname11,var1,var2,var3,var4,var5,var6,var7,var8,var9,var10,var11)
{

    var parentTextBox1 = eval("window.opener.document."+parentformname+"."+textboxname1);
    parentTextBox1.value = Trim(var1);
    var parentTextBox2 = eval("window.opener.document."+parentformname+"."+textboxname2);
    parentTextBox2.value = Trim(var2);
    var parentTextBox3 = eval("window.opener.document."+parentformname+"."+textboxname3);
    parentTextBox3.value = Trim(var3);
    var parentTextBox4 = eval("window.opener.document."+parentformname+"."+textboxname4);
    parentTextBox4.value = Trim(var4);
    var parentTextBox5 = eval("window.opener.document."+parentformname+"."+textboxname5);
    parentTextBox5.value = Trim(var5);
    var parentTextBox6 = eval("window.opener.document."+parentformname+"."+textboxname6);
    parentTextBox6.value = Trim(var6);
    var parentTextBox7 = eval("window.opener.document."+parentformname+"."+textboxname7);
    parentTextBox7.value = Trim(var7);
    var parentTextBox8 = eval("window.opener.document."+parentformname+"."+textboxname8);
    parentTextBox8.value = Trim(var8);
    var parentTextBox9 = eval("window.opener.document."+parentformname+"."+textboxname9);
    parentTextBox9.value = Trim(var9);
    var parentTextBox10 = eval("window.opener.document."+parentformname+"."+textboxname10);
    parentTextBox10.value = Trim(var10);
    var parentTextBox11 = eval("window.opener.document."+parentformname+"."+textboxname11);
    parentTextBox11.value = Trim(var11);
    window.close();
    // Focus on the customer code field which sometimes reload form information when changed
    focusEl(parentTextBox1);    // Don't remove this line, it is required!
    focusEl(parentTextBox10);
}

    /*-------------------------------------------------------------
    *
    * Function     :  searchTabAtmStatuses() used for ATM Statuses Screen.
    *
    * Purpose      :  To perform the validation part for Tabbed search screen
    *                 as we cannot use the default validation tabbed screens.
    *
    * Parameters   :
    *
    * Returns      :
    *
    * Comments     :
    *
    *-----------------------------------------------------------*/
    function searchTabAtmStatuses()
    {
        if(document.forms[0].tabid.value == 0)
        {
            if(Trim(document.forms[0].strDatelocale.value)=='')
            {
                err = getMessage('keydatelocal') + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].strDatelocale);

                return false;
            }
        }
        if(document.forms[0].tabid.value == 1)
        {
            if(Trim(document.forms[0].termcode2.value)=='')
            {
                err = getMessage('keytermcode') + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].termcode2);

                return false;
            }
            if(Trim(document.forms[0].strDatelocale2.value)=='')
            {
                err = getMessage('keydatelocal') + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].strDatelocale2);

                return false;
            }

        }
        if(document.forms[0].tabid.value == 2)
        {
            if(Trim(document.forms[0].termcode3.value)=='')
            {
                err = getMessage('keytermcode') + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].termcode3);

                return false;
            }
            if(Trim(document.forms[0].strDatelocale3.value)=='')
            {
                err = getMessage('keydatelocal') + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].strDatelocale3);

                return false;
            }
            if(Trim(document.forms[0].dvccode.value)=='')
            {
                err = getMessage('keydvccode') + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].dvccode);

                return false;
            }

        }
        if(document.forms[0].tabid.value == 3)
        {
            if(Trim(document.forms[0].termcode4.value)=='')
            {
                err = getMessage('keytermcode') + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].termcode4);

                return false;
            }
            if(Trim(document.forms[0].strDatelocale4.value)=='')
            {
                err = getMessage('keydatelocal') + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].strDatelocale4);

                return false;
             }
            if(Trim(document.forms[0].strSeverity.value)=='')
            {
                err = getMessage('keyseverity') + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].strSeverity);

                return false;
            }

        }

    enableDropdown();
    document.forms[0].tabCheck.value = 'tab';
    document.forms[0].formAction.value = 'search';
    document.forms[0].submit();
    }

    /*-------------------------------------------------------------
    *
    * Function     :  navigatetlogchild
    *
    * Purpose      :  This method is Used for TLog Screen to navigate
                      to child screens.
    *
    * Parameters   :  doStr Variable that holds the .do and key for id.
    *
    * Returns      :
    *
    * Comments     :  Added for Iteration 6
    *-----------------------------------------------------------*/
    function navigatetlogchild(dostr,key)
    {
        var params = "formAction=null&"+key+"="+document.forms[0].id.value+"&key2=0";
        var token_key = document.getElementsByName("TOKEN_KEY")[0].value;
        if(token_key !=''){
           params = params.concat(params, "&TOKEN_KEY="+token_key);
        }
        redirectWithPostMethod(dostr, params);
    }

    /*--------------------------------------------------------------------
    *
    * Function     :  Custom Navigation without any confirmation message.
    *
    * Purpose      :  Confirmation Message is not displayed on the screen
    *                 when user clicks on appropriate button.
    *                 This enables the Dropdown before submiting records as
    *                 values from the Disabled dropdowns cannot be submitted
    *
    * Parameters   :actionfile,formname,operation,keycustommsg
    *
    * Returns      :
    *
    * Comments     :
    *
    *----------------------------------------------------------------------*/
    function customnavigatenoconfirm(actionfile,formname,operation)
    {
        var ret = false;
        enableDropdown();
        document.forms[formname].action = actionfile + "?formAction=" + operation;
        document.forms[formname].submit();
    }

 /*--------------------------------------------------------------------
    *
    * Function     :  CustOnChange()
    *
    * Purpose      :  This enables the Dropdown depending on the customer type
    *                 selected
    *
    * Comments     :  Called from IaCustdetDetail.jsp
    *
    *----------------------------------------------------------------------*/
    function CustOnChange()
    {
        var type=document.forms[0].typeid.value;
        if(type==2)
        {
            addFormData('dropdown', 'false', -1, 'Marital status', -1, 'married', '');
            addFormData('dropdown', 'false', -1, 'Sex', -1, 'sex', '');
            document.forms[0].sex.value="";
            document.forms[0].married.value="";
            document.forms[0].sex.disabled=true;
            document.forms[0].married.disabled=true;
        }
        else
        {
            addFormData('dropdown', 'true', -1, 'Marital status', -1, 'married', '');
            addFormData('dropdown', 'true', -1, 'Sex', -1, 'sex', '');
            document.forms[0].sex.disabled=false;
            document.forms[0].married.disabled=false;
        }
    }

    /*-------------------------------------------------------------
     *
     * Function     :  BackToParentWindow
     *
     * Purpose      :  Used to call the Parent screen from the child.
     *
     * Parameters   :  var Variable that holds the case no: of the switch
     *                  statement that has to enter in the action class.
     *
     * Returns      :
     *
     * Comments     :
     *
     *-----------------------------------------------------------*/
    function BackToParentWindow(var1)
    {
    	redirectWithPostMethod("iacardmaintenancedetailon.do", "formAction=edit&key3="+ encodeURIComponent(var1));
    }

    /*-------------------------------------------------------------
     * Function     :  BackToParentWindowFromCust
     * Purpose      :  Used to call the Parent screen from the customer specific child.
     * Parameters   :  var Variable that holds the case no: of the switch
     *                  statement that has to enter in the action class.
     *-----------------------------------------------------------*/
    function BackToParentWindowFromCust(var1)
    {
    	redirectWithPostMethod("../iacardmaintenancedetailon.do", "formAction=edit&key3="+var1);
    }

     /*-------------------------------------------------------------
     *
     * Function     :  BackToChildParent
     *
     * Purpose      :  Used to return to the custdet screen from their respective child screens.
     *
     * Parameters   :  var Variable that holds the case no: of the switch
     *                  statement that has to enter in the action class.
     * Returns      :
     *
     * Comments     :
     *
     *-----------------------------------------------------------*/
    function BackToChildParent(var1)
    {
    	redirectWithPostMethod("iacustdetdetailon.do", "formAction=edit&key3="+ encodeURIComponent(var1));
    }

    /*-------------------------------------------------------------
     *
     * Function     :  BackToAccDetParent
     *
     * Purpose      :  Used to return to the accdet screen from their respective child screens.
     *
     * Parameters   :  var Variable that holds the case no: of the switch
     *                  statement that has to enter in the action class.
     * Returns      :
     *
     * Comments     :
     *
     *-----------------------------------------------------------*/
    function BackToAccDetParent(var1)
    {
    	redirectWithPostMethod("iaaccdetdetailon.do", "?formAction=edit&key4="+ encodeURIComponent(var1));
    }

 /*-------------------------------------------------------------
  *
  * Function     :  Perform linkaccount functionality
  *
  * Purpose      :
  *
  * Parameters   :  null
  *
  * Returns      :
  *
  * Comments     : Added by Zakir on 12/09/2002 for Link Account button
  *                in Card Account Relationship screen
  *
  *-----------------------------------------------------------*/

  function accountlink()
  {
    var ar = accountlink.arguments;
    var str = ar[0] + "?formAction=linkaccount&fromwhere=1";

    for(i=1;i<ar.length;i++)
    {
        str = str + ("&key" + i) + "=" + encodeURIComponent(ar[i]);
    }
    redirectWithPostMethodUrl(str);
  }



/*-------------------------------------------------------------
 *
 * Function     :  sort_page().
 *
 * Purpose      :  Used for sorting
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added according to Dhanu's comments for Dynamic Sorting
 *
 *-----------------------------------------------------------*/

 function sort_page(varColumn,varDirection)
 {
     document.forms[0].formAction.value = 'search';
     document.forms[0].sortColumn.value = varColumn;
     document.forms[0].sortDirection.value = varDirection;
     document.forms[0].submit();
 }

 /*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Importing Files  after checking the mandatory field
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *         when user clicks on import.
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function importrec(formname,operation)
  {
     var ret = false;
     if (checkForm(document.forms[0]))
     {
         statusMsg=getMessage('keyrecsimportwishcont');
         actionMsg=getMessage('keydoyouwancontinue');
         msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;
      ret = confirm(msg);
      }
      if(ret)
      {
         enableDropdown();
         document.forms[formname].formAction.value = operation;
         document.forms[formname].submit();
      }
  }

 /*-------------------------------------------------------------
 *
 * Function     :  refreshsetcard
 *
 * Purpose      :  This method is Used to get Set Card Status
 *                 Details.
 *
 * Parameters   :  none
 *
 * Returns      :  none
 *
 * Comments     :  Added for Iteration 6
 *-----------------------------------------------------------*/

function refreshsetcard()
{
    enableDropdown();
    document.setcardstatusdetailfrm.formAction.value="edit";
    document.setcardstatusdetailfrm.submit();
}

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Report
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *                 when user clicks on Run Report.
 *                 This enables the Dropdown before updating records as
 *                 values from the Disabled dropdowns cannot be submitted
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
 
function reportrec(formname,operation)
{
    var ret = false;
 
    if (checkForm(document.forms[0]))
    {
        statusMsg=getMessage('keyrecsupdwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n" +
            "___________________________________________________" +
            "\n\n" + actionMsg;
 
        ret = confirm(msg);
    }
  
    if(ret)
    {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
}   


 /*-------------------------------------------------------------
 *
 * Function     :  checkstatus
 *
 * Purpose      :  This method is Used to check the status
 *                 which has been chaged.
 *
 * Parameters   :  none
 *
 * Returns      :  none
 *
 * Comments     :  Added for Iteration 6
 *-----------------------------------------------------------*/

function checkstatus()
{
    if(document.setcardstatusdetailfrm.updateoldcardstat.value == '2')
    {
        if(document.setcardstatusdetailfrm.oldcardstat.value == document.setcardstatusdetailfrm.statcode.value)
        {
            msg = "___________________________________________________" +
                     "\n\n" + oldstatuscheck + "\n" +
                  "___________________________________________________";
            alert(msg);
            document.setcardstatusdetailfrm.statcode.value="";
            document.setcardstatusdetailfrm.statcode.focus();
        }
    }
    else
    {
        if(document.setcardstatusdetailfrm.oldstat.value == document.setcardstatusdetailfrm.statcode.value)
        {
            msg = "___________________________________________________" +
                     "\n\n" + currentstatuscheck + "\n" +
                  "___________________________________________________";
            alert(msg);
            document.setcardstatusdetailfrm.statcode.value="";
            document.setcardstatusdetailfrm.statcode.focus();
        }
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  zoomSelectAccNumber
 *
 * Purpose      :  Used to populate the parent field with the selected value
 *
 * Parameters   :  formname Variable that holds the parent form name.
 *              :  textboxname Variable that holds the parent text box name.
 *              :  var1 Variable that holds the data value.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function zoomSelectAccNumber(parentformname,textboxname1,var1)
{
    var parentTextBox1 = eval("window.opener.document."+parentformname+"."+textboxname1);
    parentTextBox1.value = Trim(var1);
    window.close();
}

/*------------------------------------------------------------- 
* 
* Function     :  zoomSelectAccNumberCurrCode
*
* Purpose      :  Used to populate the parent field with the selected value
*
* Parameters   :  formname Variable that holds the parent form name.
*              :  textboxname Variable that holds the parent text box name.
*              :  var1 and var2 Variable that holds the data value.
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/
function zoomSelectAccNumberCurrCode(parentformname,textboxname1,var1,textboxname2,var2)
{
	var parentTextBox1 = eval("window.opener.document."+parentformname+"."+textboxname1);
	parentTextBox1.value = Trim(var1);
   
	var parentTextBox2 = eval("window.opener.document."+parentformname+"."+textboxname2);
	parentTextBox2.value = Trim(var2);
	//alert(parentTextBox1.value +" / "+ parentTextBox2.value);
	window.close();
}



/*-------------------------------------------------------------
 *
 * Function     :  ZoomSearchAccNumber
 *
 * Purpose      :  Used to popup the Zoom  Search window
 *
 * Parameters   :  textboxname Variable which holds the textbox name.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function ZoomSearchAccNumber(parentformname,textboxname1,jspname)
{
    ZoomPanScreenSearch(parentformname,textboxname1,jspname);
}

 /*-------------------------------------------------------------
  *
  * Function     :  Refresh the current record
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on Refresh.
  *
  *
  * Parameters   :  null
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/
  function cardAccRefreshrec()
  {
    var ret = true;
    if (DirtyFormcheck(true))
    {

     statusMsg=getMessage('keyrecsrefwishcont');
     actionMsg=getMessage('keydoyouwancontinue');
     msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

     ret = confirm(msg);
     }
    if(ret)
       {
        enableDropdown();
        document.forms[0].formAction.value = 'refresh';
        document.forms[0].fromwhere.value = '1';
        document.forms[0].submit();
       }
  }


    /*-------------------------------------------------------------
    *
    * Function     :  addorupdateparammaint
    *
    * Purpose      :  Confirmation On Adding/Updating a record for Parameter Maintenance after checking the mandatory field
    *                 And Also custom validation for the same.
    *
    * Parameters   : formname - name of the form, operation - Add/Update
    *
    * Returns      :
    *
    * Comments     :
    *
    *-----------------------------------------------------------*/
    function addorupdateparammaint(formname,operation)
    {
        var bValid = true;
        var objFocusField = null;

        var statusMsg = "";
        var actionMsg = "";

        // First call checkForm to force mandatory field validations.
        if (!checkForm(document.forms[0]))
        {
            return false;
        }

        // Check for Type selected and do the appropriate Masking validation for the same.
        var dropDownType = document.forms[formname].type;
        var TypeValue = dropDownType.options[dropDownType.selectedIndex].value;

        var txtValue = document.forms[formname].formValue;
        var txtStrDate_t = document.forms[formname].strDate_t;

        if(TypeValue == "S")        //String Mask
        {
            if( (!isValidString(txtValue.value,txtValue)) || (Trim(txtValue.value) == '') )
            {
                actionMsg = getMessage('keystringinvalid');
                objFocusField = txtValue;
                bValid = false;
            }
        }
        else if(TypeValue == "L")  //Long Mask
        {
            if(!isValidLongMask(txtValue))
            {
                actionMsg = getMessage('keylonginvalid');
                objFocusField = txtValue;
                bValid = false;
            }
        }
        else if(TypeValue == "I")   //Short Mask
        {
            if(!isValidShortMask(txtValue))
            {
                actionMsg = getMessage('keyshortinvalid');
                objFocusField = txtValue;
                bValid = false;
            }
        }
        else if(TypeValue == "F")   //Double Mask
        {
            if(!isValidDoubleMask(txtValue))
            {
                actionMsg = getMessage('keydoubleinvalid');
                objFocusField = txtValue;
                bValid = false;
            }
        }
        else if(TypeValue == "D")   //Date Mask
        {
            if(!isValidDateMask(txtStrDate_t))
            {
                actionMsg = getMessage('keydateinvalid');
                objFocusField = txtStrDate_t;
                bValid = false;
            }
        }


        // Common block of code...
        statusMsg = getMessage('keyplstryagain1') + "\n" + getMessage('keyplstryagain2');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n"+
        "___________________________________________________" +
        "\n\n" + actionMsg + "\n";

        if(!bValid)
        {
            alert(msg)
            focusEl(objFocusField);
            return false;
        }

       //Validations over....
        statusMsg= (operation == "add") ? getMessage('keyrecsaddwishcont') : getMessage('keyrecsupdwishcont') ;
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;

         ret = confirm(msg);

        if(ret)
        {
            enableDropdown();
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
    }

    /*-------------------------------------------------------------------------------------------
    *
    * Function     :  isValidLongMask
    *
    * Purpose      :  This Masking validation for Long type of data for Parameter maintenance screen.
    *
    * Parameters   :  field - holds the field to be validated.
    *
    * Returns      :  boolean
    *
    * Comments     : Max value - (+999999999) and Min value - (-999999999), No Decimal values accepted.
    *
    *----------------------------------------------------------------------------------------------*/
    function isValidLongMask(field)
    {
        if (Trim(field.value) == '' )
        {
           return false;
        }
        else if(isNaN(field.value))
        {
           return false;
        }
        else if( (parseInt(field.value,10) < parseInt(-999999999,10)) || (parseInt(field.value,10) > parseInt(+999999999,10)) )
        {
            return false;
        }
        else if(field.value.indexOf(".") >= 0)
        {
            return false;
        }
        else
        {
           return true;
        }
    }

    /*-------------------------------------------------------------------------------------------
    *
    * Function     :  isValidShortMask
    *
    * Purpose      :  This Masking validation for Short type of data for Parameter maintenance screen.
    *
    * Parameters   :  field - holds the field to be validated.
    *
    * Returns      :  boolean
    *
    * Comments     : Max value - (+9999) and Min value - (-9999), No Decimal values accepted.
    *
    *----------------------------------------------------------------------------------------------*/

    function isValidShortMask(field)
    {
        if (Trim(field.value) == '' )
        {
           return false;
        }
        else if(isNaN(field.value))
        {
            return false;
        }
        else if( (parseInt(field.value,10) < parseInt(-9999,10)) || (parseInt(field.value,10) > parseInt(9999,10)) )
        {
            return false;
        }
        else if(field.value.indexOf(".") >= 0)
        {
            return false;
        }
        else
        {
           return true;
        }
    }

    /*-------------------------------------------------------------------------------------------
    *
    * Function     :  isValidDoubleMask
    *
    * Purpose      :  This Masking validation for Double type of data for Parameter maintenance screen.
    *
    * Parameters   :  field - holds the field to be validated.
    *
    * Returns      :  boolean
    * Comments     : Valid values are Max of 4 digits containing upto 2 decimal palces.
    *                Negative values are accepted.
    *
    *----------------------------------------------------------------------------------------------*/
    function isValidDoubleMask(field)
    {
        if (Trim(field.value) == '' )
        {
           return false;
        }
        else if(isNaN(field.value))
        {
           return false;
        }
        else
        {
            //Now Check if decimal values with max of 5 digits containing upto 2 decimal digits are present.
            //And for integers -9999 to + 9999
            var isDecimal = (field.value.indexOf(".") >= 0);

            if(isDecimal)
            {
                // Total digit should be <=5 digits including decimal and
                // Allow max of 2 decimal digits.
                var decIndex    = field.value.indexOf(".");
                var digitLength = field.value.length;
                var noOfDecimalDigit = digitLength - decIndex;
                noOfDecimalDigit = noOfDecimalDigit - 1;

                var valueFiveOrSix = 5;

                // If negative digit then max length can be upto 6 digits.
                if (field.value < 0)
                {
                    valueFiveOrSix = 6;
                }

                if( (digitLength <= valueFiveOrSix) && (noOfDecimalDigit <= 2) )
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            else //Integer only
            {
               return ( ((parseInt(field.value,10) < parseInt(-9999,10)) || (parseInt(field.value,10) > parseInt(9999,10)) ) ? false : true );
            }
        }

    }

    /*-------------------------------------------------------------------------------------------
    *
    * Function     :  isValidDateMask
    *
    * Purpose      :  This Masking validation for Date type of data for Parameter maintenance screen.
    *
    * Parameters   :  field - holds the field to be validated.
    *
    * Returns      :  boolean
    * Comments     : This only checks for non empty field for date as actual date validation is done
    *                at the Action level.
    *
    *
    *----------------------------------------------------------------------------------------------*/
    function isValidDateMask(field)
    {
        if (Trim(field.value) == '' )
        {
           return false;
        }

        return true;
    }


    /*-------------------------------------------------------------
     *
     * Function     :  stateRePopulate
     *
     * Purpose      :  Repopulate the VoiceAuthorisationform form.
     *
     * Parameters   :  none
     *
     * Returns      :
     *
     * Comments     :
     *
     *-----------------------------------------------------------*/
    function voiceRePopulate(arg1,arg2,arg3,parentTextBox1)
    {
        var varinst = document.forms[0].elements[arg1].value;
        var varmrchno = document.forms[0].elements[arg2].value;
        var varpan = document.forms[0].elements[arg3].value;
        var mObjval = eval("document.forms[0]."+ arg2)
        var  valmrchno = defVal[mObjval.name];
        var mObjpan = eval("document.forms[0]."+ arg3)
        var  valpan = defVal[mObjpan.name];
        if(varinst== '')
        {
            actionMsg=getMessage('keyinstnull');
            msg = actionMsg ;
            alert(msg);
            return false;
        }
        else if(varmrchno == '')
        {
            actionMsg=getMessage('keyimrcnonull');
            msg = actionMsg ;
            alert(msg);
            return false;
        }
        else if(varpan == '' || varpan == valpan)
        {
            document.forms[0].elements[parentTextBox1].focus()
            return false;

        }
        else
        {
            enableDropdown();
            document.vmvoiceauthorisationfrm.formAction.value="repopulate";
            document.vmvoiceauthorisationfrm.submit();
        }
    }
    
/*-------------------------------------------------------------
 *
 * Function     :  ZoomSearchGeneric
 *
 * Purpose      :  Used to popup the Zoom  Search window
 *
 * Parameters   :  Parent form name
 *                 Zoom JSP name
 *                 Parent form field names
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function ZoomSearchGeneric()
{
    var args = ZoomSearchGeneric.arguments;
    var parentformname = args[0];
    var jspname = args[1];
    var screenName = jspname;
    var dec = screenName.indexOf(".");
    if(dec > 0)
    {
        screenName =  screenName.substring(0,dec);
    }
    var params = "parentFormName="+parentformname;
    var i;
 
    // Add all the remaining variables as textbox names to the request
    for(i=2; i<args.length; i++)
    {
        params = params + ("&parentTextBoxName" + (i - 1)) + "=" + args[i];
    }
    // Open a new zoom window
    var GenericZoomWin = openWindowWithPostMethod(jspname, screenName, params, "toolbar=no,location=no," +
    		"directories=no,status=yes,menubar=no,scrollbars=yes," + "resizable=no,width=600,height=400");
 
}

/*-------------------------------------------------------------
 *
 * Function     :  ZoomSearchGenericPath
 *
 * Purpose      :  Used to popup the Zoom  Search window
 *                 when a path is needed
 *
 * Parameters   :  Parent form name
 *                 Path
 *                 Zoom JSP name
 *                 Parent form field names
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function ZoomSearchGenericPath()
{
    var args = ZoomSearchGenericPath.arguments;
    var parentformname = args[0];
    var path = args[1]
    var jspname = args[2];
    var screenName = jspname;
    var dec = screenName.indexOf(".");
    if(dec > 0)
    {
        screenName =  screenName.substring(0,dec);
    }
    var params = "parentFormName="+parentformname;
    var i;
 
    // Add all the remaining variables as textbox names to the request
    for(i=3; i<args.length; i++)
    {
        params = params + ("&parentTextBoxName" + (i - 2)) + "=" + args[i];
    }
    // Open a new zoom window
    var GenericZoomWin = openWindowWithPostMethod(path + jspname, screenName, params, "toolbar=no,location=no," +
    		"directories=no,status=yes,menubar=no,scrollbars=yes," + "resizable=no,width=600,height=400");
 
}

/*-------------------------------------------------------------
 *
 * Function     :  zoomSearchExtraGeneric
 *
 * Purpose      :  Used to populate the parent field with the selected value
 *
 * Parameters   :  Parent form name
 *                 number of information fields
 *                 Parent form information field names
 *                 Parent form field names to be populated
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function zoomSearchExtraGeneric()
{
    var args = zoomSearchExtraGeneric.arguments;
    var parentformname = args[0];
    var jspname = args[1];
    var screenName = jspname;
    var dec = screenName.indexOf(".");
    if(dec > 0)
    {
        screenName =  screenName.substring(0,dec);
    }
    var inf_fields = args[2];
    var params = "parentFormName="+parentformname;
    var i;
 
    // Add all the information variables to the request
    for(i=3; i < 3 + inf_fields; i++)
    {
        params = params + ("&infoField" + (i - 2)) + "=" + eval("document."+parentformname+"."+args[i]+".value");
    }
 
    // Add all the remaining variables as textbox names to the request
    for(i=3 + inf_fields; i < args.length; i++)
    {
         params = params + ("&parentTextBoxName" + (i - (2 + inf_fields))) + "=" + args[i];
    }
 
    var GenericZoomWin = openWindowWithPostMethod(jspname, screenName, params, "toolbar=no,location=no," +
            "directories=no,status=yes,menubar=no,scrollbars=yes," + "resizable=no,width=600,height=400");
}

/*-------------------------------------------------------------
 *
 * Function     :  SearchGeneric
 *
 * Purpose      :  Used to populate the parent field with the selected value
 *
 * Parameters   :  Parent form name
 *                 target jspname
 *                 string of named fields with values & seperated
 *                 number of information fields
 *                 Parent form information field names
 *                 Parent form field names to be populated
 *
 * Returns      :
 *
 * Comments     :  Same as zoomSearchExtraGeneric
 *                 but with extra named fields and values
 *                 and does not use a new window and
 *                 does not resise
 *                 DMG 21/11/2002
 *
 *-----------------------------------------------------------*/
function SearchGeneric()
{
	var args = SearchGeneric.arguments;
    var parentformname = args[0];
    var jspname = args[1];
    var named_flds = args[2];
    var inf_fields = args[3];
    var params = "parentFormName="+parentformname;
    var i;
 
    // Add all the information variables to the request
    for(i=4; i < 4 + inf_fields; i++)
    {
        params = params + ("&infoField" + (i - 3)) + "=" + eval("document."+parentformname+"."+args[i]+".value");
    }
 
    // Add the named fields
    params = params + "&" + named_flds;
 
    // Add all the remaining variables as textbox names to the request
    for(i=4 + inf_fields; i < args.length; i++)
    {
        params = params + ("&parentTextBoxName" + (i - (3 + inf_fields))) + "=" + args[i];
    }
 
    redirectWithPostMethod(jspname, params);
}    
/*-------------------------------------------------------------
 *
 * Function     :  OpenScreen
 *
 * Purpose      :  Used for opening screens without any formAction
 *
 * Parameters   :  var Variable that holds the info of the selected row.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function OpenScreen()
{
    var ar = OpenScreen.arguments;
    var str = "formAction=";
    
    // force conversion of element names to key1 ... keyn after unmasking
    str = str + "&namesToKeys=true";

    for(i=1;i<ar.length;i++)
    {
        
        // we need to check if the argument passed is a string or an element
    	if(!ar[i].name)
    	{    		
    		// we have a string
    		str = str + ("&key" + i) + "=" + encodeURIComponent(ar[i]);
    	}
    	else
    	{
    		// We have an element
    		str = str + "&" + ar[i].name + "=" + encodeURIComponent(ar[i].value);
    	}
        
    }
    
    if(document.forms[0].formAcsitem)
    {
    	// add on the acsitem passed 
    	str = str + "&formAcsitem=" + document.forms[0].formAcsitem.value;
    }
    
    redirectWithPostMethod(ar[0], str);
    enableDropdown();
    
}

/*-------------------------------------------------------------
 *
 * Function     :  OpenScreenWithAction
 *
 * Purpose      :  Used for opening screens with a formAction
 *
 * Parameters   :  var Variable that holds the info of the selected row.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function OpenScreenWithAction()
{
    var ar = OpenScreenWithAction.arguments;
    var str = ar[0] + "?formAction=" + ar[1];
    var ret = false;
    
    // force conversion of element names to key1 ... keyn after unmasking
    str = str + "&namesToKeys=true";
    
    if (DirtyFormcheck(true))
    {
        statusMsg=getMessage('keyrecsresetwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

        ret = confirm(msg);
    }
    else   
    {
        enableDropdown();
        for(i=2;i<ar.length;i++)
        {
	    	// we need to check if the argument passed is a string or an element
	    	if(!ar[i].name)
	    	{    		
	    		// we have a string
	    		str = str + ("&key" + (i-1)) + "=" + encodeURIComponent(ar[i]);
	    	}
	    	else
	    	{
	    		// We have an element
	    		str = str + "&" + ar[i].name + "=" + encodeURIComponent(ar[i].value);
	    	}
        }
        
        if(document.forms[0].formAcsitem)
	    {
	    	// add on the acsitem passed 
	    	str = str + "&formAcsitem=" + document.forms[0].formAcsitem.value;
	    }
        redirectWithPostMethodUrl(str);
    }
    if (ret)
    {
        enableDropdown();
        for(i=2;i<ar.length;i++)
        {
	    	// we need to check if the argument passed is a string or an element
	    	if(!ar[i].name)
	    	{    		
	    		// we have a string
	    		str = str + ("&key" + (i-1)) + "=" + encodeURIComponent(ar[i]);
	    	}
	    	else
	    	{
	    		// We have an element
	    		str = str + "&" + ar[i].name + "=" + encodeURIComponent(ar[i].value);
	    	}
        }
        
		if(document.forms[0].formAcsitem)
	    {
	    	// add on the acsitem passed 
	    	str = str + "&formAcsitem=" + document.forms[0].formAcsitem.value;
	    }
		redirectWithPostMethodUrl(str);
        
    }
    else
    {
        return false;
    }

}

    /*-------------------------------------------------------------
     *
     * Function     :  voiceRefresh
     *
     * Purpose      :  Get the description for currcode
     *
     * Parameters   :  none
     *
     * Returns      :
     *
     * Comments     :
     *
     *-----------------------------------------------------------*/
    function voiceRefresh(arg1,parentTextBox1)
    {
        var varmrchno = document.forms[0].elements[arg1].value;
        var mObjval = eval("document.forms[0]."+ arg1)
        var  val = defVal[mObjval.name];

        if(varmrchno == '' || varmrchno == val)
        {
            document.forms[0].elements[parentTextBox1].focus();
            return false;
        }
        else
        {
            enableDropdown();
            document.vmvoiceauthorisationfrm.formAction.value="refresh";
            document.vmvoiceauthorisationfrm.submit();
        }
    }

    /*-------------------------------------------------------------
     *
     * Function     :  Confirmation On Adding new record after checking the mandatory field
     *
     * Purpose      :  Confirmation Message is displayed on the screen
     *         when user clicks on update.
     *
     * Parameters   :
     *
     * Returns      :
     *
     * Comments     : Added for AT-TR180
     *
     *-----------------------------------------------------------*/
    function addACMK(formname,operation,keyval)
    {
        var ret = false;
        var acmkKeyName = document.forms[0].ACMKUnderKey;
        var keyValue = acmkKeyName.value;
        var keyLength = acmkKeyName.value.length;
        var useExtTR31KeyBlocks = document.forms[0].useExtTR31KeyBlocks.value;
        if("true" == useExtTR31KeyBlocks ? (keyLength == 0 || keyLength == 73 || keyLength == 81) : (keyLength == 0 || keyLength == 32)) {
        //if(keyLength == 0 || keyLength == 32) {
        	if (checkForm(document.forms[0]))
            {
                if(document.forms[0].ACMKUnderKey.value.length == 0)
                {
                    statusMsg=getMessage('keyrecsgenwishcont');
                }
                else
                {
                    statusMsg=getMessage('keyrecsaddwishcont');
                }
                actionMsg=getMessage('keydoyouwancontinue');
                msg = "___________________________________________________" +
                "\n\n" + statusMsg + "\n" +
                "___________________________________________________" +
                "\n\n" + actionMsg;
                ret = confirm(msg);
            }
            if(ret)
            {
                enableDropdown();
                document.forms[formname].formAction.value = operation;
                document.forms[formname].submit();
            }
        } else {
        	statusMsg=getMessage('keyplstryagain1')+"\n" + getMessage('keyplstryagain2');
        	actionMsg1= ("true" == useExtTR31KeyBlocks) ? "The Field \"" + keyval + "\" should be of length 73 or 81" : "The Field \"" + keyval + "\" should be of length 32" ;
            actionMsg2=" - your entry of \"" + keyValue + "\" is not allowed";
            msg = "___________________________________________________" +
                "\n\n" + statusMsg + "\n" +
                "___________________________________________________" +
                "\n\n" + actionMsg1 + actionMsg2;
            alert(msg);
            acmkKeyName.focus();
            return false;
        }
     }
    
     /*-------------------------------------------------------------
      *
      * Function     : callAuthcodeScreen
      *
      * Purpose      : for the call of Authcode screen from its parent
      *
      * Parameters   : pan,seqno,instcode,panDisplay
      *
      * Returns      :
      *
      * Comments     : for handling different call of Authcode screen
      *
      *-----------------------------------------------------------*/

      function callAuthcodeScreen(psNo)
      {
          var var1= document.forms[0].pan.value;
          var var2= document.forms[0].seqno.value;
          var var3= document.forms[0].instcode.value;
          var var4= document.forms[0].panDisplay.value;
          var var5=psNo;
          
          var str = "iaauthcodesearchon.do?formAction=search&namesToKeys=true&formAcsitem=" + document.forms[0].formAcsitem.value;
          
          str = str + "&pan="+var1+"&instcode="+var3+"&seqno="+var2+"&panDisplay="+var4;
          
          if(var5 !='1')
          {
             var5=document.forms[0].accno.value;
             // if using accno this may be masked and we would want to unmask before passing
             // to action class, hence we need to see the real name in the request
             str = str + "&accno="+var5;
          }
          else
          {
          	 str = str + "&key5="+var5;
          }
          redirectWithPostMethodUrl(str);
     }

     /*-------------------------------------------------------------
      *
      * Function     : callAuthcodeScreen
      *
      * Purpose      : for the call of Authcode screen from its parent
      *
      * Parameters   : pan,seqno,instcode
      *
      * Returns      :
      *
      * Comments     : for handling different call of Authcode screen
      *
      *-----------------------------------------------------------*/

      function callWbkAuthcodeScreen(path, psNo)
      {
          var var1= document.forms[0].pan.value;
          var var2= document.forms[0].seqno.value;
          var var3= document.forms[0].instcode.value;
          var var4=psNo;

		  var str = path + "iawbkauthcodesearchon.do?formAction=search&namesToKeys=true&formAcsitem=" + document.forms[0].formAcsitem.value;
		  
		  str = str + "&pan="+var1+"&instcode="+var3+"&seqno="+var2;
          if(var4 !='1')
          {
             var4=document.forms[0].accno.value;
             // if using accno this may be masked and we would want to unmask before passing
             // to action class, hence we need to see the real name in the request
             str = str + "&accno="+var4;
          }
          else
          {
          	 str = str + "&key4="+var4;
          }
          redirectWithPostMethodUrl(str);
     }

     /*-------------------------------------------------------------
       *
       * Function     : backToParentOfAuthcodeScreen
       *
       * Purpose      : for going back to the screen from where Authcode called
       *
       * Parameters   : pan,instcode,seqno and which parent has called
       *
       * Returns      :
       *
       * Comments     : Added for the back button
       *
       *-----------------------------------------------------------*/
       function backToParentOfAuthcodeScreen(path)
       {
           var var1= document.forms[0].pan.value;
           var var2= document.forms[0].fromWhere.value;
           var var3= document.forms[0].instcode.value;
           var var4= document.forms[0].seqno.value;

           if(var2!='1')
           {
        	    redirectWithPostMethod(path + "iacardactivitydetailon.do", "formAction=edit&key1="+var3+"&key2="+var1+"&key3="+var2);
           }
           else
           {
        	   redirectWithPostMethod(path + "iaauthfunctionsdetailon.do" ,"formAction=edit&key1="+var1+"&key2="+var4);
           }
      }

   /*-------------------------------------------------------------
    *
    * Function     :  LinktoCardAccount
    *
    * Purpose      :
    *
    * Parameters   : custcode,instcode,Fromwhere
    *
    * Returns      :
    *
    * Comments     : called from card account screen
    *
    *-----------------------------------------------------------*/

    function LinktoCardAccount(custcode,instcode,Fromwhere)
    {
    	redirectWithPostMethod("iacardaccounton.do", "customerCode="+custcode+"&userinst="+instcode+"&fromwhere="+Fromwhere);
    }

/*-------------------------------------------------------------
 *
 * Function     :  SearchSelect
 *
 * Purpose      :  Used for the Edit window.
 *
 * Parameters   :  var Variable that holds the info of the selected row.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function SelectCrdapp()
{
    var ar = SelectCrdapp.arguments;
    var str;
    var token_key = document.getElementsByName("TOKEN_KEY")[0].value;
    if(token_key !=''){
   	 str = ar[0] + "?formAction=initial&fromPopup=1&TOKEN_KEY="+token_key;
    }else{
   	 str = ar[0] + "?formAction=initial&fromPopup=1";
    }

    for(i=1;i<ar.length;i++)
    {
        str = str + ("&key" + i) + "=" + encodeURIComponent(ar[i]);
    }
    redirectWithPostMethodUrl(str);
}

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Adding new record after checking the mandatory field
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *         when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function addCardappl(formname,operation)
 {
        var ret = false;
        if (checkForm(document.forms[0]))
        {

            statusMsg=getMessage('keyrecsaddwishcont');
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n" +
            "___________________________________________________" +
            "\n\n" + actionMsg;

            ret = confirm(msg);
        }
        if(ret)
        {
            if(document.forms[formname].acctype.readOnly == true)
            {
                document.forms[formname].acctypeenable.value = false;
            }
            if(document.forms[formname].masterPan.readOnly == true)
            {
                document.forms[formname].masterpanenable.value = false;
            }
            if(document.forms[formname].strAcclimit.readOnly == true)
            {
                document.forms[formname].acclimitenable.value = false;
            }
            if(document.forms[formname].cycleId.readOnly == true)
            {
                document.forms[formname].cyclecodeenable.value = false;
            }
            enableDropdown();
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
 }

function addContinueCardappl(formname,operation)
{
    var ret = false;
    if (checkForm(document.forms[0]))
    {
        statusMsg=getMessage('keyrecsaddwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;

        ret = confirm(msg);
    }
    if(ret)
    {
        if(document.forms[formname].acctype.readOnly == true)
        {
            document.forms[formname].acctypeenable.value = false;
        }
        if(document.forms[formname].masterPan.readOnly == true)
        {
            document.forms[formname].masterpanenable.value = false;
        }
        if(document.forms[formname].strAcclimit.readOnly == true)
        {
            document.forms[formname].acclimitenable.value = false;
        }
        if(document.forms[formname].cycleId.readOnly == true)
        {
            document.forms[formname].cyclecodeenable.value = false;
        }
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
 }

/*-------------------------------------------------------------
 *
 * Function     :  ZoomAccountType
 *
 * Purpose      :  Used to popup the Zoom  Search window
 *
 * Parameters   :  textboxname Variable which holds the textbox name.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function updateCardAppl(formname, operation)
{
    var ret = false;
    if (checkForm(document.forms[0]) && DirtyFormcheck(true))
    {
        statusMsg=getMessage('keyrecsupdwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

        ret = confirm(msg);

    }
    if(ret)
    {
        if(document.forms[formname].acctype.readOnly == true)
        {
            document.forms[formname].acctypeenable.value = false;
        }
        if(document.forms[formname].masterPan.readOnly == true)
        {
            document.forms[formname].masterpanenable.value = false;
        }
        if(document.forms[formname].strAcclimit.readOnly == true)
        {
            document.forms[formname].acclimitenable.value = false;
        }
        if(document.forms[formname].cycleId.readOnly == true)
        {
            document.forms[formname].cyclecodeenable.value = false;
        }
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  ZoomAccountType
 *
 * Purpose      :  Used to popup the Zoom  Search window
 *
 * Parameters   :  textboxname Variable which holds the textbox name.
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function updateContinueCardAppl(formname,operation)
{
    var ret = false;
    if (checkForm(document.forms[0]))
    {
        statusMsg=getMessage('keyrecsupdwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

        ret = confirm(msg);
    }
    if(ret)
    {
        if(document.forms[formname].acctype.readOnly == true)
        {
            document.forms[formname].acctypeenable.value = false;
        }
        if(document.forms[formname].masterPan.readOnly == true)
        {
            document.forms[formname].masterpanenable.value = false;
        }
        if(document.forms[formname].strAcclimit.readOnly == true)
        {
            document.forms[formname].acclimitenable.value = false;
        }
        if(document.forms[formname].cycleId.readOnly == true)
        {
            document.forms[formname].cyclecodeenable.value = false;
        }
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  To Go Back To Previous Screen
 *
 * Purpose      :  On Clicking on 'BACK' button user taken back to previous page
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function isbackCardappl(actionfile,formname)
{
    var str = actionfile + "?formAction=initial";

    // force conversion of element names to key1 ... keyn after unmasking
    str = str + "&namesToKeys=true";

    str = str + "&crdProduct=" + document.forms[formname].crdProduct.value;
    str = str + "&batchno=" + document.forms[formname].batchno.value;
    str = str + "&instCode=" + document.forms[formname].instCode.value;
    
    str = str + "&formAcsitem=" + document.forms[formname].formAcsitem.value;
    
    var ret = false;
    if (DirtyFormcheck(true))
    {
        statusMsg=getMessage('keyrecsresetwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

        ret = confirm(msg);
    }
    else
    {
    	redirectWithPostMethodUrl(str);
    }

    if(ret)
    {
    	redirectWithPostMethodUrl(str);
    }
    else
    {
        return false;
    }
}

/*-------------------------------------------------------------
*
* Function     :    searchWithTab
*
* Purpose      :    for tab search without any mandatory field
*
* Parameters   :
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/

function searchWithTab()
{
    enableDropdown();
    document.forms[0].tabCheck.value = 'tab';
    document.forms[0].formAction.value = 'search';
    document.forms[0].submit();
}

 /*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Update of RV Automatic Reversal
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on update.
  *                 This enables the Dropdown before updating records as
  *                 values from the Disabled dropdowns cannot be submitted
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function rvupdaterec(formname,operation)
  {
    var ret = false;

    if(currencyGraterZero(document.forms[0].amttxn))
    {
        if (checkForm(document.forms[0]) && DirtyFormcheck(true))
        {
             statusMsg=getMessage('keyrecsupdwishcont');
             actionMsg=getMessage('keydoyouwancontinue');
             msg = "___________________________________________________" +
                 "\n\n" + statusMsg + "\n" +
                 "___________________________________________________" +
                 "\n\n" + actionMsg;

             ret = confirm(msg);
        }
        if(ret)
        {
            enableDropdown();
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
    }
    else
    {
        document.forms[0].amttxn.focus();
        return false;
    }

  }
    /*-------------------------------------------------------------------------------------
    *
    * Function     :  addEpChrgBkFeeColAutoTrans
    *
    * Purpose      :  Confirmation On Adding a record for Ep Charge back fee
    *                 collection for Automatic Transaction after checking the mandatory field
    *                 And Also custom validation for the same.
    *
    * Parameters   : formname - name of the form, operation - Add
    *
    * Returns      :
    *
    * Comments     :
    *
    *-------------------------------------------------------------------------------------*/
    function addEpChrgBkFeeColAutoTrans(formname,operation)
    {
        var bValid = true;
        var objFocusField = null;

        var billingAmtField = document.forms[formname].strAmtbill;
        var AmtField        = document.forms[formname].strAmttxn;
        var txtMsgField     = document.forms[formname].txtmsg;

        var statusMsg = "";
        var actionMsg = "";

        // First call checkForm to force mandatory field validations.
        if (!checkForm(document.forms[0]))
        {
            return false;
        }

        if (parseFloat(billingAmtField.value,10) > parseFloat(AmtField.value,10))
        {
            actionMsg = getMessage('keyepinvalidamt');
            statusMsg = getMessage('keyplstryagain1') + "\n" + getMessage('keyplstryagain2');
            msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n"+
            "___________________________________________________" +
            "\n\n" + actionMsg + "\n";

            alert(msg)
            focusEl(billingAmtField);
            billingAmtField.value = AmtField.value;
            return false;
        }

        if (Trim(txtMsgField.value) == '')
        {

            actionMsg = getMessage('keyerrordbu_ss_rfld204');
            statusMsg = getMessage('keyplstryagain1') + "\n" + getMessage('keyplstryagain2');
            msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n"+
            "___________________________________________________" +
            "\n\n" + actionMsg + "\n";

            alert(msg)
            focusEl(txtMsgField);
            return false;
        }

        //Validations over....
        statusMsg= getMessage('keyep_chbk_fee_coll');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;

         ret = confirm(msg);

        if(ret)
        {
            enableDropdown();
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
    }


 /*-------------------------------------------------------------------------------------
    *
    * Function     :  confirm_entry
    *
    * Purpose      :  Confirmation On Pressing an Execute button by the user
    *
    *
    *
    * Parameters   : formname - name of the form, operation - Execute
    *
    * Returns      :
    *
    * Comments     :
    *
    *-------------------------------------------------------------------------------------*/

    function confirm_entry(formname,operation)
    {
        var ret = true;
        if (checkForm(document.forms[0]))
        {
            statusMsg=getMessage('keyrecsaddwishcont');
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
                "\n\n" + statusMsg + "\n" +
                "________________________________________________________" +
                "\n\n" + actionMsg;
            ret = confirm(msg);
        }
       if(ret)
       {
                enableDropdown();
                document.forms[formname].formAction.value = operation;
                document.forms[formname].submit();
       }
    }

    /*-------------------------------------------------------------
     *
     * Function     :  manipulate_scheme
     *
     * Purpose      :  Manipulate (enable/disable) the scheme field based
     *                 pan field
     *
     * Parameters   :  none
     *
     * Returns      :
     *
     * Comments     :
     *
     *-----------------------------------------------------------*/
    function manipulate_scheme()
    {
        document.forms[0].pan.value = Trim(document.forms[0].pan.value);
        if(document.forms[0].pan.value == "")
        {
            document.forms[0].scheme.readonly = false;
            document.forms[0].scheme.disabled = false;
            document.forms[0].scheme.mandatory = true;
            document.forms[0].schemeEnabled.value = true;
        }
        else
        {
            var tiPan = parseInt(document.forms[0].pan.value);
            if(tiPan==0)
            {
                actionMsg=getMessage('keypannotzero');
                msg = "___________________________________________________" + "\n\n" + actionMsg + "\n" ;
                alert(msg);
            }
            else
            {
                document.forms[0].scheme.readonly = true;
                document.forms[0].scheme.disabled = true;
                document.forms[0].scheme.mandatory = false;
                document.forms[0].schemeEnabled.value = false;
            }
        }
    }

    /*-------------------------------------------------------------
    *
    * Function     :  SearchSelectDelete
    *
    * Purpose      :  This method is Used for EP Intermediate Search Screen delete operation.
    *
    *
    * Parameters   :  var Variable that holds the info of the selected row.
    *
    * Returns      :
    *
    * Comments     :
    *
    *-----------------------------------------------------------*/
    function SearchSelectDelete()
    {
        statusMsg=getMessage('keyrecsdelwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;

        if(!confirm(msg))
        {
            return false;
        }
        var ar = SearchSelectDelete.arguments;
        var str = ar[0] + "?formAction=delete&screenid=" + ar[1];
        for(var i=2;i<ar.length;i++)
        {
          str = str + ("&key" + (i-1)) + "=" + encodeURIComponent(ar[i]);
        }
        redirectWithPostMethodUrl(str);
    }

    /*-------------------------------------------------------------
     *
     * Function     :  validateAndAddForAutomaticChargeBack
     *
     * Purpose      :  validation before adding
     *
     * Parameters   :  any mandatory field, field to be focussed
     *
     * Returns      :
     *
     * Comments     :
     *
     *-----------------------------------------------------------*/
    function validateAndAddForAutomaticChargeBack()
    {
        var varReason = document.forms[0].reason.value;
        //not needed NMR012697
        //var varTxtmsg = document.forms[0].messageText.value;

        var varAmtchgbk = parseFloat(document.forms[0].strAmtchgbk.value);
        var varAmttxn = parseFloat(document.forms[0].strAmtTxn.value);
        if(varReason=="0")
        {
            actionMsg=getMessage('keydbU_SS_RFLD204');
            msg = actionMsg ;
            alert(msg);
            return false;
        }
        else if(varAmtchgbk > varAmttxn )
        {
            actionMsg=getMessage('keyEPINVALIDAMT');
            msg = actionMsg ;
            alert(msg);
            return false;
        }
        else if(varReason==4549)
        {
            actionMsg=getMessage('keyReasonInvalid');
            msg = actionMsg ;
            alert(msg);
            return false;
        }
        else
        {
            actionMsg=getMessage('keyChargeback');
            msg = actionMsg ;
            ret = confirm(msg);
            if(ret)
            {
                updaterec('epautomaticchargebackdetfrm','update');
            }
            return false;
        }

    }
    /*-------------------------------------------------------------
     *
     * Function     :  validateAndAddForChargeBackReversal
     *
     * Purpose      :  validation before adding
     *
     * Parameters   :  any mandatory field, field to be focussed
     *
     * Returns      :
     *
     * Comments     :
     *
     *-----------------------------------------------------------*/
    function validateAndAddForChargeBackReversal()
    {
        var varAmtchgbk = parseFloat(document.forms[0].stramtchgbk.value);
        var varAmttxn = parseFloat(document.forms[0].strAmtTxn.value);
        if(varAmtchgbk > varAmttxn )
        {
            actionMsg=getMessage('keyEPINVALIDAMT');
            msg = actionMsg ;
            alert(msg);
            return false;
        }
        else
        {
            actionMsg=getMessage('keyChargeback');
            msg = actionMsg ;
            ret = confirm(msg);
            if(ret)
            {
                updaterec('epchargebackreversaldetailfrm','update');
            }
            return false;
        }

    }
  /*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Update
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on update. This function checks
                    whether the amount is greater than 0
  *                 This enables the Dropdown before updating records as
  *                 values from the Disabled dropdowns cannot be submitted
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

function rvupdateAmountGt0(formname,operation,arg1,arg2)
{

    if(currencyGraterZero(document.forms[0].amttxn) && currencyGraterZero(document.forms[0].amttxnorg))
    {
        var ret = false;
        //Added for AT-0152
        if(!DirtyFormcheck(true))
        {
        statusMsg=getMessage('keydirtyreadnot');
        alert(statusMsg);
        }

        if (checkForm(document.forms[formname]) && DirtyFormcheck(true))
        {
            statusMsg=getMessage('keyrecsupdwishcont');
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
             "\n\n" + statusMsg + "\n" +
             "___________________________________________________" +
             "\n\n" + actionMsg;

            ret = confirm(msg);

        }
        if(ret)
        {
            enableDropdown();
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
    }
    else
    {
        if(!currencyGraterZero(document.forms[0].amttxn))
        {
            document.forms[0].amttxn.focus();
        }
        else if(!currencyGraterZero(document.forms[0].amttxnorg))
        {
            document.forms[0].amttxnorg.focus();
        }

        return false;

    }

}

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Adding new record after checking the mandatory field and
                    checking amount Greater than 0.
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *         when user clicks on update.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function rvnewrecAmountGt0(formname,operation,amountfield)
{
    if(currencyGraterZero(document.forms[0].amttxn) && currencyGraterZero(document.forms[0].amttxnorg))
    {
        var ret = false;
        if (checkForm(document.forms[0]))
        {
            statusMsg=getMessage('keyrecsaddwishcont');
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n" +
            "___________________________________________________" +
            "\n\n" + actionMsg;
            ret = confirm(msg);
        }
        if(ret)
        {
            enableDropdown();
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
    }
    else
    {
        if(!currencyGraterZero(document.forms[0].amttxn))
        {
            document.forms[0].amttxn.focus();
        }
        else if(!currencyGraterZero(document.forms[0].amttxnorg))
        {
            document.forms[0].amttxnorg.focus();
        }

        return false;
    }

}
/*-------------------------------------------------------------
 *
 * Function     :  validateMasterCardFeeCollection

 *
 * Purpose      :  Confirmation On Adding new record after checking the mandatory field.
 *                 Confirmation Message is displayed on the screen
 *                 when user clicks on add.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function validateMasterCardFeeCollection(formname,operation)
{

    var ret = true;
    if (parseInt(Trim(document.forms[0].amttxn.value)) == 0)
    {
        statusMsg = getMessage('keyplstryagain1') + "\n" + getMessage('keyplstryagain2');
        actionMsg=getMessage('keyamountgt0');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;
        alert(msg);
    }
    else
    {
        newrec(formname,operation);
    }
}


  /*-------------------------------------------------------------
     *
     * Function     :  ImportECCSS
     *
     * Purpose      :  This method is Used to check the Detail
     *                 which has been chaged.
     *
     * Parameters   :  none
     *
     * Returns      :  none
     *
     * Comments     :  Added for Iteration 4
     *-----------------------------------------------------------*/

    function checkdetail()
    {
        detailcheck=getMessage('keydetailcheck');
        if(document.epimporteccssdetailactionfrm.detail.value != '1' && document.epimporteccssdetailactionfrm.detail.value != '0')
        {
            msg = "___________________________________________________" +
                     "\n\n" + detailcheck + "\n" +
                  "___________________________________________________";
            alert(msg);
            document.epimporteccssdetailactionfrm.detail.value="";
            document.epimporteccssdetailactionfrm.detail.focus();
        }
    }

    /*-------------------------------------------------------------------------------------
    *
    * Function     :  addEpFeecoll
    *
    * Purpose      :  Confirmation On Adding a record for Ep Charge back fee
    *                 collection for Automatic Transaction after checking the mandatory field
    *                 And Also custom validation for the same.
    *
    * Parameters   : formname - name of the form, operation - Add
    *
    * Returns      :
    *
    * Comments     :
    *
    *-------------------------------------------------------------------------------------*/
    function addEpFeecoll(formname,operation,arg1,arg2)
    {
        var bValid = true;
        var objFocusField = null;

        var billingAmtField = document.forms[0].elements[arg1].value;
        var AmtField        = document.forms[0].elements[arg2].value;

        var statusMsg = "";
        var actionMsg = "";
        if (parseFloat(billingAmtField,10) >= parseFloat(AmtField,10))
        {
            actionMsg = getMessage('keyepinvalidamt');
            statusMsg = getMessage('keyplstryagain1') + "\n" + getMessage('keyplstryagain2');
            msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n"+
            "___________________________________________________" +
            "\n\n" + actionMsg + "\n";

            alert(msg)
            return false;
        }
        // First call checkForm to force mandatory field validations.
        if (!checkForm(document.forms[0]))
        {
            return false;
        }
        newrec(formname,operation);

    }

/*-------------------------------------------------------------
  *
  * Function     :  isbackfordowithourdirty
  *
  * Purpose      :  When a search screen is called through .do that is
  *                 when we have a functionality to be performed before
  *                 the search screen is displayed  we cannot get the
  *                 search criteria from the null block again. This function
  *                 is used to go to another block on the search action class
  *                 other than the null block
  *
  * Parameters   :  parentformname and operator
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function isbackfordowithourdirty(parentformname,operation)
  {
        var ret = false;
        redirectWithPostMethod(parentformname, "formAction="+operation);

  }
/*-------------------------------------------------------------
     *
     * Function     :  voiceRefresh
     *
     * Purpose      :  Get the description for currcode
     *
     * Parameters   :  none
     *
     * Returns      :
     *
     * Comments     :
     *
     *-----------------------------------------------------------*/
    function stateRePopulate(arg1,parentTextBox1)
    {
        var varmrchno = document.forms[0].elements[arg1].value;
        var mObjval = eval("document.forms[0]."+ arg1)
        var  val = defVal[mObjval.name];

        if(varmrchno == '' || varmrchno == val)
        {

            document.forms[0].elements[parentTextBox1].focus();
            return false;

        }
        else
        {
            enableDropdown();
            document.forms[0].formAction.value="repopulate";
            document.forms[0].submit();
        }


    }



//This function is added to fix AT-0946 - Start

/*--------------------------------------------------------------------
*
* Function     :  Custom Navigation with custom message.
*
* Purpose      :  When user clicks on appropriate button.
*                 This enables the Dropdown before submiting records as
*                 values from the Disabled dropdowns cannot be submitted
*
* Parameters   :actionfile,formname,operation
*
* Comments     : This function is added to fix AT-0941 - Start
*
*----------------------------------------------------------------------*/


function customreversalnavigate(actionfile,formname,operation)
{
    enableDropdown();
    document.forms[formname].action = actionfile + "?formAction=" + operation;
    document.forms[formname].submit();
}




/*-------------------------------------------------------------
*
* Function     : backToParentOfCardActivityScreen
*
* Purpose      : for going back to the screen from where Delete
*                Card Activity called
*
* Parameters   : pan and seqno and which parent has called
*
* Returns      :
*
* Comments     : Added for the back button
*
*-----------------------------------------------------------*/

function backToParentOfCardActivityScreen()
{
   enableDropdown();
   var var1= document.forms[0].pan.value;
   var var2= document.forms[0].seqno.value;
   redirectWithPostMethod("iaauthfunctionsdetailon.do", "formAction=back");
}

/*-------------------------------------------------------------
 *
 * Function     :  addnewCardForInputBacth
 *
 * Purpose      :  Used for the Batch Select Batch for New PIN Screen
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added to Fix TR-857  Rajkumar
 *
 *-----------------------------------------------------------*/

function addnewCardForBacth(formdo)
{
    enableDropdown();
    var ar = addnewCardForBacth.arguments;
    var str = ar[0] + "?formAction=null";

    var InstCode = document.forms[0].institution.value;
    var BatchType = document.forms[0].batchtype.value;
    var Batch = document.forms[0].batch.value;
    var CardProduct = document.forms[0].CardProduct.value;
    var parent ="add"

    str = str + ("&InstCode") + "=" + InstCode + ("&BatchType") + "=" + BatchType + ("&Batch") + "=" + Batch + ("&CardProduct") + "=" + CardProduct + ("&parent") + "=" + parent +"&fromPopup=1";
    redirectWithPostMethodUrl(str);

}


/*-------------------------------------------------------------
 *
 * Function     :  addnewCardForInputBacth
 *
 * Purpose      :  Used for the Batch Select Batch for New PIN Screen
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added to Fix TR-857  Rajkumar
 *
 *-----------------------------------------------------------*/

function addnewCardForInputBacth(formdo)
{

    enableDropdown();
    var sFromWhere = "|update";

    var IdVal = document.forms[0].IdVal.value;
    IdVal=IdVal+sFromWhere;

    var ar = addnewCardForInputBacth.arguments;
    var str = ar[0] + "?formAction=null";
    var parent ="add"

    str = str + ("&parentTextBoxName") +"="+IdVal + ("&parent") + "=" + parent+"&fromPopup=1"; 
    redirectWithPostMethodUrl(str);


}

/*-------------------------------------------------------------
 *
 * Function     :  addnewCardForReplaceBacth
 *
 * Purpose      :  Used for the Batch CardForReplaceBacth Screen
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added to Fix TR-857  Rajkumar
 *
 *-----------------------------------------------------------*/

function addnewCardForReplaceBacth(formdo)
{
    enableDropdown();
    var sFromWhere = "|add";

    var IdVal = document.forms[0].IdVal.value;
    IdVal=IdVal+sFromWhere;

    var ar = addnewCardForReplaceBacth.arguments;
    var str = ar[0] + "?formAction=null";
    var parent ="add"

    str = str + ("&parentTextBoxName") +"="+IdVal + ("&parent") + "=" + parent;
    redirectWithPostMethodUrl(str);


}


/*-------------------------------------------------------------
 *
 * Function     :  isbackForReplace
 *
 * Purpose      :  Used for the Batch for Input Screen
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added to Fix TR-857  Rajkumar
 *
 *-----------------------------------------------------------*/

function isbackForReplace()
{

    var ar = isbackForReplace.arguments;
    var ret = false;
    var parent = document.forms[0].parent.value;

    redirectWithPostMethod(ar[0], "formAction=search" + ("&parent") + "=" + parent);
}


/*-------------------------------------------------------------
 *
 * Function     :  UserGroupSearchSelect
 *
 * Purpose      :  Used for the Edit menu screen.
 *
 * Parameters   :  var Variable that holds the info of the selected row.
 *
 * Returns      :
 *
 * Comments     : Added to Fix TR-1093 Vinay
 *        Modified to fix Back functionality on 19/12/2002 :Vinay
 *
 *-----------------------------------------------------------*/
function UserGroupSearchSelect()
{

    if (checkForm(document.forms[0]))
    {
        statusMsg=getMessage('keyrecsupdwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
              "\n\n" + statusMsg + "\n" +
              "___________________________________________________" +
              "\n\n" + actionMsg;


        var ar = UserGroupSearchSelect.arguments;
        var str = ar[0] + "?formAction=null";

        for(i=1;i<ar.length;i++)
        {
            str = str + ("&usrgrp") + "=" + encodeURIComponent(ar[i]);
        }
        var descr = encodeURIComponent(document.forms[0].descr.value);
        var  str1 = "&key2=usrgrp&key3="+descr;
        var str = str+""+str1;
        redirectWithPostMethodUrl(str);
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  refreshSelect
 *
 * Purpose      :
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : Added to Fix TR-1386 Poornima
 *
 *-----------------------------------------------------------*/
function refreshSelect()
{
    document.forms[0].formAction.value='repopulate';
    document.forms[0].submit();
}

/*-------------------------------------------------------------
 *
 * Function     :  isbackforep
 *
 * Purpose      :  This method is added for back in the EP Module
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/



function isbackforep()
{

    var ar = isbackforep.arguments;
    var formAction ="search"


    var ret = false;
    if (DirtyFormcheck(true))
    {
        statusMsg=getMessage('keyrecsresetwishcont');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

        ret = confirm(msg);
    }
    else
    {
    	redirectWithPostMethod(ar[0], "formAction="+formAction+"&screenid="+ar[1]);
    }

    if(ret)
    {
    	redirectWithPostMethod(ar[0], "formAction="+formAction+"&screenid="+ar[1]);
    }
    else
    {
        return false;
    }
}


/*-------------------------------------------------------------
*
* Function     :  Confirmation On Adding new record after checking the check box
*
* Purpose      :  Confirmation Message is displayed on the screen
*         when user clicks on add
*
* Parameters   :
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/

function updatelinkaccount(formname,formdo)
{
var ret = false;

    if (modify_onClickLinkAccount())
    {
        var IdVal =checkalllinkaccount();
        var token_key = document.getElementsByName("TOKEN_KEY")[0].value;
        var params = "Iid="+IdVal+"&formAction=linkaccount&fromwhere=1";
        if(token_key !='') {
            redirectWithPostMethod(formdo, params +"&TOKEN_KEY="+token_key);
        } else {
            redirectWithPostMethod(formdo, params);
        }
    }
}

 /*-------------------------------------------------------------
    *
    * Function     :  searchTabMerchant() used for Merchant search screen.
    *
    * Purpose      :
    *
    * Parameters   :
    *
    * Returns      :
    *
    * Comments     : This javascript function is required due to 
    *                the framework not yet supporting mandatory field
    *                checks when there are several search criteria
    *                (ie several tabs in search screen)
    *
    *-----------------------------------------------------------*/
    function searchTabMerchant()
    {
        if(document.forms[0].tabid.value == 0)
        {
            if(Trim(document.forms[0].instcode.value)=='')
            {
                err= document.forms[0].instcodeLabel.value + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].instcode);
                return false;
             }
        }
        if(document.forms[0].tabid.value == 1)
        {
            if(Trim(document.forms[0].instcode2.value)=='')
            {
                err=document.forms[0].instcodeLabel.value + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].instcode);
                return false;
             }
        }
        enableDropdown();
        document.forms[0].tabCheck.value = 'tab';
        document.forms[0].formAction.value = 'search';
        document.forms[0].submit();
  }
    
    /*-------------------------------------------------------------
    *
    * Function     :  searchTabBranch() used for Branch search screen.
    *
    * Purpose      :
    *
    * Parameters   :
    *
    * Returns      :
    *
    * Comments     : This javascript function is required due to 
    *                the framework not yet supporting mandatory field
    *                checks when there are several search criteria
    *                (ie several tabs in search screen)
    *
    *-----------------------------------------------------------*/
    function searchTabBranch()
    {
        if(document.forms[0].tabid.value == 0)
        {
            if(Trim(document.forms[0].instcode.value)=='')
            {
                err= document.forms[0].instcodeLabel.value + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].instcode);
                return false;
             }
        }
        if(document.forms[0].tabid.value == 1)
        {
            if(Trim(document.forms[0].institutioncode.value)=='')
            {
                err=document.forms[0].instcodeLabel.value + getMessage('keyismandatory');
                alertErr(err);
                focusEl(document.forms[0].institutioncode);
                return false;
             }
        }
        enableDropdown();
        document.forms[0].tabCheck.value = 'tab';
        document.forms[0].formAction.value = 'search';
        document.forms[0].submit();
  }

/*-------------------------------------------------------------
 *
 * Function     :  function Called  from  addnewrec,updatenewrec and delbatchrec methods
 *
 * Purpose      :  gets the id for the selected check box
 *
 *
 * Parameters   :
 *
 * Returns      :   int
 *
 * Comments     :   used for batch
 *
 *-----------------------------------------------------------*/

    function checkalllinkaccount(frm)
    {	 
     var len= document.forms[0].radio.length;	 
     var j=0;
     var checkValue="";
     var Id ="";
     var tot = "";	 
     if(len)
	 {
         for(var i=0;i<len;i++)
         {
			  if(document.forms[0].radio[i].name == 'radio')
			  {
				  if(document.forms[0].radio[i].checked == true)
				  {
				     Id=document.forms[0].radio[i].value;
				     if(document.forms[0].isLinked[i].value=='Y'
					       &&(document.forms[0].oldPriority[i].value != document.forms[0].priority[i].value))
					   Id = Id+'| U';
                     else
                       Id =Id+'|';
					   
					 Id = Id +document.forms[0].priority[i].value+ "~";
					 tot = tot+Id;
				  }else if(document.forms[0].oldPriority[i].value != document.forms[0].priority[i].value)
				  {
					 Id = document.forms[0].radio[i].value+'|U'+document.forms[0].priority[i].value;
					 Id = Id + "~";  
					 tot = tot+Id;
				  }
			 }
		}
	}else{
	
	   if(document.forms[0].radio.checked == true)
       {
	       Id=document.forms[0].radio.value;
	       if(document.forms[0].isLinked.value=='Y'
			 &&(document.forms[0].oldPriority.value != document.forms[0].priority.value))
		      Id = Id+'| U';
           else
              Id =Id+'|';
           Id = Id +document.forms[0].priority.value+ "~";
		   tot = tot+Id;
	   
	   }
	   else if(document.forms[0].oldPriority.value != document.forms[0].priority.value)
	   {
          Id = document.forms[0].radio.value+'|U'+document.forms[0].priority.value;
	      Id = Id + "~";  
	      tot = tot+Id;
       }
	 }
     return tot;
    }

 /*-------------------------------------------------------------
   *
   * Function     :  numToCurrency() used for Currency Formatting.
   *
   * Purpose      :  This method Converts the number to the Loacle currency format
   *
   * Parameters   : vDecimalSep,vGroupSep,vCurrSym,vNumDeci,vNumber,vFldName
   *
   * Returns      :
   *
   * Comments     :
   *
   *-----------------------------------------------------------*/


    function numToCurrency(vDecimalSep,vGroupSep,vCurrSym,vNumDeci,vNumber,vFldName)
    {
        var tmp1 = cents = dollars = "";
        var dec = -1;
        var num = i = 0;

        num = eval("document.forms[0]."+ vFldName+".value");
        var vObjFldName;
       
        vObjFldName = eval("document.forms[0]."+ vFldName);

        currencyval = num;
        
        if (vGroupSep.charCodeAt(0) == 160)
        {
            num = num.replace(vGroupSep, '');
            num = num.replace(' ', '');
            vGroupSep = " ";
        }
        
        for(var j=0;j<num.length;j++)
        {
            //alert(num.charCodeAt(j));
            num = num.replace(vGroupSep, '');
        }
        
        num = num.replace(vCurrSym,'');
        // The Decimal seperator for the currency
        deci = vDecimalSep;
        // The Currency Symbol for the currency
        sym  = vCurrSym;
        // The Group Saperator for the currency
        grp  = vGroupSep;
        // No of Decimal places for rounding for the currency
        var numdec = vNumDeci;

        if (checkNum(num,deci,vObjFldName))
        {

            var deciplace = num.indexOf(deci);
            if(deciplace == 0)
            {
                num = "0"+num;
            }

            if(decisepEntered == deci)
            {
                num = num.replace(deci,".");
                dec = num.indexOf(".");

                if(dec > 0)
                {
                    cents =  num.substring(dec,num.length);
                }

                cents = cents.replace(".",deci);
                if(Trim(num)=="")
                {
                    num="0";
                }
                
                    
                dollars = "" + parseInt(num,10);

                tmp1 = insComma(dollars,grp);

                num = sym;

                for (i = tmp1.length-1; i >= 0; i--)
                    num += tmp1.charAt(i);;

                num +=cents;

                
                var vFldboj = eval("document.forms[0]."+vFldName);
                num = num.replace(vCurrSym,'');
                vFldboj.value = Trim(num);
                //alert(num);
                return(true);
            }
            else
            {

                msg =   getMessage('keydeci1')
                      + deci
                      + getMessage('keydeci2');
                alertErr(msg);

                vObjFldName.focus();
            }
        }else
        {
            //alert("Please enter valid currency ");
            vObjFldName.focus();
        }
}

/*-------------------------------------------------------------
   *
   * Function     :  numToNegativeCurrency() used for Currency Formatting.
   *
   * Purpose      :  This method Converts the number to the Loacle currency format
   *                 This also alow the negative values to be entered in the field.
   * Parameters   : vDecimalSep,vGroupSep,vCurrSym,vNumDeci,vNumber,vFldName
   *
   * Returns      :
   *
   * Comments     :
   *
   *-----------------------------------------------------------*/


    function numToNegativeCurrency(vDecimalSep,vGroupSep,vCurrSym,vNumDeci,vNumber,vFldName)
    {
        var tmp1 = cents = dollars = "";
        var dec = -1;
        var num = i = 0;
        var symb="";
        num = eval("document.forms[0]."+ vFldName+".value");
        var vObjFldName;
        vObjFldName = eval("document.forms[0]."+ vFldName);
        if(num.indexOf("-") == 0)
        {
            num =  num.substring(1,num.length);
            symb = "-";
        }
        currencyval = num;

        for(var j=0;j<num.length;j++)
        {
            num = num.replace(vGroupSep, '');
        }
        num = num.replace(vCurrSym,'');
        // The Decimal seperator for the currency
        deci = vDecimalSep;
        // The Currency Symbol for the currency
        sym  = vCurrSym;
        // The Group Saperator for the currency
        grp  = vGroupSep;
        // No of Decimal places for rounding for the currency
        var numdec = vNumDeci;

        if (checkNum(num,deci,vObjFldName))
        {

            var decisepEntered = "";

            decisepEntered = getDeciSep(num);

            if(decisepEntered == undefined)
            {
                decisepEntered = deci;
            }

            var deciplace = num.indexOf(deci);
            if(deciplace == 0)
            {
                num = "0"+num;
            }
            if(decisepEntered == deci)
            {
                num = num.replace(deci,".");
                dec = num.indexOf(".");

                if(dec > 0)
                {
                    cents =  num.substring(dec,num.length);
                }

                cents = cents.replace(".",deci);
                if(Trim(num)=="")
                {
                    num="0";
                }

                dollars = "" + parseInt(num,10);

                tmp1 = insComma(dollars,grp);
                num = sym;

                for (i = tmp1.length-1; i >= 0; i--)
                    num += tmp1.charAt(i);;

                num +=cents;

                var vFldboj = eval("document.forms[0]."+vFldName);
                num = num.replace(vCurrSym,'');
                vFldboj.value = symb + Trim(num);
                
                return(true);
            }
            else
            {

                msg =   getMessage('keydeci1')
                      + deci
                      + getMessage('keydeci2');
                alertErr(msg);

                vObjFldName.focus();
            }
        }else
        {
            //alert("Please enter valid currency ");
            vObjFldName.focus();
        }
}

/*-------------------------------------------------------------
 *
 * Function     :  forwardExtraGeneric
 *
 * Purpose      :  Used to forward the control to an action class
 *                 passing parameters to it
 *
 * Parameters   :  Parent form name
 *                 action class name
 *                 formAction value
 *                 parameters values
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function forwardExtraGeneric()
{
    var args = forwardExtraGeneric.arguments;
    var parentformname = args[0];
    var request = args[1];
    var i;
 
    // The first parameter, if any, must be formAction value
    if(args.length > 1)
    {
        request  = request  + "?formAction=" + args[2];
    }

    // Add all the parameters to the request
    for(i=3; i < args.length; i++)
    {
        request  = request  + "&key" + (i - 2) + "=" + encodeURIComponent( eval("document."+parentformname+"."+args[i]+".value") );
    }
    var str;

	var token_key = document.getElementsByName("TOKEN_KEY")[0].value;
     if(token_key !=''){
    	 str = request+"&TOKEN_KEY="+token_key;
	}else{
		str = request;
	} 
    redirectWithPostMethodUrl(str);
}

/*-------------------------------------------------------------
 *
 * Function     :  zoomRetActionGeneric
 *
 * Purpose      :  Used to close the zoom and start an action
 *                 in the parent with the passed parameters 
 *
 * Parameters   :  Parent form name
 *                 formAction value
 *                 pairs of textbox and value
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function zoomRetActionGeneric()
{
    var args = zoomRetActionGeneric.arguments;
    var parentformname = args[0];
    var i;
 
    eval("window.opener.document." + parentformname + ".formAction.value='" + args[1] + "'");

    // Update fields in the parent
    for(i=2; i < args.length; i += 2)
    {
        eval("window.opener.document." + parentformname + "." + args[i] + ".value = " + args[i + 1]);
    }

    eval("window.opener.document." + parentformname + ".submit()");
    
    window.close();
}
    
/*-------------------------------------------------------------
 *
 * Function     :  zoomSearchExtraGenericSize
 *
 * Purpose      :  Used to populate the parent field with the selected value
 *
 * Parameters   :  Parent form name
 *                 Destinantion JSP name
 *                 With of the new screen
 *                 Height of the new screen
 *                 number of information fields
 *                 Parent form information field names
 *                 Parent form field names to be populated
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function zoomSearchExtraGenericSize()
{
    var args = zoomSearchExtraGenericSize.arguments;
    var parentformname = args[0];
    var jspname = args[1];
    var screenName = jspname;
    var dec = screenName.indexOf(".");
    if(dec > 0)
    {
        screenName =  screenName.substring(0,dec);
    }
    var width = args[2];
    var height = args[3];
    var inf_fields = args[4];
    var request = "parentFormName="+parentformname;
    var i;
 
    // Add all the information variables to the request
    for(i=5; i < 5 + inf_fields; i++)
    {
        request = request + ("&infoField" + (i - 2)) + "=" + eval("document."+parentformname+"."+args[i]+".value");
    }

    // Add all the remaining variables as textbox names to the request
    for(i=5 + inf_fields; i < args.length; i++)
    {
        request = request + ("&parentTextBoxName" + (i - (2 + inf_fields))) + "=" + args[i];
    }

    openWindowWithPostMethod(jspname, screenName, request, "toolbar=no,location=no," +
            "directories=no,status=yes,menubar=no,scrollbars=yes," + "resizable=no,width=" + width + ",height=" + height);
}

/*-------------------------------------------------------------
 *
 * Function     :  forwardExtraGenericSubmit
 *
 * Purpose      :  Submits current form with a particular action
 *
 * Parameters   :  Parent form name
 *                 formAction value
 *                 pairs of textbox and value if any
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function forwardExtraGenericSubmit()
{
    var args = forwardExtraGenericSubmit.arguments;
    var parentformname = args[0];
    var i;
 
    document.forms[0].formAction.value = args[1];

    // Update fields
    for(i=2; i < args.length; i += 2)
    {
        eval("document.forms[0]." + args[i] + ".value = '" + args[i + 1] + "'");
    }

    enableDropdown();
    document.forms[0].submit();
}

/*-------------------------------------------------------------
 *
 * Function     :  addupdateGeneric
 *
 * Purpose      :  Submit an new window or and updated one. It 
 *                 calls another function (passed as a parameter)
 *                 to perform checking for that particular screen
 *
 * Parameters   :  formname:  Name of the parent form
 *                 operation: Action class operation to be performed
 *                 function: Validation function particular for each
 *                           form to be called
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function addupdateGeneric()
{
    var args = addupdateGeneric.arguments;
    var formname = args[0];
    var operation = args[1];
    var function_name = "";

    var ret = false;

    // Check if there is extra validation
    if(args.length > 2)
    {
        function_name = args[2];
    }

    // Only check dirty when updating
    if(operation.indexOf("update") >= 0)
    {
        if(!DirtyFormcheck(true))
        {
            statusMsg = getMessage('keydirtyreadnot');
            alert(statusMsg);
            
            return;
        }
    }

    // Call the validation function
    if(function_name != "")
    {
        if(checkForm(document.forms[0]) && eval(function_name + "('" + formname + "')"))
        {
            if(operation.indexOf("add") >= 0)
            {
                statusMsg=getMessage('keyrecsaddwishcont');
            }
            else
            {
                statusMsg=getMessage('keyrecsupdwishcont');
            }
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
               "\n\n" + statusMsg + "\n" +
               "___________________________________________________" +
               "\n\n" + actionMsg;

            ret = confirm(msg);
        }
    }
    else
    {
        if(checkForm(document.forms[0]))
        {
            if(operation.indexOf("add") >= 0)
            {
                statusMsg=getMessage('keyrecsaddwishcont');
            }
            else
            {
                statusMsg=getMessage('keyrecsupdwishcont');
            }
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
               "\n\n" + statusMsg + "\n" +
               "___________________________________________________" +
               "\n\n" + actionMsg;

            ret = confirm(msg);
        }
    }
    

    // Submit the form if user has confirmed
    if(ret)
    {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  isValidCurrRangeForCountry
 *
 * Purpose      :  Validates the Currrate Range
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function isValidCurrRangeForCountry(arg1)
  {

    var varcurr = document.forms[0].elements[arg1].value;
    if(Trim(varcurr) != '')
    {
        document.forms[0].formAction.value='repopulate';
        document.forms[0].submit();
    }

 }


 /*-------------------------------------------------------------
     *
     * Function     :  populatereccardstatement
     *
     * Purpose      : This is used for populating of the record on blur of institution code
     *                and Pan number.
     *
     * Parameters   : formname,operation
     *
     * Returns      :
     *
     * Comments     : used for the Set card statement cycle screen
     *
     *-----------------------------------------------------------*/

   function populatereccardstatement(formname,operation)
   {
        var ret = false;
        var valid = true;

        if(document.forms[0].pan.value != "")
        {
            if(checkForm(document.forms[0]))
            {
                enableDropdown();
                document.forms[formname].formAction.value = operation;
                document.forms[formname].submit();
            }
        }
  }
  
  /*-------------------------------------------------------------
    *
    * Function     :  populatePanDetails
    *
    * Purpose      :  This method is called to populate the pan details in
    *                   AdditionalApplication screen. When user enters pan and
    *                 tabbed out the pan details will be populated.
    *
    * Parameters   :
    *
    * Returns      :
    *
    * Comments     : //Modified to fix TR-0997,0999 :Vinay
    *
    *-----------------------------------------------------------*/
  function populatePanDetails()
  {
    if(document.forms[0].pri_pan.value == '')
    {
        document.forms[0].pannumber.focus();
        return false;
    }
    else
    {
        if((document.forms[0].prvpan.value == document.forms[0].pri_pan.value) && document.forms[0].repStatus.value == 'true')
        {
            return false;
        }
        else
        {
            document.additionalapplicationfrm.formAction.value="repopulate";
            document.additionalapplicationfrm.submit();
        }
        if(document.forms[0].repStatus.value == 'true')
        {
            return false;
        }
    }
    document.additionalapplicationfrm.formAction.value="repopulate";
    document.additionalapplicationfrm.submit();
   }

    /*--------------------------------------------------------------------
    *
    * Function     :  updaterecord
    *
    * Purpose      :  Confirmation On Update.This is similar to updaterec()
    *                 except it does not call for DirtyFormcheck.
    *                 Confirmation Message is displayed on the screen
    *                 when user clicks on update.
    *                 This enables the Dropdown before updating records as
    *                 values from the Disabled dropdowns cannot be submitted
    *
    * Parameters   :
    *
    * Returns      :
    *
    * Comments     :
    *
    *----------------------------------------------------------------------*/

    function updaterecord(formname,operation)
    {
        var ret = false;

        if (checkForm(document.forms[0]) )
        {
            statusMsg=getMessage('keyrecsupdwishcont');
            actionMsg=getMessage('keydoyouwancontinue');
            msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n" +
            "___________________________________________________" +
            "\n\n" + actionMsg;

            ret = confirm(msg);

        }
        if(ret)
        {
            enableDropdown();

            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
    }

/*-------------------------------------------------------------
 *
 * Function     :  doTabSearchGeneric
 *
 * Purpose      :  Used in search screens with several tabs. It
 *                 does only check the fields in the current tab
 *
 * Parameters   :  formname:  Name of the parent form
 *                 operation: Action class operation to be performed
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function doTabSearchGenericVirtualPan(formname, operation)
{
    fields = new Array();
    var elem;
    var i = 0;
    var j = 0;
    var check_ok = true;
    var panValue = "-";
    var virtualPanValue = "-";
    var thereIsAPanFieldInThisTab = false;
    
    for(i = 0; elem = document.all[names[i]]; i++)
    {
        if(tabs[elem.name] == document.forms[0].tabid.value)
        {
            fields[j++] = elem;
        }
    }

    i = 0;
    
    while(check_ok == true && i < j)
    {
    	elem = fields[i];
        
    	if(elem.name == "virtualPan")
        {
    		thereIsAPanFieldInThisTab = true;
        	virtualPanValue = elem.value;
        }
    	
        if(elem.name == "pan")
        {
    		thereIsAPanFieldInThisTab = true;
        	panValue = elem.value;
        } 
        
    	check_ok = check_ok & validateFld(fields[i++]);
    }
	
    if (thereIsAPanFieldInThisTab) {
    	var tPan = Trim(panValue);
    	var tVirtualPan = Trim(virtualPanValue);
	    if (!((tPan == "" && tVirtualPan != "") || (tPan != "" && tVirtualPan == ""))) {
		    errMsg = getMessage('keypanorvpan');
		    alertErr(errMsg);
		    check_ok = false;
		}
    }
    
    // If all the fields are ok, call the action class
    if(check_ok)
    {
        enableDropdown();
        document.forms[formname].tabCheck.value = 'tab';
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
}

/*-------------------------------------------------------------
*
* Function     :  searchTabCardMaint() used for Card Maintenance search screen.
*
* Purpose      :
*
* Parameters   :
*
* Returns      :
*
* Comments     : This javascript function is required due to 
*                the framework not yet supporting mandatory field
*                checks when there are several search criteria
*                (ie several tabs in search screen)
*
*-----------------------------------------------------------*/
function searchTabCardMaint()
{
    var check_ok = true;

    if(document.forms[0].tabid.value == 0)
    {
    	check_ok = check_ok & validateFld(document.forms[0].instcode);
    	if(check_ok)
    	    check_ok = check_ok & validateFld(document.forms[0].lastname);
    }
    if(document.forms[0].tabid.value == 1)
    {
    	check_ok = check_ok & validateFld(document.forms[0].instcode1);
    	if(check_ok)
    	    check_ok = check_ok & validateFld(document.forms[0].seqno);
		if(check_ok)
			check_ok = check_ok & panVirtualPanCheck();
    }
    if(document.forms[0].tabid.value == 2)
    {
    	check_ok = check_ok & validateFld(document.forms[0].instcode2);
    	if(check_ok)
    	    check_ok = check_ok & validateFld(document.forms[0].accno);
    }
    if(document.forms[0].tabid.value == 3)
    {
    	check_ok = check_ok & validateFld(document.forms[0].instcode3);
    	if(check_ok)
    	    check_ok = check_ok & validateFld(document.forms[0].custcode);
    }
    if(document.forms[0].tabid.value == 4)
    {
    	check_ok = check_ok & validateFld(document.forms[0].instcode4);
    	if(check_ok)
    	    check_ok = check_ok & validateFld(document.forms[0].strBatch);
    }
    if(document.forms[0].tabid.value == 5)
    {
    	if(document.forms[0].instcode5 != null)
    	{
        	check_ok = check_ok & validateFld(document.forms[0].instcode5);
    	}
    	else if(document.forms[0].instcode6 != null)
    	{
        	check_ok = check_ok & validateFld(document.forms[0].instcode6);
        	if(check_ok)
        	    check_ok = check_ok & validateFld(document.forms[0].usrdata1);
    	}
    	else if(document.forms[0].instcode8 != null)
    	{
        	check_ok = check_ok & validateFld(document.forms[0].instcode8);
        	if(check_ok)
        	    check_ok = check_ok & validateFld(document.forms[0].externalCustomerId);        	
    	}
    }

    if(check_ok)
    {
        enableDropdown();
        document.forms[0].tabCheck.value = 'tab';
        document.forms[0].formAction.value = 'search';
        document.forms[0].submit();
    }
}

/*-------------------------------------------------------------
*
* Function     :  doTabSearchAccMaint() used for Account Maintenance search screen.
*
* Purpose      :
*
* Parameters   :
*
* Returns      :
*
* Comments     : This javascript function is required due to 
*                the framework not yet supporting mandatory field
*                checks when there are several search criteria
*                (ie several tabs in search screen)
*
*-----------------------------------------------------------*/
function doTabSearchAccMaint(formname, operation)
{
    var check_ok = true;

    if(document.forms[0].tabid.value == 0)
    {
    	check_ok = check_ok & validateFld(document.forms[0].instcode);
    	if(check_ok)
    	    check_ok = check_ok & validateFld(document.forms[0].accno);
    }
    
	if(document.forms[0].tabid.value == 1)
    {
    	check_ok = check_ok & validateFld(document.forms[0].instcode1);
    	if(check_ok)
    	    check_ok = check_ok & validateFld(document.forms[0].custcode);
    }
	
    // If all the fields are ok, call the action class
    if(check_ok)
    {
        enableDropdown();
        document.forms[formname].tabCheck.value = 'tab';
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
}

function doTabSearchGeneric(formname, operation)
{
    fields = new Array();
    var elem;
    var i = 0;
    var j = 0;
    var check_ok = true;
    
    for(i = 0; elem = document.all[names[i]]; i++)
    {
        if(tabs[elem.name] == document.forms[0].tabid.value)
        {
            fields[j++] = elem;
        }
    }

    i = 0;
    while(check_ok == true && i < j)
    {
        check_ok = check_ok & validateFld(fields[i++]);
    }
    
    // If all the fields are ok, call the action class
    if(check_ok)
    {
        enableDropdown();
        document.forms[formname].tabCheck.value = 'tab';
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
}

/*-------------------------------------------------------------
 *
 * Function     :  printGenericMessage
 *
 * Purpose      :  Prints messages in in an alert box
 *
 * Parameters   :  resoruce:  Name or the resource entry to print
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function printGenericMessage()
{
    var args = printGenericMessage.arguments;
    var msg = "";
    var i = 0;
    
    for(i = 0; i < args.length; i++)
    {
        msg = msg + getMessage(args[i]) + "\n";
    }
    
    alert(msg);
}

/*-------------------------------------------------------------
 *
 * Function     :  checkCurrLength
 *
 * Purpose      :  Checks the Currencylength if It is not eaual to 3 
 *                 Then error message will appear               
 *
 * Parameters   :  resoruce:  Name or the resource entry to print
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function checkCurrLength(var1)
{
    var currcode = eval("document.forms[0]."+var1+".value");
    var currcodefield = eval("document.forms[0]."+var1);
    if ((currcode.length > 0) && (currcode.length != 3))    
    {
        
        actionMsg=getMessage('keycurrfield');
        msg = "___________________________________________________" +
            "\n\n" + actionMsg + "\n";
        alert(msg);
        currcodefield.focus();
        return false;
    }
    return true;
}

/*-------------------------------------------------------------
 *
 * Function     :  checkCurrLength
 *
 * Purpose      :  Checks the Currencylength if It is not eaual to 3 
 *                 Then error message will appear               
 *
 * Parameters   :  resoruce:  Name or the resource entry to print
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
function gotoAltRouting(formname)
{
	redirectWithPostMethod("coaltroutesearchon.do", "formAction=search&routing="+document.forms[formname].altroute.value+"&iid="+document.forms[formname].iid.value);
    return true;
}

/*-------------------------------------------------------------
 *
 * Function     :  ZoomSelectGeneric
 *
 * Purpose      :  Used to pass data back to the parent window
 *
 * Parameters   :  Parent form name
 *                 Parent form field name ,val pairs
 *         e.g. ZoomSelectGeneric('parentformname','textboxname1','textboxval1','textboxname2','textboxval2')
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/
 
function ZoomSelectGeneric()
{
    var args = ZoomSelectGeneric.arguments;
    var parentformname = args[0];
    for(i=1; i<args.length; i++)
    {
        var parentTextBoxName = args[i];
        var val = args[i + 1];
        eval("window.opener.document."+parentformname+"."+parentTextBoxName+".value="+"'"+val+"'");
    i++;
    }
    window.close();
}
/*-------------------------------------------------------------
 *
 * Function     :  formRepulate
 *
 * Purpose      :  populates the form fields onblur of the key field
 *
 * Parameters   :  arg1 - keyfield name
 *
 * Returns      :
 *
 * Comments     :
 * GDE:040419 - extended to allow invocation with no arguments.
 *-----------------------------------------------------------*/

function rePopulateForm(arg1)
{
    if (rePopulateForm.arguments.length <= 0)
    {
        document.forms[0].formAction.value='repopulate';
        document.forms[0].submit();
    }
    else
    {
        var varcurr = document.forms[0].elements[arg1].value;
        
        if(Trim(varcurr) != '')
        {
            document.forms[0].formAction.value='repopulate';
            document.forms[0].submit();
        }
    }
 }
 
/*-------------------------------------------------------------
 *
 * Function     :  performPrompt
 *
 * Purpose      :   
 *
 * Parameters   :  
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

function performPrompt()
{

    var ar = performPrompt.arguments;
    var formname = ar[0];


    actionMsg=getMessage('keyprompt2');
    msg = actionMsg + "\n";
    ret = confirm(msg);
    if(ret)
    {
         var param_add = ar[1].indexOf("?")==-1 ? "?": "&";
         var str = ar[1] + param_add+"formAction=prompt";

        for(i=2;i<ar.length;i++)
        {
            str = str + ("&key" + i) + "=" + encodeURIComponent(ar[i]);
        }
        redirectWithPostMethodUrl(str);
    }
    else
    {
        document.forms[0].formAction.value = '';
        document.forms[0].submit();

    }         
}
 
/*-------------------------------------------------------------
*
* Function     :  performConfirmation
*
* Purpose      :   
*
* Parameters   :  
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/

function performConfirmation()
{

   var ar = performConfirmation.arguments;
   var formname = ar[0];


   actionMsg=getMessage('keyprompt2');
   msg = actionMsg + "\n";
   ret = confirm(msg);
   if(ret)
   {
        var param_add = ar[1].indexOf("?")==-1 ? "?": "&";
        var str = ar[1] + param_add+"formAction=prompt";

       for(i=2;i<ar.length;i++)
       {
           str = str + ("&key" + i) + "=" + encodeURIComponent(ar[i]);
       }
       redirectWithPostMethodUrl(str);
   }
   else
   {
	   return false;

   }         
}
 
 
 /*-------------------------------------------------------------
  *
  * Function     :  Confirmation On running report in ifm module
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on Delete.
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/
 
  function runreport(formname,operation)
  {

     actionMsg=getMessage('keygeneratewishcont');
     msg ="___________________________________________________" +
         "\n\n" + actionMsg;
     if(confirm(msg))
     {
         enableDropdown();
         document.forms[formname].formAction.value = operation;
         document.forms[formname].submit();
     }
     else
         return false;
  }

 /*-------------------------------------------------------------
  *
  * Function     :  Validation Segment limits mandatory inputs
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on Delete.
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/
 
  function validateTranLimit()
  {

     var args = validateTranLimit.arguments;
     var formname = args[0];
     var operation = args[1];
     var pan = rtrim(args[2]);
     var seqno = rtrim(args[3]);
     var segment = rtrim(args[4]);
     var cardprod = rtrim(args[5]);
     var pass = false;
     
          
     if ((pan.length != 0) && (segment.length == 0 && cardprod.length == 0))
     {
        pass = true;
     }
     else if ((segment.length != 0 && cardprod.length != 0) && (pan.length == 0))
     {
        pass = true;
     }
     
      var Msg=getMessage('keyinputsnotcomplete');
     msg ="___________________________________________________" +
         "\n\n" + Msg;
     if (pass)
     {
         if(operation == 'add')
         {
             newrec(formname,operation);
         }
         else if(operation == 'update')
         {
             updaterec(formname,operation);
         }
    }
    else
    {
        alert(Msg);
    }
  }    

  function validateTranLimitab()
  {

     var args = validateTranLimitab.arguments;
     var formname = args[0];
     var operation = args[1];
     var pan = rtrim(args[2]);
     var seqno = rtrim(args[3]);
     var cardprod = rtrim(args[4]);
     var pass = false;
     
          
     if ((pan.length != 0) && (cardprod.length == 0))
     {
        pass = true;
     }
     else if ((cardprod.length != 0) && (pan.length == 0))
     {
        pass = true;
     }
     
      var Msg=getMessage('keyinputsnotcomplete');
     msg ="___________________________________________________" +
         "\n\n" + Msg;
     if (pass)
     {
         if(operation == 'add')
         {
             newrec(formname,operation);
         }
         else if(operation == 'update')
         {
             updaterec(formname,operation);
         }
    }
    else
    {
        alert(Msg);
    }
  }    

    function rtrim(stringtotrim)
    {
        var i = stringtotrim.length;
        var j =0;
        var iLen = i;
        var trimmedstring = stringtotrim;
        if ( iLen > 0)
        {
           for (j=0;j<iLen;j++)
           {
                if (stringtotrim.substr(i-1,1) == " ")
                {
                    i = i -1;
                    trimmedstring = stringtotrim.substr(0,i);
                }
           }
        }
        return trimmedstring;
    }


 
  /*-------------------------------------------------------------
  *
  * Function     :  Confirmation On Apply USed in ATM Note id and Terminal Note id
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on apply.
  *                 This enables the Dropdown before updating records as
  *                 values from the Disabled dropdowns cannot be submitted
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function applyrec(formname,operation)
  {
    var ret = false;

    //Added for AT-0152
    if(!DirtyFormcheck(true))
    {
        ret=true;
    //statusMsg=getMessage('keydirtyreadnot');
    //alert(statusMsg);
    }
    if (checkForm(document.forms[0]) && DirtyFormcheck(true))
    {
     statusMsg=getMessage('keyapply');
     actionMsg=getMessage('keydoyouwancontinue');
     msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

     ret = confirm(msg);

     }
    if(ret)
       {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
       }
  }
 /*-------------------------------------------------------------
  *
  * Function     :  Validation Segment limits mandatory inputs
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on Delete.
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/
 
  function validateCcschrgprof()
  {

    if (checkForm(document.forms[0]))
    {
        enableDropdown();
    
             var args = validateCcschrgprof.arguments;
             var formname = args[0];
             var operation = args[1];
             var feecmp = rtrim(args[2]);
             var maxcmp = rtrim(args[3]);
             var pass=false;
            
            if ((feecmp.length !=0) && (maxcmp.length != 0))
            {
                feecmp = parseInt(feecmp);
                maxcmp = parseInt(maxcmp);
                 if ((feecmp >= 0) && (feecmp <= maxcmp))
                 {
                    pass=true;
                 }
        
                 //alert(pass);
                  var Msg=getMessage('keyinputsnotvalid');
                 msg ="___________________________________________________" +
                     "\n\n" + Msg;
                 if (pass)
                 {
                     if(operation == 'add')
                     {
                         newrec(formname,operation);
                     }
                     else if(operation == 'update')
                     {
                         updaterec(formname,operation);
                     }
                }
                else
                {
                    alert(Msg);
                }
            }
    }           
}    
 function updaterecCustomDirty(formname,operation)
  {
    var ret = false;
    var dirty = false;
    var dirtyCheckArgs = updaterecCustomDirty.arguments;
    var iLen = dirtyCheckArgs.length;
    var j = 2;
    
    if ( (iLen > 2) && (iLen % 2 == 0))
    {
           for (j=2;j < iLen;j=j + 2)
           {
                if ( dirtyCheckArgs[j] != dirtyCheckArgs[j +1])
                {
                    dirty = true;
                    break;
                }
                
           }

    }
    if (!(dirty))
    {
           if(DirtyFormcheck(true))
           {
                dirty = true;
                
            }
    }
    if (!(dirty))
    {
        statusMsg=getMessage('keydirtyreadnot');
        alert(statusMsg);
    }
        
    if (checkForm(document.forms[0]) && dirty)
    {
     statusMsg=getMessage('keyrecsupdwishcont');
     actionMsg=getMessage('keydoyouwancontinue');
     msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;

     ret = confirm(msg);

     }
    if(ret)
       {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
       }
  }

  function HeadOffice_warning()
  {
    var args = HeadOffice_warning.arguments;
     var formname = args[0];
     var operation = args[1];
     var mrchno = rtrim(args[2]);
     var headoffice = rtrim(args[3]);
     var paymto= rtrim(args[4]);
     var paymto_orig =rtrim(args[5]);
     var stmtto_ho=rtrim(args[6]);
     var warn = false;
     var proceed = true;
    

 if (headoffice.length != 0)
 {
    
     if(operation == 'add')
     {
        warn = true;
     }
     else if(operation == 'update')
     {
        if ( paymto.length != 0)
        {
            if (paymto_orig.length != 0)
            {
                if (paymto != paymto_orig)
                {
                    warn=true;              
                }
            }
            else
            {
                warn=true;
            }
        
        }
        else if (paymto_orig.length != 0)
        {
            warn = true;
        }
     }
 }
        if (warn)
        {
                var statusMsg=getMessage('keywarnheadoffice');

                pass = alert(statusMsg);
        }
        if (headoffice.length == 0)
        {
            if (paymto != 0)
            {
            
                var warnMsg=getMessage('keywarnpaytoheadoffice');
                proceed = false;
                pass = alert(warnMsg);

            }
            if ( stmtto_ho != 0)
            {
                var warnMsg=getMessage('keywarnstmttoheadoffice');
                proceed = false;
                pass = alert(warnMsg);

            }
        }
        if(proceed)
        {
            if(operation == 'add')
             {
                newrec(formname,operation);
             }
             else if(operation == 'update')
             {
                updaterec(formname,operation);
             }
        }       

     }
        
function SearchSelectCustomAction()
{
    var ar = SearchSelectCustomAction.arguments;
    
    var param_add = ar[0].indexOf("?")==-1 ? "?": "&";
    if (ar[1].length != 0)
    {
        var str = ar[0] + param_add+"formAction=" + ar[1];
    }
    else
    {
        var str = ar[0] + param_add+"formAction=";
    }
    
    // force conversion of element names to key1..keyn after unmasking
    str = str + "&namesToKeys=true";
    
    // add the formAcsitem
    str = str + "&formAcsitem=" + document.forms[0].formAcsitem.value;
    
    for(i=1;i<ar.length-1;i++)
    {
        //str = str + "&key" + i + "=" + ar[i + 1];
        	
        if(!ar[i+1].name)
    	{
    		// we have a string
        	str = str + ("&key" + i) + "=" + encodeURIComponent(ar[i + 1]);
        }
        else
        {
        	// we have an element
       		str = str + "&" + ar[i + 1].name + "=" + encodeURIComponent(ar[i + 1].value);
        }
    }
    redirectWithPostMethodUrl(str);
}

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Delete
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *                 when user clicks on Delete.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function delreccustom(formname,operation,fileseq)
 {
    if (fileseq == 0)
    {
        delrec(formname,operation);
    }
    else
    {
        statusMsg=getMessage('keynewrecordcopy');
        actionMsg=getMessage('keydoyouwancontinue');
        msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n" +
            "___________________________________________________" +
            "\n\n" + actionMsg;
        if(confirm(msg))
        {
            enableDropdown();
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
        else
            return false;
    }
 }
 
 /**
 * This function validates AmxChargebackDetail.
 **/
 function updaterecWarning(formname,operation)
 {
 	var fraudexists = document.forms[formname].fraudexists.value;
 	if ( fraudexists = "false")
 	{
 	        var warnMsg=getMessage('keywarnnofraudentry');
            alert(warnMsg);
    } 
    updaterec(formname,operation);
 }
         
 /**
 * WARNING - do not use this function. parseFloat is not compatible with localisation.
 */
 function validateAmtNewrec(formname,operation,orgTxnAmt,chrgbckAmt,decimalSeparator)
 {

    if (validateAmt(chrgbckAmt,orgTxnAmt,decimalSeparator))
	    newrec(formname,operation);
	else
		return false;
 }
 
 /**
 * WARNING - do not use this function. parseFloat is not compatible with localisation.
 */
  function validateAmt(amtField,limitField,decimalSeparator)
 {
    var decimalSeparatorVal = decimalSeparator.value;
    var amtFieldVal = amtField.value;
    for(var i=0;i<amtFieldVal.length;i++)
    {
        if(!(isDigit(amtFieldVal.charAt(i)) || (amtFieldVal.charAt(i)==decimalSeparatorVal.charAt(0))))
        {
            amtFieldVal = amtFieldVal.replace(amtFieldVal.charAt(i) ,'');
        }
    }
    var limitFieldVal = limitField.value;
    for(var i=0;i<limitFieldVal.length;i++)
    {
        if(!(isDigit(limitFieldVal.charAt(i)) || (limitFieldVal.charAt(i)==decimalSeparatorVal.charAt(0))))
        {
            limitFieldVal = limitFieldVal.replace(limitFieldVal.charAt(i) ,'');
        }
    }
    if (parseFloat(amtFieldVal) > parseFloat(limitFieldVal))
    {
        actionMsg = getMessage('keyEPINVALIDAMT');
        statusMsg = getMessage('keyplstryagain1') + "\n" + getMessage('keyplstryagain2');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n"+
        "___________________________________________________" +
        "\n\n" + actionMsg + "\n";

        alert(msg)
        focusEl(amtField);
        amtField.value = limitField.value;
        return false;
    }  
    return true;
 }

 /**
 * WARNING - do not use this function. parseFloat is not compatible with localisation.
 */
  function validateAmtGreater(amtField,limitField)
 {
    if (parseFloat(amtField.value) < parseFloat(limitField.value))
    {
        actionMsg = getMessage('keyINVALIDAMTGT') + limitField.value + " .";
        statusMsg = getMessage('keyplstryagain1') + "\n" + getMessage('keyplstryagain2');
        msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n"+
        "___________________________________________________" +
        "\n\n" + actionMsg + "\n";

        alert(msg)
        focusEl(amtField);
        amtField.value = limitField.value;
        return false;
    }
    return true;
 }
 function searchChargebacks()
 {
 	var curtxn = Trim(document.forms[0].curtxn.value);
 	var amttxn = Trim(document.forms[0].amtTxn.value);
 	if (checkForm(document.forms[0]))
    {
	 	if (amttxn.length != 0 && curtxn.length == 0)
	 	{
	 		rePopulateForm();	
	 	}
	 	else
	 		searchrec();
	 	
	 }
	 
 }      
 	function submitOperation(formname,operation,messagekey)	 
	{
	
		
	    var statusMsg=getMessage(messagekey);
        var actionMsg=getMessage('keydoyouwancontinue');
        var msg = "___________________________________________________" +
            "\n\n" + statusMsg + "\n" +
            "___________________________________________________" +
            "\n\n" + actionMsg;
        if(confirm(msg))
        {
            enableDropdown();
            document.forms[formname].formAction.value = operation;
            document.forms[formname].submit();
        }
        else
            return false;

	}
 
 function setDate(sendnow)
 {
 		d = new Date();
 		
 		tiHour = d.getHours();
 		tiMinute = d.getMinutes();
 		tiSecond = d.getSeconds();
 		
 		if (sendnow=="1")
 		{
 			var tsTime = ((tiHour < 10) ? "0" + tiHour : "" + tiHour) + ":" + ((tiMinute < 10) ? "0" + tiMinute : "" + tiMinute) + ":" + ((tiSecond < 10) ? "0" + tiSecond : "" + tiSecond);
 			document.forms[0].scheddate.value = document.forms[0].currentdate.value;
 			document.forms[0].schedtime.value = tsTime;
	       	for (var i=0; i<non_hidden_types.length; i++)
     		{
		        if (non_hidden_types[i] == 'scheddate')
        		{
		            document.forms[0].elements[non_hidden_types[i]].readOnly = true;
		            document.forms[0].elements[non_hidden_types[i]].style.backgroundColor = document.forms[0].datexmit.style.backgroundColor;
        		}
		        if (non_hidden_types[i] == 'schedtime')
        		{
		            document.forms[0].elements[non_hidden_types[i]].readOnly = true;
		            document.forms[0].elements[non_hidden_types[i]].style.backgroundColor = document.forms[0].datexmit.style.backgroundColor;
        		}

     		}
         	
        }
        else
        {
        	for (var i=0; i<non_hidden_types.length; i++)
     		{
		        if (non_hidden_types[i] == 'scheddate')
        		{
		            document.forms[0].elements[non_hidden_types[i]].readOnly = false;
		            document.forms[0].elements[non_hidden_types[i]].style.backgroundColor = document.forms[0].nbrtype.style.backgroundColor;
		            document.forms[0].elements[non_hidden_types[i]].focus();
        		}
		        if (non_hidden_types[i] == 'schedtime')
        		{
		            document.forms[0].elements[non_hidden_types[i]].readOnly = false;
		            document.forms[0].elements[non_hidden_types[i]].style.backgroundColor = document.forms[0].nbrtype.style.backgroundColor;
        		}

     		}
  		}
		
 }
  function setTelnbr(nbrtype)
 {
 		
 		if (nbrtype=="1" || nbrtype=="2")
 		{
 		
        	for (var i=0; i<non_hidden_types.length; i++)
     		{
		        if (non_hidden_types[i] == 'telnbr')
        		{
		            document.forms[0].elements[non_hidden_types[i]].readOnly = false;
		            document.forms[0].elements[non_hidden_types[i]].style.backgroundColor = document.forms[0].nbrtype.style.backgroundColor;
		            document.forms[0].elements[non_hidden_types[i]].focus();
		            break;
        		}
     		}
        }
        else
        {
 			document.forms[0].telnbr.value = "";
	       	for (var i=0; i<non_hidden_types.length; i++)
     		{
		        if (non_hidden_types[i] == 'telnbr')
        		{
		            document.forms[0].elements[non_hidden_types[i]].readOnly = true;
		            document.forms[0].elements[non_hidden_types[i]].style.backgroundColor = document.forms[0].datexmit.style.backgroundColor;
		            break;
        		}
     		}
 		}
 		
 }
// for atm notification - LSB 
  function setMsgsrc(msgsrc)
 {
 	
	for (var i=0; i<non_hidden_types.length; i++)
    {
			if (msgsrc=="0")
			{
				document.forms[0].descrtype.value = "";
				document.forms[0].str_id.value = "";
		        if (non_hidden_types[i] == 'descrtype')
        		{
		            document.forms[0].elements[non_hidden_types[i]].readOnly = true;
		            mnd[document.forms[0].elements[non_hidden_types[i]].name] = "false";		
		            document.forms[0].elements[non_hidden_types[i]].style.backgroundColor = document.forms[0].time_stamp_date.style.backgroundColor;
        		}
 		        if (non_hidden_types[i] == 'str_id')
        		{
		            document.forms[0].elements[non_hidden_types[i]].readOnly = true;
		            mnd[document.forms[0].elements[non_hidden_types[i]].name] = "false";		            
		            document.forms[0].elements[non_hidden_types[i]].style.backgroundColor = document.forms[0].time_stamp_date.style.backgroundColor;
        		}
		        if (non_hidden_types[i] == 'num_id')
        		{
		            document.forms[0].elements[non_hidden_types[i]].readOnly = false;
		            mnd[document.forms[0].elements[non_hidden_types[i]].name] = "true";		            
		            document.forms[0].elements[non_hidden_types[i]].style.backgroundColor = document.forms[0].set_id.style.backgroundColor;
		            document.forms[0].elements[non_hidden_types[i]].focus();
        		}
    		}
	 		if (msgsrc=="1")
	 		{
	 			document.forms[0].num_id.value = "";
		        if (non_hidden_types[i] == 'descrtype')
        		{
		            document.forms[0].elements[non_hidden_types[i]].readOnly = false;
		            mnd[document.forms[0].elements[non_hidden_types[i]].name] = "true";
		            document.forms[0].elements[non_hidden_types[i]].style.backgroundColor = document.forms[0].set_id.style.backgroundColor;
		            document.forms[0].elements[non_hidden_types[i]].focus();
        		}
				if (non_hidden_types[i] == 'num_id')
        		{
		            document.forms[0].elements[non_hidden_types[i]].readOnly = true;
		            mnd[document.forms[0].elements[non_hidden_types[i]].name] = "false";
		            document.forms[0].elements[non_hidden_types[i]].style.backgroundColor = document.forms[0].time_stamp_date.style.backgroundColor;
        		}
		        if (non_hidden_types[i] == 'str_id')
        		{
		            document.forms[0].elements[non_hidden_types[i]].readOnly = false;
		            mnd[document.forms[0].elements[non_hidden_types[i]].name] = "true";
		            document.forms[0].elements[non_hidden_types[i]].style.backgroundColor = document.forms[0].set_id.style.backgroundColor;
        		}
	 		}
	 		if (msgsrc=="2")
	 		{
	 			document.forms[0].str_id.value = "";
		        if (non_hidden_types[i] == 'descrtype')
        		{
		            document.forms[0].elements[non_hidden_types[i]].readOnly = false;
		            mnd[document.forms[0].elements[non_hidden_types[i]].name] = "true";
		            document.forms[0].elements[non_hidden_types[i]].style.backgroundColor = document.forms[0].set_id.style.backgroundColor;
		            document.forms[0].elements[non_hidden_types[i]].focus();
        		}
				if (non_hidden_types[i] == 'str_id')
        		{
		            document.forms[0].elements[non_hidden_types[i]].readOnly = true;
		            mnd[document.forms[0].elements[non_hidden_types[i]].name] = "false";
		            document.forms[0].elements[non_hidden_types[i]].style.backgroundColor = document.forms[0].time_stamp_date.style.backgroundColor;
        		}
		        if (non_hidden_types[i] == 'num_id')
        		{
		            document.forms[0].elements[non_hidden_types[i]].readOnly = false;
		            mnd[document.forms[0].elements[non_hidden_types[i]].name] = "true";
		            document.forms[0].elements[non_hidden_types[i]].style.backgroundColor = document.forms[0].set_id.style.backgroundColor;
        		}
	 		}
 		}
 } 
 
 function performCheck(formname,operation)
 {
 
 	var ret = true;
 	var checkfields = performCheck.arguments;

 	if (checkfields.length > 2)
 	{
	 	var merchanttyp = document.forms[0].elements[checkfields[2]].value;
 		var stanval = document.forms[0].elements[checkfields[3]].value;
	 	if (merchanttyp == '6011')
	 	{
	 		if ( stanval == '0')
	 		{
		 		ret = false;
			    var msg  = "________________________________________________________\n\n";
			    msg += getMessage('keyplstryagain1') + "\n" + getMessage('keyplstryagain2') + "\n\n";
			    msg += "________________________________________________________\n\n";
		 		
	 			msg= msg + getMessage('keyinputsnotcomplete');
				alert(msg);	
				document.forms[0].elements[checkfields[3]].focus();
	 		}
	 	}
 	}

 	if (ret)
 	{
         if(operation == 'add')
         {
             newrec(formname,operation);
         }
         else if(operation == 'update')
         {
             updaterec(formname,operation);
         }
 	}
 }
 
 /*-------------------------------------------------------------
 *
 * Function     :  refreshSelect1
 *
 * Purpose      :
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     : to call action repopulateone in case of two diff refresh selects
 *
 *-----------------------------------------------------------*/
function refreshSelectOne()
{
    document.forms[0].formAction.value='repopulateone';
    document.forms[0].submit();
}
 
function performCcsCorrespondanceCheck(formname,operation)
 {
 
 	var ret = true;
 	var maxcreate = document.forms[0].maxcreate.value;
 	var first = document.forms[0].first.value;
 	var sbsqnt = document.forms[0].sbsqnt.value;
 	var sbsqnt1 = document.forms[0].sbsqnt1.value;
 	var sbsqnt2 = document.forms[0].sbsqnt2.value;
 	var sbsqnt3 = document.forms[0].sbsqnt3.value;
 	var sbsqnt4 = document.forms[0].sbsqnt4.value;
 	var sbsqnt5 = document.forms[0].sbsqnt5.value;
	var showalert = false;
	var value = "";

    var msg  = "________________________________________________________\n\n";
    msg += getMessage('keysubsqnt'); 


	
	switch(parseInt(maxcreate))
	{
		case 0 :
			break;
		default :
			if ((!showalert) && (sbsqnt <= 0))
			{
				value = "";
				showalert = true;
			}
		case 6:
			if ((!showalert) && (sbsqnt5 <= 0))
			{
				value = "5";
				showalert = true;
			}
		case 5:
			if ((!showalert) && (sbsqnt4 <= 0))
			{
				value = "4";
				showalert = true;
			}
		case 4:
			if ((!showalert) && (sbsqnt3 <= 0))
			{
				value = "3";
				showalert = true;
			}
		case 3:
			if ((!showalert) && (sbsqnt2 <= 0))
			{
				value = "2";
				showalert = true;
			}
		case 2 :
			if ((!showalert) && (sbsqnt1 <= 0))
			{
				value = "1";
				showalert = true;
			}
		case 1 :
			if ((!showalert) && (first <= 0))
			{
				var msg  = "________________________________________________________\n\n";
			    	msg += getMessage('keyinitialoffset'); 
				value = "";
				showalert = true;
			}
			break;
	}
	
	if(showalert)
	{
		msg += " " + value + getMessage('keyshdgreat0') + "\n\n";
	    msg += "________________________________________________________\n\n";
	    ret=false;
	    alert(msg);
	    if (maxcreate == '1')
	    	document.forms[0].first.focus();
	    else
	    	eval("document.forms[0].sbsqnt" + value + ".focus()");
	}

 	if (ret)
 	{
         if(operation == 'add')
         {
             newrec(formname,operation);
         }
         else if(operation == 'update')
         {
             updaterec(formname,operation);
         }
 	}
 }


/*-------------------------------------------------------------
  *
  * Function     :  generateconfirm
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on Re-print Statement button.
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function generateconfirm(formname,operation)
  {
    var ret = false;

     statusMsg=getMessage('keyrecsgenwishcont');
     actionMsg=getMessage('keyapplyreprintfee');
     msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;
     
    ret = confirm(msg);
 
    if(ret)
    {
       document.forms[formname].applyFee.value = true;
    }else{
        document.forms[formname].applyFee.value = false;
    }
    enableDropdown();
    document.forms[formname].formAction.value = operation;
    document.forms[formname].submit();
  }

/*-------------------------------------------------------------
  *
  * Function     :  	
  *
  * Purpose      :  Confirmation Message is displayed on the screen
  *                 when user clicks on Re-print Statement button.
  *
  * Parameters   :
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/

  function openBirtReport(outpath,outfile,type)
  {
	    var url = "BirtReportViewer.jsp?" + outpath + outfile;

	    	 resWin = window.open(url, "BirtReport");
		     resWin.focus();
		
  }
  
/*-------------------------------------------------------------
  *
  * Function     :    copy_new_noteid  
  *
  * Purpose      :  Copies the value from dropdown to text field
  *  
  *
  * Parameters   :  form name
  *
  * Returns      :
  *
  * Comments     :
  *
  *-----------------------------------------------------------*/
function copy_new_noteid(obj,drumno)
{
    var newNoteId = obj.options[obj.selectedIndex].value;
    
    if(drumno=='1'){
    document.aatermatmdetailfrm.drum1noteid.value=newNoteId;
    }
    else if(drumno=='2'){
    document.aatermatmdetailfrm.drum2noteid.value=newNoteId;
    }
    else if(drumno=='3'){
    document.aatermatmdetailfrm.drum3noteid.value=newNoteId;
    }
    else if(drumno=='4'){
    document.aatermatmdetailfrm.drum4noteid.value=newNoteId;
    }
}

/*-------------------------------------------------------------
*
* Function     :    updatePanDisplay  
*
* Purpose      :  Copies the value from dropdown to text dropdown
*  
*
* Parameters   :  form name
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/
function updatePanDisplay(obj)
{
	var newNoteId = obj.selectedIndex;
	document.ccspostadjustmentdetailfrm.panDisplay.selectedIndex=newNoteId;
}  


/*-------------------------------------------------------------
*
* Function     :  updatePanFromPanDisplay  
*
* Purpose      :  Copies the value from dropdown to text dropdown
*  
*
* Parameters   :  form name
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/
function updatePanFromPanDisplay(obj)
{
	var newNoteId = obj.selectedIndex;
	document.ccspostadjustmentdetailfrm.cardnumber.selectedIndex=newNoteId;
}  

/*-------------------------------------------------------------
*
* Function     :  LinktoContactManagement
*
* Purpose      :  Directs to contact management screen
*
* Parameters   : 
*
* Returns      :
*
* Comments     : called from customer detail screen
*
*-----------------------------------------------------------*/

function LinktoContactManagement(customerCode, instCode, fromwhere, contextPath)
{
	var strContextPath = contextPath;
	var custCodeVal = customerCode.value;
	var instCodeVal = instCode.value;
	var fromwhereVal = fromwhere.value;
	redirectWithPostMethodUrl("/"+strContextPath +"/wicket/party/contactMechanism?customerCode="+custCodeVal+"&instCode="+instCodeVal+"&fromwhere="+fromwhereVal);
}

/*-------------------------------------------------------------
*
* Function     :  LinktoMediaContactManagement
*
* Purpose      :  Directs to media contact management screen
*
* Parameters   : 
*
* Returns      :
*
* Comments     : called from card maintenance screen
*
*-----------------------------------------------------------*/

function LinktoMediaContactManagement(customerCode, instCode, pan, seqno, fromwhere, contextPath)
{
	var strContextPath = contextPath;
	var custCodeVal = customerCode.value;
	var instCodeVal = instCode.value;
	var panVal = pan.value;
	var seqVal = seqno.value;
	var fromwhereVal = fromwhere.value;
	redirectWithPostMethodUrl("/"+strContextPath +"/wicket/media/contactMechanism?customerCode="+custCodeVal+"&instCode="+instCodeVal+"&pan="+panVal+"&seqno="+seqVal+"&fromwhere="+fromwhereVal);
}

/*-------------------------------------------------------------
*
* Function     :  validatedCardDeliveryInfo
*
* Purpose      :  Validates Card Delivery Information
*
* Parameters   : 
*
* Returns      :  boolean
*
* Comments     : called from card maintenance detail screen
*
*-----------------------------------------------------------*/
function validatedCardDeliveryInfo()
{
	if(document.forms[0].deliverInfoPresent != null)
	{
		if(document.forms[0].deliverInfoPresent.value == true)
		{
			return true;
		}
		else
		{
			var docType = document.forms[0].doc_type.value;
			var docNo = document.forms[0].doc_no.value;
			var personType = document.forms[0].person_type.value;
			var personName = document.forms[0].person_name.value;
			if ((docType != 0) && (docNo != null && Trim(docNo) != "") && (personType != 0) && (personName != null && Trim(personName) != ""))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	else
	{
		return true;
	}

}

/*-------------------------------------------------------------
*
* Function     :  updateCardDeliveryInfo
*
* Purpose      :  Updates Card Delivery Info if values are valid
*
* Parameters   : 
*
* Returns      :  
*
* Comments     : called from card maintenance detail screen, Delivery Information tab
*
*-----------------------------------------------------------*/
function updateCardDeliveryInfo(formname,operation)
{
	var validValue = validatedCardDeliveryInfo();
	if(validValue == true)
	{
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
	}
	else
	{
		alert(getMessage('keycrddelivinfomandatory'));
		return false;
	}
}

/*-------------------------------------------------------------
*
* Function     :  hideShowRateBasis
*
* Purpose      :  Show or Hide Rate Basis component on Add Payment Set screen
*
* Parameters   : 
*
* Returns      :  
*
* Comments     : called from card Add Payment Set screen
*
*-----------------------------------------------------------*/
function hideShowRateBasis()
{
	var elementInstChrgCalcMthd = document.getElementById('instchrgcalcmthd');
	if(elementInstChrgCalcMthd.value=='2' || elementInstChrgCalcMthd.value=='')
	{
	  var divTogglePercentage=document.getElementsByName("togglePercentage");	  
	   for(var i =0;i<divTogglePercentage.length;i++)
	   {
			divTogglePercentage[i].style.visibility="hidden";			
	   }
	   var rate_basisRow = document.getElementById('rate_basisRow');
	   rate_basisRow.style.visibility = 'hidden';
	   rate_basisRow.mandatory = 'false';
	   document.getElementById('rate_basis').value='Y';
	}
	else if(elementInstChrgCalcMthd.value=='1')
	{
	 var divTogglePercentage=document.getElementsByName("togglePercentage");	  
	   for(var i =0;i<divTogglePercentage.length;i++)
	   {
			divTogglePercentage[i].style.visibility="visible";		  
	   }
	   
	   var rate_basisRow = document.getElementById('rate_basisRow');
	   rate_basisRow.style.visibility = 'visible';
	   rate_basisRow.mandatory = 'true';	  
	   if(document.getElementById('rate_basis').value !='')
		   ;
	    else
		   document.getElementById('rate_basis').value='';
	}
	
}
/*-------------------------------------------------------------
*
* Function     :  updateRateBasis
*
* Purpose      :  Show or Hide Rate Basis component on Add/Edit Payment Set screen
*
* Parameters   : 
*
* Returns      :  
*
* Comments     : called from card Add/Edit Payment Set screen
*
*-----------------------------------------------------------*/
function updateRateBasis()
{
   hideShowRateBasis();
}


/*-------------------------------------------------------------
*
* Function     :  ZoomAddOverride
*
* Purpose      :  Used to popup the Add Override window
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/
function ZoomAddOverride()
{
    var ar = ZoomAddOverride.arguments;
    var parentFormName = ar[0];
    var screenName = ar[1];
    var formAction = ar[2]
    var fromwhere = ar[3];
    var resultsIndex = ar[4];
    var dec = screenName.indexOf(".");
    if(dec > 0)
    {
        screenName =  screenName.substring(0,dec);
    }
    
    var params;
    var popup="1"; 
    var token_key = document.getElementsByName("TOKEN_KEY")[0].value;
   	if((token_key !='') ? params = "parentFormName=" + parentFormName + "&formAction=" + formAction + "&fromwhere=" + fromwhere + "&resultsIndex=" +resultsIndex+"&fromPopup="+popup+"&TOKEN_KEY="+token_key : params = "parentFormName=" + parentFormName + "&formAction=" + formAction + "&fromwhere=" + fromwhere + "&resultsIndex=" +resultsIndex+"&fromPopup="+popup);
   
    screenZoomWin = openWindowWithPostMethod(ar[1], screenName, params, "toolbar=no,location=no," +
    		"directories=no,status=yes,menubar=no,scrollbars=yes," + "resizable=no,width=600,height=400")
    screenZoomWin.name = screenName;
}

/*-------------------------------------------------------------
*
* Function     :  doOverride
*
* Purpose      :  Submit the Override operation
*
* Parameters   :
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/
function doOverride(formname,operation)
{
    var ret = false;

    if (checkForm(document.forms[0]))
    {

         statusMsg=getMessage('keyrecsaddwishcont');
         actionMsg=getMessage('keydoyouwancontinue');
         msg = "___________________________________________________" +
         "\n\n" + statusMsg + "\n" +
         "___________________________________________________" +
         "\n\n" + actionMsg;
      ret = confirm(msg);
     }
    if(ret) {
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }

}

/*-------------------------------------------------------------
*
* Function     :  refreshParentScreen
*
* Purpose      :  To close the popup window and repopulate the parent window
*
* Parameters   :
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/
function refreshParentScreen(operation) {
	if(document.forms[0].toParent.value == "true"){
		window.opener.document.forms[0].formAction.value = operation;
		window.opener.document.forms[0].submit();
    	window.close();
	}
}

/*-------------------------------------------------------------
*
* Function     :  zoomSelectdesc
*
* Purpose      :  Used to populate the parent field with the selected value
*
* Parameters   :  formname Variable that holds the parent form name.
*              :  textboxname Variable that holds the parent text box name.
*              :  var1 Variable that holds the data value.
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/
function zoomSelectdesc(parentformname,textboxname1,var1)
{
    var parentTextBox1 = eval("window.opener.document."+parentformname+"."+textboxname1);
    parentTextBox1.value = var1;   
    window.close();
}
/*-------------------------------------------------------------
*
* Function     :  zoomSearchdesc
*
* Purpose      :  Used to populate the parent field with the selected value
*
* Parameters   :  Parent form name
*                 Destinantion JSP name
*                 With of the new screen
*                 Height of the new screen
*                 number of information fields
*                 Parent form information field names
*                 Parent form field names to be populated
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/
function zoomSearchdesc(parentformname,textboxname1,jspname)
{
   ZoomPanScreenSearch(parentformname,textboxname1,jspname);
}

/*-------------------------------------------------------------
*
* Function     :  restrictValueMaxLength
*
* Purpose      :  Textarea field doesn't support maxlength. Instead this function is used to restrict value max size 
*
* Parameters   :
*
* Returns      :
*
* Comments     : Newline is counted as two characters.
*
*-----------------------------------------------------------*/

function restrictValueMaxLength(obj, maxLength) {
	var textLength = obj.value.length + obj.value.replace(/\r/g,'').split('\n').length - 1;

	if(textLength > maxLength) {
		obj.value = obj.value.substr(0, (maxLength - obj.value.replace(/\r/g,'').split('\n').length + 1)); 
	}
}

function rePrintPinsPinTypes(requestScheme,serverName,serverPort,contextPath,formname,formaction,keymsg,crdproduct,lang)
{
	var form = document.forms[formname];	
	var url= requestScheme+'://'+serverName+':'+serverPort+contextPath+'/iaajaxreprintaction.do?crdproduct='+crdproduct+'&lang='+lang;
	
	var request = null;
	var multiReprinPinType;
	enableDropdown();
	if(window.XMLHttpRequest) 
	{
		request = new XMLHttpRequest();
	} 
	else if(window.ActiveXObject) 
	{
		request = new ActiveXObject("Microsoft.XMLHTTP");
	}
	if(request)
	{
		 request.open("GET",url,false);
		 request.send(null);
		 multiReprinPinType = request.responseText;
	}
	else
	{
	    alert("Browser is not compatible");
	}
	if(multiReprinPinType == "true")
	{
		var params = 'crdproduct='+crdproduct+'&parnetformaction='+formaction;
		openWindowWithPostMethod("iareprintsmultipintypeson.do", "reprintsmultipintypeson", params, 
				"toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=no,width=700,height=250")
	}
	else
	{
		GenericSubmitConfirmation(formname,formaction,keymsg);
	}
}

function rePrintsMultiPinsId(formname)
{
	var form = document.forms[formname];
	var Ids = "";
	for (i = 0; i < form.chkPinType.length; i++)
	{
	     if (form.chkPinType[i].checked)
	     {
			 if(i==0)
			 {
				Ids = form.chkPinType[i].value;
			 }
			 else
			 {
				if(Ids.length > 0)
				{
					Ids = Ids + ",";
				}
	    		Ids = Ids + form.chkPinType[i].value;
			 }
	     }
	}
	var reprintsMultiPins = window.opener.document.getElementsByName('reprintsMultiPins')[0];
	reprintsMultiPins.value = Ids;
	var parentform = window.opener.document.forms['iacrddetdetailfrm'];
	var crddetId = parentform.id.value;
	var batch = parentform.batch.value;
	var params = 'crddetId='+crddetId+'&cardBatch='+batch+'&eventType=5';
	openWindowWithPostMethod("iafeewaivingon.do", "iafeewaivingon", params, 
			"toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes, resizable=no,width=700,height=250")
}

function enableDisableButton(formname)
{
	var check = true;
	var form = document.forms[formname];
	var reprintsselectpins = form.reprintsselectpins;
	for (i = 0; i < form.chkPinType.length; i++)
	{
	    if (form.chkPinType[i].checked)
		{
			check = false;
		}
	}
	reprintsselectpins.disabled = check;
}

function feeWaivingWindow(eventType)
{
	var cardform = window.document.forms['iacrddetdetailfrm'];
	var crddetId = cardform.id.value;
	var batch = document.getElementById('batch').value;
	var params = 'crddetId='+crddetId+'&cardBatch='+batch+'&eventType='+eventType;
	openWindowWithPostMethod("iafeewaivingon.do", "iafeewaivingon", params, 
			"toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=no,width=700,height=250")
}

function feeWaivingParentFormSubmit()
{
	var formname = 'iacrddetdetailfrm';
	var keymsg;
	var formaction;
	if(document.getElementsByName("closeWin")[0].value == "true")
	{
		if(document.getElementsByName("eventType")[0].value == "3")
		{
			keymsg = 'keyreplace';
			formaction = 'replace';
		}
		else if(document.getElementsByName("eventType")[0].value == "4")
		{
			keymsg = 'keyreissue';
			formaction = 'reissue';
		}
		else if(document.getElementsByName("eventType")[0].value == "5")
		{
			keymsg = 'keyreprint';
			formaction = 'reprint';
		}
		
		if(document.getElementsByName("eventType")[0].value == "3" || document.getElementsByName("eventType")[0].value == "4")
		{
			window.opener.enableDropdown();
			var msg=window.opener.getMessage(keymsg);
			var form = window.opener.document.forms[formname];
			form.feeWaivingEventReason.value = document.getElementById("eventReason").value;
			form.feeWaivingEventNotes.value = document.getElementById("eventNotes").value;
			form.feeWaivingFeeControl.value = document.getElementsByName("feeControlvalue")[0].value;
			if(document.getElementsByName("eventType")[0].value == "3")
			{
				form.feeWaivingEventType.value = 3;
			}
			else
			{
				form.feeWaivingEventType.value = 4;
			}
			var ret = confirm(msg);
			if(ret)
			{
				 form.formAction.value=formaction;
				 form.submit();
			}
		}
		else if(document.getElementsByName("eventType")[0].value == "5")
		{
			var msg=window.opener.opener.getMessage(keymsg);
			var parentform = window.opener.opener.document.forms[formname];
			parentform.feeWaivingEventReason.value = document.getElementById("eventReason").value;
			parentform.feeWaivingEventNotes.value = document.getElementById("eventNotes").value;
			parentform.feeWaivingFeeControl.value = document.getElementsByName("feeControlvalue")[0].value;
			parentform.feeWaivingEventType.value = 5;
		    var ret = confirm(msg);
		    if(ret)
		    {
		    	 window.opener.opener.document.getElementsByName('formAction')[0].value='reprint';
		    	 parentform.formAction.value='reprint';
		    	 parentform.submit();
		    }
		    window.opener.close();
		}
		window.close();
	}
}


/*-------------------------------------------------------------
*
* Function     :  populateCustUsrgrpValues
*
* Purpose      :  Populate all values in page when option from dropdown is selected 
*
* Parameters   :
*
* Returns      :
*
* Comments     : Used to populate with customer specific values
*
*-----------------------------------------------------------*/
function populateCustUsrgrpValues(obj) {
	var optValue = obj.options[obj.selectedIndex].value;
	optValue = optValue.replace(/\ /g,'_');

	var groupIdObj = eval("document.usrgrpdescrfrm.groupid_"+optValue);
	if (groupIdObj) {
		var groupId = groupIdObj.value;
		var descr = eval("document.usrgrpdescrfrm.descr_"+optValue+".value");
		var taskDescr = eval("document.usrgrpdescrfrm.taskdescr_"+optValue+".value");
		var demanderName = eval("document.usrgrpdescrfrm.demandername_"+optValue+".value");
		var delReason = eval("document.usrgrpdescrfrm.delreason_"+optValue+".value");
		var replacedGroup = eval("document.usrgrpdescrfrm.replacedgroup_"+optValue+".value");

		document.usrgrpdescrfrm.groupid.value=groupId;
		document.usrgrpdescrfrm.descr.value=descr;
		document.usrgrpdescrfrm.taskdescr.value=taskDescr;
		document.usrgrpdescrfrm.demandername.value=demanderName;
		document.usrgrpdescrfrm.delreason.value=delReason;
		document.usrgrpdescrfrm.replacedgroup.value=replacedGroup;
	}
}

/*-------------------------------------------------------------
*
* Function     :  convertBytesToHumanReadableFormat
*
* Purpose      :  Convert size in bytes to human readable size 
*
* Parameters   :
*
* Returns      :
*
* Comments     : 
*
*-----------------------------------------------------------*/
function convertBytesToHumanReadableFormat(sizeInBytes) {
	var i = -1;
    var byteUnits = [' kB', ' MB', ' GB', ' TB', 'PB', 'EB', 'ZB', 'YB'];
    do {
        sizeInBytes = sizeInBytes / 1024;
        i++;
    } while (sizeInBytes > 1024);

    return Math.max(sizeInBytes, 0).toFixed(1) + byteUnits[i];
}


/*-------------------------------------------------------------
*
* Function     :  checkMandatoryField
*
* Purpose      :  Displays message if mandatory field is not filled 
*
* Parameters   :
*
* Returns      :
*
* Comments     : 
*
*-----------------------------------------------------------*/
function checkMandatoryField(field) {
	var fldValue = document.forms[0].elements[field].value;
	if (Trim(fldValue) == "") {
		var errMsg = "\"" + label[field] + "\""+ getMessage('keyismandatory');
	    alertErr(errMsg);

        // Reset to the init variable
	    document.forms[0].elements[field].value = defVal[field];
        return false;
	}
	return true;
}
/*-------------------------------------------------------------
*
* Function     :  updateCheckboxStatusInString
*
* Purpose      :  Updates checkbox status with '0' or '1' in a string value 
*
* Parameters   :  stringValName  name of form element which holds string value with all checkbox statuses
*              :  position  position in string for current checkbox status
*              :  chbox  checkbox object
*
* Returns      :
*
* Comments     : 
*
*-----------------------------------------------------------*/
function updateCheckboxStatusInString(stringValName, position, chbox) {
	checkboxValue = "0";
	if (chbox.checked == true) {
		checkboxValue = "1";
	}
	stringVal = document.getElementsByName(stringValName)[0].value;
	stringVal = stringVal.substring(0, position) + checkboxValue + stringVal.substring(position + 1);
	document.getElementsByName(stringValName)[0].value = stringVal;
}
/*-------------------------------------------------------------
*
* Function     :  To Go Back To Previous Screen
*
* Purpose      :  On Clicking on 'BACK' button user taken back to previous page without checking changes of page 
*
* Parameters   :
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/

function isbackWithoutAlert()
{
   var ar = isbackWithoutAlert.arguments;
   var ret = false;
   var str = ar[0];
   var param_add = ar[0].indexOf("?")==-1 ? "?": "&";
	
   // force conversion of element names to key1..keyn after unmasking
   str = str + param_add + "namesToKeys=true";
	
   // add the formAcsitem
   str = str + "&formAcsitem=" + document.forms[0].formAcsitem.value;
   
   for(i=1;i<ar.length;i++)
   {
   	if(!ar[i].name)
   	{
   		// we have a string
       	str = str + ("&key" + i) + "=" + encodeURIComponent(ar[i]);
       }
       else
       {
       	// we have an element
       	str = str + "&" + ar[i].name + "=" + encodeURIComponent(ar[i].value);
       }
    }
   redirectWithPostMethodUrl(str);
}

/*-------------------------------------------------------------
*
* Function     :  Confirmation On Update
*
* Purpose      :  Confirmation Message is displayed on the screen
*                 when user clicks on update.
*
* Parameters   :
*
* Returns      :
*
* Comments     :
*
*-----------------------------------------------------------*/

function updaterecNoDirtyCheckNoDropdown(formname,operation)
{
  var ret = false; 

  if (checkForm(document.forms[0]))
  {
   statusMsg=getMessage('keyrecsupdwishcont');
   actionMsg=getMessage('keydoyouwancontinue');
   msg = "___________________________________________________" +
       "\n\n" + statusMsg + "\n" +
       "___________________________________________________" +
       "\n\n" + actionMsg;

   ret = confirm(msg);

   }
  if(ret)
     {
      document.forms[formname].formAction.value = operation;
      document.forms[formname].submit();
     }
}

function panVirtualPanCheck()
{
	for(i = 0; elem = document.getElementById(names[i]); i++)
    {
    	if(elem.name == "virtualPan")
        {
        	virtualPanValue = elem.value;
        }
    	
        if(elem.name == "pan")
        {
        	panValue = elem.value;
        } 
    }
	var tPan = Trim(panValue);
	var tVirtualPan = Trim(virtualPanValue);
    if (!((tPan == "" && tVirtualPan != "") || (tPan != "" && tVirtualPan == ""))) {
	    errMsg = getMessage('keypanorvpan');
	    alertErr(errMsg);
	    return false;
	}
	return true;
}
/*-------------------------------------------------------------
*
* Function     :  enablePriorityField
*
* Purpose      : set priorities in the  url 
*
* Parameters   : 
*
* Returns      :  
*
* Comments     : called from  Card/Accunt Relationship search screen
*
*-----------------------------------------------------------*/
function enablePriorityFields(formname)
{
   var checkBoxes=document.getElementsByName("radio");
   
   if(checkBoxes.length>1)
   {
       for(var i=0;i<checkBoxes.length;i++)
       { 
	      if(document.forms[formname].radio[i].checked && document.forms[formname].isLinked[i].value=='N')
		  {
		    document.forms[formname].priority[i].disabled=false;
		    document.forms[formname].priority[i].value=1;
		  }
		  else if(document.forms[formname].radio[i].checked && document.forms[formname].isLinked[i].value=='Y')
		  {
		    // do nothing
		  }
		  else if(document.forms[formname].isLinked[i].value!='Y')
		  {
		    document.forms[formname].priority[i].value=0;
			document.forms[formname].priority[i].disabled=true;
		  }	  
	   
	   }   
   }else{
          if(document.forms[formname].radio.checked && document.forms[formname].isLinked.value=='N')
		  {
		    document.forms[formname].priority.disabled=false;
		    document.forms[formname].priority.value=1;
		  }
		  else if(document.forms[formname].radio.checked && document.forms[formname].isLinked.value=='Y')
		  {
		    // do nothing
		  }
		  else if(document.forms[formname].isLinked.value!='Y')
		  {
		    document.forms[formname].priority.value=0;
			document.forms[formname].priority.disabled=true;
		  }	
   
   }
 }
/*-------------------------------------------------------------
*
* Function     :  function Called  from modify_onClickLinkAccount
*
* Purpose      :  gets the count of the records selected
*
*
* Parameters   :
*
* Returns      :   int
*
* Comments     :   used for batch
*
*-----------------------------------------------------------*/

function getCountLinkAccount()
{
   var len = document.forms[0].radio.length;
   var count = 0;
   if(len)
   {
	    for(i=0;i<len;i++)
	    {
			if(document.forms[0].radio[i].checked == true||document.forms[0].oldPriority[i].value !=document.forms[0].priority[i].value)
			 count++;
			
	    }
   }else{
	    if(document.forms[0].radio.checked == true||document.forms[0].oldPriority[i].value !=document.forms[0].priority[i].value)
	    count++;
   }

  return count;
}
/*-------------------------------------------------------------
*
* Function     :  function Called  from updatelinkaccount
*
* Purpose      :  Confirmation Message is displayed on the screen
*                 when user clicks update Card/Account button.
*
* Parameters   :
*
* Returns      :
*
* Comments     :   used for batch
*
*-----------------------------------------------------------*/

function modify_onClickLinkAccount()
{
 var len = document.forms[0].elements.length;
 var count = getCountLinkAccount();
 if((count ==0))
 {
    msg=getMessage('keycheckdelete');
    alertErr(msg);

       return false;
 }
 else
 return true;

}

/*-------------------------------------------------------------
*
* Function     :  function forwardDisplayPage
*
* Purpose      :  the purpose of this function is to set the parameters in post request
*
* Parameters   :
*
* Returns      :
*
* Comments     :   used for Account Maintenance screen for PostAdjustments,unload account, view items and Account limit
*
*-----------------------------------------------------------*/
function forwardDisplayPage(){
	  var paramsArray =forwardDisplayPage.arguments;  
	  var formaction = paramsArray[0];  
	  var processAction=paramsArray[1];
	  var formAcsitem=paramsArray[2];
	  var keyIndex=0;
	  var form = document.createElement("form");
	  form.setAttribute("method", "post");
	  form.setAttribute("action", formaction);
	  for(keyIndex=3;keyIndex<paramsArray.length;keyIndex++){     
	    var dynamicFormHiddenField = document.createElement("input");
		dynamicFormHiddenField.setAttribute("type", "hidden");
		dynamicFormHiddenField.setAttribute("name","key"+(keyIndex-2));
		if(paramsArray[keyIndex].name)
		{
	       dynamicFormHiddenField.setAttribute("value",paramsArray[keyIndex].value);
	    }
		else
		{	
	     
		  dynamicFormHiddenField.setAttribute("value",paramsArray[keyIndex]);
		}
		form.appendChild(dynamicFormHiddenField);
	 }
	  var formActionField= document.createElement("input");
	  formActionField.setAttribute("type", "hidden");
	  formActionField.setAttribute("name","formAction");
	  formActionField.setAttribute("value",processAction);
	  form.appendChild(formActionField);
	  var formAcsitemField= document.createElement("input");
	  formAcsitemField.setAttribute("type", "hidden");
	  formAcsitemField.setAttribute("name","formAcsitem");
	  formAcsitemField.setAttribute("value",formAcsitem);
	  form.appendChild(formAcsitemField);
	  document.body.appendChild(form);
	  form.submit();
	  
	}
	
function enableKeyLengthsByKeyType(keyTypeElementId, encrTypeElementId, setDefault, useKeyBlocks){
	var keyType = jQuery("#" + keyTypeElementId).val();
	if(keyType == null || keyType == ""){
		jQuery("#" + encrTypeElementId + " option[value='16']").removeAttr('disabled');
		jQuery("#" + encrTypeElementId + " option[value='32']").removeAttr('disabled');
		jQuery("#" + encrTypeElementId + " option[value='48']").removeAttr('disabled');
	}
	else if(keyType == 1 || keyType == 22 || keyType == 23){
		jQuery("#" + encrTypeElementId + " option[value='16']").attr('disabled', 'disabled');
		jQuery("#" + encrTypeElementId + " option[value='32']").removeAttr('disabled');
		if(setDefault){
			jQuery("#" + encrTypeElementId + " option[value='48']").removeAttr('disabled').attr('selected','selected');
		}
	}
	else if(keyType == 6 || keyType == 7 || keyType == 16 
			|| keyType == 17 || keyType == 18 || keyType == 20){
		jQuery("#" + encrTypeElementId + " option[value='16']").removeAttr('disabled');
		jQuery("#" + encrTypeElementId + " option[value='48']").attr('disabled', 'disabled');
		if(setDefault){
			jQuery("#" + encrTypeElementId + " option[value='32']").removeAttr('disabled').attr('selected','selected');
		}
	}
	else{
		jQuery("#" + encrTypeElementId + " option[value='16']").attr('disabled', 'disabled');
		jQuery("#" + encrTypeElementId + " option[value='48']").attr('disabled', 'disabled');
		if(setDefault){
			jQuery("#" + encrTypeElementId + " option[value='32']").removeAttr('disabled').attr('selected','selected');
		}
	}
	if(useKeyBlocks) {
		jQuery("#" + encrTypeElementId + " option[value='16']").attr('disabled', 'disabled');
	}
}

function enableKBHKeyLengthsByKeyType(keyTypeElementId, encrTypeElementId, setDefault){
	var keyType = jQuery("#" + keyTypeElementId).val();
	if(keyType == null || keyType == ""){
		jQuery("#" + encrTypeElementId + " option[value='57']").removeAttr('disabled');
		jQuery("#" + encrTypeElementId + " option[value='73']").removeAttr('disabled');
		jQuery("#" + encrTypeElementId + " option[value='89']").removeAttr('disabled');
	}
	else if(keyType == 1 || keyType == 22 || keyType == 23){
		jQuery("#" + encrTypeElementId + " option[value='57']").attr('disabled', 'disabled');
		jQuery("#" + encrTypeElementId + " option[value='73']").removeAttr('disabled');
		if(setDefault){
			jQuery("#" + encrTypeElementId + " option[value='89']").removeAttr('disabled').attr('selected','selected');
		}
	}
	else if(keyType == 6 || keyType == 7 || keyType == 16 
			|| keyType == 17 || keyType == 18 || keyType == 20){
		jQuery("#" + encrTypeElementId + " option[value='73']").attr('disabled', 'disabled');
		jQuery("#" + encrTypeElementId + " option[value='89']").attr('disabled', 'disabled');
		if(setDefault){
			jQuery("#" + encrTypeElementId + " option[value='57']").removeAttr('disabled').attr('selected','selected');
		}
	}
	else{
		jQuery("#" + encrTypeElementId + " option[value='57']").attr('disabled', 'disabled');
		jQuery("#" + encrTypeElementId + " option[value='89']").attr('disabled', 'disabled');
		if(setDefault){
			jQuery("#" + encrTypeElementId + " option[value='73']").removeAttr('disabled').attr('selected','selected');
		}
	}
}
	

function isCashbackEligible(){
	var arr = ['4853', '4854', '4855', '4860','4859'];
	var reason = jQuery('#reason').val();
	if(document.getElementById('strAmttxncb').disabled ==false){
		// not disabled
		if(jQuery.inArray(reason, arr) != -1 ){
			// invalid reason code
			jQuery('#strAmttxncb').data('val',jQuery('#strAmttxncb').val() );
			jQuery('#strAmttxncb').val('0');
			jQuery('#strAmttxncb').attr('disabled', 'disabled');
		}
	}else{
		// disabled
		if(jQuery.inArray(reason, arr) == -1 ){
			// valid
			jQuery('#strAmttxncb').removeAttr('disabled');
			var prev = jQuery('#strAmttxncb').data('val');
			jQuery('#strAmttxncb').val(prev);
		}

	}
}

/*-------------------------------------------------------------
*
* Function     :  function rePopulateFormOnInstitutionChange
*
* Purpose      :  the purpose of this function is to set the reload the page on institution change
*
* Parameters   :
*
* Returns      :
*
* Comments     :   used for ATM Maintenance
*
*-----------------------------------------------------------*/
function rePopulateFormOnInstitutionChange(arg1)
{
    if (rePopulateForm.arguments.length <= 0)
    {
        document.forms[0].formAction.value='repopulateinst';
        document.forms[0].submit();
    }
    else
    {
        var varcurr = document.forms[0].elements[arg1].value;
        
        if(Trim(varcurr) != '')
        {
            document.forms[0].formAction.value='repopulateinst';
            document.forms[0].submit();
        }
    }
 }

function emvPrfileSearchWindow() {
	var varChildWin = ""
	window.open("emvprofilesearchon.do", "Emv Profile Search", "toolbar=no,location=no," +
	                                    "directories=no,status=yes,menubar=no,scrollbars=yes," +
	                                    "resizable=no,width=800,height=600");
}

function changeCrdProductEmvProfileId(profileId) {
	window.opener.document.iacrdproductdetailfrm.emvProfileId.value = profileId;
	window.opener.document.iacrdproductdetailfrm.formAction.value='repopulateone';
	window.opener.document.iacrdproductdetailfrm.submit();
	window.close();
}

function partialChrBckChk()
{
	document.forms[0].partialChrBck.value='';
	if(confirm("Is this partial charge back")){
		document.forms[0].partialChrBck.value='P';
	} 
}

function keyblkhdrSrchWindowForShtDescr()
{
	var ar = keyblkhdrSrchWindowForShtDescr.arguments;
	var keyType=eval("document."+ar[0]+"."+ar[1]+".value");
	if((null != keyType) && (Trim(keyType) != "") && (-1 != keyType)) {
		ZoomSearchKeyBlockHeader(ar[0], keyType, ar);
	} else {
		alert(getMessage('keytypenotselected'));
		return false;
	}
	return true;
}

function keyblkhdrSearchWindow()
{
	var ar = keyblkhdrSearchWindow.arguments;
	var formName = document.getElementsByName(ar[0])[0].value;
	var keyTypeProp = document.getElementsByName(ar[1])[0].value;
	var keyType=eval("document."+formName+"."+keyTypeProp+".value");
	if((null != keyType) && (Trim(keyType) != "") && (-1 != keyType)) {
		ZoomSearchKeyBlockHeader(formName, keyType, ar);
	} else {
		alert(getMessage('keytypenotselected'));
		return false;
	}
	return true;
}

function ZoomSearchKeyBlockHeader(parentformname, keyType, ar)
{
    var screenName = ar[ar.length-1];
    var dec = screenName.indexOf(".");
    if(dec > 0)
    {
        screenName =  screenName.substring(0,dec);
    }
    var params = "parentFormName="+parentformname+"&keyType="+keyType;
    for(i=2;i<ar.length-1;i++) {
    	params = params + ("&parentTextBoxName" + (i-1)) + "=" + ar[i];
    }
    
    stateZoomWin = openWindowWithPostMethod(ar[ar.length-1], screenName, params, "toolbar=no,location=no," +
            "directories=no,status=yes,menubar=no,scrollbars=yes," + "resizable=no,width=800,height=400");
    stateZoomWin.name = screenName;
}

function ZoomKeyBlockHeaderSelect(parentformname,textboxname1,textboxname2,textboxname3,textboxname4,textboxname5,textboxname6,textboxname7,textboxname8,textboxname9,textboxname10,textboxname11,textboxname12,var1,var2,var3,var4,var5,var6,var7,var8,var9,var10,var11,var12)
{
    var parentTextBox1 = eval("window.opener.document."+parentformname+"."+textboxname1);
    parentTextBox1.value = Trim(var1);
    var parentTextBox2 = eval("window.opener.document."+parentformname+"."+textboxname2);
    parentTextBox2.value = Trim(var2);
    var parentTextBox3 = eval("window.opener.document."+parentformname+"."+textboxname3);
    parentTextBox3.value = Trim(var3);
    var parentTextBox4 = eval("window.opener.document."+parentformname+"."+textboxname4);
    parentTextBox4.value = Trim(var4);
    var parentTextBox5 = eval("window.opener.document."+parentformname+"."+textboxname5);
    parentTextBox5.value = Trim(var5);
    var parentTextBox6 = eval("window.opener.document."+parentformname+"."+textboxname6);
    parentTextBox6.value = Trim(var6);
    var parentTextBox7 = eval("window.opener.document."+parentformname+"."+textboxname7);
    parentTextBox7.value = Trim(var7);
    var parentTextBox8 = eval("window.opener.document."+parentformname+"."+textboxname8);
    parentTextBox8.value = Trim(var8);
    var parentTextBox9 = eval("window.opener.document."+parentformname+"."+textboxname9);
    parentTextBox9.value = Trim(var9);
    var parentTextBox10 = eval("window.opener.document."+parentformname+"."+textboxname10);
    parentTextBox10.value = Trim(var10);
    var parentTextBox11 = eval("window.opener.document."+parentformname+"."+textboxname11);
    parentTextBox11.value = Trim(var11);
    var parentTextBox12 = eval("window.opener.document."+parentformname+"."+textboxname12);
    parentTextBox12.value = Trim(var12);
    window.close();
}

function ZoomKeyBlockHeaderSelectShtDescr(parentformname,textboxname1,var1)
{
    var parentTextBox1 = eval("window.opener.document."+parentformname+"."+textboxname1);
    parentTextBox1.value = Trim(var1);
    window.close();
}

function resetKeyBlkhdrOnChangeKeyType(keyTypeProp) {
	var keyType=document.getElementsByName(keyTypeProp)[0].value;
	var keyBlkHdrKeyType = document.forms[0].KBHKeyType.value;
	if(keyBlkHdrKeyType != null && (keyType != keyBlkHdrKeyType)) {
		document.forms[0].keyblkhdrId.value = null;
		document.forms[0].KBHKeyType.value = null;
		document.forms[0].KBHShortDescr.value = null;
		document.forms[0].KBHKeyTypeDescr.value = null;
		document.forms[0].KBHTemplateTypeDescr.value = null;
		document.forms[0].KBHSchemeTagDescr.value = null;
		document.forms[0].KBHVersionIdDescr.value = null;
		document.forms[0].KBHAlgorithmDescr.value = null;
		document.forms[0].KBHModeOfUseDescr.value = null;
		document.forms[0].KBHKeyVersionNumber.value = null;
		document.forms[0].KBHExportabilityDescr.value = null;
		document.forms[0].KBHLmkId.value = null;
	}

}

function displaySecondCVKPVK(keyLengthProp, cvkPvkFlag) {
	var keyLength = document.getElementsByName(keyLengthProp)[0].value;
	if(keyLength == 16) {
		if(cvkPvkFlag == 1) {
			document.forms[0].secondCVK.disabled = false;
			document.forms[0].secondCVK.readonly = false;
		} else {
			document.forms[0].secondPVK.disabled = false;
			document.forms[0].secondPVK.readonly = false;
		}
	} else if (keyLength == 32) {
		if(cvkPvkFlag == 1) {
			document.forms[0].secondCVK.disabled = true;
			document.forms[0].secondCVK.readonly = true;
			document.forms[0].secondCVK.value = "";
		} else {
			document.forms[0].secondPVK.disabled = true;
			document.forms[0].secondPVK.readonly = true;
			document.forms[0].secondPVK.value = "";
		}
	}
}

function openWindowWithPostMethod(url, screenName, params, windowOptions) {
    var form = document.createElement('form');
    form.setAttribute("method", "post");
    form.setAttribute("action", url);
    form.setAttribute("target", screenName);
    params = params.split("&");
    for(var key=0; key<params.length; key++) {
        var sa = params[key];
        sa = sa.split("=");
        var xs = (sa[1]);
        if(params.hasOwnProperty(key)) {
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", sa[0]);
            hiddenField.setAttribute("value",xs);
            form.appendChild(hiddenField);
         }
    }
    
    var fromPopup= document.createElement("input");
	fromPopup.setAttribute("type", "hidden");
	fromPopup.setAttribute("name","fromPopup");
	fromPopup.setAttribute("value","1");
	form.appendChild(fromPopup);
	
    document.body.appendChild(form);
    var popWin = window.open('', screenName, windowOptions);
    form.target = screenName;
    form.submit();
    document.body.removeChild(form);
    return popWin;
}

function redirectWithPostMethodUrl(str) {
	redirectWithPostMethod(str.indexOf("?") >0 ? str.substring(0, str.indexOf("?")) : str, str.indexOf("?") >0 ? str.substring(str.indexOf("?")+1) : "");
}

function redirectWithPostMethod(redirectPage, params) {	
	params = params.indexOf("?") >= 0 ? params.substring(params.indexOf("?")+1) : params;
	var form = document.createElement('form');
    form.setAttribute("method", "post");
    form.setAttribute("action", redirectPage);
	form.setAttribute("display", "none");
	if(params.length > 0) {
		if(params.indexOf("namesToKeys") > 0) {
			params = params.split("&");
			for(var key=0; key<params.length; key++) {
				var sa = params[key];
				sa = sa.split("=");
				var xs = (sa[1]);
				if(params.hasOwnProperty(key) && sa[0] == "namesToKeys") {
					var hiddenField = document.createElement("input");
					hiddenField.setAttribute("type", "hidden");
					hiddenField.setAttribute("name", sa[0]);
					hiddenField.setAttribute("value",xs);
					form.appendChild(hiddenField);
				 }
			}
			var hiddenField = document.createElement("input");
			hiddenField.setAttribute("type", "hidden");
			hiddenField.setAttribute("name", "redirectPostMethodParams");
			hiddenField.setAttribute("value",params);
			form.appendChild(hiddenField);
		} else {
			params = params.split("&");
			for(var key=0; key<params.length; key++) {
				var sa = params[key];
				sa = sa.split("=");
				var xs = (sa[1]);
				if(params.hasOwnProperty(key)) {
					var hiddenField = document.createElement("input");
					hiddenField.setAttribute("type", "hidden");
					hiddenField.setAttribute("name", sa[0]);
					hiddenField.setAttribute("value",xs);
					form.appendChild(hiddenField);
				 }
			}
		}
	}
    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);
}

//--------------------------------------------BRE CUSTOM--------------------------------------------//
function isCashbackEligible(){
	var arr = ['4853', '4854', '4855', '4860','4859'];
	var reason = jQuery('#reason').val();
	if(document.getElementById('strAmttxncb').disabled ==false){
		// not disabled
		if(jQuery.inArray(reason, arr) != -1 ){
			// invalid reason code
			jQuery('#strAmttxncb').data('val',jQuery('#strAmttxncb').val() );
			jQuery('#strAmttxncb').val('0');
			jQuery('#strAmttxncb').attr('disabled', 'disabled');
		}
	}else{
		// disabled
		if(jQuery.inArray(reason, arr) == -1 ){
			// valid
			jQuery('#strAmttxncb').removeAttr('disabled');
			var prev = jQuery('#strAmttxncb').data('val');
			jQuery('#strAmttxncb').val(prev);
		}

	}
}

function partialChrBckChk()
{
	document.forms[0].partialChrBck.value='';
	if(confirm("Is this partial charge back")){
		document.forms[0].partialChrBck.value='P';
	} 
}

/*-------------------------------------------------------------
 *
 * Function     :  Confirmation On Unlink
 *
 * Purpose      :  Confirmation Message is displayed on the screen
 *                 when user clicks on Unlink.
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *-----------------------------------------------------------*/

 function unlinkrec(formname, operation)
 {
    statusMsg=getMessage('keyrecsunlinkwishcont');
    actionMsg=getMessage('keydoyouwancontinue');
    msg = "___________________________________________________" +
        "\n\n" + statusMsg + "\n" +
        "___________________________________________________" +
        "\n\n" + actionMsg;
    if(confirm(msg))
    {
        enableDropdown();
        document.forms[formname].formAction.value = operation;
        document.forms[formname].submit();
    }
    else
        return false;
 }
 