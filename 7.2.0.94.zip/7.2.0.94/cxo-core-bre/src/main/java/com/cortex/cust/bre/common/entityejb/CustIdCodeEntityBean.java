/*
 *  Entity bean for Cust_idcode table
 *
 *  ORACLE entity bean
 *     (to be used only with an Oracle database)
 */

package com.cortex.cust.bre.common.entityejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.sql.DataSource;

import com.cortex.common.constant.globalConstant;
import com.cortex.common.exception.ServiceLocatorException;
import com.cortex.common.exception.serverException;
import com.cortex.common.interfaces.IResultInfo;
import com.cortex.common.lib.FunctionLib;
import com.cortex.common.lib.ServiceLocator;
import com.cortex.common.lib.debugLib;
import com.cortex.common.valueobj.ResultInfo;
import com.cortex.gui.common.lib.CommonGlobalFunctions;

/*
 * COLUMNS OF THE Cust_idcode TABLE (Oracle schema)
 *
 *
 *  Col name             Type           Size
 *  ==================   ===========    ====
 *  id                   int            4                                      
 *  idtype_id            int            4                                             
 *  idcode               varchar        32                                              
 *  custdet_id           int            4                                              
 *
 *
 *  IMPORTANT NOTES:
 *
 *      - CHAR and VARCHAR database types cannot be an empty string ("") because
 *        this is a null value in some databases (ie Oracle).  As a result, the
 *        following has been done to resolve this problem:
 *
 *             1) FunctionLib.setDbString() method is always called on CHAR/VARCHAR
 *                fields when creating/updating records to the database.  This 
 *                function ensures that no empty strings are sent to the database by
 *                adding one space when the string is "".
 *
 *             2) FunctionLib.getDbString() method is always called on CHAR/VARCHAR fields
 *                when reading records from the database to ensure that the additional
 *                spaces added by the FunctionLib.setDbString function are removed.
 *
 *      - CHAR fields in some databases are padded to the column width (eg. the value
 *        'XYZ' of a CHAR(5) field type will be stored as 'XYZ  ').  This means that
 *        some databases have problems when CHAR fields are used in the WHERE clause
 *        (ie PreparedStatements in Oracle require that the field must also be padded).
 *        As a result, the following has been done to resolve this problem:
 * 
 *             3) FunctionLib.ensureStrLength() method is always called for CHAR fields
 *                that are used in a WHERE clause.  This method adds as many trailing
 *                spaces as required.
 *
 *             4) FunctionLib.rtrim() method should be called when reading CHAR fields
 *                from the database to remove any trailing spaces.
 *                
 */


/**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project no: <br>
 * Use case no: <br>
 * Use case name: Cust_idcodeEntityBean Data<br>
 * Date created: 19/04/2002 09:35 </h4><hr>
 *
 * This EJB inserts and selects the relevant data
 * from database for charge profile.
 *
 * @author j2eegen
 */
public class CustIdCodeEntityBean implements EntityBean
{
    //private final String CLASSNAME=this.getClass().getName();
	private final String CLASSNAME="Custidcode";

    private EntityContext entityContext;
    private DataSource ds;

    private boolean update_database_flag = false;

    private final String insertSQL = "INSERT INTO Custidcode (id, idtype_id, idcode, custdet_id) VALUES (?, ?, ?, ?)";
    private final String selectSQL = "SELECT id, idtype_id, idcode, custdet_id, verno_ctx FROM Custidcode WHERE id = ?";
    private final String updateSQL = "UPDATE Custidcode SET id = ?, idtype_id = ?, idcode = ?, custdet_id = ? WHERE id = ? AND verno_ctx = ?";
    private final String deleteSQL = "DELETE FROM Custidcode WHERE id = ?";

                                                            // verno_ctx
    public void setVerno_ctx (long verno_ctx) throws serverException
    {
        CustIdCodeInfo cust_idcodeInfo = getCustIdCodeInfo();
        cust_idcodeInfo.setVerno_ctx (verno_ctx);
        setCustIdCodeInfo(cust_idcodeInfo);
    }
    public long getVerno_ctx () throws serverException
    {
        CustIdCodeInfo cust_idcodeInfo = getCustIdCodeInfo();
        return cust_idcodeInfo.getVerno_ctx();
    }

                                                            // idcode
    public void setIdcode (String idcode) throws serverException
    {
        CustIdCodeInfo cust_idcodeInfo = getCustIdCodeInfo();
        cust_idcodeInfo.setIdentificationCode(idcode);
        setCustIdCodeInfo(cust_idcodeInfo);
    }
    public String getIdcode () throws serverException
    {
        CustIdCodeInfo cust_idcodeInfo = getCustIdCodeInfo();
        return cust_idcodeInfo.getIdentificationCode();
    }

                                                            // idtype_id
    public void setIdtype_id (long idtype_id) throws serverException
    {
        CustIdCodeInfo cust_idcodeInfo = getCustIdCodeInfo();
        cust_idcodeInfo.setIdtype_id (idtype_id);
        setCustIdCodeInfo(cust_idcodeInfo);
    }
    public long getIdtype_id () throws serverException
    {
        CustIdCodeInfo cust_idcodeInfo = getCustIdCodeInfo();
        return cust_idcodeInfo.getIdtype_id();
    }

                                                            // id
    public void setId (long id) throws serverException
    {
        CustIdCodeInfo cust_idcodeInfo = getCustIdCodeInfo();
        cust_idcodeInfo.setId (id);
        setCustIdCodeInfo(cust_idcodeInfo);
    }
    public long getId () throws serverException
    {
        CustIdCodeInfo cust_idcodeInfo = getCustIdCodeInfo();
        return cust_idcodeInfo.getId();
    }

                                                            // custdet_id
    public void setCustdet_id (long custdet_id) throws serverException
    {
        CustIdCodeInfo cust_idcodeInfo = getCustIdCodeInfo();
        cust_idcodeInfo.setCustdet_id (custdet_id);
        setCustIdCodeInfo(cust_idcodeInfo);
    }
    public long getCustdet_id () throws serverException
    {
        CustIdCodeInfo cust_idcodeInfo = getCustIdCodeInfo();
        return cust_idcodeInfo.getCustdet_id();
    }


    /**
     *  This method updates the database with the information provided in cust_idcodeInfo <br>
     *
     *  It also controls versioning.  It throws a serverException when the version of the
     *  record in the database is different to that of the cust_idcodeInfo record.<br>
     *
     *  It should be noted that this method always sends an UPDATE SQL statement to the database.
     *  The details of the primary key are taken from the context rather than from the 
     *  cust_idcodeInfo object
     *  
     */
    public IResultInfo setCustIdCodeInfo (CustIdCodeInfo cust_idcodeInfo) throws serverException
    {
        CustIdCodePK primary_key = (CustIdCodePK) entityContext.getPrimaryKey();
        //System.out.println ("setCust_idcodeInfo "+primary_key +"***** UPDATE SQL statement sent to database");
        
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try
        {
            // Prepare UPDATE SQL statement to update record
            conn = ds.getConnection();
            String executeSQL = updateSQL;

            stmt = conn.prepareStatement (executeSQL);

            // Set the new values of the record to the PreparedStatement
            String dbString = "";
            stmt.setLong (1, cust_idcodeInfo.getId());
            stmt.setLong (2, cust_idcodeInfo.getIdtype_id());
            stmt.setString (3, FunctionLib.setDbString(cust_idcodeInfo.getIdentificationCode()));
            stmt.setLong (4, cust_idcodeInfo.getCustdet_id());


            // Set the values of the where clause - PK and verno_ctx to the PreparedStatement
            stmt.setLong (5, primary_key.id);


            stmt.setLong (6, cust_idcodeInfo.getVerno_ctx());        // Verno_ctx
                              
            // Execute UPDATE SQL statement
            int num_records_updated = stmt.executeUpdate();
            //System.out.println ("[" + num_records_updated + "] records updated");
            
            // Optimistic locking control
            // If not records update means that either the version number has changed
            // (that is, somebody has updated the record), or the record has been
            // removed.  In either case, a serverException must be thrown.
            if (num_records_updated<=0) 
            {
                throw new serverException ("error.db.updatelock");
            }                     

            // Create IResultInfo object with the current versioning in the database
            ResultInfo tobjResultInfo = new ResultInfo();
            tobjResultInfo.setVerno_ctx (cust_idcodeInfo.getVerno_ctx() + 1);
            return tobjResultInfo;
        }
        catch (SQLException sqle)
        {
            debugLib.logError(CLASSNAME, ""+sqle.getErrorCode()+" "+sqle, entityContext.getCallerPrincipal().getName());
            debugLib.logError(CLASSNAME, sqle, entityContext.getCallerPrincipal().getName());
            throw new serverException("error.db.updatefailed");
        }
        catch (Exception e)
        {
            debugLib.logError(CLASSNAME, e, entityContext.getCallerPrincipal().getName());
            throw new serverException("error.db.updatefailed");
        }
        finally 
        {
            // Close the connection
            if (conn!=null) 
            {
                try
                {
                    conn.close();
                }
                catch (SQLException sqle)
                {
                    debugLib.logError(CLASSNAME, ""+sqle.getErrorCode()+" "+sqle, entityContext.getCallerPrincipal().getName());
                    debugLib.logError(CLASSNAME, sqle, entityContext.getCallerPrincipal().getName());
                    throw new EJBException ("Exception while closing the connection");
                }
            }
        }
    }
       
    /**
     *  This method retrieves a Cust_idcodeInfo object containing the details of the record 
     *  represented by the Entity bean in the database.<br>
     *
     *  It should be noted that this method always sends an SELECT SQL statement to the database.
     *  The details of the primary key are taken from the context.
     */
    public CustIdCodeInfo getCustIdCodeInfo () throws serverException
    {
    	CustIdCodeInfo cust_idcodeInfo = new CustIdCodeInfo();    
        CustIdCodePK primary_key = (CustIdCodePK) entityContext.getPrimaryKey();
        //System.out.println ("getCust_idcodeInfo "+primary_key+"***** SELECT SQL statement sent to database");


        Connection conn = null;
        PreparedStatement stmt = null;
        
        try
        {
            // Prepare SELECT SQL statement to load record
            conn = ds.getConnection();
            String executeSQL = selectSQL;

            stmt = conn.prepareStatement (executeSQL);

            stmt.setLong (1, primary_key.id);

            // Execute SELECT SQL statement
            ResultSet rs = stmt.executeQuery();
            
            // Check whether the record exists in the database
            if (rs.next()) 
            {
                cust_idcodeInfo.setId (rs.getLong(1));
                cust_idcodeInfo.setIdtype_id (rs.getLong(2));
                cust_idcodeInfo.setIdentificationCode(FunctionLib.getDbString(rs.getString(3)));
                cust_idcodeInfo.setCustdet_id (rs.getLong(4));

                cust_idcodeInfo.setVerno_ctx (rs.getLong (5));             // Verno_ctx
                return cust_idcodeInfo;
            }
            else 
            {
                throw new serverException ("error.db.recorddoesnotexist");
            }
        }
        catch (SQLException sqle)
        {
            debugLib.logError(CLASSNAME, ""+sqle.getErrorCode()+" "+sqle, entityContext.getCallerPrincipal().getName());
            debugLib.logError(CLASSNAME, sqle, entityContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        }
        catch (Exception e)
        {
            debugLib.logError(CLASSNAME, e, entityContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        }
        finally 
        {
            // Close the connection
            if (conn!=null) 
            {
                try
                {
                    conn.close();
                }
                catch (SQLException sqle)
                {
                    debugLib.logError(CLASSNAME, ""+sqle.getErrorCode()+" "+sqle, entityContext.getCallerPrincipal().getName());
                    debugLib.logError(CLASSNAME, sqle, entityContext.getCallerPrincipal().getName());
                    throw new EJBException ("Exception while closing the connection");
                }
            }
        }
    }


    /**
     *  This method updates the database with the information provided in cust_idcodeInfo <br>
     *
     *  It also controls versioning.  It throws a serverException when the version of the
     *  record in the database is different to that of the cust_idcodeInfo record.<br>
     *
     *  It should be noted that this method always sends an UPDATE SQL statement to the database.
     *  The details of the primary key are taken from the context rather than from the 
     *  cust_idcodeInfo object
     * 
     *  @deprecated Replaced by setCust_idcodeInfo as as clients that call doCust_idcodeUpdate  
     *              cannot correctly handle versioning.
     */
    public boolean doCustIdCodeUpdate(CustIdCodeInfo cust_idcodeInfo) throws serverException
    {
        setCustIdCodeInfo (cust_idcodeInfo);
        return true;
    }

    /**
     *  EJB callback method ejbFindByPrimaryKey <br>
     * 
     *  This method always returns the primary_key object passed as parameter. <br>
     * 
     *  Please note that due to Nomad's BMP entity bean model, this method does not
     *  checks in the database whether the record exists, as suggested in the EJB specification.
     *  This is to avoid unnecessary SELECT SQL statements sent to the database.
     */
    public CustIdCodePK ejbFindByPrimaryKey (CustIdCodePK primary_key) throws FinderException
    {
        //System.out.println ("ejbFindByPrimaryKey " + primary_key);
        return primary_key;
    }


    /**
     *  EJB callback method ejbCreate <br>
     * 
     *  This method creates a new record in the database with the information provided in cust_idcodeInfo
     */
    public CustIdCodePK ejbCreate(CustIdCodeInfo cust_idcodeInfo) throws CreateException,serverException
    {
        //System.out.println ("ejbCreate");

        // Setup the PK object
    	CustIdCodePK primary_key = new CustIdCodePK();
                    primary_key.id = cust_idcodeInfo.getId();

                
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try
        {
            // Execute SQL to insert record
            conn = ds.getConnection();
            if (primary_key.id == 0)
            {
            	//String tableName = CommonGlobalFunctions.getEntityTableNameByClassName(CLASSNAME);
            	String tableName = "Custidcode";
                primary_key.id = CommonGlobalFunctions.getNextIdByTableName(tableName);
            }
            String executeSQL = insertSQL;

            stmt = conn.prepareStatement (executeSQL);
            String dbString = "";
            stmt.setLong (1, primary_key.id);
            stmt.setLong (2, cust_idcodeInfo.getIdtype_id());
            stmt.setString (3, FunctionLib.setDbString(cust_idcodeInfo.getIdentificationCode()));
            stmt.setLong (4, cust_idcodeInfo.getCustdet_id());


            stmt.executeUpdate();
            
            // Return PK
            return primary_key;
        }
        catch (SQLException sqle)
        {
            debugLib.logError(CLASSNAME, ""+sqle.getErrorCode()+" "+sqle, entityContext.getCallerPrincipal().getName());
            debugLib.logError(CLASSNAME, sqle, entityContext.getCallerPrincipal().getName());
            throw new serverException("error.db.insertfailed");
        }
        catch (Exception e)
        {
            debugLib.logError(CLASSNAME, e, entityContext.getCallerPrincipal().getName());
            throw new serverException("error.db.insertfailed");
        }
        finally 
        {
            // Close the connection
            if (conn!=null) 
            {
                try
                {
                    conn.close();
                }
                catch (SQLException sqle)
                {
                    debugLib.logError(CLASSNAME, ""+sqle.getErrorCode()+" "+sqle, entityContext.getCallerPrincipal().getName());
                    debugLib.logError(CLASSNAME, sqle, entityContext.getCallerPrincipal().getName());
                    throw new EJBException ("Exception while closing the connection");
                }
            }
        }        
    }

    /**
     *  EJB callback method ejbPostCreate<br>
     * 
     *  Method not used
     */
    public void ejbPostCreate(CustIdCodeInfo cust_idcodeInfo) throws CreateException {}

    /**
     *  EJB callback method ejbRemove<br>
     * 
     *  This method removes the record represented by the Entity bean from the database.
     *  The primary key is taken from the entity Context.
     */
    public void ejbRemove() throws RemoveException 
    {
        //System.out.println ("ejbRemove");
    	CustIdCodePK primary_key = (CustIdCodePK) entityContext.getPrimaryKey();
    
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try
        {
            // Execute SQL to update record
            conn = ds.getConnection();
            stmt = conn.prepareStatement (deleteSQL);

            stmt.setLong (1, primary_key.id);

            // Execute UPDATE SQL statement
            int num_records_deleted = stmt.executeUpdate();
            //System.out.println ("[" + num_records_deleted + "] records deleted");
            
            // Optimistic locking control
            // If not records update means that either the version number has changed
            // (that is, somebody has updated the record), or the record has been
            // removed.  In either case, a serverException must be thrown.
            if (num_records_deleted<=0) 
            {
                throw new RemoveException ("The record has not been removed because it did not exist in the database");
            }     
        }
        catch (SQLException sqle)
        {
            debugLib.logError(CLASSNAME, ""+sqle.getErrorCode()+" "+sqle, entityContext.getCallerPrincipal().getName());
            debugLib.logError(CLASSNAME, sqle, entityContext.getCallerPrincipal().getName());
            throw new EJBException ("unable to remove record from database ["+primary_key+"]");
        }
        catch (Exception e)
        {
            debugLib.logError(CLASSNAME, e, entityContext.getCallerPrincipal().getName());
        }
        
        finally 
        {
            // Close the connection
            if (conn!=null) 
            {
                try
                {
                    conn.close();
                }
                catch (SQLException sqle)
                {
                    debugLib.logError(CLASSNAME, ""+sqle.getErrorCode()+" "+sqle, entityContext.getCallerPrincipal().getName());
                    debugLib.logError(CLASSNAME, sqle, entityContext.getCallerPrincipal().getName());
                    throw new EJBException ("Exception while closing the connection");
                }
            }
        }
    }

    /**
     *  EJB callback method ejbLoad<br>
     * 
     *  This method does not do anything<br>
     * 
     *  Please note that due to Nomad's BMP entity bean model, this method does not
     *  loads the record from the database, as suggested in the EJB specification.
     *  This is to avoid unnecessary SELECT SQL statements sent to the database.<br>
     *
     *  For loading the record from the database, please use getCust_idcodeInfo().
     *  
     */
    public void ejbLoad() 
    {
        //System.out.println ("ejbLoad "+(Cust_idcodePK) entityContext.getPrimaryKey());
    }

    /**
     *  EJB callback method ejbStore<br>
     * 
     *  This method does not do anything<br>
     * 
     *  Please note that due to Nomad's BMP entity bean model, this method does not
     *  loads the record from the database, as suggested in the EJB specification.
     *  This is to avoid unnecessary SELECT SQL statements sent to the database.<br>
     *
     *  For storing the record to the database, please use setCust_idcodeInfo().
     *  
     */    
    public void ejbStore() 
    {
        //System.out.println ("ejbStore - entered");
    }

    /**
     *  EJB callback method ejbActivate<br>
     * 
     *  Method not used
     */
    public void ejbActivate() 
    {
        //System.out.println ("ejbActivate");
    }

    /**
     *  EJB callback method ejbPassivate<br>
     * 
     *  Method not used
     */
    public void ejbPassivate() {
        //System.out.println ("ejbPassivate");
    }
    
    /**
     *  EJB callback method unsetEntityContext<br>
     * 
     */
    public void unsetEntityContext()
    {
        //System.out.println ("unsetEntityContext");
   
        this.entityContext = null;
    }

    /**
     *  EJB callback method setEntityContext<br>
     * 
     */
    public void setEntityContext(EntityContext entityContext)
    {
        //System.out.println ("setEntityContext");
    
        this.entityContext = entityContext;
        
        try
        {
            ds = ServiceLocator.getInstance().getDataSource(globalConstant.DATA_SOURCE);
        }
        catch (ServiceLocatorException e) 
        {
            throw new EJBException (e);
        }
    }
}

