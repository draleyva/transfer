package com.cortex.cust.bre.gui.ia.plugins.customerids;

import org.apache.commons.lang.StringUtils;

import com.cortex.common.hook.HookInterface;
import com.cortex.common.hook.HookParam;
import com.cortex.gui.ia.valueobj.CustdetSearchInfo;

public class GetCustdetIDsTabPlugin implements HookInterface {

    public static final String CLASSNAME = "GetCustdetIDsTabPlugin";

    public static final String GET_IA_CUSTDET_SEARCH_COUNT_SQL_BPD = "select count(*) as count from custdet cu , custidcode i, inst inst where i.custdet_id = cu.id and inst.id = cu.inst_id and 1=1 ";
    public static String GET_IA_CUSTDET_SEARCH_SQL_BPD = "Select c.id, firstname, inst.instcode instcode, custcode, lastname ,typeid ,id_number,sex,married,addrl1,home_city, postcode,date_birth from custdet c , custidcode i, inst inst where i.custdet_id = c.id and inst.id = c.inst_id and 1=1";

    public HookParam process(HookParam param) throws Exception {
        String tsBRESQlQuery = (String) param.get(HookParam.PARAM1);
        String tsBRECountQuery = (String) param.get(HookParam.PARAM2);
        CustdetSearchInfo pobjCustdetSearchInfo = (CustdetSearchInfo) param.get(HookParam.PARAM3);

        if (StringUtils.isNotBlank(pobjCustdetSearchInfo.getInstcode2())) {
            tsBRESQlQuery = GET_IA_CUSTDET_SEARCH_SQL_BPD;
            tsBRECountQuery = GET_IA_CUSTDET_SEARCH_COUNT_SQL_BPD;
        } else {
            tsBRESQlQuery = null;
            tsBRECountQuery = null;
        }

        param.put(HookParam.PARAM1, tsBRESQlQuery);
        param.put(HookParam.PARAM2, tsBRECountQuery);

        return param;
    }

}
