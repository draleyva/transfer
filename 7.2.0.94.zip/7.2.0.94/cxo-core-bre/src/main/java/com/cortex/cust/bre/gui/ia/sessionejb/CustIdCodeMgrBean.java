package com.cortex.cust.bre.gui.ia.sessionejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.cortex.common.constant.SQLConstants;
import com.cortex.common.constant.globalConstant;
import com.cortex.common.constant.serverConstant;
import com.cortex.common.entityejb.CrddetEntity;
import com.cortex.common.entityejb.CrddetEntityHome;
import com.cortex.common.entityejb.CrddetInfo;
import com.cortex.common.entityejb.CrddetSK;
import com.cortex.common.exception.serverException;
import com.cortex.common.interfaces.IResultInfo;
import com.cortex.common.lib.HomeCacheController;
import com.cortex.common.lib.ServiceLocator;
import com.cortex.common.lib.dbLib;
import com.cortex.common.lib.debugLib;
import com.cortex.common.sql.SQLFactory;
import com.cortex.common.sql.SQLSearchNode;
import com.cortex.cust.bre.common.constant.SQLConstantsBre;
import com.cortex.cust.bre.common.constant.serverConstantBre;
import com.cortex.cust.bre.common.entityejb.CustIdCodeEntity;
import com.cortex.cust.bre.common.entityejb.CustIdCodeEntityHome;
import com.cortex.cust.bre.common.entityejb.CustIdCodeInfo;
import com.cortex.cust.bre.common.entityejb.CustIdCodePK;
import com.cortex.cust.bre.gui.ia.valueobj.BREReplaceLostOrStolenCardsInfo;
import com.cortex.cust.bre.gui.ia.valueobj.CustIdCodePKInfo;
import com.cortex.cust.bre.gui.ia.valueobj.CustIdCodeSearchInfo;
import com.cortex.gui.common.constant.IChConstant;
import com.cortex.gui.common.lib.BasicPanCryptor;
import com.cortex.gui.common.lib.IaGlobalFunctions;
import com.cortex.gui.common.lib.PageWithSorting;
import com.cortex.gui.common.lib.PagingInterface;
import com.cortex.gui.common.lib.WhereClauseLib;
import com.cortex.gui.common.valueobj.PageWithSortingDataInfo;
import com.cortex.gui.common.valueobj.PagingContextInfo;
import com.cortex.gui.common.valueobj.WhereClauseInfo;

/**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project No           : 1103  <br>
 * Module Name          : Ia<br>
 * Global Use Case      : N/A<br>
 * Business Use case    : N/A<br>
 * Maintenance Use case : N/A<br>
 * @author                j2eegen<br>
 *
 * This bean class contains the bussiness methods of Cust_idcode table<br>
 *
 * Date   Author     Reviewer    Description of change<br>
 *
 * @version 1.0
 */
public class CustIdCodeMgrBean implements SessionBean, PagingInterface
{
    private javax.ejb.SessionContext mctx;
    private static final String CLASSNAME="CustIdCodeMgrBean";

    private CustIdCodeEntityHome home = null;  
    private HomeCacheController mobjCrddetHomeCacheController = null;

    /**
     *  This method updates the cust_idcode record in the database with the
     *  values provided in the Cust_idcodeInfo object
     *
     *  @param pobjCust_idcodeInfo info object containing the values to update
     *  @return IResultInfo returns a IResultInfo object with the updated verno_ctx value
     *  @throws serverException if the record could not be updated (ie. the version
     *                          of the Cust_idcodeInfo object is not the latest one)
     */
    public IResultInfo updateCustIdCode(CustIdCodeInfo pobjCust_idcodeInfo) throws serverException
    {
        try
        {
            // Obtain reference to Entity bean
            CustIdCodePK tobjCust_idcodePK = new CustIdCodePK();
            tobjCust_idcodePK.id = pobjCust_idcodeInfo.getId();
            CustIdCodeEntity mobjCust_idcodeEntity=(CustIdCodeEntity)home.findByPrimaryKey(tobjCust_idcodePK);
            Map custdet = getCustomerDetails(pobjCust_idcodeInfo.getCustCode(), pobjCust_idcodeInfo.getInstCode());
        	pobjCust_idcodeInfo.setCustdet_id(((Integer)custdet.get(SQLConstantsBre.GET_CUSTOMER_ID)).intValue());
            // Change values
            IResultInfo tobjResultInfo = mobjCust_idcodeEntity.setCustIdCodeInfo (pobjCust_idcodeInfo);

            // The update was successfull (otherwise a serverException would have been thrown)
            return tobjResultInfo;
        }
        catch(FinderException fe)
        {
            debugLib.logError(CLASSNAME,fe,mctx.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        }
        catch(RemoteException re)
        {
            debugLib.logError(CLASSNAME,re,mctx.getCallerPrincipal().getName());
            throw new serverException("error.db.updatefailed");
        }
    }
    

    /**
     *  This method deletes the cust_idcode record in the database  especified
     *  in the Cust_idcodePKInfo object.
     *
     *  @param pobjCust_idcodePKInfo info object containing the primary key of the
     *                           cust_idcode record to delete.
     *  @return void
     *  @throws serverException if the record could not be deleted from the database
     */
    public void deleteCustIdCode(CustIdCodePKInfo pobjCust_idcodePKInfo) throws serverException
    {
        try
        {
            // Obtain reference to Entity bean
            CustIdCodePK tobjCust_idcodePK = new CustIdCodePK();
            tobjCust_idcodePK.id = pobjCust_idcodePKInfo.getId();
            CustIdCodeEntity mobjCust_idcodeEntity=(CustIdCodeEntity)home.findByPrimaryKey(tobjCust_idcodePK);

            // Remove bean
            mobjCust_idcodeEntity.remove();
        }
        catch(FinderException fe)
        {
            debugLib.logError(CLASSNAME,fe,mctx.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        }
        catch (RemoveException re)
        {
            debugLib.logError(CLASSNAME,re,mctx.getCallerPrincipal().getName());
            throw new serverException("error.db.updatefailed");
        }
        catch(RemoteException re)
        {
            debugLib.logError(CLASSNAME,re,mctx.getCallerPrincipal().getName());
            throw new serverException("error.db.deletefailed");
        }
    }

    /**
     *  This method adds a new cust_idcode record in the database.  The details of this
     *  new record are provided in a Cust_idcodeInfo object
     *
     *  @param pobjCust_idcodeInfo info object containing the details of the record to
     *                           be inserted in the database
     *  @return void
     *  @throws serverException if the record could not be inserted into the database
     */
    public void addCustIdCode(CustIdCodeInfo pobjCust_idcodeInfo) throws serverException
    {
        try
        {
        	Map custdet = getCustomerDetails(pobjCust_idcodeInfo.getCustCode(), pobjCust_idcodeInfo.getInstCode());
        	pobjCust_idcodeInfo.setCustdet_id(((Integer)custdet.get(SQLConstantsBre.GET_CUSTOMER_ID)).intValue());
            // Create bean
            CustIdCodeEntity mobjCust_idcodeEntity = home.create(pobjCust_idcodeInfo);
        }
        catch(CreateException ce)
        {
            debugLib.logError(CLASSNAME,ce,mctx.getCallerPrincipal().getName());
            throw new serverException("ia.error.db.cust_idcode.keyexist");
        }
        catch(RemoteException re)
        {
            debugLib.logError(CLASSNAME,re,mctx.getCallerPrincipal().getName());
            throw new serverException("error.db.insertfailed");
        }
    }


    /**
     *  This method retrieves a record from the database.  The primary key of this
     *  method is provided in the pobjCust_idcodePKInfo object.
     *
     *  @param pobjCust_idcodePKInfo info object containing the primary key of the
     *                           cust_idcode record to retrieve.
     *  @return Cust_idcodeInfo the details of the cust_idcode record retrieved
     *  @throws serverException if the record could not be retrieved from the database
     */
    public CustIdCodeInfo getCustIdCode(CustIdCodePKInfo pobjCust_idcodePKInfo) throws serverException
    {
    	CustIdCodeInfo tobjCust_idcodeInfo=null;

        try
        {
            // Obtain reference to Entity bean
            CustIdCodePK tobjCust_idcodePK= new CustIdCodePK();
            tobjCust_idcodePK.id = pobjCust_idcodePKInfo.getId();
            CustIdCodeEntity mobjCust_idcodeEntity=home.findByPrimaryKey(tobjCust_idcodePK);

            // Get info details
            tobjCust_idcodeInfo = mobjCust_idcodeEntity.getCustIdCodeInfo();

         }
        catch(FinderException fe)
        {
            debugLib.logError(CLASSNAME,fe,mctx.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        }
        catch(RemoteException re)
        {
            debugLib.logError(CLASSNAME,re,mctx.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        }

        return tobjCust_idcodeInfo;
    }

   /**
    * Form the search query based on the search criteria provided in the object
    * and populate the PagingContextInfo with oppropriate values and pass that Sql
    * Query and PagingContextInfo to the PageWithSorting.getRowSet() method which
    * inturn will return the CachedRowSet object through which we need to populate
    * the ArrayList of Cust_idcodeSearchInfo objects and return the populated Vector.
    *
    * @param pobjCust_idcodeSearchInfo
    * @param pobjPagingContextInfo
    * @return java.util.List
    * @throws serverException if an error occurred when retrieving data from the database
    */
    public java.util.List searchCustIdCode(CustIdCodeSearchInfo pobjCust_idcodeSearchInfo, PagingContextInfo pobjPagingContextInfo)
        throws serverException
    {
        ArrayList tobjSearchInfo = new ArrayList();
        boolean tbWhereFlag = true;

        SQLFactory tobjFactory = SQLFactory.getSQLFactory();
        SQLSearchNode tobjNode = tobjFactory.getSQLSearchNode("ia", "com.cortex.cust.bre.gui.ia.sessionejb.searchCust_idcode");

        try {
            pobjPagingContextInfo.setPKColumnAliasName(tobjNode.getColumnName("cust_idcodePK"));
            pobjPagingContextInfo.setPKVariableType(false);
            pobjPagingContextInfo.setPKColumn(tobjNode.getPKColumn());
            pobjPagingContextInfo.setSortVariableType(false);
            pobjPagingContextInfo.setSortColumn(tobjNode.getColumnName("idcode")); 

            String tsSQlQuery = tobjNode.getStatement();
            String tsCountQuery = tobjNode.getCountStatement();
            tbWhereFlag = false;
            tsSQlQuery +=  pobjCust_idcodeSearchInfo.getCustId();
            tsCountQuery +=  pobjCust_idcodeSearchInfo.getCustId();
            PageWithSortingDataInfo tobjPageWithSortingDataInfo = new PageWithSortingDataInfo();
            tobjPageWithSortingDataInfo.msSelectQry = tsSQlQuery;
            tobjPageWithSortingDataInfo.msCountQry = tsCountQuery;
            tobjPageWithSortingDataInfo.miCountColumn = tobjNode.getCountColumnPos();
            tobjPageWithSortingDataInfo.miPKAliasColumn = tobjNode.getColumnPos("cust_idcodePK");
            tobjPageWithSortingDataInfo.miSortColumn = tobjNode.getColumnPos("idcode");
            tobjPageWithSortingDataInfo.mbWhereFlag = tbWhereFlag;
            tobjPageWithSortingDataInfo.mobjPagingContextInfo = pobjPagingContextInfo;
            tobjPageWithSortingDataInfo.mobjPagingInterface = (PagingInterface)this;

            PageWithSorting tobjPageWithSorting = new PageWithSorting();
            tobjSearchInfo = tobjPageWithSorting.getSearchDetails(tobjPageWithSortingDataInfo);
        }
        catch(Exception e)
        {
            debugLib.logError(CLASSNAME,e,mctx.getCallerPrincipal().getName());
            throw new serverException ("error.unknownerror");
        }


        return tobjSearchInfo;
   }

   /**
    * A generalised SQL Where clause
    *
    * @param pobjCust_idcodeSearchInfo
    * @return String
    */
    private String getWhereForSearch(CustIdCodeSearchInfo pobjCust_idcodeSearchInfo, SQLSearchNode pobjNode)
    {
        String tsWhereClause = "";
        Vector tvecWhereClauseInfo = new Vector();
        
        if (pobjCust_idcodeSearchInfo.getCustId() != 0)
        {
            WhereClauseInfo tobjWhereClauseInfo1 = new WhereClauseInfo();
            tobjWhereClauseInfo1.setDBColumnName(pobjNode.getColumnName("custdet_id"));
            tobjWhereClauseInfo1.setVariableValue(Integer.toString(pobjCust_idcodeSearchInfo.getCustId()));
            tobjWhereClauseInfo1.setVaribleType(globalConstant.WHERE_TYPE_INT);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo1);
        }

        tsWhereClause = WhereClauseLib.formWhereClause(tvecWhereClauseInfo);

        return tsWhereClause;
    }


   /**
    * A generalised method of obtaining the Data from Cached Row set
    *
    * @param pobjCachedRowSet
    * @return Object
    */
   public Object getDataFromCachedRowset(ResultSet pobjCachedRowSet)
   {
        CustIdCodeSearchInfo tobjCust_idcodeSearchInfo= null;

        SQLFactory tobjFactory = SQLFactory.getSQLFactory();
        SQLSearchNode tobjNode = tobjFactory.getSQLSearchNode("ia", "com.cortex.cust.bre.gui.ia.sessionejb.searchCust_idcode");

        try
        {
            tobjCust_idcodeSearchInfo = new CustIdCodeSearchInfo();
            tobjCust_idcodeSearchInfo.setIndentificationTypeCode(pobjCachedRowSet.getString(tobjNode.getColumnPos("idtypecode")));
            tobjCust_idcodeSearchInfo.setIndentificationTypeDesc(pobjCachedRowSet.getString(tobjNode.getColumnPos("idtypedescr")));
            tobjCust_idcodeSearchInfo.setIndentificationCode(pobjCachedRowSet.getString(tobjNode.getColumnPos("idcode")));
            tobjCust_idcodeSearchInfo.setId(pobjCachedRowSet.getString(tobjNode.getColumnPos("id")));
        }
        catch(Exception e)
        {
           debugLib.logError (CLASSNAME,e,mctx.getCallerPrincipal().getName());
           tobjCust_idcodeSearchInfo = null;
        }

        return tobjCust_idcodeSearchInfo;
   }
   
   /**
    * this method will returns customer details
    * 
    * @param custCode
    * @param inst
    * @return
    * @throws serverException
    */
   public Map getCustomerDetails(String custCode, String instCode) throws serverException
   {
	   Map customerDetails = new HashMap();
	   Connection tobjConnection = null;
       PreparedStatement tobjpstmt = null;
       ResultSet tobjRs = null;
       String name = "";
       try
       {
           tobjConnection = dbLib.getConnection(globalConstant.DATA_SOURCE);
           tobjpstmt = tobjConnection.prepareStatement(SQLConstantsBre.GET_CUSTOMER_DETAILS);
           tobjpstmt.setString(1, custCode);
           debugLib.logInfo(CLASSNAME, custCode, mctx.getCallerPrincipal().getName());
           tobjpstmt.setString(2, instCode);
           debugLib.logInfo(CLASSNAME, instCode, mctx.getCallerPrincipal().getName());
           debugLib.logInfo(CLASSNAME, SQLConstantsBre.GET_CUSTOMER_DETAILS, mctx.getCallerPrincipal().getName());
           tobjRs = tobjpstmt.executeQuery();
           if(tobjRs.next())
           {
        	   customerDetails.put(SQLConstantsBre.GET_CUSTOMER_ID, new Integer(tobjRs.getInt(1)));
        	   if(null != tobjRs.getString(2) && tobjRs.getString(2).length() > 0)
        	   {
        		   name = tobjRs.getString(2);
        	   }
        	   if(null != tobjRs.getString(3) && tobjRs.getString(3).length() > 0)
        	   {
        		   name = name +" "+ tobjRs.getString(3);
        	   }
        	   if(null != tobjRs.getString(4) && tobjRs.getString(4).length() > 0)
        	   {
        		   name = name +" "+ tobjRs.getString(4);
        	   }
        	   customerDetails.put(SQLConstantsBre.GET_CUSTOMER_NAME, name.trim());
           }
       }
       catch(SQLException e)
       {
           debugLib.logError(CLASSNAME,e.toString(),mctx.getCallerPrincipal().getName());
           throw new serverException("error.db.searchfailed");
       }
       catch(Exception e)
       {
           debugLib.logError(CLASSNAME,e.toString(),mctx.getCallerPrincipal().getName());
           throw new serverException("error.db.searchfailed");
       }
       finally 
		{
			try 
			{
				if (tobjConnection != null) 
				{
					dbLib.closeConnection(tobjConnection);
					dbLib.closeResultSet(tobjRs);
					dbLib.closeStatement(tobjpstmt);
				}
			} catch (Exception e) 
			{
				debugLib.logError(CLASSNAME, e.toString());
			}
		}
       return customerDetails;
   }
   
   /**
    * this method does bre card replacement
    * 
    * @param bREReplaceLostOrStolenCardsInfo
    */
   public void replaceCard(BREReplaceLostOrStolenCardsInfo bREReplaceLostOrStolenCardsInfo) throws serverException
   {
	   Connection tobjConnection = null;
	   
       PreparedStatement tobjpstmt = null;
       Statement tobjStmt = null;
       ResultSet tobjRs = null;
       try
       {
           tobjConnection = dbLib.getConnection(globalConstant.DATA_SOURCE);
           tobjpstmt = tobjConnection.prepareStatement(SQLConstantsBre.REPLACE_CARD_PAN_VALIDATION);
           tobjpstmt.setString(1, BasicPanCryptor.getInstance().encryptPan(bREReplaceLostOrStolenCardsInfo.getNewPan()));
           tobjpstmt.setString(2, bREReplaceLostOrStolenCardsInfo.getInstcode());
           tobjRs = tobjpstmt.executeQuery();
           if(tobjRs.next())
           {
        	   if(!tobjRs.getString(1).equals("99999999"))
        	   {
        		   throw new serverException("error.error.cardalreadyassigned"); 
        	   }
           }
           else
           {
        	   throw new serverException("error.error.cardnotfound"); 
           }
           
        // Obtain reference to Home bean
           CrddetEntityHome mobjCrddetEntityHome = (CrddetEntityHome)mobjCrddetHomeCacheController.getHome (false);
           CrddetSK oldCrddetSK = new CrddetSK();
           oldCrddetSK.pan = BasicPanCryptor.getInstance().encryptPan(bREReplaceLostOrStolenCardsInfo.getOldPan());
           oldCrddetSK.seqno = Integer.parseInt(bREReplaceLostOrStolenCardsInfo.getOldSeqno());
           CrddetEntity oldCrddetEntity = (CrddetEntity)mobjCrddetEntityHome.findBySecondaryKey(oldCrddetSK);
           CrddetInfo oldCrddetInfo = oldCrddetEntity.getCrddetInfo();
           
           CrddetSK newCrddetSK = new CrddetSK();
           newCrddetSK.pan = BasicPanCryptor.getInstance().encryptPan(bREReplaceLostOrStolenCardsInfo.getNewPan());
           newCrddetSK.seqno = Integer.parseInt(bREReplaceLostOrStolenCardsInfo.getNewSeqno());
           CrddetEntity newCrddetEntity = (CrddetEntity)mobjCrddetEntityHome.findBySecondaryKey(newCrddetSK);
           CrddetInfo newCrddetInfo = newCrddetEntity.getCrddetInfo();
           
           //updating new card datat
           newCrddetInfo.setCustdet_id(oldCrddetInfo.getCustdet_id());
           newCrddetInfo.recalculateCustcode();
           newCrddetInfo.setAccdet_id(oldCrddetInfo.getAccdet_id());
           newCrddetInfo.recalculateAccnoCurrcode();
           if (newCrddetInfo.getBranch_id() != oldCrddetInfo.getBranch_id()){
           newCrddetInfo.setBranch_id(oldCrddetInfo.getBranch_id());
           newCrddetInfo.recalculateInstCodeBranchCode();
           }
           newCrddetInfo.setFirstname(oldCrddetInfo.getFirstname());
           newCrddetInfo.setLastname(oldCrddetInfo.getLastname());
           newCrddetInfo.setTitle(oldCrddetInfo.getTitle());
           newCrddetInfo.setDeliv_brncode(oldCrddetInfo.getDeliv_brncode());
           newCrddetEntity.setCrddetInfo(newCrddetInfo);
           
           //updating crdacc
           IaGlobalFunctions.insertCrdAcc(bREReplaceLostOrStolenCardsInfo.getOldPan(),
            							   bREReplaceLostOrStolenCardsInfo.getNewPan(),
                                           new Integer(bREReplaceLostOrStolenCardsInfo.getOldSeqno()).intValue(),
                                           new Integer(bREReplaceLostOrStolenCardsInfo.getNewSeqno()).intValue());
           
           //charge data insert
           java.sql.Date ctxDate = null;
           String chargeCur = "";
           int chargeType = 0;
           tobjStmt = tobjConnection.createStatement();
           tobjRs = tobjStmt.executeQuery(SQLConstants.GET_POPULATE_SYSTEM_DATE_SQL);
           if(tobjRs.next())
           {
        	   ctxDate = tobjRs.getDate(SQLConstants.GET_POPULATE_SYSTEM_DATE_DATE);
           }
           
           if(oldCrddetInfo.getStatcode().equals("04") || oldCrddetInfo.getStatcode().equals("05"))
           {
        	   chargeType = IChConstant.CHRG_CRD_REPLOST;
           }
           else if(oldCrddetInfo.getStatcode().equals("08"))
           {
        	   chargeType = IChConstant.CHRG_CRD_REPFRAUD;
           }
           else
           {
        	   chargeType = IChConstant.CHRG_CRD_REPLACEMENT;
           }
        	
           tobjpstmt = tobjConnection.prepareStatement(SQLConstants.GET_CARDSTATUS_CRDDET_QUERY6);
           String pan_enc = BasicPanCryptor.getInstance().encryptPan(bREReplaceLostOrStolenCardsInfo.getNewPan());
           tobjpstmt.setString(1,pan_enc);
           tobjpstmt.setInt(2, new Integer(bREReplaceLostOrStolenCardsInfo.getNewSeqno()).intValue());
           tobjRs = tobjpstmt.executeQuery();
           if(tobjRs.next())
           {
        	   chargeCur = tobjRs.getString(SQLConstants.GET_CARDSTATUS_CURRCODE).trim();
           }
           tobjpstmt = tobjConnection.prepareStatement(SQLConstantsBre.REPLACE_CARD_CHARGEDATA_INSERT);
           tobjpstmt.setDate(1, ctxDate);
           tobjpstmt.setLong(2, newCrddetInfo.getId());
           tobjpstmt.setInt(3, chargeType);
           tobjpstmt.setString(4, chargeCur);
           tobjpstmt.executeUpdate();
           
           //Insertion of the CRDRPLACE record
           tobjpstmt = tobjConnection.prepareStatement(SQLConstantsBre.UDPATE_CRDRPLACE);
           tobjpstmt.setInt(1, 1);
           tobjpstmt.setDate(2, (new java.sql.Date(System.currentTimeMillis())));
           tobjpstmt.setString(3, mctx.getCallerPrincipal().getName());
           tobjpstmt.setString(4, "Operator request");
           tobjpstmt.setLong(5, newCrddetInfo.getId());
           tobjpstmt.setLong(6, oldCrddetInfo.getId());
           tobjpstmt.executeUpdate();
       }
       catch(SQLException e)
       {
           debugLib.logError(CLASSNAME,e.toString(),mctx.getCallerPrincipal().getName());
           throw new serverException("error.error.cardreplacement");
       }
       catch(serverException e)
       {
    	   debugLib.logError(CLASSNAME,e.toString(),mctx.getCallerPrincipal().getName());
           throw e;
       }
       catch(Exception e)
       {
           debugLib.logError(CLASSNAME,e.toString(),mctx.getCallerPrincipal().getName());
           throw new serverException("error.error.cardreplacement");
       }
       finally 
		{
			try 
			{
				if (tobjConnection != null) 
				{
					dbLib.closeConnection(tobjConnection);
					dbLib.closeResultSet(tobjRs);
					dbLib.closeStatement(tobjpstmt);
					dbLib.closeStatement(tobjStmt);
				}
			} catch (Exception e) 
			{
				debugLib.logError(CLASSNAME, e.toString());
			}
		}
	   
   }
   
    public void  ejbCreate()
        throws javax.ejb.CreateException
    {
        try
        {
            home = (CustIdCodeEntityHome)ServiceLocator.getInstance().getRemoteHome(serverConstantBre.VIEW_CUST_IDCODE_ENTITY, CustIdCodeEntityHome.class);
            mobjCrddetHomeCacheController = new HomeCacheController (serverConstant.VIEW_CRDDET_ENTITY, CrddetEntityHome.class);
            mobjCrddetHomeCacheController.refreshHome();
        }
        catch (Exception e)
        {
            debugLib.logError(CLASSNAME, e);
            throw new javax.ejb.CreateException (e.toString());
        }
    }


    //Implementing SessionBeanInterface methods.....//
    public void setSessionContext(SessionContext pctx)
        throws javax.ejb.EJBException, java.rmi.RemoteException
    {
        this.mctx = pctx;
    }

    public void ejbRemove()
        throws javax.ejb.EJBException, java.rmi.RemoteException
    {
    }

    public void ejbActivate()
        throws javax.ejb.EJBException, java.rmi.RemoteException
    {
    }

    public void ejbPassivate()
        throws javax.ejb.EJBException, java.rmi.RemoteException
    {
    }

}
