package com.cortex.cust.bre.gui.ia.sessionejb;

import java.rmi.RemoteException;

import javax.ejb.EJBHome;

/**
 * @author : Y.Vinay Kumar
 */
public interface BREAccdetMgrHome extends EJBHome
{
    public BREAccdetMgr create()
      throws javax.ejb.CreateException,RemoteException ;
}
