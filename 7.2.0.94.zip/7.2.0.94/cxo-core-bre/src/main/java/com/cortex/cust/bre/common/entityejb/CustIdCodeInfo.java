package com.cortex.cust.bre.common.entityejb;

import java.io.Serializable;

import com.cortex.common.interfaces.IResultInfo;

/**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project no: <br>
 * Use case no: <br>
 * Use case name: Cust_idcodeInfo<br>
 * Date created: 19/04/2002 09:35 </h4><hr>
 *
 * @author j2eegen
 */
public class CustIdCodeInfo  implements IResultInfo, Serializable
{

    private long verno_ctx=0;
    private long custdet_id = 0;
    private long id = 0;
    private long idtype_id = 0;
    private String identificationCode = "";
    
    private String msInstCode = "";
    private String msCustCode = "";
    private String msCustName = "";
    

    public long getVerno_ctx()
    {
        return verno_ctx;
    }
    public void setVerno_ctx(long newVerno_ctx)
    {
        this.verno_ctx = newVerno_ctx;
    }

    public long getIdtype_id()
    {
        return idtype_id;
    }
    public void setIdtype_id(long newIdtype_id)
    {
        this.idtype_id = newIdtype_id;
    }

    public long getId()
    {
        return id;
    }
    public void setId(long newId)
    {
        this.id = newId;
    }

    public long getCustdet_id()
    {
        return custdet_id;
    }
    public void setCustdet_id(long newCustdet_id)
    {
        this.custdet_id = newCustdet_id;
    }
    
	public String getInstCode() {
		return msInstCode;
	}
	public void setInstCode(String msInstCode) {
		this.msInstCode = msInstCode;
	}
	public String getCustCode() {
		return msCustCode;
	}
	public void setCustCode(String msCustCode) {
		this.msCustCode = msCustCode;
	}
	public String getCustName() {
		return msCustName;
	}
	public void setCustName(String msCustName) {
		this.msCustName = msCustName;
	}
	public String getIdentificationCode() {
		return identificationCode;
	}
	public void setIdentificationCode(String identificationCode) {
		this.identificationCode = identificationCode;
	}
	
}
