package com.cortex.cust.bre.gui.ia.valueobj;

import java.io.Serializable;

/**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project No           : 1103  <br>
 * Module Name          : Ia<br>
 * Global Use Case      : N/A<br>
 * Business Use case    : N/A<br>
 * Maintenance Use case : N/A<br>
 * @author                j2eegen
 *
 * This is the Info class used for the cust_idcode search screen.
 * This info object must contain setXXX/getXXX methods for all
 * the fields to be used in the search criteria and those
 * of the search results list
 *
 * Date   Author     Reviewer    Description of change<br>
 *
 * @version 1.0
 */

public class CustIdCodeSearchInfo implements Serializable
{
    private String msCustdet_id = "";
    private String msId = "";
    private String msIdcode = "";
    private String msIdtype_id = "";
    
    private String msInstCode = "";
    private String msCustCode = "";
    private String msCustName = "";
    private int msCustId = 0;
    private String indentificationTypeCode = "";
    private String indentificationTypeDesc = "";
    private String indentificationCode = "";

                                                            // custdet_id
    /**
     * Get the custdet_id field from the form
     *
     * @return the custdet_id value
     */
    public String getCustdet_id()
    {
        return msCustdet_id;
    }
    /**
     * Set the custdet_id field into the form
     *
     * @param psCustdet_id the custdet_id value
     */
    public void setCustdet_id(String psCustdet_id)
    {
        msCustdet_id = psCustdet_id;
    }

                                                            // id
    /**
     * Get the id field from the form
     *
     * @return the id value
     */
    public String getId()
    {
        return msId;
    }
    /**
     * Set the id field into the form
     *
     * @param psId the id value
     */
    public void setId(String psId)
    {
        msId = psId;
    }

                                                            // idcode
    /**
     * Get the idcode field from the form
     *
     * @return the idcode value
     */
    public String getIdcode()
    {
        return msIdcode;
    }
    /**
     * Set the idcode field into the form
     *
     * @param psIdcode the idcode value
     */
    public void setIdcode(String psIdcode)
    {
        msIdcode = psIdcode;
    }

                                                            // idtype_id
    /**
     * Get the idtype_id field from the form
     *
     * @return the idtype_id value
     */
    public String getIdtype_id()
    {
        return msIdtype_id;
    }
    /**
     * Set the idtype_id field into the form
     *
     * @param psIdtype_id the idtype_id value
     */
    public void setIdtype_id(String psIdtype_id)
    {
        msIdtype_id = psIdtype_id;
    }
    /**
     * get inst code
     * 
     * @return
     */
	public String getInstCode() {
		return msInstCode;
	}
	/**
	 * set inst code
	 * 
	 * @param msInstCode
	 */
	public void setInstCode(String msInstCode) {
		this.msInstCode = msInstCode;
	}
	/**
	 * get cust code
	 * 
	 * @return
	 */
	public String getCustCode() {
		return msCustCode;
	}
	/**
	 * set cust code
	 * 
	 * @param msCustCode
	 */
	public void setCustCode(String msCustCode) {
		this.msCustCode = msCustCode;
	}
	/**
	 * get customer name 
	 * 
	 * @return
	 */
	public String getCustName() {
		return msCustName;
	}
	/**
	 * set customer name 
	 * 
	 * @param msCustName
	 */
	public void setCustName(String msCustName) {
		this.msCustName = msCustName;
	}
	/**
	 * @return the msCustId
	 */
	public int getCustId() {
		return msCustId;
	}
	/**
	 * @param msCustId the msCustId to set
	 */
	public void setCustId(int msCustId) {
		this.msCustId = msCustId;
	}
	/**
	 * 
	 * @return
	 */
	public String getIndentificationCode() {
		return indentificationCode;
	}
	/**
	 * 
	 * @param indentificationCode
	 */
	public void setIndentificationCode(String indentificationCode) {
		this.indentificationCode = indentificationCode;
	}
	/**
	 * 
	 * @return
	 */
	public String getIndentificationTypeCode() {
		return indentificationTypeCode;
	}
	/**
	 * 
	 * @param indentificationTypeCode
	 */
	public void setIndentificationTypeCode(String indentificationTypeCode) {
		this.indentificationTypeCode = indentificationTypeCode;
	}
	/**
	 * 
	 * @return
	 */
	public String getIndentificationTypeDesc() {
		return indentificationTypeDesc;
	}
	/**
	 * 
	 * @param indentificationTypeDesc
	 */
	public void setIndentificationTypeDesc(String indentificationTypeDesc) {
		this.indentificationTypeDesc = indentificationTypeDesc;
	}

}
