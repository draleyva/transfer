/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cortex.cust.bre.gui.ia.sessionejb;

import com.cortex.common.exception.serverException;
import com.cortex.gui.common.valueobj.PagingContextInfo;
import com.cortex.gui.ia.valueobj.CardStatusChangeHistorySearchInfo;
import com.cortex.gui.ia.valueobj.SetCardStatusDetailInfo;
import java.rmi.RemoteException;
import java.util.ArrayList;
import javax.ejb.EJBHome;
import javax.ejb.EJBObject;

/**
 *
 * @author FIS
 */
public interface BRECardStatusMgr  extends EJBObject  {
    	/**
	 * This method is to search the CardStatus details.
	 *
	 * @param CardStatusChangeHistorySearchInfo
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws serverException
	 */
	public ArrayList searchCardStatusChangeHistory(CardStatusChangeHistorySearchInfo pobjCardStatusChangeHistorySearchInfo, PagingContextInfo pobjPagingContextInfo)throws RemoteException, serverException;
	/**
	 * This method is to search the CardStatus details.
	 *
	 * @param CardStatusChangeHistorySearchInfo
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws serverException
	 */
	public ArrayList searchCardStatusChangeHistory1(CardStatusChangeHistorySearchInfo pobjCardStatusChangeHistorySearchInfo, PagingContextInfo pobjPagingContextInfo)throws RemoteException, serverException;

	/**
	 * This method is to edit the SetCardStatus details.
	 *
	 * @param SetCardStatusDetailInfo
	 * @return SetCardStatusDetailInfo
	 * @throws RemoteException
	 * @throws serverException
	 */
	public SetCardStatusDetailInfo editSetCardStatus(SetCardStatusDetailInfo pobjSetCardStatusDetailInfo)throws RemoteException, serverException;
	/**
	 * This method is to add the card status detail.
	 * @param SetCardStatusDetailInfo
	 * @throws RemoteException
	 * @throws serverException
	 */
	public SetCardStatusDetailInfo addCardStatus(SetCardStatusDetailInfo pobjSetCardStatusDetailInfo, String acsitem)throws RemoteException, serverException;
	/**
	 * This method is to return additional card/customer information.
	 * @param GetCrdCustInfo
	 * @throws RemoteException
	 * @throws serverException
	 */
	public SetCardStatusDetailInfo getCrdCustInfo( String psPan, int piSeqno ) throws RemoteException, serverException;

	/**
	 * This method return the configured status code for card activation (from msc table)
	 * @return
	 * @throws RemoteException
	 * @throws serverException
	 */
	public String getConfiguredStatusCode() throws RemoteException, serverException;

	/** 
	 * Get the expiry date/old expiry date for the card.
	 * @param pobjSetCardStatusDetailInfo
	 * @return
	 * @throws RemoteException
	 * @throws serverException
	 */
	public SetCardStatusDetailInfo getExpiryDate(SetCardStatusDetailInfo pobjSetCardStatusDetailInfo)throws RemoteException, serverException;
	
	/**
	 * 
	 * @param crdproduct
	 * @param toStatus
	 * @param fromOldStatus
	 * @param fromCurrentStatus
	 * @param oldOrNewOrBoth
	 * @return
	 * @throws RemoteException
	 * @throws serverException
	 */
	public boolean isTransitionAllowed(String crdproduct, String toStatus, String fromOldStatus, String fromCurrentStatus, String oldOrNewOrBoth, boolean hasOldCard) throws RemoteException, serverException;


}
