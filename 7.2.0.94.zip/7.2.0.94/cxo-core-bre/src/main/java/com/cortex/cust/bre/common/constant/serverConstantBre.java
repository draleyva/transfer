package com.cortex.cust.bre.common.constant;

public class serverConstantBre
{
  public static String VIEW_CUST_IDCODE_SESSION = "CustIdCodeMgr";
	public static String VIEW_CUST_IDCODE_ENTITY = "CustIdCodeEJB";
 	public static String VIEW_BREACCDET_SESSION = "BREAccdetMgr";
  public static String VIEW_BRE_CRDSTHST_SESSION = "BRECardStatusMgr";
  
 	public static String GET_CUSTOMER_CUST_CODE = "custcode";
 	public static String GET_CUSTOMER_INST_CODE = "instcode";
 	public static String GET_CUSTOMER_NAME = "custname";
 	
 	public static String GET_REPLACE_VIRTUAL_PAN = "virtualPan";
 	public static String GET_REPLACE_PAN = "pan";
 	public static String GET_REPLACE_SEQNO = "seqno"; 
 	public static String GET_REPLACE_PAN_DISPLAY = "panDisplay";
 	public static String GET_REPLACE_STATECODE = "statcode";
 	public static String GET_REPLACE_STATECODE_DESC = "statusdesc"; 
 	public static String GET_REPLACE_BATCH = "batch";
 	public static String GET_REPLACE_CARDPRODUCT = "crdproduct"; 
 	public static String GET_REPLACE_CUST_NAME = "customerName";
 	public static String GET_REPLACE_INST_CODE = "instcode";
 	public static String GET_STATE_CODE_FOUR = "04";
 	public static String GET_STATE_CODE_FIVE = "05";
 	public static String GET_STATE_CODE_EIGHT = "08";
 	public static String GET_STATE_CODE_FIFTEEN = "15";

	public static String ALLOW_SECONDARY_CARDS = "AllowSecondaryCards";	
}
