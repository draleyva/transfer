package com.cortex.cust.bre.gui.ia.sessionejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import com.cortex.common.constant.INovusConstant;
import com.cortex.common.constant.SQLConstants;
import com.cortex.common.constant.globalConstant;
import com.cortex.common.constant.serverConstant;
import com.cortex.common.entityejb.CdsthstEntityHome;
import com.cortex.common.entityejb.CdsthstInfo;
import com.cortex.common.entityejb.CrddetEntity;
import com.cortex.common.entityejb.CrddetEntityHome;
import com.cortex.common.entityejb.CrddetInfo;
import com.cortex.common.entityejb.CrddetSK;
import com.cortex.common.entityejb.CrdpinEntity;
import com.cortex.common.entityejb.CrdpinEntityHome;
import com.cortex.common.entityejb.CrdpinInfo;
import com.cortex.common.entityejb.CrdpinSK;
import com.cortex.common.entityejb.CustdetEntity;
import com.cortex.common.entityejb.CustdetEntityHome;
import com.cortex.common.entityejb.CustdetInfo;
import com.cortex.common.entityejb.CustdetSK;
import com.cortex.common.exception.serverException;
import com.cortex.common.hook.HookFactory;
import com.cortex.common.hook.HookParam;
import com.cortex.common.interfaces.IResultInfo;
import com.cortex.common.lib.CommonLib;
import com.cortex.common.lib.FunctionLib;
import com.cortex.common.lib.HomeCacheController;
import com.cortex.common.lib.dateTimeLib;
import com.cortex.common.lib.dbLib;
import com.cortex.common.lib.debugLib;
import com.cortex.gui.co.constant.ICoConstant;
import com.cortex.gui.common.constant.IChConstant;
import com.cortex.gui.common.constant.viewConstant;
import com.cortex.gui.common.lib.AuditPanMask;
import com.cortex.gui.common.lib.BaseSessionBean;
import com.cortex.gui.common.lib.BasicPanCryptor;
import com.cortex.gui.common.lib.CommonGlobalFunctions;
import com.cortex.gui.common.lib.IaGlobalFunctions;
import com.cortex.gui.common.lib.PageWithSorting;
import com.cortex.gui.common.lib.PagingInterface;
import com.cortex.gui.common.lib.PanSeqno;
import com.cortex.gui.common.lib.WhereClauseLib;
import com.cortex.gui.common.sessionejb.IaCommonGlobalFunctionsMgr;
import com.cortex.gui.common.sessionejb.IaCommonGlobalFunctionsMgrHome;
import com.cortex.gui.common.valueobj.CrdeventDetailInfo;
import com.cortex.gui.common.valueobj.PageWithSortingDataInfo;
import com.cortex.gui.common.valueobj.PagingContextInfo;
import com.cortex.gui.common.valueobj.WhereClauseInfo;
import com.cortex.gui.ia.valueobj.CardStatusChangeHistorySearchInfo;
import com.cortex.gui.ia.valueobj.SetCardStatusDetailInfo;
import com.cortex.cust.bre.common.constant.SQLConstantsBre;
import com.cortex.gui.ia.valueobj.CardStatusTags;

/**
 *
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project No : 1103  <br>
 * Module Name : Issuer Authorizer<br>
 * Use case ref : UC0070<br>
 * Use case name : changeCardStatus<br>
 * Version No : 1.0<br>
 * Date created : 05/08/2002 <br>
 *
 * Description : This is the Bean implementation of the Sessionbean<br>
 *
 * Date Author Reviewer Description of change 05/08/2002 Nithila S./Sunandha R.
 *
 * @author Sunandha R./Tapasvi/Nithila Modified to fix TR-0970 :by Vinay
 * Modified to fix AT TR - 0897: by Beena
 *
 */
public class BRECardStatusMgrBean extends BaseSessionBean implements PagingInterface {

    /**
     * Attributes declaration
     */
    private HomeCacheController mobjHomeCacheController = null;
    private HomeCacheController mobjHomeCacheController1 = null;
    private HomeCacheController mobjHomeCacheController2 = null;    // Crddet
    private HomeCacheController mobjHomeCacheController3 = null;    // Custdet
    private HomeCacheController mobjIaCommonGlobalHomeCacheController = null;

    private static final String CLASSNAME = "BRECardStatusMgrBean";
    private SetCardStatusDetailInfo mobjSetCardStatusDetailInfo = null;

    /**
     * This method is to search the CardStatus details.
     *
     * @param CardStatusChangeHistorySearchInfo
     * @return ArrayList
     * @throws RemoteException
     * @throws serverException
     */
    public ArrayList searchCardStatusChangeHistory(CardStatusChangeHistorySearchInfo pobjCardStatusChangeHistorySearchInfo,
            PagingContextInfo pobjPagingContextInfo)
            throws RemoteException, serverException {
        ArrayList tobjSearchInfo = new ArrayList();
        boolean tbWhereFlag = true;
        try {

            pobjPagingContextInfo.setPKColumnAliasName(SQLConstants.GET_IA_CRDSTHST_SEARCH_PK_ALIAS_NAME);
            pobjPagingContextInfo.setPKVariableType(false);
            pobjPagingContextInfo.setPKColumn(SQLConstants.GET_IA_CRDSTHST_SEARCH_PK);
            pobjPagingContextInfo.setSortVariableType(false);

            //Added to fix TR-0970:Vinay
            pobjPagingContextInfo.setSortDirection(false);

            if (pobjPagingContextInfo.getSortColumn().trim().length() == 0) {
                pobjPagingContextInfo.setSortColumn(SQLConstants.GET_IA_CRDSTHST_SEARCH_DATE_SET_TIME_SET_NAME);
            }

            // SQL Injection protection - pass this vector to the paging to build the query using a prepared statement
            Vector whereClauseInfo = getWhereForSearch(pobjCardStatusChangeHistorySearchInfo);
            // String tsWhereClause = WhereClauseLib.formPreparedWhereClauseWithoutValue(whereClauseInfo);
            String tsWhereClause = WhereClauseLib.formPreparedWhereClause(whereClauseInfo);

            String tsSQlQuery = SQLConstants.GET_IA_CRDSTHST_SEARCH_SQL;
            String tsCountQuery = SQLConstants.GET_IA_CRDSTHST_SEARCH_COUNT_SQL;

            tbWhereFlag = false;
            if (!(tsWhereClause.trim().equals(""))) {
                tsSQlQuery += " and " + tsWhereClause;
                tsCountQuery += " and " + tsWhereClause;
            }

            PageWithSortingDataInfo tobjPageWithSortingDataInfo = new PageWithSortingDataInfo();
            tobjPageWithSortingDataInfo.msSelectQry = tsSQlQuery;
            tobjPageWithSortingDataInfo.msCountQry = tsCountQuery;
            tobjPageWithSortingDataInfo.miCountColumn = SQLConstants.GET_IA_CRDSTHST_SEARCH_COUNT;
            tobjPageWithSortingDataInfo.miPKAliasColumn = SQLConstants.GET_IA_CRDSTHST_SEARCH_PK_ALIAS;
            tobjPageWithSortingDataInfo.miSortColumn = SQLConstants.GET_IA_CRDSTHST_SEARCH_DATE_SET;
            tobjPageWithSortingDataInfo.mbWhereFlag = tbWhereFlag;
            tobjPageWithSortingDataInfo.mobjPagingContextInfo = pobjPagingContextInfo;
            tobjPageWithSortingDataInfo.mobjPagingInterface = (PagingInterface) this;
            // Set the wherClauseInfo into the PageWithSortingDataInfo to get to the prepared statement parameters
            tobjPageWithSortingDataInfo.whereClauseInfo = whereClauseInfo;

            PageWithSorting tobjPageWithSorting = new PageWithSorting();
            tobjSearchInfo = tobjPageWithSorting.getSearchDetails(tobjPageWithSortingDataInfo);
        } catch (serverException se) {
            debugLib.logError(CLASSNAME, se, mobjSessionContext.getCallerPrincipal().getName());
            throw se;
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.unknownerror");
        }

        return tobjSearchInfo;
    }

    /**
     * A generalised SQL Where clause
     *
     * @param CardStatusChangeHistorySearchInfo
     * @return String
     * @exception none
     */
    private Vector getWhereForSearch(CardStatusChangeHistorySearchInfo pobjCardStatusChangeHistorySearchInfo) throws serverException {
        Vector tvecWhereClauseInfo = new Vector();

        if (!pobjCardStatusChangeHistorySearchInfo.getPan().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo1 = new WhereClauseInfo();
            tobjWhereClauseInfo1.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_PAN_NAME);
            tobjWhereClauseInfo1.setVariableValue(BasicPanCryptor.getInstance().encryptPan(pobjCardStatusChangeHistorySearchInfo.getPan().trim()));
            tobjWhereClauseInfo1.setVaribleType(globalConstant.WHERE_TYPE_STRING);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo1);
        }
        if (!(pobjCardStatusChangeHistorySearchInfo.getStrSeqno().trim().equals(""))) {
            WhereClauseInfo tobjWhereClauseInfo2 = new WhereClauseInfo();
            tobjWhereClauseInfo2.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_SEQNO_NAME);
            tobjWhereClauseInfo2.setVariableValue(pobjCardStatusChangeHistorySearchInfo.getStrSeqno().trim());
            tobjWhereClauseInfo2.setVaribleType(globalConstant.WHERE_TYPE_INT);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo2);
        }

        return tvecWhereClauseInfo;
    }

    /**
     * This method is to search the CardStatus details.
     *
     * @param CardStatusChangeHistorySearchInfo
     * @return ArrayList
     * @throws RemoteException
     * @throws serverException
     */
    public ArrayList searchCardStatusChangeHistory1(CardStatusChangeHistorySearchInfo pobjCardStatusChangeHistorySearchInfo,
            PagingContextInfo pobjPagingContextInfo)
            throws RemoteException, serverException {
        ArrayList tobjSearchInfo = new ArrayList();
        boolean tbWhereFlag = true;
        try {

            pobjPagingContextInfo.setPKColumnAliasName(SQLConstants.GET_IA_CRDSTHST_SEARCH_PK_ALIAS_NAME);
            pobjPagingContextInfo.setPKVariableType(false);
            pobjPagingContextInfo.setPKColumn(SQLConstants.GET_IA_CRDSTHST_SEARCH_PK);
            pobjPagingContextInfo.setSortVariableType(false);

            //Added to fix TR-0970:Vinay
            pobjPagingContextInfo.setSortDirection(false);

            if (pobjPagingContextInfo.getSortColumn().trim().length() == 0) {
                pobjPagingContextInfo.setSortColumn(SQLConstants.GET_IA_CRDSTHST_SEARCH_DATE_SET_TIME_SET_NAME);
            }

            Vector whereClauseInfo = getWhereForSearch1(pobjCardStatusChangeHistorySearchInfo);
//           String tsWhereClause = WhereClauseLib.formPreparedWhereClauseWithoutValue(whereClauseInfo);

            String tsWhereClause = WhereClauseLib.formPreparedWhereClause(whereClauseInfo);

            String tsSQlQuery = SQLConstants.GET_IA_CRDSTHST_SEARCH_SQL;
            String tsCountQuery = SQLConstants.GET_IA_CRDSTHST_SEARCH_COUNT_SQL;

            tbWhereFlag = false;
            if (!(tsWhereClause.trim().equals(""))) {
                tsSQlQuery += " and " + tsWhereClause;
                tsCountQuery += " and " + tsWhereClause;
            }

            PageWithSortingDataInfo tobjPageWithSortingDataInfo = new PageWithSortingDataInfo();
            tobjPageWithSortingDataInfo.msSelectQry = tsSQlQuery;
            tobjPageWithSortingDataInfo.msCountQry = tsCountQuery;
            tobjPageWithSortingDataInfo.miCountColumn = SQLConstants.GET_IA_CRDSTHST_SEARCH_COUNT;
            tobjPageWithSortingDataInfo.miPKAliasColumn = SQLConstants.GET_IA_CRDSTHST_SEARCH_PK_ALIAS;
            tobjPageWithSortingDataInfo.miSortColumn = SQLConstants.GET_IA_CRDSTHST_SEARCH_PAN;
            tobjPageWithSortingDataInfo.mbWhereFlag = tbWhereFlag;
            tobjPageWithSortingDataInfo.mobjPagingContextInfo = pobjPagingContextInfo;
            tobjPageWithSortingDataInfo.mobjPagingInterface = (PagingInterface) this;
            tobjPageWithSortingDataInfo.whereClauseInfo = whereClauseInfo;

            PageWithSorting tobjPageWithSorting = new PageWithSorting();
            tobjSearchInfo = tobjPageWithSorting.getSearchDetails(tobjPageWithSortingDataInfo);
        } catch (serverException se) {
            debugLib.logError(CLASSNAME, se, mobjSessionContext.getCallerPrincipal().getName());
            throw se;
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.unknownerror");
        }

        return tobjSearchInfo;
    }

    /**
     * A generalised SQL Where clause
     *
     * @param CardStatusChangeHistorySearchInfo
     * @return String
     * @exception none
     */
    private Vector getWhereForSearch1(CardStatusChangeHistorySearchInfo pobjCardStatusChangeHistorySearchInfo) throws serverException {
        Vector tvecWhereClauseInfo = new Vector();

        if (!pobjCardStatusChangeHistorySearchInfo.getPan().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo1 = new WhereClauseInfo();
            tobjWhereClauseInfo1.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_PAN_NAME);
            tobjWhereClauseInfo1.setVariableValue(BasicPanCryptor.getInstance().encryptPan(pobjCardStatusChangeHistorySearchInfo.getPan().trim()));
            tobjWhereClauseInfo1.setVaribleType(globalConstant.WHERE_TYPE_STRING);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo1);
        }
        if (!pobjCardStatusChangeHistorySearchInfo.getVirtualPan().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo = new WhereClauseInfo();
            tobjWhereClauseInfo.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_VIRTUALPAN_NAME);
            tobjWhereClauseInfo.setVariableValue(pobjCardStatusChangeHistorySearchInfo.getVirtualPan().trim());
            tobjWhereClauseInfo.setVaribleType(globalConstant.WHERE_TYPE_STRING);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo);
        }

        if (!(pobjCardStatusChangeHistorySearchInfo.getStrSeqno().trim().equals(""))) {
            WhereClauseInfo tobjWhereClauseInfo2 = new WhereClauseInfo();
            tobjWhereClauseInfo2.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_SEQNO_NAME);
            tobjWhereClauseInfo2.setVariableValue(pobjCardStatusChangeHistorySearchInfo.getStrSeqno().trim());
            tobjWhereClauseInfo2.setVaribleType(globalConstant.WHERE_TYPE_INT);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo2);
        }

        if (!pobjCardStatusChangeHistorySearchInfo.getStrDateset().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo3 = new WhereClauseInfo();
            tobjWhereClauseInfo3.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_DATE_SET_NAME);
            tobjWhereClauseInfo3.setVariableValue(pobjCardStatusChangeHistorySearchInfo.getStrDateset().trim());
            tobjWhereClauseInfo3.setVaribleType(globalConstant.WHERE_TYPE_DATE);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo3);
        }

        if (!pobjCardStatusChangeHistorySearchInfo.getNewstatcode().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo3 = new WhereClauseInfo();
            tobjWhereClauseInfo3.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_NEW_STATCODE_NAME);
            tobjWhereClauseInfo3.setVariableValue(pobjCardStatusChangeHistorySearchInfo.getNewstatcode().trim());
            tobjWhereClauseInfo3.setVaribleType(globalConstant.WHERE_TYPE_STRING);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo3);
        }

        if (!pobjCardStatusChangeHistorySearchInfo.getOldstatcode().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo3 = new WhereClauseInfo();
            tobjWhereClauseInfo3.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_OLD_STATCODE_NAME);
            tobjWhereClauseInfo3.setVariableValue(pobjCardStatusChangeHistorySearchInfo.getOldstatcode().trim());
            tobjWhereClauseInfo3.setVaribleType(globalConstant.WHERE_TYPE_STRING);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo3);
        }

        if (!pobjCardStatusChangeHistorySearchInfo.getWhoset().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo3 = new WhereClauseInfo();
            tobjWhereClauseInfo3.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_WHO_SET_NAME);
            tobjWhereClauseInfo3.setVariableValue(pobjCardStatusChangeHistorySearchInfo.getWhoset().trim());
            tobjWhereClauseInfo3.setVaribleType(globalConstant.WHERE_TYPE_STRING);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo3);
        }

        return tvecWhereClauseInfo;
    }

    /**
     * Method used by the Paging with sorting form to populate the data.
     *
     * @param ResultSet
     *
     * @return Object.
     *
     * @exception serverException if there is an exception
     */
    public Object getDataFromCachedRowset(ResultSet pobjResultSet) {
        //Should be replaced with the result info depending upon the search criteria obtained from the client
        CardStatusChangeHistorySearchInfo tobjCardStatusChangeHistorySearchInfo = null;

        try {
            tobjCardStatusChangeHistorySearchInfo = new CardStatusChangeHistorySearchInfo();
            tobjCardStatusChangeHistorySearchInfo.setStrDateset(pobjResultSet.getString(
                    SQLConstants.GET_IA_CRDSTHST_SEARCH_DATE_SET));
            tobjCardStatusChangeHistorySearchInfo.setStrTimeset(pobjResultSet.getString(
                    SQLConstants.GET_IA_CRDSTHST_SEARCH_TIME_SET));
            tobjCardStatusChangeHistorySearchInfo.setNewstatcode(pobjResultSet.getString(
                    SQLConstants.GET_IA_CRDSTHST_SEARCH_NEW_STATCODE));
            tobjCardStatusChangeHistorySearchInfo.setOldstatcode(pobjResultSet.getString(
                    SQLConstants.GET_IA_CRDSTHST_SEARCH_OLD_STATCODE));
            tobjCardStatusChangeHistorySearchInfo.setWhyset(pobjResultSet.getString(SQLConstants.GET_IA_CRDSTHST_SEARCH_WHY_SET));
            tobjCardStatusChangeHistorySearchInfo.setWhoset(pobjResultSet.getString(SQLConstants.GET_IA_CRDSTHST_SEARCH_WHO_SET));
            tobjCardStatusChangeHistorySearchInfo.setTimeset(pobjResultSet.getLong(SQLConstants.GET_IA_CRDSTHST_SEARCH_TIME_SET));
            tobjCardStatusChangeHistorySearchInfo.setPan(pobjResultSet.getString(SQLConstants.GET_IA_CRDSTHST_SEARCH_PAN));
            tobjCardStatusChangeHistorySearchInfo.setSeqno(pobjResultSet.getInt(SQLConstants.GET_IA_CRDSTHST_SEARCH_SEQNO));
            tobjCardStatusChangeHistorySearchInfo.setPanDisplay(pobjResultSet.getString(SQLConstants.GET_IA_CRDSTHST_SEARCH_PANDISPLAY));
            tobjCardStatusChangeHistorySearchInfo.setVirtualPan(pobjResultSet.getString(SQLConstants.GET_IA_CRDSTHST_SEARCH_VIRTUALPAN));
            tobjCardStatusChangeHistorySearchInfo.setExpdate(pobjResultSet.getDate(SQLConstants.GET_IA_CRDSTHST_SEARCH_EXPDATE));
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
        }
        return tobjCardStatusChangeHistorySearchInfo;
    }

    /**
     * This method is to edit the SetCardStatus details.
     *
     * @param SetCardStatusDetailInfo
     * @return SetCardStatusDetailInfo
     * @throws RemoteException
     * @throws serverException
     */
    public SetCardStatusDetailInfo getCrdCustInfo(String psPan, int piSeqno) throws serverException {
        SetCardStatusDetailInfo tobjSetCardStatusDetailInfo = null;
        String PAN = psPan;
        try {
            if (!BasicPanCryptor.getInstance().isPanEncrypted(psPan)) {
                PAN = BasicPanCryptor.getInstance().encryptPan(psPan);
                debugLib.logDetail(CLASSNAME, "Encrypting PAN");
            }

            CrddetEntityHome tobjCrddetEntityHome = (CrddetEntityHome) mobjHomeCacheController2.getHome(false);
            CrddetEntity tobjCrddetEntity = (CrddetEntity) tobjCrddetEntityHome.findBySecondaryKey(new CrddetSK(PAN, piSeqno));
            CrddetInfo tobjCrddetInfo = tobjCrddetEntity.getCrddetInfo();

            CustdetEntityHome tobjCustdetEntityHome = (CustdetEntityHome) mobjHomeCacheController3.getHome(false);
            CustdetEntity tobjCustdetEntity = (CustdetEntity) tobjCustdetEntityHome.findBySecondaryKey(new CustdetSK(tobjCrddetInfo.getInstcode(), tobjCrddetInfo.getCustcode()));
            CustdetInfo tobjCustdetInfo = tobjCustdetEntity.getCustdetInfo();

            tobjSetCardStatusDetailInfo = new SetCardStatusDetailInfo();

            tobjSetCardStatusDetailInfo.setInstcode(tobjCrddetInfo.getInstcode());
            tobjSetCardStatusDetailInfo.setPan(PAN);
            tobjSetCardStatusDetailInfo.setSeqno(piSeqno);
            tobjSetCardStatusDetailInfo.setClassid(tobjCrddetInfo.getClassid());

            // G.M. : 2004/july/27 : Without this check some cards are failing!
            if (!tobjCrddetInfo.getCorp().equals("") && tobjCrddetInfo.getCorp() != null) {
                tobjSetCardStatusDetailInfo.setCorp(tobjCrddetInfo.getCorp().trim());
            }

            tobjSetCardStatusDetailInfo.setAdditionalno(tobjCrddetInfo.getAdditionalno());
            tobjSetCardStatusDetailInfo.setBatch(new Integer(String.valueOf(tobjCrddetInfo.getBatch())).intValue());
            tobjSetCardStatusDetailInfo.setCrdproduct(tobjCrddetInfo.getCrdproduct());
            tobjSetCardStatusDetailInfo.setExpdate(String.valueOf(tobjCrddetInfo.getExpdate()));
            tobjSetCardStatusDetailInfo.setOldcardstat(tobjCrddetInfo.getOld_statcode());
            tobjSetCardStatusDetailInfo.setOldstat(tobjCrddetInfo.getStatcode());

            tobjSetCardStatusDetailInfo.setEmbossname(tobjCrddetInfo.getEmbossname());
            tobjSetCardStatusDetailInfo.setCustcode(tobjCustdetInfo.getCustcode());
            tobjSetCardStatusDetailInfo.setUsrdata(tobjCustdetInfo.getUsrdata1());
            tobjSetCardStatusDetailInfo.setDatebirth(tobjCustdetInfo.getDate_birth());
            getCustomerAddress(tobjSetCardStatusDetailInfo, tobjCrddetInfo.getAddrind());
            tobjSetCardStatusDetailInfo.setDisplayname(tobjCustdetInfo.getTitle() + " "
                    + tobjCustdetInfo.getFirstname() + " "
                    + tobjCustdetInfo.getLastname());

            //NMR12622 RN 20/12/04
            tobjSetCardStatusDetailInfo.setAccno(tobjCrddetInfo.getAccno());
            tobjSetCardStatusDetailInfo.setPanDisplay(tobjCrddetInfo.getPanDisplay());
            tobjSetCardStatusDetailInfo.setExt_custnum(tobjCrddetInfo.getExt_custnum());
        } catch (serverException se) {
            mobjSessionContext.setRollbackOnly();
            debugLib.logError(CLASSNAME, se.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("ia.error.setcardstatus.invalidpan");
        } catch (RemoteException re) {
            mobjSessionContext.setRollbackOnly();
            debugLib.logError(CLASSNAME, re.toString(), mobjSessionContext.getCallerPrincipal().getName());
            mobjHomeCacheController2.refreshHome();
            mobjHomeCacheController3.refreshHome();
            throw new serverException("co.error.unknownerror");
        } catch (Exception e) {
            mobjSessionContext.setRollbackOnly();
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.connectfailed");
        }
        return tobjSetCardStatusDetailInfo;
    }

    public SetCardStatusDetailInfo getExpiryDate(SetCardStatusDetailInfo pobjSetCardStatusDetailInfo) throws serverException {
        Connection tobjConn = null;
        PreparedStatement tobjPstmt = null;
        ResultSet tobjRs = null;
        try {
            tobjConn = dbLib.getConnection(globalConstant.DATA_SOURCE);
            tobjPstmt = tobjConn.prepareStatement(SQLConstants.GET_CARDSTATUS_CRDDET_QUERY);
            String pan_enc = BasicPanCryptor.getInstance().encryptPan(pobjSetCardStatusDetailInfo.getPan());
            tobjPstmt.setString(1, pan_enc);
            tobjPstmt.setInt(2, pobjSetCardStatusDetailInfo.getSeqno());
            debugLib.logInfo(CLASSNAME, SQLConstants.GET_CARDSTATUS_CRDDET_QUERY, mobjSessionContext.getCallerPrincipal().getName());
            debugLib.logInfo(CLASSNAME, pan_enc, mobjSessionContext.getCallerPrincipal().getName());
            debugLib.logInfo(CLASSNAME, (pobjSetCardStatusDetailInfo.getSeqno() + ""), mobjSessionContext.getCallerPrincipal().getName());
            tobjRs = tobjPstmt.executeQuery();
            if (tobjRs.next()) {
                pobjSetCardStatusDetailInfo.setOldcardexpdate(tobjRs.getDate(SQLConstants.GET_CARDSTATUS_CRDDET_OLDCARD_EXPDATE));
                pobjSetCardStatusDetailInfo.setDateExpdate(tobjRs.getDate(SQLConstants.GET_CARDSTATUS_CRDDET_EXPDATE));
            }
        } catch (SQLException se) {
            debugLib.logError(CLASSNAME, se.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        } finally {
            try {
                if (tobjConn != null) {
                    dbLib.closeConnection(tobjConn);
                }
            } catch (Exception e) {
                debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            }
        }
        return pobjSetCardStatusDetailInfo;
    }

    /**
     * This method is to edit the SetCardStatus details.
     *
     * @param SetCardStatusDetailInfo
     * @return SetCardStatusDetailInfo
     * @throws RemoteException
     * @throws serverException
     */
    public SetCardStatusDetailInfo editSetCardStatus(SetCardStatusDetailInfo pobjSetCardStatusDetailInfo) throws serverException {
        Connection tobjConn = null;
        PreparedStatement tobjPstmt = null;
        ResultSet tobjRs = null;
        int tiAddrind = 0;
        try {
            tobjConn = dbLib.getConnection(globalConstant.DATA_SOURCE);
            tobjPstmt = tobjConn.prepareStatement(SQLConstants.GET_CARDSTATUS_CRDDET_QUERY);
            String pan_enc = BasicPanCryptor.getInstance().encryptPan(pobjSetCardStatusDetailInfo.getPan());
            tobjPstmt.setString(1, pan_enc);
            tobjPstmt.setInt(2, pobjSetCardStatusDetailInfo.getSeqno());
            debugLib.logInfo(CLASSNAME, SQLConstants.GET_CARDSTATUS_CRDDET_QUERY,
                    mobjSessionContext.getCallerPrincipal().getName());
            debugLib.logInfo(CLASSNAME, pan_enc, mobjSessionContext.getCallerPrincipal().getName());
            debugLib.logInfo(CLASSNAME, (pobjSetCardStatusDetailInfo.getSeqno() + ""),
                    mobjSessionContext.getCallerPrincipal().getName());
            tobjRs = tobjPstmt.executeQuery();
            if (tobjRs.next()) {
                pobjSetCardStatusDetailInfo.setOldcardexpdate(tobjRs.getDate(SQLConstants.GET_CARDSTATUS_CRDDET_OLDCARD_EXPDATE));
                pobjSetCardStatusDetailInfo.setOldcardstat(tobjRs.getString(SQLConstants.GET_CARDSTATUS_CRDDET_OLDCARD_STATCODE));
                pobjSetCardStatusDetailInfo.setOldstat(tobjRs.getString(SQLConstants.GET_CARDSTATUS_CRDDET_STATCODE));
                pobjSetCardStatusDetailInfo.setClassid(tobjRs.getInt(SQLConstants.GET_CARDSTATUS_CRDDET_CLASSID));
                pobjSetCardStatusDetailInfo.setCustcode(tobjRs.getString(SQLConstants.GET_CARDSTATUS_CRDDET_CUSTCODE));
                pobjSetCardStatusDetailInfo.setEmbossname(tobjRs.getString(SQLConstants.GET_CARDSTATUS_CRDDET_EMBOSSNAME));
                pobjSetCardStatusDetailInfo.setUsrdata(tobjRs.getString(SQLConstants.GET_CARDSTATUS_CRDDET_USRDATA));
                pobjSetCardStatusDetailInfo.setCorp(tobjRs.getString(SQLConstants.GET_CARDSTATUS_CRDDET_CORP).trim());
                pobjSetCardStatusDetailInfo.setAdditionalno(tobjRs.getInt(SQLConstants.GET_CARDSTATUS_CRDDET_ADDITIONALNO));
                pobjSetCardStatusDetailInfo.setAccno(tobjRs.getString(SQLConstants.GET_CARDSTATUS_CRDDET_ACCNO));
                pobjSetCardStatusDetailInfo.setBatch(tobjRs.getInt(SQLConstants.GET_CARDSTATUS_CRDDET_BATCH));
                pobjSetCardStatusDetailInfo.setCrdproduct(tobjRs.getString(SQLConstants.GET_CARDSTATUS_CRDDET_CRDPRODUCT));
                pobjSetCardStatusDetailInfo.setDateExpdate(tobjRs.getDate(SQLConstants.GET_CARDSTATUS_CRDDET_EXPDATE));
                pobjSetCardStatusDetailInfo.setPanDisplay(tobjRs.getString(SQLConstants.GET_CARDSTATUS_CRDDET_PANDISPLAY));
                pobjSetCardStatusDetailInfo.setExt_custnum(tobjRs.getString(SQLConstants.GET_CARDSTATUS_CRDDET_EXTCUSTNUM));
                tiAddrind = tobjRs.getInt(SQLConstants.GET_CARDSTATUS_CRDDET_ADDRIND);
            } else {
                pobjSetCardStatusDetailInfo.setOldcardstat("");
                pobjSetCardStatusDetailInfo.setOldstat("");
                pobjSetCardStatusDetailInfo.setClassid(0);
                pobjSetCardStatusDetailInfo.setCustcode("");
                pobjSetCardStatusDetailInfo.setEmbossname("");
                pobjSetCardStatusDetailInfo.setUsrdata("");
                pobjSetCardStatusDetailInfo.setCorp("");
                pobjSetCardStatusDetailInfo.setAdditionalno(0);
                pobjSetCardStatusDetailInfo.setAccno("");
                pobjSetCardStatusDetailInfo.setBatch(0);
                pobjSetCardStatusDetailInfo.setCrdproduct("");
            }

        } catch (SQLException se) {
            debugLib.logError(CLASSNAME, se.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        } finally {
            try {
                if (tobjConn != null) {
                    dbLib.closeConnection(tobjConn);
                }
            } catch (Exception e) {
                debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            }
        }
        //This validation is done before the Displayname validation because Custcode is required for the
        //retrieval of Displayname
        if (pobjSetCardStatusDetailInfo.getCustcode() == null || pobjSetCardStatusDetailInfo.getCustcode().equals("")) {
            throw new serverException("ia.error.CARD_NOT_FILE");
        }
        try {
            tobjConn = dbLib.getConnection(globalConstant.DATA_SOURCE);
            tobjPstmt = tobjConn.prepareStatement(SQLConstants.GET_CARDSTATUS_CUSTDET_QUERY);

            tobjPstmt.setString(1, pobjSetCardStatusDetailInfo.getInstcode());
            tobjPstmt.setString(2, pobjSetCardStatusDetailInfo.getCustcode());

            debugLib.logInfo(CLASSNAME, SQLConstants.GET_CARDSTATUS_CUSTDET_QUERY,
                    mobjSessionContext.getCallerPrincipal().getName());
            debugLib.logInfo(CLASSNAME, pobjSetCardStatusDetailInfo.getInstcode(),
                    mobjSessionContext.getCallerPrincipal().getName());
            debugLib.logInfo(CLASSNAME, pobjSetCardStatusDetailInfo.getCustcode(),
                    mobjSessionContext.getCallerPrincipal().getName());

            tobjRs = tobjPstmt.executeQuery();

            if (tobjRs.next()) {
                pobjSetCardStatusDetailInfo.setFirstname(tobjRs.getString(SQLConstants.GET_CARDSTATUS_CUSTDET_FIRSTNAME));
                pobjSetCardStatusDetailInfo.setLastname(tobjRs.getString(SQLConstants.GET_CARDSTATUS_CUSTDET_LASTNAME));
                pobjSetCardStatusDetailInfo.setTypeid(tobjRs.getInt(SQLConstants.GET_CARDSTATUS_CUSTDET_TYPEID));
            } else {
                pobjSetCardStatusDetailInfo.setFirstname("");
                pobjSetCardStatusDetailInfo.setLastname("");
                pobjSetCardStatusDetailInfo.setTypeid(0);
            }
            getCustomerAddress(pobjSetCardStatusDetailInfo, tiAddrind);

        } catch (SQLException se) {
            debugLib.logError(CLASSNAME, se.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        } finally {
            try {
                if (tobjConn != null) {
                    dbLib.closeConnection(tobjConn);
                }
            } catch (Exception e) {
                debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            }
        }
        if (pobjSetCardStatusDetailInfo.getFirstname() == null
                && pobjSetCardStatusDetailInfo.getTypeid() != viewConstant.NUMBER_TWO) {
            pobjSetCardStatusDetailInfo.setDisplayname("");
        } else {
            if (pobjSetCardStatusDetailInfo.getTypeid() == viewConstant.NUMBER_TWO) {
                if (pobjSetCardStatusDetailInfo.getFirstname() == null || pobjSetCardStatusDetailInfo.getFirstname().equals("")) {
                    pobjSetCardStatusDetailInfo.setDisplayname(pobjSetCardStatusDetailInfo.getLastname().trim());
                } else {
                    pobjSetCardStatusDetailInfo.setDisplayname(pobjSetCardStatusDetailInfo.getLastname().trim() + " "
                            + pobjSetCardStatusDetailInfo.getFirstname().trim());
                }
            } else {
                pobjSetCardStatusDetailInfo.setDisplayname(pobjSetCardStatusDetailInfo.getFirstname().trim() + " "
                        + pobjSetCardStatusDetailInfo.getLastname().trim());
            }
        }
        if (pobjSetCardStatusDetailInfo.getDisplayname() == null || pobjSetCardStatusDetailInfo.getDisplayname().equals("")) {
            throw new serverException("ia.error.CARD_NOT_FILE");
        }
        pobjSetCardStatusDetailInfo.setOldstatdescr(setStatDescr(pobjSetCardStatusDetailInfo.getOldstat()));
        pobjSetCardStatusDetailInfo.setDateset(dateTimeLib.getCurrentDate());
        //pobjSetCardStatusDetailInfo.setTime_set(dateTimeLib.getCurrentTime());
        return pobjSetCardStatusDetailInfo;
    }

    /**
     * @This method is to get the stat Description
     * @param String
     * @return String
     */
    private String setStatDescr(String tsStatcode) throws serverException {
        Connection tobjConn = null;
        PreparedStatement tobjPstmt = null;
        ResultSet tobjRs = null;
        String tsDescr = null;
        try {
            tobjConn = dbLib.getConnection(globalConstant.DATA_SOURCE);
            tobjPstmt = tobjConn.prepareStatement(SQLConstants.GET_CARDSTATUS_CUSTDET_QUERY1);
            tobjPstmt.setString(1, tsStatcode);
            debugLib.logInfo(CLASSNAME, SQLConstants.GET_CARDSTATUS_CUSTDET_QUERY1,
                    mobjSessionContext.getCallerPrincipal().getName());
            debugLib.logInfo(CLASSNAME, tsStatcode, mobjSessionContext.getCallerPrincipal().getName());
            tobjRs = tobjPstmt.executeQuery();
            if (tobjRs.next()) {
                tsDescr = tobjRs.getString(SQLConstants.GET_CARDSTATUS_DESCR_NAME);
            }

        } catch (SQLException se) {
            debugLib.logError(CLASSNAME, se.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        } finally {
            try {
                if (tobjConn != null) {
                    dbLib.closeConnection(tobjConn);
                }
            } catch (Exception e) {
                debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            }
        }
        return tsDescr;
    }

    /**
     *
     * This method is to add the card status detail.
     *
     * @param SetCardStatusDetailInfo
     * @throws RemoteException
     * @throws serverException
     */
    public SetCardStatusDetailInfo addCardStatus(SetCardStatusDetailInfo pobjSetCardStatusDetailInfo, String acsitem) throws serverException {

        Connection tobjConn = null;
        PreparedStatement tobjPstmt = null;
        ResultSet tobjRs = null;
        //Migration to 7.2
        CardStatusTags cardStatusTags;

        String hookFlag = "false";
        if (pobjSetCardStatusDetailInfo.getCorp() == String.valueOf(viewConstant.CHAR_TWO)
                && (pobjSetCardStatusDetailInfo.getStatcode() != INovusConstant.A_CRDSTAT_CANCEL
                && pobjSetCardStatusDetailInfo.getStatcode() != INovusConstant.A_CRDSTAT_CLOSED)) {
            throw new serverException("ia.error.CRD_STAT_INVALID");
        }

        // NMR013724 plugin inserts entry to cdsthst for all card including primary card
        // however primary card would also have entry added in std functionality further down
        // using flag to stop this if the plugin ran successfully
        String changedStatusFlag = "false";

        // MO 01/11/2004 If necessary change statuses of all additional cards            
        HookParam hookParam = new HookParam();
        hookParam.put(HookParam.INFO, pobjSetCardStatusDetailInfo);
        hookParam.put(HookParam.PARAM1, changedStatusFlag);

        try {
            hookParam = HookFactory.getPlugin("com.cortex.cust.parex.gui.ia.plugins.addcrdchgstat.AdditionalCardStatusChangePlugin").process(hookParam);
            changedStatusFlag = (String) hookParam.get(HookParam.PARAM1);
        } catch (Exception e) {
            mobjSessionContext.setRollbackOnly();
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.updatefailed");
        }

        String pan_enc = BasicPanCryptor.getInstance().encryptPan(pobjSetCardStatusDetailInfo.getPan().trim());

        // MO 10.03.2005: NMR013256: add instcode into where clause 
        String tsInstcodeWhereClause = "";

        if (pobjSetCardStatusDetailInfo.getInstcode() != null && !pobjSetCardStatusDetailInfo.getInstcode().equals("")) {
            //NVO
            //tsInstcodeWhereClause = " and CRDDET.instcode=\'"+pobjSetCardStatusDetailInfo.getInstcode()+"\'";
            //NVO
        }

        if (pobjSetCardStatusDetailInfo.getCorp().equals(String.valueOf(viewConstant.CHAR_TWO))
                && (pobjSetCardStatusDetailInfo.getStatcode().equals(INovusConstant.A_CRDSTAT_CANCEL)
                || pobjSetCardStatusDetailInfo.getStatcode().equals(INovusConstant.A_CRDSTAT_CLOSED))) {
            try {
                PreparedStatement tobjPreparedStatement1 = null;
                PreparedStatement tobjPreparedStatementUpdate1 = null;

                tobjConn = dbLib.getConnection(globalConstant.DATA_SOURCE);

                tobjPreparedStatementUpdate1 = tobjConn.prepareStatement(SQLConstants.GET_CARDSTATUS_CRDDET_QUERY1_1);

                tobjPreparedStatement1 = tobjConn.prepareStatement(SQLConstants.GET_CARDSTATUS_CRDDET_QUERY1_2 + tsInstcodeWhereClause);
                tobjPreparedStatement1.setString(1, pobjSetCardStatusDetailInfo.getPan());
                tobjPreparedStatement1.setInt(2, pobjSetCardStatusDetailInfo.getSeqno());

                ResultSet tsChildCards1 = tobjPreparedStatement1.executeQuery();

                while (tsChildCards1.next()) {
                    String tsChildPan = tsChildCards1.getString("pan");
                    int tiChildSeqno = tsChildCards1.getInt("seqno");
                    String tsChildStatus = tsChildCards1.getString("statcode");
                    java.sql.Date tsChildExpDate = tsChildCards1.getDate("expdate");

                    if (!tsChildStatus.equals(pobjSetCardStatusDetailInfo.getStatcode())) {
                        // prepare log info
                        List pobjUpdates1 = new ArrayList(); // update log list
                        String tsPrefix1 = "CRDDET UPDATE " + tsChildPan + "," + tiChildSeqno;
                        pobjUpdates1.add(tsPrefix1 + " statcode => " + pobjSetCardStatusDetailInfo.getStatcode());
                        pobjUpdates1.add(tsPrefix1 + " date_statchg => " + pobjSetCardStatusDetailInfo.getDateset());

                        // update additional card
                        tobjPreparedStatementUpdate1.setString(1, pobjSetCardStatusDetailInfo.getStatcode());
                        tobjPreparedStatementUpdate1.setString(2, pobjSetCardStatusDetailInfo.getOldcardstat());
                        tobjPreparedStatementUpdate1.setString(3, tsChildPan);
                        tobjPreparedStatementUpdate1.setInt(4, tiChildSeqno);

                        tobjPreparedStatementUpdate1.executeUpdate();

                        // log update event
                        FunctionLib.writeAccessLog(mobjSessionContext.getCallerPrincipal().getName(), pobjUpdates1);

                        // insert cdsthst
                        CdsthstInfo tobjCdsthstInfo = new CdsthstInfo();
                        tobjCdsthstInfo.setInstcode(pobjSetCardStatusDetailInfo.getInstcode());
                        tobjCdsthstInfo.setPan(tsChildPan);
                        tobjCdsthstInfo.setSeqno(tiChildSeqno);
                        tobjCdsthstInfo.setOld_statcode(tsChildStatus);
                        tobjCdsthstInfo.setNew_statcode(pobjSetCardStatusDetailInfo.getStatcode());
                        tobjCdsthstInfo.setDate_set(pobjSetCardStatusDetailInfo.getDateset());
                        tobjCdsthstInfo.setTime_set(pobjSetCardStatusDetailInfo.getTime_set());
                        tobjCdsthstInfo.setWhy_set(pobjSetCardStatusDetailInfo.getWhy_set());
                        tobjCdsthstInfo.setWho_set(pobjSetCardStatusDetailInfo.getWho_set());
                        tobjCdsthstInfo.setExpdate(tsChildExpDate);
                        CdsthstEntityHome tobjCdsthstEntityHome = (CdsthstEntityHome) FunctionLib.getLookup(serverConstant.VIEW_CDSTHST_ENTITY);
                        tobjCdsthstEntityHome.create(tobjCdsthstInfo);
                    }
                }
            } catch (SQLException se) {
                mobjSessionContext.setRollbackOnly();
                debugLib.logError(CLASSNAME, se.toString(), mobjSessionContext.getCallerPrincipal().getName());
                throw new serverException("error.db.selectfailed");
            } catch (Exception e) {
                mobjSessionContext.setRollbackOnly();
                debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
                throw new serverException("error.db.selectfailed");
            } finally {
                try {
                    if (tobjConn != null) {
                        dbLib.closeConnection(tobjConn);
                    }
                } catch (Exception e) {
                    debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
                    throw new serverException("error.db.selectfailed");
                }
            }

        }

        // corp=0 and additionalno=0 and (statcode='06' or statcode='07')
        if (((pobjSetCardStatusDetailInfo.getCorp().equals(String.valueOf(viewConstant.NUMBER_ZERO)))
                && (pobjSetCardStatusDetailInfo.getAdditionalno() == viewConstant.NUMBER_ZERO)
                && (pobjSetCardStatusDetailInfo.getStatcode().equals(INovusConstant.A_CRDSTAT_CANCEL)
                || pobjSetCardStatusDetailInfo.getStatcode().equals(INovusConstant.A_CRDSTAT_CLOSED)))) {
            // Alvis 30/05/2006: NMR015614 Processes additional cards if new status = bank cancelled or bank closed.
            //                             Updates status of additional cards and inserts records in cdsthst.
            hookFlag = "true";

            HookParam hookParam2 = new HookParam();
            hookParam2.put(HookParam.PARAM1, hookFlag);

            try {
                // Disables processing of additional cards.
                // (Processing is: if new status = bank cancelled or bank closed, updates statuses of additional cards and inserts records in cdsthst.)
                hookParam2 = HookFactory.getPlugin("com.cortex.gui.ia.sessionejb.AdditionalCardsPlugin").process(hookParam2);
                hookFlag = (String) hookParam2.get(HookParam.PARAM1);
            } catch (Exception e) {
                debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            }

            if (hookFlag.equals("true")) {
                try {
                    PreparedStatement tobjPreparedStatement = null;
                    PreparedStatement tobjPreparedStatementUpdate = null;

                    tobjConn = dbLib.getConnection(globalConstant.DATA_SOURCE);

                    tobjPreparedStatementUpdate = tobjConn.prepareStatement(SQLConstants.GET_CARDSTATUS_CRDDET_QUERY2_1);

                    tobjPreparedStatement = tobjConn.prepareStatement(SQLConstants.GET_CARDSTATUS_CRDDET_QUERY2_2 + tsInstcodeWhereClause);
                    tobjPreparedStatement.setString(1, pobjSetCardStatusDetailInfo.getCorp().trim());
                    tobjPreparedStatement.setString(2, pobjSetCardStatusDetailInfo.getAccno());
                    tobjPreparedStatement.setString(3, pobjSetCardStatusDetailInfo.getCrdproduct());

                    ResultSet rsAdditionals = tobjPreparedStatement.executeQuery();

                    while (rsAdditionals.next()) {
                        String tsAddPan = rsAdditionals.getString("pan");
                        int tiAddSeqno = rsAdditionals.getInt("seqno");
                        String tsAddStatus = rsAdditionals.getString("statcode");
                        java.sql.Date tsAddExpDate = rsAdditionals.getDate("expdate");

                        if (!tsAddStatus.equals(pobjSetCardStatusDetailInfo.getStatcode())) {
                            String pan_enc_tsAddPan = BasicPanCryptor.getInstance().encryptPan(tsAddPan);
                            String auditPANValue = pan_enc_tsAddPan;
                            if (AuditPanMask.getInstance().useAuditPANMask()) {
                                auditPANValue = AuditPanMask.getInstance().findVirtualOrDisplayPan(pan_enc_tsAddPan, tiAddSeqno);
                            }
                            // prepare log info
                            List pobjUpdates = new ArrayList(); // update log list
                            String tsPrefix = "CRDDET UPDATE " + auditPANValue + "," + tiAddSeqno;
                            pobjUpdates.add(tsPrefix + " statcode => " + pobjSetCardStatusDetailInfo.getStatcode());
                            pobjUpdates.add(tsPrefix + " date_statchg => " + pobjSetCardStatusDetailInfo.getDateset());

                            // update additional card
                            tobjPreparedStatementUpdate.setString(1, pobjSetCardStatusDetailInfo.getStatcode());
                            tobjPreparedStatementUpdate.setString(2, pobjSetCardStatusDetailInfo.getOldcardstat());
                            tobjPreparedStatementUpdate.setDate(3, pobjSetCardStatusDetailInfo.getDateset());
                            tobjPreparedStatementUpdate.setString(4, tsAddPan);
                            tobjPreparedStatementUpdate.setInt(5, tiAddSeqno);

                            tobjPreparedStatementUpdate.executeUpdate();

                            // log update event
                            FunctionLib.writeAccessLog(mobjSessionContext.getCallerPrincipal().getName(), pobjUpdates);

                            // insert cdsthst
                            CdsthstInfo tobjCdsthstInfo = new CdsthstInfo();
                            tobjCdsthstInfo.setInstcode(pobjSetCardStatusDetailInfo.getInstcode());
                            tobjCdsthstInfo.setPan(tsAddPan);
                            tobjCdsthstInfo.setSeqno(tiAddSeqno);
                            tobjCdsthstInfo.setOld_statcode(tsAddStatus);
                            tobjCdsthstInfo.setNew_statcode(pobjSetCardStatusDetailInfo.getStatcode());
                            tobjCdsthstInfo.setDate_set(pobjSetCardStatusDetailInfo.getDateset());
                            tobjCdsthstInfo.setTime_set(pobjSetCardStatusDetailInfo.getTime_set());
                            tobjCdsthstInfo.setWhy_set(pobjSetCardStatusDetailInfo.getWhy_set());
                            tobjCdsthstInfo.setWho_set(pobjSetCardStatusDetailInfo.getWho_set());
                            tobjCdsthstInfo.setExpdate(tsAddExpDate);
                            CdsthstEntityHome tobjCdsthstEntityHome = (CdsthstEntityHome) FunctionLib.getLookup(serverConstant.VIEW_CDSTHST_ENTITY);
                            tobjCdsthstEntityHome.create(tobjCdsthstInfo);
                        }
                    }
                } catch (SQLException se) {
                    mobjSessionContext.setRollbackOnly();
                    debugLib.logError(CLASSNAME, se.toString(), mobjSessionContext.getCallerPrincipal().getName());
                    throw new serverException("error.db.selectfailed");
                } catch (Exception e) {
                    mobjSessionContext.setRollbackOnly();
                    debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
                    throw new serverException("error.db.selectfailed");
                } finally {
                    try {
                        if (tobjConn != null) {
                            dbLib.closeConnection(tobjConn);
                        }
                    } catch (Exception e) {
                        debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
                        throw new serverException("error.db.selectfailed");
                    }
                }
            }
        }

        mobjSetCardStatusDetailInfo = pobjSetCardStatusDetailInfo;
        mobjSetCardStatusDetailInfo.setDateset(dateTimeLib.getCurrentDate());
        mobjSetCardStatusDetailInfo.setTime_set(dateTimeLib.getCurrentTime());
        String tsStatcodeNow = null;
        try {
            tobjConn = dbLib.getConnection(globalConstant.DATA_SOURCE);
            tobjPstmt = tobjConn.prepareStatement(SQLConstants.GET_CARDSTATUS_CRDDET_QUERY3);
            tobjPstmt.setString(1, pan_enc);
            tobjPstmt.setInt(2, mobjSetCardStatusDetailInfo.getSeqno());
            debugLib.logInfo(CLASSNAME, SQLConstants.GET_CARDSTATUS_CRDDET_QUERY3,
                    mobjSessionContext.getCallerPrincipal().getName());
            debugLib.logInfo(CLASSNAME, pan_enc, mobjSessionContext.getCallerPrincipal().getName());
            debugLib.logInfo(CLASSNAME, (mobjSetCardStatusDetailInfo.getSeqno() + ""),
                    mobjSessionContext.getCallerPrincipal().getName());
            tobjRs = tobjPstmt.executeQuery();
            if (tobjRs.next()) {
                tsStatcodeNow = tobjRs.getString(SQLConstants.GET_CARDSTATUS_CRDDET_STATCODE);
                mobjSetCardStatusDetailInfo.setOldstat(tsStatcodeNow);
            }

        } catch (SQLException se) {
            mobjSessionContext.setRollbackOnly();
            debugLib.logError(CLASSNAME, se.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        } catch (Exception e) {
            mobjSessionContext.setRollbackOnly();
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        } finally {
            try {
                if (tobjConn != null) {
                    dbLib.closeConnection(tobjConn);
                }
            } catch (Exception e) {
                debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
                throw new serverException("error.db.selectfailed");
            }
        }
        if (!(mobjSetCardStatusDetailInfo.getOldstat().equals(tsStatcodeNow))) {
            // Modified for AT TR - 0897 :by Beena
            throw new serverException("error.db.updatefailed");
        }

        try {
            try {
                tobjConn = dbLib.getConnection(globalConstant.DATA_SOURCE);

                List pobjUpdates = new ArrayList();		// update log list

                String auditPANValue = pan_enc;
                if (AuditPanMask.getInstance().useAuditPANMask()) {
                    auditPANValue = AuditPanMask.getInstance().findVirtualOrDisplayPan(pan_enc, pobjSetCardStatusDetailInfo.getSeqno());
                }

                if (mobjSetCardStatusDetailInfo.getClassid() == ICoConstant.CC_CRD_TYPE) {
                    tobjPstmt = tobjConn.prepareStatement(SQLConstants.GET_CARDSTATUS_CRDDET_QUERY4 + tsInstcodeWhereClause);
                    tobjPstmt.setString(1, pobjSetCardStatusDetailInfo.getStatcode());
                    tobjPstmt.setString(2, pobjSetCardStatusDetailInfo.getOldcardstat());
                    tobjPstmt.setDate(3, pobjSetCardStatusDetailInfo.getDateset());
                    tobjPstmt.setString(4, pan_enc);
                    debugLib.logInfo(CLASSNAME, SQLConstants.GET_CARDSTATUS_CRDDET_QUERY4 + tsInstcodeWhereClause,
                            mobjSessionContext.getCallerPrincipal().getName());
                    debugLib.logInfo(CLASSNAME, pobjSetCardStatusDetailInfo.getStatcode(),
                            mobjSessionContext.getCallerPrincipal().getName());
                    debugLib.logInfo(CLASSNAME, (pobjSetCardStatusDetailInfo.getDateset() + ""),
                            mobjSessionContext.getCallerPrincipal().getName());
                    debugLib.logInfo(CLASSNAME, pan_enc,
                            mobjSessionContext.getCallerPrincipal().getName());

                    // prepare log info
                    String tsPKey = "where pan = " + auditPANValue;
                    String tsPrefix = "CRDDET UPDATE " + tsPKey;

                    pobjUpdates.add(tsPrefix + " statcode => " + pobjSetCardStatusDetailInfo.getStatcode());
                    pobjUpdates.add(tsPrefix + " date_statchg => " + pobjSetCardStatusDetailInfo.getDateset());
                } else {
                    tobjPstmt = tobjConn.prepareStatement(SQLConstants.GET_CARDSTATUS_CRDDET_QUERY5 + tsInstcodeWhereClause);
                    tobjPstmt.setString(1, pobjSetCardStatusDetailInfo.getStatcode());
                    tobjPstmt.setString(2, pobjSetCardStatusDetailInfo.getOldcardstat());
                    tobjPstmt.setDate(3, pobjSetCardStatusDetailInfo.getDateset());
                    tobjPstmt.setString(4, pan_enc);
                    tobjPstmt.setInt(5, pobjSetCardStatusDetailInfo.getSeqno());
                    debugLib.logInfo(CLASSNAME, SQLConstants.GET_CARDSTATUS_CRDDET_QUERY5 + tsInstcodeWhereClause,
                            mobjSessionContext.getCallerPrincipal().getName());
                    debugLib.logInfo(CLASSNAME, pobjSetCardStatusDetailInfo.getStatcode(),
                            mobjSessionContext.getCallerPrincipal().getName());
                    debugLib.logInfo(CLASSNAME, (pobjSetCardStatusDetailInfo.getDateset() + ""),
                            mobjSessionContext.getCallerPrincipal().getName());
                    debugLib.logInfo(CLASSNAME, pan_enc,
                            mobjSessionContext.getCallerPrincipal().getName());
                    debugLib.logInfo(CLASSNAME, (pobjSetCardStatusDetailInfo.getSeqno() + ""),
                            mobjSessionContext.getCallerPrincipal().getName());

                    // prepare log info
                    String tsPKey = auditPANValue + "," + pobjSetCardStatusDetailInfo.getSeqno();
                    String tsPrefix = "CRDDET UPDATE " + tsPKey;

                    pobjUpdates.add(tsPrefix + " statcode => " + pobjSetCardStatusDetailInfo.getStatcode());
                    pobjUpdates.add(tsPrefix + " date_statchg => " + pobjSetCardStatusDetailInfo.getDateset());
                }

                tobjPstmt.executeUpdate();

                // log update event
                FunctionLib.writeAccessLog(mobjSessionContext.getCallerPrincipal().getName(), pobjUpdates);
            } catch (SQLException se) {
                mobjSessionContext.setRollbackOnly();
                debugLib.logError(CLASSNAME, se.toString(), mobjSessionContext.getCallerPrincipal().getName());
                throw se;
            } catch (Exception e) {
                mobjSessionContext.setRollbackOnly();
                debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
                throw new serverException("error.db.selectfailed");
            } finally {
                try {
                    if (tobjConn != null) {
                        dbLib.closeConnection(tobjConn);
                    }
                } catch (Exception e) {
                    debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
                }
            }

        } catch (Exception e) {
            throw new serverException("ia.error.STAT_UPD_FAIL");
        }
        if (mobjSetCardStatusDetailInfo.getWhy_set() == null) {
            mobjSetCardStatusDetailInfo.setWhy_set("sl.label.UNKNOWN_STR");
        }
        boolean tbExtlist = false;

        // NMR013724 only change the status if the plugin above has not
        // Alvis 06/01/2006: NMR014847 Changing card status to 07=bank cancelled does not insert a record in CDSTHST table
        if (changedStatusFlag.equals("false") || pobjSetCardStatusDetailInfo.getStatcode().equals(INovusConstant.A_CRDSTAT_CANCEL)) {
            try {

                CdsthstInfo tobjCdsthstInfo = new CdsthstInfo();
                tobjCdsthstInfo.setInstcode(mobjSetCardStatusDetailInfo.getInstcode());
                tobjCdsthstInfo.setPan(pan_enc);
                tobjCdsthstInfo.setSeqno(mobjSetCardStatusDetailInfo.getSeqno());
                tobjCdsthstInfo.setOld_statcode(mobjSetCardStatusDetailInfo.getOldstat());
                tobjCdsthstInfo.setNew_statcode(mobjSetCardStatusDetailInfo.getStatcode());
                tobjCdsthstInfo.setDate_set(mobjSetCardStatusDetailInfo.getDateset());
                tobjCdsthstInfo.setTime_set(mobjSetCardStatusDetailInfo.getTime_set());
                tobjCdsthstInfo.setWhy_set(mobjSetCardStatusDetailInfo.getWhy_set());
                tobjCdsthstInfo.setWho_set(mobjSetCardStatusDetailInfo.getWho_set());
                tobjCdsthstInfo.setExpdate(mobjSetCardStatusDetailInfo.getDateExpdate());
                // Obtain reference to CdsthstEntityHome Home bean
                CdsthstEntityHome mobjCdsthstEntityHome = (CdsthstEntityHome) mobjHomeCacheController.getHome(false);

                mobjCdsthstEntityHome.create(tobjCdsthstInfo);
            } catch (RemoteException re) {
                mobjSessionContext.setRollbackOnly();
                debugLib.logError(CLASSNAME, re.toString(), mobjSessionContext.getCallerPrincipal().getName());
                mobjHomeCacheController.refreshHome();
                throw new serverException("error.db.HIST_ADD_FAIL");
            } catch (Exception e) {
                System.out.println(e.getMessage());
                mobjSessionContext.setRollbackOnly();
                debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
                throw new serverException("ia.error.HIST_ADD_FAIL");
            }
        }
        try {
            // Obtain reference to IaCommonGlobalFunctionsMgrHome Home bean
            IaCommonGlobalFunctionsMgrHome tobjIaCommonGlobalFunctionsMgrHome = (IaCommonGlobalFunctionsMgrHome) mobjIaCommonGlobalHomeCacheController.getHome(false);
            IaCommonGlobalFunctionsMgr tobjIaCommonGlobalFunctionsMgr = tobjIaCommonGlobalFunctionsMgrHome.create();
            //tobjArray = tobjIaCommonGlobalFunctionsMgr.read_ca_msc(tsCrdprod_lst,tsNewinctv,tsNewinctvpte,tsRenewinctv,tsRenewinctvpte);
            cardStatusTags = tobjIaCommonGlobalFunctionsMgr.read_ca_msc();

        } catch (RemoteException re) {
            debugLib.logError(CLASSNAME, re.toString(), mobjSessionContext.getCallerPrincipal().getName());
            mobjIaCommonGlobalHomeCacheController.refreshHome();
            throw new serverException("error.db.connectfailed");
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.connectfailed");
        }

        if ((mobjSetCardStatusDetailInfo.getOldstat().equals(INovusConstant.A_CRDSTAT_PINTRIES)
                || mobjSetCardStatusDetailInfo.getOldstat().equals(cardStatusTags.getNewinctvpte())
                || mobjSetCardStatusDetailInfo.getOldstat().equals(cardStatusTags.getRenewinctvpte()))
                && (mobjSetCardStatusDetailInfo.getStatcode().equals(INovusConstant.A_CRDSTAT_NORMAL)
                || mobjSetCardStatusDetailInfo.getStatcode().equals(cardStatusTags.getNewinctv())
                || mobjSetCardStatusDetailInfo.getStatcode().equals(cardStatusTags.getRenewinctv()))) {
            // G.M. : 2004/Mar/24 : AT-0362 : Reset crdpin.pintries
            try {
                CrdpinInfo tobjCrdpinInfo = new CrdpinInfo();
                // Obtain reference to CrdpinEntityHome Home bean
                CrdpinEntityHome mobjCrdpinEntityHome = (CrdpinEntityHome) mobjHomeCacheController1.getHome(false);

                CrdpinSK mobjCrdpinSK = new CrdpinSK(pan_enc,
                        mobjSetCardStatusDetailInfo.getSeqno());

                CrdpinEntity mobjCrdpinEntity = (CrdpinEntity) mobjCrdpinEntityHome.findBySecondaryKey(mobjCrdpinSK);
                boolean tbUpdateCrdpin = true;
                try {
                    tobjCrdpinInfo = mobjCrdpinEntity.getCrdpinInfo();
                } catch (serverException se) {
                    tbUpdateCrdpin = false;
                }
                if (tbUpdateCrdpin) {
                    tobjCrdpinInfo.setPintries(viewConstant.NUMBER_ZERO);
                    IResultInfo tobjIResultInfo = mobjCrdpinEntity.setCrdpinInfo(tobjCrdpinInfo);
                }
            } catch (RemoteException re) {
                mobjSessionContext.setRollbackOnly();
                debugLib.logError(CLASSNAME, re.toString(), mobjSessionContext.getCallerPrincipal().getName());
                mobjHomeCacheController1.refreshHome();
                throw new serverException("co.error.unknownerror");
            } catch (Exception e) {
                mobjSessionContext.setRollbackOnly();
                debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
                throw new serverException("co.error.unknownerror");
            }
        }

        hookFlag = "true";
        try {
            // Start com.cortex.gui.ia.sessionejb.CardStatusMgrBeanPlugin
            hookParam = new HookParam();
            hookParam.put(HookParam.INFO, mobjSetCardStatusDetailInfo);
            hookParam.put(HookParam.PARAM1, hookFlag);
            hookParam.put(HookParam.PARAM2, mobjSetCardStatusDetailInfo.getStatcode());
            hookParam.put(HookParam.PARAM3, mobjSetCardStatusDetailInfo.getOldstat());
            hookParam.put(HookParam.PARAM4, FunctionLib.getCortexUserFromLdapUser(mobjSessionContext.getCallerPrincipal().getName()));
            hookParam = HookFactory.getPlugin("com.cortex.gui.ia.sessionejb.CardStatusMgrBeanPlugin.conditionHook").process(hookParam);
            hookFlag = (String) hookParam.get(HookParam.PARAM1);
            // End com.cortex.gui.ia.sessionejb.CardStatusMgrBeanPlugin
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
        }

        if (hookFlag.equals("true")) {
            createFees(tbExtlist);
        }
        try {
            tobjConn = dbLib.getConnection(globalConstant.DATA_SOURCE);
            tobjPstmt = tobjConn.prepareStatement(SQLConstants.GET_CRDSTATUS_CRDFORMAT_QUERY);
            tobjPstmt.setString(1, mobjSetCardStatusDetailInfo.getCrdproduct());
            debugLib.logInfo(CLASSNAME, SQLConstants.GET_CRDSTATUS_CRDFORMAT_QUERY,
                    mobjSessionContext.getCallerPrincipal().getName());
            debugLib.logInfo(CLASSNAME, mobjSetCardStatusDetailInfo.getCrdproduct(),
                    mobjSessionContext.getCallerPrincipal().getName());
            tobjRs = tobjPstmt.executeQuery();
            if (tobjRs.next()) {
                mobjSetCardStatusDetailInfo.setScheme(tobjRs.getString(SQLConstants.GET_CARDSTATUS_SCHEME_NAME).trim());
            }

        } catch (SQLException se) {
            debugLib.logError(CLASSNAME, se.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        } finally {
            try {
                if (tobjConn != null) {
                    dbLib.closeConnection(tobjConn);
                }
            } catch (Exception e) {
                debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
                throw new serverException("error.db.selectfailed");
            }
        }
        //Plugin for card event loggging 
        Boolean crdeventLoggingRequired = Boolean.FALSE;
        try {
            HookParam crdeventHookParam = new HookParam();
            crdeventHookParam.put(HookParam.PARAM1, crdeventLoggingRequired);
            crdeventHookParam = HookFactory.getPlugin("com.cortex.gui.ia.plugins.crdeventlog.CrdeventLogPlugin").process(crdeventHookParam);
            crdeventLoggingRequired = (Boolean) crdeventHookParam.get(HookParam.PARAM1);
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString());
        }
        if (crdeventLoggingRequired) {
            try {

                // Obtain reference to IaCommonGlobalFunctionsMgrHome Home bean
                IaCommonGlobalFunctionsMgrHome tobjIaCommonGlobalFunctionsMgrHome = (IaCommonGlobalFunctionsMgrHome) mobjIaCommonGlobalHomeCacheController.getHome(false);
                IaCommonGlobalFunctionsMgr tobjIaCommonGlobalFunctionsMgr = tobjIaCommonGlobalFunctionsMgrHome.create();
                CrdeventDetailInfo crdeventDetailInfo = new CrdeventDetailInfo();
                PanSeqno panSeqno = new PanSeqno(pan_enc, pobjSetCardStatusDetailInfo.getSeqno());

                String usr = mobjSessionContext.getCallerPrincipal().getName();
                tobjConn = dbLib.getConnection(globalConstant.DATA_SOURCE);
                tobjPstmt = tobjConn.prepareStatement(SQLConstantsBre.GET_USER_ID_SQL);
                tobjPstmt.setString(1, usr);
                debugLib.logInfo(CLASSNAME, SQLConstantsBre.GET_USER_ID_SQL, mobjSessionContext.getCallerPrincipal().getName());
                debugLib.logInfo(CLASSNAME, usr, mobjSessionContext.getCallerPrincipal().getName());

                tobjRs = tobjPstmt.executeQuery();
                if (tobjRs.next()) {
                    crdeventDetailInfo.setUsrId(tobjRs.getLong(SQLConstantsBre.GET_USER_ID_ID));
                }

                long crddetId = CommonGlobalFunctions.getCrddetIdByPanSeqno(panSeqno);
                //Set card event detail
                crdeventDetailInfo.setCrddetId(crddetId);
                crdeventDetailInfo.setBatch(0);
                crdeventDetailInfo.setEvtype(globalConstant.CRDEVENT_TYPE_CRDSTATUS);
                crdeventDetailInfo.setEvsrc(globalConstant.CRDEVENT_SRC_CTXONLINE);
                crdeventDetailInfo.setStatus(globalConstant.CRDEVENT_STAT_UNSET);

                crdeventDetailInfo.setEntityType(globalConstant.ENTITY_TYPE_CARD);
                crdeventDetailInfo.setEntityId(crddetId);
                crdeventDetailInfo.setDataLabel(globalConstant.CRDEV_DL_CRDDET_STATCODE);
                crdeventDetailInfo.setDataOld(pobjSetCardStatusDetailInfo.getOldstat());
                crdeventDetailInfo.setDataNew(pobjSetCardStatusDetailInfo.getStatcode());

                crdeventDetailInfo.setAcsitem(acsitem);

                tobjIaCommonGlobalFunctionsMgr.logCrdeventDetail(crdeventDetailInfo);

            } catch (serverException serverException) {
                throw serverException;
            } catch (RemoteException re) {
                debugLib.logError(CLASSNAME, re.toString(), mobjSessionContext.getCallerPrincipal().getName());
                mobjIaCommonGlobalHomeCacheController.refreshHome();
                throw new serverException("error.db.connectfailed");
            } catch (Exception e) {
                debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
                throw new serverException("error.db.connectfailed");
            }
        }

        return pobjSetCardStatusDetailInfo;
    }

    private void getCustomerAddress(SetCardStatusDetailInfo pobjSetCardStatusDetailInfo, int piAddrind) {
        CustdetInfo tobjCustdetInfo = null;
        try {
            IaCommonGlobalFunctionsMgrHome tobjIaCommonGlobalFunctionsMgrHome
                    = (IaCommonGlobalFunctionsMgrHome) mobjIaCommonGlobalHomeCacheController.getHome(false);
            IaCommonGlobalFunctionsMgr tobjIaCommonGlobalFunctionsMgr = tobjIaCommonGlobalFunctionsMgrHome.create();

            tobjCustdetInfo = tobjIaCommonGlobalFunctionsMgr.getCustomerAddress(pobjSetCardStatusDetailInfo.getInstcode(), pobjSetCardStatusDetailInfo.getCustcode(), piAddrind);
            //If Contact Mechanism is enabled get address detail from party tables
            if (CommonLib.isContactMechanismEnabled()) {
                PanSeqno panSeqno = new PanSeqno(pobjSetCardStatusDetailInfo.getPan(), pobjSetCardStatusDetailInfo.getSeqno());
                long crddetId = CommonGlobalFunctions.getCrddetIdByPanSeqno(panSeqno);
                setPartyPostalAddressDetails(pobjSetCardStatusDetailInfo, crddetId);
                setPartyTelecomNumberDetails(pobjSetCardStatusDetailInfo, crddetId);
            } else {
                pobjSetCardStatusDetailInfo.setAddrl1(tobjCustdetInfo.getAddrl1());
                pobjSetCardStatusDetailInfo.setAddrl2(tobjCustdetInfo.getAddrl2());
                pobjSetCardStatusDetailInfo.setAddrl3(tobjCustdetInfo.getAddrl3());
                pobjSetCardStatusDetailInfo.setHome_city(tobjCustdetInfo.getHome_city());
                pobjSetCardStatusDetailInfo.setHome_tel(tobjCustdetInfo.getHome_tel());
            }

            tobjIaCommonGlobalFunctionsMgrHome = null;
            tobjIaCommonGlobalFunctionsMgr = null;
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
        }

    }

    /**
     * Method to get address details from party tables if contact mechanism is
     * enabled
     *
     * @param pobjSetCardStatusDetailInfo
     * @param crddetId
     * @throws serverException
     */
    private void setPartyPostalAddressDetails(SetCardStatusDetailInfo pobjSetCardStatusDetailInfo, long crddetId) throws serverException {
        Connection tConn = null;
        PreparedStatement tStmt = null;
        ResultSet tRs = null;
        String addr1 = null;
        String addr2 = null;
        String addr3 = null;
        String home_city = null;
        try {
            tConn = com.cortex.common.lib.dbLib.getConnection(globalConstant.DATA_SOURCE);
            tStmt = tConn.prepareStatement(getPartyPostalSelectQuery());
            tStmt.setLong(1, crddetId);
            tStmt.setInt(2, globalConstant.DEFAULT_POSTAL_PURPOSE_TYPE_ID);
            tStmt.setString(3, pobjSetCardStatusDetailInfo.getCustcode());
            tRs = tStmt.executeQuery();
            while (tRs.next()) {
                addr1 = tRs.getString(SQLConstants.PARTY_ADDR_1);
                addr2 = tRs.getString(SQLConstants.PARTY_ADDR_2);
                addr3 = tRs.getString(SQLConstants.PARTY_ADDR_3);
                home_city = tRs.getString(SQLConstants.PARTY_CITY);
                if (addr1 == null) {
                    addr1 = "";
                }
                if (addr2 == null) {
                    addr2 = "";
                }
                if (addr3 == null) {
                    addr3 = "";
                }
                if (home_city == null) {
                    home_city = "";
                }
                pobjSetCardStatusDetailInfo.setAddrl1(addr1);
                pobjSetCardStatusDetailInfo.setAddrl2(addr2);
                pobjSetCardStatusDetailInfo.setAddrl3(addr3);
                pobjSetCardStatusDetailInfo.setHome_city(home_city);

            }
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        }
    }

    /**
     * Method to get select query get postal address detail from party tables
     *
     * @return queryString
     */
    private String getPartyPostalSelectQuery() {
        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder.append(SQLConstants.GET_MEDIA_CUST_POSTAL_ADDR);
        queryBuilder.append(SQLConstants.GET_PARTY_MEDIA_CUST_CLAUSE);
        queryBuilder.append(SQLConstants.GET_PARTY_MEDIA_POSTAL_FUNTION);
        return queryBuilder.toString();
    }

    /**
     * Method to get telecommunication details from party tables if contact
     * mechanism is enabled
     *
     * @param pobjSetCardStatusDetailInfo
     * @param crddetId
     * @throws serverException
     */
    private void setPartyTelecomNumberDetails(SetCardStatusDetailInfo pobjSetCardStatusDetailInfo, long crddetId) throws serverException {
        Connection tConn = null;
        PreparedStatement tStmt = null;
        ResultSet tRs = null;
        String home_tel = null;
        String country_prefix = null;
        String area_code = null;
        String contact_no = null;
        String extension_no = null;
        try {
            tConn = com.cortex.common.lib.dbLib.getConnection(globalConstant.DATA_SOURCE);
            tStmt = tConn.prepareStatement(getPartyTelecomSelectQuery());
            tStmt.setLong(1, crddetId);
            tStmt.setInt(2, globalConstant.DEFAULT_TELECOM_PURPOSE_TYPE_ID);
            tStmt.setString(3, pobjSetCardStatusDetailInfo.getCustcode());
            tRs = tStmt.executeQuery();
            while (tRs.next()) {
                country_prefix = tRs.getString(SQLConstants.PARTY_COUNTRY_PREFIX);
                area_code = tRs.getString(SQLConstants.PARTY_AREA_CODE);
                contact_no = tRs.getString(SQLConstants.PARTY_CONTACT_NO);
                extension_no = tRs.getString(SQLConstants.PARTY_EXTENSION_NO);
                if (country_prefix == null) {
                    country_prefix = "";
                }
                if (area_code == null) {
                    area_code = "";
                }
                if (contact_no == null) {
                    contact_no = "";
                }
                if (extension_no == null) {
                    extension_no = "";
                }
                home_tel = country_prefix + " " + area_code + " " + contact_no + " " + extension_no;

                pobjSetCardStatusDetailInfo.setHome_tel(home_tel.trim());

            }
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        }
    }

    /**
     * Method to get select query to get Telecommunication details from party
     * tables
     *
     * @return queryString
     */
    private String getPartyTelecomSelectQuery() {
        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder.append(SQLConstants.GET_MEDIA_CUST_TELECOM_NUM);
        queryBuilder.append(SQLConstants.GET_PARTY_MEDIA_CUST_CLAUSE);
        queryBuilder.append(SQLConstants.GET_PARTY_MEDIA_TELECOM_FUNTION);
        return queryBuilder.toString();
    }

    /**
     * @This method is to create fees.
     * @param boolean
     * @throws serverException
     */
    private void createFees(boolean pbExtlist) throws serverException {
        Connection tobjConn = null;
        PreparedStatement tobjPstmt = null;
        ResultSet tobjRs = null;

        if (pbExtlist) {
            mobjSetCardStatusDetailInfo.setChargedata(IChConstant.CHRG_ACL_COND_INTER_LIST);
        } else {
            mobjSetCardStatusDetailInfo.setChargedata(IChConstant.CHRG_ACL_COND_LOCAL_LIST);
        }
        mobjSetCardStatusDetailInfo.setChargetype(IChConstant.CHRG_CRD_RESTRICT);
        try {
            tobjConn = dbLib.getConnection(globalConstant.DATA_SOURCE);
            tobjPstmt = tobjConn.prepareStatement(SQLConstants.GET_CARDSTATUS_CRDDET_QUERY6);
            String pan_enc = BasicPanCryptor.getInstance().encryptPan(mobjSetCardStatusDetailInfo.getPan());
            tobjPstmt.setString(1, pan_enc);
            tobjPstmt.setInt(2, mobjSetCardStatusDetailInfo.getSeqno());
            debugLib.logInfo(CLASSNAME, SQLConstants.GET_CARDSTATUS_CRDDET_QUERY6,
                    mobjSessionContext.getCallerPrincipal().getName());
            debugLib.logInfo(CLASSNAME, pan_enc, mobjSessionContext.getCallerPrincipal().getName());
            debugLib.logInfo(CLASSNAME, (mobjSetCardStatusDetailInfo.getSeqno() + ""),
                    mobjSessionContext.getCallerPrincipal().getName());
            tobjRs = tobjPstmt.executeQuery();
            if (tobjRs.next()) {
                // DMG 2004/1/2 Bug fix, currcode used to get set always to 'currcode' and the value
                // was not retrieved
                mobjSetCardStatusDetailInfo.setCurrcode(tobjRs.getString(SQLConstants.GET_CARDSTATUS_CURRCODE).trim());
            }

        } catch (SQLException se) {
            debugLib.logError(CLASSNAME, se.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new serverException("error.db.selectfailed");
        } finally {
            try {
                if (tobjConn != null) {
                    dbLib.closeConnection(tobjConn);
                }
            } catch (Exception e) {
                debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
                throw new serverException("error.db.selectfailed");
            }
        }
        if (mobjSetCardStatusDetailInfo.getCurrcode() == null) {
            throw new serverException("error.db.currcodefailed");
        }

        Boolean addChargeData = Boolean.TRUE;
        try {
            HookParam hookParam = new HookParam();
            hookParam.put(HookParam.PARAM1, addChargeData);
            hookParam = HookFactory.getPlugin("com.cortex.gui.ia.plugins.flexfee.FlexFeePlugin").process(hookParam);
            addChargeData = (Boolean) hookParam.get(HookParam.PARAM1);
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
        }

        if (addChargeData.booleanValue()) {
            new IaGlobalFunctions().addFlexFee(mobjSetCardStatusDetailInfo.getPan(),
                    mobjSetCardStatusDetailInfo.getSeqno(),
                    mobjSetCardStatusDetailInfo.getChargetype(),
                    mobjSetCardStatusDetailInfo.getChargedata(),
                    mobjSetCardStatusDetailInfo.getCurrcode());
        }

    }

    public void ejbCreate() throws javax.ejb.CreateException {
        try {
            mobjHomeCacheController = new HomeCacheController(serverConstant.VIEW_CDSTHST_ENTITY, CdsthstEntityHome.class);
            mobjHomeCacheController.refreshHome();

            mobjHomeCacheController1 = new HomeCacheController(serverConstant.VIEW_CRDPIN_ENTITY, CrdpinEntityHome.class);
            mobjHomeCacheController1.refreshHome();

            mobjHomeCacheController2 = new HomeCacheController(serverConstant.VIEW_CRDDET_ENTITY, CrddetEntityHome.class);
            mobjHomeCacheController2.refreshHome();

            mobjHomeCacheController3 = new HomeCacheController(serverConstant.VIEW_CUSTDET_ENTITY, CustdetEntityHome.class);
            mobjHomeCacheController3.refreshHome();

            mobjIaCommonGlobalHomeCacheController = new HomeCacheController(serverConstant.IA_GLOBAL_FUNCTIONS_SESSION, IaCommonGlobalFunctionsMgrHome.class);
            mobjIaCommonGlobalHomeCacheController.refreshHome();
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), mobjSessionContext.getCallerPrincipal().getName());
            throw new javax.ejb.CreateException(e.toString());
        }
    }

    public String getConfiguredStatusCode() throws serverException {
        Connection tobjConnection = null;
        PreparedStatement tobjpstmt = null;
        ResultSet tobjRs = null;
        String statusCodeForCardActivation = null;
        try {
            tobjConnection = dbLib.getConnection(globalConstant.DATA_SOURCE);
            tobjpstmt = tobjConnection.prepareStatement(SQLConstants.GET_STATUS_CODE_FOR_CARD_ACTIVATION);
            debugLib.logInfo(CLASSNAME, SQLConstants.GET_STATUS_CODE_FOR_CARD_ACTIVATION);
            tobjRs = tobjpstmt.executeQuery();
            while (tobjRs.next()) {
                statusCodeForCardActivation = tobjRs.getString("string_t");
            }
        } catch (SQLException e) {
            debugLib.logError(CLASSNAME, e.toString());
            throw new serverException("error.db.searchfailed");
        } catch (serverException e) {
            debugLib.logError(CLASSNAME, e.toString());
            throw new serverException(e.getErrorCode());
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString());
            throw new serverException("error.db.searchfailed");
        } finally {
            try {
                if (tobjpstmt != null) {
                    tobjpstmt.close();
                }
            } catch (SQLException ex) {
            }
            dbLib.closeConnection(tobjConnection);
        }
        return statusCodeForCardActivation;
    }

    public boolean isTransitionAllowed(String crdproduct, String toStatus, String fromOldStatus, String fromCurrentStatus, String oldOrNewOrBoth, boolean hasOldCard) throws serverException {
        boolean transitionAllowed = false;

        String from = " ";
        if (hasOldCard) {
            if ("0".equals(oldOrNewOrBoth)) // both old and new status change 
            {
                transitionAllowed = isTransitionAllowedCheck(crdproduct, toStatus, fromOldStatus);// for old
                if (!transitionAllowed) {
                    from = fromOldStatus;
                } else {
                    transitionAllowed = isTransitionAllowedCheck(crdproduct, toStatus, fromCurrentStatus);// for new
                    if (!transitionAllowed) {
                        from = fromCurrentStatus;
                    }
                }
            } else if ("1".equals(oldOrNewOrBoth))// new status change
            {
                transitionAllowed = isTransitionAllowedCheck(crdproduct, toStatus, fromCurrentStatus);// for new
                if (!transitionAllowed) {
                    from = fromCurrentStatus;
                }
            } else if ("2".equals(oldOrNewOrBoth)) // old status change
            {
                transitionAllowed = isTransitionAllowedCheck(crdproduct, toStatus, fromOldStatus);// for old
                if (!transitionAllowed) {
                    from = fromOldStatus;
                }
            }
        } else {
            transitionAllowed = isTransitionAllowedCheck(crdproduct, toStatus, fromCurrentStatus);// for new
            if (!transitionAllowed) {
                from = fromCurrentStatus;
            }
        }

        if (!transitionAllowed) {
            throw new serverException("ia.error.TRANSITION_FAILED", from, toStatus);
        }

        return true;
    }

    private boolean isTransitionAllowedCheck(String crdproduct, String toStatus, String fromStatus) throws serverException {
        boolean transitionAllowed = false;
        String selectSQL1 = SQLConstantsBre.GET_BRE_STATUS_TRANSITION_CONTROL_SQL1;
        String selectSQL2 = SQLConstantsBre.GET_BRE_STATUS_TARNSITION_CONTROL_SQL2;
        Connection tobjConnection = null;
        PreparedStatement tobjStatement = null;
        ResultSet tobjResultSet = null;
        try {
            tobjConnection = dbLib.getConnection(globalConstant.DATA_SOURCE);
            tobjStatement = tobjConnection.prepareStatement(selectSQL1);
            tobjStatement.setString(1, fromStatus);
            tobjStatement.setString(2, toStatus);
            tobjResultSet = tobjStatement.executeQuery();
            if (tobjResultSet != null) {
                if (tobjResultSet.next()) {
                    if (tobjResultSet.getInt(1) == 1) {
                        transitionAllowed = true;
                    }
                }
            }
            /*
            if(!transitionAllowed)
            {
	            tobjStatement = tobjConnection.prepareStatement(selectSQL2);
	            tobjStatement.setString(1, fromStatus);	           
	            tobjResultSet = tobjStatement.executeQuery();
	            if (tobjResultSet != null)
	            {
	                if (tobjResultSet.next()) 
	                {
	                	if(tobjResultSet.getInt(1) >= 1)
	                	{
	                		transitionAllowed = false;
	                	}
	                	else
	                	{
	                		transitionAllowed = true;
	                	}
	                }
	            }
            }
            * */
        } catch (SQLException e) {
            debugLib.logError(CLASSNAME, e.toString());
            throw new serverException("error.db.searchfailed");
        } catch (serverException e) {
            debugLib.logError(CLASSNAME, e.toString());
            throw new serverException(e.getErrorCode());
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString());
            throw new serverException("error.db.searchfailed");
        } finally {
            try {
                if (tobjStatement != null) {
                    tobjStatement.close();
                }
            } catch (SQLException ex) {
                debugLib.logError(CLASSNAME, ex.toString());
                throw new serverException("error.db.searchfailed");
            }
            dbLib.closeConnection(tobjConnection);
        }
        return transitionAllowed;
    }

}
