package com.cortex.cust.bre.gui.ia.plugins.cardreplace;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cortex.common.constant.globalConstant;
import com.cortex.common.exception.serverException;
import com.cortex.common.hook.HookInterface;
import com.cortex.common.hook.HookParam;
import com.cortex.common.lib.dbLib;
import com.cortex.common.lib.debugLib;
import com.cortex.common.sql.SQLFactory;
import com.cortex.common.sql.SQLNode;
import com.cortex.cust.bre.common.constant.serverConstantBre;
import com.cortex.gui.ia.valueobj.CardMaintDetailInfo;

public class ReplaceCard1 implements HookInterface
{
    public static final String CLASSNAME = "ReplaceCard1";

	public HookParam process(HookParam param) throws Exception 
	{   
		Connection tobjConnection = null;
	    PreparedStatement tobjPreparedStatement = null;
	    ResultSet tobjResultSet = null;
	    SQLFactory tobjSQLFactory = SQLFactory.getSQLFactory();
	   
	    boolean crdrplace = true;
	    boolean crdstatus = false;
		
		CardMaintDetailInfo cardMaintDetailInfo = (CardMaintDetailInfo) param.get(HookParam.PARAM1);
		
		if(cardMaintDetailInfo.getStatcode().equals(serverConstantBre.GET_STATE_CODE_FOUR) || cardMaintDetailInfo.getStatcode().equals(serverConstantBre.GET_STATE_CODE_FIVE) 
				|| cardMaintDetailInfo.getStatcode().equals(serverConstantBre.GET_STATE_CODE_EIGHT) || cardMaintDetailInfo.getStatcode().equals(serverConstantBre.GET_STATE_CODE_FIFTEEN))
		{
			crdstatus = true;
		}
		
		try
        {
			tobjConnection = dbLib.getConnection(globalConstant.DATA_SOURCE);
			SQLNode tobjSQLNode = tobjSQLFactory.getSQLNode("ia", "com.cortex.cust.bre.gui.ia.plugin.replaceCard");
	        tobjPreparedStatement = tobjConnection.prepareStatement(tobjSQLNode.getStatement());
	        tobjPreparedStatement.setLong(1, cardMaintDetailInfo.getId());
	        tobjResultSet = tobjPreparedStatement.executeQuery();
            if (tobjResultSet.next())
            {
            	crdrplace = false;
            }
        }
        catch(Exception e)
        {
            debugLib.logError(CLASSNAME, e);
            throw new serverException ("error.unknownerror");
        }
        finally
        {
            try
            {
                if (tobjPreparedStatement != null) tobjPreparedStatement.close();
                if (tobjResultSet != null) tobjResultSet.close();
            }
            catch (SQLException ex)
            {
            	debugLib.logError(CLASSNAME, ex);
                throw new serverException ("error.unknownerror");
            }
            dbLib.closeConnection(tobjConnection);
        }
            	
       if(crdrplace && crdstatus ) 
       {
    	   cardMaintDetailInfo.setCardReplace(true);
       }
       else
       {
    	   cardMaintDetailInfo.setCardReplace(false);
       }
            
		return param;
	}
}
