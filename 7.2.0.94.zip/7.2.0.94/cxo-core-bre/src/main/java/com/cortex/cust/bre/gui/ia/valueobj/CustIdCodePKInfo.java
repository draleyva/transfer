package com.cortex.cust.bre.gui.ia.valueobj;

import java.sql.Date;
import java.io.Serializable;

/**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project No           : 1103  <br>
 * Module Name          : Ia<br>
 * Global Use Case      : N/A<br>
 * Business Use case    : N/A<br>
 * Maintenance Use case : N/A<br>
 * @author                j2eegen
 *
 * This Info class contains the PK of the cust_idcode table.
 * This object will be used to minimise network traffic when
 * communicating with the session bean to getCust_idcodeInfo and
 * deleteCust_idcodeInfo methods.
 *
 * Date   Author     Reviewer    Description of change<br>
 *
 * @version 1.0
 */
public class CustIdCodePKInfo implements Serializable
{
    private long msCustdet_id = 0;
    private long msId = 0;
    private String msIdcode = "";
    private long msIdtype_id = 0;

                                                            // custdet_id
    /**
     * Get the custdet_id field from the form
     *
     * @return the custdet_id value
     */
    public long getCustdet_id()
    {
        return msCustdet_id;
    }
    /**
     * Set the custdet_id field into the form
     *
     * @param psCustdet_id the custdet_id value
     */
    public void setCustdet_id(long psCustdet_id)
    {
        msCustdet_id = psCustdet_id;
    }

                                                            // id
    /**
     * Get the id field from the form
     *
     * @return the id value
     */
    public long getId()
    {
        return msId;
    }
    /**
     * Set the id field into the form
     *
     * @param psId the id value
     */
    public void setId(long psId)
    {
        msId = psId;
    }

                                                            // idcode
    /**
     * Get the idcode field from the form
     *
     * @return the idcode value
     */
    public String getIdcode()
    {
        return msIdcode;
    }
    /**
     * Set the idcode field into the form
     *
     * @param psIdcode the idcode value
     */
    public void setIdcode(String psIdcode)
    {
        msIdcode = psIdcode;
    }

                                                            // idtype_id
    /**
     * Get the idtype_id field from the form
     *
     * @return the idtype_id value
     */
    public long getIdtype_id()
    {
        return msIdtype_id;
    }
    /**
     * Set the idtype_id field into the form
     *
     * @param psIdtype_id the idtype_id value
     */
    public void setIdtype_id(long psIdtype_id)
    {
        msIdtype_id = psIdtype_id;
    }

}
