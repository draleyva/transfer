package com.cortex.cust.bre.gui.ia.sessionejb;

import com.cortex.common.exception.serverException;
import com.cortex.gui.ia.sessionejb.AccdetMgr;
import com.cortex.gui.ia.valueobj.AccdetDetailInfo;
import java.rmi.RemoteException;

/**
 *
 * @author e5706717
 */
public interface BREAccdetMgr extends AccdetMgr
{
    public void unlinkAccdet(AccdetDetailInfo adi) throws RemoteException, serverException;
}
