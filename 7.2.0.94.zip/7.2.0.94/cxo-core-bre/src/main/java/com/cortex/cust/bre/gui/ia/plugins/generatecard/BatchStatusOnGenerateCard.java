package com.cortex.cust.bre.gui.ia.plugins.generatecard;

import com.cortex.common.exception.serverException;
import com.cortex.common.hook.HookInterface;
import com.cortex.common.hook.HookParam;
import com.cortex.common.lib.debugLib;


public class BatchStatusOnGenerateCard implements HookInterface
{
    public static final String CLASSNAME = "BatchStatusOnGenerateCard";

	public HookParam process(HookParam param) throws Exception 
	{   
		debugLib.logDetail(CLASSNAME, "Entering process in BatchStatusOnGenerateCard");
		
		try{
		  param.put(HookParam.RESULT,4);
		}catch(Exception exp){
			debugLib.logError(CLASSNAME, exp);
            throw new serverException ("error.unknownerror");
		}
		debugLib.logDetail(CLASSNAME, "exiting process in BatchStatusOnGenerateCard");
		return param;
	}
}
