package com.cortex.cust.bhfm.gui.ia.plugins.cardmainttab;

import org.apache.commons.lang.StringUtils;
import java.util.Vector;

import com.cortex.gui.common.valueobj.WhereClauseInfo;
import com.cortex.gui.common.lib.CommonGlobalFunctions;
import com.cortex.common.hook.HookInterface;
import com.cortex.common.hook.HookParam;
import com.cortex.cust.bre.common.constant.SQLConstantsBre;
import com.cortex.gui.ia.valueobj.CardMaintSearchInfo;
import com.cortex.common.constant.globalConstant;
import com.cortex.common.constant.SQLConstants;

public class ExtCustIdCriteriaPlugin implements HookInterface{

	public static final String CLASSNAME = "ExtCustIdCriteriaPlugin";
	
	public static String GET_IA_CRDDET_SEARCH_ACCDET_ID_NOTDEFAULT = "d.id";
	
	public HookParam process(HookParam param) throws Exception
	{
		Vector tvecWhereClauseInfo = (Vector)param.get(HookParam.PARAM1); 
		CardMaintSearchInfo pobjCardMaintSearchInfo = (CardMaintSearchInfo)param.get(HookParam.PARAM2);		

		if(!pobjCardMaintSearchInfo.getDefaultAccount().equals(SQLConstantsBre.GET_CUSTOMER_IDENTIFICATION_DEFAULT_ACCOUNT))
		{
			if(StringUtils.isNotBlank(pobjCardMaintSearchInfo.getInstcode2())){
			
				tvecWhereClauseInfo = new Vector();
				
				if (!pobjCardMaintSearchInfo.getAccno().trim().equals(""))
				{
					String instcode = pobjCardMaintSearchInfo.getInstcode2();
					long inst_id = CommonGlobalFunctions.getInstIdByInstCode(instcode);
					if (inst_id != 0)
					{
						String accno = pobjCardMaintSearchInfo.getAccno();
						String accdet_ids = CommonGlobalFunctions.getAccdetIdsByInstIdAccno(inst_id, accno);        	
						WhereClauseInfo tobjWhereClauseInfo = new WhereClauseInfo();
						tobjWhereClauseInfo.setDBColumnName(GET_IA_CRDDET_SEARCH_ACCDET_ID_NOTDEFAULT);
						tobjWhereClauseInfo.setVariableValue(!accdet_ids.equals("null") ? accdet_ids : "-1");
						tobjWhereClauseInfo.setVaribleType(globalConstant.WHERE_TYPE_INT);
						tvecWhereClauseInfo.addElement(tobjWhereClauseInfo);        		
					}
				}		
				       
				if (!pobjCardMaintSearchInfo.getInstcode2().trim().equals(""))
				{
					WhereClauseInfo tobjWhereClauseInfo = new WhereClauseInfo();
					tobjWhereClauseInfo.setDBColumnName(SQLConstants.GET_IA_INSTCODE_SEARCH_NAME);
					tobjWhereClauseInfo.setVariableValue(pobjCardMaintSearchInfo.getInstcode2().trim());
					tobjWhereClauseInfo.setVaribleType(globalConstant.WHERE_TYPE_STRING);
					tvecWhereClauseInfo.addElement(tobjWhereClauseInfo);        	        	
				}
				
			}

		}
		param.put(HookParam.PARAM1, tvecWhereClauseInfo);		

		return param;
	}

}	
	

