package com.cortex.cust.bre.common.entityejb;

import java.rmi.RemoteException;


import com.cortex.common.exception.serverException;
import com.cortex.common.interfaces.IResultInfo;
import com.cortex.cxo.core.legacyejb.entity.EjbEntity;


/** <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project no: <br>
 * Use case no: <br>
 * Use case name: Cust_idcodeEntity<br>
 *
 * This interface is the local home interface for the Cust_idcodeEntityBean.java,
 * which in WebLogic is implemented by the code-generated container
 * class. A home interface may support one or more create
 * methods, which must correspond to methods named "ejbCreate" in the EJBean.
 *
 * @author j2eegen
 */
public interface CustIdCodeEntity extends EjbEntity
{

    public long getVerno_ctx() throws serverException, RemoteException;
    public void setVerno_ctx(long verno_ctx) throws serverException, RemoteException;

    public String getIdcode() throws serverException, RemoteException;
    public void setIdcode(String newIdcode) throws serverException, RemoteException;
    public long getIdtype_id() throws serverException, RemoteException;
    public void setIdtype_id(long newIdtype_id) throws serverException, RemoteException;
    public long getId() throws serverException, RemoteException;
    public void setId(long newId) throws serverException, RemoteException;
    public long getCustdet_id() throws serverException, RemoteException;
    public void setCustdet_id(long newCustdet_id) throws serverException, RemoteException;

    public IResultInfo setCustIdCodeInfo (CustIdCodeInfo pobjCust_idcodeInfo)
        throws serverException, RemoteException;

    public CustIdCodeInfo getCustIdCodeInfo()
        throws serverException, RemoteException;

    public boolean doCustIdCodeUpdate(CustIdCodeInfo pbojCust_idcodeInfo)
        throws serverException, RemoteException;

}
