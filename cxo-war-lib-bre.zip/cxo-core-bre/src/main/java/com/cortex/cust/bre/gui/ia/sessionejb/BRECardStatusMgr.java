/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cortex.cust.bre.gui.ia.sessionejb;

import com.cortex.common.exception.serverException;
import com.cortex.cxo.core.legacyejb.session.EjbSessionBean;
import com.cortex.gui.common.valueobj.PagingContextInfo;
import com.cortex.gui.ia.valueobj.CardStatusChangeHistorySearchInfo;
import com.cortex.gui.ia.valueobj.SetCardStatusDetailInfo;
import java.rmi.RemoteException;
import java.util.ArrayList;

/**
 *
 * @author FIS
 */
public interface BRECardStatusMgr  extends EjbSessionBean {
    	/**
	 * This method is to search the CardStatus details.
	 *
	 * @param CardStatusChangeHistorySearchInfo
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws serverException
	 */
	public ArrayList searchCardStatusChangeHistory(CardStatusChangeHistorySearchInfo pobjCardStatusChangeHistorySearchInfo, PagingContextInfo pobjPagingContextInfo)throws RemoteException, serverException;
	/**
	 * This method is to search the CardStatus details.
	 *
	 * @param CardStatusChangeHistorySearchInfo
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws serverException
	 */
	public ArrayList searchCardStatusChangeHistory1(CardStatusChangeHistorySearchInfo pobjCardStatusChangeHistorySearchInfo, PagingContextInfo pobjPagingContextInfo)throws RemoteException, serverException;


	/**
	 *
	 * @param crdproduct
	 * @param toStatus
	 * @param fromOldStatus
	 * @param fromCurrentStatus
	 * @param oldOrNewOrBoth
	 * @return
	 * @throws RemoteException
	 * @throws serverException
	 */
	public boolean isTransitionAllowed(String crdproduct, String toStatus, String fromOldStatus, String fromCurrentStatus, String oldOrNewOrBoth, boolean hasOldCard) throws RemoteException, serverException;


}
