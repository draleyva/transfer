package com.cortex.cust.bre.gui.ia.valueobj;

import java.io.Serializable;

/**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project No           : 1103  <br>
 * Module Name          : Ia<br>
 * Global Use Case      : N/A<br>
 * Business Use case    : N/A<br>
 * Maintenance Use case : N/A<br>
 * @author                j2eegen
 *
 * This is the Info class used for the cust_idcode search screen.
 * This info object must contain setXXX/getXXX methods for all
 * the fields to be used in the search criteria and those
 * of the search results list
 *
 * Date   Author     Reviewer    Description of change<br>
 *
 * @version 1.0
 */

public class BREReplaceLostOrStolenCardsInfo implements Serializable
{
    private String crdproduct = "";
    private String batch = "";
    private String instcode = "";
    private String oldSeqno = "";
    private String oldPan = "";
    private String newPan = "";
    private String newSeqno = "0";
    
    private String panDisplay = "";
    private String virtualPan = "";
    private String custName = "";
    private String statCode = "";
    private String statCodeDescr = "";
    
    private boolean replacementDone = false;
    
	/**
	 * @return the crdproduct
	 */
	public String getCrdproduct() {
		return crdproduct;
	}
	/**
	 * @param crdproduct the crdproduct to set
	 */
	public void setCrdproduct(String crdproduct) {
		this.crdproduct = crdproduct;
	}
	/**
	 * @return the batch
	 */
	public String getBatch() {
		return batch;
	}
	/**
	 * @param batch the batch to set
	 */
	public void setBatch(String batch) {
		this.batch = batch;
	}
	/**
	 * @return the instcode
	 */
	public String getInstcode() {
		return instcode;
	}
	/**
	 * @param instcode the instcode to set
	 */
	public void setInstcode(String instcode) {
		this.instcode = instcode;
	}
	/**
	 * @return the oldSeqno
	 */
	public String getOldSeqno() {
		return oldSeqno;
	}
	/**
	 * @param oldSeqno the oldSeqno to set
	 */
	public void setOldSeqno(String oldSeqno) {
		this.oldSeqno = oldSeqno;
	}
	/**
	 * @return the oldPan
	 */
	public String getOldPan() {
		return oldPan;
	}
	/**
	 * @param oldPan the oldPan to set
	 */
	public void setOldPan(String oldPan) {
		this.oldPan = oldPan;
	}
	/**
	 * @return the newPan
	 */
	public String getNewPan() {
		return newPan;
	}
	/**
	 * @param newPan the newPan to set
	 */
	public void setNewPan(String newPan) {
		this.newPan = newPan;
	}
	/**
	 * @return the newSeqno
	 */
	public String getNewSeqno() {
		return newSeqno;
	}
	/**
	 * @param newSeqno the newSeqno to set
	 */
	public void setNewSeqno(String newSeqno) {
		this.newSeqno = newSeqno;
	}
	/**
	 * @return the panDisplay
	 */
	public String getPanDisplay() {
		return panDisplay;
	}
	/**
	 * @param panDisplay the panDisplay to set
	 */
	public void setPanDisplay(String panDisplay) {
		this.panDisplay = panDisplay;
	}
	/**
	 * @return the virtualPan
	 */
	public String getVirtualPan() {
		return virtualPan;
	}
	/**
	 * @param virtualPan the virtualPan to set
	 */
	public void setVirtualPan(String virtualPan) {
		this.virtualPan = virtualPan;
	}
	/**
	 * @return the custName
	 */
	public String getCustName() {
		return custName;
	}
	/**
	 * @param custName the custName to set
	 */
	public void setCustName(String custName) {
		this.custName = custName;
	}
	/**
	 * @return the statCode
	 */
	public String getStatCode() {
		return statCode;
	}
	/**
	 * @param statCode the statCode to set
	 */
	public void setStatCode(String statCode) {
		this.statCode = statCode;
	}
	/**
	 * @return the statCodeDescr
	 */
	public String getStatCodeDescr() {
		return statCodeDescr;
	}
	/**
	 * @param statCodeDescr the statCodeDescr to set
	 */
	public void setStatCodeDescr(String statCodeDescr) {
		this.statCodeDescr = statCodeDescr;
	}
	/**
	 * @return the replacementDone
	 */
	public boolean getReplacementDone() {
		return replacementDone;
	}
	/**
	 * @param replacementDone the replacementDone to set
	 */
	public void setReplacementDone(boolean replacementDone) {
		this.replacementDone = replacementDone;
	}
    
}
    
