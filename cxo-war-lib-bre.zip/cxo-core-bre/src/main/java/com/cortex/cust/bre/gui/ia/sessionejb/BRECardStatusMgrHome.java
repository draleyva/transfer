package com.cortex.cust.bre.gui.ia.sessionejb;


import com.cortex.cxo.core.legacyejb.session.EjbSessionBeanHome;


 /**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project No           : 1103  <br>
 * Module Name          : Issuer Authorizer <br>
 * Use case ref			: UC0070<br>
 * Use case name		: changeCardStatus<br>
 * Version No			: 1.0<br>
 * Date created         : 05/09/2002<br>
 * 
 * Description			: EJB Session Home of Card Status Change History Search screen<br>
 *	 
 * Date         Author     Reviewer    Description of change<br>
 * 05\09\2002    Sunandha Ramasamy/Tapasvi/Nithila
 *
 */
public interface BRECardStatusMgrHome extends EjbSessionBeanHome<BRECardStatusMgr>
{

    /**
     * @J2EE_METHOD  --  create
     * Called by the client to create an EJB bean instance. It requires a matching pair in
     * the bean class, i.e. ejbCreate().
     */
    public BRECardStatusMgr create();
}
