package com.cortex.cust.bre.common.constant;

import com.cortex.gui.common.constant.viewConstant;

/**
 *
 * @author e5706717
 */
public class viewConstantBRE extends viewConstant
{
    public static String BUTTON_UNLINK="unlink";
}
