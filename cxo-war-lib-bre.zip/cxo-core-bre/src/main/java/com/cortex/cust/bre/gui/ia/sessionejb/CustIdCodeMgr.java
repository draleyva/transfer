package com.cortex.cust.bre.gui.ia.sessionejb;

import java.rmi.RemoteException;
import java.util.Map;



import com.cortex.common.exception.serverException;
import com.cortex.common.interfaces.IResultInfo;
import com.cortex.cust.bre.common.entityejb.CustIdCodeInfo;
import com.cortex.cust.bre.gui.ia.valueobj.BREReplaceLostOrStolenCardsInfo;
import com.cortex.cust.bre.gui.ia.valueobj.CustIdCodePKInfo;
import com.cortex.cust.bre.gui.ia.valueobj.CustIdCodeSearchInfo;
import com.cortex.cxo.core.legacyejb.session.EjbSessionBean;
import com.cortex.gui.common.valueobj.PagingContextInfo;

/**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project No           : 1103  <br>
 * Module Name          : Ia<br>
 * Global Use Case      : N/A<br>
 * Business Use case    : N/A<br>
 * Maintenance Use case : N/A<br>
 * @author                j2eegen<br>
 *
 * This bean class contains the bussiness methods of Cust_idcode table<br>
 *
 * Date   Author     Reviewer    Description of change<br>
 *
 * @version 1.0
 */
public interface CustIdCodeMgr extends EjbSessionBean
{

    public IResultInfo updateCustIdCode(CustIdCodeInfo pobjCust_idcodeInfo) throws RemoteException,serverException;

    public void deleteCustIdCode(CustIdCodePKInfo pobjCust_idcodePKInfo) throws RemoteException,serverException;

    public void addCustIdCode(CustIdCodeInfo pobjCust_idcodeInfo) throws RemoteException,serverException;

    public CustIdCodeInfo getCustIdCode(CustIdCodePKInfo pobjCust_idcodePKInfo) throws RemoteException,serverException;

    public java.util.List searchCustIdCode(CustIdCodeSearchInfo pobjCust_idcodeSearchInfo, PagingContextInfo pobjPagingContextInfo)
        throws RemoteException,serverException;
    
    public Map getCustomerDetails(String custCode, String inst) throws RemoteException,serverException;
    
    public void replaceCard(BREReplaceLostOrStolenCardsInfo bREReplaceLostOrStolenCardsInfo) throws RemoteException,serverException;


}


