package com.cortex.cust.bre.gui.ia.sessionejb;

import com.cortex.cxo.core.legacyejb.session.EjbSessionBeanHome;
import com.cortex.gui.ia.sessionejb.AccdetMgr;



/**
 * @author : Y.Vinay Kumar
 */
public interface BREAccdetMgrHome extends EjbSessionBeanHome<AccdetMgr>
{
    public BREAccdetMgr create()
       ;
}
