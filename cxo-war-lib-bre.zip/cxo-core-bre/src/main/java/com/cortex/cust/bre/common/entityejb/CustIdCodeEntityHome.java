package com.cortex.cust.bre.common.entityejb;

import java.rmi.RemoteException;


import com.cortex.common.exception.serverException;
import com.cortex.cust.bre.gui.ia.sessionejb.CustIdCodeMgr;
import com.cortex.cxo.core.legacyejb.LegacyEjbCreateException;
import com.cortex.cxo.core.legacyejb.LegacyEjbFinderException;
import com.cortex.cxo.core.legacyejb.session.EjbSessionBeanHome;

/**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project no: <br>
 * Use case no: <br>
 * Use case name: Cust_idcodeEntityHome<br>
 *
 * This is a home interface of entity bean which declare create and find method
 * of Cust_idcode
 *
 * @author j2eegen
 */
public interface CustIdCodeEntityHome extends EjbSessionBeanHome<CustIdCodeMgr> {

    public CustIdCodeEntity create(CustIdCodeInfo cust_idcodeInfo)
            throws LegacyEjbCreateException, serverException, RemoteException;

    public CustIdCodeEntity findByPrimaryKey(CustIdCodePK primaryKey)
            throws LegacyEjbFinderException, RemoteException;
}
