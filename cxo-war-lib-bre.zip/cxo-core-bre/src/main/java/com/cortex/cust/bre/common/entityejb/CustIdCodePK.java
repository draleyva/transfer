package com.cortex.cust.bre.common.entityejb;

import com.cortex.common.entityejb.key.BaseKey;

import java.io.Serializable;

/**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project no: <br>
 * Use case no: <br>
 * Use case name: Cust_idcodePK<br>
 *
 * This is primary key class.
 *
 *
 * @author j2eegen
 */
public class CustIdCodePK extends BaseKey implements Serializable
{
    private int hashCode = -1;
    public long id;

    public CustIdCodePK(){}

    public CustIdCodePK(long id)
    {
        this.id = id;
    }

    public boolean equals(Object other)
    {
        if (other == this)
            {
            return true;
            }

            if (!(other instanceof CustIdCodePK))
        {
            return false;
        }

        CustIdCodePK otherPK = (CustIdCodePK)other;

        if (otherPK.hashCode() == hashCode())
        {
            return id == otherPK.id;

        }
        else
        {
            return false;
        }
    }

    public int hashCode()
    {
        if( hashCode == -1 )
        {
            hashCode = (int)(id);
        }
        return hashCode;
    }
    public String toString()
    {
        return "(" + String.valueOf(id) + ")";
    }
}
