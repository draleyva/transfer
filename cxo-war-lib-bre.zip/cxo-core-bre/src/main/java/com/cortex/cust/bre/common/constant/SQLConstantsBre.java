package com.cortex.cust.bre.common.constant;

public interface SQLConstantsBre {

    public static String GET_CUSTOMER_DETAILS = "Select cd.id, cd.title, cd.firstname, cd.lastname from custdet cd, inst ist where cd.custcode=? and ist.instcode=? and cd.inst_id=ist.id ";
    public static String GET_CUSTOMER_NAME = "name";
    public static String GET_CUSTOMER_ID = "id";

    public static String INDENTIFICATION_TYPE_LIST = "indentificationTypeList";
    public static String INDENTIFICATION_TYPE_SQL = "Select custidtype.id , custidtype.idtypecode||' - '||custidtype.idtypedescr descr from custidtype, inst where custidtype.inst_id = inst.id ";
    public static String INDENTIFICATION_TYPE_LABEL = "descr";
    public static String INDENTIFICATION_TYPE_VALUE = "id";
    public static String INDENTIFICATION_TYPE_DEFAULT = "dropdown.tablename";

    public static String GET_CUSTOMER_IDENTIFICATION_DEFAULT_ACCOUNT = "on";

    public static String REPLACE_CARD_PAN_VALIDATION = "Select cu.custcode from crddet c, crdproduct p, custdet cu, inst inst where c.crdproduct_id = p.id and p.inst_id = inst.id and cu.id = c.custdet_id and c.pan = ? and c.seqno = 0 and inst.instcode = ?";
    public static String REPLACE_CARD_CHARGEDATA_INSERT = "Insert into chargedata(verno_ctx, ctxdate, crddet_id, chargetype, chargedata, chargecur, custtype, opdata, processed)  values (0, ?, ?, ?, ' ', ?, 0, ' ', 0)";
    public static String UDPATE_CRDRPLACE = "insert into CRDRPLACE(VERNO_CTX ,DATERPLC ,USR ,REASON ,NEW_CRDDET_ID ,OLD_CRDDET_ID) values (?, ?, ?, ?, ?, ?)";

    public static final String GET_BRE_STATUS_TRANSITION_CONTROL_SQL1 = "Select count(*) from bre_cust_crdstatustrans c, bre_cust_crdstatustransset s  where s.id = c.crdstatustransset_id and c.statcode_from = ? and c.statcode_to = ?";
    public static final String GET_BRE_STATUS_TARNSITION_CONTROL_SQL2 = "Select count(*) from bre_cust_crdstatustrans c, bre_cust_crdstatustransset s  where s.id = c.crdstatustransset_id and c.statcode_from = ? ";

    // Constants for Card Status dropdown
    public static String CARD_STATUS_LIST = "cardStatusList";
    public static String CARD_STATUS_SQL = "SELECT TRIM(statcode) as statcode,TRIM(statcode) || '-' ||descr as descr FROM CRDSTATUS order by statcode";
    public static String CARD_STATUS_LABEL = "descr";
    public static String CARD_STATUS_VALUE = "statcode";
    public static String CARD_STATUS_DEFAULT = "dropdown.tablename";

    // Constants for Card Status dropdown
    public static String GET_USER_ID_SQL = "SELECT ID as FROM USR WHERE USR = ?";
    public static String GET_USER_ID_ID = "ID";

    // CRDDET
    public static final String UNLINK_CRDDET_SELECT = "select id, pan, seqno, expdate, statcode, accdet_id from crddet " +
      "where accdet_id in " +
      "(select id from accdet where inst_id = ? and accno = ? and currcode = ?)";
    
    public static final String UNLINK_CRDDET_UPDATE = "update crddet " +
      "set statcode = ?, accdet_id = ? " +
      "where id = ?";
  
    // CRDACC
    public static final String UNLINK_CRDACC_SELECT = "select CRDDET_ID, ACCDET_ID from crdacc " +
      "where accdet_id in " +
      "(select id from accdet where inst_id = ? and accno = ? and currcode = ?)";
    
    public static final String UNLINK_CRDACC_DELETE = "delete from crdacc " + 
      "where CRDDET_ID = ? and accdet_id = ?";
  
    // CRDACCUPL
    public static final String UNLINK_CRDACCUPL_SELECT = "select id from crdaccupl " + 
      "where accdet_id in "+
      "(select id from accdet where inst_id = ? and accno = ? and currcode = ?)";
    
    public static final String UNLINK_CRDACCUPL_DELETE = "delete from crdaccupl " + 
      "where id = ?";
}
