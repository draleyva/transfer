package com.cortex.cust.bre.gui.ia.sessionejb;


import com.cortex.cxo.core.legacyejb.session.EjbSessionBeanHome;



/**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project No           : 1103  <br>
 * Module Name          : Ia<br>
 * Global Use Case      : N/A<br>
 * Business Use case    : N/A<br>
 * Maintenance Use case : N/A<br>
 * @author                j2eegen<br>
 *
 * This bean class contains the bussiness methods of Cust_idcode table<br>
 *
 * Date   Author     Reviewer    Description of change<br>
 *
 * @version 1.0
 */
public interface CustIdCodeMgrHome extends EjbSessionBeanHome<CustIdCodeMgr>
{

      public CustIdCodeMgr create()
             ;

}

