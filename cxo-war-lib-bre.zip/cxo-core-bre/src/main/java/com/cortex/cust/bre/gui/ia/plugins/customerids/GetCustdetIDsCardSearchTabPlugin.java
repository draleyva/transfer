package com.cortex.cust.bre.gui.ia.plugins.customerids;

import org.apache.commons.lang3.StringUtils;

import com.cortex.common.hook.HookInterface;
import com.cortex.common.hook.HookParam;
import com.cortex.gui.ia.valueobj.CardMaintSearchInfo;

public class GetCustdetIDsCardSearchTabPlugin implements HookInterface {

    public static final String CLASSNAME = "GetCustdetIDsCardSearchTabPlugin";

    public static final String GET_IA_CUSTDET_SEARCH_COUNT_SQL_BPD = "select count(*) as count from crddet a, branch b, custdet c, accdet d, inst i, custidcode custidcode "
            + "where custidcode.custdet_id = c.id and c.id = a.custdet_id and  i.id = b.inst_id and b.id = a.branch_id "
            + "and d.id = a.accdet_id and 1=1 ";
    public static String GET_IA_CUSTDET_SEARCH_SQL_BPD = "Select a.id, a.batch, a.seqno, a.pan, i.instcode instcode, b.brncode brncode, a.expdate, a.statcode, "
            + "c.custcode custcode, a.date_birth, d.accno accno, d.currcode currcode, a.embossname, a.pan_display, a.iss_host_crdref "
            + "from crddet a, branch b, custdet c, accdet d, inst i, custidcode custidcode where custidcode.custdet_id = c.id "
            + "and c.id = a.custdet_id and  i.id = b.inst_id and b.id = a.branch_id and d.id = a.accdet_id ";

    public HookParam process(HookParam param) throws Exception {
        String tsBRESQlQuery = (String) param.get(HookParam.PARAM1);
        String tsBRECountQuery = (String) param.get(HookParam.PARAM2);
        CardMaintSearchInfo pobjCardMaintSearchInfo = (CardMaintSearchInfo) param.get(HookParam.PARAM3);

        if (StringUtils.isNotBlank(pobjCardMaintSearchInfo.getInstcode7())) {
            tsBRESQlQuery = GET_IA_CUSTDET_SEARCH_SQL_BPD;
            tsBRECountQuery = GET_IA_CUSTDET_SEARCH_COUNT_SQL_BPD;
        } else {
            tsBRESQlQuery = null;
            tsBRECountQuery = null;
        }

        param.put(HookParam.PARAM1, tsBRESQlQuery);
        param.put(HookParam.PARAM2, tsBRECountQuery);

        return param;
    }

}
