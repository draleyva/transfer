package com.cortex.cust.bre.gui.ia.sessionejb;

import com.cortex.common.entityejb.*;
import com.cortex.common.exception.serverException;
import com.cortex.common.lib.FunctionLib;
import com.cortex.common.lib.dateTimeLib;
import com.cortex.common.lib.dbLib;
import com.cortex.common.util.debugLib;
import com.cortex.cust.bre.common.constant.SQLConstantsBre;
import com.cortex.cxo.core.legacyejb.entity.HomeEjbEntityController;
import com.cortex.gui.ia.sessionejb.AccdetMgrBean;
import com.cortex.gui.ia.valueobj.AccdetDetailInfo;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import static java.util.Calendar.DAY_OF_MONTH;
import static org.apache.commons.lang3.time.DateUtils.truncate;

/**
 *
 * @author e5706717
 */
public class BREAccdetMgrBean extends AccdetMgrBean
{
  private static final String CLASSNAME = "BREAccdetMgrBean";

  private HomeEjbEntityController<CdsthstEntityHome> cdsthstHomeCacheController;
  
  @Override
  public void ejbCreate()
  {
    super.ejbCreate();
    
    try {

      cdsthstHomeCacheController = ejbEntityHomeController(CdsthstEntityHome.class);
    }
    catch (Exception e)
    {
      debugLib.logError(CLASSNAME, e, userName());
      //throw new LegacyEjbCreateException(e.toString());
    }
  }
  
  public String toString(AccdetDetailInfo adi)
  {
    return String.format("ACCDET <instcode %d accno %s currcode %s>", adi.getInst_id(), adi.getAccno(), adi.getCurrCode());
  }
  
  public void unlinkAccdet(AccdetDetailInfo adi) throws RemoteException, serverException
  {
    Connection connection = null;
      
    try
    {
      connection = getConnection();
      
      logInfo(String.format("UNLINK %s", toString(adi)));

      unlinkUpdateCRDDET(connection, adi);
      
      unlinkDeleteCRDACC(connection, adi);

      //ToDo: Check if this table is still needed. It was removed from the core code.
     // unlinkDeleteCRDACCUPL(connection, adi);


      acsLogWriter().writeAccessLog(userName(), String.format("UNLINK success %s", toString(adi)));
    }
    catch (Exception e)
    {
       acsLogWriter().writeAccessLog(userName(), String.format("UNLINK failed %s", toString(adi)));
      
      debugLib.logError(CLASSNAME, e.toString(), userName());
    }
    finally
    {
      closeConnection(connection);
    }    
  }
  
  protected final static String UNLINK_CRDDET_STATCODE = "07";
  protected final static Long UNLINK_CRDDET_ACCDETID = 699L;
  
  void unlinkUpdateCRDDET(Connection connection, AccdetDetailInfo adi) throws Exception
  {
    PreparedStatement statement;
    ResultSet resultset;
            
    try
    {
      statement = connection.prepareStatement(SQLConstantsBre.UNLINK_CRDDET_SELECT);
      statement.setLong(1, adi.getInst_id());
      statement.setString(2, adi.getAccno());
      statement.setString(3, adi.getCurrCode());
      
      List<CrddetPK> crddetpklist = new ArrayList<>();
      List<CrddetInfo> crddetinfo = new ArrayList<>();
              
      resultset = statement.executeQuery();
      
      while (resultset.next())
      {
        crddetpklist.add(new CrddetPK(resultset.getLong(1)));
        
        CrddetInfo cdi = new CrddetInfo();
        
        cdi.setInstcode(adi.getInstcode());
        cdi.setPan(FunctionLib.getDbString(resultset.getString(2)));
        cdi.setSeqno(resultset.getInt(3));
        cdi.setExpdate(resultset.getDate(4));
        cdi.setStatcode(resultset.getString(5));
        cdi.setAccdet_id(resultset.getLong(6));
        
        crddetinfo.add(cdi);
      }
      
      dbLib.closeResultSet(resultset);
      dbLib.closeStatement(statement);
      
      if(crddetpklist.isEmpty())
         acsLogWriter().writeAccessLog(userName(), String.format("CRDDET unlink [update] %s : no records", toString(adi)));
      
      for(int i = 0; i < crddetpklist.size(); ++i)
      {
        statement = connection.prepareStatement(SQLConstantsBre.UNLINK_CRDDET_UPDATE);
        
        statement.setString(1, UNLINK_CRDDET_STATCODE);
        statement.setLong(2, UNLINK_CRDDET_ACCDETID);
        statement.setLong(3, crddetpklist.get(i).id);

        statement.executeUpdate();
      
        dbLib.closeStatement(statement);
        
        createCDSTHST(crddetpklist.get(i), crddetinfo.get(i), crddetinfo.get(i).getStatcode(), UNLINK_CRDDET_STATCODE, "Unlink update");

         acsLogWriter().writeAccessLog(userName(),
                String.format("CRDDET unlink [update] id %d : statcode %s => %s accdet_id %d => %d", 
                     crddetpklist.get(i).id,
                     crddetinfo.get(i).getStatcode(), UNLINK_CRDDET_STATCODE, crddetinfo.get(i).getAccdet_id(), UNLINK_CRDDET_ACCDETID));
      } 
    }
    catch(Exception e)
    {
      throw e;
    }
  }
  
  protected void createCDSTHST(CrddetPK crddetpk, CrddetInfo crddetinfo, String oldstatcode, String newstatcode, String whyset) throws Exception
  {
    CdsthstInfo tobjCdsthstInfo = new CdsthstInfo();
    CdsthstEntityHome tobjCdsthstEntityHome = (CdsthstEntityHome) cdsthstHomeCacheController.getHome();
    
    tobjCdsthstInfo.setInstcode(crddetinfo.getInstcode());
    tobjCdsthstInfo.setPan(crddetinfo.getPan());
    tobjCdsthstInfo.setSeqno(crddetinfo.getSeqno());
    tobjCdsthstInfo.setExpdate(crddetinfo.getExpdate());
    tobjCdsthstInfo.setOld_statcode(oldstatcode);
    tobjCdsthstInfo.setNew_statcode(newstatcode);
    tobjCdsthstInfo.setDate_set(new java.sql.Date(truncate(dateTimeLib.getCurrentDate(), DAY_OF_MONTH).getTime()));
    tobjCdsthstInfo.setTime_set(dateTimeLib.getCurrentTime());
    tobjCdsthstInfo.setWhy_set(whyset);
    tobjCdsthstInfo.setWho_set(userName());
    
    tobjCdsthstEntityHome.create(tobjCdsthstInfo);
  }
  
  void unlinkDeleteCRDACC(Connection connection, AccdetDetailInfo adi) throws Exception
  {
    PreparedStatement statement;
    ResultSet resultset;
            
    try
    {
      statement = connection.prepareStatement(SQLConstantsBre.UNLINK_CRDACC_SELECT);
      statement.setLong(1, adi.getInst_id());
      statement.setString(2, adi.getAccno());
      statement.setString(3, adi.getCurrCode());
      
      List<CrdaccPK> crdaccpklist = new ArrayList<>();
              
      resultset = statement.executeQuery();
      
      while (resultset.next())
        crdaccpklist.add(new CrdaccPK(resultset.getLong(1), resultset.getLong(2)));
      
      dbLib.closeResultSet(resultset);
      dbLib.closeStatement(statement);
      
      if(crdaccpklist.isEmpty())
         acsLogWriter().writeAccessLog(userName(), String.format("CRDACC unlink [delete] %s : no records", toString(adi)));
      
      for(CrdaccPK crdaccpk : crdaccpklist)
      {
        statement = connection.prepareStatement(SQLConstantsBre.UNLINK_CRDACC_DELETE);
        
        statement.setLong(1, crdaccpk.crddet_id);
        statement.setLong(2, crdaccpk.accdet_id);

        statement.executeUpdate();
      
        dbLib.closeStatement(statement);
        
         acsLogWriter().writeAccessLog(userName(),
                String.format("CRDACC unlink [delete] : crddet_id %d accdet_id %d", 
                     crdaccpk.crddet_id, crdaccpk.accdet_id));
      } 
    }
    catch(Exception e)
    {
      throw e;
    }
  }

  /*
  void unlinkDeleteCRDACCUPL(Connection connection, AccdetDetailInfo adi) throws Exception
  {
    PreparedStatement statement;
    ResultSet resultset;
    
    try
    {
      statement = connection.prepareStatement(SQLConstantsBre.UNLINK_CRDACCUPL_SELECT);
      
      statement.setLong(1, adi.getInst_id());
      statement.setString(2, adi.getAccno());
      statement.setString(3, adi.getCurrCode());

      List<CrdaccuplPK> crdaccuplpklist = new ArrayList<>();
      
      resultset = statement.executeQuery();
      
      while (resultset.next())
        crdaccuplpklist.add(new CrdaccuplPK(resultset.getLong(1)));
      
      dbLib.closeResultSet(resultset);
      dbLib.closeStatement(statement);
      
      if(crdaccuplpklist.isEmpty())
         acsLogWriter().writeAccessLog(userName(), String.format("CRDACCUPL unlink [delete] %s : no records", toString(adi)));
      
      for(CrdaccuplPK crdaccuplpk : crdaccuplpklist)
      {
        statement = connection.prepareStatement(SQLConstantsBre.UNLINK_CRDACCUPL_DELETE);
        statement.setLong(1, crdaccuplpk.id);
      
        statement.executeUpdate();
        
        dbLib.closeStatement(statement);
        
         acsLogWriter().writeAccessLog(userName(),
                String.format("CRDACCUPL unlink [delete] : id %d", 
                     crdaccuplpk.id));
      }
    }
    catch(Exception e)
    {
      throw e;
    }
  }
  */

}
