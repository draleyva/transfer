package com.cortex.cust.bre.gui.ia.sessionejb;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.cortex.common.constant.SQLConstants;
import com.cortex.common.constant.globalConstant;
import com.cortex.common.exception.serverException;
import com.cortex.common.hook.HookFactory;
import com.cortex.common.hook.HookParam;
import com.cortex.common.lib.debugLib;
import com.cortex.cxo.core.legacyejb.EjbCxoReadOnlyTransactional;
import com.cortex.cxo.core.legacyejb.EjbCxoTransactional;
import com.cortex.cxo.core.legacyejb.session.AbstractCoreServicesSupportSessionBean;
import com.cortex.gui.common.constant.IChConstant;
import com.cortex.gui.common.lib.PageWithSorting;
import com.cortex.gui.common.lib.PagingInterface;
import com.cortex.gui.common.lib.WhereClauseLib;
import com.cortex.gui.common.valueobj.PageWithSortingDataInfo;
import com.cortex.gui.common.valueobj.PagingContextInfo;
import com.cortex.gui.common.valueobj.WhereClauseInfo;
import com.cortex.gui.ia.valueobj.CardStatusChangeHistorySearchInfo;
import com.cortex.gui.ia.valueobj.SetCardStatusDetailInfo;
import com.cortex.cust.bre.common.constant.SQLConstantsBre;

@Service
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
@Lazy
@EjbCxoTransactional
public class BRECardStatusMgrBean extends AbstractCoreServicesSupportSessionBean<BRECardStatusMgr> implements BRECardStatusMgrHome, BRECardStatusMgr, PagingInterface {
    private static final String CLASSNAME = "CardStatusMgrBean";

    private SetCardStatusDetailInfo mobjSetCardStatusDetailInfo;

    /**
     * This method is to search the CardStatus details.
     *
     * @param pobjCardStatusChangeHistorySearchInfo info object
     * @param pobjPagingContextInfo paging context info
     * @return ArrayList
     *
     * @throws serverException if there is an exception
     */
    public ArrayList searchCardStatusChangeHistory(
            CardStatusChangeHistorySearchInfo pobjCardStatusChangeHistorySearchInfo,
            PagingContextInfo pobjPagingContextInfo) throws  serverException {
        ArrayList tobjSearchInfo = new ArrayList();
        boolean tbWhereFlag = true;
        try {

            pobjPagingContextInfo.setPKColumnAliasName(SQLConstants.GET_IA_CRDSTHST_SEARCH_PK_ALIAS_NAME);
            pobjPagingContextInfo.setPKVariableType(false);
            pobjPagingContextInfo.setPKColumn(SQLConstants.GET_IA_CRDSTHST_SEARCH_PK);
            pobjPagingContextInfo.setSortVariableType(false);

            pobjPagingContextInfo.setSortDirection(false);

            if (pobjPagingContextInfo.getSortColumn().trim().length() == 0) {
                pobjPagingContextInfo.setSortColumn(SQLConstants.GET_IA_CRDSTHST_SEARCH_SORT_COL_NAME);
            }

            Vector<WhereClauseInfo> whereClauseInfo = getWhereForSearch(pobjCardStatusChangeHistorySearchInfo);
            String tsWhereClause = WhereClauseLib.formPreparedWhereClauseWithoutValue(whereClauseInfo);

            String tsSQlQuery = SQLConstants.GET_IA_CRDSTHST_SEARCH_SQL;
            String tsCountQuery = SQLConstants.GET_IA_CRDSTHST_SEARCH_COUNT_SQL;

            tbWhereFlag = false;
            if (!tsWhereClause.trim().equals("")) {
                tsSQlQuery += " and " + tsWhereClause;
                tsCountQuery += " and " + tsWhereClause;
            }

            PageWithSortingDataInfo tobjPageWithSortingDataInfo = new PageWithSortingDataInfo();
            tobjPageWithSortingDataInfo.msSelectQry = tsSQlQuery;
            tobjPageWithSortingDataInfo.msCountQry = tsCountQuery;
            tobjPageWithSortingDataInfo.miCountColumn = SQLConstants.GET_IA_CRDSTHST_SEARCH_COUNT;
            tobjPageWithSortingDataInfo.miPKAliasColumn = SQLConstants.GET_IA_CRDSTHST_SEARCH_PK_ALIAS;
            tobjPageWithSortingDataInfo.miSortColumn = SQLConstants.GET_IA_CRDSTHST_SEARCH_DATE_SET;
            tobjPageWithSortingDataInfo.mbWhereFlag = tbWhereFlag;
            tobjPageWithSortingDataInfo.mobjPagingContextInfo = pobjPagingContextInfo;
            tobjPageWithSortingDataInfo.mobjPagingInterface = this;
            tobjPageWithSortingDataInfo.whereClauseInfo = whereClauseInfo;

            PageWithSorting tobjPageWithSorting = new PageWithSorting();
            tobjSearchInfo = tobjPageWithSorting.getSearchDetails(tobjPageWithSortingDataInfo, getConnection());
        } catch (serverException se) {
            debugLib.logError(CLASSNAME, se, userName());
            throw se;
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), userName());
            throw new serverException("error.unknownerror");
        }

        return tobjSearchInfo;
    }

    /**
     * A generalised SQL Where clause
     *
     * @param pobjCardStatusChangeHistorySearchInfo info object
     * @return Vector
     * @exception serverException if there is an exception
     */
    private Vector<WhereClauseInfo> getWhereForSearch(CardStatusChangeHistorySearchInfo pobjCardStatusChangeHistorySearchInfo)
            throws serverException {
        Vector<WhereClauseInfo> tvecWhereClauseInfo = new Vector<WhereClauseInfo>();

        if (!pobjCardStatusChangeHistorySearchInfo.getPan().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo1 = new WhereClauseInfo();
            tobjWhereClauseInfo1.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_PAN_NAME);
            tobjWhereClauseInfo1.setVariableValue(panCryptor().encryptPan(
                    pobjCardStatusChangeHistorySearchInfo.getPan().trim()));
            tobjWhereClauseInfo1.setVaribleType(globalConstant.WHERE_TYPE_STRING);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo1);
        }
        if (!pobjCardStatusChangeHistorySearchInfo.getStrSeqno().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo2 = new WhereClauseInfo();
            tobjWhereClauseInfo2.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_SEQNO_NAME);
            tobjWhereClauseInfo2.setVariableValue(pobjCardStatusChangeHistorySearchInfo.getStrSeqno().trim());
            tobjWhereClauseInfo2.setVaribleType(globalConstant.WHERE_TYPE_INT);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo2);
        }

        return tvecWhereClauseInfo;
    }

    /**
     * This method is to search the CardStatus details.
     *
     * @param pobjCardStatusChangeHistorySearchInfo info object
     * @param pobjPagingContextInfo paging context info
     * @return ArrayList
     *
     * @throws serverException if there is an exception
     */
    public ArrayList searchCardStatusChangeHistory1(
            CardStatusChangeHistorySearchInfo pobjCardStatusChangeHistorySearchInfo,
            PagingContextInfo pobjPagingContextInfo) throws  serverException {
        ArrayList tobjSearchInfo = new ArrayList();
        boolean tbWhereFlag = true;
        try {

            pobjPagingContextInfo.setPKColumnAliasName(SQLConstants.GET_IA_CRDSTHST_SEARCH_PK_ALIAS_NAME);
            pobjPagingContextInfo.setPKVariableType(false);
            pobjPagingContextInfo.setPKColumn(SQLConstants.GET_IA_CRDSTHST_SEARCH_PK);
            pobjPagingContextInfo.setSortVariableType(false);

            pobjPagingContextInfo.setSortDirection(false);

            if (pobjPagingContextInfo.getSortColumn().trim().length() == 0) {
                pobjPagingContextInfo.setSortColumn(SQLConstants.GET_IA_CRDSTHST_SEARCH_SORT_COL_NAME);
            }

            Vector<WhereClauseInfo> whereClauseInfo = getWhereForSearch1(pobjCardStatusChangeHistorySearchInfo);
            String tsWhereClause = WhereClauseLib.formPreparedWhereClauseWithoutValue(whereClauseInfo);

            String tsSQlQuery = SQLConstants.GET_IA_CRDSTHST_SEARCH_SQL;
            String tsCountQuery = SQLConstants.GET_IA_CRDSTHST_SEARCH_COUNT_SQL;

            tbWhereFlag = false;
            if (!tsWhereClause.trim().equals("")) {
                tsSQlQuery += " and " + tsWhereClause;
                tsCountQuery += " and " + tsWhereClause;
            }

            PageWithSortingDataInfo tobjPageWithSortingDataInfo = new PageWithSortingDataInfo();
            tobjPageWithSortingDataInfo.msSelectQry = tsSQlQuery;
            tobjPageWithSortingDataInfo.msCountQry = tsCountQuery;
            tobjPageWithSortingDataInfo.miCountColumn = SQLConstants.GET_IA_CRDSTHST_SEARCH_COUNT;
            tobjPageWithSortingDataInfo.miPKAliasColumn = SQLConstants.GET_IA_CRDSTHST_SEARCH_PK_ALIAS;
            tobjPageWithSortingDataInfo.miSortColumn = SQLConstants.GET_IA_CRDSTHST_SEARCH_PAN;
            tobjPageWithSortingDataInfo.mbWhereFlag = tbWhereFlag;
            tobjPageWithSortingDataInfo.mobjPagingContextInfo = pobjPagingContextInfo;
            tobjPageWithSortingDataInfo.mobjPagingInterface = this;
            tobjPageWithSortingDataInfo.whereClauseInfo = whereClauseInfo;

            PageWithSorting tobjPageWithSorting = new PageWithSorting();
            tobjSearchInfo = tobjPageWithSorting.getSearchDetails(tobjPageWithSortingDataInfo, getConnection());
        } catch (serverException se) {
            debugLib.logError(CLASSNAME, se, userName());
            throw se;
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), userName());
            throw new serverException("error.unknownerror");
        }

        return tobjSearchInfo;
    }

    /**
     * A generalised SQL Where clause
     *
     * @param pobjCardStatusChangeHistorySearchInfo info object
     * @return Vector
     * @exception serverException if there is an exception
     */
    private Vector<WhereClauseInfo> getWhereForSearch1(CardStatusChangeHistorySearchInfo pobjCardStatusChangeHistorySearchInfo)
            throws serverException {
        Vector<WhereClauseInfo> tvecWhereClauseInfo = new Vector<WhereClauseInfo>();

        if (!pobjCardStatusChangeHistorySearchInfo.getPan().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo1 = new WhereClauseInfo();
            tobjWhereClauseInfo1.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_PAN_NAME);
            tobjWhereClauseInfo1.setVariableValue(panCryptor().encryptPan(
                    pobjCardStatusChangeHistorySearchInfo.getPan().trim()));
            tobjWhereClauseInfo1.setVaribleType(globalConstant.WHERE_TYPE_STRING);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo1);
        }
        if (!pobjCardStatusChangeHistorySearchInfo.getVirtualPan().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo = new WhereClauseInfo();
            tobjWhereClauseInfo.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_VIRTUALPAN_NAME);
            tobjWhereClauseInfo.setVariableValue(pobjCardStatusChangeHistorySearchInfo.getVirtualPan().trim());
            tobjWhereClauseInfo.setVaribleType(globalConstant.WHERE_TYPE_STRING);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo);
        }

        if (!pobjCardStatusChangeHistorySearchInfo.getStrSeqno().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo2 = new WhereClauseInfo();
            tobjWhereClauseInfo2.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_SEQNO_NAME);
            tobjWhereClauseInfo2.setVariableValue(pobjCardStatusChangeHistorySearchInfo.getStrSeqno().trim());
            tobjWhereClauseInfo2.setVaribleType(globalConstant.WHERE_TYPE_INT);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo2);
        }

        if (!pobjCardStatusChangeHistorySearchInfo.getStrDateset().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo3 = new WhereClauseInfo();
            tobjWhereClauseInfo3.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_DATE_SET_NAME);
            tobjWhereClauseInfo3.setVariableValue(pobjCardStatusChangeHistorySearchInfo.getStrDateset().trim());
            tobjWhereClauseInfo3.setVaribleType(globalConstant.WHERE_TYPE_DATE);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo3);
        }

        if (!pobjCardStatusChangeHistorySearchInfo.getNewstatcode().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo3 = new WhereClauseInfo();
            tobjWhereClauseInfo3.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_NEW_STATCODE_NAME);
            tobjWhereClauseInfo3.setVariableValue(pobjCardStatusChangeHistorySearchInfo.getNewstatcode().trim());
            tobjWhereClauseInfo3.setVaribleType(globalConstant.WHERE_TYPE_STRING);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo3);
        }

        if (!pobjCardStatusChangeHistorySearchInfo.getOldstatcode().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo3 = new WhereClauseInfo();
            tobjWhereClauseInfo3.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_OLD_STATCODE_NAME);
            tobjWhereClauseInfo3.setVariableValue(pobjCardStatusChangeHistorySearchInfo.getOldstatcode().trim());
            tobjWhereClauseInfo3.setVaribleType(globalConstant.WHERE_TYPE_STRING);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo3);
        }

        if (!pobjCardStatusChangeHistorySearchInfo.getWhoset().trim().equals("")) {
            WhereClauseInfo tobjWhereClauseInfo3 = new WhereClauseInfo();
            tobjWhereClauseInfo3.setDBColumnName(SQLConstants.GET_IA_CRDSTHST_SEARCH_WHO_SET_NAME);
            tobjWhereClauseInfo3.setVariableValue(pobjCardStatusChangeHistorySearchInfo.getWhoset().trim());
            tobjWhereClauseInfo3.setVaribleType(globalConstant.WHERE_TYPE_STRING);
            tvecWhereClauseInfo.addElement(tobjWhereClauseInfo3);
        }

        return tvecWhereClauseInfo;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @EjbCxoReadOnlyTransactional
    public Object getDataFromCachedRowset(ResultSet pobjResultSet) {
        CardStatusChangeHistorySearchInfo tobjCardStatusChangeHistorySearchInfo = null;

        try {
            tobjCardStatusChangeHistorySearchInfo = new CardStatusChangeHistorySearchInfo();
            tobjCardStatusChangeHistorySearchInfo.setStrDateset(pobjResultSet
                    .getString(SQLConstants.GET_IA_CRDSTHST_SEARCH_DATE_SET));
            tobjCardStatusChangeHistorySearchInfo.setStrTimeset(pobjResultSet
                    .getString(SQLConstants.GET_IA_CRDSTHST_SEARCH_TIME_SET));
            tobjCardStatusChangeHistorySearchInfo.setNewstatcode(pobjResultSet
                    .getString(SQLConstants.GET_IA_CRDSTHST_SEARCH_NEW_STATCODE));
            tobjCardStatusChangeHistorySearchInfo.setOldstatcode(pobjResultSet
                    .getString(SQLConstants.GET_IA_CRDSTHST_SEARCH_OLD_STATCODE));
            tobjCardStatusChangeHistorySearchInfo.setWhyset(pobjResultSet
                    .getString(SQLConstants.GET_IA_CRDSTHST_SEARCH_WHY_SET));
            tobjCardStatusChangeHistorySearchInfo.setWhoset(pobjResultSet
                    .getString(SQLConstants.GET_IA_CRDSTHST_SEARCH_WHO_SET));
            tobjCardStatusChangeHistorySearchInfo.setTimeset(pobjResultSet
                    .getLong(SQLConstants.GET_IA_CRDSTHST_SEARCH_TIME_SET));
            tobjCardStatusChangeHistorySearchInfo.setPan(pobjResultSet
                    .getString(SQLConstants.GET_IA_CRDSTHST_SEARCH_PAN));
            tobjCardStatusChangeHistorySearchInfo.setSeqno(pobjResultSet
                    .getInt(SQLConstants.GET_IA_CRDSTHST_SEARCH_SEQNO));
            tobjCardStatusChangeHistorySearchInfo.setPanDisplay(pobjResultSet
                    .getString(SQLConstants.GET_IA_CRDSTHST_SEARCH_PANDISPLAY));
            tobjCardStatusChangeHistorySearchInfo.setVirtualPan(pobjResultSet
                    .getString(SQLConstants.GET_IA_CRDSTHST_SEARCH_VIRTUALPAN));
            tobjCardStatusChangeHistorySearchInfo.setExpdate(pobjResultSet
                    .getDate(SQLConstants.GET_IA_CRDSTHST_SEARCH_EXPDATE));
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), userName());
        }
        return tobjCardStatusChangeHistorySearchInfo;
    }

    private void createFees(boolean pbExtlist) throws serverException {
        Connection tobjConn = null;
        PreparedStatement tobjPstmt = null;
        ResultSet tobjRs = null;

        if (pbExtlist) {
            mobjSetCardStatusDetailInfo.setChargedata(IChConstant.CHRG_ACL_COND_INTER_LIST);
        } else {
            mobjSetCardStatusDetailInfo.setChargedata(IChConstant.CHRG_ACL_COND_LOCAL_LIST);
        }
        mobjSetCardStatusDetailInfo.setChargetype(IChConstant.CHRG_CRD_RESTRICT);
        try {
            tobjConn =getConnection();
            tobjPstmt = tobjConn.prepareStatement(SQLConstants.GET_CARDSTATUS_CRDDET_QUERY6);
            String pan_enc = panCryptor().encryptPan(mobjSetCardStatusDetailInfo.getPan());
            tobjPstmt.setString(1, pan_enc);
            tobjPstmt.setInt(2, mobjSetCardStatusDetailInfo.getSeqno());
            debugLib.logInfo(CLASSNAME, SQLConstants.GET_CARDSTATUS_CRDDET_QUERY6, userName());
            debugLib.logInfo(CLASSNAME, pan_enc, userName());
            debugLib.logInfo(CLASSNAME, mobjSetCardStatusDetailInfo.getSeqno() + "", userName());
            tobjRs = tobjPstmt.executeQuery();
            if (tobjRs.next()) {
                mobjSetCardStatusDetailInfo.setCurrcode(tobjRs.getString(SQLConstants.GET_CARDSTATUS_CURRCODE).trim());
            }

        } catch (SQLException se) {
            debugLib.logError(CLASSNAME, se.toString(), userName());
            throw new serverException("error.db.selectfailed");
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), userName());
            throw new serverException("error.db.selectfailed");
        } finally {
            closeResultSet(tobjRs);
            closeStatement(tobjPstmt);

        }
        if (mobjSetCardStatusDetailInfo.getCurrcode() == null) {
            throw new serverException("error.db.currcodefailed");
        }

        Boolean addChargeData = Boolean.TRUE;
        try {
            HookParam hookParam = new HookParam();
            hookParam.put(HookParam.PARAM1, addChargeData);
            hookParam = HookFactory.getPlugin("com.cortex.gui.ia.plugins.flexfee.FlexFeePlugin").process(hookParam);
            addChargeData = (Boolean) hookParam.get(HookParam.PARAM1);
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString(), userName());
        }

        if (addChargeData.booleanValue()) {
            iaGlobalFunctions().addFlexFee(mobjSetCardStatusDetailInfo.getPan(),
                    mobjSetCardStatusDetailInfo.getSeqno(), mobjSetCardStatusDetailInfo.getChargetype(),
                    mobjSetCardStatusDetailInfo.getChargedata(), mobjSetCardStatusDetailInfo.getCurrcode());
        }

    }
    public String getConfiguredStatusCode() throws serverException {
        Connection tobjConnection = null;
        PreparedStatement tobjpstmt = null;
        ResultSet tobjRs = null;
        String statusCodeForCardActivation = null;
        try {
            tobjConnection = getConnection();
            tobjpstmt = tobjConnection.prepareStatement(SQLConstants.GET_STATUS_CODE_FOR_CARD_ACTIVATION);
            debugLib.logInfo(CLASSNAME, SQLConstants.GET_STATUS_CODE_FOR_CARD_ACTIVATION);
            tobjRs = tobjpstmt.executeQuery();
            while (tobjRs.next()) {
                statusCodeForCardActivation = tobjRs.getString("string_t");
            }
        } catch (SQLException e) {
            debugLib.logError(CLASSNAME, e.toString());
            throw new serverException("error.db.searchfailed");
        }  catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString());
            throw new serverException("error.db.searchfailed");
        } finally {
            try {
                if (tobjpstmt != null) {
                    tobjpstmt.close();
                }
            } catch (SQLException ex) {
            }
            closeConnection(tobjConnection);
        }
        return statusCodeForCardActivation;
    }

    public boolean isTransitionAllowed(String crdproduct, String toStatus, String fromOldStatus, String fromCurrentStatus, String oldOrNewOrBoth, boolean hasOldCard) throws serverException {
        boolean transitionAllowed = false;

        String from = " ";
        if (hasOldCard) {
            if ("0".equals(oldOrNewOrBoth)) // both old and new status change 
            {
                transitionAllowed = isTransitionAllowedCheck(crdproduct, toStatus, fromOldStatus);// for old
                if (!transitionAllowed) {
                    from = fromOldStatus;
                } else {
                    transitionAllowed = isTransitionAllowedCheck(crdproduct, toStatus, fromCurrentStatus);// for new
                    if (!transitionAllowed) {
                        from = fromCurrentStatus;
                    }
                }
            } else if ("1".equals(oldOrNewOrBoth))// new status change
            {
                transitionAllowed = isTransitionAllowedCheck(crdproduct, toStatus, fromCurrentStatus);// for new
                if (!transitionAllowed) {
                    from = fromCurrentStatus;
                }
            } else if ("2".equals(oldOrNewOrBoth)) // old status change
            {
                transitionAllowed = isTransitionAllowedCheck(crdproduct, toStatus, fromOldStatus);// for old
                if (!transitionAllowed) {
                    from = fromOldStatus;
                }
            }
        } else {
            transitionAllowed = isTransitionAllowedCheck(crdproduct, toStatus, fromCurrentStatus);// for new
            if (!transitionAllowed) {
                from = fromCurrentStatus;
            }
        }

        if (!transitionAllowed) {
            throw new serverException("ia.error.TRANSITION_FAILED", from, toStatus);
        }

        return true;
    }

    private boolean isTransitionAllowedCheck(String crdproduct, String toStatus, String fromStatus) throws serverException {
        boolean transitionAllowed = false;
        String selectSQL1 = SQLConstantsBre.GET_BRE_STATUS_TRANSITION_CONTROL_SQL1;
        String selectSQL2 = SQLConstantsBre.GET_BRE_STATUS_TARNSITION_CONTROL_SQL2;
        Connection tobjConnection = null;
        PreparedStatement tobjStatement = null;
        ResultSet tobjResultSet = null;
        try {
            tobjConnection = getConnection();
            tobjStatement = tobjConnection.prepareStatement(selectSQL1);
            tobjStatement.setString(1, fromStatus);
            tobjStatement.setString(2, toStatus);
            tobjResultSet = tobjStatement.executeQuery();
            if (tobjResultSet != null) {
                if (tobjResultSet.next()) {
                    if (tobjResultSet.getInt(1) == 1) {
                        transitionAllowed = true;
                    }
                }
            }
            /*
            if(!transitionAllowed)
            {
	            tobjStatement = tobjConnection.prepareStatement(selectSQL2);
	            tobjStatement.setString(1, fromStatus);	           
	            tobjResultSet = tobjStatement.executeQuery();
	            if (tobjResultSet != null)
	            {
	                if (tobjResultSet.next()) 
	                {
	                	if(tobjResultSet.getInt(1) >= 1)
	                	{
	                		transitionAllowed = false;
	                	}
	                	else
	                	{
	                		transitionAllowed = true;
	                	}
	                }
	            }
            }
            * */
        } catch (SQLException e) {
            debugLib.logError(CLASSNAME, e.toString());
            throw new serverException("error.db.searchfailed");
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString());
            throw new serverException("error.db.searchfailed");
        } finally {
            try {
                if (tobjStatement != null) {
                    tobjStatement.close();
                }
            } catch (SQLException ex) {
                debugLib.logError(CLASSNAME, ex.toString());
                throw new serverException("error.db.searchfailed");
            }
            closeConnection(tobjConnection);
        }
        return transitionAllowed;
    }

}
