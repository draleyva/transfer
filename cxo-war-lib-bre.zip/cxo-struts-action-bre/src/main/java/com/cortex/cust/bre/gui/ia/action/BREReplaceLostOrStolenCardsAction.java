package com.cortex.cust.bre.gui.ia.action;

import java.io.IOException;
import java.rmi.RemoteException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cortex.common.exception.serverException;
import com.cortex.cust.bre.common.constant.serverConstantBre;
import com.cortex.cust.bre.gui.ia.formbean.BREReplaceLostOrStolenCardsForm;
import com.cortex.cust.bre.gui.ia.sessionejb.CustIdCodeMgr;
import com.cortex.cust.bre.gui.ia.sessionejb.CustIdCodeMgrHome;
import com.cortex.cust.bre.gui.ia.valueobj.BREReplaceLostOrStolenCardsInfo;
import com.cortex.gui.common.action.PagingAction;
import com.cortex.gui.common.constant.viewConstant;
/**
* <hr><h3>
* Copyright &copy Nomad Software Ltd.</h3><h4>
* Project No           : 1103 <br>
* Module Name          : Issure Authoriser<br>
* File Name            : ReplaceLostOrStolenCardsAction.java <br>
* User Use case        : UC0010: createNewBatch<br>
*                        UC0120: selectLostOrStolenCard <br>
*                        UC160: activateCard<br>
*                        UC0070: generatePIN<br>
*                        UC0080: produceCard<br>
*                        UC0090: produceCardDataProductionFile<br>
*                        UC0100: produceCardProductionReport<br>
*                        UC0160: activateCard<br>
* Date created         : 21-06-2002 </h4><hr>
* This action class is used to perform update action .
*
* Date             Author          Reviewer        Description of change
* 21-06-2002       Riaz Mohamed
* 29-Nov-2002      Rajkumar.A.S            For AT-TR 0857
* @author Riaz Mohamed
*
* @version 1.0
*/


public class BREReplaceLostOrStolenCardsAction extends PagingAction
{

    private static final String CLASSNAME="BREReplaceLostOrStolenCardsAction";

    public ActionForward perform(ActionMapping pobjActionMapping, 
                                 ActionForm pobjActionForm,
                                 HttpServletRequest pobjRequest,  
                                 HttpServletResponse pobjResponse)
        throws IOException, ServletException
   {
       setUser((String)pobjRequest.getSession().getAttribute(viewConstant.USERNAME));
        ActionErrors errors = new ActionErrors();
        BREReplaceLostOrStolenCardsForm tobjLostOrStolenCardsForm = new BREReplaceLostOrStolenCardsForm();
        BREReplaceLostOrStolenCardsInfo tobjLostOrStolenCardsInfo = 
			((BREReplaceLostOrStolenCardsForm) pobjActionForm).getBREReplaceLostOrStolenCardsInfo();

        String tsFormAction = pobjRequest.getParameter(viewConstant.PERFORM_FORMACTION);
        String tsResult = viewConstant.RESULT_SUCCESS;
        
        if ((tsFormAction == viewConstant.PERFORM_NULL) || (tsFormAction.length() == 0))
        {
            tobjLostOrStolenCardsInfo = new BREReplaceLostOrStolenCardsInfo();
        }

        else if(tsFormAction.equals(viewConstant.PERFORM_EDIT))
        {
        	BREReplaceLostOrStolenCardsInfo objReplaceLostOrStolenCardsInfo = new BREReplaceLostOrStolenCardsInfo();
            String tsPan = (String)pobjRequest.getParameter(serverConstantBre.GET_REPLACE_PAN);
            String tsSeqno = (String)pobjRequest.getParameter(serverConstantBre.GET_REPLACE_SEQNO);
            String tsStatcode = (String)pobjRequest.getParameter(serverConstantBre.GET_REPLACE_STATECODE);
            String tiBatch = (String)pobjRequest.getParameter(serverConstantBre.GET_REPLACE_BATCH);
            String tsCrdproduct = (String)pobjRequest.getParameter(serverConstantBre.GET_REPLACE_CARDPRODUCT);
            String tsStatCodeDescr = (String)pobjRequest.getParameter(serverConstantBre.GET_REPLACE_STATECODE_DESC);
            
            String panDisplay = (String)pobjRequest.getParameter(serverConstantBre.GET_REPLACE_PAN_DISPLAY);
            String virtualPan = (String)pobjRequest.getParameter(serverConstantBre.GET_REPLACE_VIRTUAL_PAN);
            String customerName = (String)pobjRequest.getParameter(serverConstantBre.GET_REPLACE_CUST_NAME);
            String instcode = (String)pobjRequest.getParameter(serverConstantBre.GET_REPLACE_INST_CODE);
            
            
            objReplaceLostOrStolenCardsInfo.setOldPan(tsPan);
            objReplaceLostOrStolenCardsInfo.setOldSeqno(tsSeqno);
            objReplaceLostOrStolenCardsInfo.setStatCode(tsStatcode);
            objReplaceLostOrStolenCardsInfo.setBatch(tiBatch);
            objReplaceLostOrStolenCardsInfo.setCrdproduct(tsCrdproduct);
            objReplaceLostOrStolenCardsInfo.setStatCodeDescr(tsStatCodeDescr);
            objReplaceLostOrStolenCardsInfo.setPanDisplay(panDisplay);
            objReplaceLostOrStolenCardsInfo.setVirtualPan(virtualPan);
            objReplaceLostOrStolenCardsInfo.setCustName(customerName);
            objReplaceLostOrStolenCardsInfo.setInstcode(instcode);
            tobjLostOrStolenCardsForm.setBREReplaceLostOrStolenCardsInfo(objReplaceLostOrStolenCardsInfo);
            tobjLostOrStolenCardsForm.setResultAction(viewConstant.PERFORM_SUCCESS);
        }

        else if(tsFormAction.equals(viewConstant.PERFORM_UPDATE))
        {
            try
            {
            	tobjLostOrStolenCardsForm.setBREReplaceLostOrStolenCardsInfo(tobjLostOrStolenCardsInfo); 
            	tobjLostOrStolenCardsInfo.setReplacementDone(false);
                CustIdCodeMgrHome mobjCustIdcodeMgrHome =fetchMgrHomeBean(pobjRequest,CustIdCodeMgrHome.class);
                CustIdCodeMgr mobjCustIdcodeMgr = mobjCustIdcodeMgrHome.create();
                mobjCustIdcodeMgr.replaceCard(tobjLostOrStolenCardsInfo);
                tobjLostOrStolenCardsInfo.setReplacementDone(true);
            }
            catch (RemoteException ex)
            {
                logError(CLASSNAME,ex.toString());
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.error.cardreplacement"));
            }
            catch (serverException ex)
            {
                logError(CLASSNAME,ex.toString());
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError(ex.getErrorCode()));
            }
            catch (Exception e)
            {
                logError(CLASSNAME,e.toString());
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.error.cardreplacement"));
            }
        }
        
        if (!errors.empty())
        {
        	tobjLostOrStolenCardsForm.setResultAction(viewConstant.RESULT_ERROR);
            tsResult = viewConstant.RESULT_ERROR;
            saveErrors(pobjRequest, errors);
        }
          

        pobjRequest.setAttribute("BREReplaceLostOrStolenCardsForm",tobjLostOrStolenCardsForm);
        return pobjActionMapping.findForward(tsResult);
    }
}
