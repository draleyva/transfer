package com.cortex.cust.bre.gui.ia.action;

import java.io.IOException;
import java.rmi.RemoteException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cortex.common.exception.serverException;
import com.cortex.common.interfaces.IResultInfo;
import com.cortex.common.lib.debugLib;
import com.cortex.common.valueobj.ResultInfo;
import com.cortex.cust.bre.common.entityejb.CustIdCodeInfo;
import com.cortex.cust.bre.gui.ia.formbean.CustIdCodeDetailForm;
import com.cortex.cust.bre.gui.ia.sessionejb.CustIdCodeMgr;
import com.cortex.cust.bre.gui.ia.sessionejb.CustIdCodeMgrHome;
import com.cortex.cust.bre.gui.ia.valueobj.CustIdCodePKInfo;
import com.cortex.gui.common.action.SessionDataAction;
import com.cortex.gui.common.constant.viewConstant;
import com.cortex.cust.bre.common.constant.serverConstantBre;

/**
 * <hr><h3>
 * Copyright &copy Nomad Software Ltd.</h3><h4>
 * Project No           : 1103  <br>
 * Module Name          : Aa<br>
 * Global Use Case      : N/A<br>
 * Business Use case    : N/A<br>
 * Maintenance Use case : N/A<br>
 * @author                j2eegen
 *
 * This is the Action class of the detail screen for cust_idcode table
 *
 * Date   Author     Reviewer    Description of change<br>
 *
 * @version 1.0
 */

public class CustIdCodeDetailAction extends SessionDataAction
{
    private static final String CLASSNAME="CustIdCodeDetailAction";

    /**
     * This method is called when a new action is initiated from the form (i.e. user
     * presses a button).  This action will be decoded and processed.
     * When appropriate, a successfull processing will displayed a success message in
     * the screen.  Similarly, an error message will be displayed when processing fails.
     *
     * Below the actions supported by this perform method:
     * <UL>
     * <LI>
     * <default>:   This action happens when the user request adding a new record.
     *              An empty form will be displayed.
     * </LI>
     * <LI>
     * ADD:         This action happens when the user fills in all the required fields
     *              from the add/creation form and presses the ADD button.
     *              The info object containing the entered information is read and
     *              the system attempts to create a new record in the database.
     * </LI>
     * <LI>
     * EDIT:        This action happens when the user requests editing a record.
     *              This option will retrieve the record information from the database
     *              and populate the appropriate fields from the form.
     * </LI>
     * <LI>
     * UPDATE:      This action happens when the user presses the UPDATE button from
     *              the edit screen.  The details of the record are updated in the
     *              database.
     * </LI>
     * <LI>
     * DELETE:      This action happens when the user presses the DELETE button from
     *              the edit screen.  The record is removed from the database.
     * </LI>
     * </UL>
     *
     * @param pobjActionMapping The ActionMapping used to select this instance
     * @param pobjActionForm The optional ActionForm bean for this request (if any)
     * @param pobjRequest The HTTP request we are processing
     * @param pobjResponse The HTTP response we are creating
     *
     * @return ActionForward The ActionForward used to forward the request.
     *
     * @throws IOException thrown if an input/output error occurs
     * @throws ServletException thron if a servlet exception occurs
     */
    public ActionForward perform(ActionMapping pobjActionMapping, ActionForm pobjActionForm,
                        HttpServletRequest pobjRequest, HttpServletResponse pobjResponse)
         throws IOException, ServletException
    {
        /*
         *  Set up variables
         */
        // Get user name for auditing purposes
        String tsUser = (String)pobjRequest.getSession().getAttribute(viewConstant.USERNAME);         
         
        // Store the ActionForm and info object in local variables for simplicity of the code
        CustIdCodeDetailForm mobjCust_idcodeDetailForm = (CustIdCodeDetailForm)pobjActionForm;
        CustIdCodeInfo mobjCust_idcodeInfo = ((CustIdCodeDetailForm) pobjActionForm).getCustIdCodeInfo();

        // Create ActionErrors variable used to store errors to be reported back to the client
        ActionErrors errors = mobjCust_idcodeDetailForm.getActionErrors();

        // This variable contains the forwarding name that will be used to display
        // the next screen.
        String tsResult=viewConstant.RESULT_SUCCESS;

        // This variable contains the action to carry out (ie Add, Edit, Update or Delete)
        String tsFormAction = pobjRequest.getParameter(viewConstant.PARAMETER_FORMACTION);

        // Get the Http Session from the request
        HttpSession tobjHttpSession = pobjRequest.getSession(true);
    

        /*
         *  Display empty create screen - prepare create/add screen
         */
        if (!errors.empty())
        {
            // Errors found during form validation
            // No further processing should be carried out
        }
        /*
         *  Display empty create screen - prepare create/add screen
         */
        else if ((tsFormAction == null) || (tsFormAction.length() == 0))
        {
            mobjCust_idcodeInfo = new CustIdCodeInfo();
            mobjCust_idcodeDetailForm.getCustIdCodeInfo().setCustCode(pobjRequest.getParameter(serverConstantBre.GET_CUSTOMER_CUST_CODE));
            mobjCust_idcodeDetailForm.getCustIdCodeInfo().setCustName(pobjRequest.getParameter(serverConstantBre.GET_CUSTOMER_NAME));
            mobjCust_idcodeDetailForm.getCustIdCodeInfo().setInstCode(pobjRequest.getParameter(serverConstantBre.GET_CUSTOMER_INST_CODE));
            tobjHttpSession.setAttribute(viewConstant.VIEW_MODE,viewConstant.CREATE_VIEW_MODE);
        }

        /*
         *  Add new cust_idcode record (Add button of create screen pressed)
         */
        else if(tsFormAction.equals(viewConstant.BUTTON_ADD))
        {
            try
            {
                tobjHttpSession.setAttribute(viewConstant.VIEW_MODE,viewConstant.CREATE_VIEW_MODE);

                // Perform any extra form validation 
                errors = mobjCust_idcodeDetailForm.validateForm(errors);
            

                CustIdCodeMgrHome mobjCust_idcodeMgrHome = fetchMgrHomeBean(pobjRequest,CustIdCodeMgrHome.class);
                CustIdCodeMgr mobjCust_idcodeMgr = mobjCust_idcodeMgrHome.create();

                // Add new cust_idcode record to database
                mobjCust_idcodeMgr.addCustIdCode(mobjCust_idcodeInfo);

                 // Operation Successful - set up success flags
                pobjRequest.setAttribute(viewConstant.ACTION_SUCCESS_FLAG, "ia.msg.cust_idcode.success.add");
                tsResult=viewConstant.RESULT_SUCCESS;
            }
            catch (RemoteException ex)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.unknownerror"));
            }
            catch (serverException ex)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError(ex.getErrorCode()));
            }
            catch(Exception ex)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.unknownerror"));
                debugLib.logError (CLASSNAME,ex,tsUser);
            }
        }

        /*
         *  Display details screen and populate the fields with the required record details
         */
        else if(tsFormAction.equals(viewConstant.BUTTON_EDIT))
        {

            try
            {
                tobjHttpSession.setAttribute(viewConstant.VIEW_MODE, viewConstant.EDIT_VIEW_MODE);

                // Obtain Session Bean reference
                CustIdCodeMgrHome mobjCust_idcodeMgrHome =fetchMgrHomeBean(pobjRequest,CustIdCodeMgrHome.class);
                CustIdCodeMgr mobjCust_idcodeMgr = mobjCust_idcodeMgrHome.create();

                // Get cust_idcode details from Session Bean
                CustIdCodePKInfo tobjCust_idcodePKInfo = new CustIdCodePKInfo();
                tobjCust_idcodePKInfo.setId (Long.parseLong(pobjRequest.getParameter(viewConstant.PARAMETER_KEY_1)));
                
                mobjCust_idcodeDetailForm.setCustIdCodeInfo(mobjCust_idcodeMgr.getCustIdCode(tobjCust_idcodePKInfo));
                mobjCust_idcodeDetailForm.getCustIdCodeInfo().setCustCode(pobjRequest.getParameter(viewConstant.PARAMETER_KEY_2));
                mobjCust_idcodeDetailForm.getCustIdCodeInfo().setCustName(pobjRequest.getParameter(viewConstant.PARAMETER_KEY_3));
                mobjCust_idcodeDetailForm.getCustIdCodeInfo().setInstCode(pobjRequest.getParameter(viewConstant.PARAMETER_KEY_4));
                
                tsResult=viewConstant.RESULT_SUCCESS;
            }
            catch (RemoteException ex)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.unknownerror"));
            }
            catch (serverException ex)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError(ex.getErrorCode()));
            }
            catch (Exception ex)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.unknownerror"));
                debugLib.logError (CLASSNAME,ex,tsUser);
            }

        }

        /*
         *  Update cust_idcode record of the detail screen  (Update button of details screen pressed)
         */
        else if(tsFormAction.equals(viewConstant.BUTTON_UPDATE))
        {
            try
            {
                tobjHttpSession.setAttribute(viewConstant.VIEW_MODE,viewConstant.EDIT_VIEW_MODE);

                // Perform any extra form validation 
                errors = mobjCust_idcodeDetailForm.validateForm(errors);

                // Obtain Session Bean reference
                CustIdCodeMgrHome mobjCust_idcodeMgrHome =fetchMgrHomeBean(pobjRequest,CustIdCodeMgrHome.class);
                CustIdCodeMgr mobjCust_idcodeMgr = mobjCust_idcodeMgrHome.create();

                // Update cust_idcode record in database
                IResultInfo tobjResultInfo = mobjCust_idcodeMgr.updateCustIdCode (mobjCust_idcodeInfo);
                ResultInfo.copyTo (tobjResultInfo, mobjCust_idcodeInfo);

                // Operation Successful - set up success flags
                pobjRequest.setAttribute(viewConstant.ACTION_SUCCESS_FLAG, "ia.msg.cust_idcode.success.update");
                tsResult=viewConstant.RESULT_UPDATE_SUCCESS;
            }
            catch (RemoteException ex)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.unknownerror"));
            }
            catch (serverException ex)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError(ex.getErrorCode()));
            }
            catch (Exception ex)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.unknownerror"));
                debugLib.logError (CLASSNAME,ex,tsUser);
            }
        }

        /*
         *  Delete cust_idcode record of the detail screen  (Delete button of details screen pressed)
         */
        else if(tsFormAction.equals(viewConstant.BUTTON_DELETE))
        {
            try
            {
                tobjHttpSession.setAttribute(viewConstant.VIEW_MODE,viewConstant.EDIT_VIEW_MODE);

                // Obtain Session Bean reference
                CustIdCodeMgrHome mobjCust_idcodeMgrHome =fetchMgrHomeBean(pobjRequest,CustIdCodeMgrHome.class);
                CustIdCodeMgr mobjCust_idcodeMgr = mobjCust_idcodeMgrHome.create();

                // Delete cust_idcode record from database
                CustIdCodePKInfo tobjCust_idcodePKInfo = new CustIdCodePKInfo();
                tobjCust_idcodePKInfo.setId (mobjCust_idcodeInfo.getId());
                mobjCust_idcodeMgr.deleteCustIdCode(tobjCust_idcodePKInfo);

                // Set up Action Success Flag
                pobjRequest.setAttribute(viewConstant.ACTION_SUCCESS_FLAG,"ia.msg.cust_idcode.success.delete");
                mobjCust_idcodeDetailForm.setCustIdCodeInfo(new CustIdCodeInfo());
                tsResult=viewConstant.RESULT_DELETE_SUCCESS;
            }
            catch (RemoteException ex)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.unknownerror"));
            }
            catch (serverException ex)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError(ex.getErrorCode()));
            }
            catch(Exception ex)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.unknownerror"));
                debugLib.logError (CLASSNAME,ex,tsUser);
            }
        }
        
        /*
         *  Display details screen and populate the fields with the required record details
         */
        else if(tsFormAction.equals(viewConstant.BUTTON_REFRESH))
        {

            try
            {
                tobjHttpSession.setAttribute(viewConstant.VIEW_MODE, viewConstant.EDIT_VIEW_MODE);

                // Obtain Session Bean reference
                CustIdCodeMgrHome mobjCust_idcodeMgrHome =fetchMgrHomeBean(pobjRequest,CustIdCodeMgrHome.class);
                CustIdCodeMgr mobjCust_idcodeMgr = mobjCust_idcodeMgrHome.create();

                // Get cust_idcode details from Session Bean
                CustIdCodePKInfo tobjCust_idcodePKInfo = new CustIdCodePKInfo();
                tobjCust_idcodePKInfo.setId (mobjCust_idcodeInfo.getId());
                mobjCust_idcodeDetailForm.setCustIdCodeInfo(mobjCust_idcodeMgr.getCustIdCode(tobjCust_idcodePKInfo));
                mobjCust_idcodeDetailForm.setInstCode(mobjCust_idcodeInfo.getInstCode());
                mobjCust_idcodeDetailForm.setCustCode(mobjCust_idcodeInfo.getCustCode());
                mobjCust_idcodeDetailForm.setCustName(mobjCust_idcodeInfo.getCustName());

                // Operation Successful - set up success flags
                pobjRequest.setAttribute(viewConstant.ACTION_SUCCESS_FLAG, "ia.msg.cust_idcode.success.refresh");
                tsResult=viewConstant.RESULT_SUCCESS;
            }
            catch (RemoteException ex)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.unknownerror"));
            }
            catch (serverException ex)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError(ex.getErrorCode()));
            }
            catch (Exception ex)
            {
                errors.add(ActionErrors.GLOBAL_ERROR,new ActionError("error.unknownerror"));
                debugLib.logError (CLASSNAME,ex,tsUser);
            }
        }
        /*
         *  Reset all the fields of the detail screen  (Reset button pressed)
         */
        else if(tsFormAction.equals(viewConstant.BUTTON_RESET))
        {
            // No code in here yet
        }


        // Check for errors
        if (!errors.empty())
        {
            tsResult=viewConstant.RESULT_ERROR;
            saveErrors(pobjRequest, errors);
        }


        // Attach new form to request and forward result
        pobjRequest.setAttribute("Cust_idcodeDetailForm",mobjCust_idcodeDetailForm);
        return pobjActionMapping.findForward(tsResult);
    }
}
