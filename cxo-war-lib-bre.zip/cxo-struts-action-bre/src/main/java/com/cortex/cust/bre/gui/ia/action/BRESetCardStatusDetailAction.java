package com.cortex.cust.bre.gui.ia.action;

import static com.cortex.common.constant.globalConstant.DENY_UNDEF_STATUS_CHANGE;
import static com.cortex.common.constant.globalConstant.MAKER_CHECKER_CONSTANT_PENDING_REQUEST;
import static com.cortex.common.constant.globalConstant.MAKER_CHECKER_CONSTANT_SUCCESS;
import static com.cortex.common.constant.globalConstant.NEVER_DATE;
import static com.cortex.common.hook.HookFactory.getPlugin;
import static com.cortex.common.hook.HookParam.PARAM1;
import static com.cortex.gui.common.constant.viewConstant.ACTION_SUCCESS;
import static com.cortex.gui.common.constant.viewConstant.ACTION_SUCCESS_FLAG;
import static com.cortex.gui.common.constant.viewConstant.CHAR_YES;
import static com.cortex.gui.common.constant.viewConstant.ERROR_CREATE_JOBAUTH_REQUEST;
import static com.cortex.gui.common.constant.viewConstant.ERROR_KEY_USER_DEFINED;
import static com.cortex.gui.common.constant.viewConstant.FORMACSITEM;
import static com.cortex.gui.common.constant.viewConstant.FROMWHERE;
import static com.cortex.gui.common.constant.viewConstant.KEY1;
import static com.cortex.gui.common.constant.viewConstant.KEY2;
import static com.cortex.gui.common.constant.viewConstant.KEY3;
import static com.cortex.gui.common.constant.viewConstant.NO_USER_INST;
import static com.cortex.gui.common.constant.viewConstant.PERFORM_ADD;
import static com.cortex.gui.common.constant.viewConstant.PERFORM_EDIT;
import static com.cortex.gui.common.constant.viewConstant.PERFORM_ERROR;
import static com.cortex.gui.common.constant.viewConstant.PERFORM_FORMACTION;
import static com.cortex.gui.common.constant.viewConstant.PERFORM_REFRESH;
import static com.cortex.gui.common.constant.viewConstant.PERFORM_SUCCESS;
import static com.cortex.gui.common.constant.viewConstant.PREPARE_MKC_DATA_START;
import static com.cortex.gui.common.constant.viewConstant.RESULT_MKC_JOB_CREATED_SUCCESS;
import static com.cortex.gui.common.constant.viewConstant.RESULT_MKC_JOB_CREATION_SUCCESS;
import static com.cortex.gui.common.constant.viewConstant.USERNAME;
import static com.cortex.gui.common.constant.viewConstant.VISA;
import static com.cortex.gui.common.lib.CommonGlobalFunctions.getUserInst;
import static com.cortex.gui.common.security.obfuscation.SessionAccess.getRemoteIp;
import static com.cortex.gui.ia.valueobj.OperatorActionInfo.ACTIVATE_CARD;
import static com.fis.mkc.domain.model.ServiceType.BEAN_NAME;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNoneBlank;
import static org.apache.struts.action.ActionErrors.GLOBAL_ERROR;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cortex.gui.ia.action.SetCardStatusDetailAction;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cortex.common.constant.SQLConstants;
import com.cortex.common.constant.globalConstant;
import com.cortex.common.exception.serverException;
import com.cortex.common.hook.HookParam;
import com.cortex.common.lib.dateTimeLib;
import com.cortex.common.lib.dbLib;
import com.cortex.common.lib.debugLib;
import com.cortex.common.startup.StartupXmlConfigData;
import com.cortex.cxo.controllers.common.IntegratedEntity;
import com.cortex.cxo.controllers.ejb.common.globalfunctions.CommonGlobalFunctionsMgr;
import com.cortex.cxo.controllers.ejb.issuer.cardmaintenance.CardMaintenanceMgr;
import com.cortex.cxo.controllers.ejb.issuer.cardstatus.CardStatusMgr;
import com.cortex.cxo.controllers.ejb.issuer.crdstatus.CrdstatusMgr;
import com.cortex.gui.common.action.SessionDataAction;
import com.cortex.gui.common.action.mkc.EntityType;
import com.cortex.gui.common.action.mkc.MkcConstants;
import com.cortex.gui.common.action.mkc.Util;
import com.cortex.gui.common.constant.viewConstant;
import com.cortex.gui.common.lib.AccessPermissions;
import com.cortex.gui.ia.formbean.SetCardStatusDetailForm;
import com.cortex.gui.ia.valueobj.CrddetPKInfo;
import com.cortex.gui.ia.valueobj.CrdstatusPKInfo;
import com.cortex.gui.ia.valueobj.OperatorActionInfo;
import com.cortex.gui.ia.valueobj.ParentCardDetailsInfo;
import com.cortex.gui.ia.valueobj.SetCardStatusDetailInfo;
import com.fis.mkc.domain.model.JobType;
import com.fis.mkc.domain.shared.JobAuthCallCollator;

//ToDo: Figure out what was customized in this class

public class BRESetCardStatusDetailAction extends SessionDataAction {
    private static final String CLASSNAME = SetCardStatusDetailAction.class.getSimpleName();
    private static final String FORM_PARAM = "SetCardStatusDetailForm";
    private static final String CLASS_NUMBER = "classNumber";
    private static final String[] TRANSFERABLE_REQUEST_PARAMS = withMandatoryRedirectionParams(ERROR_KEY, FORM_PARAM,
            ACTION_SUCCESS_FLAG, ERROR_KEY_USER_DEFINED, CLASS_NUMBER);

    private static final String CO_ERROR_UNKNOWNERROR = "co.error.unknownerror";
    private static final String ERROR_UNKNOWNERROR = "error.unknownerror";
    private static final String SUCCCESS_FLAG_1 = "ia.msg.cardstatus.successflag1";
    private static final String SUCCCESS_FLAG_2 = "ia.msg.cardstatus.successflag2";
    private static final String VISA_EXCEPTION_FILE_PLUG_IN = "com.cortex.gui.ia.plugins.VisaExceptionFilePromptPlugin";
    private static final String ERROR_FLAG1 = "ia.msg.cardstatus.errorflag1";
    private static final String ERROR_FLAG_PENDING_REQUEST = "ia.msg.jobauth.errorflagPendingRequest";

    private static final String FORCE_VALUE = "force";
    private static final String FALSE = "false";
    private static final String TRUE = "true";
    private static final String ADD_CARD_STATUS = "addCardStatus";

    private static final String OPERATOR_ACTION_INFO = "OperatorActionInfo";
    private static final String PARENT_CARD_DETAILS_INFO = "ParentCardDetailsInfo";
    private static final String NUMBER_ZERO = "0";
    private static final String NUMBER_ZERO_ZERO = "00";
    private static final String NUMBER_ZERO_THREE = "03";
    private static final String NUMBER_ZERO_FOUR = "04";
    private static final String NUMBER_ONE = "1";
    private static final String NUMBER_TWO = "2";
    private static final String NUMBER_THREE = "3";
    private static final String PAN = "Pan:";
    private static final String SEGMA = ",";
    private static final String EMPTY = "";
    private static final String SEQUENCE_NUMBER = "Seq no:";

    /**
     * {@inheritDoc}
     */
    @Override
    public ActionForward perform(ActionMapping actionMapping, ActionForm actionForm, HttpServletRequest request,
                                 HttpServletResponse response) throws IOException, ServletException {
        appendMandatoryRedirectionParams(request);

        HttpSession httpSession = request.getSession(false);
        String userName = (String) httpSession.getAttribute(USERNAME);

        SetCardStatusDetailForm setCardStatusDetailForm = (SetCardStatusDetailForm) actionForm;
        SetCardStatusDetailInfo setCardStatusDetailInfo = setCardStatusDetailForm.getSetCardStatusDetailInfo();
        setCardStatusDetailInfo.setWhoIp(getRemoteIp());

        ActionErrors errors = new ActionErrors();

        String result = PERFORM_SUCCESS;

        String formAction = request.getParameter(PERFORM_FORMACTION);
        String fromWhere = request.getParameter(FROMWHERE);
        int updateResult = 0;

        request.removeAttribute(ERROR_KEY_USER_DEFINED);

        String disablePrompt = FALSE;
        HookParam hookParam = new HookParam();
        hookParam.put(PARAM1, disablePrompt);
        try {
            hookParam = getPlugin(VISA_EXCEPTION_FILE_PLUG_IN).process(hookParam);
            disablePrompt = (String) hookParam.get(PARAM1);
        } catch (Exception e) {
            logInfo(e.toString());
        }

        try {
            if (isEmpty(formAction)) {
                if (fromWhere == null) {
                    fromWhere = setCardStatusDetailForm.getFromwhere();
                }
                setCardStatusDetailForm.setFromwhere(fromWhere);
                setCardStatusDetailForm.setPrompt(FALSE);
                setCardStatusDetailInfo.setDateset(dateTimeLib.getCurrentDate());
                setCardStatusDetailInfo.setTime_set(dateTimeLib.getCurrentTime());
                setCardStatusDetailInfo
                        .setStrTime_set(dateTimeLib.convertLongToStringTime(setCardStatusDetailInfo.getTime_set()));
                setCardStatusDetailForm.setWhoset(userName);

                if (!getUserInst(httpSession).getInstcode().equals(NO_USER_INST)) {
                    setCardStatusDetailForm.setInstcode(getUserInst(httpSession).getInstcode());
                }
            } else if (formAction.equals(PERFORM_REFRESH)) {
                performRefresh(setCardStatusDetailForm, setCardStatusDetailInfo, request);
            } else if (formAction.equals(PERFORM_ADD)) {
                setCardStatusDetailInfo.setWho_set(userName);
                final Object[] tenantDateAndTime = commonGlobalFunctions(request)
                        .provideTenantDateAndTimeByInstCode(setCardStatusDetailInfo.getInstcode());
                setCardStatusDetailInfo.setDateset((Date) tenantDateAndTime[0]);
                setCardStatusDetailInfo.setTime_set(((Long) tenantDateAndTime[1]).longValue());
                setCardStatusDetailInfo.setStrTime_set(dateTimeLib.convertLongToStringTime(setCardStatusDetailInfo.getTime_set()));
                if (allowStatusChange(setCardStatusDetailInfo, request, httpSession)) {
                    updateResult = performAdd(setCardStatusDetailForm, setCardStatusDetailInfo, disablePrompt,
                            (String) httpSession.getAttribute(USERNAME), request.getParameter(FORMACSITEM),
                            FORCE_VALUE.equals(actionMapping.getParameter()), request);
                } else {
                    errors.add(GLOBAL_ERROR, new ActionError(ERROR_FLAG1));
                }

                if (updateResult == MAKER_CHECKER_CONSTANT_PENDING_REQUEST) {
                    errors.add(GLOBAL_ERROR, new ActionError(ERROR_FLAG_PENDING_REQUEST));
                    request.setAttribute(ERROR_KEY_USER_DEFINED, ERROR_CREATE_JOBAUTH_REQUEST);
                }

            } else if (formAction.equals(PERFORM_EDIT)) {
                if (fromWhere.equals(NUMBER_TWO)) {
                    OperatorActionInfo operatorActionInfo = (OperatorActionInfo) httpSession
                            .getAttribute(OPERATOR_ACTION_INFO);
                    if (operatorActionInfo != null) {
                        httpSession.removeAttribute(OPERATOR_ACTION_INFO);
                        if (operatorActionInfo.getAction() == ACTIVATE_CARD) {
                            setCardStatusDetailForm.setStatcode(NUMBER_ZERO_ZERO);
                        } else {
                            setCardStatusDetailForm.setStatcode(NUMBER_ZERO_FOUR);
                        }
                    }
                }
                if (!fromWhere.equals(NUMBER_ZERO)) {
                    setCardStatusDetailForm.setFromwhere(fromWhere);
                    final Object[] tenantDateAndTime = commonGlobalFunctions(request)
                            .provideTenantDateAndTimeByInstCode(setCardStatusDetailInfo.getInstcode());
                    setCardStatusDetailInfo.setDateset((Date) tenantDateAndTime[0]);
                    setCardStatusDetailInfo.setTime_set(((Long) tenantDateAndTime[1]).longValue());
                    setCardStatusDetailInfo
                            .setStrTime_set(dateTimeLib.convertLongToStringTime(setCardStatusDetailInfo.getTime_set()));
                    setCardStatusDetailForm.setWhoset(userName);

                    if (fromWhere.equals(NUMBER_THREE)) {
                        setCardStatusDetailInfo.setPan(request.getParameter(KEY1));
                        setCardStatusDetailInfo.setSeqno(Integer.parseInt(request.getParameter(KEY2)));
                        setCardStatusDetailInfo.setInstcode(request.getParameter(KEY3));
                    } else {
                        ParentCardDetailsInfo parentCardDetailsInfo = new ParentCardDetailsInfo();
                        parentCardDetailsInfo = (ParentCardDetailsInfo) httpSession
                                .getAttribute(PARENT_CARD_DETAILS_INFO);
                        setCardStatusDetailInfo.setInstcode(parentCardDetailsInfo.getInstcode());
                        setCardStatusDetailInfo.setPan(parentCardDetailsInfo.getPan());
                        setCardStatusDetailInfo.setSeqno(parentCardDetailsInfo.getSeqno());
                    }
                }

                performEdit(setCardStatusDetailForm, setCardStatusDetailInfo, request);

                if (fromWhere.equals(NUMBER_THREE)) {
                    String statusCode = fetchSingleBean(request, CardStatusMgr.class).getConfiguredStatusCode();
                    setCardStatusDetailForm.setStatcode(statusCode != null ? statusCode : NUMBER_ZERO_ZERO);
                }
            }
        } catch (serverException se) {
            logError(se, userName);
            if (isNoneBlank(se.getValue0(), se.getValue1())) {
                errors.add(GLOBAL_ERROR, new ActionError(se.getErrorCode(), se.getValue0(), se.getValue1()));
            } else {
                errors.add(GLOBAL_ERROR, new ActionError(se.getErrorCode()));
            }
        } catch (Exception e) {
            logError(e, userName);
            errors.add(GLOBAL_ERROR, new ActionError(ERROR_UNKNOWNERROR));
        } finally {
            if (errors.empty()) {
                if (formAction != null && !formAction.equals(PERFORM_EDIT) && !formAction.equals(PERFORM_REFRESH)) {
                    try {
                        if (!setCardStatusDetailForm.getPrompt().equals(TRUE)) {
                            SetCardStatusDetailInfo setCardStatusDetailInfo2 = new SetCardStatusDetailInfo();
                            setCardStatusDetailInfo2.setDateset(dateTimeLib.getCurrentDate());
                            setCardStatusDetailInfo2.setTime_set(dateTimeLib.getCurrentTime());
                            setCardStatusDetailInfo
                                    .setStrTime_set(dateTimeLib.convertLongToStringTime(setCardStatusDetailInfo.getTime_set()));
                            setCardStatusDetailForm = new SetCardStatusDetailForm(setCardStatusDetailInfo2, request);
                            if (fromWhere == null) {
                                fromWhere = setCardStatusDetailForm.getFromwhere();
                            }
                            setCardStatusDetailForm.setFromwhere(fromWhere);
                            String instCode = getUserInst(httpSession).getInstcode();
                            setCardStatusDetailForm.setWhoset(userName);
                            if (instCode != null && !instCode.equals(NO_USER_INST)) {
                                setCardStatusDetailForm.setInstcode(instCode);
                            }
                        }
                    } catch (Exception e) {
                        logError(e);
                        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWNERROR));
                    }
                    if (updateResult == 0) {
                        request.setAttribute(ACTION_SUCCESS_FLAG, ACTION_SUCCESS);
                    } else if (updateResult == 1) {
                        request.setAttribute(ACTION_SUCCESS_FLAG, SUCCCESS_FLAG_1);
                    } else if (updateResult == 2) {
                        request.setAttribute(ACTION_SUCCESS_FLAG, SUCCCESS_FLAG_2);
                    } else if (updateResult == MAKER_CHECKER_CONSTANT_SUCCESS) {
                        request.setAttribute(ACTION_SUCCESS_FLAG, RESULT_MKC_JOB_CREATION_SUCCESS);
                        if (fromWhere != null && fromWhere.equals(NUMBER_ONE)) {
                            httpSession.setAttribute(RESULT_MKC_JOB_CREATED_SUCCESS, CHAR_YES);
                        }
                    }

                    setCardStatusDetailForm.setResultAction(result);
                }
            } else {
                saveErrors(request, errors);
                setCardStatusDetailForm.setResultAction(PERFORM_ERROR);
            }
        }
        setCardStatusDetailForm.setWhoset(userName);
        request.setAttribute(FORM_PARAM, setCardStatusDetailForm);
        return cxoRedirect(actionMapping, result, TRANSFERABLE_REQUEST_PARAMS);
    }

    private int performAdd(SetCardStatusDetailForm setCardStatusDetailForm,
                           SetCardStatusDetailInfo setCardStatusDetailInfo, String disablePrompt, String userName, String acsitem,
                           boolean forceChange, HttpServletRequest request) throws serverException, Exception {
        int updateRes = 0;

        SetCardStatusDetailInfo tempSetCardStatusDetailInfo = null;

        StringBuilder recIdBuilder = new StringBuilder();
        recIdBuilder.append(PAN).append(setCardStatusDetailInfo.getPan());
        recIdBuilder.append(SEGMA);
        recIdBuilder.append(SEQUENCE_NUMBER).append(setCardStatusDetailInfo.getSeqno());

        try {
            if (isPreviousRequestPending(request, createMkcRecId(setCardStatusDetailInfo), CLASSNAME)) {
                return MAKER_CHECKER_CONSTANT_PENDING_REQUEST;
            }
            setCardStatusDetailInfo = fetchSingleBean(request, CardStatusMgr.class)
                    .getExpiryDate(setCardStatusDetailInfo);
            tempSetCardStatusDetailInfo = copyCardStatusDetail(
                    fetchSingleBean(request, CardStatusMgr.class).editSetCardStatus(setCardStatusDetailInfo));

            if (!forceChange) {
                fetchSingleBean(request, CardStatusMgr.class).isTransitionAllowed(
                        setCardStatusDetailInfo.getCrdproduct(), setCardStatusDetailInfo.getStatcode(),
                        setCardStatusDetailInfo.getOldcardstat(), setCardStatusDetailInfo.getOldstat(),
                        setCardStatusDetailInfo.getUpdateoldcardstat(), setCardStatusDetailInfo.getHasOldCard());
            }

            if (setCardStatusDetailInfo.getHasOldCard()) {
                if (NUMBER_ZERO.equals(setCardStatusDetailInfo.getUpdateoldcardstat())) {
                    setCardStatusDetailInfo = fetchSingleBean(request, CardStatusMgr.class)
                            .editSetCardStatus(setCardStatusDetailInfo);
                    if (NUMBER_ZERO_THREE.equals(setCardStatusDetailInfo.getStatcode())) {
                        setCardStatusDetailInfo.setOldcardstat(setCardStatusDetailInfo.getStatcode());
                        setCardStatusDetailInfo.setDateExpdate(setCardStatusDetailInfo.getOldcardexpdate());
                        updateRes = 1;
                    } else if (setCardStatusDetailInfo.getOldcardexpdate() != null
                            && !setCardStatusDetailInfo.getOldcardexpdate().equals(NEVER_DATE)) {
                        if (commonGlobalFunctions(request)
                                .provideTenantDateByInstCode(setCardStatusDetailInfo.getInstcode())
                                .compareTo(setCardStatusDetailInfo.getOldcardexpdate()) <= 0) {
                            setCardStatusDetailInfo.setOldcardstat(setCardStatusDetailInfo.getStatcode());
                            setCardStatusDetailInfo.setDateExpdate(setCardStatusDetailInfo.getOldcardexpdate());
                            updateRes = 1;
                        } else {
                            updateRes = 2;
                        }
                    }
                } else if (NUMBER_TWO.equals(setCardStatusDetailInfo.getUpdateoldcardstat())) {
                    setCardStatusDetailInfo.setOldcardstat(setCardStatusDetailInfo.getStatcode());
                    setCardStatusDetailInfo.setStatcode(setCardStatusDetailInfo.getOldstat());
                    setCardStatusDetailInfo.setDateExpdate(setCardStatusDetailInfo.getOldcardexpdate());
                }
            }

            logInfo(PREPARE_MKC_DATA_START);

            CrdstatusPKInfo cardstatusPKInfo = new CrdstatusPKInfo();
            cardstatusPKInfo.setStatcode(setCardStatusDetailInfo.getStatcode());
            setCardStatusDetailInfo.setStatcodedescr(
                    fetchSingleBean(request, CrdstatusMgr.class).getCrdstatus(cardstatusPKInfo).getDescr());

            tempSetCardStatusDetailInfo.setStatcodedescr(setCardStatusDetailInfo.getOldstatdescr());
            fetchSingleBean(request, CardStatusMgr.class);

            IntegratedEntity<SetCardStatusDetailInfo> integratedEntityCrdstatus = new IntegratedEntity<>(tempSetCardStatusDetailInfo, setCardStatusDetailInfo);

            CrddetPKInfo crddetPKInfo = new CrddetPKInfo();
            crddetPKInfo.setPan(setCardStatusDetailInfo.getPan());
            crddetPKInfo.setSeqno(setCardStatusDetailInfo.getSeqno());

            if (!createMkcAuthJob(request, integratedEntityCrdstatus, acsitem,
                    fetchSingleBean(request, CardMaintenanceMgr.class).getCrddet(crddetPKInfo).getBrncode(),
                    JobType.OLD_NEW_DIFF, ADD_CARD_STATUS)) {
                SetCardStatusDetailInfo addedSetCardStatusDetailInfo = fetchSingleBean(request, CardStatusMgr.class)
                        .addCardStatus(integratedEntityCrdstatus, acsitem);
                if (!addedSetCardStatusDetailInfo.getStatcode().equals(NUMBER_ZERO_ZERO)
                        && addedSetCardStatusDetailInfo.getScheme() != null
                        && addedSetCardStatusDetailInfo.getScheme().equals(VISA) && disablePrompt.equals(FALSE)) {
                    setCardStatusDetailForm.setPrompt(TRUE);
                }
                return updateRes;
            } else {
                return MAKER_CHECKER_CONSTANT_SUCCESS;
            }
        } catch (Exception e) {
            logError(e, userName);
            throw new serverException(CO_ERROR_UNKNOWNERROR);
        }
    }

    private void performEdit(SetCardStatusDetailForm setCardStatusDetailForm,
                             SetCardStatusDetailInfo setCardStatusDetailInfo, HttpServletRequest request)
            throws serverException, Exception {
        try {
            if (setCardStatusDetailInfo.getHasOldCard()
                    && NUMBER_ZERO.equals(setCardStatusDetailInfo.getUpdateoldcardstat())) {
                setCardStatusDetailForm.setSetCardStatusDetailInfo(
                        fetchSingleBean(request, CardStatusMgr.class).editSetCardStatus(setCardStatusDetailInfo));
            } else {
                setCardStatusDetailForm.setSetCardStatusDetailInfo(fetchSingleBean(request, CardStatusMgr.class)
                        .getCrdCustInfo(setCardStatusDetailInfo.getPan(), setCardStatusDetailInfo.getSeqno()));
            }
        } catch (serverException se) {
            logError(se, user(request));
            throw se;
        } catch (Exception e) {
            logError(e, user(request));
            throw new serverException(CO_ERROR_UNKNOWNERROR);
        }
    }

    private void performRefresh(SetCardStatusDetailForm setCardStatusDetailForm,
                                SetCardStatusDetailInfo setCardStatusDetailInfo, HttpServletRequest request)
            throws serverException, Exception {
        try {
            setCardStatusDetailInfo = fetchSingleBean(request, CardStatusMgr.class)
                    .getCrdCustInfo(setCardStatusDetailInfo.getPan(), setCardStatusDetailInfo.getSeqno());
            setCardStatusDetailInfo.setDateset(setCardStatusDetailInfo.getDateset());
            setCardStatusDetailInfo.setTime_set(setCardStatusDetailInfo.getTime_set());
            setCardStatusDetailInfo.setStrTime_set(dateTimeLib.convertLongToStringTime(setCardStatusDetailInfo.getTime_set()));
            setCardStatusDetailInfo.setPanDisplay(setCardStatusDetailInfo.getPanDisplay());
            setCardStatusDetailForm.setSetCardStatusDetailInfo(setCardStatusDetailInfo);
        } catch (Exception e) {
            logError(e, user(request));
            throw new serverException(CO_ERROR_UNKNOWNERROR);
        }
    }

    private boolean allowStatusChange(SetCardStatusDetailInfo setCardStatusDetailInfo, HttpServletRequest request,
                                      HttpSession httpSession) throws serverException, Exception {
        boolean changeStatusAllowed = false;
        Boolean allowUndefStatusChange = false;
        try {
            allowUndefStatusChange = !new Boolean(
                    StartupXmlConfigData.getInstance().getParameterFileItem(DENY_UNDEF_STATUS_CHANGE));
        } catch (Exception e) {
            allowUndefStatusChange = true;
        }
        String acsItem = commonGlobalFunctions(request).getStatusChangeAcsItemValue(setCardStatusDetailInfo.getOldstat(),
                setCardStatusDetailInfo.getStatcode());
        if (isBlank(acsItem)) {
            changeStatusAllowed = allowUndefStatusChange;
        } else {
            String userName = user(request);
            AccessPermissions accessPermissions = fetchSingleBean(request, AccessPermissions.class);
            if (getUserPermissionsSet(acsItem, userName, request)) {
                changeStatusAllowed = accessPermissions.checkUpdatePermission(userName, acsItem);
            } else {
                if (getGroupPermissionsSet(acsItem, startupData(request).getUsr(userName).getUsrgrp(), request)) {
                    changeStatusAllowed = accessPermissions.checkUpdatePermission(userName, acsItem);
                } else {
                    changeStatusAllowed = allowUndefStatusChange;
                }
            }
        }
        return changeStatusAllowed;
    }

    private SetCardStatusDetailInfo copyCardStatusDetail(SetCardStatusDetailInfo setCardStatusDetailInfo) {
        SetCardStatusDetailInfo setCardStatusDetailInfo2 = new SetCardStatusDetailInfo();

        setCardStatusDetailInfo2.setAccno(setCardStatusDetailInfo.getAccno());
        setCardStatusDetailInfo2.setAdditionalno(setCardStatusDetailInfo.getAdditionalno());
        setCardStatusDetailInfo2.setAddrl1(setCardStatusDetailInfo.getAddrl1());
        setCardStatusDetailInfo2.setAddrl2(setCardStatusDetailInfo.getAddrl2());
        setCardStatusDetailInfo2.setBatch(setCardStatusDetailInfo.getBatch());
        setCardStatusDetailInfo2.setCardBlockOnly(setCardStatusDetailInfo.getCardBlockOnly());
        setCardStatusDetailInfo2.setChargedata(setCardStatusDetailInfo.getChargedata());
        setCardStatusDetailInfo2.setChargetype(setCardStatusDetailInfo.getChargetype());
        setCardStatusDetailInfo2.setClassid(setCardStatusDetailInfo.getClassid());
        setCardStatusDetailInfo2.setCorp(setCardStatusDetailInfo.getCorp());
        setCardStatusDetailInfo2.setCrdproduct(setCardStatusDetailInfo.getCrdproduct());
        setCardStatusDetailInfo2.setCurrcode(setCardStatusDetailInfo.getCurrcode());
        setCardStatusDetailInfo2.setCustcode(setCardStatusDetailInfo.getCustcode());
        setCardStatusDetailInfo2.setDatebirth(setCardStatusDetailInfo.getDatebirth());
        setCardStatusDetailInfo2.setDateExpdate(setCardStatusDetailInfo.getDateExpdate());
        setCardStatusDetailInfo2.setDateset(setCardStatusDetailInfo.getDateset());
        setCardStatusDetailInfo2.setDisplayname(setCardStatusDetailInfo.getDisplayname());
        setCardStatusDetailInfo2.setEmbossname(setCardStatusDetailInfo.getEmbossname());
        setCardStatusDetailInfo2.setExpdate(setCardStatusDetailInfo.getExpdate());
        setCardStatusDetailInfo2.setFirstname(setCardStatusDetailInfo.getFirstname());
        setCardStatusDetailInfo2.setHasOldCard(setCardStatusDetailInfo.getHasOldCard());
        setCardStatusDetailInfo2.setHome_city(setCardStatusDetailInfo.getHome_city());
        setCardStatusDetailInfo2.setHome_tel(setCardStatusDetailInfo.getHome_tel());
        setCardStatusDetailInfo2.setInstcode(setCardStatusDetailInfo.getInstcode());
        setCardStatusDetailInfo2.setLastname(setCardStatusDetailInfo.getLastname());
        setCardStatusDetailInfo2.setOldcardexpdate(setCardStatusDetailInfo.getOldcardexpdate());
        setCardStatusDetailInfo2.setOldstat(setCardStatusDetailInfo.getOldstat());
        setCardStatusDetailInfo2.setOldstatdescr(setCardStatusDetailInfo.getOldstatdescr());
        setCardStatusDetailInfo2.setPan(setCardStatusDetailInfo.getPan());
        setCardStatusDetailInfo2.setPanDisplay(setCardStatusDetailInfo.getPanDisplay());
        setCardStatusDetailInfo2.setScheme(setCardStatusDetailInfo.getScheme());
        setCardStatusDetailInfo2.setSeqno(setCardStatusDetailInfo.getSeqno());
        setCardStatusDetailInfo2.setStatcode(setCardStatusDetailInfo.getOldstat());
        setCardStatusDetailInfo2.setOldcardstat(setCardStatusDetailInfo.getOldcardstat());
        setCardStatusDetailInfo2.setStrdatebirth(setCardStatusDetailInfo.getStrdatebirth());
        setCardStatusDetailInfo2.setTypeid(setCardStatusDetailInfo.getTypeid());
        setCardStatusDetailInfo2.setUpdateoldcardstat(setCardStatusDetailInfo.getUpdateoldcardstat());
        setCardStatusDetailInfo2.setUsrdata(setCardStatusDetailInfo.getUsrdata());
        setCardStatusDetailInfo2.setVerno_ctx(setCardStatusDetailInfo.getVerno_ctx());
        setCardStatusDetailInfo2.setWho_set(setCardStatusDetailInfo.getWho_set());
        setCardStatusDetailInfo2.setWhoIp(setCardStatusDetailInfo.getWhoIp());
        setCardStatusDetailInfo2.setWhy_set(EMPTY);

        return setCardStatusDetailInfo2;

    }

    private Boolean createMkcAuthJob(HttpServletRequest request, IntegratedEntity<SetCardStatusDetailInfo> integratedEntityCrdstatus, String accessItem, String brndCode, JobType jobType,
                                     String methodName) throws Exception {
        SetCardStatusDetailInfo info = integratedEntityCrdstatus.current();
        return Util.getMakerCheckerStatus(false, (String) request.getSession(false).getAttribute(viewConstant.USERNAME),
                request.getParameter(FORMACSITEM), brndCode, info.getInstcode(), globalConstant.SOURCE_ID_CTX,
                createMkcRecId(info),
                createJobAuthCallCollator(request, methodName, integratedEntityCrdstatus, accessItem, EntityType.CARD,
                        commonGlobalFunctions(request).getCrddetIdByPanSeqno(info.getPan(), info.getSeqno()),
                        String.format(ENTITY_KEY_TWO_FMT_PTRN, info.getPan(), info.getSeqno())),
                jobType);
    }

    private JobAuthCallCollator createJobAuthCallCollator(HttpServletRequest request, String methodName,
                                                          IntegratedEntity<SetCardStatusDetailInfo> integratedEntityCrdstatus, String accessItem,
                                                          EntityType entityType, long entityId, String entityKey) {
        JobAuthCallCollator collator = new JobAuthCallCollator(beanNameFor(request, CardStatusMgr.class), BEAN_NAME,
                methodName, integratedEntityCrdstatus, integratedEntityCrdstatus, integratedEntityCrdstatus.current(), integratedEntityCrdstatus.origin(), entityType.getCode(), entityId, entityKey,
                SetCardStatusDetailInfo.aliasesMap);
        collator.addParameter(accessItem, null, null);
        return collator;
    }

    private String createMkcRecId(SetCardStatusDetailInfo info) {
        return String.format(MkcConstants.CARD_REC_ID_FMT_PTRN, info.getPan(), info.getSeqno());
    }

    private boolean getGroupPermissionsSet(String acsItem, String groupName, HttpServletRequest request) {
        String selectSQL = SQLConstants.GET_GROUP_PERMISSIONS_FOR_ACS_ITEM;

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection(request);
            statement = connection.prepareStatement(selectSQL);
            statement.setString(1, acsItem);
            statement.setString(2, groupName);

            resultSet = statement.executeQuery();
            return resultSet != null && resultSet.next();
        } catch (SQLException sqlex) {
            debugLib.logError(CLASSNAME, sqlex.toString());
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString());
        } finally {
            dbLib.closeResultSet(resultSet);
            dbLib.closeStatement(statement);
            closeConnection(request, CLASSNAME, connection);
        }
        return false;
    }

    private boolean getUserPermissionsSet(String acsItem, String userName, HttpServletRequest request) {
        String selectSQL = SQLConstants.GET_USER_PERMISSIONS_FOR_ACS_ITEM;

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection(request);
            statement = connection.prepareStatement(selectSQL);
            statement.setString(1, acsItem);
            statement.setString(2, userName);

            resultSet = statement.executeQuery();
            return resultSet != null && resultSet.next();
        } catch (SQLException sqlex) {
            debugLib.logError(CLASSNAME, sqlex.toString());
        } catch (Exception e) {
            debugLib.logError(CLASSNAME, e.toString());
        } finally {
            dbLib.closeResultSet(resultSet);
            dbLib.closeStatement(statement);
            closeConnection(request, CLASSNAME, connection);
        }
        return false;
    }
}
