package com.cortex.cust.bre.gui.ia.action;

import static com.cortex.common.constant.CortexConstants.ERROR_UNKNOWN_ERROR_KEY;
import static com.cortex.cxo.controllers.common.utils.ActionUtil.generateJobAuthCallCollator;
import static com.cortex.gui.StrutsConstants.DELETE_STATUS_PARAM;
import static com.cortex.gui.StrutsConstants.DELETE_STATUS_VALUE;
import static com.cortex.gui.common.constant.viewConstant.ACTION_SUCCESS;
import static com.cortex.gui.common.constant.viewConstant.ACTION_SUCCESS_FLAG;
import static com.cortex.gui.common.constant.viewConstant.BUTTON_ADD;
import static com.cortex.gui.common.constant.viewConstant.BUTTON_DELETE;
import static com.cortex.gui.common.constant.viewConstant.BUTTON_EDIT;
import static com.cortex.gui.common.constant.viewConstant.BUTTON_REFRESH;
import static com.cortex.gui.common.constant.viewConstant.BUTTON_UPDATE;
import static com.cortex.gui.common.constant.viewConstant.CHAR_YES;
import static com.cortex.gui.common.constant.viewConstant.CREATE_VIEW_MODE;
import static com.cortex.gui.common.constant.viewConstant.DELETE_SUCCESS;
import static com.cortex.gui.common.constant.viewConstant.EDIT_VIEW_MODE;
import static com.cortex.gui.common.constant.viewConstant.ERROR_KEY_USER_DEFINED;
import static com.cortex.gui.common.constant.viewConstant.FORMACSITEM;
import static com.cortex.gui.common.constant.viewConstant.NO_USER_INST;
import static com.cortex.gui.common.constant.viewConstant.NO_USER_INST_ID;
import static com.cortex.gui.common.constant.viewConstant.PARAMETER_FORMACTION;
import static com.cortex.gui.common.constant.viewConstant.PARAMETER_KEY_1;
import static com.cortex.gui.common.constant.viewConstant.PARAMETER_KEY_2;
import static com.cortex.gui.common.constant.viewConstant.PARAMETER_KEY_3;
import static com.cortex.gui.common.constant.viewConstant.PARAMETER_KEY_4;
import static com.cortex.gui.common.constant.viewConstant.PARAMETER_KEY_5;
import static com.cortex.gui.common.constant.viewConstant.PARAMETER_KEY_6;
import static com.cortex.gui.common.constant.viewConstant.PARAMETER_KEY_7;
import static com.cortex.gui.common.constant.viewConstant.PERFORM_DEL_SUCCESS;
import static com.cortex.gui.common.constant.viewConstant.PERFORM_EDIT;
import static com.cortex.gui.common.constant.viewConstant.PERFORM_ERROR;
import static com.cortex.gui.common.constant.viewConstant.PERFORM_NOACTION;
import static com.cortex.gui.common.constant.viewConstant.PERFORM_NULL;
import static com.cortex.gui.common.constant.viewConstant.PERFORM_REPOPULATE;
import static com.cortex.gui.common.constant.viewConstant.PERFORM_SUCCESS;
import static com.cortex.gui.common.constant.viewConstant.RESULT_DELETE_SUCCESS;
import static com.cortex.gui.common.constant.viewConstant.RESULT_MKC_JOB_CREATED_SUCCESS;
import static com.cortex.gui.common.constant.viewConstant.RESULT_MKC_JOB_CREATION_SUCCESS;
import static com.cortex.gui.common.constant.viewConstant.RESULT_SUCCESS;
import static com.cortex.gui.common.constant.viewConstant.RESULT_UPDATE_SUCCESS;
import static com.cortex.gui.common.constant.viewConstant.THREE;
import static com.cortex.gui.common.constant.viewConstant.TWO;
import static com.cortex.gui.common.constant.viewConstant.USERNAME;
import static com.cortex.gui.common.constant.viewConstant.VIEW_MODE;
import static com.cortex.gui.common.constant.viewConstant.ZERO;
import static com.cortex.gui.ia.valueobj.AccdetDetailInfo.aliasesMap;
import static com.fis.mkc.domain.model.ServiceType.BEAN_NAME;
import static org.apache.commons.lang3.StringUtils.SPACE;
import static org.apache.commons.lang3.StringUtils.isNoneEmpty;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;
import static org.apache.struts.action.ActionErrors.GLOBAL_ERROR;

import java.io.IOException;
import java.util.Locale;
import java.util.Vector;

import javax.rmi.PortableRemoteObject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cortex.cust.bre.gui.ia.formbean.BREAccdetDetailForm;
import com.cortex.cust.bre.gui.ia.sessionejb.BREAccdetMgr;
import com.cortex.cust.bre.gui.ia.sessionejb.BREAccdetMgrHome;
import org.apache.commons.lang3.StringUtils;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cortex.common.constant.globalConstant;
import com.cortex.common.entityejb.AccdetXInfo;
import com.cortex.common.entityejb.AcctypeInfo;
import com.cortex.common.entityejb.EvlogInfo;
import com.cortex.common.exception.serverException;
import com.cortex.common.hook.HookFactory;
import com.cortex.common.hook.HookParam;
import com.cortex.common.lib.dateTimeLib;
import com.cortex.common.lib.debugLib;
import com.cortex.cxo.controllers.common.IntegratedEntity;
import com.cortex.cxo.controllers.ejb.core.evlog.EvlogMgr;
import com.cortex.cxo.controllers.ejb.issuer.accdet.AccdetMgr;
import com.cortex.cxo.utils.common.exception.BeanRetrievalException;
import com.cortex.gui.common.action.SessionDataAction;
import com.cortex.gui.common.action.mkc.EntityType;
import com.cortex.gui.common.action.mkc.MkcConstants;
import com.cortex.gui.common.action.mkc.Util;
import com.cortex.gui.common.lib.CommonGlobalFunctions;
import com.cortex.gui.common.lib.LocaleFormatConverter;
import com.cortex.gui.common.lib.UserInst;
import com.cortex.gui.ia.formbean.AccdetDetailForm;
import com.cortex.gui.ia.valueobj.AccdetDetailInfo;
import com.cortex.gui.ia.valueobj.AccdetPKInfo;
import com.cortex.gui.ia.valueobj.AccountDetailsInfo;
import com.cortex.gui.ia.valueobj.ParentCardDetailsInfo;
import com.fis.mkc.domain.model.JobType;
import com.fis.mkc.domain.shared.JobAuthCallCollator;

/**
 * @author : Y.Vinay Kumar
 */
public class BREAccdetDetailAction extends SessionDataAction {
  private static final String DATA_INTEGRITY_FAILURE = "Data integrity failure";
  private static final String COMMON = "COMMON";
  private static final String CO = "co";
  private static final String DIFAIL = "difail";
  private static final String UPDATE_ACCDET_METHOD = "updateAccdet";
  private static final String FORM_PARAM = "AccdetDetailForm";
  private static final String FORM_TYPE_INFO_PARAM = "FormTypeInfo";
  private static final String HAS_RIGHT_PARAM = "hasRights";
  private static final String ACCESS_ACSITEM_PARAM = "accessAcsitem";
  private static final String[] TRANSFERABLE_REQUEST_PARAMS = withMandatoryRedirectionParams(ERROR_KEY, FORM_PARAM,
          FORM_TYPE_INFO_PARAM, HAS_RIGHT_PARAM, ACCESS_ACSITEM_PARAM, ACTION_SUCCESS_FLAG, ERROR_KEY_USER_DEFINED,
          DELETE_STATUS_PARAM);
  private static final String CLASSNAME = BREAccdetDetailAction.class.getName();
  private static final String UPDATE_UNSENT_ACTION = "update_unsent";
  private static final String ACCDET_SUCCESS_REFRESH_MSG_KEY = "ia.msg.accdet.success.refresh";
  private static final String ACCDET_SUCCESS_DELETE_MSG_KEY = "ia.msg.accdet.success.delete";
  private static final String ACCDET_SUCCESS_UPDATE_MSG_KEY = "ia.msg.accdet.success.update";
  private static final String FROM_WHERE_5 = "5";
  private static final String FROM_WHERE_6 = "6";
  private static final String FROM_WHERE_7 = "7";
  private static final String PARENT_CARD_DETAILS_INFO_ATTR = "ParentCardDetailsInfo";
  private static final String ACCOUNT_NUMBER_LENGTH_ERR_PTRN = "Length of Account number must be %d";
  private static final String ACCDET_SUCCESS_ADD_MSG_KEY = "ia.msg.accdet.success.add";
  private static final String BRN_NOT_FILE_ERR_KEY = "co.error.BRN_NOT_FILE";
  private static final String INVALID_CURR_ERR_KEY = "error.common.INVALID_CURR";
  private static final String AMOUNT_AND_ACCOUNT_TYPE_EDITABLE_PLUGIN = "com.cortex.gui.ia.plugins.accdetamountsacctype.AmountAndAccountTypeEditablePlugin";
  private static final String READONLY_AMOUNT_FIELDS_PLUGIN = "com.cortex.cust.stb.gui.ia.plugins.readonlyamountfields.ReadonlyAmountFieldsPlugin";
  private static final String DELETE_ACCDET_METHOD = "deleteAccdet";
  private static final String ADD_ACCDET_METHOD = "addAccdet";

  /**
   * {@inheritDoc}
   */
  @SuppressWarnings("unchecked")
  @Override
  public ActionForward perform(ActionMapping actionMapping, ActionForm actionForm, HttpServletRequest request,
                               HttpServletResponse response) throws IOException, ServletException {
    appendMandatoryRedirectionParams(request);
    setUser((String) request.getSession(false).getAttribute(USERNAME));

    AccdetDetailForm accdetDetailForm = (AccdetDetailForm) actionForm;
    AccdetDetailInfo accdetDetailInfo = ((AccdetDetailForm) actionForm).getAccdetDetailInfo();
    AccdetXInfo accdetXInfo = ((AccdetDetailForm) actionForm).getAccdetXInfo();
    ActionErrors errors = new ActionErrors();
    Locale locale = request.getLocale();
    Vector<String> detailInfo = new Vector<>();
    String result = RESULT_SUCCESS;
    final HttpSession httpSession = request.getSession(false);
    final String formAction = request.getParameter(PARAMETER_FORMACTION);
    final Boolean mkcJobCreated = false;

    String readonlyAmountAndAccountTypeFields = String.valueOf(Boolean.TRUE);

    HookParam hookParam = new HookParam();
    hookParam.put(HookParam.PARAM1, readonlyAmountAndAccountTypeFields);
    try {
      hookParam = HookFactory.getPlugin(READONLY_AMOUNT_FIELDS_PLUGIN).process(hookParam);
      readonlyAmountAndAccountTypeFields = (String) hookParam.get(HookParam.PARAM1);
    } catch (final Exception e) {
      debugLib.logInfo(CLASSNAME, e.toString());
    }

    HookParam hookParam2 = new HookParam();
    hookParam2.put(HookParam.PARAM1, readonlyAmountAndAccountTypeFields);
    try {
      hookParam2 = HookFactory.getPlugin(AMOUNT_AND_ACCOUNT_TYPE_EDITABLE_PLUGIN).process(hookParam2);
      readonlyAmountAndAccountTypeFields = (String) hookParam2.get(HookParam.PARAM1);
    } catch (final Exception e) {
      debugLib.logInfo(CLASSNAME, e.toString());
    }
    if (formAction == PERFORM_NULL || formAction.length() == 0) {
      try {
        accdetDetailInfo = new AccdetDetailInfo();
        request.getSession(false).setAttribute(VIEW_MODE, CREATE_VIEW_MODE);

        fetchSingleBean(request, AccdetMgr.class).setFormLabels(accdetXInfo);

        commonGlobalFunctions(request);
        UserInst userInst = CommonGlobalFunctions.getUserInst(httpSession);
        long instId = userInst.getInst_id();
        String instcode = userInst.getInstcode();

        if (instId != NO_USER_INST_ID) {
          accdetDetailForm.setInstId(String.valueOf(instId));
        } else {
          accdetDetailForm.setFrmId(PERFORM_NOACTION);
        }
        accdetDetailInfo.setInstcode(instcode);
        accdetDetailInfo.setInstIdCustIdBranchID(instcode);
        accdetDetailInfo.setReadonlyAmountFields(readonlyAmountAndAccountTypeFields);
        accdetDetailForm.setAccdetDetailInfo(accdetDetailInfo);
        request.setAttribute(FORM_PARAM, accdetDetailForm);
        return cxoSuccessRedirect(actionMapping, TRANSFERABLE_REQUEST_PARAMS);
      } catch (final serverException ex) {
        if (isNotEmpty(ex.getErrorCode())) {
          errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ex.getErrorCode()));
        }
      } catch (final Exception ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
        logError(CLASSNAME, ex.toString());
      }
    } else if (formAction.equals(BUTTON_ADD)) {
      try {
        Vector<String> addCurrcode = coGlobalFunctions(request).nameCurrFind(accdetDetailInfo.getCurrCode());
        String addAlphaCode = addCurrcode.elementAt(1);

        addAlphaCode = addAlphaCode.trim();

        if (StringUtils.isEmpty(addAlphaCode)) {
          throw new serverException(INVALID_CURR_ERR_KEY);
        }
        request.getSession(false).setAttribute(VIEW_MODE, CREATE_VIEW_MODE);
        detailInfo = coGlobalFunctions(request).getAlphaCurrencyDescr(accdetDetailInfo.getCurrCode(), request
                .getLocale().getLanguage().toUpperCase());
        if (detailInfo.size() > 0) {
          accdetDetailForm.setCurrencyAlphaCode(detailInfo.elementAt(0));
          accdetDetailForm.setCurrencyDesc(detailInfo.elementAt(1));
        }

        String brnName = commonGlobalFunctions(request).funSetBrnName(accdetDetailInfo.getInstcode(),
                accdetDetailInfo.getBrncode());
        if (isNotBlank(brnName)) {
          accdetDetailForm.setBranchDescr(brnName);
        } else {
          throw new serverException(BRN_NOT_FILE_ERR_KEY);
        }

        final AccdetMgr accdetMgr = fetchSingleBean(request, AccdetMgr.class);
        accdetDetailInfo.setClassid(accdetMgr.getAcctypeData(accdetDetailInfo.getInstcode(),
                accdetDetailInfo.getTypecode()).getClassid());
        boolean flag = true;
        final int length = accdetMgr.getAccLength(accdetDetailInfo);

        if (length > 0 && accdetDetailInfo.getAccno().trim().length() != length) {
          flag = false;
        }
        if (flag) {
          accdetDetailInfo = convertAmountToLocaleFormat(storeAmountToSQLFormat(accdetDetailInfo, locale),
                  locale, accdetMgr.calculateAvlbalUnsent(accdetDetailInfo),
                  accdetMgr.calculateBlkamtUnsent(accdetDetailInfo),
                  accdetMgr.calculateUnclrcreditUnsent(accdetDetailInfo));
          AccountDetailsInfo AccountDetailsInfo = new AccountDetailsInfo(accdetDetailInfo, accdetXInfo);
          IntegratedEntity<AccountDetailsInfo> accdetDetailInfoIntegratedEntity = new IntegratedEntity<>(
                  null, AccountDetailsInfo);
          if (!createMkcAuthJob(request, accdetDetailInfo, null,
                  !Boolean.valueOf(readonlyAmountAndAccountTypeFields), EntityType.CUSTOMER,
                  JobType.NEW_ONLY, ADD_ACCDET_METHOD, accdetDetailInfo.getCustdet_id(),
                  createCustomerEntityKey(accdetDetailInfo), accdetDetailInfoIntegratedEntity)) {
            accdetMgr.addAccdet(accdetDetailInfoIntegratedEntity,
                    !Boolean.valueOf(readonlyAmountAndAccountTypeFields));
            accdetDetailInfo.setReadonlyAmountFields(readonlyAmountAndAccountTypeFields);
            accdetDetailForm.setAccdetDetailInfo(accdetDetailInfo);
            accdetDetailForm.setInstId(String.valueOf(
                    commonGlobalFunctions(request).getInstIdByInstCode(accdetDetailInfo.getInstcode())));
            request.setAttribute(ACTION_SUCCESS_FLAG, ACCDET_SUCCESS_ADD_MSG_KEY);
            result = RESULT_SUCCESS;
          } else {
            request.setAttribute(ACTION_SUCCESS_FLAG, RESULT_MKC_JOB_CREATION_SUCCESS);
            result = RESULT_SUCCESS;
          }
        } else {
          request.setAttribute(ERROR_KEY_USER_DEFINED, String.format(ACCOUNT_NUMBER_LENGTH_ERR_PTRN, length));
        }
      } catch (final Exception ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
        logError(ex);
      }
    } else if (formAction.equals(PERFORM_REPOPULATE)) {
      accdetDetailForm.setInstId(String.valueOf(
              commonGlobalFunctions(request).getInstIdByInstCode(accdetDetailInfo.getInstcode())));
      result = RESULT_SUCCESS;
    } else if (formAction.equals(BUTTON_EDIT)) {
      try {
        request.getSession(false).setAttribute(VIEW_MODE, EDIT_VIEW_MODE);
        final AccdetMgr accdetMgr = fetchSingleBean(request, AccdetMgr.class);
        final AccdetPKInfo accdetPKInfo = new AccdetPKInfo();
        ParentCardDetailsInfo parentCardDetailsInfo = new ParentCardDetailsInfo();
        accdetDetailForm.setFromwhere(request.getParameter(PARAMETER_KEY_4));
        final int fromWhere = Integer.parseInt(request.getParameter(PARAMETER_KEY_4));

        switch (fromWhere) {
          case 0: {
            accdetPKInfo.setInstcode(request.getParameter(PARAMETER_KEY_1));
            accdetPKInfo.setAccno(request.getParameter(PARAMETER_KEY_2));
            accdetPKInfo.setCurrcode(request.getParameter(PARAMETER_KEY_3));
          }
          break;
          case 1: {
            parentCardDetailsInfo = (ParentCardDetailsInfo) httpSession
                    .getAttribute(PARENT_CARD_DETAILS_INFO_ATTR);

            accdetPKInfo.setInstcode(parentCardDetailsInfo.getInstcode());
            accdetPKInfo.setAccno(parentCardDetailsInfo.getAccno());
            accdetPKInfo.setCurrcode(parentCardDetailsInfo.getCurrcode());
            accdetDetailForm.setFromwhere(ZERO);// for "0"
          }
          break;
          case 2: {
            parentCardDetailsInfo = (ParentCardDetailsInfo) httpSession
                    .getAttribute(PARENT_CARD_DETAILS_INFO_ATTR);

            accdetPKInfo.setInstcode(parentCardDetailsInfo.getInstcode());
            accdetPKInfo.setAccno(parentCardDetailsInfo.getAccno());
            accdetPKInfo.setCurrcode(parentCardDetailsInfo.getCurrcode());
            accdetDetailForm.setFromwhere(TWO);// for "1"
          }
          break;
          case 3: {
            accdetPKInfo.setInstcode(request.getParameter(PARAMETER_KEY_1));
            accdetPKInfo.setAccno(request.getParameter(PARAMETER_KEY_2));
            accdetPKInfo.setCurrcode(request.getParameter(PARAMETER_KEY_3));

            accdetDetailForm.setFromwhere(TWO);// for "2"
          }
          break;
          // for Card account screen(view cards button in card maintenance)
          case 4: {
            accdetPKInfo.setInstcode(request.getParameter(PARAMETER_KEY_1));
            accdetPKInfo.setAccno(request.getParameter(PARAMETER_KEY_2));
            accdetPKInfo.setCurrcode(request.getParameter(PARAMETER_KEY_3));

            accdetDetailForm.setFromwhere(THREE);// for "3"
          }
          break;
          case 5: {
            accdetPKInfo.setInstcode(request.getParameter(PARAMETER_KEY_1));
            accdetPKInfo.setAccno(request.getParameter(PARAMETER_KEY_2));
            accdetPKInfo.setCurrcode(request.getParameter(PARAMETER_KEY_3));
            final String pan = request.getParameter(PARAMETER_KEY_5);
            final String seqno = request.getParameter(PARAMETER_KEY_6);
            final String isLinked = request.getParameter(PARAMETER_KEY_7);

            if (isNotEmpty(pan) && isNotEmpty(seqno) && StringUtils.equals(isLinked, CHAR_YES)) {
              accdetDetailForm.setPan(pan);
              accdetDetailForm.setSeqno(seqno);
              accdetDetailForm.setIsCrdaccLnk(Boolean.TRUE.toString());
            }

            accdetDetailForm.setFromwhere(FROM_WHERE_5);// for "5"
            break;
          }
          case 6: {
            parentCardDetailsInfo = (ParentCardDetailsInfo) httpSession
                    .getAttribute(PARENT_CARD_DETAILS_INFO_ATTR);

            accdetPKInfo.setInstcode(parentCardDetailsInfo.getInstcode());
            accdetPKInfo.setAccno(parentCardDetailsInfo.getAccno());
            accdetPKInfo.setCurrcode(parentCardDetailsInfo.getCurrcode());
            accdetDetailForm.setFromwhere(FROM_WHERE_6);// for "1"
          }
          case 7: {
            accdetPKInfo.setInstcode(request.getParameter(PARAMETER_KEY_1));
            accdetPKInfo.setAccno(request.getParameter(PARAMETER_KEY_2));
            accdetPKInfo.setCurrcode(request.getParameter(PARAMETER_KEY_3));
            final String pan = request.getParameter(PARAMETER_KEY_5);
            final String seqno = request.getParameter(PARAMETER_KEY_6);

            if (isNotEmpty(pan) && isNotEmpty(seqno)) {
              accdetDetailForm.setPan(pan);
              accdetDetailForm.setSeqno(seqno);
              accdetDetailForm.setIsCrdaccLnk(Boolean.TRUE.toString());
            }

            accdetDetailForm.setFromwhere(FROM_WHERE_7);// for "7"
            break;
          }
        }
        AccdetDetailInfo tempAccdetDetailInfo = accdetMgr.auditedGetAccdet(new IntegratedEntity<>(
                accdetPKInfo, accdetPKInfo));
        final AccdetXInfo tempAccdetXInfo = accdetMgr.getAccdetX(tempAccdetDetailInfo.getId());

        tempAccdetDetailInfo = setAccountRelatedInfo(request, accdetDetailForm, errors, locale,
                readonlyAmountAndAccountTypeFields, accdetMgr, tempAccdetDetailInfo);

        if (fromWhere == 0) {
          parentCardDetailsInfo.setInstcode(request.getParameter(PARAMETER_KEY_1));
          parentCardDetailsInfo.setAccno(request.getParameter(PARAMETER_KEY_2));
          parentCardDetailsInfo.setCurrcode(request.getParameter(PARAMETER_KEY_3));
          parentCardDetailsInfo.setCustcode(tempAccdetDetailInfo.getCustcode());
          httpSession.setAttribute(PARENT_CARD_DETAILS_INFO_ATTR, parentCardDetailsInfo);
        }

        accdetDetailForm.setAccdetDetailInfo(tempAccdetDetailInfo);
        accdetDetailForm.setAccdetXInfo(tempAccdetXInfo);
        accdetDetailForm.setCycleStartDate(displayTOLocaleDate(tempAccdetDetailInfo.getStartDate(), request.getLocale()));
        accdetDetailForm.setCycleEndDate(displayTOLocaleDate(tempAccdetDetailInfo.getEndDate(), request.getLocale()));
        result = RESULT_SUCCESS;
      } catch (final Exception ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
        logError(ex);
      }
    } else if (formAction.equals(BUTTON_UPDATE)) {
      try {
        final AccdetMgr accdetMgr = fetchSingleBean(request, AccdetMgr.class);
        accdetMgr.checkAccdetIntegrity(accdetDetailInfo.getInstcode(), accdetDetailInfo.getAccno(),
                accdetDetailInfo.getCurrCode());
        Vector<String> currcode = coGlobalFunctions(request).nameCurrFind(accdetDetailInfo.getCurrCode());
        if (StringUtils.isBlank(currcode.elementAt(1))) {
          throw new serverException(INVALID_CURR_ERR_KEY);
        }
        request.getSession(false).setAttribute(VIEW_MODE, EDIT_VIEW_MODE);

        accdetDetailInfo.setClassid(accdetMgr.getAcctypeData(accdetDetailInfo.getInstcode(),
                accdetDetailInfo.getTypecode()).getClassid());
        accdetDetailInfo = storeAmountToSQLFormat(accdetDetailInfo, locale);
        final AccdetDetailInfo accdetOriginal = getOriginalAccdetDetailInfo(accdetDetailInfo.getInstcode(),
                accdetDetailInfo.getAccno(), accdetDetailInfo.getCurrCode(), locale, accdetMgr);
        accdetDetailInfo.setId(accdetOriginal.getId());
        accdetDetailInfo.setLastLoadDate(accdetOriginal.getLastLoadDate());
        accdetOriginal.setStrPreauth_unclr(Double.toString(accdetOriginal.getPreauth_unclr()));
        final AccdetXInfo originalmobjAccdetXInfo = accdetMgr.getAccdetX(accdetOriginal.getId());
        final Boolean updateAmounts = !Boolean.valueOf(readonlyAmountAndAccountTypeFields);

        final AccountDetailsInfo AccountDetailsInfo = new AccountDetailsInfo(accdetDetailInfo, accdetXInfo);
        final AccountDetailsInfo AccountDetailsInfoOriginal = new AccountDetailsInfo(accdetOriginal,
                originalmobjAccdetXInfo);
        IntegratedEntity<AccountDetailsInfo> accdetDetailInfoIntegratedEntity = new IntegratedEntity<>(
                AccountDetailsInfoOriginal, AccountDetailsInfo);

        if (!createMkcAuthJob(request, accdetDetailInfo, accdetOriginal, updateAmounts, EntityType.ACCOUNT,
                JobType.OLD_NEW_DIFF, UPDATE_ACCDET_METHOD, accdetDetailInfo.getId(),
                createAccountEntityKey(accdetDetailInfo), accdetDetailInfoIntegratedEntity)) {
          copyTo(accdetMgr.updateAccdet(accdetDetailInfoIntegratedEntity, updateAmounts), accdetDetailInfo);

          accdetDetailInfo = convertAmountToLocaleFormat(accdetDetailInfo, locale,
                  accdetMgr.calculateAvlbalUnsent(accdetDetailInfo),
                  accdetMgr.calculateBlkamtUnsent(accdetDetailInfo),
                  accdetMgr.calculateUnclrcreditUnsent(accdetDetailInfo));

          accdetDetailForm.setInstId(String.valueOf(
                  commonGlobalFunctions(request).getInstIdByInstCode(accdetDetailInfo.getInstcode())));

          accdetDetailInfo.setReadonlyAmountFields(readonlyAmountAndAccountTypeFields);
          final String statcode = accdetDetailInfo.getStatcode();
          accdetDetailInfo.setReadonlyStatcodeField(accdetMgr.isReadonlyStatcodeField(statcode));
          accdetDetailForm.setAccdetDetailInfo(accdetDetailInfo);
          accdetDetailForm.setAcclogId(String
                  .valueOf(getAccountLoggingId(accdetDetailInfo, errors, accdetMgr)));
          request.setAttribute(ACTION_SUCCESS_FLAG, ACCDET_SUCCESS_UPDATE_MSG_KEY);
          result = RESULT_UPDATE_SUCCESS;
        } else {
          request.setAttribute(ACTION_SUCCESS_FLAG, RESULT_MKC_JOB_CREATION_SUCCESS);
          result = RESULT_UPDATE_SUCCESS;
        }
      } catch (final serverException ex) {
        if (ex.getErrorCode().equals("error.integrityerror")) {
          try {
            fetchSingleBean(request, EvlogMgr.class).addEvlog(prepareEvlogInfo());
          } catch (serverException | BeanRetrievalException e) {
            logError(ex);
          }
        }
        errors.add(GLOBAL_ERROR, new ActionError(ex.getErrorCode()));

      } catch (final Exception ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
        logError(ex);
      }
    } else if (formAction.equals(BUTTON_DELETE)) {
      try {
        request.getSession(false).setAttribute(VIEW_MODE, EDIT_VIEW_MODE);

        final AccdetMgr accdetMgr = fetchSingleBean(request, AccdetMgr.class);
        final AccdetPKInfo accdetPKInfo = new AccdetPKInfo();
        accdetPKInfo.setInstcode(accdetDetailInfo.getInstcode());
        accdetPKInfo.setAccno(accdetDetailInfo.getAccno());
        accdetPKInfo.setCurrcode(accdetDetailInfo.getCurrCode());
        final AccdetDetailInfo accdetOriginal = setAccountRelatedInfo(request, accdetDetailForm, errors, locale,
                readonlyAmountAndAccountTypeFields, accdetMgr, accdetMgr.getAccdet(accdetPKInfo));
        accdetDetailInfo.setId(accdetOriginal.getId());

        AccountDetailsInfo accountDetailsInfo = new AccountDetailsInfo(accdetOriginal, accdetXInfo);
        IntegratedEntity<AccountDetailsInfo> accdetDetailInfoIntegratedEntity = new IntegratedEntity<>(
                accountDetailsInfo, null);

        if (!createMkcAuthJob(request, null, accdetOriginal, null, EntityType.ACCOUNT, JobType.OLD_ONLY,
                DELETE_ACCDET_METHOD, accdetOriginal.getId(), createAccountEntityKey(accdetOriginal),
                accdetDetailInfoIntegratedEntity)) {
          accdetMgr.deleteAccdet(accdetDetailInfoIntegratedEntity);
          request.setAttribute(ACTION_SUCCESS_FLAG, ACCDET_SUCCESS_DELETE_MSG_KEY);
          accdetDetailForm.setAccdetDetailInfo(new AccdetDetailInfo());
          result = RESULT_DELETE_SUCCESS;
        } else {
          request.setAttribute(ACTION_SUCCESS_FLAG, RESULT_MKC_JOB_CREATION_SUCCESS);
          result = RESULT_DELETE_SUCCESS;
        }
      } catch (final Exception ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
        logError(ex);
      } finally {
        if (errors.empty()) {
          if (mkcJobCreated != true) {
            request.setAttribute(ACTION_SUCCESS_FLAG, ACTION_SUCCESS);
          } else {
            request.setAttribute(ACTION_SUCCESS_FLAG, RESULT_MKC_JOB_CREATED_SUCCESS);
            request.getSession(false).setAttribute(RESULT_MKC_JOB_CREATED_SUCCESS, CHAR_YES);
          }
          accdetDetailForm.setFrmId(PERFORM_EDIT);
          request.getSession(false).setAttribute(DELETE_SUCCESS, CHAR_YES);
          request.setAttribute(DELETE_STATUS_PARAM, DELETE_STATUS_VALUE);
          return cxoRedirect(actionMapping, PERFORM_DEL_SUCCESS, TRANSFERABLE_REQUEST_PARAMS);
        } else {
          accdetDetailForm.setResultAction(PERFORM_ERROR);
          saveErrors(request, errors);
          accdetDetailForm.setFrmId(PERFORM_EDIT);
          accdetDetailForm.setResultAction(PERFORM_SUCCESS);
        }
      }
    } else if (formAction.equals(BUTTON_REFRESH)) {
      try {
        final String viewMode = (String) request.getSession(false).getAttribute(VIEW_MODE);

        final AccdetMgr accdetMgr = fetchSingleBean(request, AccdetMgr.class);
        if (viewMode.equals(EDIT_VIEW_MODE)) {
          request.getSession(false).setAttribute(VIEW_MODE, EDIT_VIEW_MODE);
          final AccdetPKInfo accdetPKInfo = new AccdetPKInfo();
          accdetPKInfo.setInstcode(accdetDetailInfo.getInstcode());
          accdetPKInfo.setAccno(accdetDetailInfo.getAccno());
          accdetPKInfo.setCurrcode(accdetDetailInfo.getCurrCode());

          AccdetDetailInfo tempAccdetDetailInfo = accdetMgr.getAccdet(accdetPKInfo);
          detailInfo = coGlobalFunctions(request).getAlphaCurrencyDescr(tempAccdetDetailInfo.getCurrCode(), request
                  .getLocale().getLanguage().toUpperCase());

          if (detailInfo.size() > 0) {
            accdetDetailForm.setCurrencyAlphaCode(detailInfo.elementAt(0));
            accdetDetailForm.setCurrencyDesc(detailInfo.elementAt(1));
          }

          tempAccdetDetailInfo = convertAmountToLocaleFormat(tempAccdetDetailInfo, locale,
                  accdetMgr.calculateAvlbalUnsent(tempAccdetDetailInfo),
                  accdetMgr.calculateBlkamtUnsent(tempAccdetDetailInfo),
                  accdetMgr.calculateUnclrcreditUnsent(tempAccdetDetailInfo));

          accdetDetailForm.setInstId(String.valueOf(
                  commonGlobalFunctions(request).getInstIdByInstCode(accdetDetailInfo.getInstcode())));
          accdetDetailForm.setAccdetDetailInfo(tempAccdetDetailInfo);
          accdetDetailForm.setCycleStartDate(displayTOLocaleDate(tempAccdetDetailInfo.getStartDate(), request.getLocale()));
          accdetDetailForm.setCycleEndDate(displayTOLocaleDate(tempAccdetDetailInfo.getEndDate(), request.getLocale()));
          if (isNoneEmpty(tempAccdetDetailInfo.getInstcode(), tempAccdetDetailInfo.getCustcode())) {
            try {
              tempAccdetDetailInfo = accdetMgr.getCustName(tempAccdetDetailInfo);

              accdetDetailForm.setLastname(tempAccdetDetailInfo.getLastname());
              accdetDetailForm.setFirstname(tempAccdetDetailInfo.getFirstname());
              accdetDetailForm.setTitle(tempAccdetDetailInfo.getTitle());
            } catch (final Exception ex) {
              logError(ex);
            }

            try {
              final int typeId = accdetMgr.getCustTypeid(tempAccdetDetailInfo.getInstcode(),
                      tempAccdetDetailInfo.getCustcode());
              tempAccdetDetailInfo.setCustTypeid(typeId);
              accdetDetailForm.setCustTypeid(typeId);
            } catch (final Exception ex) {
              logError(ex);
            }
          }

          accdetDetailForm.setAcclogId(String
                  .valueOf(getAccountLoggingId(accdetDetailInfo, errors, accdetMgr)));
          request.setAttribute(ACTION_SUCCESS_FLAG, ACCDET_SUCCESS_REFRESH_MSG_KEY);
        } else {
          request.getSession(false).setAttribute(VIEW_MODE, CREATE_VIEW_MODE);
          AccdetDetailInfo tempAccdetDetailInfo = new AccdetDetailInfo();
          final String tempInstcode = accdetDetailInfo.getInstcode();

          if (!tempInstcode.equals(NO_USER_INST) && isNotEmpty(tempInstcode)) {
            accdetDetailForm.setInstId(String.valueOf(commonGlobalFunctions(request).getInstIdByInstCode(tempInstcode)));
          }

          if (isNoneEmpty(accdetDetailInfo.getCustcode(), accdetDetailInfo.getInstcode())) {
            try {
              tempAccdetDetailInfo = accdetMgr.getCustName(accdetDetailInfo);
              accdetDetailForm.setLastname(tempAccdetDetailInfo.getLastname());
              accdetDetailForm.setFirstname(tempAccdetDetailInfo.getFirstname());
              accdetDetailForm.setTitle(tempAccdetDetailInfo.getTitle());
            } catch (final Exception ex) {
              logError(CLASSNAME, ex.toString());
            }
          }

          if (isNoneEmpty(accdetDetailInfo.getTypecode(), tempInstcode)) {
            final AcctypeInfo acctypeInfo = accdetMgr
                    .getAcctypeData(tempInstcode, accdetDetailInfo.getTypecode());
            accdetDetailForm.setCurrcode(acctypeInfo.getCurrCode());
            accdetDetailForm.setClassid(acctypeInfo.getClassid());
          }

          if (isNoneEmpty(accdetDetailInfo.getBrncode(), tempInstcode)) {
            accdetDetailForm.setBranchDescr(accdetMgr.getBrnDescr(accdetDetailInfo));
          }
        }
        result = RESULT_SUCCESS;
      } catch (final serverException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ex.getErrorCode()));
      } catch (final Exception ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
        logError(ex);
      }
    } else if (formAction.equals(UPDATE_UNSENT_ACTION)) {
      try {
        request.getSession(false).setAttribute(VIEW_MODE, EDIT_VIEW_MODE);

        final AccdetMgr accdetMgr = fetchSingleBean(request, AccdetMgr.class);
        final double avlbalUnsent = accdetMgr.calculateAvlbalUnsent(accdetDetailInfo);
        final double blkamtUnsent = accdetMgr.calculateBlkamtUnsent(accdetDetailInfo);
        final double unclrcreditUnsent = accdetMgr.calculateUnclrcreditUnsent(accdetDetailInfo);
        accdetDetailInfo = storeUnsentToSQLFormat(accdetDetailInfo, locale, avlbalUnsent, blkamtUnsent,
                unclrcreditUnsent);

        final AccdetDetailInfo accdetOriginal = getOriginalAccdetDetailInfo(accdetDetailInfo.getInstcode(),
                accdetDetailInfo.getAccno(), accdetDetailInfo.getCurrCode(), locale, accdetMgr);
        accdetDetailInfo.setId(accdetOriginal.getId());
        accdetDetailInfo.setLastLoadDate(accdetOriginal.getLastLoadDate());
        accdetOriginal.setStrPreauth_unclr(Double.toString(accdetOriginal.getPreauth_unclr()));
        final AccdetXInfo originalAccdetXInfo = accdetMgr.getAccdetX(accdetOriginal.getId());

        final AccountDetailsInfo AccountDetailsInfoOriginal = new AccountDetailsInfo(accdetOriginal,
                originalAccdetXInfo);

        AccountDetailsInfo accountDetailsInfo = new AccountDetailsInfo(accdetDetailInfo, accdetXInfo);
        IntegratedEntity<AccountDetailsInfo> accdetDetailInfoIntegratedEntity = new IntegratedEntity<>(
                AccountDetailsInfoOriginal, accountDetailsInfo);
        copyTo(accdetMgr.updateAccdetUnsentValues(accdetDetailInfoIntegratedEntity), accdetDetailInfo);
        accdetDetailInfo = convertAmountToLocaleFormat(accdetDetailInfo, locale, avlbalUnsent, blkamtUnsent,
                unclrcreditUnsent);
        accdetDetailForm.setInstId(String.valueOf(
                commonGlobalFunctions(request).getInstIdByInstCode(accdetDetailInfo.getInstcode())));

        accdetDetailInfo.setReadonlyStatcodeField(accdetMgr.isReadonlyStatcodeField(accdetDetailInfo
                .getStatcode()));
        accdetDetailForm.setAccdetDetailInfo(accdetDetailInfo);
        accdetDetailForm.setCycleStartDate(displayTOLocaleDate(accdetDetailInfo.getStartDate(), request.getLocale()));
        accdetDetailForm.setCycleEndDate(displayTOLocaleDate(accdetDetailInfo.getEndDate(), request.getLocale()));
        request.setAttribute(ACTION_SUCCESS_FLAG, ACCDET_SUCCESS_UPDATE_MSG_KEY);
        result = RESULT_UPDATE_SUCCESS;
      } catch (final serverException ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ex.getErrorCode()));
      } catch (final Exception ex) {
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
        logError(CLASSNAME, ex.toString());
      }
    }
    request.setAttribute(FORM_PARAM, accdetDetailForm);
    if (!errors.empty()) {
      return saveErrorsAndRedirect(request, errors, actionMapping, TRANSFERABLE_REQUEST_PARAMS);
    }

    return cxoRedirect(actionMapping, result, TRANSFERABLE_REQUEST_PARAMS);
  }

  private AccdetDetailInfo getOriginalAccdetDetailInfo(String instCode, String accno, String currCode, Locale locale,
                                                       AccdetMgr accdetMgr) throws  serverException, Exception {

    AccdetDetailInfo accdetOriginal;
    AccdetPKInfo accdetPKInfo = new AccdetPKInfo();

    accdetPKInfo.setInstcode(instCode);
    accdetPKInfo.setAccno(accno);
    accdetPKInfo.setCurrcode(currCode);

    accdetOriginal = accdetMgr.getAccdet(accdetPKInfo);

    accdetOriginal = accdetMgr.getAccdet(accdetPKInfo);
    accdetOriginal = convertAmountToLocaleFormat(accdetOriginal, locale,
            accdetMgr.calculateAvlbalUnsent(accdetOriginal), accdetMgr.calculateBlkamtUnsent(accdetOriginal),
            accdetMgr.calculateUnclrcreditUnsent(accdetOriginal));

    final String tempInstcode = accdetOriginal.getInstcode();
    final String custcode = accdetOriginal.getCustcode();
    if (isNoneEmpty(tempInstcode, custcode)) {
      try {
        accdetOriginal = accdetMgr.getCustName(accdetOriginal);
      } catch (final Exception ex) {
        logError(ex);
      }

      try {
        final int typeId = accdetMgr.getCustTypeid(tempInstcode, custcode);
        accdetOriginal.setCustTypeid(typeId);
      } catch (final Exception ex) {
        logError(ex);
      }
    }
    accdetPKInfo = null;

    return accdetOriginal;
  }

  private AccdetDetailInfo convertAmountToLocaleFormat(AccdetDetailInfo accdetDetailInfo, Locale locale,
                                                       double avlbalUnsent, double blkamtUnsent, double unclrcreditUnsent) throws serverException, Exception {
    try {
      accdetDetailInfo.setStrOpenbal(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getAvlBal(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setStrBlkamt(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getBlkAmt(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setStrClrbal(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getClrbal(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setStrUnclrbal(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getUnclrbal(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setStrCredit_limit(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getCredit_limit(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo
              .setStrAvlbal(LocaleFormatConverter.displayToLocalCurrencysymb(
                      accdetDetailInfo.getAvlBal() - accdetDetailInfo.getBlkAmt()
                              + accdetDetailInfo.getOverride() + accdetDetailInfo.getUnclrCredit(),
                      locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setStrOverride(LocaleFormatConverter.convertCurrencyToLocale(
              accdetDetailInfo.getOverride(), locale, accdetDetailInfo.getCurrCode()));

      accdetDetailInfo.setStrAvlbal_unsent(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getAvlbal_unsent(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setStrBlkamt_unsent(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getBlkamt_unsent(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setStrAvlbal_unsent_upload(LocaleFormatConverter.displayToLocalCurrencysymb(avlbalUnsent,
              locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setStrBlkamt_unsent_upload(LocaleFormatConverter.displayToLocalCurrencysymb(blkamtUnsent,
              locale, accdetDetailInfo.getCurrCode()));

      accdetDetailInfo.setStrShdwAuthOv(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getShdwAuthOv(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setStrUnclrcredit(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getUnclrCredit(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setStrUnclrcredit_unsent(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getUnclrcredit_unsent(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setStrUnclrcredit_unsent_upload(LocaleFormatConverter.displayToLocalCurrencysymb(
              unclrcreditUnsent, locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setStrUnclrlocredit(LocaleFormatConverter.displayToLocalCurrencysymb(
              accdetDetailInfo.getUnclrlocredit(), locale, accdetDetailInfo.getCurrCode()));
    } catch (final serverException se) {
      throw se;
    } catch (final Exception e) {
      throw e;
    }

    return accdetDetailInfo;
  }

  private AccdetDetailInfo storeAmountToSQLFormat(AccdetDetailInfo accdetDetailInfo, Locale locale)
          throws serverException, Exception {
    try {
      accdetDetailInfo.setAvlBal(LocaleFormatConverter.storeToSqlCurrencysymb(accdetDetailInfo.getStrOpenbal(),
              locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setBlkAmt(LocaleFormatConverter.storeToSqlCurrencysymb(accdetDetailInfo.getStrBlkamt(),
              locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setClrbal(LocaleFormatConverter.storeToSqlCurrencysymb(accdetDetailInfo.getStrClrbal(),
              locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setUnclrbal(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrUnclrbal(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setCredit_limit(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrCredit_limit(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setAvlbal_unsent(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrAvlbal_unsent(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setBlkamt_unsent(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrBlkamt_unsent(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setShdwAuthOv(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrShdwAuthOv(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setUnclrCredit(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrUnclrcredit(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setUnclrcredit_unsent(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrUnclrcredit_unsent(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setUnclrlocredit(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrUnclrlocredit(), locale, accdetDetailInfo.getCurrCode()));
    } catch (final serverException se) {
      throw se;
    } catch (final Exception e) {
      throw e;
    }
    return accdetDetailInfo;
  }

  private AccdetDetailInfo storeUnsentToSQLFormat(AccdetDetailInfo accdetDetailInfo, Locale locale,
                                                  double avlbalUnsent, double blkamtUnsent, double unclrcreditUnsent) throws serverException, Exception {
    try {
      accdetDetailInfo.setAvlBal(LocaleFormatConverter.storeToSqlCurrencysymb(accdetDetailInfo.getStrOpenbal(),
              locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setBlkAmt(LocaleFormatConverter.storeToSqlCurrencysymb(accdetDetailInfo.getStrBlkamt(),
              locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setClrbal(LocaleFormatConverter.storeToSqlCurrencysymb(accdetDetailInfo.getStrClrbal(),
              locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setUnclrbal(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrUnclrbal(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setCredit_limit(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrCredit_limit(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setAvlbal_unsent(LocaleFormatConverter.storeToSqlCurrencysymb(
              LocaleFormatConverter.displayToLocalCurrencysymb(avlbalUnsent, locale,
                      accdetDetailInfo.getCurrCode()),
              locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setBlkamt_unsent(LocaleFormatConverter.storeToSqlCurrencysymb(
              LocaleFormatConverter.displayToLocalCurrencysymb(blkamtUnsent, locale,
                      accdetDetailInfo.getCurrCode()),
              locale, accdetDetailInfo.getCurrCode()));

      accdetDetailInfo.setShdwAuthOv(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrShdwAuthOv(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setUnclrCredit(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrUnclrcredit(), locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setUnclrcredit_unsent(LocaleFormatConverter.storeToSqlCurrencysymb(
              LocaleFormatConverter.displayToLocalCurrencysymb(unclrcreditUnsent, locale,
                      accdetDetailInfo.getCurrCode()),
              locale, accdetDetailInfo.getCurrCode()));
      accdetDetailInfo.setUnclrlocredit(LocaleFormatConverter.storeToSqlCurrencysymb(
              accdetDetailInfo.getStrUnclrlocredit(), locale, accdetDetailInfo.getCurrCode()));
    } catch (final serverException se) {
      throw se;
    } catch (final Exception e) {
      throw e;
    }
    return accdetDetailInfo;
  }

  private int getAccountLoggingId(AccdetDetailInfo accdetDetailInfo, ActionErrors errors, AccdetMgr accdetMgr) {
    int acclogId = 1;
    try {
      acclogId = accdetMgr.getAcctypeData(accdetDetailInfo.getInstcode(), accdetDetailInfo.getTypecode())
              .getAcclogId();
    } catch (final serverException ex) {
      errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ex.getErrorCode()));
    } catch (final Exception ex) {
      errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(ERROR_UNKNOWN_ERROR_KEY));
      logError(CLASSNAME, ex.toString());
    }

    return acclogId;
  }

  private Boolean createMkcAuthJob(HttpServletRequest request, AccdetDetailInfo displayInfo,
                                   AccdetDetailInfo displayOriginalInfo, Boolean readonlyAmountAndAccountTypeFields, EntityType entityType,
                                   JobType jobType, String methodName, long entityId, String entityKey,
                                   IntegratedEntity<AccountDetailsInfo> accdetDetailInfoIntegratedEntity) throws Exception {
    final AccdetDetailInfo keyInfo = displayInfo != null ? displayInfo : displayOriginalInfo;
    aliasesMap.putAll(AccdetXInfo.aliasesMap);
    final JobAuthCallCollator jobAuthCallCollator = generateJobAuthCallCollator(beanNameFor(request, AccdetMgr.class),
            BEAN_NAME, methodName, accdetDetailInfoIntegratedEntity, aliasesMap);
    if (null != readonlyAmountAndAccountTypeFields) {
      jobAuthCallCollator.addParameter(readonlyAmountAndAccountTypeFields, null, null);
    }
    return Util.getMakerCheckerStatus(
            false,
            (String) request.getSession(false).getAttribute(USERNAME),
            request.getParameter(FORMACSITEM),
            keyInfo.getBrncode(),
            keyInfo.getInstcode(),
            globalConstant.SOURCE_ID_CTX,
            String.format(MkcConstants.ACCOUNT_REC_ID_FMT_PTRN, keyInfo.getInstcode(), keyInfo.getAccno(),
                    keyInfo.getCurrCode()),
            jobAuthCallCollator, jobType);
  }

  private String createAccountEntityKey(AccdetDetailInfo keyInfo) {
    return String.format(ENTITY_KEY_THREE_FMT_PTRN, keyInfo.getInstcode(), keyInfo.getAccno(),
            keyInfo.getCurrCode());
  }

  private String createCustomerEntityKey(AccdetDetailInfo keyInfo) {
    return String.format(ENTITY_KEY_TWO_FMT_PTRN, keyInfo.getInstcode(), keyInfo.getCustcode());
  }

  private AccdetDetailInfo setAccountRelatedInfo(HttpServletRequest request, AccdetDetailForm accdetDetailForm,
                                                 ActionErrors errors, Locale locale, String readonlyAmountAndAccountTypeFields, AccdetMgr accdetMgr,
                                                 AccdetDetailInfo tempAccdetDetailInfo) throws serverException, Exception {
    Vector<String> detailInfo;
    if (isNotEmpty(tempAccdetDetailInfo.getInstcode()) && isNotEmpty(tempAccdetDetailInfo.getCustcode())) {
      try {
        tempAccdetDetailInfo = accdetMgr.getCustName(tempAccdetDetailInfo);
        accdetDetailForm.setLastname(tempAccdetDetailInfo.getLastname());
        accdetDetailForm.setFirstname(tempAccdetDetailInfo.getFirstname());
        accdetDetailForm.setTitle(tempAccdetDetailInfo.getTitle());
      } catch (final Exception ex) {
        logError(ex);
      }

      try {
        final int typeId = accdetMgr.getCustTypeid(tempAccdetDetailInfo.getInstcode(),
                tempAccdetDetailInfo.getCustcode());
        tempAccdetDetailInfo.setCustTypeid(typeId);
        accdetDetailForm.setCustTypeid(typeId);
      } catch (final Exception ex) {
        logError(ex);
      }
    }

    accdetDetailForm.setInstId(String.valueOf(
            commonGlobalFunctions(request).getInstIdByInstCode(tempAccdetDetailInfo.getInstcode())));

    detailInfo = coGlobalFunctions(request).getAlphaCurrencyDescr(tempAccdetDetailInfo.getCurrCode(),
            request.getLocale()
                    .getLanguage().toUpperCase());

    if (detailInfo.size() > 0) {
      accdetDetailForm.setCurrencyAlphaCode(detailInfo.elementAt(0));
      accdetDetailForm.setCurrencyDesc(detailInfo.elementAt(1));
    }

    String brnName = commonGlobalFunctions(request).funSetBrnName(tempAccdetDetailInfo.getInstcode(),
            tempAccdetDetailInfo.getBrncode());
    accdetDetailForm.setBranchDescr(brnName);

    tempAccdetDetailInfo = convertAmountToLocaleFormat(tempAccdetDetailInfo, locale,
            accdetMgr.calculateAvlbalUnsent(tempAccdetDetailInfo),
            accdetMgr.calculateBlkamtUnsent(tempAccdetDetailInfo),
            accdetMgr.calculateUnclrcreditUnsent(tempAccdetDetailInfo));

    tempAccdetDetailInfo.setReadonlyAmountFields(readonlyAmountAndAccountTypeFields);

    final String statcode = tempAccdetDetailInfo.getStatcode();
    tempAccdetDetailInfo.setReadonlyStatcodeField(accdetMgr.isReadonlyStatcodeField(statcode));
    accdetDetailForm.setAcclogId(String.valueOf(getAccountLoggingId(tempAccdetDetailInfo, errors, accdetMgr)));
    return tempAccdetDetailInfo;
  }

  private EvlogInfo prepareEvlogInfo() {
    final EvlogInfo evlogInfo = new EvlogInfo();
    evlogInfo.setEvent(DIFAIL);
    evlogInfo.setFmodule(CO);
    evlogInfo.setFprg(COMMON);
    evlogInfo.setFdate(dateTimeLib.getCurrentDate());
    evlogInfo.setFtime(dateTimeLib.getCurrentTime());
    evlogInfo.setEvdata(DATA_INTEGRITY_FAILURE);
    evlogInfo.setAckdate(dateTimeLib.getNeverDate());
    evlogInfo.setAcktime(0l);
    evlogInfo.setAckusr(SPACE);
    evlogInfo.setAckdescr(SPACE);
    return evlogInfo;
  }

protected void performUnlink(HttpServletRequest request, ActionForm actionForm)
  {
    logInfo(CLASSNAME, "performUnlink");
    
    try
    {
      AccdetDetailInfo accdetDetailInfo = ((BREAccdetDetailForm) actionForm).getAccdetDetailInfo();

      BREAccdetMgrHome accdetMgrHome  = fetchMgrHomeBean(request, BREAccdetMgrHome.class);
      BREAccdetMgr accdetMgr = accdetMgrHome.create();

      accdetMgr.unlinkAccdet(accdetDetailInfo);
    }
    catch (Exception e)
    {     
      logError(CLASSNAME, e.toString());
    }
  }
}
