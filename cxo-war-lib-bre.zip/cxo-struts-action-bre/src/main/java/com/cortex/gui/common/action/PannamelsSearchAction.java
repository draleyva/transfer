package com.cortex.gui.common.action;

import java.io.IOException;
import java.sql.Date;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cortex.common.exception.serverException;
import com.cortex.gui.common.constant.viewConstant;
import com.cortex.gui.common.formbean.PagingForm;
import com.cortex.gui.common.formbean.PannamelsSearchForm;
import com.cortex.gui.common.lib.CommonGlobalFunctions;
import com.cortex.gui.common.lib.LocaleFormatConverter;
import com.cortex.gui.common.lib.UserInst;
import com.cortex.gui.common.security.obfuscation.FieldObfuscator;
import com.cortex.gui.common.sessionejb.PannamelsMgr;
import com.cortex.gui.common.sessionejb.PannamelsMgrHome;
import com.cortex.gui.common.valueobj.PagingContextInfo;
import com.cortex.gui.common.valueobj.PannamelsInfo;

public class PannamelsSearchAction extends PagingAction
{
    private static final String CLASSNAME="PannamelsSearchAction";


    /**
     * {@inheritDoc}
     */
    @Override
    public ActionForward perform(ActionMapping pobjActionMapping, ActionForm pobjActionForm,
                                 HttpServletRequest request,  HttpServletResponse pobjResponse)
            throws IOException, ServletException
    {
        setUser((String)request.getSession().getAttribute(viewConstant.USERNAME));
        Locale tobjLocale = request.getLocale();

        // Nomad V.K. 05/12/2003: NMR010431: AT-0004 Adding comments to the fixes.
        // This screen was redeveloped. Removed tabs from ia_pannamels.
        // Search criteria contains just 'First name', 'Last Name', 'Card Number' and 'Date of Birth'.
        // None of the fields are mandatory.
        // If any of the fields are left blank, this is treated has a wildcard character, e.g. showing
        // the warning message. Please see all these changes in previous submit.

        PannamelsInfo mobjPannamelsInfo = new PannamelsInfo();
        HttpSession session = request.getSession(true);

        ActionErrors errors = new ActionErrors();
        PannamelsSearchForm tobjPannamelsSearchForm = new PannamelsSearchForm();
        PagingContextInfo tobjPagingContextInfo = null;
        PannamelsInfo tobjPannamelsInfo = null;
        String tsFormAction = request.getParameter(viewConstant.PERFORM_FORMACTION);
        UserInst userInst = CommonGlobalFunctions.getUserInst(session);
        String tsinstcode = userInst.getInstcode();
        if (!( tsinstcode != null && !tsinstcode.equals(viewConstant.NO_USER_INST))) {
            tsinstcode = "";
        }


        if(tsFormAction == viewConstant.PERFORM_NULL||tsFormAction.length() ==0)
        {
            try
            {
                tobjPannamelsInfo = ((PannamelsSearchForm) pobjActionForm).getPannamelsInfo();
                tobjPagingContextInfo = ((PannamelsSearchForm) pobjActionForm).getPagingContextInfo();
                ((PannamelsSearchForm) pobjActionForm).getSessionDataInfo();
                tobjPannamelsInfo.setInstcode(tsinstcode);
                tobjPannamelsInfo.recalculateAccIdCustIdBranchId();
            }
            catch(Exception e)
            {
                logError(CLASSNAME,e.toString());
            }
        }
        else if(tsFormAction.equals(viewConstant.PERFORM_SEARCH))
        {
            try
            {
                tobjPannamelsInfo = ((PannamelsSearchForm) pobjActionForm).getPannamelsInfo();
                tobjPagingContextInfo = ((PannamelsSearchForm) pobjActionForm).getPagingContextInfo();
                ((PannamelsSearchForm) pobjActionForm).getSessionDataInfo();

                if(tobjPannamelsInfo.getFirstname()!=null && !tobjPannamelsInfo.getFirstname().trim().equals("")){
                    mobjPannamelsInfo.setFirstname(tobjPannamelsInfo.getFirstname());
                }
                if(tobjPannamelsInfo.getLastname()!=null && !tobjPannamelsInfo.getLastname().trim().equals("")){
                    mobjPannamelsInfo.setLastname(tobjPannamelsInfo.getLastname());
                }
                if(tobjPannamelsInfo.getPan()!=null && !tobjPannamelsInfo.getPan().trim().equals("")){
                    String strPAN = tobjPannamelsInfo.getPan();

                    if (!panCryptor(request).isPanEncrypted(strPAN)) {
                        strPAN = panCryptor(request).encryptPan(tobjPannamelsInfo.getPan());
                    }
                    // mobjPannamelsInfo.setPan(tobjPannamelsInfo.getPan());
                    mobjPannamelsInfo.setPan(strPAN);
                }
                if(tobjPannamelsInfo.getVirtualPan()!=null && !tobjPannamelsInfo.getVirtualPan().trim().equals("")){
                    mobjPannamelsInfo.setVirtualPan(tobjPannamelsInfo.getVirtualPan());
                }
                if(tobjPannamelsInfo.getDob()!=null && !tobjPannamelsInfo.getDob().trim().equals("")){
                    Date tsDob = LocaleFormatConverter.convertLocaleToSqlDate(tobjPannamelsInfo.getDob(),request.getLocale());
                    mobjPannamelsInfo.setDob(LocaleFormatConverter.convertToStandardFormat(tsDob));
                }
                mobjPannamelsInfo.setInstcode(tsinstcode);
                mobjPannamelsInfo.recalculateAccIdCustIdBranchId();

                PagingContextInfo tobjRetPagingContextInfo = performSearch(request, tobjPannamelsSearchForm, mobjPannamelsInfo, tobjPagingContextInfo, tobjLocale);
                request.setAttribute("pageForm",new PagingForm(tobjRetPagingContextInfo));
                tobjPannamelsSearchForm.setResultAction(viewConstant.PERFORM_SUCCESS);

            }
            catch(serverException se)
            {
                errors.add("newDate", new ActionError(se.getErrorCode()));
            }
            catch(Exception e)
            {
                tobjPannamelsSearchForm.setResultAction(viewConstant.PERFORM_ERROR);
            }
            finally
            {
                tobjPannamelsSearchForm.setPannamelsInfo(tobjPannamelsInfo);
                if (!errors.empty())
                {
                    saveErrors(request, errors);
                }
            }
        }
        else if (tsFormAction.equals(viewConstant.PERFORM_UNMASK))
        {
            try
            {
                tobjPannamelsSearchForm = (PannamelsSearchForm)pobjActionForm;
                tobjPannamelsInfo = ((PannamelsSearchForm) pobjActionForm).getPannamelsInfo();

                String tsUnmaskedValue =
                        fetchSingleBean(request, FieldObfuscator.class).unmaskField("pannamelsInfoList.pan",
                        tobjPannamelsSearchForm.getIndex_returned(), request);

                if(tsUnmaskedValue != null && !tsUnmaskedValue.equals(""))
                {
                    tobjPannamelsSearchForm.setPan_returned(tsUnmaskedValue);
                }
                tobjPannamelsSearchForm.setFormActionUnmask("true");
            }
            catch(Exception e)
            {
                tobjPannamelsSearchForm.setResultAction(viewConstant.PERFORM_ERROR);
            }
            finally
            {
                tobjPannamelsSearchForm.setPannamelsInfo(tobjPannamelsInfo);
                if (!errors.empty())
                {
                    saveErrors(request, errors);
                }
            }
        }

        tobjPannamelsSearchForm.setInstCode(tsinstcode);
        request.getSession().setAttribute(viewConstant.TABID,"0");
        request.setAttribute("pannamelsSearchForm",tobjPannamelsSearchForm);
        request.setAttribute("PannamelsSearchForm",tobjPannamelsSearchForm);
        request.setAttribute(Action.ERROR_KEY,errors);

        return pobjActionMapping.findForward(viewConstant.PERFORM_SUCCESS);
    }

    private PagingContextInfo performSearch(HttpServletRequest request,PannamelsSearchForm tobjPannamelsSearchForm,
                                            PannamelsInfo pobjPannamelsInfo,
                                            PagingContextInfo pobjPagingContextInfo,
                                            Locale tobjLocale)
            throws Exception
    {


        PannamelsMgrHome objPannamelsMgrHome =
                fetchMgrHomeBean(request,PannamelsMgrHome.class);


        PannamelsMgr objPannamelsMgr = objPannamelsMgrHome.create();
        java.util.ArrayList objSearchInfo = objPannamelsMgr.searchPanname(pobjPannamelsInfo,pobjPagingContextInfo);


        PannamelsInfo objPannamelsInfoList[] = new PannamelsInfo[objSearchInfo.size()-1];
        for(int n=0; n<objSearchInfo.size()-1; n++)
        {
            PannamelsInfo tobjPannamelsInfo = (PannamelsInfo)objSearchInfo.get(n);
            tobjPannamelsInfo.setExpiryDate(convertSQLToLocaleStringDate(tobjPannamelsInfo.getExpiryDate(),tobjLocale));
            tobjPannamelsInfo.setDob(convertSQLToLocaleStringDate(tobjPannamelsInfo.getDob(),tobjLocale));
            objPannamelsInfoList[n] = tobjPannamelsInfo;
        }
        tobjPannamelsSearchForm.setPannamelsInfoList(objPannamelsInfoList);
        PagingContextInfo tobjPagingContextInfo = (PagingContextInfo)objSearchInfo.get(objSearchInfo.size()-1);
        tobjPannamelsSearchForm.setPagingContextInfo(tobjPagingContextInfo);

        return tobjPagingContextInfo;
    }

}
