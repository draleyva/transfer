package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "AddCrdRetData")
@XmlAccessorType(XmlAccessType.FIELD)
public class AdditionalCardReturnData {
	
	@XmlElement(name = "PIN", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Pin pin;

	@XmlElement(name = "CardProData", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String cardProductionData;

	public Pin getPin() {
		return pin;
	}

	public void setPin(Pin pin) {
		this.pin = pin;
	}

	public String getCardProductionData() {
		return cardProductionData;
	}

	public void setCardProductionData(String cardProductionData) {
		this.cardProductionData = cardProductionData;
	}

}
