package com.fis.cortex.domain.custid.basic;

import java.io.Serializable;

import com.fis.cortex.domain.custid.CustIdCode;
import com.fis.cortex.domain.custid.CustIdType;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/domain/custid/basic/BasicCustIdCode.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class BasicCustIdCode implements CustIdCode, Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private int versionNumber;
	private long  customerId;
	private CustIdType custIdType;
	private String  code;
	
	
    public long getId(){
    	return  this.id;
    }
	
	public void setId(long id){
		this.id = id;
	}

	public int getVersionNUmber(){
		return this.versionNumber;
	}
	
	public void setVersionNumber(int versionNumber){
	   this.versionNumber = versionNumber;	
	}
	
	public long  getCustomerId(){
		return this.customerId;
	}
	
	public void  setCustomerId(Long custId){
		this.customerId = custId;
	}
	
	public CustIdType getCustIdType(){
		return custIdType;
	}
	
	public void setCustIdType(CustIdType custIdType){
		 this.custIdType =custIdType;
	}
	
	public String getCode(){
		return this.code;
	}
	
	public void setCode(String code){
		this.code=code;
	}
	
	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result
				+ ((custIdType == null) ? 0 : custIdType.hashCode());
		result = prime * result + (int) (customerId ^ (customerId >>> 32));
		return result;
	}

	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BasicCustIdCode other = (BasicCustIdCode) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		if (custIdType == null) {
			if (other.custIdType != null)
				return false;
		} else if (!custIdType.equals(other.custIdType))
			return false;
		if (customerId != other.customerId)
			return false;
		return true;
	}
	
	

}
