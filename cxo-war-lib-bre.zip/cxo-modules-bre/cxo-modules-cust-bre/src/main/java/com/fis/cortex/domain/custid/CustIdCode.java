package com.fis.cortex.domain.custid;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/domain/custid/CustIdCode.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public interface CustIdCode {
	
	long getId();
	
	void setId(long id);
	
	int getVersionNUmber();
	
	void setVersionNumber(int versionNumber);
	
	long  getCustomerId();
	
	void  setCustomerId(Long custId);
	
	CustIdType getCustIdType();
	
	void setCustIdType(CustIdType custIdType);
	
	String getCode();
	
	void setCode(String code);

}
