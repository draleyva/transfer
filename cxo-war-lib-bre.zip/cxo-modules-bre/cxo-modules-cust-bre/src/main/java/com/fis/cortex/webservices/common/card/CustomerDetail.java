package com.fis.cortex.webservices.common.card;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "CustDet")
@XmlAccessorType(XmlAccessType.FIELD)
public class CustomerDetail 
{
	@XmlElement(name = "DuplicateMng", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String duplicateMng;
	@XmlElement(name = "Custcode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String custCode;
	@XmlElement(name = "Title", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String title;
	@XmlElement(name = "LastName", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String lastName;
	@XmlElement(name = "FirstName", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String firstName;
	@XmlElement(name = "DOB", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String DOB;
	@XmlElement(name = "AddrInd", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private int addrInd;
	@XmlElement(name = "MaritalStatus", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String maritalStatus;
	@XmlElement(name = "Sex", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String sex;
	@XmlElement(name = "RefuseChq", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String refuseChq;
	@XmlElementWrapper( name = "UserDataLst", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	@XmlElement( name = "UserData", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private List<UserData> userDataList;
	@XmlElement(name = "MailShots", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String mailShots;
	@XmlElement(name = "PrfLang", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	String prfLang;
	@XmlElement(name = "TypeId", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private int typeId;
	@XmlElement(name = "ProfCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private int profCode;
	@XmlElement(name = "CustSeg", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String customerSegmentation;
	@XmlElementWrapper( name = "ContactMechLst", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	@XmlElement( name = "ContactMech", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private List<ContactMechanism> contactMechLst;
	@XmlElementWrapper( name = "IdentLst", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	@XmlElement(name = "Ident", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private List<Identification> identificationList; 
	
	public String getDuplicateMng() {
		return duplicateMng;
	}
	public void setDuplicateMng(String duplicateMng) {
		this.duplicateMng = duplicateMng;
	}
	public String getCustCode() {
		return custCode;
	}
	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public int getAddrInd() {
		return addrInd;
	}
	public void setAddrInd(int addrInd) {
		this.addrInd = addrInd;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getRefuseChq() {
		return refuseChq;
	}
	public void setRefuseChq(String refuseChq) {
		this.refuseChq = refuseChq;
	}
	public String getMailShots() {
		return mailShots;
	}
	public void setMailShots(String mailShots) {
		this.mailShots = mailShots;
	}
	public String getPrfLang() {
		return prfLang;
	}
	public void setPrfLang(String prfLang) {
		this.prfLang = prfLang;
	}
	public int getTypeId() {
		return typeId;
	}
	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}
	public int getProfCode() {
		return profCode;
	}
	public void setProfCode(int profCode) {
		this.profCode = profCode;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public List<UserData> getUserDataList() {
		return userDataList;
	}
	public void setUserDataList(List<UserData> userDataList) {
		this.userDataList = userDataList;
	}
	public List<Identification> getIdentificationList() {
		return identificationList;
	}
	public void setIdentificationList(List<Identification> identificationList) {
		this.identificationList = identificationList;
	}
	public List<ContactMechanism> getContactMechLst() {
		return contactMechLst;
	}
	public void setContactMechLst(List<ContactMechanism> contactMechLst) {
		this.contactMechLst = contactMechLst;
	}
	public void setCustomerSegmentation(String customerSegmentation) {
		this.customerSegmentation = customerSegmentation;
	}
	public String getCustomerSegmentation() {
		return customerSegmentation;
	}
	
	
}
