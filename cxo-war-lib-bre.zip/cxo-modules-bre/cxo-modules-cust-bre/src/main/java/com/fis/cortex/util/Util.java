package com.fis.cortex.util;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import org.slf4j.helpers.MessageFormatter;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.ConsoleAppender;
import ch.qos.logback.core.util.StatusPrinter;
import org.slf4j.LoggerFactory;

/**
 *
 * @author e5706717
 */
public class Util 
{
  static final Logger LOGGER = (Logger) org.slf4j.LoggerFactory.getLogger(Util.class);
  
  static
  {
    /*
    configureFileLogging(Level.DEBUG);
    
    setLogLevel(new String[]{
      "org.apache.wicket.Page",
      "org.apache.wicket.Component",
      "org.apache.wicket.MarkupContainer",
      "org.apache.wicket.core.util.resource.locator.Resource",
      "org.hibernate.impl.SessionImpl",
      "wicket.protocol.http.request.CryptedUrlWebRequestCodingStrategy",
      "org.apache.wicket.Localizer",
      "org.hibernate.jdbc.ConnectionManager",
      "org.apache.wicket.RequestCycle",
      "org.apache.wicket.protocol.http.request.CryptedUrlWebRequestCodingStrategy",
      "org.hibernate.jdbc.ConnectionManager"
    }, Level.OFF);
    */
  }
  
  public static void setLogLevel(String [] classes, Level level)
  {
    if(level == null)
      return;
   
    Logger root;
    for(String c : classes)
    {
      root = (Logger)LoggerFactory.getLogger(c);
      root.setLevel(level);
    }
  }
    
  // CortexSession.get().getUserName();
  // CortexSession.get().getUserName();
  public static void configureFileLogging(Level level) 
  {
    LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
    
    //context.reset(); // Clear previous config

    // === 1. Encoder ===
    PatternLayoutEncoder encoder = new PatternLayoutEncoder();
    encoder.setContext(context);
    encoder.setPattern("%d{yyyy-MM-dd HH:mm:ss} %-5level [%thread] %logger{36} - %msg%n");
    encoder.setImmediateFlush(true);
    encoder.start();

    /*
    // === 2. Rolling Policy ===
    TimeBasedRollingPolicy<ILoggingEvent> rollingPolicy = new TimeBasedRollingPolicy<>();
    rollingPolicy.setContext(context);
    rollingPolicy.setFileNamePattern("C:\\FISserver\\WLS\\user_projects\\domains\\ctx42bre\\fis\\BRE\\logs\\Cortex.%d{yyyy-MM-dd}.log"); // daily rotation
    rollingPolicy.setMaxHistory(7); // keep 7 days
    rollingPolicy.setParent(new RollingFileAppender<>()); // required dummy parent
    rollingPolicy.start();

    // === 3. RollingFileAppender ===
    RollingFileAppender<ILoggingEvent> rollingFileAppender = new RollingFileAppender<>();
    rollingFileAppender.setContext(context);
    rollingFileAppender.setName("ROLLING");
    rollingFileAppender.setFile("C:\\FISserver\\WLS\\user_projects\\domains\\ctx42bre\\fis\\BRE\\logs\\Cortex.log"); // current log file
    rollingFileAppender.setEncoder(encoder);
    rollingFileAppender.setRollingPolicy(rollingPolicy);
    rollingPolicy.setParent(rollingFileAppender); // real parent now
    rollingFileAppender.start();
    */
    // === 4. ConsoleAppender ===
    ConsoleAppender<ILoggingEvent> consoleAppender = new ConsoleAppender<>();
    consoleAppender.setContext(context);
    consoleAppender.setName("STDOUT");
    consoleAppender.setEncoder(encoder);
    consoleAppender.start();

    // === 5. Root Logger ===
    Logger rootLogger = context.getLogger(Logger.ROOT_LOGGER_NAME);
    rootLogger.setLevel(level);
    //rootLogger.addAppender(rollingFileAppender);
    rootLogger.addAppender(consoleAppender);

    // === 6. Debug (optional) ===
    StatusPrinter.printInCaseOfErrorsOrWarnings(context);
  }
  
  public static void logInfo(String format, Object... args)
  {
    String formatted = MessageFormatter.arrayFormat(format, args).getMessage();
    //System.out.println(formatted);
    LOGGER.info(formatted);
  }
  
  public static void logError(String format, Object... args)
  {
    String formatted = MessageFormatter.arrayFormat(format, args).getMessage();
    //System.out.println(formatted);
    LOGGER.error(formatted);
  }
}
