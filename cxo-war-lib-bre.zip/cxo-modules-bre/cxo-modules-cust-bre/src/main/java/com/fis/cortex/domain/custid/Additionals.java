package com.fis.cortex.domain.custid;


/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/domain/custid/Additionals.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public interface Additionals {
	
	int getVersionNumber();
	
	void setVersionNumber(int versionNumber);
	
	int getAdditionalsno();
	
	void setAdditionalsno(int additionalno);
	
	AdditionalsId getId();
	
	void setId(AdditionalsId id);

}
