package com.fis.cortex.webservices.common.card;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "CrdDet")
@XmlAccessorType(XmlAccessType.FIELD)
public class CardDetail 
{
	@XmlElement( name = "CustCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String customerCode;
	@XmlElement( name = "Title", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String title;
	@XmlElement( name = "FirstName", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String firstName;
	@XmlElement( name = "Lastname", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String lastname;
	@XmlElement( name = "LocTitle", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String localizedTitle;
	@XmlElement( name = "LocFirstName", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String localizedFirstName;
	@XmlElement( name = "LocLastName", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String localizedLastName;
	@XmlElement( name = "PAN", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String pan;
	@XmlElement( name = "SeqNo", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Short seqNo;
	@XmlElement( name = "CardAlias", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String cardAlias;
	@XmlElement( name = "ReplacementPAN", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String replacementPAN;
	@XmlElement( name = "ReplacementCardAlias", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String replacementCardAlias;
	@XmlElement( name = "AdditonalNo", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Integer additonalNo;
	@XmlElement( name = "AddLinkage", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private AddLinkage addLinkage;
	@XmlElement( name = "BrnCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String branchCode;
	@XmlElement( name = "DlvBrnCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String deliveryBranchCode;
	@XmlElement( name = "Priority", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Integer priority;
	@XmlElement( name = "AccNo", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String accountNumber;
	@XmlElement( name = "CurrCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String currencyCode;
	@XmlElement( name = "Renew", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String renew;
	@XmlElement( name = "DOB", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Date DOB;
	@XmlElement( name = "Discret", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String discret;
	@XmlElementWrapper( name = "UserDataLst", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	@XmlElement( name = "UserData", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private List<UserData> UserDataLst;
	@XmlElement( name = "StatCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String statusCode;
	@XmlElement( name = "EffDate", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Date effectDate;
	@XmlElement( name = "ExpDate", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Date expirypDate;
	@XmlElement( name = "CrdProduct", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String cardProduct;
	@XmlElement( name = "Lang", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String language;
	@XmlElement( name = "EmbossName", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String embossName;
	@XmlElement( name = "DlvMethod", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String deliveryMethod;
	@XmlElement( name = "AddrInd", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Integer addressIndicator;
	@XmlElement( name = "CustIdNum", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String custIdNum;
	@XmlElement( name = "ExtCustIdNum", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String extCustIdNum;	
	@XmlElement( name = "KinShip", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String kinShip;
	@XmlElementWrapper( name = "CrdSupDocLst", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	@XmlElement( name = "CrdSupDoc", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private List<CardSupportingDocumentData> cardSupportingDocuments;
	@XmlElement( name = "CrdProgram", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String cardProgram;
	@XmlElement( name = "CrdDesign", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String cardDesign;
	@XmlElement( name = "sCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String issuerHostCode;
	@XmlElement( name = "CommCat", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String commissionCategory;
	@XmlElement( name = "FeeCat", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String feeCategory;
	@XmlElement( name = "CycFeeCat", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String cycFeeCat;   
	@XmlElement( name = "IssRiskCat", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String issRiskCat;
	@XmlElement( name = "CrdIssCat", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String cardIssuanceCategory;
	@XmlElementWrapper( name = "ContactMechLst", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	@XmlElement( name = "ContactMech", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private List<ContactMechanism> contactMechLst;
	@XmlElement( name = "SecurityVerification", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private SecurityVerification securityVerification;
	@XmlElement( name = "CrdNotify", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private CardNotify cardNotify;
	@XmlElement( name = "GenPIN", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String doGeneratePin;
	@XmlElementWrapper( name = "PINTypeLst", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	@XmlElement( name = "PINType", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private List<Short> pinType;
	@XmlElement( name = "CrdEventPINStatus", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Short cardEventPinStatus;
	@XmlElement( name = "AddCrdRetData", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private AdditionalCardReturnData additionalCardReturnData;
	
	
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getPan() {
		return pan;
	}
	public String getLocalizedTitle() {
		return localizedTitle;
	}
	public void setLocalizedTitle(String localizedTitle) {
		this.localizedTitle = localizedTitle;
	}
	public String getLocalizedFirstName() {
		return localizedFirstName;
	}
	public void setLocalizedFirstName(String localizedFirstName) {
		this.localizedFirstName = localizedFirstName;
	}
	public String getLocalizedLastName() {
		return localizedLastName;
	}
	public void setLocalizedLastName(String localizedLastName) {
		this.localizedLastName = localizedLastName;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public Short getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(Short seqNo) {
		this.seqNo = seqNo;
	}
	public String getCardAlias() {
		return cardAlias;
	}
	public void setCardAlias(String cardAlias) {
		this.cardAlias = cardAlias;
	}
	public String getReplacementPAN() {
		return replacementPAN;
	}
	public void setReplacementPAN(String replacementPAN) {
		this.replacementPAN = replacementPAN;
	}
	public Integer getAdditonalNo() {
		return additonalNo;
	}
	public void setAdditonalNo(Integer additonalNo) {
		this.additonalNo = additonalNo;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getDeliveryBranchCode() {
		return deliveryBranchCode;
	}
	public void setDeliveryBranchCode(String deliveryBranchCode) {
		this.deliveryBranchCode = deliveryBranchCode;
	}
	public Integer getPriority() {
		return priority;
	}
	public void setPriority(Integer priority) {
		this.priority = priority;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getRenew() {
		return renew;
	}
	public void setRenew(String renew) {
		this.renew = renew;
	}
	public String getDiscret() {
		return discret;
	}
	public void setDiscret(String discret) {
		this.discret = discret;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getCardProduct() {
		return cardProduct;
	}
	public void setCardProduct(String cardProduct) {
		this.cardProduct = cardProduct;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getEmbossName() {
		return embossName;
	}
	public void setEmbossName(String embossName) {
		this.embossName = embossName;
	}
	public String getDeliveryMethod() {
		return deliveryMethod;
	}
	public void setDeliveryMethod(String deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}
	public Integer getAddressIndicator() {
		return addressIndicator;
	}
	public void setAddressIndicator(Integer addressIndicator) {
		this.addressIndicator = addressIndicator;
	}
	public String getCustIdNum() {
		return custIdNum;
	}
	public void setCustIdNum(String custIdNum) {
		this.custIdNum = custIdNum;
	}
	public String getCardProgram() {
		return cardProgram;
	}
	public void setCardProgram(String cardProgram) {
		this.cardProgram = cardProgram;
	}
	public String getCardDesign() {
		return cardDesign;
	}
	public void setCardDesign(String cardDesign) {
		this.cardDesign = cardDesign;
	}
	public String getCommissionCategory() {
		return commissionCategory;
	}
	public void setCommissionCategory(String commissionCategory) {
		this.commissionCategory = commissionCategory;
	}
	public String getFeeCategory() {
		return feeCategory;
	}
	public void setFeeCategory(String feeCategory) {
		this.feeCategory = feeCategory;
	}
	public String getCycFeeCat() {
		return cycFeeCat;
	}
	public void setCycFeeCat(String cycFeeCat) {
		this.cycFeeCat = cycFeeCat;
	}
	public String getIssRiskCat() {
		return issRiskCat;
	}
	public void setIssRiskCat(String issRiskCat) {
		this.issRiskCat = issRiskCat;
	}
	public Date getDOB() {
		return DOB;
	}
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	public Date getEffectDate() {
		return effectDate;
	}
	public void setEffectDate(Date effectDate) {
		this.effectDate = effectDate;
	}
	public Date getExpirypDate() {
		return expirypDate;
	}
	public void setExpirypDate(Date expirypDate) {
		this.expirypDate = expirypDate;
	}
	public List<UserData> getUserDataLst() {
		return UserDataLst;
	}
	public void setUserDataLst(List<UserData> userDataLst) {
		UserDataLst = userDataLst;
	}
	public AddLinkage getAddLinkage() {
		return addLinkage;
	}
	public void setAddLinkage(AddLinkage addLinkage) {
		this.addLinkage = addLinkage;
	}
	public SecurityVerification getSecurityVerification() {
		return securityVerification;
	}
	public void setSecurityVerification(SecurityVerification securityVerification) {
		this.securityVerification = securityVerification;
	}
	public String getReplacementCardAlias() {
		return replacementCardAlias;
	}
	public void setReplacementCardAlias(String replacementCardAlias) {
		this.replacementCardAlias = replacementCardAlias;
	}
	public void setDoGeneratePin(String doGeneratePin) {
		this.doGeneratePin = doGeneratePin;
	}
	public String getDoGeneratePin() {
		return doGeneratePin;
	}
	public void setAdditionalCardReturnData(AdditionalCardReturnData additionalCardReturnData) {
		this.additionalCardReturnData = additionalCardReturnData;
	}
	public AdditionalCardReturnData getAdditionalCardReturnData() {
		return additionalCardReturnData;
	}
	public void setCardIssuanceCategory(String cardIssuanceCategory) {
		this.cardIssuanceCategory = cardIssuanceCategory;
	}
	public String getCardIssuanceCategory() {
		return cardIssuanceCategory;
	}
	public void setCardEventPinStatus(Short cardEventPinStatus) {
		this.cardEventPinStatus = cardEventPinStatus;
	}
	public Short getCardEventPinStatus() {
		return cardEventPinStatus;
	}
	public List<Short> getPinType() {
		return pinType;
	}
	public void setPinType(List<Short> pinType) {
		this.pinType = pinType;
	}
	
	public String getKinShip() {
		return kinShip;
	}
	public void setKinShip(String kinShip) {
		this.kinShip = kinShip;
	}
	
	public List<CardSupportingDocumentData> getCardSupportingDocuments() {
		return cardSupportingDocuments;
	}
	public void setCardSupportingDocuments(
			List<CardSupportingDocumentData> cardSupportingDocuments) {
		this.cardSupportingDocuments = cardSupportingDocuments;
	}
	public CardNotify getCardNotify() {
		return cardNotify;
	}
	public void setCardNotify(CardNotify cardNotify) {
		this.cardNotify = cardNotify;
	}
	public List<ContactMechanism> getContactMechLst() {
		return contactMechLst;
	}
	public void setContactMechLst(List<ContactMechanism> contactMechLst) {
		this.contactMechLst = contactMechLst;
	}
	public String getIssuerHostCode() {
		return issuerHostCode;
	}
	public void setIssuerHostCode(String issuerHostCode) {
		this.issuerHostCode = issuerHostCode;
	}
	public String getExtCustIdNum() {
		return extCustIdNum;
	}
	public void setExtCustIdNum(String extCustIdNum) {
		this.extCustIdNum = extCustIdNum;
	}

}
