package com.fis.cortex.access.custid.view;

import com.fis.cortex.transport.core.dataholder.TransportObject;
import com.metavante.cortex.transport.objects.core.Institution;

/*** 
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/view/AdditionalAccountsContextSummary.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 * 
 */

public class AdditionalAccountsContextSummary extends TransportObject implements Cloneable{
	private static final long serialVersionUID = 3638067847753911549L;
	
	// member variables
	private Card card;
	private Institution institution;
	private String message;

	public AdditionalAccountsContextSummary() {}
	
	public AdditionalAccountsContextSummary(Institution institution,Card card,String message) {
		this.card = card;
		this.institution = institution;
		this.message=message;
	}

	public Card getCard() {
		return card;
	}

	public void setCard(Card card) {
		this.card = card;
	}

	public Institution getInstitution() {
		return institution;
	}

	public void setInstitution(Institution institution) {
		this.institution = institution;
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
