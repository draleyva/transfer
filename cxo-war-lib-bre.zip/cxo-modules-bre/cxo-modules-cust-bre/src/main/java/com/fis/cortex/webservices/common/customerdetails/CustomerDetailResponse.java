package com.fis.cortex.webservices.common.customerdetails;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/customerDetailResponse", name = "CustomerDetailResponse")
@XmlAccessorType(XmlAccessType.FIELD)
public class CustomerDetailResponse {
	
	@XmlElement(required = true, name = "InstCode", namespace = "http://crdbase.cortex.fis.com/customerDetailResponse")
	private String institutionCode;
	
	@XmlElement(required = true, name = "CustCode", namespace = "http://crdbase.cortex.fis.com/customerDetailResponse")
	private String customerCode;
	
	public CustomerDetailResponse(String institutionCode, String customerCode) {
		this.institutionCode = institutionCode;
		this.customerCode = customerCode;
	}

	/**
	 * 
	 */
	public CustomerDetailResponse() {
	}

	public String getInstitutionCode() {
		return institutionCode;
	}

	public void setInstitutionCode(String institutionCode) {
		this.institutionCode = institutionCode;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

}
