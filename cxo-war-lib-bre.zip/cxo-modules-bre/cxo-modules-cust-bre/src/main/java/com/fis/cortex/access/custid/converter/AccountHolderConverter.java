package com.fis.cortex.access.custid.converter;

import org.apache.commons.lang3.StringUtils;

import com.fis.cortex.access.custid.view.Account;
import com.fis.cortex.access.custid.view.AccountHolder;
import com.fis.cortex.access.custid.view.Address;
import com.fis.cortex.transport.core.converter.EntityTransportConverter;
import com.fis.cortex.transport.core.dataholder.TransportList;
import com.fis.cortex.transport.core.dataholder.TransportObject.Id;
import com.nomadsoft.cortex.domain.accountholder.basic.BasicAddress;


/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/converter/AccountHolderConverter.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public class AccountHolderConverter extends EntityTransportConverter<com.nomadsoft.cortex.domain.accountholder.AccountHolder, AccountHolder>{
	AccountConverter accountConverter;	
	private static final String EMPTY=" ";
	
	public AccountHolder convertRealToTransport(com.nomadsoft.cortex.domain.accountholder.AccountHolder accountHolder){
		TransportList<Account>  accountList =new TransportList<Account>();
		AccountHolder accHolder = new AccountHolder();
		accHolder.markConfiguredWithId(accountHolder.getId());
		accHolder.setAddressIndicator(accountHolder.getAddressIndicator());
		accHolder.setCollectionZone(accountHolder.getCollectionZone());
		accHolder.setDateAccepted(accountHolder.getDateAccepted());
		accHolder.setDateOfBirth(accountHolder.getDateOfBirth());
		accHolder.setEmail(accountHolder.getEmailAddress());
		accHolder.setFirstName(accountHolder.getFirstName());
		accHolder.setHomeTelephoneNumber(accountHolder.getHomeTelephoneNumber());
		accHolder.setIdNumber(accountHolder.getIdNumber());
		accHolder.setLastName(accountHolder.getLastName());
		accHolder.setMailShots(accountHolder.getMailShots());
		accHolder.setMaritalStatus(accountHolder.getMaritalStatus());
		accHolder.setMemo(accountHolder.getMemo());
		accHolder.setMobileTelephoneNumber(accountHolder.getMobileTelephoneNumber());
		accHolder.setNumberBouncedChequesPrimaryCurrency(accountHolder.getNumberBouncedChequesPrimaryCurrency());
		accHolder.setNumberBouncedChequesSecondaryCurrency(accountHolder.getNumberBouncedChequesSecondaryCurrency());
		accHolder.setPOBox(accountHolder.getPOBox());
		accHolder.setPreferredLanguage(accountHolder.getPreferredLanguage());
		accHolder.setProfessionCode(accountHolder.getProfessionCode());
		accHolder.setRefuseCheque(accountHolder.getRefuseCheque());
		accHolder.setSex(accountHolder.getSex());
		accHolder.setStatementCode(accountHolder.getStatementCode());
		accHolder.setTitle(accountHolder.getTitle());
		accHolder.setCustomerType(accountHolder.getCustomerType());
		accHolder.setUserData1(accountHolder.getUserData1());
		accHolder.setUserData2(accountHolder.getUserData2());
		accHolder.setUserData3(accountHolder.getUserData3());
		accHolder.setUserData4(accountHolder.getUserData4());
		accHolder.setCustomerCode(accountHolder.getCustomerCode());	
		accHolder.setFaxNumber(accountHolder.getFaxNumber());
		accHolder.setCatParams(accountHolder.getCatParams());
		for(com.nomadsoft.cortex.domain.account.Account account : accountHolder.getAccounts()){
			Account acnt =accountConverter.convertRealToTransport(account);
			acnt.setAccountHolder(accHolder);
			accountList.add(acnt);			
		}
		accHolder.setAccounts(accountList);		
		com.nomadsoft.cortex.domain.accountholder.Address homeAddressDomain= accountHolder.getHomeAddress();
		if(homeAddressDomain!=null){
			Address homeAddress = new Address();
			homeAddress.setAddressLine1(homeAddressDomain.getAddressLine1());
			homeAddress.setAddressLine1UpperCase(homeAddressDomain.getAddressLine1UpperCase());
			homeAddress.setAddressLine2(homeAddressDomain.getAddressLine2());
			homeAddress.setAddressLine3(homeAddressDomain.getAddressLine3());
			homeAddress.setCity(homeAddressDomain.getCity());
			homeAddress.setCounty(homeAddressDomain.getCounty());
			homeAddress.setPostCode(homeAddressDomain.getPostCode());
			homeAddress.setPostCodeUpperCase(homeAddressDomain.getPostCodeUpperCase());
			accHolder.setHomeAddress(homeAddress);
		}
		com.nomadsoft.cortex.domain.accountholder.Address workAddressDomain= accountHolder.getWorkAddress();
		if(workAddressDomain!=null){
			Address workAddress = new Address();
			workAddress.setAddressLine1(workAddressDomain.getAddressLine1());
			workAddress.setAddressLine1UpperCase(workAddressDomain.getAddressLine1UpperCase());
			workAddress.setAddressLine2(workAddressDomain.getAddressLine2());
			workAddress.setAddressLine3(workAddressDomain.getAddressLine3());
			workAddress.setCity(workAddressDomain.getCity());
			workAddress.setCounty(workAddressDomain.getCounty());
			workAddress.setPostCode(workAddressDomain.getPostCode());
			workAddress.setPostCodeUpperCase(workAddressDomain.getPostCodeUpperCase());
			accHolder.setWorkAddress(workAddress);
		}
		
		return accHolder;
	}	
	
	public com.nomadsoft.cortex.domain.accountholder.AccountHolder findReal(Id userId, Integer version) {
	   return null;
	}	
	
	public void updateRealFromTransport(com.nomadsoft.cortex.domain.accountholder.AccountHolder customer, AccountHolder accountHolder)
	{
		
		customer.setAddressIndicator(accountHolder.getAddressIndicator());
		customer.setCollectionZone(accountHolder.getCollectionZone());
		customer.setDateAccepted(accountHolder.getDateAccepted());
		customer.setDateOfBirth(accountHolder.getDateOfBirth());
		customer.setEmailAddress(StringUtils.isNotEmpty(accountHolder.getEmail())?accountHolder.getEmail():EMPTY);
		customer.setFirstName(StringUtils.isNotEmpty(accountHolder.getFirstName())?accountHolder.getFirstName():EMPTY);
		customer.setHomeTelephoneNumber(StringUtils.isNotEmpty(accountHolder.getHomeTelephoneNumber())?accountHolder.getHomeTelephoneNumber():EMPTY);
		customer.setIdNumber(StringUtils.isNotEmpty(accountHolder.getIdNumber())?accountHolder.getIdNumber():EMPTY);
		customer.setLastName(StringUtils.isNotEmpty(accountHolder.getLastName())?accountHolder.getLastName():EMPTY);
		customer.setMailShots(accountHolder.getMailShots());
		customer.setMaritalStatus(accountHolder.getMaritalStatus());
		customer.setMemo(accountHolder.getMemo());
		customer.setMobileTelephoneNumber(StringUtils.isNotEmpty(accountHolder.getMobileTelephoneNumber())?accountHolder.getMobileTelephoneNumber():EMPTY);
		customer.setNumberBouncedChequesPrimaryCurrency(accountHolder.getNumberBouncedChequesPrimaryCurrency());
		customer.setNumberBouncedChequesSecondaryCurrency(accountHolder.getNumberBouncedChequesSecondaryCurrency());
		customer.setPOBox(StringUtils.isNotEmpty(accountHolder.getPOBox())?accountHolder.getPOBox():EMPTY);
		customer.setPreferredLanguage(accountHolder.getPreferredLanguage());
		customer.setProfessionCode(accountHolder.getProfessionCode());
		customer.setRefuseCheque(accountHolder.getRefuseCheque());
		customer.setSex(accountHolder.getSex());
		customer.setStatementCode(accountHolder.getStatementCode());
		customer.setTitle(StringUtils.isNotEmpty(accountHolder.getTitle())?accountHolder.getTitle():EMPTY);
		customer.setCustomerType(accountHolder.getCustomerType());
		customer.setUserData1(StringUtils.isNotEmpty(accountHolder.getUserData1())?accountHolder.getUserData1():EMPTY);
		customer.setUserData2(StringUtils.isNotEmpty(accountHolder.getUserData2())?accountHolder.getUserData2():EMPTY);
		customer.setUserData3(StringUtils.isNotEmpty(accountHolder.getUserData3())?accountHolder.getUserData3():EMPTY);
		customer.setUserData4(StringUtils.isNotEmpty(accountHolder.getUserData4())?accountHolder.getUserData4():EMPTY);
		customer.setCustomerCode(StringUtils.isNotEmpty(accountHolder.getCustomerCode())?accountHolder.getCustomerCode():EMPTY);
		customer.setFaxNumber(StringUtils.isNotEmpty(accountHolder.getFaxNumber())?accountHolder.getFaxNumber():EMPTY);
		customer.setHomeCountryIso(StringUtils.isNotEmpty(accountHolder.getHomeCountryIso())?accountHolder.getHomeCountryIso():EMPTY);
		customer.setNationalityId(StringUtils.isNotEmpty(accountHolder.getNationalityId())?accountHolder.getNationalityId():EMPTY);
		customer.setWorkCountryIso(StringUtils.isNotEmpty(accountHolder.getWorkCountryIso())?accountHolder.getWorkCountryIso():EMPTY);
		customer.setWorkTelephoneNumber(StringUtils.isNotEmpty(accountHolder.getWorkTelephoneNumber())?accountHolder.getWorkTelephoneNumber():EMPTY);
		customer.setCatParams(StringUtils.isNotEmpty(accountHolder.getCatParams())?accountHolder.getCatParams():EMPTY);
		Address homeAddress=accountHolder.getHomeAddress();
		if(homeAddress!=null){
			String homeAddrLine1= StringUtils.isNotEmpty(homeAddress.getAddressLine1())?homeAddress.getAddressLine1():EMPTY;
			String homeAddrLine2=StringUtils.isNotEmpty(homeAddress.getAddressLine2())?homeAddress.getAddressLine2():EMPTY;
			String homeAddrLine3=StringUtils.isNotEmpty(homeAddress.getAddressLine3())?homeAddress.getAddressLine3():EMPTY;
			String homeAddrcity=StringUtils.isNotEmpty(homeAddress.getCity())?homeAddress.getCity():EMPTY;
			String homeAddrPostCode=StringUtils.isNotEmpty(homeAddress.getPostCode())?homeAddress.getPostCode():EMPTY;
			String homeAddrCounty=StringUtils.isNotEmpty(homeAddress.getCounty())?homeAddress.getCounty():EMPTY;
			com.nomadsoft.cortex.domain.accountholder.Address homeAddressDomain=new BasicAddress(homeAddrLine1, homeAddrLine2, homeAddrLine3, homeAddrcity, homeAddrPostCode, homeAddrCounty);
			customer.setHomeAddress(homeAddressDomain);
		}
		Address workAddress=accountHolder.getWorkAddress();
		if(workAddress!=null){
			String workAddrLine1= StringUtils.isNotEmpty(workAddress.getAddressLine1())?workAddress.getAddressLine1():EMPTY;
			String workAddrLine2=StringUtils.isNotEmpty(workAddress.getAddressLine2())?workAddress.getAddressLine2():EMPTY;
			String workAddrLine3=StringUtils.isNotEmpty(workAddress.getAddressLine3())?workAddress.getAddressLine3():EMPTY;
			String workAddrcity=StringUtils.isNotEmpty(workAddress.getCity())?workAddress.getCity():EMPTY;
			String workAddrPostCode=StringUtils.isNotEmpty(workAddress.getPostCode())?workAddress.getPostCode():EMPTY;
			String workAddrCounty=StringUtils.isNotEmpty(workAddress.getCounty())?workAddress.getCounty():EMPTY;
			com.nomadsoft.cortex.domain.accountholder.Address workAddressDomain=new BasicAddress(workAddrLine1, workAddrLine2, workAddrLine3, workAddrcity, workAddrPostCode, workAddrCounty);
			customer.setWorkAddress(workAddressDomain);
		}
		
		
			
	}
	
	public void setAccountConverter(AccountConverter accountConverter){
		this.accountConverter=accountConverter;
	}

}
