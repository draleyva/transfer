package com.fis.cortex.webservices.client;
import org.springframework.ws.WebServiceMessageFactory;
import org.springframework.ws.client.core.WebServiceTemplate;

/**
*
* @author schinnas
* @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/webservices/client/CortexWebServiceTemplate.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
*/

public class CortexWebServiceTemplate extends WebServiceTemplate {	 
	
	CortexWebServiceTemplate(WebServiceMessageFactory  webServiceMessageFactory){
		super(webServiceMessageFactory);
	}


}
