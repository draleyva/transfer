package com.fis.cortex.access.custid.converter;



import com.fis.cortex.access.custid.view.CardStatus;
import com.fis.cortex.transport.core.converter.EntityTransportConverter;
import com.fis.cortex.transport.core.dataholder.TransportObject.Id;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/converter/CardStatusConverter.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $ 
 * 
 * 
 */



public class CardStatusConverter extends EntityTransportConverter<com.nomadsoft.cortex.domain.card.CardStatus,CardStatus> {
	
	
	public CardStatus convertRealToTransport(com.nomadsoft.cortex.domain.card.CardStatus cardStatus){		
		CardStatus status = new CardStatus();
		status.setActionCode(cardStatus.getActionCode());
		status.setCancelled(cardStatus.isCancelled());
		status.setDescription(cardStatus.getDescription());
		status.setResponseCode(cardStatus.getResponseCode());
		status.setStatusCode(cardStatus.getStatusCode());
		return status;
	}
	
	
	public com.nomadsoft.cortex.domain.card.CardStatus findReal(Id accountId, Integer version) {		
	       return null;
	}	
	
	
	
	protected void updateRealFromTransport(com.nomadsoft.cortex.domain.card.CardStatus cardStatus, CardStatus status){
				
	}

}
