package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.fis.cortex.webservices.common.carddetails.CardDetailRequest;


@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "AddLinkage")
@XmlAccessorType(XmlAccessType.FIELD)
public class AddLinkage {
	
	@XmlElement(name = "LinkMthd", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Integer linkMethod;
	@XmlElement(required = false, name = "CardId", namespace = "http://crdbase.cortex.fis.com/cardDetailRequest")
	private CardDetailRequest cardId;

	public Integer getLinkMethod() {
		return linkMethod;
	}

	public void setLinkMethod(Integer linkMethod) {
		this.linkMethod = linkMethod;
	}

	public void setCardId(CardDetailRequest cardId) {
		this.cardId = cardId;
	}

	public CardDetailRequest getCardId() {
		return cardId;
	}

}
