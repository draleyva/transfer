package com.fis.cortex.webservices.common.card;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

/**
 * @author rmura
 *
 */
@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "DirectiveOsi")
@XmlAccessorType(XmlAccessType.FIELD)
public class GenerateCardOsi 
{
	@XmlElement(name = "RecId", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String recId;
	@XmlElement(name = "Action", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String Action;
	@XmlElement(name = "InstCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String InstCode;
	@XmlElement(name = "BtchClass", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Short BtchClass;
	@XmlElement(name = "Reason", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String Reason;
	@XmlElement(required = false, name = "CrdEventData", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private CardEventData cardEventData;
	@XmlElement(name = "CustDet", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
    private CustomerDetail customerDetail;
	@XmlElementWrapper( name = "AccDetLst", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	@XmlElement(name = "AccDet", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private List <AccountDetail> accountDetail;
	@XmlElement(name = "CrdDet", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
    private CardDetail cardDetail;
	@XmlElement(required = false, name = "CrdEventExtAuth", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private CardEventExternalAuthorisation cardEventExternalAuthorisation;
	
	
	/**
	 * @return the cardEventData
	 */
	public CardEventData getCardEventData() {
		return cardEventData;
	}

	/**
	 * @param cardEventData the cardEventData to set
	 */
	public void setCardEventData(CardEventData cardEventData) {
		this.cardEventData = cardEventData;
	}
	public String getAction() {
		return Action;
	}

	public void setAction(String action) {
		Action = action;
	}

	public String getInstCode() {
		return InstCode;
	}

	public void setInstCode(String instCode) {
		InstCode = instCode;
	}

	public String getReason() {
		return Reason;
	}

	public void setReason(String reason) {
		Reason = reason;
	}

	public CustomerDetail getCustomerDetail() {
		return customerDetail;
	}

	public void setCustomerDetail(CustomerDetail customerDetail) {
		this.customerDetail = customerDetail;
	}

	public List<AccountDetail> getAccountDetail() {
		return accountDetail;
	}

	public void setAccountDetail(List<AccountDetail> accountDetail) {
		this.accountDetail = accountDetail;
	}

	public CardDetail getCardDetail() {
		return cardDetail;
	}

	public void setCardDetail(CardDetail cardDetail) {
		this.cardDetail = cardDetail;
	}

	public void setBtchClass(Short btchClass) {
		BtchClass = btchClass;
	}

	public Short getBtchClass() {
		return BtchClass;
	}

	public void setCardEventExternalAuthorisation(
			CardEventExternalAuthorisation cardEventExternalAuthorisation) {
		this.cardEventExternalAuthorisation = cardEventExternalAuthorisation;
	}

	public CardEventExternalAuthorisation getCardEventExternalAuthorisation() {
		return cardEventExternalAuthorisation;
	}

	public String getRecId() {
		return recId;
	}

	public void setRecId(String recId) {
		this.recId = recId;
	}
	
	
}
