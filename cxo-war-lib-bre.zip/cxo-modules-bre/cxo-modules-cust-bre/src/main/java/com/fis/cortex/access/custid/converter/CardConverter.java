package com.fis.cortex.access.custid.converter;


import java.util.Iterator;

import com.fis.cortex.access.custid.view.Account;
import com.fis.cortex.access.custid.view.Card;
import com.fis.cortex.transport.core.converter.EntityTransportConverter;
import com.fis.cortex.transport.core.dataholder.TransportList;
import com.fis.cortex.transport.core.dataholder.TransportObject.Id;
import com.metavante.cortex.transport.objects.converter.BranchConvertor;
import com.fis.cortex.access.custid.view.CardAccount;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/converter/CardConverter.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 *  
 * 
 * 
 */

public class CardConverter extends EntityTransportConverter<com.nomadsoft.cortex.domain.card.Card, Card>{
	

	private CardProductConverter cardProductConverter;	
	private AccountHolderConverter accountHolderConverter;
	private BranchConvertor branchConverter;
	private AccountConverter accountConverter;
	private CardAccountConverter cardAccountConverter;
	private CardStatusConverter cardStatusConverter;
	
	public Card convertRealToTransport(com.nomadsoft.cortex.domain.card.Card card){
		Card  cardDTO =  new Card();
		TransportList<Account>  accounts =new TransportList<Account>();
		cardDTO.setPan(card.getPan());
		cardDTO.markConfiguredWithId(card.getId());
		cardDTO.setPanDisplay(card.getPanDisplay());
		cardDTO.setSequenceNumber(card.getSequenceNumber());		
		cardDTO.setVirtualPan(card.getVirtualPan());
		cardDTO.setBranch(this.branchConverter.convertRealToTransport(card.getBranch()));
		cardDTO.setAccountHolder(this.accountHolderConverter.convertRealToTransport(card.getAccountHolder()));
		cardDTO.setAccessCode(card.getAccessCode());
		cardDTO.setAccount(this.accountConverter.convertRealToTransport(card.getAccount()));
		cardDTO.setAuthCharsIndicator(card.isAuthCharsIndicator());
		cardDTO.setAdditionalNumber(card.getAdditionalNumber());
		cardDTO.setAddrind(card.getAddrind());
		cardDTO.setApplicationNumber(card.getApplicationNumber());
		cardDTO.setAppTransactionCounter(card.getAppTransactionCounter());
		cardDTO.setCardClass(card.getCardClass());
		cardDTO.setCorporateCard(card.isCorporateCard());
		cardDTO.setCardDesignId(card.getCardDesignId());
		cardDTO.setCardProduct(this.cardProductConverter.convertRealToTransport(card.getCardProduct()));
		cardDTO.setCardsMade(card.getCardsMade());
		cardDTO.setCardVerificationCode(card.getCardVerificationCode());
		cardDTO.setCardVerificationValue(card.getCardVerificationValue());
		cardDTO.setCycleLen(card.getCycleLen());
		cardDTO.setDiscretionaryData(card.getDiscretionaryData());
		cardDTO.setDeliveryMethod(card.getDeliveryMethod());
		cardDTO.setEmbossedName(card.getEmbossedName());
		cardDTO.setFallbackCount(card.getFallbackCount());
		cardDTO.setKinshipToPrimary(card.getKinshipToPrimary());
		cardDTO.setLanguageCode(card.getLanguageCode());
		cardDTO.setNopin(card.getNopin());
		cardDTO.setPinsMade(card.getPinsMade());
		cardDTO.setPinVerificationKeyIndex(card.getPinVerificationKeyIndex());
		cardDTO.setPinVerificationValue(card.getPinVerificationValue());
		cardDTO.setRecid(card.getRecid());
		cardDTO.setRenewalFlag(card.isRenewalFlag());
		cardDTO.setScriptStatus(card.getScriptStatus());
		cardDTO.setServiceCode(card.getServiceCode());
		cardDTO.setUserDefinedData(card.getUserDefinedData());
		cardDTO.setExpiresOn(card.getExpiresOn());
		cardDTO.setCardStatus(this.cardStatusConverter.convertRealToTransport(card.getCardStatus()));
		if(card.getAccounts()!=null&&card.getAccounts().size()>0){
			for(com.nomadsoft.cortex.domain.account.Account account : card.getAccounts()){
				Account acnt =accountConverter.convertRealToTransport(account);	
				accounts.add(acnt);			
			}
		}
		cardDTO.setAccounts(accounts);	
		
		return cardDTO;		
	}
	

	
	public Card convertRealToTransport(com.nomadsoft.cortex.domain.card.Card card,boolean linkedAccRequired){
		Card  cardDTO = convertRealToTransport(card);
		TransportList<Account>  linkedAccounts =new TransportList<Account>();
		for(Iterator<com.nomadsoft.cortex.domain.card.CardAccount> iterator=card.getCardAccSet().iterator();iterator.hasNext();)
		{
			CardAccount  cardAccount=this.cardAccountConverter.convertRealToTransport(iterator.next());
			Account linkedAccount=cardAccount.getAccount();
			for(Account cc:cardDTO.getAccountHolder().getAccounts())
			{
				if(linkedAccount.getRealId()==cc.getRealId())
				{
					cc.setLinked(true);
					linkedAccounts.add(cc);
					break;
				}			
			}
		 }		
		for(Account cc:cardDTO.getAccountHolder().getAccounts())
		{
			if(cardDTO.getAccount().getRealId()==cc.getRealId()){
				cardDTO.setAccount(cc);
				break;
			}
		}
		
        cardDTO.setLinkedAccounts(linkedAccounts);
		return cardDTO;		
	}
    
	public com.nomadsoft.cortex.domain.card.Card findReal(Id accountId, Integer version) {		
       return null;
	}	
	protected void updateRealFromTransport(com.nomadsoft.cortex.domain.card.Card card, Card cardDTO){
			
	}
	public void setBranchConverter(BranchConvertor branchConverter){
		this.branchConverter =branchConverter;
	}
	
	public void setAccountHolderConverter(AccountHolderConverter accountHolderConverter){
		this.accountHolderConverter =accountHolderConverter;
	}
	
	public void setAccountConverter(AccountConverter accountConverter){
		this.accountConverter =accountConverter;
	}
	
	public void setCardProductConverter(CardProductConverter cardProductConverter){
		this.cardProductConverter =cardProductConverter;
	}
	
	public void setCardAccountConverter(CardAccountConverter cardAccountConverter){
		this.cardAccountConverter =cardAccountConverter;
	}	
	
	public void setCardStatusConverter(CardStatusConverter cardStatusConverter){
		this.cardStatusConverter =cardStatusConverter;
	}	




}
