package com.fis.cortex.webservices.common.card.serviceparameter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "http://wscore.cortex.fis.com/ctxCommon", name = "ServPrmtrsLst")
public class ServiceParametersList{

	@XmlElement(required = true, name = "ServPrmtrs", namespace = "http://wscore.cortex.fis.com/ctxCommon")
	private ServiceParameters servPrmtrs;

	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(namespace = "http://wscore.cortex.fis.com/ctxCommon", name = "ServPrmtrs")
	public static class ServiceParameters{

		@XmlElement(required = true, name = "FeId", namespace = "http://wscore.cortex.fis.com/ctxCommon")
		private String feId;

		@XmlElement(required = true, name = "ServId", namespace = "http://wscore.cortex.fis.com/ctxCommon")
		private String servId;

		@XmlElement(required = true, name = "ServVer", namespace = "http://wscore.cortex.fis.com/ctxCommon")
		private String servVer;

		@XmlElement(required = true, name = "ApplId", namespace = "http://wscore.cortex.fis.com/ctxCommon")
		private String applId;

		public String getFeId() {
			return feId;
		}

		public void setFeId(String feId) {
			this.feId = feId;
		}

		public String getServId() {
			return servId;
		}

		public void setServId(String servId) {
			this.servId = servId;
		}

		public String getServVer() {
			return servVer;
		}

		public void setServVer(String servVer) {
			this.servVer = servVer;
		}

		public String getApplId() {
			return applId;
		}

		public void setApplId(String applId) {
			this.applId = applId;
		}

	}

	public ServiceParameters getServPrmtrs() {
		return servPrmtrs;
	}

	public void setServPrmtrs(ServiceParameters servPrmtrs) {
		this.servPrmtrs = servPrmtrs;
	}
	

}
