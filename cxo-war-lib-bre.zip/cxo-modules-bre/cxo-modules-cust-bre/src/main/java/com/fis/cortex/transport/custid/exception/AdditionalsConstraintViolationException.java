package com.fis.cortex.transport.custid.exception;

import com.metavante.cortex.transport.exceptions.BusinessException;

public class AdditionalsConstraintViolationException extends BusinessException{
	
	/**
	 * This class throws exception when duplicate data inserting in ADDITIONALS table
	 * @author schinnas
	 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/transport/custid/exception/AdditionalsConstraintViolationException.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
	 */
	private static final long serialVersionUID = 1L;

	public AdditionalsConstraintViolationException() {
		super();
		
	}

	public AdditionalsConstraintViolationException(String message) {
		super(message);
	
	}


}
