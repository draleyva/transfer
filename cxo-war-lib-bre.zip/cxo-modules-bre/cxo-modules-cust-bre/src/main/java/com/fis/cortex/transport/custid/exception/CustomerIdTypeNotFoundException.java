package com.fis.cortex.transport.custid.exception;

import com.fis.cortex.exceptions.BusinessException;
/**
 * This class is used to throw exception CustomerIdType entity not found in DB
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/transport/custid/exception/CustomerIdTypeNotFoundException.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public class CustomerIdTypeNotFoundException extends  BusinessException{

	
	private static final long serialVersionUID = 1L;

	public CustomerIdTypeNotFoundException() {
		super();
		
	}

	public CustomerIdTypeNotFoundException(String message) {
		super(message);
		
	}

}
