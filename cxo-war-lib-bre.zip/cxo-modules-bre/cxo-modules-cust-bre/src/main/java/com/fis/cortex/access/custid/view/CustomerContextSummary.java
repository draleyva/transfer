package com.fis.cortex.access.custid.view;

import java.util.Collection;

import com.fis.cortex.transport.core.dataholder.TransportObject;
import com.metavante.cortex.transport.objects.core.Institution;

/**
 * @author schinnas
 * @version $Id:
 * //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/view/CustomerContextSummary.java#1
 * $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class CustomerContextSummary extends TransportObject implements Cloneable
{
  private static final long serialVersionUID = 1L;
  private Institution institution;
  private CustIdType custIdType;
  private CustIdCode custIdCode;
  private AccountHolder accountHolder;
  private Account dlftAcc;
  private Collection<Account> selectedList;
  private boolean isIssueCardCancel;
  private boolean isAssignCardCancel;
  private String pan;

  public CustomerContextSummary(Institution institution,
          CustIdType custIdType, CustIdCode custIdCode, AccountHolder accountHolder)
  {
    this.institution = institution;
    this.custIdType = custIdType;
    this.custIdCode = custIdCode;
    this.accountHolder = accountHolder;
  }

  public CustomerContextSummary(Institution institution,
          CustIdType custIdType, CustIdCode custIdCode)
  {
    this.institution = institution;
    this.custIdType = custIdType;
    this.custIdCode = custIdCode;
  }

  public Institution getInstitution()
  {
    return institution;
  }

  public void setInstitution(Institution institution)
  {
    this.institution = institution;
  }

  public CustIdType getCustIdType()
  {
    return custIdType;
  }

  public void setCustIdType(CustIdType custIdType)
  {
    this.custIdType = custIdType;
  }

  public CustIdCode getCustIdCode()
  {
    return custIdCode;
  }

  public void setCustIdCode(CustIdCode custIdCode)
  {
    this.custIdCode = custIdCode;
  }

  public AccountHolder getAccountHolder()
  {
    return accountHolder;
  }

  public void setAccountHolder(AccountHolder accountHolder)
  {
    this.accountHolder = accountHolder;
  }

  public Account getDlftAcc()
  {
    return dlftAcc;
  }

  public void setDlftAcc(Account dlftAcc)
  {
    this.dlftAcc = dlftAcc;
  }

  public Collection<Account> getSelectedList()
  {
    return selectedList;
  }

  public void setSelectedList(Collection<Account> selectedList)
  {
    this.selectedList = selectedList;
  }

  public boolean isIssueCardCancel()
  {
    return isIssueCardCancel;
  }

  public void setIssueCardCancel(boolean isIssueCardCancel)
  {
    this.isIssueCardCancel = isIssueCardCancel;
  }

  public boolean isAssignCardCancel()
  {
    return isAssignCardCancel;
  }

  public void setAssignCardCancel(boolean isAssignCardCancel)
  {
    this.isAssignCardCancel = isAssignCardCancel;
  }

  public String getPan()
  {
    return pan;
  }

  public void setPan(String pan)
  {
    this.pan = pan;
  }
}
