package com.fis.cortex.access.custid.view;
import com.fis.cortex.transport.core.dataholder.TransportObject;
/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/view/CustIdCode.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class CustIdCode extends TransportObject implements Cloneable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long codeId;
	private long customerId;
	private CustIdType custIdType;
	private String code;

	public long getCodeId() {
		return codeId;
	}
	public void setCodeId(long id) {
		this.codeId = id;
	}
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public CustIdType getCustIdType() {
		return custIdType;
	}
	public void setCustIdType(CustIdType custIdType) {
		this.custIdType = custIdType;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
}
