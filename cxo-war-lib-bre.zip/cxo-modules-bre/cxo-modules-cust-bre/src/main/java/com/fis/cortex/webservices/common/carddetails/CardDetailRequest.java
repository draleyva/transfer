package com.fis.cortex.webservices.common.carddetails;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/cardDetailRequest", name = "CardDetailRequest")
@XmlAccessorType(XmlAccessType.FIELD)
public class CardDetailRequest {
	
	@XmlElement(required = false, name = "PAN", namespace = "http://crdbase.cortex.fis.com/cardDetailRequest")
	private String PAN;
	
	@XmlElement(required = false, name = "SeqNo", namespace = "http://crdbase.cortex.fis.com/cardDetailRequest")
	private short seqNo;
	
	@XmlElement(required = false, name = "PANAlias", namespace = "http://crdbase.cortex.fis.com/cardDetailRequest")
	private String PANAlias;
	
	@XmlElement(required = false, name = "Id", namespace = "http://crdbase.cortex.fis.com/cardDetailRequest")
	private Long id;
	
	@XmlElement(required = false, name = "ExpDate", namespace = "http://crdbase.cortex.fis.com/cardDetailRequest")
	private Date expDate;

	public String getPAN() {
		return PAN;
	}

	public void setPAN(String pAN) {
		PAN = pAN;
	}

	public short getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(short seqNo) {
		this.seqNo = seqNo;
	}

	public String getPANAlias() {
		return PANAlias;
	}

	public void setPANAlias(String pANAlias) {
		PANAlias = pANAlias;
	}

	public Date getExpDate() {
		return expDate;
	}

	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	/**
	 * 
	 */
	public CardDetailRequest() {
	}
	
}
