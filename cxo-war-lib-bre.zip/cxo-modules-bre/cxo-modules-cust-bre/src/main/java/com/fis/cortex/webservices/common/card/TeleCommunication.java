package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "Telcom")
@XmlAccessorType(XmlAccessType.FIELD)
public class TeleCommunication {
	
	@XmlElement(name = "TelType", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Integer telType;
	@XmlElement(name = "CountryPrefix", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String countryPrefix;
	@XmlElement(name = "ContactNumber", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String contactNumber;
	
	public Integer getTelType() {
		return telType;
	}
	public void setTelType(Integer telType) {
		this.telType = telType;
	}
	public String getCountryPrefix() {
		return countryPrefix;
	}
	public void setCountryPrefix(String countryPrefix) {
		this.countryPrefix = countryPrefix;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
}
