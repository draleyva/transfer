package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "DeliveryRef")
@XmlAccessorType(XmlAccessType.FIELD)
public class DeliveryReference {
	
	@XmlElement(name = "RefType", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Integer refType;
	@XmlElement(name = "Refid", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String refid;
	
	public Integer getRefType() {
		return refType;
	}
	public void setRefType(Integer refType) {
		this.refType = refType;
	}
	public String getRefid() {
		return refid;
	}
	public void setRefid(String refid) {
		this.refid = refid;
	}

}
