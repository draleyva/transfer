
package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fis.cortex.webservices.common.card.response.AbstractResponse;



/**
 * @author rmura
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType( name = "IssuerDirectivesResponse")
@XmlRootElement(name = "IssuerDirectivesResponse", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
public class GenerateCardResponse extends AbstractResponse 
{
	@XmlElement(name = "DirectiveOso", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private GenerateCardOso directiveOso;

	public GenerateCardOso getDirectiveOso() {
		return directiveOso;
	}
	public void setDirectiveOso(GenerateCardOso directiveOso) {
		this.directiveOso = directiveOso;
	}
	
}