package com.fis.cortex.access.custid.converter;

import com.fis.cortex.access.custid.view.Account;
import com.fis.cortex.access.custid.view.AccountHolder;
import com.fis.cortex.transport.core.converter.EntityTransportConverter;
import com.fis.cortex.transport.core.dataholder.TransportList;
import com.fis.cortex.transport.core.dataholder.TransportObject.Id;
import com.metavante.cortex.transport.objects.converter.CurrencyConverter;
import com.metavante.cortex.transport.objects.converter.InstitutionConverter;
import com.metavante.cortex.transport.objects.converter.BranchConvertor;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/converter/AccountConverter.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public class AccountConverter extends EntityTransportConverter<com.nomadsoft.cortex.domain.account.Account, Account>{
	
	private CurrencyConverter currencyConverter;
	private InstitutionConverter institutionConverter;
	private BranchConvertor branchConverter;
	
	public Account convertRealToTransport(com.nomadsoft.cortex.domain.account.Account acount){
		Account  acnt =  new Account();
		acnt.markConfiguredWithId(acount.getId());
		acnt.setAccountClass(acount.getAccountClass());
		acnt.setAccountType(acount.getAccountType());
		acnt.setStatus(acount.getStatus());
		acnt.setCatParams(acount.getCatParams());
		acnt.setVip(acount.getVip());
		acnt.setAccountNumber(acount.getAccountNumber());
		acnt.setCurrency(this.currencyConverter.convertRealToTransport(acount.getCurrency()));
		acnt.setInstitution(this.institutionConverter.convertRealToTransport(acount.getInstitution()));
		acnt.setAccountHolder(this.convertRealToTransport(acount.getAccountHolder()));
		acnt.setBranch(this.branchConverter.convertRealToTransport(acount.getBranch()));
		return acnt;
		
	}
	
	public void setCurrencyConverter(CurrencyConverter currencyConverter){
		this.currencyConverter =currencyConverter;
	}
	public void setInstitutionConverter(InstitutionConverter institutionConverter){
		this.institutionConverter =institutionConverter;
	}
	
	public void setBranchConverter(BranchConvertor branchConverter){
		this.branchConverter =branchConverter;
	}
	
	private AccountHolder convertRealToTransport(com.nomadsoft.cortex.domain.accountholder.AccountHolder accountHolder){
		TransportList<Account>  accountList =new TransportList<Account>();
		AccountHolder accHolder = new AccountHolder();
		accHolder.markConfiguredWithId(accountHolder.getId());
		accHolder.setAddressIndicator(accountHolder.getAddressIndicator());
		accHolder.setCollectionZone(accountHolder.getCollectionZone());
		accHolder.setDateAccepted(accountHolder.getDateAccepted());
		accHolder.setDateOfBirth(accountHolder.getDateOfBirth());
		accHolder.setEmail(accountHolder.getEmailAddress());
		accHolder.setFirstName(accountHolder.getFirstName());
		accHolder.setHomeTelephoneNumber(accountHolder.getHomeTelephoneNumber());
		accHolder.setIdNumber(accountHolder.getIdNumber());
		accHolder.setLastName(accountHolder.getLastName());
		accHolder.setMailShots(accountHolder.getMailShots());
		accHolder.setMaritalStatus(accountHolder.getMaritalStatus());
		accHolder.setMemo(accountHolder.getMemo());
		accHolder.setMobileTelephoneNumber(accountHolder.getMobileTelephoneNumber());
		accHolder.setNumberBouncedChequesPrimaryCurrency(accountHolder.getNumberBouncedChequesPrimaryCurrency());
		accHolder.setNumberBouncedChequesSecondaryCurrency(accountHolder.getNumberBouncedChequesSecondaryCurrency());
		accHolder.setPOBox(accountHolder.getPOBox());
		accHolder.setPreferredLanguage(accountHolder.getPreferredLanguage());
		accHolder.setProfessionCode(accountHolder.getProfessionCode());
		accHolder.setRefuseCheque(accountHolder.getRefuseCheque());
		accHolder.setSex(accountHolder.getSex());
		accHolder.setStatementCode(accountHolder.getStatementCode());
		accHolder.setTitle(accountHolder.getTitle());
		accHolder.setCustomerType(accountHolder.getCustomerType());
		accHolder.setUserData1(accountHolder.getUserData1());
	    accHolder.setAccounts(accountList);		
		return accHolder;
	}
	
	
	public com.nomadsoft.cortex.domain.account.Account findReal(Id accountId, Integer version) {
		return null;
	}
	
	
	protected void updateRealFromTransport(com.nomadsoft.cortex.domain.account.Account acc, Account account){
			
	}
	

}
