package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fis.cortex.webservices.common.card.request.AbstractRequest;

/**
 * @author schinnas
 *
 */
@SuppressWarnings("restriction")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType( name = "IssuerDirectivesRequest")
@XmlRootElement(name = "IssuerDirectivesRequest", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
public class GenerateCardRequest extends AbstractRequest
{
	@XmlElement(name = "DirectiveOsi", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private GenerateCardOsi directiveOsi;
	
	public GenerateCardOsi getDirectiveOsi() {
		return directiveOsi;
	}
	public void setDirectiveOsi(GenerateCardOsi directiveOsi) {
		this.directiveOsi = directiveOsi;
	}
	
}
