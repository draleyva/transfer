package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "Ident")
@XmlAccessorType(XmlAccessType.FIELD)
public class Identification {
	
	@XmlElement(name = "IdentType", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String  identificationType;
	@XmlElement(name = "IdentRef", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String IdentificationRef;
	
	public String getIdentificationType() {
		return identificationType;
	}
	public void setIdentificationType(String identificationType) {
		this.identificationType = identificationType;
	}
	public String getIdentificationRef() {
		return IdentificationRef;
	}
	public void setIdentificationRef(String identificationRef) {
		IdentificationRef = identificationRef;
	}
	
	

}
