package com.fis.cortex.access.custid.view;

import java.io.Serializable;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/view/Message.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class Message implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3982037307318565786L;
	
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCardProdDescription() {
		return cardProdDescription;
	}
	public void setCardProdDescription(String cardProdDescription) {
		this.cardProdDescription = cardProdDescription;
	}
	private String message;
	private String action;
	private String cardNumber;
	private String cardProdDescription;

}
