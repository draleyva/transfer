package com.fis.cortex.transport.custid.exception;

import com.fis.cortex.exceptions.BusinessException;

/**
 * This class is used to throw exception when webservice host throws any exceptions
 * 
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/transport/custid/exception/CortexWebServiceException.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public class CortexWebServiceException extends  BusinessException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public CortexWebServiceException() {
		super();
	}


	public CortexWebServiceException(String exception) {
		super(exception);
	}

}
