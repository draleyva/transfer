package com.fis.cortex.domain.custid;

import java.io.Serializable;


/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/domain/custid/AdditionalsId.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class AdditionalsId implements Serializable{
    private static final long serialVersionUID = -2265516757413018565L;
	
	private long primaryCard;
	private long additionalCard;
	
	public AdditionalsId(){
	  // do nothing
	}
	
	public AdditionalsId(long primaryCard,long additionalCard){
	  this.primaryCard=primaryCard;
	  this.additionalCard=additionalCard;
	}
	
	public long getPrimaryCard(){
	  return this.primaryCard;
	}
	
	public void setPrimaryCard(long primaryCard){
	  this.primaryCard=primaryCard;
	}
	
	public long getAdditionalCard(){
	  return this.additionalCard;	
	}
	
	public void setAdditionalCard(long additionalCard){
	   this.additionalCard=additionalCard;
	}
	
	
	

}
