package com.fis.cortex.access.custid.view;

import com.fis.cortex.transport.core.dataholder.TransportObject;
import com.metavante.cortex.transport.objects.core.Institution;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/view/CardProduct.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class CardProduct extends TransportObject {
	
	private static final long serialVersionUID = -5541759053337962763L;	
	private String cardProduct;
	private Institution institution;   
	private String description;

	public String getCardProduct() {
		return cardProduct;
	}
	public void setCardProduct(String cardProduct) {
		this.cardProduct = cardProduct;
	}
	public Institution getInstitution() {
		return institution;
	}
	public void setInstitution(Institution institution) {
		this.institution = institution;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
  
    

}
