package com.fis.cortex.webservices.common.card.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "http://wscore.cortex.fis.com/ctxCommonRqstHdr", name = "Sec")
public class SecurityData {
	
	@XmlElement(required = true, name = "BasicAuthen", namespace = "http://wscore.cortex.fis.com/ctxCommonRqstHdr")
	private BasicAuthentication basicAuthen;

	public BasicAuthentication getBasicAuthen() {
		return basicAuthen;
	}

	public void setBasicAuthen(BasicAuthentication basicAuthen) {
		this.basicAuthen = basicAuthen;
	}

}
