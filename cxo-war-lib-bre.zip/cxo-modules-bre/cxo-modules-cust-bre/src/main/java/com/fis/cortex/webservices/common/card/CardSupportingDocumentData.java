/**
 * 
 */
package com.fis.cortex.webservices.common.card;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;
/**
 * @author jricha
 *
 */

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "CrdSupDoc")
@XmlAccessorType(XmlAccessType.FIELD)
public class CardSupportingDocumentData {
	@XmlElement(name = "CrdSupDocAction", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private Short cardSupportingDocumentAction;
 	@XmlElement(name = "SupDocType", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private Short supportingDocumentType;
 	@XmlElement(name = "DocRef1", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private String documentReferenceOne;
 	@XmlElement(name = "DocRef2", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private String documentReferenceTwo;
 	@XmlElement(name = "CrdEffDate", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private String cardEffectiveDate;
 	@XmlElement(name = "CrdExpDate", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private String cardExpiryDate;
 	@XmlElement(name = "DocEffDate", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private String documentEffectiveDate;
 	@XmlElement(name = "DocExpDate", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
 	private String documentExpiryDate;
	@XmlElementWrapper( name = "UserDataLst", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	@XmlElement( name = "UserData", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private List<UserData> userDataList;
	
	/**
	 * @return the cardSupportingDocumentAction
	 */
	public Short getCardSupportingDocumentAction() {
		return cardSupportingDocumentAction;
	}

	/**
	 * @param cardSupportingDocumentAction the cardSupportingDocumentAction to set
	 */
	public void setCardSupportingDocumentAction(Short cardSupportingDocumentAction) {
		this.cardSupportingDocumentAction = cardSupportingDocumentAction;
	}

	/**
	 * @return the supportingDocumentType
	 */
	public Short getSupportingDocumentType() {
		return supportingDocumentType;
	}
	/**
	 * @param supportingDocumentType the supportingDocumentType to set
	 */
	public void setSupportingDocumentType(Short supportingDocumentType) {
		this.supportingDocumentType = supportingDocumentType;
	}
	/**
	 * @return the documentReferenceOne
	 */
	public String getDocumentReferenceOne() {
		return documentReferenceOne;
	}
	/**
	 * @param documentReferenceOne the documentReferenceOne to set
	 */
	public void setDocumentReferenceOne(String documentReferenceOne) {
		this.documentReferenceOne = documentReferenceOne;
	}
	/**
	 * @return the documentReferenceTwo
	 */
	public String getDocumentReferenceTwo() {
		return documentReferenceTwo;
	}
	/**
	 * @param documentReferenceTwo the documentReferenceTwo to set
	 */
	public void setDocumentReferenceTwo(String documentReferenceTwo) {
		this.documentReferenceTwo = documentReferenceTwo;
	}
	/**
	 * @return the cardEffectiveDate
	 */
	public String getCardEffectiveDate() {
		return cardEffectiveDate;
	}
	/**
	 * @param cardEffectiveDate the cardEffectiveDate to set
	 */
	public void setCardEffectiveDate(String cardEffectiveDate) {
		this.cardEffectiveDate = cardEffectiveDate;
	}
	/**
	 * @return the cardExpiryDate
	 */
	public String getCardExpiryDate() {
		return cardExpiryDate;
	}
	/**
	 * @param cardExpiryDate the cardExpiryDate to set
	 */
	public void setCardExpiryDate(String cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}
	/**
	 * @return the documentEffectiveDate
	 */
	public String getDocumentEffectiveDate() {
		return documentEffectiveDate;
	}
	/**
	 * @param documentEffectiveDate the documentEffectiveDate to set
	 */
	public void setDocumentEffectiveDate(String documentEffectiveDate) {
		this.documentEffectiveDate = documentEffectiveDate;
	}
	/**
	 * @return the documentExpiryDate
	 */
	public String getDocumentExpiryDate() {
		return documentExpiryDate;
	}
	/**
	 * @param documentExpiryDate the documentExpiryDate to set
	 */
	public void setDocumentExpiryDate(String documentExpiryDate) {
		this.documentExpiryDate = documentExpiryDate;
	}
	/**
	 * @return the userDataList
	 */
	public List<UserData> getUserDataList() {
		return userDataList;
	}
	/**
	 * @param userDataList the userDataList to set
	 */
	public void setUserDataList(List<UserData> userDataList) {
		this.userDataList = userDataList;
	}
}
