package com.fis.cortex.access.custid.view;

import com.fis.cortex.transport.core.dataholder.TransportObject;
/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/view/CardAccount.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class CardAccount extends TransportObject {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int isoCode;
	private String roleId;
	private String typeCode;
	private Card card;
	private Account account;
	
	public int getIsoCode() {
		return isoCode;
	}
	public void setIsoCode(int isoCode) {
		this.isoCode = isoCode;
	}
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	public Card getCard() {
		return card;
	}
	public void setCard(Card card) {
		this.card = card;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}


}
