package com.fis.cortex.domain.custid.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import com.nomadsoft.cortex.domain.accountholder.AccountHolder;
import com.nomadsoft.cortex.domain.branch.Branch;
import com.nomadsoft.cortex.domain.card.Card;
import com.nomadsoft.cortex.domain.card.CardAccount;
import com.nomadsoft.cortex.domain.card.CardProduct;
import com.nomadsoft.cortex.domain.cardbatch.CardBatch;
import com.nomadsoft.cortex.domain.cardbatch.CardBatchPriority;
import com.nomadsoft.cortex.domain.cardbatch.CardBatchStatus;
import com.nomadsoft.cortex.domain.cardbatch.CardBatchType;
import com.nomadsoft.cortex.domain.institution.Institution;
import com.nomadsoft.cortex.domain.msc.Msc;
import com.fis.cortex.domain.custid.BranchCardBatch;
import com.fis.cortex.domain.custid.CustIdCode;
import com.fis.cortex.domain.custid.CustIdType;
import com.fis.cortex.domain.custid.CustomerIdRepository;
import com.fis.cortex.util.Util;
import com.fis.infrastructure.persistence.hibernate.SearchTransporter;
import com.fis.infrastructure.persistence.hibernate.SearchCriteriaFactory;
import java.util.Arrays;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author schinnas
 * @version $Id:
 * //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/domain/custid/basic/HibernateCustomerIdRepository.java#1
 * $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class HibernateCustomerIdRepository extends HibernateDaoSupport implements CustomerIdRepository
{
  private static final Log LOGGER = LogFactory.getLog(HibernateCustomerIdRepository.class);

  @Autowired
  @Qualifier("cortexCustSessionFactory")
  private SessionFactory sessionFactory;

  public List<CustIdType> getIdTypes(String institutionCode)
  {
    Criteria criteria = sessionFactory.getCurrentSession().createCriteria(CustIdType.class).createCriteria("institution");
    criteria.add(Restrictions.eq("institutionCode", institutionCode));
    List<CustIdType> list = (List<CustIdType>) criteria.list();
    return list;
  }

  public CustIdCode findCustIdCodeById(String cutIdCode)
  {
    try
    {
      Criteria criteria = sessionFactory.getCurrentSession().createCriteria(CustIdCode.class);
      criteria.add(Restrictions.eq("code", cutIdCode));
      CustIdCode domainCustIdCode = (CustIdCode) criteria.uniqueResult();
      return domainCustIdCode;
    }
    catch (Exception e)
    {
      throw new RuntimeException(CustIdCode.class.getName() + " not found", e);
    }
  }

  public CustIdCode getCustIdCodeByCust(long customerId)
  {
    try
    {
      Criteria criteria = sessionFactory.getCurrentSession().createCriteria(CustIdCode.class);
      criteria.add(Restrictions.eq("customerId", customerId));
      CustIdCode domainCustIdCode = (CustIdCode) criteria.uniqueResult();
      return domainCustIdCode;
    }
    catch (Exception e)
    {
      throw new RuntimeException(CustIdCode.class.getName() + " not found", e);
    }
  }

  public CustIdCode getCustIdCode(long custIdTypeId, String custIdCode)
  {
    try
    {
      Criteria criteria = sessionFactory.getCurrentSession().createCriteria(CustIdCode.class);
      criteria.add(Restrictions.eq("code", custIdCode));
      criteria.createCriteria("custIdType", "idType");
      criteria.add(Restrictions.eq("idType.id", custIdTypeId));
      CustIdCode code = (CustIdCode) criteria.uniqueResult();
      return code;
    }
    catch (Exception e)
    {
      throw new RuntimeException(CustIdCode.class.getName() + " not found", e);
    }
  }

  public AccountHolder getAccountHolderById(long id)
  {
    return (AccountHolder) getHibernateTemplate()
            .get(AccountHolder.class, id);
  }

  public Card getCard(String pan, long instId) throws Exception
  {
    try
    {
      Criteria criteria = sessionFactory.getCurrentSession().createCriteria(Card.class, "card");
      criteria.add(Restrictions.eq("card.pan", pan));
      criteria.createCriteria("cardProduct", "cardProduct");
      criteria.add(Restrictions.eq("cardProduct.institution.id", instId));
      criteria.createCriteria("accountHolder", "accountHolder");
      criteria.createCriteria("branch", "branch");
      Card card = null;
      List<?> list = criteria.list();
      if (list != null && list.size() > 0)
      {
        card = (Card) list.get(0);
      }
      return card;
    }
    catch (Exception e)
    {
      throw new RuntimeException(CustIdCode.class.getName() + " not found", e);
    }
  }

  public void deleteCardAccount(CardAccount cardAccount)
  {
    getHibernateTemplate().delete("com.nomadsoft.cortex.domain.card.CardAccount", cardAccount);
  }

  public Object findById(long id, String className, String[] dependencies)
  {
    return findById((Object) id, className, dependencies);
  }

  public Object findById(Object id, String className, String[] dependencies)
  {
    Criteria criteria = sessionFactory.getCurrentSession().createCriteria(getInterfaceName(className));
    criteria.add(Restrictions.eq("id", id));
    for (String requiredData : dependencies)
    {
      criteria.setFetchMode(requiredData, FetchMode.SELECT);
    }
    Object result = criteria.uniqueResult();
    return result;
  }

  public String getInterfaceName(String interfaceName)
  {
    if (interfaceName.substring(0, 4).equals("com."))
    {
      return interfaceName;
    }
    return null;
  }

  public Object findAtMostOne(String className, Map<String, Object> values)
  {
    try
    {
      String searchClass = getInterfaceName(className);
      Criteria searchCriteria = sessionFactory.getCurrentSession().createCriteria(searchClass);
      Criteria countCriteria = sessionFactory.getCurrentSession().createCriteria(searchClass);
      countCriteria.setProjection(Projections.rowCount());

      SearchTransporter searchTransporter
              = new SearchTransporter(className, 12, values, new ArrayList<String>());

      SearchCriteriaFactory.populateCriteria(searchTransporter,
              Class.forName(getInterfaceImplementationName(searchClass)).newInstance(),
              searchCriteria, countCriteria);

      return searchCriteria.uniqueResult();
    }
    catch (InstantiationException e)
    {
      throw new RuntimeException(className + " not found", e);
    }
    catch (IllegalAccessException e)
    {
      throw new RuntimeException(className + " not found", e);
    }
    catch (ClassNotFoundException e)
    {
      throw new RuntimeException(className + " not found", e);
    }
  }

  /**
   * Determines the implementation class for a interface
   *
   * @param interfaceName full interface name e.g.
   * com.nomadsoft.cortex.domain.card.VirtualPan
   * @return full implementation name e.g.
   * com.nomadsoft.cortex.domain.card.basic.BasicVirtualPan
   */
  public static String getInterfaceImplementationName(String interfaceName)
  {
    int endOfPackageName = interfaceName.lastIndexOf(".");
    String interfacepackageName = interfaceName.substring(0, endOfPackageName);
    String interfaceNameWithoutPackage
            = interfaceName.substring(endOfPackageName + 1, interfaceName.length());
    StringBuffer implementationName
            = new StringBuffer().append(interfacepackageName).append(".basic.Basic")
                    .append(interfaceNameWithoutPackage);
    return implementationName.toString();
  }

  public void save(Object object, String className)
  {
    sessionFactory.getCurrentSession().save(getInterfaceName(className), object);
    //getHibernateTemplate().save(getInterfaceName(className), object);
  }

  public void update(Object object, String className)
  {
    //getHibernateTemplate().saveOrUpdate(getInterfaceName(className), object);
    sessionFactory.getCurrentSession().saveOrUpdate(getInterfaceName(className), object);
  }

  public CardBatch findByInstcodeBatchtypeCrdproductstatusandDelvaddr(Institution institution, int batchType,
          CardProduct cardProduct, CardBatchStatus batchStatus, char deliveryAddress, CardBatchPriority cardBatchPriority)
  {
    try
    {
      Criteria criteria = sessionFactory.getCurrentSession().createCriteria(CardBatch.class);
      criteria.add(Restrictions.eq("institution", institution));
      criteria.add(Restrictions.eq("batchType", CardBatchType.getCardBatchType(batchType)));
      criteria.add(Restrictions.eq("cardProduct", cardProduct));
      criteria.add(Restrictions.eq("batchStatus", batchStatus));
      criteria.add(Restrictions.eq("deliveryAddress", String.valueOf(deliveryAddress)));
      criteria.add(Restrictions.eq("priority", cardBatchPriority));
      if (criteria.list() != null && criteria.list().size() > 0)
      {
        return (CardBatch) criteria.list().get(0);
      }
    }
    catch (Exception e)
    {
      throw new RuntimeException(CardBatch.class.getName() + " not found", e);
    }
    return null;
  }

  public Msc findByTagAndIndex(String tag, short index)
  {
    try
    {
      Criteria crit = sessionFactory.getCurrentSession().createCriteria(Msc.class);
      crit.add(Restrictions.eq("id.tag", tag));
      crit.add(Restrictions.eq("id.idx", index));
      Msc msc = (Msc) crit.uniqueResult();
      return msc;
    }
    catch (Exception e)
    {
      throw new RuntimeException(Msc.class.getName() + " not found", e);
    }
  }

  public BranchCardBatch getBranchCardBatch(String branchCode, Institution institution, int batchType,
          CardProduct cardProduct, CardBatchStatus batchStatus, char deliveryAddress, CardBatchPriority cardBatchPriority)
  {
    try
    {
      Criteria criteria = sessionFactory.getCurrentSession().createCriteria(BranchCardBatch.class);
      criteria.createAlias("cardBatch", "batch");
      criteria.add(Restrictions.eq("batch.institution", institution));
      criteria.add(Restrictions.eq("batch.batchType", CardBatchType.getCardBatchType(batchType)));
      criteria.add(Restrictions.eq("batch.cardProduct", cardProduct));
      criteria.add(Restrictions.eq("batch.batchStatus", batchStatus));
      criteria.add(Restrictions.eq("batch.deliveryAddress", String.valueOf(deliveryAddress)));
      criteria.add(Restrictions.eq("batch.priority", cardBatchPriority));
      criteria.createAlias("branch", "branch");
      criteria.add(Restrictions.eq("branch.branchCode", branchCode));
      List<BranchCardBatch> list = criteria.list();
      if (!list.isEmpty())
      {
        return (BranchCardBatch) list.get(0);
      }
      return null;
    }
    catch (Exception e)
    {
      throw new RuntimeException(CardBatch.class.getName() + " not found", e);
    }

  }

  /**
   * Devuelve la cantidad de tarjetas activas 
   * Estados a considerar como cancelados: 
    - 03: Card Expired
    - 04: Card Reported Lost
    - 05: Card Reported Stolen
    - 06: Customer Closed
    - 07: Bank Cancelled
    - 08: Card used Fraudulently

    Adicionales: 
    - 10: NO_PROCURADA
    - 30: COMPROMETIDA
    - 15: DETERIORADA
    - 20: REEMPLAZADA
    - 35: RETENIDA_EN_ATM
    - 25: ERROR_EN_NOMBRE
   * asociadas a un número de cuenta.
   * @param accountNumber
   * @return 
  */
  @Override
  @Transactional(readOnly = true)
  public Long countActiveCardsByAccountNumber(String accountNumber)
  {
    try
    {
      return getHibernateTemplate().execute(session -> 
      {
        Criteria criteria = session.createCriteria(Card.class, "card");

        // Asociaciones necesarias
        criteria.createAlias("card.account", "account");
        criteria.createAlias("card.cardStatus", "status");

        // Filtro por número de cuenta
        criteria.add(Restrictions.eq("account.accountNumber", accountNumber));

        // Excluir ciertos estados
        criteria.add(Restrictions.not(Restrictions.in("status.statusCode",
            Arrays.asList("03", "04", "05", "06", "07", "08",
                    "10", "15", "20","25","30","35"))));

        // Contar los resultados
        criteria.setProjection(Projections.rowCount());

        Number result = (Number) criteria.uniqueResult();
        return result != null ? result.longValue() : 0L;
      });
    }
    catch (Exception e)
    {
      Util.logError("error countActiveCardsByAccountNumber: {}", e.getMessage());
      throw new RuntimeException(Card.class.getName() + " not found", e);
    }
  }
  
  public List<Branch> getBranchesByInstitution(Institution institution)
  {
    Criteria criteria = sessionFactory.getCurrentSession().createCriteria(Branch.class);
    criteria.add(Restrictions.eq("institution", institution));
    return (List<Branch>) criteria.list();
  }
}
