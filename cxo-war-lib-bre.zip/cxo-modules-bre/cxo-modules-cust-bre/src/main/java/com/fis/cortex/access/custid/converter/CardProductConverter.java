package com.fis.cortex.access.custid.converter;

import com.fis.cortex.access.custid.view.CardProduct;
import com.fis.cortex.transport.core.converter.EntityTransportConverter;
import com.fis.cortex.transport.core.dataholder.TransportObject.Id;
import com.metavante.cortex.transport.objects.converter.InstitutionConverter;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/converter/CardProductConverter.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public class CardProductConverter extends EntityTransportConverter<com.nomadsoft.cortex.domain.card.CardProduct, CardProduct>{
	private InstitutionConverter institutionConverter;
	public CardProduct convertRealToTransport(com.nomadsoft.cortex.domain.card.CardProduct cardProduct){
		CardProduct  cardProductDTO =  new CardProduct();
		cardProductDTO.markConfiguredWithId(cardProduct.getId());
		cardProductDTO.setCardProduct(cardProduct.getCardProduct());
		cardProductDTO.setDescription(cardProduct.getDescription());
		cardProductDTO.setInstitution(this.institutionConverter.convertRealToTransport(cardProduct.getInstitution()));
		return cardProductDTO;
	}
	
	
	public com.nomadsoft.cortex.domain.card.CardProduct findReal(Id cardId, Integer version) {		
		return null;
	}	
	
	protected void updateRealFromTransport(com.nomadsoft.cortex.domain.card.CardProduct cardProduct, CardProduct cardProductDTO){
			
	}
	public void setInstitutionConverter(InstitutionConverter institutionConverter){
		this.institutionConverter =institutionConverter;
	}

}
