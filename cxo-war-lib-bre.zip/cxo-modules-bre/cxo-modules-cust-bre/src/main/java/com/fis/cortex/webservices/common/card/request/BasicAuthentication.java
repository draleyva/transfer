package com.fis.cortex.webservices.common.card.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "http://wscore.cortex.fis.com/ctxCommonRqstHdr", name = "BasicAuthen")
public class BasicAuthentication {


	@XmlElement(required = true, name = "UsrId", namespace = "http://wscore.cortex.fis.com/ctxCommonRqstHdr")
	private String usrId;

	@XmlElement(required = true, name = "Pswrd", namespace = "http://wscore.cortex.fis.com/ctxCommonRqstHdr")
	private String pswrd;
	
	public String getUsrId() {
		return usrId;
	}

	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}

	public String getPswrd() {
		return pswrd;
	}

	public void setPswrd(String pswrd) {
		this.pswrd = pswrd;
	}

}
