package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "CrdEventData")
@XmlAccessorType(XmlAccessType.FIELD)
public class CardEventData {
	
	@XmlElement(required = false, name = "Reason", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String reason 	 ;
	
	@XmlElement(required = false, name = "EvNotes", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String eventNotes ;
	
	@XmlElement(required = false, name = "FeeCtrl", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private short feeControl 	 ;

	/**
	 * @return the reason
	 */
	public String getReason() {
		return reason;
	}

	/**
	 * @param reason the reason to set
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}

	/**
	 * @return the eventNotes
	 */
	public String getEventNotes() {
		return eventNotes;
	}

	/**
	 * @param eventNotes the eventNotes to set
	 */
	public void setEventNotes(String eventNotes) {
		this.eventNotes = eventNotes;
	}

	/**
	 * @return the feeControl
	 */
	public short getFeeControl() {
		return feeControl;
	}

	/**
	 * @param feeControl the feeControl to set
	 */
	public void setFeeControl(short feeControl) {
		this.feeControl = feeControl;
	}
	
}
