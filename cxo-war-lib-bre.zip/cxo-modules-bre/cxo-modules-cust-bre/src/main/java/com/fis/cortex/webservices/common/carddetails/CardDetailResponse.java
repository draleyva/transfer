package com.fis.cortex.webservices.common.carddetails;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/cardDetailResponse", name = "CardDetailResponse")
@XmlAccessorType(XmlAccessType.FIELD)
public class CardDetailResponse {
	
	@XmlElement(required = true, name = "InstCode", namespace = "http://crdbase.cortex.fis.com/cardDetailResponse")
	private String institutionCode;
	
	@XmlElement(required = false, name = "PAN", namespace = "http://crdbase.cortex.fis.com/cardDetailResponse")
	private String PAN;
	
	@XmlElement(required = false, name = "SeqNo", namespace = "http://crdbase.cortex.fis.com/cardDetailResponse")
	private short seqNo;
	
	@XmlElement(required = true, name = "PANDisplay", namespace = "http://crdbase.cortex.fis.com/cardDetailResponse")
	private String PANDisplay;
	
	@XmlElement(required = false, name = "PANAlias", namespace = "http://crdbase.cortex.fis.com/cardDetailResponse")
	private String PANAlias;
	
	@XmlElement(required = true, name = "Id", namespace = "http://crdbase.cortex.fis.com/cardDetailResponse")
	private Long id;
	
	@XmlElement(required = true, name = "ExpDate", namespace = "http://crdbase.cortex.fis.com/cardDetailResponse")
	private String expDate;
	
	@XmlElement(required = false, name = "OldExpDate", namespace = "http://crdbase.cortex.fis.com/cardDetailResponse")
	private String oldExpDate;

	public String getInstitutionCode() {
		return institutionCode;
	}

	public void setInstitutionCode(String institutionCode) {
		this.institutionCode = institutionCode;
	}

	public String getPAN() {
		return PAN;
	}

	public void setPAN(String pAN) {
		PAN = pAN;
	}

	public short getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(short seqNo) {
		this.seqNo = seqNo;
	}

	public String getPANDisplay() {
		return PANDisplay;
	}

	public void setPANDisplay(String pANDisplay) {
		PANDisplay = pANDisplay;
	}

	public String getPANAlias() {
		return PANAlias;
	}

	public void setPANAlias(String pANAlias) {
		PANAlias = pANAlias;
	}

	public String getExpDate() {
		return expDate;
	}

	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

	public String getOldExpDate() {
		return oldExpDate;
	}

	public void setOldExpDate(String oldExpDate) {
		this.oldExpDate = oldExpDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * 
	 */
	public CardDetailResponse() {
	}

}
