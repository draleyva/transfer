package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@SuppressWarnings("restriction")
@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives", name = "Address")
@XmlAccessorType(XmlAccessType.FIELD)
public class Address 
{
	
	@XmlElement(name = "AddType", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Integer addType;
	@XmlElement(name = "ContactType", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Integer contactType;
	@XmlElement(name = "Purpose", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Integer purpose;
	@XmlElement(name = "UpdAction", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Integer updateAction;	
	@XmlElement(name = "AddrL0", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String addressLine0;
	@XmlElement(name = "AddrL1", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String addressLine1;
	@XmlElement(name = "AddrL2", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String addressLine2;
	@XmlElement(name = "AddrL3", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String addressLine3;
	@XmlElement(name = "AddrL4", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String addressLine4;
	@XmlElement(name = "AddrL5", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String addressLine5;
	@XmlElement(name = "Directions", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String directions;
	@XmlElement(name = "City", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String city;
	@XmlElement(name = "PostCode", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String postCode;
	@XmlElement(name = "Province", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String province;
	@XmlElement(name = "Territory", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String territory;
	@XmlElement(name = "State", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String state;
	@XmlElement(name = "County", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String county;
	@XmlElement(name = "Region", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String region;
	
	@XmlElement(name = "Country", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String country;
	
	public Integer getAddType() {
		return addType;
	}
	public void setAddType(Integer addType) {
		this.addType = addType;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getAddressLine3() {
		return addressLine3;
	}
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getCounty() {
		return county;
	}
	public void setAddressLine0(String addressLine0) {
		this.addressLine0 = addressLine0;
	}
	public String getAddressLine0() {
		return addressLine0;
	}
	public Integer getContactType() {
		return contactType;
	}
	public void setContactType(Integer contactType) {
		this.contactType = contactType;
	}
	public Integer getPurpose() {
		return purpose;
	}
	public void setPurpose(Integer purpose) {
		this.purpose = purpose;
	}
	public Integer getUpdateAction() {
		return updateAction;
	}
	public void setUpdateAction(Integer updateAction) {
		this.updateAction = updateAction;
	}
	public String getAddressLine4() {
		return addressLine4;
	}
	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}
	public String getAddressLine5() {
		return addressLine5;
	}
	public void setAddressLine5(String addressLine5) {
		this.addressLine5 = addressLine5;
	}
	public String getDirections() {
		return directions;
	}
	public void setDirections(String directions) {
		this.directions = directions;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getTerritory() {
		return territory;
	}
	public void setTerritory(String territory) {
		this.territory = territory;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	
}
