package com.fis.cortex.webservices.common.card;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(namespace = "http://crdbase.cortex.fis.com/IssuerDirectives",name = "Email" )
@XmlAccessorType(XmlAccessType.FIELD)
public class Email {
	
	@XmlElement(name = "EmailType", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private Integer emailType;
	@XmlElement(name = "EAddr", namespace = "http://crdbase.cortex.fis.com/IssuerDirectives")
	private String electronicAddress ;
	
	public Integer getEmailType() {
		return emailType;
	}
	public void setEmailType(Integer emailType) {
		this.emailType = emailType;
	}
	public String getElectronicAddress() {
		return electronicAddress;
	}
	public void setElectronicAddress(String electronicAddress) {
		this.electronicAddress = electronicAddress;
	}
	
	

}
