package com.fis.cortex.access.custid.view;

import com.fis.cortex.transport.core.dataholder.TransportObject;

/**
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/access/custid/view/AccountType.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public class AccountType extends TransportObject{
	
	private static final long serialVersionUID = 1L;

	private int ISOCode;
	
	private long instId;
	private String typeCode;
	private int versionNumber;
	private String bankAccCode;
	private String description;
	
	public int getISOCode() {
		return ISOCode;
	}
	public void setISOCode(int code) {
		ISOCode = code;
	}


	public int getVersionNumber() {
		return versionNumber;
	}
	public String getBankAccCode() {
		return bankAccCode;
	}
	public void setBankAccCode(String bankAccCode) {
		this.bankAccCode = bankAccCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public long getInstId() {
		return instId;
	}
	public void setInstId(long instId) {
		this.instId = instId;
	}
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	
	

}
