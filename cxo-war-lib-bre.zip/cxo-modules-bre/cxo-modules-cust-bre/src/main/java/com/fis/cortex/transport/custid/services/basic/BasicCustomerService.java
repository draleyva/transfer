package com.fis.cortex.transport.custid.services.basic;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.lang3.StringUtils;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.TransformerException;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.WebServiceIOException;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceMessageExtractor;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import com.fis.cortex.encryption.basic.BasicPanCryptor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fis.cortex.access.custid.converter.AccountConverter;
import com.fis.cortex.access.custid.converter.AccountHolderConverter;
import com.fis.cortex.access.custid.converter.CardConverter;
import com.metavante.cortex.transport.objects.converter.BranchConvertor;
import com.fis.cortex.access.custid.view.Account;
import com.fis.cortex.access.custid.view.AccountHolder;
import com.fis.cortex.access.custid.view.Card;
import com.fis.cortex.access.custid.view.CustIdType;
import com.fis.cortex.access.custid.view.CustIdCode;
import com.fis.cortex.domain.custid.Additionals;
import com.fis.cortex.domain.custid.AdditionalsId;
import com.fis.cortex.domain.custid.BranchCardBatch;
import com.fis.cortex.domain.custid.ChargeData;
import com.fis.cortex.domain.custid.CustomerIdRepository;
import com.fis.cortex.domain.custid.basic.BasicAdditionals;
import com.fis.cortex.domain.custid.basic.BasicBranchCardBatch;
import com.fis.cortex.domain.custid.basic.BasicChargeData;
import com.fis.cortex.domain.custid.basic.BasicCustIdCode;
import com.fis.cortex.transport.custid.exception.AdditionalsConstraintViolationException;
import com.fis.cortex.transport.custid.exception.CardAccountLinkingException;
import com.fis.cortex.transport.custid.exception.CardNotFoundException;
import com.fis.cortex.transport.custid.exception.CortexWebServiceException;
import com.fis.cortex.transport.custid.exception.CustomerIdTypeNotFoundException;
import com.fis.cortex.transport.custid.exception.CustomerNotFoundException;
import com.fis.cortex.transport.custid.exception.GeneralSqlException;
import com.fis.cortex.transport.custid.services.CustomerService;
import com.fis.cortex.webservices.accountsearch.CortexAccountSearchRequest;
import com.fis.cortex.webservices.accountsearch.CortexAccountSearchResult;
import com.fis.cortex.webservices.accountsearch.CortexAccountSearchSoapIn;
import com.fis.cortex.webservices.accountsearch.CortexAccountSearchSoapOut;
import com.fis.cortex.webservices.client.CortexWebServiceTemplate;
import com.fis.cortex.webservices.client.constant.Constants;
import com.fis.cortex.webservices.common.ArrayOfAccount;
import com.fis.cortex.webservices.common.BaseRequest;
import com.fis.cortex.webservices.common.Gender;
import com.fis.cortex.webservices.common.MaritalStatus;
import com.fis.cortex.webservices.common.card.AccountDetail;
import com.fis.cortex.webservices.common.card.Address;
import com.fis.cortex.webservices.common.card.CardDetail;
import com.fis.cortex.webservices.common.card.ContactMechanism;
import com.fis.cortex.webservices.common.card.CreditDetailResponse;
import com.fis.cortex.webservices.common.card.CustomerDetail;
import com.fis.cortex.webservices.common.card.DeliveryReference;
import com.fis.cortex.webservices.common.card.Email;
import com.fis.cortex.webservices.common.card.TeleCommunication;
import com.fis.cortex.webservices.common.card.GenerateCardOsi;
import com.fis.cortex.webservices.common.card.GenerateCardOso;
import com.fis.cortex.webservices.common.card.GenerateCardRequest;
import com.fis.cortex.webservices.common.card.GenerateCardResponse;
import com.fis.cortex.webservices.common.card.request.RequestHeader;
import com.fis.cortex.webservices.common.card.serviceparameter.ServiceParametersList;
import com.fis.cortex.webservices.common.card.serviceparameter.ServiceParametersList.ServiceParameters;
import com.fis.cortex.webservices.customersearch.CortexCustomerSearchRequest;
import com.fis.cortex.webservices.customersearch.CortexCustomerSearchResult;
import com.fis.cortex.webservices.customersearch.CortexCustomerSearchSoapIn;
import com.fis.cortex.webservices.customersearch.CortexCustomerSearchSoapOut;
import com.fis.cortex.webservices.validateaccounts.CortexValidateCustomerAdditionalAccountRequest;
import com.fis.cortex.webservices.validateaccounts.CortexValidateCustomerAdditionalAccountResult;
import com.fis.cortex.webservices.validateaccounts.CortexValidateCustomerAdditionalAccountSoapIn;
import com.fis.cortex.webservices.validateaccounts.CortexValidateCustomerAdditionalAccountSoapOut;
import com.metavante.cortex.transport.objects.converter.InstitutionConverter;
import com.nomadsoft.cortex.domain.accountholder.basic.BasicAddress;
import com.nomadsoft.cortex.domain.branch.Branch;
import com.nomadsoft.cortex.domain.card.CardAccountId;
import com.nomadsoft.cortex.domain.card.CardProduct;
import com.nomadsoft.cortex.domain.card.basic.BasicCardAccount;
import com.nomadsoft.cortex.domain.cardbatch.CardBatch;
import com.nomadsoft.cortex.domain.cardbatch.CardBatchPriority;
import com.nomadsoft.cortex.domain.cardbatch.CardBatchStatus;
import com.nomadsoft.cortex.domain.cardbatch.CardBatchType;
import com.nomadsoft.cortex.domain.cardbatch.basic.BasicCardBatch;
import com.nomadsoft.cortex.domain.money.Money;
import com.nomadsoft.cortex.domain.msc.Msc;
import com.metavante.cortex.transport.objects.core.Institution;
import com.fis.cortex.domain.core.accesslog.AccessLogServiceManager;
import com.fis.cortex.util.Util;
import java.io.File;
import org.apache.wicket.protocol.http.request.WebClientInfo;

/**
 *
 * @author schinnas
 * @version $Id:
 * //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/fis/cortex/transport/custid/services/basic/BasicCustomerService.java#1
 * $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 *
 */
public class BasicCustomerService implements CustomerService
{
  private static final Log LOGGER = LogFactory.getLog(BasicCustomerService.class);
  
  private static String webserviceURL;
  private static String crdbasewebserviceURL;

  private static final String HOST_URL = "HOST_URL";
  private static final String CRDBASE_WS_URL = "cardbase_webservice";
  private static final String PREFIX = "tem";
  private static final String HOST_NS_URI = "http://tempuri.org/";
  private static final String CORTEX_CUSTOMER_SEARCH = "CortexCustomerSearch";
  private static final String CORTEX_CUST_REQUEST = "request";
  private static final String CORTEX_CUST_CHANNEL = "Channel";
  private static final String CORTEX_CUST_USER = "User";
  private static final String CORTEX_CUST_TERMINAL = "Terminal";
  private static final String CORTEX_ID_CODE = "IdCode";
  private static final String CORTEX_ID_TYPE = "IdType";
  private static final String CORTEX_CUST_DATE = "Date";
  private static final String CORTEX_ACCOUNT_SEARCH = "CortexAccountSearch";
  private static final String CORTEX_ACCOUNTS_VALIDATE = "CortexValidateCustomerAdditionalAccount";
  private static final String CORTEX_CUST_ACC_NUMBER = "AccountNumber";
  private static final String DATE_FORMAT_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSS";
  private static final String ISSUER_DIRECTIVES_SERVICE_NAME = "IssuerDirectives";

  private CustomerIdRepository customerIdRepository;
  private AccountHolderConverter accountHolderConverter;
  private CardConverter cardConverter;
  private AccountConverter accountConverter;
  private InstitutionConverter institutionConverter;
  private BranchConvertor branchConvertor;
  private CortexWebServiceTemplate wsTemplate;
  private CortexWebServiceTemplate crdbaseWsTemplate;

  private AccessLogServiceManager accessLogServiceManager;

  /*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.fis.cortex.transport.services.CoreService#getCycles(java.lang
	 * .String)
   */
  @SuppressWarnings("unchecked")
  @Override
  public List<CustIdType> getCustIdTypes(String institutionCode) throws CustomerIdTypeNotFoundException
  {
    List<CustIdType> out = new ArrayList<>();
    List<com.fis.cortex.domain.custid.CustIdType> list = customerIdRepository.getIdTypes(institutionCode);
    if (list != null && list.isEmpty())
    {
      throw new CustomerIdTypeNotFoundException("customer_id_type_not_found");
    }
    CustIdType idType = null;
    for (com.fis.cortex.domain.custid.CustIdType type : list)
    {
      idType = new CustIdType();
      idType.setCode(type.getCode());
      idType.setCustId(type.getId());
      idType.setInstId(type.getInstitution().getId());
      idType.setDescription(type.getDescription());
      out.add(idType);
    }
    return out;
  }

  public CustIdType convertCustIdType(com.fis.cortex.domain.custid.CustIdType type)
  {
    CustIdType idType = new CustIdType();
    idType.setCode(type.getCode());
    idType.setCustId(type.getId());
    idType.setInstId(type.getInstitution().getId());
    idType.setDescription(type.getDescription());
    return idType;
  }

  public CustIdCode convertCustIdCode(com.fis.cortex.domain.custid.CustIdCode code)
  {
    CustIdCode idCode = new CustIdCode();
    idCode.setCode(code.getCode());
    idCode.setCodeId(code.getId());
    idCode.setCustIdType(convertCustIdType(code.getCustIdType()));
    idCode.setCustomerId(code.getCustomerId());
    return idCode;
  }

  @Override
  public long getCustomerById(long custIdTypeId, String custIdCode) throws CustomerNotFoundException
  {
    com.fis.cortex.domain.custid.CustIdCode domainCustIdCode = customerIdRepository.getCustIdCode(custIdTypeId, custIdCode);
    if (domainCustIdCode != null)
    {
      return domainCustIdCode.getCustomerId();
    }
    else
    {
      throw new CustomerNotFoundException("agn_card_cust_not_found");
    }
  }

  public CustIdCode getCustIdCodeByCustomer(long customerId)
  {
    com.fis.cortex.domain.custid.CustIdCode domainCustIdCode = customerIdRepository.getCustIdCodeByCust(customerId);
    return domainCustIdCode != null ? convertCustIdCode(domainCustIdCode) : null;

  }

  @Override
  public CustIdCode getCustIdCode(long instId, long custIdTypeId, String custIdCode, String username) throws CortexWebServiceException
  {
    CustIdCode custIdCodeTO = null;
    CortexCustomerSearchResult result = null;

    Util.logInfo(String.format("e5706717 custIdTypeId %d custIdCode %s", custIdTypeId, custIdCode));

    try
    {      
      com.fis.cortex.domain.custid.CustIdCode domainCustIdCode = customerIdRepository.getCustIdCode(custIdTypeId, custIdCode);
      
      if (domainCustIdCode != null)
      {
        custIdCodeTO = new CustIdCode();
        custIdCodeTO.setCodeId(domainCustIdCode.getId());
        custIdCodeTO.setCustIdType(convertCustIdType(domainCustIdCode.getCustIdType()));
        custIdCodeTO.setCustomerId(domainCustIdCode.getCustomerId());
        custIdCodeTO.setCode(domainCustIdCode.getCode());
      }
      else
      {
        final CortexCustomerSearchSoapIn searchRequest = setCortexCustomerSearch(custIdCode, (int) custIdTypeId, username);
        CortexCustomerSearchSoapOut searchResponse = (CortexCustomerSearchSoapOut) wsTemplate.sendAndReceive((WebServiceMessage message) ->
        {
          SaajSoapMessage saajSoapMessage = (SaajSoapMessage) message;
          saajSoapMessage.setSoapAction("http://tempuri.org/CortexCustomerSearch");
          try
          {
            SOAPMessage soapMessage = saajSoapMessage.getSaajMessage();
            SOAPPart soapPart = soapMessage.getSOAPPart();
            SOAPEnvelope envelope = soapPart.getEnvelope();
            SOAPBody soapBody = soapMessage.getSOAPBody();
            envelope.addNamespaceDeclaration(PREFIX, HOST_NS_URI);
            soapBody.removeContents();
            Name bodyName = envelope.createName(CORTEX_CUSTOMER_SEARCH, PREFIX, HOST_NS_URI);
            SOAPBodyElement soapBodyElement = soapBody.addBodyElement(bodyName);
            Name requestName = envelope.createName(CORTEX_CUST_REQUEST, PREFIX, HOST_NS_URI);
            SOAPElement requestElement = soapBodyElement.addChildElement(requestName);
            Name channelName = envelope.createName(CORTEX_CUST_CHANNEL, PREFIX, HOST_NS_URI);
            SOAPElement channelElement = requestElement.addChildElement(channelName);
            channelElement.addTextNode(searchRequest.getRequest().getChannel());
            Name userName = envelope.createName(CORTEX_CUST_USER, PREFIX, HOST_NS_URI);
            SOAPElement userElement = requestElement.addChildElement(userName);
            userElement.addTextNode(searchRequest.getRequest().getUser());
            Name terminalName = envelope.createName(CORTEX_CUST_TERMINAL, PREFIX, HOST_NS_URI);
            SOAPElement terminalElement = requestElement.addChildElement(terminalName);
            terminalElement.addTextNode(searchRequest.getRequest().getTerminal());
            Name dateName = envelope.createName(CORTEX_CUST_DATE, PREFIX, HOST_NS_URI);
            SOAPElement dateElement = requestElement.addChildElement(dateName);
            dateElement.addTextNode(new SimpleDateFormat(DATE_FORMAT_PATTERN).format(searchRequest.getRequest().getDate()));
            Name idTypeName = envelope.createName(CORTEX_ID_TYPE, PREFIX, HOST_NS_URI);
            SOAPElement idTypeElement = requestElement.addChildElement(idTypeName);
            idTypeElement.addTextNode(String.valueOf(searchRequest.getRequest().getIdType()));
            Name idCodeName = envelope.createName(CORTEX_ID_CODE, PREFIX, HOST_NS_URI);
            SOAPElement idCodeElement = requestElement.addChildElement(idCodeName);
            idCodeElement.addTextNode(searchRequest.getRequest().getIdCode());
            soapMessage.saveChanges();
          }
          catch (SOAPException e)
          {
            e.printStackTrace();
            LOGGER.error(e.getMessage());
          }
        },
                new WebServiceMessageExtractor()
        {
          public Object extractData(WebServiceMessage response) throws IOException,
                  TransformerException
          {
            SaajSoapMessage saajSoapMessage = (SaajSoapMessage) response;
            CortexCustomerSearchSoapOut custSearchResponse = new CortexCustomerSearchSoapOut();
            CortexCustomerSearchResult searchResult = new CortexCustomerSearchResult();

            try
            {

              SOAPMessage soapMessage = saajSoapMessage.getSaajMessage();
              SOAPBody soapBody = soapMessage.getSOAPBody();
              Iterator<SOAPElement> iterator = soapBody.getChildElements();
              SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
              while (iterator.hasNext())
              {
                SOAPElement searchResponseElement = iterator.next();
                Iterator<SOAPElement> searchResponseIterator = searchResponseElement.getChildElements();
                while (searchResponseIterator.hasNext())
                {
                  SOAPElement searchResultElement = searchResponseIterator.next();
                  Iterator<SOAPElement> searchResultIterator = searchResultElement.getChildElements();
                  while (searchResultIterator.hasNext())
                  {
                    SOAPElement element = searchResultIterator.next();
                    if (element.getLocalName().equalsIgnoreCase("Title"))
                    {
                      searchResult.setTitle(element.getTextContent());
                    }
                    else if (element.getLocalName().equalsIgnoreCase("FirstName"))
                    {
                      searchResult.setFirstName(element.getTextContent());
                    }
                    else if (element.getLocalName().equalsIgnoreCase("LastName"))
                    {
                      searchResult.setLastName(element.getTextContent());
                    }
                    else if (element.getLocalName().equalsIgnoreCase("CustomerProfessionCode"))
                    {
                      searchResult.setCustomerProfessionCode(element.getTextContent() != null ? Integer.parseInt(element.getTextContent()) : 0);
                    }
                    else if (element.getLocalName().equalsIgnoreCase("Gender"))
                    {
                      searchResult.setGender(Gender.fromValue(element.getTextContent()));
                    }
                    else if (element.getLocalName().equalsIgnoreCase("MaritalStatus"))
                    {
                      searchResult.setMaritalStatus(MaritalStatus.fromValue(element.getTextContent()));
                    }
                    else if (element.getLocalName().equalsIgnoreCase("DOB"))
                    {
                      String dateStr = element.getTextContent();
                      dateStr = dateStr.substring(0, dateStr.indexOf("T"));
                      searchResult.setDOB(dateFormat.parse(dateStr));
                    }
                    else if (element.getLocalName().equalsIgnoreCase("Result"))
                    {
                      if (element.getTextContent() != null)
                      {
                        searchResult.setResult(Short.parseShort(element.getTextContent()));
                      }
                    }
                  }
                }
              }
              custSearchResponse.setCortexCustomerSearchResult(searchResult);
            }
            catch (SOAPException exp)
            {
              LOGGER.error(exp.getMessage());
            }
            catch (Exception exp)
            {
              LOGGER.error(exp.getMessage());
            }
            return custSearchResponse;
          }
        });

        if (searchResponse != null)
        {
          result = searchResponse.getCortexCustomerSearchResult();
        }
        if (searchResponse != null && result != null && result.getResult() == 0)
        {
          com.nomadsoft.cortex.domain.accountholder.AccountHolder accountHolder = createCustomer(searchResponse);
          com.nomadsoft.cortex.domain.institution.Institution institution = getInstitution(instId);
          accountHolder.setInstitution(institution);
          customerIdRepository.save(accountHolder, "com.nomadsoft.cortex.domain.accountholder.AccountHolder");
          com.fis.cortex.domain.custid.CustIdType idTypeObj = getCustIdType(custIdTypeId);
          domainCustIdCode = new BasicCustIdCode();
          domainCustIdCode.setCode(custIdCode);
          domainCustIdCode.setCustIdType(idTypeObj);
          domainCustIdCode.setCustomerId(accountHolder.getId());
          customerIdRepository.save(domainCustIdCode, "com.fis.cortex.domain.custid.CustIdCode");
          custIdCodeTO = new CustIdCode();
          custIdCodeTO.setCodeId(domainCustIdCode.getId());
          custIdCodeTO.setCustIdType(convertCustIdType(domainCustIdCode.getCustIdType()));
          custIdCodeTO.setCustomerId(domainCustIdCode.getCustomerId());
          custIdCodeTO.setCode(domainCustIdCode.getCode());
        }
        else
        {
          throw new CortexWebServiceException("customer_id_not_found");
        }
      }
    }
    catch (WebServiceIOException webserviceIOException)
    {
      LOGGER.error(webserviceIOException.getMessage());
      throw new CortexWebServiceException("webservice_connection_error");
    }
    catch (SoapFaultClientException soapFault)
    {
      LOGGER.error(soapFault.getMessage());
      throw new CortexWebServiceException("webservice_timeout_error");
    }

    return custIdCodeTO;
  }

  public CortexAccountSearchSoapOut getOfflineAccountSearchResponse(String jsonFilePath)
  {
    ObjectMapper mapper = new ObjectMapper();
    CortexAccountSearchSoapOut response = new CortexAccountSearchSoapOut();
    CortexAccountSearchResult result = new CortexAccountSearchResult();
    ArrayOfAccount accounts = new ArrayOfAccount();

    try
    {
      List<com.fis.cortex.webservices.common.Account> accountList = mapper.readValue(
          new File(jsonFilePath),
          new TypeReference<List<com.fis.cortex.webservices.common.Account>>() {}
      );
      accounts.getAccount().addAll(accountList);
    }
    catch (IOException e)
    {
      Util.logError("Error reading JSON file: " + e.getMessage());
    }

    result.setAccounts(accounts);
    response.setCortexAccountSearchResult(result);
    
    return response;
  }

  public void getAccountsTest(long instId, long customerId, long custTypeId, String custIdCode, String user) throws CortexWebServiceException
  {
    com.nomadsoft.cortex.domain.accountholder.AccountHolder accountHolder = null;
    ArrayOfAccount arrayOfAccount = null;
    com.nomadsoft.cortex.domain.institution.Institution institution = null;
    List<com.fis.cortex.webservices.common.Account> accountsList = null;
    CortexAccountSearchResult result = null;
    Map<String, Object> branchSearchCriteria = new HashMap<>();
    Map<String, Object> accountSearchCriteria = new HashMap<>();
    Map<String, Object> currencySearchCriteria = new HashMap<>();
    String accountType = null;
    
    try
    {
      final CortexAccountSearchSoapIn accountSearchRequest = setCortexAccountSearch(custIdCode, (int) custTypeId, user);
      CortexAccountSearchSoapOut response = getOfflineAccountSearchResponse("C:\\FISserver\\WLS\\user_projects\\domains\\ctx42bre\\fis\\BRE\\data\\accounts.json");
      
      if (response != null)
      {
        result = response.getCortexAccountSearchResult();
      }
      
      if (response != null && result != null)
      {
        arrayOfAccount = result.getAccounts();
        accountsList = arrayOfAccount.getAccount();
        institution = getInstitution(instId);
        accountHolder = getAccountHolderDetails(customerId);
        for (com.fis.cortex.webservices.common.Account hostAccount : accountsList)
        {

          if (hostAccount.getAvailableBalance() == null)
          {
            throw new CortexWebServiceException("no_avl_balance_found");
          }
          branchSearchCriteria.put("institution.id", instId);
          branchSearchCriteria.put("branchCode", hostAccount.getBranchCode());
          com.nomadsoft.cortex.domain.branch.Branch branchDomain = getBranch(branchSearchCriteria);
          if (branchDomain != null && branchDomain.getId() > 0)
          {
            currencySearchCriteria.put("id", String.valueOf(hostAccount.getAccountCurrency()));
            com.nomadsoft.cortex.domain.money.Currency currencyDomain = getCurrency(currencySearchCriteria);
            accountSearchCriteria.put("institution.id", instId);
            accountSearchCriteria.put("accountNumber", hostAccount.getAccountNumber() != null ? hostAccount.getAccountNumber() : " ");
            accountSearchCriteria.put("currency.id", String.valueOf(hostAccount.getAccountCurrency()));
            com.nomadsoft.cortex.domain.account.Account accountDomain = getAccount(accountSearchCriteria);
            if (accountDomain == null)
            {
              com.nomadsoft.cortex.domain.account.Account account = new com.nomadsoft.cortex.domain.account.basic.BasicAccount();
              account.setAccountNumber(hostAccount.getAccountNumber() != null ? hostAccount.getAccountNumber() : " ");
              account.setInstitution(institution);
              account.setBranch(branchDomain);
              account.setCurrency(currencyDomain);
              if (hostAccount.getAccountType() != null)
              {
                accountType = hostAccount.getAccountType().substring(0, 2);
                account.setAccountType(accountType);
              }
              else
              {
                account.setAccountType("20");
              }
              if (hostAccount.getAccountStatus() != null)
              {
                account.setStatus(hostAccount.getAccountStatus());
              }
              else
              {
                account.setStatus("00");
              }
              account.setVip('0');
              Money availableBalanceMoney = new Money(new BigDecimal(0), currencyDomain);
              Money amtMoney = new Money(new BigDecimal(0), currencyDomain);
              account.setAmountBlocked(amtMoney);
              account.setAvailableBalance(availableBalanceMoney);
              account.setUnclearedBalance(amtMoney);
              account.setClearedBalance(amtMoney);
              account.setCreditLimit(amtMoney);
              account.setAvlbalUnsent(amtMoney);
              account.setBlkamtUnsent(amtMoney);
              account.setPreauthBlk(amtMoney);
              account.setPreauthUnclr(amtMoney);
              account.setPreauthExpUnclr(amtMoney);
              account.setPreauthExpBlk(amtMoney);
              account.setCatParams(" ");
              account.setAccountHolder(accountHolder);
              account.setAccountClass((short) 0);
              customerIdRepository.save(account, "com.nomadsoft.cortex.domain.account.Account");
            }
          }
          else
          {
            throw new CortexWebServiceException("not_valid_branch");
          }

        }
      }
      else
      {
        throw new CortexWebServiceException("no_accounts_found");
      }
    }
    catch (WebServiceIOException webserviceIOException)
    {
      LOGGER.error(webserviceIOException.getMessage());
      throw new CortexWebServiceException("webservice_connection_error");
    }
    catch (SoapFaultClientException soapFault)
    {
      LOGGER.error(soapFault.getMessage());
      throw new CortexWebServiceException("webservice_timeout_error");
    }

  }

  @Override
  public void getAccounts(long instId, long customerId, long custTypeId, String custIdCode, String user) throws CortexWebServiceException
  {
    com.nomadsoft.cortex.domain.accountholder.AccountHolder accountHolder = null;
    ArrayOfAccount arrayOfAccount = null;
    com.nomadsoft.cortex.domain.institution.Institution institution = null;
    List<com.fis.cortex.webservices.common.Account> accountsList = null;
    CortexAccountSearchResult result = null;
    Map<String, Object> branchSearchCriteria = new HashMap<>();
    Map<String, Object> accountSearchCriteria = new HashMap<>();
    Map<String, Object> currencySearchCriteria = new HashMap<>();
    String accountType = null;
    try
    {
      final CortexAccountSearchSoapIn accountSearchRequest = setCortexAccountSearch(custIdCode, (int) custTypeId, user);
      CortexAccountSearchSoapOut response = (CortexAccountSearchSoapOut) wsTemplate.sendAndReceive((WebServiceMessage message) ->
      {
        SaajSoapMessage saajSoapMessage = (SaajSoapMessage) message;
        saajSoapMessage.setSoapAction("http://tempuri.org/CortexAccountSearch");
        try
        {
          SOAPMessage soapMessage = saajSoapMessage.getSaajMessage();
          SOAPPart soapPart = soapMessage.getSOAPPart();
          SOAPEnvelope envelope = soapPart.getEnvelope();
          SOAPBody soapBody = soapMessage.getSOAPBody();
          envelope.addNamespaceDeclaration(PREFIX, HOST_NS_URI);
          soapBody.removeContents();
          Name bodyName = envelope.createName(CORTEX_ACCOUNT_SEARCH, PREFIX, HOST_NS_URI);
          SOAPBodyElement soapBodyElement = soapBody.addBodyElement(bodyName);
          Name requestName = envelope.createName(CORTEX_CUST_REQUEST, PREFIX, HOST_NS_URI);
          SOAPElement requestElement = soapBodyElement.addChildElement(requestName);
          Name channelName = envelope.createName(CORTEX_CUST_CHANNEL, PREFIX, HOST_NS_URI);
          SOAPElement channelElement = requestElement.addChildElement(channelName);
          channelElement.addTextNode(accountSearchRequest.getRequest().getChannel());
          Name userName = envelope.createName(CORTEX_CUST_USER, PREFIX, HOST_NS_URI);
          SOAPElement userElement = requestElement.addChildElement(userName);
          userElement.addTextNode(accountSearchRequest.getRequest().getUser());
          Name terminalName = envelope.createName(CORTEX_CUST_TERMINAL, PREFIX, HOST_NS_URI);
          SOAPElement terminalElement = requestElement.addChildElement(terminalName);
          terminalElement.addTextNode(accountSearchRequest.getRequest().getTerminal());
          Name dateName = envelope.createName(CORTEX_CUST_DATE, PREFIX, HOST_NS_URI);
          SOAPElement dateElement = requestElement.addChildElement(dateName);
          dateElement.addTextNode(new SimpleDateFormat(DATE_FORMAT_PATTERN).format(accountSearchRequest.getRequest().getDate()));
          Name idTypeName = envelope.createName(CORTEX_ID_TYPE, PREFIX, HOST_NS_URI);
          SOAPElement idTypeElement = requestElement.addChildElement(idTypeName);
          idTypeElement.addTextNode(String.valueOf(accountSearchRequest.getRequest().getIdType()));
          Name idCodeName = envelope.createName(CORTEX_ID_CODE, PREFIX, HOST_NS_URI);
          SOAPElement idCodeElement = requestElement.addChildElement(idCodeName);
          idCodeElement.addTextNode(accountSearchRequest.getRequest().getIdCode());
          soapMessage.saveChanges();
          
        }
        catch (SOAPException e)
        {
          LOGGER.error(e.getMessage());
        }
      }, new WebServiceMessageExtractor()
      {

        public Object extractData(WebServiceMessage response) throws IOException,
                TransformerException
        {
          SaajSoapMessage saajSoapMessage = (SaajSoapMessage) response;
          CortexAccountSearchSoapOut accSearchResponse = new CortexAccountSearchSoapOut();
          CortexAccountSearchResult accSearchResult = new CortexAccountSearchResult();
          ArrayOfAccount accounts = new ArrayOfAccount();

          try
          {
            SOAPMessage soapMessage = saajSoapMessage.getSaajMessage();
            SOAPBody soapBody = soapMessage.getSOAPBody();
            Iterator<SOAPElement> iterator = soapBody.getChildElements();
            while (iterator.hasNext())
            {
              SOAPElement searchResponseElement = iterator.next();
              Iterator<SOAPElement> searchResponseIterator = searchResponseElement.getChildElements();
              while (searchResponseIterator.hasNext())
              {
                SOAPElement searchResultElement = searchResponseIterator.next();
                Iterator<SOAPElement> searchResultIterator = searchResultElement.getChildElements();
                while (searchResultIterator.hasNext())
                {
                  SOAPElement accountsElement = searchResultIterator.next();
                  Iterator accountsIterator = accountsElement.getChildElements();
                  while (accountsIterator.hasNext())
                  {
                    com.fis.cortex.webservices.common.Account account = new com.fis.cortex.webservices.common.Account();
                    SOAPElement accElement = null;
                    Object obj = accountsIterator.next();
                    if (obj instanceof SOAPElement)
                    {
                      accElement = (SOAPElement) obj;
                    }
                    else
                    {
                      continue;
                    }
                    Iterator<SOAPElement> elementIterator = accElement.getChildElements();
                    while (elementIterator.hasNext())
                    {
                      SOAPElement element = elementIterator.next();
                      if (element.getLocalName().equalsIgnoreCase("AccountType"))
                      {
                        account.setAccountType(element.getTextContent());
                      }
                      else if (element.getLocalName().equalsIgnoreCase("AccountNumber"))
                      {
                        account.setAccountNumber(element.getTextContent());
                      }
                      else if (element.getLocalName().equalsIgnoreCase("AccountCurrency"))
                      {
                        account.setAccountCurrency(element.getTextContent() != null ? Integer.parseInt(element.getTextContent()) : 0);
                      }
                      else if (element.getLocalName().equalsIgnoreCase("BranchCode"))
                      {
                        account.setBranchCode(element.getTextContent());
                      }
                      else if (element.getLocalName().equalsIgnoreCase("AccountStatus"))
                      {
                        account.setAccountStatus(element.getTextContent());
                      }
                      else if (element.getLocalName().equalsIgnoreCase("AvailableBalance"))
                      {
                        if (element.getTextContent() != null)
                        {
                          account.setAvailableBalance(new BigDecimal(element.getTextContent()));
                        }
                      }
                    }
                    accounts.getAccount().add(account);
                  }
                }
              }
            }

          }
          catch (SOAPException exp)
          {
            LOGGER.error(exp.getMessage());
          }
          catch (Exception exp)
          {
            LOGGER.error(exp.getMessage());
          }
          accSearchResult.setAccounts(accounts);
          accSearchResponse.setCortexAccountSearchResult(accSearchResult);
          return accSearchResponse;
        }
      });
      
      if (response != null)
      {
        result = response.getCortexAccountSearchResult();
      }
      if (response != null && result != null)
      {
        arrayOfAccount = result.getAccounts();
        accountsList = arrayOfAccount.getAccount();
        institution = getInstitution(instId);
        accountHolder = getAccountHolderDetails(customerId);
        
        for (com.fis.cortex.webservices.common.Account hostAccount : accountsList)
        {
          if (hostAccount.getAvailableBalance() == null)
          {
            throw new CortexWebServiceException("no_avl_balance_found");
          }
          branchSearchCriteria.put("institution.id", instId);
          branchSearchCriteria.put("branchCode", hostAccount.getBranchCode());
          com.nomadsoft.cortex.domain.branch.Branch branchDomain = getBranch(branchSearchCriteria);
          if (branchDomain != null && branchDomain.getId() > 0)
          {
            currencySearchCriteria.put("id", String.valueOf(hostAccount.getAccountCurrency()));
            com.nomadsoft.cortex.domain.money.Currency currencyDomain = getCurrency(currencySearchCriteria);
            accountSearchCriteria.put("institution.id", instId);
            accountSearchCriteria.put("accountNumber", hostAccount.getAccountNumber() != null ? hostAccount.getAccountNumber() : " ");
            accountSearchCriteria.put("currency.id", String.valueOf(hostAccount.getAccountCurrency()));
            com.nomadsoft.cortex.domain.account.Account accountDomain = getAccount(accountSearchCriteria);
            if (accountDomain == null)
            {
              com.nomadsoft.cortex.domain.account.Account account = new com.nomadsoft.cortex.domain.account.basic.BasicAccount();
              account.setAccountNumber(hostAccount.getAccountNumber() != null ? hostAccount.getAccountNumber() : " ");
              account.setInstitution(institution);
              account.setBranch(branchDomain);
              account.setCurrency(currencyDomain);
              if (hostAccount.getAccountType() != null)
              {
                accountType = hostAccount.getAccountType().substring(0, 2);
                account.setAccountType(accountType);
              }
              else
              {
                account.setAccountType("20");
              }
              if (hostAccount.getAccountStatus() != null)
              {
                account.setStatus(hostAccount.getAccountStatus());
              }
              else
              {
                account.setStatus("00");
              }
              account.setVip('0');
              Money availableBalanceMoney = new Money(new BigDecimal(0), currencyDomain);
              Money amtMoney = new Money(new BigDecimal(0), currencyDomain);
              account.setAmountBlocked(amtMoney);
              account.setAvailableBalance(availableBalanceMoney);
              account.setUnclearedBalance(amtMoney);
              account.setClearedBalance(amtMoney);
              account.setCreditLimit(amtMoney);
              account.setAvlbalUnsent(amtMoney);
              account.setBlkamtUnsent(amtMoney);
              account.setPreauthBlk(amtMoney);
              account.setPreauthUnclr(amtMoney);
              account.setPreauthExpUnclr(amtMoney);
              account.setPreauthExpBlk(amtMoney);
              account.setCatParams(" ");
              account.setAccountHolder(accountHolder);
              account.setAccountClass((short) 0);
              customerIdRepository.save(account, "com.nomadsoft.cortex.domain.account.Account");
            }
          }
          else
          {
            throw new CortexWebServiceException("not_valid_branch");
          }
        }
      }
      else
      {
        throw new CortexWebServiceException("no_accounts_found");
      }
    }
    catch (WebServiceIOException webserviceIOException)
    {
      LOGGER.error(webserviceIOException.getMessage());
      throw new CortexWebServiceException("webservice_connection_error");
    }
    catch (SoapFaultClientException soapFault)
    {
      LOGGER.error(soapFault.getMessage());
      throw new CortexWebServiceException("webservice_timeout_error");
    }
  }

  @Override
  public com.nomadsoft.cortex.domain.account.Account getAdditionalAccounts(long instId, String accountNumber, String custIdCode, long custIdType, String user) throws CortexWebServiceException
  {
    CortexValidateCustomerAdditionalAccountResult result = null;
    Map<String, Object> branchSearchCriteria = new HashMap<>();
    Map<String, Object> currencySearchCriteria = new HashMap<>();
    Map<String, Object> accountSearchCriteria = new HashMap<>();
    com.nomadsoft.cortex.domain.institution.Institution institution = null;
    com.nomadsoft.cortex.domain.accountholder.AccountHolder accountHolder = null;
    String accountType = null;
    com.nomadsoft.cortex.domain.account.Account account = null;
    try
    {

      final CortexValidateCustomerAdditionalAccountSoapIn validateAdditionalAccount = setCortexValidateCustomerAdditionalAccount(accountNumber, custIdCode, custIdType, user);
      CortexValidateCustomerAdditionalAccountSoapOut response = (CortexValidateCustomerAdditionalAccountSoapOut) wsTemplate.sendAndReceive(new WebServiceMessageCallback()
      {
        public void doWithMessage(WebServiceMessage message) throws IOException,
                TransformerException
        {
          SaajSoapMessage saajSoapMessage = (SaajSoapMessage) message;
          saajSoapMessage.setSoapAction("http://tempuri.org/CortexValidateCustomerAdditionalAccount");
          try
          {
            SOAPMessage soapMessage = saajSoapMessage.getSaajMessage();
            SOAPPart soapPart = soapMessage.getSOAPPart();
            SOAPEnvelope envelope = soapPart.getEnvelope();
            SOAPBody soapBody = soapMessage.getSOAPBody();
            envelope.addNamespaceDeclaration(PREFIX, HOST_NS_URI);
            soapBody.removeContents();
            Name bodyName = envelope.createName(CORTEX_ACCOUNTS_VALIDATE, PREFIX, HOST_NS_URI);
            SOAPBodyElement soapBodyElement = soapBody.addBodyElement(bodyName);
            Name requestName = envelope.createName(CORTEX_CUST_REQUEST, PREFIX, HOST_NS_URI);
            SOAPElement requestElement = soapBodyElement.addChildElement(requestName);
            Name channelName = envelope.createName(CORTEX_CUST_CHANNEL, PREFIX, HOST_NS_URI);
            SOAPElement channelElement = requestElement.addChildElement(channelName);
            channelElement.addTextNode(validateAdditionalAccount.getRequest().getChannel());
            Name userName = envelope.createName(CORTEX_CUST_USER, PREFIX, HOST_NS_URI);
            SOAPElement userElement = requestElement.addChildElement(userName);
            userElement.addTextNode(validateAdditionalAccount.getRequest().getUser());
            Name terminalName = envelope.createName(CORTEX_CUST_TERMINAL, PREFIX, HOST_NS_URI);
            SOAPElement terminalElement = requestElement.addChildElement(terminalName);
            terminalElement.addTextNode(validateAdditionalAccount.getRequest().getTerminal());
            Name dateName = envelope.createName(CORTEX_CUST_DATE, PREFIX, HOST_NS_URI);
            SOAPElement dateElement = requestElement.addChildElement(dateName);
            dateElement.addTextNode(new SimpleDateFormat(DATE_FORMAT_PATTERN).format(validateAdditionalAccount.getRequest().getDate()));
            Name idTypeName = envelope.createName(CORTEX_ID_TYPE, PREFIX, HOST_NS_URI);
            SOAPElement idTypeElement = requestElement.addChildElement(idTypeName);
            idTypeElement.addTextNode(String.valueOf(validateAdditionalAccount.getRequest().getIdType()));
            Name idCodeName = envelope.createName(CORTEX_ID_CODE, PREFIX, HOST_NS_URI);
            SOAPElement idCodeElement = requestElement.addChildElement(idCodeName);
            idCodeElement.addTextNode(String.valueOf(validateAdditionalAccount.getRequest().getIdCode()));
            Name accNumberName = envelope.createName(CORTEX_CUST_ACC_NUMBER, PREFIX, HOST_NS_URI);
            SOAPElement accNumberElement = requestElement.addChildElement(accNumberName);
            accNumberElement.addTextNode(validateAdditionalAccount.getRequest().getAccountNumber());
            soapMessage.saveChanges();
          }
          catch (SOAPException e)
          {
            LOGGER.error(e.getMessage());
          }

        }
      }, new WebServiceMessageExtractor()
      {

        public Object extractData(WebServiceMessage message) throws IOException,
                TransformerException
        {
          SaajSoapMessage saajSoapMessage = (SaajSoapMessage) message;
          CortexValidateCustomerAdditionalAccountSoapOut accValidateResponse = new CortexValidateCustomerAdditionalAccountSoapOut();
          CortexValidateCustomerAdditionalAccountResult accValidateResult = new CortexValidateCustomerAdditionalAccountResult();

          try
          {
            SOAPMessage soapMessage = saajSoapMessage.getSaajMessage();
            SOAPBody soapBody = soapMessage.getSOAPBody();
            Iterator<SOAPElement> iterator = soapBody.getChildElements();
            while (iterator.hasNext())
            {
              SOAPElement searchResponseElement = iterator.next();
              Iterator<SOAPElement> searchResponseIterator = searchResponseElement.getChildElements();
              while (searchResponseIterator.hasNext())
              {
                SOAPElement searchResultElement = searchResponseIterator.next();
                Iterator<SOAPElement> searchResultIterator = searchResultElement.getChildElements();
                while (searchResultIterator.hasNext())
                {
                  SOAPElement element = searchResultIterator.next();
                  if (element.getLocalName().equalsIgnoreCase("Date"))
                  {
                    accValidateResult.setDate(new SimpleDateFormat(DATE_FORMAT_PATTERN).parse(element.getTextContent()));
                  }
                  else if (element.getLocalName().equalsIgnoreCase("AccountType"))
                  {
                    accValidateResult.setAccountType(element.getTextContent());
                  }
                  else if (element.getLocalName().equalsIgnoreCase("AccountCurrency"))
                  {
                    accValidateResult.setAccountCurrency(element.getTextContent() != null ? Integer.parseInt(element.getTextContent()) : 0);
                  }
                  else if (element.getLocalName().equalsIgnoreCase("BranchCode"))
                  {
                    accValidateResult.setBranchCode(element.getTextContent());
                  }
                  else if (element.getLocalName().equalsIgnoreCase("AccountStatus"))
                  {
                    accValidateResult.setAccountStatus(element.getTextContent());
                  }
                  else if (element.getLocalName().equalsIgnoreCase("AvailableBalance"))
                  {
                    if (element.getTextContent() != null)
                    {
                      accValidateResult.setAvailableBalance(new BigDecimal(element.getTextContent()));
                    }
                  }
                  else if (element.getLocalName().equalsIgnoreCase("Result"))
                  {
                    if (element.getTextContent() != null)
                    {
                      accValidateResult.setResult(Short.parseShort(element.getTextContent()));
                    }
                  }

                }
              }
            }

          }
          catch (SOAPException exp)
          {
            LOGGER.error(exp.getMessage());
          }
          catch (Exception exp)
          {
            LOGGER.error(exp.getMessage());
          }
          accValidateResponse.setCortexValidateCustomerAdditionalAccountResult(accValidateResult);
          return accValidateResponse;
        }
      });
      if (response != null)
      {
        result = response.getCortexValidateCustomerAdditionalAccountResult();
      }

      if (result != null && result.getResult() == 0)
      {

        CustIdCode custIdCodeDTO = getCustIdCode(instId, (long) custIdType, custIdCode, user);
        if (result.getAvailableBalance() == null)
        {
          throw new CortexWebServiceException("no_avl_balance_found");
        }
        branchSearchCriteria.put("institution.id", instId);
        branchSearchCriteria.put("branchCode", result.getBranchCode());
        com.nomadsoft.cortex.domain.branch.Branch branchDomain = getBranch(branchSearchCriteria);
        if (branchDomain == null)
        {
          throw new CortexWebServiceException("not_valid_branch");
        }
        currencySearchCriteria.put("id", String.valueOf(result.getAccountCurrency()));
        com.nomadsoft.cortex.domain.money.Currency currencyDomain = getCurrency(currencySearchCriteria);
        accountSearchCriteria.put("institution.id", instId);
        accountSearchCriteria.put("accountNumber", accountNumber);
        accountSearchCriteria.put("currency.id", String.valueOf(result.getAccountCurrency()));
        com.nomadsoft.cortex.domain.account.Account accountDomain = getAccount(accountSearchCriteria);
        accountHolder = getAccountHolderDetails(custIdCodeDTO.getCustomerId());
        institution = getInstitution(instId);
        if (accountDomain == null)
        {
          account = new com.nomadsoft.cortex.domain.account.basic.BasicAccount();
          account.setAccountNumber(accountNumber);
          account.setInstitution(institution);
          account.setBranch(branchDomain);
          account.setCurrency(currencyDomain);
          if (result.getAccountType() != null)
          {
            accountType = result.getAccountType().substring(0, 2);
            account.setAccountType(accountType);
          }
          else
          {
            account.setAccountType("20");
          }
          if (result.getAccountStatus() != null)
          {
            account.setStatus(result.getAccountStatus());
          }
          else
          {
            account.setStatus("00");
          }
          account.setVip('0');
          Money availableBalanceMoney = new Money(result.getAvailableBalance(), currencyDomain);
          Money amtMoney = new Money(new BigDecimal(0), currencyDomain);
          account.setAmountBlocked(amtMoney);
          account.setAvailableBalance(availableBalanceMoney);
          account.setUnclearedBalance(amtMoney);
          account.setClearedBalance(amtMoney);
          account.setCreditLimit(amtMoney);
          account.setAvlbalUnsent(amtMoney);
          account.setBlkamtUnsent(amtMoney);
          account.setPreauthBlk(amtMoney);
          account.setPreauthUnclr(amtMoney);
          account.setPreauthExpUnclr(amtMoney);
          account.setPreauthExpBlk(amtMoney);
          account.setCatParams(" ");
          account.setAccountHolder(accountHolder);
          account.setAccountClass((short) 0);
        }
        else if (accountDomain.getAccountHolder().getId() == accountHolder.getId())
        {
          account = accountDomain;
        }

      }
      else
      {
        throw new CortexWebServiceException("no_accounts_found");
      }
    }
    catch (WebServiceIOException webserviceIOException)
    {
      LOGGER.error(webserviceIOException.getMessage());
      throw new CortexWebServiceException("webservice_connection_error");
    }
    catch (SoapFaultClientException soapFault)
    {
      LOGGER.error(soapFault.getMessage());
      throw new CortexWebServiceException("webservice_timeout_error");
    }
    catch (CortexWebServiceException cortexExp)
    {
      LOGGER.error(cortexExp.getMessage());
      throw cortexExp;
    }
    return account;
  }

  public Account getAccount(com.nomadsoft.cortex.domain.account.Account accountDomain)
  {
    return accountConverter.convertRealToTransport(accountDomain);
  }

  public void saveAdditionalAccount(com.nomadsoft.cortex.domain.account.Account account)
  {
    Map<String, Object> accountSearchCriteria = new HashMap<String, Object>();
    accountSearchCriteria.put("institution.id", account.getInstitution().getId());
    accountSearchCriteria.put("accountNumber", account.getAccountNumber());
    accountSearchCriteria.put("currency.id", account.getCurrency().getId());
    com.nomadsoft.cortex.domain.account.Account accountDomain = getAccount(accountSearchCriteria);
    if (account != null && accountDomain == null)
    {
      customerIdRepository.save(account, "com.nomadsoft.cortex.domain.account.Account");
    }

  }

  public AccountHolder getAccountHolder(long customerId) throws CustomerNotFoundException
  {
    AccountHolder accountHolderTO = null;
    com.nomadsoft.cortex.domain.accountholder.AccountHolder accountHolder = null;
    if (customerId > 0)
    {
      accountHolder = customerIdRepository.getAccountHolderById(customerId);
      if (accountHolder == null)
      {
        throw new CustomerNotFoundException("customer_not_found");
      }
      accountHolderTO = accountHolderConverter.convertRealToTransport(accountHolder);
    }
    return accountHolderTO;
  }

  public Card getCard(String panNumber, long instId) throws CardNotFoundException
  {
    Card cardDTO = null;
    com.nomadsoft.cortex.domain.card.Card card = null;
    try
    {
      card = customerIdRepository.getCard(panNumber, instId);
    }
    catch (Exception exp)
    {
      LOGGER.error("Error while fetching card entity " + exp.getMessage());
      throw new CardNotFoundException("card_not_found");
    }
    if (card != null)
    {
      cardDTO = cardConverter.convertRealToTransport(card);
    }
    else
    {
      throw new CardNotFoundException("card_not_found");
    }

    return cardDTO;
  }

  public Institution getInstitution(String instId)
  {
    Institution institutionDTO = null;
    com.nomadsoft.cortex.domain.institution.Institution institution = (com.nomadsoft.cortex.domain.institution.Institution) customerIdRepository.findById(Long.parseLong(instId), com.nomadsoft.cortex.domain.institution.Institution.class.getCanonicalName(), new String[0]);
    if (institution != null)
    {
      institutionDTO = institutionConverter.convertRealToTransport(institution);
    }
    return institutionDTO;
  }

  public Card getLinkedAccountsForCard(String panNumber, long instId) throws CardNotFoundException, GeneralSqlException
  {
    Card cardDTO = null;
    try
    {
      com.nomadsoft.cortex.domain.card.Card card = customerIdRepository.getCard(panNumber, instId);
      if (card == null)
      {
        throw new CardNotFoundException("card_not_found");
      }
      else if (card != null)
      {
        cardDTO = cardConverter.convertRealToTransport(card, true);
      }
    }
    catch (org.hibernate.exception.GenericJDBCException sqlExp)
    {
      LOGGER.error(sqlExp.getMessage());
      throw new GeneralSqlException("amend_acc_sql_exception");
    }
    catch (Exception exp)
    {
      LOGGER.error(exp.getMessage());
      throw new GeneralSqlException("amend_acc_sql_exception");
    }
    return cardDTO;
  }

  public void updateCardAccountLinks(Card cardTransferObject, List<Account> linkAccounts) throws CardAccountLinkingException
  {
    try
    {
      com.nomadsoft.cortex.domain.card.Card card = (com.nomadsoft.cortex.domain.card.Card) customerIdRepository.findById(cardTransferObject.getRealId(), com.nomadsoft.cortex.domain.card.Card.class.getCanonicalName(), new String[0]);
      //set default account to the card
      com.nomadsoft.cortex.domain.account.Account accountDomain = (com.nomadsoft.cortex.domain.account.Account) customerIdRepository.findById(cardTransferObject.getAccount().getRealId(), com.nomadsoft.cortex.domain.account.Account.class.getCanonicalName(), new String[0]);
      card.setAccount(accountDomain);
      Map<String, Object> values = new HashMap<String, Object>();

      for (Account accountDto : linkAccounts)
      {
        com.nomadsoft.cortex.domain.account.Account acctDomain = (com.nomadsoft.cortex.domain.account.Account) customerIdRepository.findById(accountDto.getRealId(), com.nomadsoft.cortex.domain.account.Account.class.getCanonicalName(), new String[0]);
        com.nomadsoft.cortex.domain.card.CardAccount cardAccount = null;
        values.clear();
        // already linked
        if (accountDto.isLinked() && accountDto.isSelected())
        {
          values.put("id.card", card);
          values.put("id.account", acctDomain);
          cardAccount = (com.nomadsoft.cortex.domain.card.CardAccount) customerIdRepository.findAtMostOne(com.nomadsoft.cortex.domain.card.CardAccount.class.getCanonicalName(), values);;
          card.addCardAccount(cardAccount);
        }
        else if (!accountDto.isLinked() && accountDto.isSelected())
        {
          // account to be linked
          values.put("id.instId", accountDto.getInstitution().getRealId());
          values.put("id.accountType", accountDto.getAccountType());
          com.nomadsoft.cortex.domain.account.AccountType accountType = (com.nomadsoft.cortex.domain.account.AccountType) customerIdRepository.findAtMostOne(com.nomadsoft.cortex.domain.account.AccountType.class.getCanonicalName(), values);
          com.nomadsoft.cortex.domain.card.CardAccount cardAccounObjt = new BasicCardAccount();
          cardAccounObjt.setId(new CardAccountId(card, acctDomain));
          cardAccounObjt.setIsoCode(accountType.getISOCode());
          cardAccounObjt.setTypeCode(acctDomain.getAccountType());
          cardAccounObjt.setRoleId("  ");
          card.addCardAccount(cardAccounObjt);
        }
      }
    }
    catch (Exception exp)
    {
      LOGGER.error(exp.getMessage());
      throw new CardAccountLinkingException(exp.getMessage());
    }
  }

  public void deleteCardAccountLinks(Card cardTransferObject, List<Account> linkAccounts) throws CardAccountLinkingException
  {
    try
    {
      com.nomadsoft.cortex.domain.card.Card card = (com.nomadsoft.cortex.domain.card.Card) customerIdRepository.findById(cardTransferObject.getRealId(), com.nomadsoft.cortex.domain.card.Card.class.getCanonicalName(), new String[0]);
      //set default account to the card
      com.nomadsoft.cortex.domain.account.Account accountDomain = (com.nomadsoft.cortex.domain.account.Account) customerIdRepository.findById(cardTransferObject.getAccount().getRealId(), com.nomadsoft.cortex.domain.account.Account.class.getCanonicalName(), new String[0]);
      card.setAccount(accountDomain);
      Map<String, Object> values = new HashMap<String, Object>();

      for (Account accountDto : linkAccounts)
      {
        com.nomadsoft.cortex.domain.account.Account acctDomain = (com.nomadsoft.cortex.domain.account.Account) customerIdRepository.findById(accountDto.getRealId(), com.nomadsoft.cortex.domain.account.Account.class.getCanonicalName(), new String[0]);
        com.nomadsoft.cortex.domain.card.CardAccount cardAccount = null;
        values.clear();
        if (accountDto.isLinked() && !accountDto.isSelected())
        {
          values.put("id.card", card);
          values.put("id.account", acctDomain);
          cardAccount = (com.nomadsoft.cortex.domain.card.CardAccount) customerIdRepository.findAtMostOne(com.nomadsoft.cortex.domain.card.CardAccount.class.getCanonicalName(), values);;
          customerIdRepository.deleteCardAccount(cardAccount);
        }
      }
    }
    catch (Exception exp)
    {
      LOGGER.error(exp.getMessage());
      throw new CardAccountLinkingException(exp.getMessage());
    }
  }

  public void deleteCardLink(Card cardTransport)
  {
    com.nomadsoft.cortex.domain.card.Card card = (com.nomadsoft.cortex.domain.card.Card) customerIdRepository.findById(cardTransport.getRealId(), com.nomadsoft.cortex.domain.card.Card.class.getCanonicalName(), new String[0]);
    com.nomadsoft.cortex.domain.account.Account dummyAccount = card.getAccount();
    if (dummyAccount == null && cardTransport.getAccount() != null)
    {
      dummyAccount = (com.nomadsoft.cortex.domain.account.Account) customerIdRepository.findById(cardTransport.getAccount().getRealId(), com.nomadsoft.cortex.domain.account.Account.class.getCanonicalName(), new String[0]);
    }
    Map<String, Object> values = new HashMap<String, Object>();
    values.clear();
    values.put("id.card", card);
    if (dummyAccount != null)
    {
      values.put("id.account", dummyAccount);
    }
    com.nomadsoft.cortex.domain.card.CardAccount cardAccount = (com.nomadsoft.cortex.domain.card.CardAccount) customerIdRepository.findAtMostOne(com.nomadsoft.cortex.domain.card.CardAccount.class.getCanonicalName(), values);;
    if (cardAccount != null)
    {
      customerIdRepository.deleteCardAccount(cardAccount);
    }

  }

  public void updateCard(Card cardTransport, Account accountTransport, long customerId)
  {
    com.nomadsoft.cortex.domain.card.Card card = (com.nomadsoft.cortex.domain.card.Card) customerIdRepository.findById(cardTransport.getRealId(), com.nomadsoft.cortex.domain.card.Card.class.getCanonicalName(), new String[0]);
    com.nomadsoft.cortex.domain.account.Account accountDomain = (com.nomadsoft.cortex.domain.account.Account) customerIdRepository.findById(accountTransport.getRealId(), com.nomadsoft.cortex.domain.account.Account.class.getCanonicalName(), new String[0]);
    com.nomadsoft.cortex.domain.accountholder.AccountHolder accountHolderDomain = (com.nomadsoft.cortex.domain.accountholder.AccountHolder) customerIdRepository.findById(customerId, com.nomadsoft.cortex.domain.accountholder.AccountHolder.class.getCanonicalName(), new String[0]);
    card.setEmbossedName(cardTransport.getEmbossedName());
    card.setAccount(accountDomain);
    card.setAccountHolder(accountHolderDomain);
    com.nomadsoft.cortex.domain.card.CardHolder cardHolder = new com.nomadsoft.cortex.domain.card.basic.BasicCardHolder();
    cardHolder.setDateOfBirth(accountHolderDomain.getDateOfBirth());
    cardHolder.setFirstName(accountHolderDomain.getFirstName());
    cardHolder.setLastName(accountHolderDomain.getLastName());
    cardHolder.setTitle(accountHolderDomain.getTitle() != null ? accountHolderDomain.getTitle() : " ");
    cardHolder.setIdNumber(" ");
    card.setCardHolder(cardHolder);
    // inserting chargedata
    ChargeData chargeData = new BasicChargeData();
    chargeData.setCard(card);
    chargeData.setTransactionDate(Calendar.getInstance().getTime());
    chargeData.setChargeCurrency(accountDomain.getCurrency().getId());
    chargeData.setChargeData(" ");
    chargeData.setChargeType(2010L);
    chargeData.setCustomerType(0L);
    chargeData.setOpdata(" ");
    chargeData.setProcessed("0");
    customerIdRepository.save(chargeData, "com.fis.cortex.domain.custid.ChargeData");

    try
    {
      this.accessLogServiceManager.logAccess(Calendar.getInstance(),
              com.metavante.cortexonline.wicket.CortexSession.get().getUserName(),
              "AGN_CARD - CRDDET " + card.getPan() + "ACCNO " + card.getAccount().getAccountNumber(),
              ((WebClientInfo) com.metavante.cortexonline.wicket.CortexSession.get().getClientInfo()).getProperties().getRemoteAddress());
    }
    catch (Exception e)
    {
      LOGGER.error("AccessLogServiceManager " + e.getMessage());
    }
  }

  public void updateAdditionalCard(Card primaryCard, Card additionalCard) throws AdditionalsConstraintViolationException, GeneralSqlException
  {
    Additionals additionals = null;
    try
    {
      com.nomadsoft.cortex.domain.card.Card cardDomain = (com.nomadsoft.cortex.domain.card.Card) customerIdRepository.findById(primaryCard.getRealId(), com.nomadsoft.cortex.domain.card.Card.class.getCanonicalName(), new String[0]);
      com.nomadsoft.cortex.domain.card.Card additionalCardDomain = (com.nomadsoft.cortex.domain.card.Card) customerIdRepository.findById(additionalCard.getRealId(), com.nomadsoft.cortex.domain.card.Card.class.getCanonicalName(), new String[0]);
      com.nomadsoft.cortex.domain.card.CardHolder cardHolder = additionalCardDomain.getCardHolder();
      if (cardHolder == null)
      {
        cardHolder = new com.nomadsoft.cortex.domain.card.basic.BasicCardHolder();
      }
      cardHolder.setDateOfBirth(additionalCard.getCardHolder().getDateOfBirth());
      cardHolder.setFirstName(additionalCard.getCardHolder().getFirstName());
      cardHolder.setLastName(additionalCard.getCardHolder().getLastName());
      cardHolder.setTitle(additionalCard.getCardHolder().getTitle());
      cardHolder.setIdNumber(" ");
      additionalCardDomain.setCardHolder(cardHolder);
      additionalCardDomain.setAdditionalNumber(additionalCard.getAdditionalNumber());
      additionalCardDomain.setEmbossedName(additionalCard.getEmbossedName());
      additionalCardDomain.setAccountHolder(cardDomain.getAccountHolder());
      additionalCardDomain.setAccount(cardDomain.getAccount());
      Map<String, Object> values = new HashMap<String, Object>();
      for (Iterator<com.nomadsoft.cortex.domain.account.Account> it = cardDomain.getAccounts().iterator(); it.hasNext();)
      {
        com.nomadsoft.cortex.domain.account.Account cardAccount = it.next();
        com.nomadsoft.cortex.domain.card.CardAccount cardAccounObjt = new BasicCardAccount();
        cardAccounObjt.setId(new CardAccountId(additionalCardDomain, cardAccount));
        values.clear();
        values.put("id.instId", cardAccount.getInstitution().getId());
        values.put("id.accountType", cardAccount.getAccountType());
        com.nomadsoft.cortex.domain.account.AccountType accountType = (com.nomadsoft.cortex.domain.account.AccountType) customerIdRepository.findAtMostOne(com.nomadsoft.cortex.domain.account.AccountType.class.getCanonicalName(), values);
        cardAccounObjt.setIsoCode(accountType.getISOCode());
        cardAccounObjt.setTypeCode(cardAccount.getAccountType());
        cardAccounObjt.setRoleId(" ");
        additionalCardDomain.addCardAccount(cardAccounObjt);
      }
      additionals = new BasicAdditionals();
      additionals.setId(new AdditionalsId(cardDomain.getId(), additionalCardDomain.getId()));
      additionals.setAdditionalsno((short) 0);
      customerIdRepository.update(additionals, "com.fis.cortex.domain.custid.Additionals");

    }
    catch (org.hibernate.exception.ConstraintViolationException exp)
    {
      LOGGER.error(exp.getMessage());
      throw new AdditionalsConstraintViolationException("additional_card_constraint_violation");
    }
    catch (org.hibernate.exception.GenericJDBCException sqlExp)
    {
      LOGGER.error(sqlExp.getMessage());
      throw new GeneralSqlException("additional_card_sql_exception");
    }
  }

  public void updateLinkForAccounts(Card cardTransport, List<Account> accountList)
  {
    com.nomadsoft.cortex.domain.card.Card card = (com.nomadsoft.cortex.domain.card.Card) customerIdRepository.findById(cardTransport.getRealId(), com.nomadsoft.cortex.domain.card.Card.class.getCanonicalName(), new String[0]);
    Map<String, Object> values = new HashMap<String, Object>();
    com.nomadsoft.cortex.domain.account.Account accountDomain = null;
    for (Account accountDto : accountList)
    {
      accountDomain = (com.nomadsoft.cortex.domain.account.Account) customerIdRepository.findById(accountDto.getRealId(), com.nomadsoft.cortex.domain.account.Account.class.getCanonicalName(), new String[0]);
      values.clear();
      values.put("id.instId", accountDto.getInstitution().getRealId());
      values.put("id.accountType", accountDto.getAccountType());
      com.nomadsoft.cortex.domain.account.AccountType accountType = (com.nomadsoft.cortex.domain.account.AccountType) customerIdRepository.findAtMostOne(com.nomadsoft.cortex.domain.account.AccountType.class.getCanonicalName(), values);
      com.nomadsoft.cortex.domain.card.CardAccount cardAccounObjt = new BasicCardAccount();
      cardAccounObjt.setId(new CardAccountId(card, accountDomain));
      cardAccounObjt.setIsoCode(accountType.getISOCode());
      cardAccounObjt.setTypeCode(accountDomain.getAccountType());
      cardAccounObjt.setRoleId("  ");
      card.addCardAccount(cardAccounObjt);
    }

  }

  public void setCustomerIdRepository(CustomerIdRepository repository)
  {
    this.customerIdRepository = repository;
  }

  public void setAccountHolderConverter(AccountHolderConverter accountHolderConverter)
  {
    this.accountHolderConverter = accountHolderConverter;
  }

  public void setCardConverter(CardConverter cardConverter)
  {
    this.cardConverter = cardConverter;
  }

  public void setAccountConverter(AccountConverter accountConverter)
  {
    this.accountConverter = accountConverter;
  }

  public void setInstitutionConverter(InstitutionConverter institutionConverter)
  {
    this.institutionConverter = institutionConverter;
  }

  public void setBranchConvertor(BranchConvertor branchConvertor)
  {
    this.branchConvertor = branchConvertor;
  }

  // get Spring-WS client Template 
  public void setCortexWebServiceTemplate(CortexWebServiceTemplate wsTemplate)
  {
    String hostUrl = System.getProperty(HOST_URL);
    if (hostUrl != null)
    {
      webserviceURL = hostUrl;
    }
    else
    {
      webserviceURL = wsTemplate.getDefaultUri();
    }
    this.wsTemplate = wsTemplate;
    this.wsTemplate.setDefaultUri(webserviceURL);
  }

  // get Spring-WS client Template  for  crdbase webservice
  public void setCardBaseTemplate(CortexWebServiceTemplate wsTemplate)
  {
    String hostUrl = System.getProperty(CRDBASE_WS_URL);
    if (hostUrl != null)
    {
      crdbasewebserviceURL = hostUrl;
    }
    else
    {
      crdbasewebserviceURL = wsTemplate.getDefaultUri();
    }
    this.crdbaseWsTemplate = wsTemplate;
    this.crdbaseWsTemplate.setDefaultUri(crdbasewebserviceURL);
  }

  //set CortexCustomerSearch type
  private CortexCustomerSearchSoapIn setCortexCustomerSearch(String custIdCode, int custIdTypeId, String user)
  {
    CortexCustomerSearchSoapIn searchRequest = new CortexCustomerSearchSoapIn();
    CortexCustomerSearchRequest request = new CortexCustomerSearchRequest();
    request = (CortexCustomerSearchRequest) setBaseRequest(request, user);
    request.setIdCode(custIdCode);
    request.setIdType((int) custIdTypeId);
    searchRequest.setRequest(request);
    return searchRequest;
  }

  private BaseRequest setBaseRequest(BaseRequest baseRequest, String user)
  {
    String channel = System.getProperty("channel");;
    String terminal = System.getProperty("terminal");
    baseRequest.setDate(Calendar.getInstance().getTime());
    if (channel != null)
    {
      baseRequest.setChannel(channel);
    }
    else
    {
      baseRequest.setChannel("Cortex");
    }

    if (terminal != null)
    {
      baseRequest.setTerminal(terminal);
    }
    else
    {
      baseRequest.setTerminal("00008888888");
    }

    baseRequest.setUser(user);
    return baseRequest;
  }
  // get Institution 

  private com.nomadsoft.cortex.domain.institution.Institution getInstitution(long instId)
  {
    com.nomadsoft.cortex.domain.institution.Institution institution = (com.nomadsoft.cortex.domain.institution.Institution) customerIdRepository.findById(instId, com.nomadsoft.cortex.domain.institution.Institution.class.getCanonicalName(), new String[0]);
    return institution;
  }

  // get CustIdType 
  private com.fis.cortex.domain.custid.CustIdType getCustIdType(long custIdTypeId)
  {
    com.fis.cortex.domain.custid.CustIdType idType = (com.fis.cortex.domain.custid.CustIdType) customerIdRepository.findById(custIdTypeId, com.fis.cortex.domain.custid.CustIdType.class.getCanonicalName(), new String[0]);
    return idType;
  }

  // get Branch 
  private com.nomadsoft.cortex.domain.branch.Branch getBranch(Map<String, Object> criteria)
  {
    com.nomadsoft.cortex.domain.branch.Branch branch = (com.nomadsoft.cortex.domain.branch.Branch) customerIdRepository.findAtMostOne(com.nomadsoft.cortex.domain.branch.Branch.class.getCanonicalName(), criteria);
    return branch;
  }

  // get Currency 
  private com.nomadsoft.cortex.domain.money.Currency getCurrency(Map<String, Object> criteria)
  {
    com.nomadsoft.cortex.domain.money.Currency currency = (com.nomadsoft.cortex.domain.money.Currency) customerIdRepository.findAtMostOne(com.nomadsoft.cortex.domain.money.Currency.class.getCanonicalName(), criteria);
    return currency;
  }

  // get AccountHolder
  private com.nomadsoft.cortex.domain.accountholder.AccountHolder getAccountHolderDetails(long customerId)
  {
    com.nomadsoft.cortex.domain.accountholder.AccountHolder accountHolder = (com.nomadsoft.cortex.domain.accountholder.AccountHolder) customerIdRepository.findById(customerId, com.nomadsoft.cortex.domain.accountholder.AccountHolder.class.getCanonicalName(), new String[0]);
    return accountHolder;
  }

  // get Account 
  private com.nomadsoft.cortex.domain.account.Account getAccount(Map<String, Object> criteria)
  {
    com.nomadsoft.cortex.domain.account.Account account = (com.nomadsoft.cortex.domain.account.Account) customerIdRepository.findAtMostOne(com.nomadsoft.cortex.domain.account.Account.class.getCanonicalName(), criteria);
    return account;
  }

  // create AccountHolder
  private com.nomadsoft.cortex.domain.accountholder.AccountHolder createCustomer(CortexCustomerSearchSoapOut cortexCustomerSearch)
  {
    com.nomadsoft.cortex.domain.accountholder.AccountHolder hostCustomer = new com.nomadsoft.cortex.domain.accountholder.basic.BasicAccountHolder();
    CortexCustomerSearchResult result = cortexCustomerSearch.getCortexCustomerSearchResult();
    hostCustomer.setCustomerCode(" ");
    hostCustomer.setTitle(result.getTitle() != null ? result.getTitle() : " ");
    hostCustomer.setFirstName(result.getFirstName() != null ? result.getFirstName() : " ");
    hostCustomer.setLastName(result.getLastName() != null ? result.getLastName() : " ");
    hostCustomer.setCustomerType((short) 0);
    hostCustomer.setAddressIndicator((short) 0);
    BasicAddress homeAddress = new BasicAddress("-", " ", " ", " ", " ", " ");
    hostCustomer.setHomeAddress(homeAddress);
    hostCustomer.setHomeAddressLine1("-");
    hostCustomer.setHomeTelephoneNumber(" ");
    BasicAddress workAddress = new BasicAddress(" ", " ", " ", " ", " ", " ");
    hostCustomer.setWorkAddress(workAddress);
    hostCustomer.setPOBox(" ");
    hostCustomer.setStatementCode((short) 0);
    hostCustomer.setWorkAddressPostCode(" ");
    hostCustomer.setCollectionZone((short) 0);
    hostCustomer.setProfessionCode((short) result.getCustomerProfessionCode());
    hostCustomer.setMaritalStatus(result.getMaritalStatus().value().charAt(0));
    hostCustomer.setSex(result.getGender().value().charAt(0));
    hostCustomer.setDateAccepted(new Date());
    hostCustomer.setRefuseCheque('0');
    hostCustomer.setMailShots('0');
    hostCustomer.setIdNumber(" ");
    hostCustomer.setNumberBouncedChequesPrimaryCurrency("0");
    hostCustomer.setNumberBouncedChequesSecondaryCurrency("0");
    hostCustomer.setUserData1(" ");
    hostCustomer.setUserData2(" ");
    hostCustomer.setUserData3(" ");
    hostCustomer.setUserData4(" ");
    hostCustomer.setEmailAddress(" ");
    hostCustomer.setFaxNumber(" ");
    hostCustomer.setCatParams(" ");
    Calendar cal = Calendar.getInstance();
    if (result.getDOB() != null)
    {
      cal.set(result.getDOB().getYear() + 1900, result.getDOB().getMonth(), result.getDOB().getDate());
      hostCustomer.setDateOfBirth(cal.getTime());
    }
    else
    {
      cal.set(2283 + 1900, 8, 31);
      hostCustomer.setDateOfBirth(cal.getTime());
    }
    hostCustomer.setPreferredLanguage("01");
    hostCustomer.setLatinTitle(" ");
    hostCustomer.setLatinFirstName(" ");
    hostCustomer.setLatinLastName(" ");
    hostCustomer.setUcFirstName(" ");
    hostCustomer.setUcLastName(" ");
    hostCustomer.setNationalityId(" ");
    hostCustomer.setWorkCountryIso(" ");
    hostCustomer.setWorkTelephoneNumber(" ");
    hostCustomer.setWorkCounty(" ");
    hostCustomer.setMobileTelephoneNumber(" ");
    return hostCustomer;
  }

  //set CortexCustomerSearch type
  private CortexAccountSearchSoapIn setCortexAccountSearch(String custIdCode, int custIdTypeId, String user)
  {
    CortexAccountSearchSoapIn accountSearchRequest = new CortexAccountSearchSoapIn();
    CortexAccountSearchRequest accountRequest = new CortexAccountSearchRequest();
    accountRequest = (CortexAccountSearchRequest) setBaseRequest(accountRequest, user);
    accountRequest.setIdCode(custIdCode);
    accountRequest.setIdType(custIdTypeId);
    accountSearchRequest.setRequest(accountRequest);
    return accountSearchRequest;
  }

  //set CortexValidateCustomerAdditionalAccount
  private CortexValidateCustomerAdditionalAccountSoapIn setCortexValidateCustomerAdditionalAccount(String accountNumber, String custIdCode, long custIdType, String user)
  {
    CortexValidateCustomerAdditionalAccountSoapIn validateAdditionalAccount = new CortexValidateCustomerAdditionalAccountSoapIn();
    CortexValidateCustomerAdditionalAccountRequest validateAdditionalAccountRequest = new CortexValidateCustomerAdditionalAccountRequest();
    validateAdditionalAccountRequest = (CortexValidateCustomerAdditionalAccountRequest) setBaseRequest(validateAdditionalAccountRequest, user);
    validateAdditionalAccountRequest.setAccountNumber(accountNumber);
    validateAdditionalAccountRequest.setIdCode(custIdCode);
    validateAdditionalAccountRequest.setIdType((int) custIdType);
    validateAdditionalAccount.setRequest(validateAdditionalAccountRequest);
    return validateAdditionalAccount;
  }

  public Card getGeneratedCard(Institution institution, String cardProduct, AccountHolder accountHolder, Account dlftAccount, com.metavante.cortex.transport.objects.common.Branch deliveryBranch, String username) throws CortexWebServiceException
  {
    Card cardDto = null;
    try
    {

      this.crdbaseWsTemplate.setDefaultUri(crdbasewebserviceURL + ISSUER_DIRECTIVES_SERVICE_NAME);
      GenerateCardOsi generateCard = getGenerateCardOsi(institution, cardProduct, accountHolder, dlftAccount);
      GenerateCardRequest request = new GenerateCardRequest();
      request.setDirectiveOsi(generateCard);
      request.setRqstHdr(populateRequestHeader());
      GenerateCardResponse response = (GenerateCardResponse) crdbaseWsTemplate.marshalSendAndReceive(request);
      if (response != null && response.getDirectiveOso() != null && response.getDirectiveOso().getActionCode().equals(Constants.VALID_ACTION_CODE))
      {
        GenerateCardOso oso = response.getDirectiveOso();
        CreditDetailResponse cardResponse = oso.getCreditDetailResponse();
        String pan = cardResponse.getPan();
        BasicPanCryptor panCryptor = BasicPanCryptor.getInstance();
        pan = panCryptor.encryptPan(pan);
        com.nomadsoft.cortex.domain.card.Card card = customerIdRepository.getCard(pan, institution.getRealId());
        String branchCode = String.format("%s", deliveryBranch != null ? deliveryBranch.getBranchCode() : "");
        CardBatch cardBatch = getCardBatch(branchCode, card.getCardProduct().getInstitution(), card.getCardProduct(), Constants.INT_ZERO, Constants.INT_ZERO, CardBatchStatus.OPEN_TO_ADD_CARDS, CardBatchType.ISSUE, username);
        card.setBatch(cardBatch);
        customerIdRepository.update(card, com.nomadsoft.cortex.domain.card.Card.class.getCanonicalName());
        cardDto = cardConverter.convertRealToTransport(card);
        cardDto.setCardBatch(String.valueOf(card.getBatch().getId()));
      }
      else if (response != null && response.getDirectiveOso() != null && response.getDirectiveOso().getActionCode().equals(Constants.INVALID_ACTION_CODE))
      {
        LOGGER.error("ActionCode ::" + response.getDirectiveOso().getActionCode());
        throw new CortexWebServiceException("gen_card_create_error");
      }

    }
    catch (WebServiceIOException webserviceIOException)
    {
      LOGGER.error(webserviceIOException.getMessage());
      throw new CortexWebServiceException("webservice_connection_error");
    }
    catch (SoapFaultClientException soapFault)
    {
      LOGGER.error(soapFault.getMessage());
      throw new CortexWebServiceException("gen_card_validation_error");
    }
    catch (Exception exp)
    {
      LOGGER.error(exp.getMessage());
      throw new CortexWebServiceException("gen_card_create_error");
    }
    return cardDto;
  }

  public void updateAccountHolder(AccountHolder accountHolder)
  {
    com.nomadsoft.cortex.domain.accountholder.AccountHolder accHolder = getAccountHolderDetails(accountHolder.getRealId());
    accountHolderConverter.updateRealFromTransport(accHolder, accountHolder);
    customerIdRepository.update(accHolder, com.nomadsoft.cortex.domain.accountholder.AccountHolder.class.getCanonicalName());
  }

  private RequestHeader populateRequestHeader()
  {
    RequestHeader header = new RequestHeader();
    header.setLclPrf(Constants.PREF_LANG);
    header.setMsgUuid(Constants.MSG_UUID);
    header.setRqstHdrVer(Constants.REQUEST_HDR_VER);
    header.setSrcId(Constants.SRC_ID);
    ServiceParameters serviceparameter = new ServiceParameters();
    serviceparameter.setServId(Constants.SERVICE_ID);
    serviceparameter.setApplId(Constants.APP_ID);
    serviceparameter.setFeId(Constants.FE_ID);
    serviceparameter.setServVer(Constants.SERVICE_VERSION);
    ServiceParametersList parameterList = new ServiceParametersList();
    parameterList.setServPrmtrs(serviceparameter);
    header.setServPrmtrsLst(parameterList);
    return header;

  }

  private GenerateCardOsi getGenerateCardOsi(Institution institution, String cardProduct, AccountHolder accountHolder, Account account)
  {
    GenerateCardOsi generateCardOsi = new GenerateCardOsi();
    generateCardOsi.setInstCode(institution.getCode());
    generateCardOsi.setAction(Constants.STRING_ONE);
    generateCardOsi.setAccountDetail(getAccountDetailList(accountHolder));
    generateCardOsi.setCustomerDetail(getCustomerDetail(accountHolder));
    generateCardOsi.setCardDetail(getCardDetail(accountHolder, account, cardProduct));
    return generateCardOsi;
  }

  private List<AccountDetail> getAccountDetailList(AccountHolder accountHolder)
  {
    List<AccountDetail> accountDetailList = null;
    if (accountHolder != null && accountHolder.getAccounts().size() > 0)
    {
      accountDetailList = new ArrayList<AccountDetail>();
      for (Account account : accountHolder.getAccounts())
      {
        if (account.isLinked())
        {
          AccountDetail accountDetail = new AccountDetail();
          accountDetail.setAccNo(account.getAccountNumber());
          accountDetail.setBranchCode(account.getBranch().getBranchCode());
          accountDetail.setCurrCode(account.getCurrency().getCode());
          accountDetail.setDuplicateMng(Constants.DUPLICATE_MNG);
          accountDetail.setCustomerCode(accountHolder.getCustomerCode());
          accountDetail.setStatusCode(account.getStatus());
          accountDetail.setVipFlag(String.valueOf(account.getVip()));
          accountDetail.setTypeCode(account.getAccountType());
          accountDetailList.add(accountDetail);
        }

      }
    }
    return accountDetailList;
  }

  private CustomerDetail getCustomerDetail(AccountHolder accountHolder)
  {
    CustomerDetail customerDetail = new CustomerDetail();
    customerDetail.setAddrInd(Constants.ADDR_IND);
    customerDetail.setCustCode(accountHolder.getCustomerCode());
    Date dob = accountHolder.getDateOfBirth() != null ? accountHolder.getDateOfBirth() : new Date();
    customerDetail.setDOB(formatSpecificDate(dob));
    customerDetail.setDuplicateMng(Constants.DUPLICATE_MNG);
    String fistname = StringUtils.isNotBlank(accountHolder.getFirstName()) ? accountHolder.getFirstName() : Constants.STRING_HYPEN;
    customerDetail.setFirstName(fistname);
    String lastname = StringUtils.isNotEmpty(accountHolder.getLastName()) ? accountHolder.getLastName() : Constants.STRING_ONE_SPACE;
    customerDetail.setLastName(lastname);
    String title = StringUtils.isNotBlank(accountHolder.getTitle()) ? accountHolder.getTitle() : Constants.STRING_HYPEN;
    customerDetail.setTitle(title);
    customerDetail.setMailShots(Constants.STRING_ZERO);
    customerDetail.setPrfLang(accountHolder.getPreferredLanguage());
    customerDetail.setProfCode(accountHolder.getProfessionCode());
    customerDetail.setMaritalStatus(String.valueOf(accountHolder.getMaritalStatus()));
    Character refuseCheque = new Character(accountHolder.getRefuseCheque());
    if ((refuseCheque != null && refuseCheque.toString().equals(Constants.STRING_ONE_SPACE)) || refuseCheque == null)
    {
      customerDetail.setRefuseChq(Constants.STRING_ZERO);
    }
    else
    {
      customerDetail.setRefuseChq(refuseCheque.toString());
    }

    customerDetail.setSex(String.valueOf(accountHolder.getSex()));
    ContactMechanism contactMechanism = getContactMechanism(accountHolder);
    List<ContactMechanism> contactMechanismList = new ArrayList<ContactMechanism>();
    contactMechanismList.add(contactMechanism);
    customerDetail.setContactMechLst(contactMechanismList);
    return customerDetail;

  }

  private ContactMechanism getContactMechanism(AccountHolder accountHolder)
  {
    ContactMechanism contactMechanism = new ContactMechanism();
    contactMechanism.setTelcom(getTeleCommunication(accountHolder));
    contactMechanism.setAddress(getHomeAddress(accountHolder));
    contactMechanism.setDeliveryReference(getDeliveryReference(accountHolder));
    contactMechanism.seteAddr(getEmail(accountHolder));
    return contactMechanism;
  }

  private Address getHomeAddress(AccountHolder accountHolder)
  {
    Address address = new Address();
    address.setAddType(1);
    address.setPostCode(StringUtils.isNotEmpty(accountHolder.getHomeAddress().getPostCode()) ? accountHolder.getHomeAddress().getPostCode() : Constants.STRING_ONE_SPACE);
    address.setProvince(Constants.STRING_ONE_SPACE);
    address.setTerritory(Constants.STRING_ONE_SPACE);
    address.setState(Constants.STRING_ONE_SPACE);
    address.setCounty(StringUtils.isNotEmpty(accountHolder.getHomeAddress().getCounty()) ? accountHolder.getHomeAddress().getCounty() : Constants.STRING_ONE_SPACE);
    address.setRegion(Constants.STRING_ONE_SPACE);
    address.setCountry(Constants.DUMMY_COUNTRY_CODE);
    address.setAddressLine1(StringUtils.isNotBlank(accountHolder.getHomeAddress().getAddressLine1()) ? accountHolder.getHomeAddress().getAddressLine1() : Constants.ADDRESS_LINE1);
    address.setCity(StringUtils.isNotEmpty(accountHolder.getHomeAddress().getCity()) ? accountHolder.getHomeAddress().getCity() : Constants.CITY);
    return address;

  }

  private DeliveryReference getDeliveryReference(AccountHolder accountHolder)
  {
    DeliveryReference deliveryReference = new DeliveryReference();
    deliveryReference.setRefType(Constants.INT_ONE);
    deliveryReference.setRefid(Constants.REF_ID);
    return deliveryReference;
  }

  private Email getEmail(AccountHolder accountHolder)
  {
    Email email = new Email();
    email.setEmailType(Constants.INT_ONE);
    email.setElectronicAddress(StringUtils.isNotBlank(accountHolder.getEmail()) ? accountHolder.getEmail() : Constants.EMAIL);
    return email;
  }

  private TeleCommunication getTeleCommunication(AccountHolder accountHolder)
  {
    TeleCommunication teleCommunication = new TeleCommunication();
    teleCommunication.setContactNumber(StringUtils.isNotBlank(accountHolder.getHomeTelephoneNumber()) ? accountHolder.getHomeTelephoneNumber() : Constants.TELEPHONE_HOME);
    teleCommunication.setTelType(Constants.INT_ONE);
    teleCommunication.setCountryPrefix(StringUtils.isNotBlank(accountHolder.getHomeCountryIso()) ? accountHolder.getHomeCountryIso() : Constants.COUNTRY_PREFIX);
    return teleCommunication;
  }

  private CardDetail getCardDetail(AccountHolder accountHolder, Account account, String cardProduct)
  {
    String customerName = null;
    String embozzname = null;
    CardDetail cardDetail = new CardDetail();
    cardDetail.setAccountNumber(account.getAccountNumber());
    cardDetail.setAdditonalNo(Constants.INT_ZERO);
    cardDetail.setAddressIndicator(new Integer(Constants.ADDR_IND));
    String branchCode = String.format("%s", account.getBranch() != null ? account.getBranch().getBranchCode() : "");
    cardDetail.setBranchCode(branchCode);
    cardDetail.setCurrencyCode(account.getCurrency().getCode());
    String firstname = StringUtils.isNotEmpty(accountHolder.getFirstName()) ? accountHolder.getFirstName() : Constants.STRING_ONE_SPACE;
    cardDetail.setFirstName(firstname);
    String lastname = StringUtils.isNotEmpty(accountHolder.getLastName()) ? accountHolder.getLastName() : Constants.STRING_ONE_SPACE;
    cardDetail.setLastname(accountHolder.getLastName());
    String title = StringUtils.isNotEmpty(accountHolder.getTitle()) ? accountHolder.getTitle() : Constants.STRING_ONE_SPACE;
    cardDetail.setTitle(title);
    cardDetail.setCardProduct(cardProduct);
    cardDetail.setCustomerCode(accountHolder.getCustomerCode());
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(title).append(firstname).append(lastname);
    customerName = stringBuilder.toString();
    if (customerName.length() > Constants.EMBOSS_NAME_LENGTH)
    {
      customerName = customerName.substring(0, Constants.EMBOSS_NAME_LENGTH);
    }
    embozzname = StringUtils.isNotBlank(accountHolder.getEmbossName()) ? accountHolder.getEmbossName() : null;
    if (embozzname != null)
    {
      if (embozzname.length() <= Constants.EMBOSS_NAME_LENGTH)
      {
        cardDetail.setEmbossName(embozzname);
      }
      else
      {
        embozzname = embozzname.substring(0, Constants.EMBOSS_NAME_LENGTH);
        cardDetail.setEmbossName(embozzname);
      }
    }
    else
    {
      cardDetail.setEmbossName(customerName);
    }
    return cardDetail;
  }

  public CardBatch getCardBatch(String branchCode, com.nomadsoft.cortex.domain.institution.Institution institution,
          CardProduct cardproduct, int addrind, int priority,
          CardBatchStatus crdbatchStatus, CardBatchType cardBatchType, String username) throws Exception
  {
    com.nomadsoft.cortex.domain.msc.Msc msc = null;
    long longValue;
    long maxnumcards;
    BranchCardBatch branchCardBatch = null;
    BranchCardBatch newBranchCardBatch = null;
    Map<String, Object> branchSearchCriteria = new HashMap<String, Object>();
    CardBatch cardBatch = null;
    Branch branch = null;
    try
    {
      branchCardBatch = customerIdRepository.getBranchCardBatch(branchCode,
              institution, Constants.CBTCH_ISSUE, cardproduct,
              crdbatchStatus, Character.forDigit(addrind, Constants.INT_TEN),
              CardBatchPriority.getCardBatchPriority(priority));
      branchSearchCriteria.put("institution.id", institution.getId());
      branchSearchCriteria.put("branchCode", branchCode);
      branch = getBranch(branchSearchCriteria);
    }
    catch (Exception e)
    {
      LOGGER.error(e.getMessage());
      throw e;
    }
    if (branchCardBatch != null)
    {
      cardBatch = branchCardBatch.getCardBatch();
    }

    if (cardBatch != null)
    {
      msc = customerIdRepository.findByTagAndIndex(Constants.MSC_MAXNUMCARDS, (short) Constants.INT_ONE);
      if (msc == null)
      {
        maxnumcards = Constants.MAX_CARDS_IN_BATCHES;
      }
      else
      {
        maxnumcards = msc.getLong();
      }
      if (cardBatch.getCardCount() >= maxnumcards)
      {
        cardBatch.setBatchStatus(CardBatchStatus.READY_TO_PRODUCE_CARDS);
        customerIdRepository.update(cardBatch, CardBatch.class.getCanonicalName());
        return getCardBatch(branchCode, institution, cardproduct, addrind,
                priority, crdbatchStatus, cardBatchType, username);
      }
      else
      {
        cardBatch.setCardCount(cardBatch.getCardCount() + Constants.INT_ONE);
        customerIdRepository.update(cardBatch, CardBatch.class.getCanonicalName());
      }
    }
    else
    {
      msc = customerIdRepository.findByTagAndIndex(Constants.NEXT_CARD_BATCH_TAG, (short) Constants.INT_ONE);
      if (msc == null)
      {
        LOGGER.error("Could not find the Msc record for card batch");
        throw new Exception();
      }
      else
      {
        longValue = msc.getLong();
        msc.setLong(msc.getLong() + Constants.INT_ONE);
        try
        {
          customerIdRepository.update(msc, Msc.class.getCanonicalName());
        }
        catch (Exception e)
        {
          LOGGER.error(e.getMessage());
          throw e;
        }

        cardBatch = new BasicCardBatch();
        cardBatch.setId(longValue);
        cardBatch.setInstitution(institution);
        cardBatch.setCardProduct(cardproduct);
        if (priority != Constants.INT_ZERO)
        {
          cardBatch.setPriority(CardBatchPriority
                  .getCardBatchPriority(priority));
        }
        else
        {
          // default priority
          cardBatch.setPriority(CardBatchPriority
                  .getCardBatchPriority(Constants.INT_ZERO));
        }
        cardBatch.setDeliveryAddress(String.valueOf(Character.forDigit(addrind, Constants.INT_TEN)));
        cardBatch.setBatchType(CardBatchType.ISSUE);
        cardBatch.setBatchStatus(CardBatchStatus.OPEN_TO_ADD_CARDS);
        cardBatch.setCreateDate(new Date());
        try
        {
          cardBatch.setCardsProducedOn(getSpecificDate(Constants.NEVERDATE));
          cardBatch.setPinsProducedOn(getSpecificDate(Constants.NEVERDATE));
        }
        catch (Exception exp)
        {
          LOGGER.error(exp.getMessage());
          throw exp;
        }
        cardBatch.setCardCount(Constants.INT_ONE);
        cardBatch.setUser(username);
        newBranchCardBatch = new BasicBranchCardBatch();
        newBranchCardBatch.setBranch(branch);
        newBranchCardBatch.setCardBatch(cardBatch);
        try
        {
          customerIdRepository.update(cardBatch, CardBatch.class.getCanonicalName());
          customerIdRepository.update(newBranchCardBatch, BranchCardBatch.class.getCanonicalName());
        }
        catch (Exception e)
        {
          LOGGER.error(e.getMessage());
          throw e;
        }
      }
    }
    return cardBatch;
  }

  public List<com.metavante.cortex.transport.objects.common.Branch> getBranchesByInstitution(Institution institutionTO)
  {
    List<com.metavante.cortex.transport.objects.common.Branch> list = null;
    try
    {
      if (institutionTO != null)
      {
        com.nomadsoft.cortex.domain.institution.Institution institution = (com.nomadsoft.cortex.domain.institution.Institution) customerIdRepository.findById(institutionTO.getRealId(), com.nomadsoft.cortex.domain.institution.Institution.class.getCanonicalName(), new String[0]);
        if (institution != null)
        {
          list = getTransportBranchList(institution);
        }

      }

    }
    catch (Exception exp)
    {
      LOGGER.error(exp.getMessage());
    }
    
    return list;

  }

  private List<com.metavante.cortex.transport.objects.common.Branch> getTransportBranchList(com.nomadsoft.cortex.domain.institution.Institution institution)
  {
    List<com.nomadsoft.cortex.domain.branch.Branch> branchList = findBranchByInstitution(institution);
    List<com.metavante.cortex.transport.objects.common.Branch> transportList = new ArrayList<com.metavante.cortex.transport.objects.common.Branch>();

    if (!branchList.isEmpty())
    {
      for (com.nomadsoft.cortex.domain.branch.Branch branch : branchList)
      {
        transportList.add(this.branchConvertor.convertRealToTransport(branch));
      }
    }
    return transportList;
  }

  private List<com.nomadsoft.cortex.domain.branch.Branch> findBranchByInstitution(com.nomadsoft.cortex.domain.institution.Institution institution)
  {
    return customerIdRepository.getBranchesByInstitution(institution);
  }

  private Date getSpecificDate(String stringDate) throws ParseException
  {
    SimpleDateFormat dateFormatter = new SimpleDateFormat(Constants.NEVERDATE_DATE_PATTERN);
    return dateFormatter.parse(stringDate);
  }

  private String formatSpecificDate(Date date)
  {
    GregorianCalendar calendar = new GregorianCalendar();
    calendar.setTime(date);
    int yyyy = calendar.get(Calendar.YEAR);
    if (yyyy < 1000)
    {
      calendar.set(Calendar.YEAR, yyyy + 1900);
    }
    return new SimpleDateFormat(Constants.DATE_PATTERN).format(calendar.getTime());
  }

  public void setAccessLogServiceManager(AccessLogServiceManager accessLogServiceManager)
  {
    this.accessLogServiceManager = accessLogServiceManager;
  }

  @Override
  public Long countActiveCardsByAccountNumber(String accountNumber)
  {
    return customerIdRepository.countActiveCardsByAccountNumber(accountNumber);
  }
}
