package com.metavante.cortexonline.wicket.content.cust.components;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.spring.injection.annot.SpringBean;
import com.fis.cortex.access.custid.view.Account;
import com.fis.cortex.access.custid.view.AccountHolder;
import com.fis.cortex.access.custid.view.AccountType;
import com.fis.cortex.access.custid.view.CustIdCode;
import com.fis.cortex.support.repository.SearchTransporter;
import com.fis.cortex.transport.core.dataholder.TransportList;
import com.fis.cortex.transport.core.services.TransportConverterService;
import com.fis.cortex.transport.custid.exception.CortexWebServiceException;
import com.fis.cortex.transport.custid.services.CustomerService;
import com.metavante.cortexonline.wicket.CortexSession;
import com.fis.cortex.wicket.base.CortexModalWindow;
import com.metavante.cortex.transport.SearchTransport;
import com.metavante.cortex.transport.objects.core.Institution;
import com.metavante.cortex.transport.objects.money.Currency;
import com.metavante.cortexonline.wicket.components.componentline.TextFieldLine;
import com.metavante.cortexonline.wicket.components.searcher.CriteriaPanel;
import com.metavante.cortexonline.wicket.content.cust.additionalaccounts.panels.AmendAccountsPanel;
import com.metavante.cortexonline.wicket.content.cust.components.CustomizedAjaxSearcher;
import com.metavante.cortexonline.wicket.content.cust.components.CustomizedAjaxSearcher.Column;
import com.metavante.cortexonline.wicket.content.cust.components.CustomizedAjaxSearcher.ColumnConfiguration;
import com.metavante.cortexonline.wicket.components.workflow.SelectEntityPanel;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowPanel;


/**
 * This panel mainly used in ModalWindow to display Account and its details 
 * after searching it.
 *   
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/components/AdditionalAccountsZoomPanel.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 * 
 * 
 */

public class AdditionalAccountsZoomPanel extends SelectEntityPanel<Account> {
	
	private static Log logger = LogFactory.getLog(AdditionalAccountsZoomPanel.class);
	private static final long serialVersionUID = 1L;
	private static final int NO_OF_PAGES=10;
	private static final int RESULTS_DISPLAY_SIZE=10;

	private Account acnt;
	private Institution inst;
	private TransportList<Account> accountList; 
	@SpringBean(name = "transportCustomerIdService")
	private CustomerService customerService;
	private CustomizedAjaxSearcher<Account> searcher;
	private long customerId;
	@SpringBean(name = "transportConverterService")
	private TransportConverterService transportConverterService;
	
	List<Account> accList;
	com.nomadsoft.cortex.domain.account.Account account;
	
	

	public static class Criteria extends CriteriaPanel {

		private static final long serialVersionUID = 1L;			
		private Account account;
		private TextFieldLine<String> txtFieldLine;
		

		public Criteria(final CortexModalWindow window,
				final WorkFlowPanel mainPanel, IModel<Account> model) {
			this.account = model.getObject();
			this.account.setAccountNumber("");
			Currency  currency = new Currency(null,null,(short)0,null);
			this.account.setCurrency(currency);	
			this.account.setAccountHolder(null);
			this.addComponents(this);
		}

		private void addComponents(WebMarkupContainer parent) {	
			this.txtFieldLine=new TextFieldLine<String>("accountNumber", getString("account_number"), new PropertyModel<String>(this.account,"accountNumber"));
			this.txtFieldLine.setMandatory(true);
			this.txtFieldLine.setMaxLength(28);
			this.txtFieldLine.setSize(28);
			parent.add(this.txtFieldLine);
		}

		
		protected void populateSearchValues(SearchValues values) {
			values.putIfUseful("institution.id",this.account.getInstitution().getRealId());			
			values.putIfUseful("accountNumber",this.account.getAccountNumber()!=null?this.account.getAccountNumber():"");
		}

	}

	private final List<Column<Account>> columns;
	{
		ColumnConfiguration<Account> c = new ColumnConfiguration<Account>();		
		c.addColumn(getString("customer_name"), "accountHolder.name");
		c.addColumn(getString("cust_account_type"), "accountTypeDescription");
		this.columns = c.getColumns();
	}

	public AdditionalAccountsZoomPanel( final WorkFlowPanel mainPanel,
			final CortexModalWindow window, final IModel<Account> model,
			 String id) {

		super(id, model);
		this.acnt = model.getObject();
		this.searcher = new CustomizedAjaxSearcher<Account>("searcher",new PropertyModel<Account>(this, "acnt"),this.columns) {

			private static final long serialVersionUID = 1L;

			@Override
			protected SearchTransport<Account> search(
					SearchTransport<Account> transport) {
				return AdditionalAccountsZoomPanel.this.search(transport);
				
			}

			@Override
			public void onLinkCard(AjaxRequestTarget target) {				
				AccountHolder accountHolder = new AccountHolder();				
				accountHolder.setAccounts(AdditionalAccountsZoomPanel.this.accountList);
				if(AdditionalAccountsZoomPanel.this.account!=null){
					AdditionalAccountsZoomPanel.this.customerService.saveAdditionalAccount(AdditionalAccountsZoomPanel.this.account);
					model.setObject(AdditionalAccountsZoomPanel.this.customerService.getAccount(AdditionalAccountsZoomPanel.this.account));
				}
				
				model.getObject().setAccountHolder(accountHolder);
				window.close(target);
			}
			@Override
			public void onCancel(AjaxRequestTarget target) {
				window.close(target);
			}
		};

		this.searcher.setCriteriaPanel(new Criteria(window, mainPanel, model));
		this.add(this.searcher);

	}

	@SuppressWarnings("unchecked")
	protected SearchTransport<Account> search(SearchTransport<Account> transport) {
		SearchTransporter transporter = new SearchTransporter(
				com.nomadsoft.cortex.domain.account.Account.class
						.getCanonicalName(), transport.getPageSize(), transport
						.getCriteria());
		transporter.setPageNumber(transport.getPageNumber());
		if (transporter.getSearchValueMap() == null) {
			// internal cannot handle null map
			transporter.setSearchValueMap(new HashMap<String, Object>());
		}
		transporter.setSortBy(Arrays.asList("accountNumber"));
		transporter.setSearchResultSize(RESULTS_DISPLAY_SIZE);
		try
		{
		
				String user=CortexSession.get().getUserName();			
				CustIdCode  idCode=customerService.getCustIdCodeByCustomer(this.customerId);
				if(idCode!=null)
				{
					this.account=customerService.getAdditionalAccounts(this.acnt.getInstitution().getRealId(),(String)transport.getCriteria().get("accountNumber"),idCode.getCode(),idCode.getCustIdType().getCustId(),user);
					if(this.account!=null)
					{
						accList= new ArrayList<Account>();
						Account additionalAccount=customerService.getAccount(this.account);
						accList.add(additionalAccount);
						transporter.setSearchResults(accList);
					}
				}
				else
				{
				  this.error(this.getString("amend_acc_customer_not_found"));
				  logger.error(this.getString("amend_acc_customer_not_found"));
				}
			
		}catch(CortexWebServiceException exp){
			logger.error(this.getString(exp.getMessage()));
			this.error(this.getString(exp.getMessage()));
	    }
		Map<String,Object> acctTypeMap=null;
		// convert each result into transport objects
		List<Account> results = new ArrayList<Account>();
		accountList = new TransportList<Account>();
		if(transporter.getSearchResults()!=null&&transporter.getSearchResults().size()>0){
			for (Account account : (List<Account>) transporter.getSearchResults()) 
			{
				Account result=new Account();
				acctTypeMap = new HashMap<String,Object>();
				acctTypeMap.put("id.instId", account.getInstitution().getRealId());
				acctTypeMap.put("id.accountType", account.getAccountType());
				
				AccountType accountType=null;
				SearchTransporter accountTypeTransporter = new SearchTransporter(
						com.nomadsoft.cortex.domain.account.AccountType.class 
								.getCanonicalName(),NO_OF_PAGES,acctTypeMap);
				accountTypeTransporter =transportConverterService.search(accountTypeTransporter,AccountType.class);
				if(accountTypeTransporter.getSearchResults()!=null&&accountTypeTransporter.getSearchResults().size()>0){
					accountType =(AccountType)accountTypeTransporter.getSearchResults().get(0);
				}
				result.setAccountHolder(account.getAccountHolder());
				if(accountType!=null){
					result.setAccountTypeDescription(accountType.getTypeCode()+"-"+accountType.getDescription());
				}
				result.setAccountType(account.getAccountType());
				result.setStatus(account.getStatus());
				result.setCurrency(account.getCurrency());
				result.setAccountNumber(account.getAccountNumber());
				result.setBranch(account.getBranch());
				result.setCatParams(account.getCatParams());
				result.setInstitution(account.getInstitution());
				result.setStatus(account.getStatus());
				result.setVip(account.getVip());
				results.add(result);
				
			}
			// set result details into external transport
			transport.setResults(results);
			accountList.addAll(transport.getResults());
			if (transporter.getSearchResultSize() >= transporter.getSearchResults()
					.size()) {
				// guard this, to deal with the backend not redoing the count query
				transport.setAllResultsSize(transporter.getSearchResultSize());
			}
		}
		return transport;
	}

	public void refresh() {
		this.searcher.refresh();
	}
	public void setCustomerId(long customerId){
		this.customerId=customerId;
    }
	

}
