package com.metavante.cortexonline.wicket.content.cust.components;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.Model;
import com.fis.cortex.access.custid.view.Message;
import com.fis.cortex.wicket.base.CortexAjaxButton;
import com.fis.cortex.wicket.base.CortexModalWindow;
import com.metavante.cortexonline.wicket.components.buttonbox.ButtonBox;
import com.metavante.cortexonline.wicket.components.workflow.SelectEntityPanel;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowPanel;

/**
 * This class is used to display the messages in the pop-up screen  
 * 
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/components/MessageDisplayPanel.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public class MessageDisplayPanel extends SelectEntityPanel<Message> {

	private static final long serialVersionUID = 1L;
	private CortexModalWindow modalWindow;
	private Form<Message> form;	
	private Label msg;
	private CortexAjaxButton okAjxBtn;
	
	
	private Message message;

	public MessageDisplayPanel(final WorkFlowPanel mainPanel,
			final CortexModalWindow window, final IModel<Message> model,
			 String id) {
		super(id, model);
		this.message=model.getObject();
		this.modalWindow=window;
		form= new Form<Message>("form") {
			private static final long serialVersionUID = 1L;
			@Override
			protected void onSubmit() {}
			
		
		};	
		this.setOutputMarkupId(true);
		this.setOutputMarkupPlaceholderTag(true);
		this.add(this.form);
		this.addFormComponents(this.form);		
		this.addAjaxButton(this.form);
		
		
	}


	private void addAjaxButton(WebMarkupContainer parent) {		
		IModel<String> model = new Model<String>(this.getString("msg_ok"));	
		this.okAjxBtn=new CortexAjaxButton("button",model,
				MessageDisplayPanel.this.form) {
			private static final long serialVersionUID = 1L;
			@Override
			protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
				target.addComponent(MessageDisplayPanel.this);
				MessageDisplayPanel.this.modalWindow.close(target);
				
			}
		};		
		this.okAjxBtn.setOutputMarkupId(true);
		this.okAjxBtn.setOutputMarkupPlaceholderTag(true);			
	    parent.add(this.okAjxBtn);
	}
	
	private void addFormComponents(WebMarkupContainer parent){
		this.msg=new Label("messageLabel",this.message.getMessage());
		this.msg.setVisible(true);
		parent.add(this.msg);
	}
	
	
	public void setDisplayMessage(String message){
		this.message.setMessage(message);
	}
	
	public void setAction(String action){
		this.message.setAction(action);
	}
}
