/**
 * <hr>
 * <h4>Copyright Metavante Technologies Ltd.</h4>
 */
package com.metavante.cortexonline.wicket.content.cust.assigncard.panels;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.fis.cortex.encryption.PanCryptor;
import com.fis.cortex.encryption.basic.BasicPanCryptor;
import com.fis.cortex.encryption.exceptions.PanEncryptionFailedException;
import org.apache.wicket.AttributeModifier;
import org.apache.wicket.MarkupContainer;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.form.OnChangeAjaxBehavior;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Check;
import org.apache.wicket.markup.html.form.CheckGroup;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.HiddenField;
import org.apache.wicket.markup.html.form.Radio;
import org.apache.wicket.markup.html.form.RadioGroup;
import org.apache.wicket.model.CompoundPropertyModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.model.util.CollectionModel;
import org.apache.wicket.spring.injection.annot.SpringBean;
import org.apache.wicket.markup.transformer.NoopOutputTransformerContainer;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import com.fis.cortex.access.custid.view.Account;
import com.fis.cortex.access.custid.view.AccountHolder;
import com.fis.cortex.access.custid.view.Card;
import com.fis.cortex.access.custid.view.CustIdCode;
import com.fis.cortex.access.custid.view.CustIdType;
import com.fis.cortex.access.custid.view.CustomerContextSummary;
import com.fis.cortex.access.custid.view.Message;
import com.fis.cortex.transport.core.dataholder.TransportList;
import com.fis.cortex.transport.custid.exception.CardNotFoundException;
import com.fis.cortex.transport.custid.exception.CortexWebServiceException;
import com.fis.cortex.transport.custid.exception.CustomerNotFoundException;
import com.fis.cortex.transport.custid.services.CustomerService;
import com.metavante.cortexonline.wicket.CortexSession;
import com.fis.cortex.wicket.base.CortexAjaxButton;
import com.fis.cortex.wicket.base.CortexAjaxLink;
import com.fis.cortex.wicket.base.CortexModalWindow;
import com.metavante.cortex.transport.objects.core.Institution;
import com.metavante.cortex.transport.objects.money.Currency;
import com.metavante.cortexonline.wicket.components.ContextPanel;
import com.metavante.cortexonline.wicket.components.buttonbox.BoxedButton;
import com.metavante.cortexonline.wicket.components.buttonbox.BoxedSubmitButton;
import com.metavante.cortexonline.wicket.components.buttonbox.ButtonBox;
import com.metavante.cortexonline.wicket.components.componentline.TextFieldLine;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowPanel;
import com.metavante.cortexonline.wicket.content.cust.components.CustomerIdTypeSelectLine;
import com.metavante.cortexonline.wicket.metadata.AcsInfo;
import org.apache.wicket.Component;
import org.apache.wicket.extensions.ajax.markup.html.modal.ModalWindow;
import com.cortex.common.exception.serverException;

import com.cortex.common.startup.StartupXmlConfigData;
import com.cortex.cust.bre.common.constant.serverConstantBre;

import com.cortex.common.lib.debugLib;
import com.fis.cortex.util.Util;
import org.apache.wicket.behavior.AttributeAppender;

/**
 * Customer Details screen. This is the main screen from which user will
 * configure accounts to user
 *
 * @author schinnas
 * @version $Id:
 * //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/assigncard/panels/CustomerDetailsPanel.java#2
 * $ $DateTime: 2019/03/28 02:47:01 $ $Author: dtoca $
 */
@AcsInfo(acsItem = "agn_crd_det")
public class CustomerDetailsPanel extends WorkFlowPanel
{
  private static final long serialVersionUID = 1L;

  private String custIdValue;
  private String custIdCodeValue;
  private String cardNumber;
  private String embossname;
  private ButtonBox buttons;
  private ButtonBox issueCardButtons;
  private ButtonBox assignCardButtons;
  private String customerName;
  private CortexModalWindow accountZoom;
  private CortexModalWindow msgZoom;
  private Label customerLabel;
  private Label nameTextLabel;
  private CustomerContextSummary customerContextSummary;
  private CustIdType custIdTypeValue;
  private CustIdCode custIdCode;
  private AccountHolder accountHolder;
  private List<Account> originalAccountList;
  private List<Account> selectedAccountList;
  private Card card;
  private Message popupMsg;
  private WebMarkupContainer outputArea;
  
  @SpringBean(name = "transportCustomerIdService")
  private CustomerService customerService;

  private boolean custAllowSecondaryCards;

  private final static String CLASSNAME = "CustomerDetailsPanel";

  protected Institution institution;

  CortexAjaxButton submitAjaxButton;
  CortexAjaxButton accAjaxButton;
  BoxedButton boxedButton;
  BoxedSubmitButton assignCardLink;
  BoxedSubmitButton assignCardCancel;
  BoxedSubmitButton generateCardButton;
  ListView<Account> listView;
  CustomerIdTypeSelectLine idTypeSelectLine;
  TextFieldLine<String> tlf;
  TextFieldLine<String> nameOnCardTlf;
  CortexAjaxLink<Object> additionalAccounts;
  Account account;
  Currency currency;
  Form<Void> form;
  TextFieldLine<String> panField;
  MessageDisplayPanel messagePanel;
  RadioGroup<Account> accListRadioGroup;
  CheckGroup<Account> checkGroup;
  Account radioGroupModel;
  Collection<Account> listAccount;
  String dlftAcc;
  String selectedAcc;
  HiddenField<String> hf1;
  AccountZoomPanel accountZoomPanel;

  Collection<Account> listAccountTemp;

  // construction	
  public CustomerDetailsPanel(CustomerContextSummary customerContextSummary)
  {
    /*
		Evaluate AllowSecondaryCards parameter in cortexOnlineCfg.xml
     */
    try
    {
      debugLib.logDetail(CLASSNAME, "CustomerDetailsPanel start");
      // Ensure that the path to the runner script is set in the configuration file
      StartupXmlConfigData startupXmlData = StartupXmlConfigData.getInstance();
      debugLib.logDetail(CLASSNAME, "StartupXmlConfigData instance created");
      String tsRemoteRunner = startupXmlData.getParameterFileItem(serverConstantBre.ALLOW_SECONDARY_CARDS);
      debugLib.logDetail(CLASSNAME, "serverConstantBre ALLOW_SECONDARY_CARDS " + serverConstantBre.ALLOW_SECONDARY_CARDS);
      debugLib.logDetail(CLASSNAME, "tsRemoteRunner " + tsRemoteRunner);

      this.custAllowSecondaryCards = (tsRemoteRunner != null && "true".equalsIgnoreCase(tsRemoteRunner.trim()));

      debugLib.logDetail(CLASSNAME, "custAllowSecondaryCards " + custAllowSecondaryCards);
    }
    catch (Exception e)
    {
      this.error(this.getString(e.getMessage()));
    }

    this.listAccountTemp = new ArrayList<>();

    this.setDefaultModel(new CompoundPropertyModel<AssignCardHomePanel>(this));
    this.institution = customerContextSummary.getInstitution();
    if (customerContextSummary.getCustIdType() != null)
    {
      custIdTypeValue = customerContextSummary.getCustIdType();
    }
    if (customerContextSummary.getCustIdCode() != null)
    {
      custIdCode = customerContextSummary.getCustIdCode();
      this.custIdCodeValue = custIdCode.getCode();
    }

    if (customerContextSummary.getAccountHolder() == null)
    {
      try
      {
        String user = CortexSession.get().getUserName();
        customerService.getAccounts(this.institution.getRealId(), custIdCode.getCustomerId(), custIdCode.getCustIdType().getCustId(), custIdCode.getCode(), user);
        this.accountHolder = customerService.getAccountHolder(custIdCode.getCustomerId());
      }
      catch (CortexWebServiceException exp)
      {
        this.error(this.getString(exp.getMessage()));
      }
      catch (CustomerNotFoundException cnfe)
      {
        this.error(this.getString(cnfe.getMessage()));
      }
      this.listAccount = new ArrayList<>();
    }
    else
    {
      this.accountHolder = customerContextSummary.getAccountHolder();
      this.radioGroupModel = customerContextSummary.getDlftAcc();
      this.listAccount = customerContextSummary.getSelectedList();
      dlftAcc = this.radioGroupModel.getRealId() + "^";
      for (Account acc : this.listAccount)
      {
        dlftAcc += acc.getRealId() + "~";
      }
      this.embossname = this.accountHolder.getEmbossName();
    }

    if (this.accountHolder != null)
    {
      this.originalAccountList = this.accountHolder.getAccounts();
    }

    currency = new Currency(null, null, (short) 0, null);
    account = new Account();
    account.setCurrency(currency);
    account.setInstitution(institution);
    popupMsg = new Message();
    form = new Form<Void>("form")
    {
      private static final long serialVersionUID = 1L;

      @Override
      protected void onSubmit()
      {
        CustomerDetailsPanel.this.setAccountsSelection();
      }

      @Override
      protected void onError()
      {
      }
    };
    
    boolean accCompVisibility = customerContextSummary.isIssueCardCancel() || customerContextSummary.getAccountHolder() == null;
    this.add(form);
    this.addContext(this);
    this.addControls(form, accCompVisibility);
    this.addAccountTables(form, accCompVisibility);
    this.addButtons(form);
    this.addLinkButtons(form, accCompVisibility);
    this.addPanComponent(form, !accCompVisibility);
    this.addIssueCardBtn(form, !accCompVisibility);
    this.setAssignBarVisibility();
    this.form.setOutputMarkupId(true);
  }

  protected void addContext(WebMarkupContainer parent)
  {
    parent.add(new ContextPanel("context").addInstitution(this.institution).setEnabled(false));
  }

  private void addAccountTables(final MarkupContainer parent, boolean visibility)
  {
    this.outputArea = new WebMarkupContainer("table_area");
    this.outputArea.setOutputMarkupId(true);
    this.outputArea.setOutputMarkupPlaceholderTag(true);
    parent.add(this.outputArea);

    WebMarkupContainer c;
    this.outputArea.add(c = new WebMarkupContainer("table")
    {
      private static final long serialVersionUID = 1L;

      @Override
      public boolean isVisible()
      {
        return true;
      }
    });

    this.addActionsTable(c, visibility);
  }

  private void addActionsTable(MarkupContainer parent, final boolean visibility)
  {
    AttributeModifier behaviour = new AttributeModifier("colspan", new Model<>(String.format("%d", 6)));
    parent.add(new Label("accountList", this.getString("account_list")).add(behaviour));
    parent.add(new Label("default", this.getString("agn_card_dlft")));
    parent.add(new Label("link", this.getString("agn_card_link")));
    parent.add(new Label("type", this.getString("agn_card_type")));
    parent.add(new Label("status", this.getString("agn_card_status")));
    parent.add(new Label("currency", this.getString("agn_card_currency")));
    parent.add(new Label("account", this.getString("agn_card_account")));
    parent.add(new NoopOutputTransformerContainer("databreakline1").add(behaviour));
    parent.add(new NoopOutputTransformerContainer("databreakline2").add(behaviour));
    parent.add(hf1 = new HiddenField<>("h1", new PropertyModel<>(this, "dlftAcc")));
    this.accListRadioGroup = new RadioGroup<>("accountListRg", new PropertyModel<>(this, "radioGroupModel"));
    this.accListRadioGroup.add(new OnChangeAjaxBehavior()
    {
      private static final long serialVersionUID = 1L;

      @Override
      protected void onUpdate(AjaxRequestTarget target)
      {
        CustomerDetailsPanel.this.radioGroupModel = CustomerDetailsPanel.this.accListRadioGroup.getModelObject();
        target.addComponent(CustomerDetailsPanel.this.accListRadioGroup);

      }
    });
    
    List<Account> accountsList = null;
    if (this.accountHolder != null)
    {
      accountsList = new PropertyModel<List<Account>>(this.accountHolder, "accounts").getObject();
    }
    Account dftAcc = new PropertyModel<Account>(this, "radioGroupModel").getObject();
    if (dftAcc == null && accountsList != null && !accountsList.isEmpty())
    {
      this.radioGroupModel = accountsList.get(0);

      if (CustomerDetailsPanel.this.custAllowSecondaryCards == false)
      {
        debugLib.logDetail(CLASSNAME, "AllowSecondaryCards false - checkbox selected on the first account ");
        listAccount.add(accountsList.get(0));
      }
    }
    else
    {
      this.accListRadioGroup.setDefaultModelObject(dftAcc);

      if (CustomerDetailsPanel.this.custAllowSecondaryCards == false)
      {
        debugLib.logDetail(CLASSNAME, "AllowSecondaryCards false - checkbox selected on default account");
        listAccount.add(dftAcc);
      }
    }
    
    this.accListRadioGroup.setOutputMarkupId(true);
    this.accListRadioGroup.setOutputMarkupPlaceholderTag(true);
    parent.add(this.accListRadioGroup);
    this.checkGroup = new CheckGroup<>("checkGroup", new PropertyModel<ArrayList<Account>>(this, "listAccount"));
    if (this.accountHolder == null)
    {
      this.accountHolder = new AccountHolder();
    }

    this.listView = new ListView<Account>("tablerow", new PropertyModel<List<Account>>(this.accountHolder, "accounts"))
    {
      private static final long serialVersionUID = 1L;

      @Override
      protected void populateItem(final ListItem<Account> item)
      {
        debugLib.logDetail(CLASSNAME, "CustomerDetailsPanel.this.custAllowSecondaryCards " + CustomerDetailsPanel.this.custAllowSecondaryCards);

        Check<Account> accountCheck = new Check<>("acclink", item.getModel());
        Radio<Account> rb = new Radio<>("accDlft", item.getModel());

        if (CustomerDetailsPanel.this.custAllowSecondaryCards)
        {
          debugLib.logDetail(CLASSNAME, "AllowSecondaryCards: true");
          accountCheck.setEnabled(true);
        }
        else
        {
          debugLib.logDetail(CLASSNAME, "AllowSecondaryCards: false, to add onclick method");
          accountCheck.setEnabled(false);
          rb.add(new AttributeAppender("onclick", new Model("onselectAccount(this)"), ""));
        }
        
        item.add(rb);
        item.add(accountCheck);
        item.add(new Label("accType", new PropertyModel<String>(item.getModel(), "accountType")));
        item.add(new Label("accStatus", new PropertyModel<String>(item.getModel(), "status")));
        item.add(new Label("accCurrency", new PropertyModel<String>(item.getModelObject().getCurrency(), "code")));
        item.add(new Label("custAccount", new PropertyModel<String>(item.getModel(), "accountNumber")));
      }
    };
    
    this.listView.setReuseItems(true);
    this.listView.setEnabled(visibility);
    this.checkGroup.add(this.listView);
    this.checkGroup.setOutputMarkupId(true);
    this.checkGroup.setOutputMarkupPlaceholderTag(true);

    this.accListRadioGroup.add(this.checkGroup);

    // Contents of the table
    //parent.add(this.listView);
  }

  private void addControls(WebMarkupContainer parent, boolean visibility)
  {
    StringBuilder strBuilder = new StringBuilder();
    if (this.accountHolder != null)
    {
      strBuilder.append(accountHolder.getTitle() != null ? accountHolder.getTitle() + " " : " ");
      strBuilder.append(accountHolder.getFirstName() != null ? accountHolder.getFirstName() + " " : " ");
      strBuilder.append(accountHolder.getLastName() != null ? accountHolder.getLastName() : " ");
      this.customerName = strBuilder.toString();
    }
    parent.add(this.nameTextLabel = new Label("nameText", this.getString("name_text")));
    parent.add(this.customerLabel = new Label("name", this.customerName));
    this.nameTextLabel.setOutputMarkupId(true);
    this.nameTextLabel.setOutputMarkupPlaceholderTag(true);
    this.customerLabel.setOutputMarkupId(true);
    this.customerLabel.setOutputMarkupPlaceholderTag(true);
    this.nameOnCardTlf = new TextFieldLine<>("nameOnCard", this.getString("name_on_card"), new PropertyModel<>(this, "embossname"));
    this.nameOnCardTlf.setMaxLength(51);
    this.nameOnCardTlf.setMandatory(true);
    this.nameOnCardTlf.setEnabled(true);
    this.nameOnCardTlf.setOutputMarkupId(true);
    this.nameOnCardTlf.setOutputMarkupPlaceholderTag(true);
    if (this.customerName != null && this.embossname == null)
    {
      if (this.customerName.length() > 51)
      {
        this.embossname = this.customerName.substring(0, 51).trim();
      }
      else
      {
        this.embossname = this.customerName.trim();
      }
    }
    else if (this.embossname != null)
    {
      this.nameOnCardTlf.setEnabled(false);
    }
    parent.add(this.nameOnCardTlf);
    accountZoom = new CortexModalWindow("zoomAccount", new PropertyModel<Account>(CustomerDetailsPanel.this, "account"), this.getString("get_additional_accounts"))
    {
      private static final long serialVersionUID = 1L;

      protected Component createContent(String id)
      {
        if (getDefaultModelObject() == null)
        {
          return null;
        }
        else
        {
          return CustomerDetailsPanel.this.accountZoomPanel = new AccountZoomPanel(CustomerDetailsPanel.this, accountZoom, new PropertyModel<>(CustomerDetailsPanel.this, "account"), id);
        }
      }
    };
    accountZoom.setWindowClosedCallback(new ModalWindow.WindowClosedCallback()
    {
      private static final long serialVersionUID = 1L;
      private boolean isValidAccList = false;

      public void onClose(AjaxRequestTarget target)
      {
        Account returnedAcc = new PropertyModel<Account>(CustomerDetailsPanel.this, "account").getObject();
        if (returnedAcc != null && returnedAcc.getAccountHolder() != null && returnedAcc.getAccountHolder().getAccounts() != null && returnedAcc.getAccountHolder().getAccounts().size() > 0)
        {
          CustomerDetailsPanel.this.selectedAccountList = returnedAcc.getAccountHolder().getAccounts();
          f1:
          for (Account selectedAccount : CustomerDetailsPanel.this.selectedAccountList)
          {
            for (Account originalAccount : CustomerDetailsPanel.this.originalAccountList)
            {
              if (selectedAccount.getAccountNumber().equalsIgnoreCase(originalAccount.getAccountNumber()))
              {
                isValidAccList = true;
                CustomerDetailsPanel.this.messagePanel.setDisplayMessage(CustomerDetailsPanel.this.getString("acc_already_exist_msg"));
                CustomerDetailsPanel.this.messagePanel.setAction("addAdditionAccounts");
                CustomerDetailsPanel.this.msgZoom.refreshContent();
                CustomerDetailsPanel.this.msgZoom.show(target);
                break f1;
              }
            }
          }
        }
        if (!isValidAccList && CustomerDetailsPanel.this.selectedAccountList != null)
        {
          CustomerDetailsPanel.this.originalAccountList.addAll(CustomerDetailsPanel.this.selectedAccountList);
          CustomerDetailsPanel.this.listAccount.addAll(CustomerDetailsPanel.this.selectedAccountList);
        }
        setAccountsSelection();
        target.addComponent(CustomerDetailsPanel.this.outputArea);
      }
    });

    accountZoom.setOutputMarkupId(true);
    parent.add(accountZoom);
    this.idTypeSelectLine = new CustomerIdTypeSelectLine("custIdType", this.getString("cust_id_type"), this.institution.getCode(), new PropertyModel<CustIdType>(this, "custIdTypeValue"));
    this.idTypeSelectLine.setMandatory(true);
    this.idTypeSelectLine.setExpanded(true);
    this.idTypeSelectLine.setEnabled(false);
    this.idTypeSelectLine.setOutputMarkupId(true);
    this.idTypeSelectLine.setOutputMarkupPlaceholderTag(true);
    parent.add(this.idTypeSelectLine);
    this.tlf = new TextFieldLine<>("custIdCode", this.getString("cust_id_code"), new PropertyModel<>(this, "custIdCodeValue"));
    this.tlf.setMaxLength(32);
    this.tlf.setMandatory(true);
    this.tlf.setEnabled(false);
    this.tlf.setOutputMarkupId(true);
    this.tlf.setOutputMarkupPlaceholderTag(true);
    parent.add(this.tlf);
    msgZoom = new CortexModalWindow("messageZoom", new PropertyModel<Message>(CustomerDetailsPanel.this, "popupMsg"), this.getString("adding_addn_accounts"))
    {
      private static final long serialVersionUID = 1L;

      protected Component createContent(String id)
      {
        if (getDefaultModelObject() == null)
        {
          return null;
        }
        else
        {
          CustomerDetailsPanel.this.messagePanel = new MessageDisplayPanel(CustomerDetailsPanel.this, msgZoom, new PropertyModel<Message>(CustomerDetailsPanel.this, "popupMsg"), id);
          return CustomerDetailsPanel.this.messagePanel;
        }
      }

    };
    msgZoom.setInitialHeight(150);
    msgZoom.setWindowClosedCallback(new ModalWindow.WindowClosedCallback()
    {
      private static final long serialVersionUID = 1L;

      public void onClose(AjaxRequestTarget target)
      {
        setAccountsSelection();
        Message panelMsg = new PropertyModel<Message>(CustomerDetailsPanel.this, "popupMsg").getObject();
        if ("assignCardPanel".equalsIgnoreCase(CustomerDetailsPanel.this.popupMsg.getAction()))
        {
          CustomerDetailsPanel.this.refreshIssueCardPanel(target);
        }
        else if ("confirm".equalsIgnoreCase(panelMsg.getAction()))
        {
          CustomerDetailsPanel.this.processIssuedCard(target);
        }
        else if ("success".equalsIgnoreCase(panelMsg.getAction()))
        {
          CustomerDetailsPanel.this.refreshSearchCriteriaPanel(target);
        }
        else
        {
          CustomerDetailsPanel.this.refreshIssueCardPanel(target);
        }

      }
    });
    msgZoom.setOutputMarkupId(true);
    parent.add(msgZoom);

  }

  protected void addButtons(WebMarkupContainer parent)
  {
    this.buttons = new ButtonBox("buttons");
    this.buttons.addButton(new BoxedSubmitButton(new Model<>(this.getString("find_customer")))
    {
      private static final long serialVersionUID = 1L;

      @Override
      public void onSubmit()
      {
        CustomerDetailsPanel.this.goSearchCustomerDetails();
      }

    });
    this.buttons.setOutputMarkupId(true);
    this.buttons.setOutputMarkupPlaceholderTag(true);
    parent.add(this.buttons.setEnabled(false));

  }

  
  public static final Long parseStringToLong(String input)
  {
    if (input == null || input.trim().isEmpty()) 
      return -1L;

    try
    {
      return Long.valueOf(input.trim());
    }
    catch (NumberFormatException e)
    {
      return -1L;
    }
  }
  
  protected void addLinkButtons(WebMarkupContainer parent, boolean visibility)
  {
    this.assignCardButtons = new ButtonBox("assignCardButtons", false);
    this.assignCardLink = new BoxedSubmitButton(new Model<>(this.getString("assign_card_link_btn")))
    {
      private static final long serialVersionUID = 1L;

      @Override
      public void onSubmit()
      {
        Util.logInfo("custAllowSecondaryCards: {}", CustomerDetailsPanel.this.custAllowSecondaryCards);
        
        if (CustomerDetailsPanel.this.custAllowSecondaryCards)
        {
          if (CustomerDetailsPanel.this.listAccount != null && CustomerDetailsPanel.this.listAccount.isEmpty())
          {
            this.error(this.getString("link_account_not_selected"));
            return;
          }
          if (CustomerDetailsPanel.this.accountHolder != null)
          {
            CustomerDetailsPanel.this.accountHolder.setEmbossName(CustomerDetailsPanel.this.embossname);
          }
          
          for(Account account : CustomerDetailsPanel.this.listAccount)
          {
            Util.logInfo("######## Assign AccountNumber: {}", account.getAccountNumber());
            
            if(CustomerDetailsPanel.this.countActiveCardsByAccountNumber(account.getAccountNumber()) >= 1)
            {
              this.error(String.format("%s : %s", account.getAccountNumber(), this.getString("error_active_card_associated")));
              return;
            }
          }
          
          CustomerDetailsPanel.this.customerContextSummary = new CustomerContextSummary(CustomerDetailsPanel.this.institution, CustomerDetailsPanel.this.custIdTypeValue, CustomerDetailsPanel.this.custIdCode, CustomerDetailsPanel.this.accountHolder);
          CustomerDetailsPanel.this.customerContextSummary.setDlftAcc(CustomerDetailsPanel.this.radioGroupModel);
          CustomerDetailsPanel.this.customerContextSummary.setSelectedList(CustomerDetailsPanel.this.listAccount);
          CustomerDetailsPanel.this.complete(new AssignCardMainPanel.GoSearchCustomerResult(CustomerDetailsPanel.this.customerContextSummary));
        }
        else
        {
          if (CustomerDetailsPanel.this.radioGroupModel == null)
          {
            this.error(this.getString("link_account_not_selected"));
            return;
          }
          debugLib.logDetail(CLASSNAME, "Assign Card custAllowSecondaryCards false");
          if (CustomerDetailsPanel.this.accountHolder != null)
          {
            CustomerDetailsPanel.this.accountHolder.setEmbossName(CustomerDetailsPanel.this.embossname);
          }
          
          Util.logInfo("######## Radio AccountNumber: {}", CustomerDetailsPanel.this.radioGroupModel.getAccountNumber());
          if(CustomerDetailsPanel.this.countActiveCardsByAccountNumber(CustomerDetailsPanel.this.radioGroupModel.getAccountNumber()) >= 1)
          {
            this.error(this.getString("error_active_card_associated"));
            return;
          }
          
          CustomerDetailsPanel.this.listAccountTemp.removeAll(CustomerDetailsPanel.this.listAccountTemp);
          CustomerDetailsPanel.this.listAccountTemp.add(CustomerDetailsPanel.this.radioGroupModel);

          CustomerDetailsPanel.this.customerContextSummary = new CustomerContextSummary(CustomerDetailsPanel.this.institution, CustomerDetailsPanel.this.custIdTypeValue, CustomerDetailsPanel.this.custIdCode, CustomerDetailsPanel.this.accountHolder);
          CustomerDetailsPanel.this.customerContextSummary.setDlftAcc(CustomerDetailsPanel.this.radioGroupModel);
          CustomerDetailsPanel.this.customerContextSummary.setSelectedList(CustomerDetailsPanel.this.listAccountTemp);
          CustomerDetailsPanel.this.complete(new AssignCardMainPanel.GoSearchCustomerResult(CustomerDetailsPanel.this.customerContextSummary));
        }
      }

    };
    this.assignCardButtons.addButton(assignCardLink);

    this.generateCardButton = new BoxedSubmitButton(new Model<>(this.getString("agn_card_generate_card_btn")))
    {
      private static final long serialVersionUID = 1L;

      @Override
      public void onSubmit()
      {
        if (CustomerDetailsPanel.this.custAllowSecondaryCards)
        {
          if (CustomerDetailsPanel.this.listAccount != null && CustomerDetailsPanel.this.listAccount.isEmpty())
          {
            this.error(this.getString("link_account_not_selected"));
            return;
          }
          debugLib.logDetail(CLASSNAME, "Generate Card custAllowSecondaryCards true");
          if (CustomerDetailsPanel.this.accountHolder != null)
          {
            CustomerDetailsPanel.this.accountHolder.setEmbossName(CustomerDetailsPanel.this.embossname);
          }
          
          for(Account account : CustomerDetailsPanel.this.listAccount)
          {
            Util.logInfo("######## Generate AccountNumber: {}", account.getAccountNumber());
            
            if(CustomerDetailsPanel.this.countActiveCardsByAccountNumber(account.getAccountNumber()) >= 1)
            {
              this.error(String.format("%s : %s", account.getAccountNumber(), this.getString("error_active_card_associated")));
              return;
            }
          }
          
          CustomerDetailsPanel.this.setLinkedAccount(CustomerDetailsPanel.this.listAccount, CustomerDetailsPanel.this.accountHolder);
        }
        else
        {
          if (CustomerDetailsPanel.this.radioGroupModel == null)
          {
            this.error(this.getString("link_account_not_selected"));
            return;
          }
          debugLib.logDetail(CLASSNAME, "Generate Card custAllowSecondaryCards false");
          if (CustomerDetailsPanel.this.accountHolder != null)
          {
            CustomerDetailsPanel.this.accountHolder.setEmbossName(CustomerDetailsPanel.this.embossname);
          }
          
          Util.logInfo("######## Generate AccountNumber: {}", CustomerDetailsPanel.this.radioGroupModel.getAccountNumber());
          if(CustomerDetailsPanel.this.countActiveCardsByAccountNumber(CustomerDetailsPanel.this.radioGroupModel.getAccountNumber()) >= 1)
          {
            this.error(this.getString("error_active_card_associated"));
            return;
          }
          
          CustomerDetailsPanel.this.listAccountTemp.removeAll(CustomerDetailsPanel.this.listAccountTemp);
          CustomerDetailsPanel.this.listAccountTemp.add(CustomerDetailsPanel.this.radioGroupModel);
          CustomerDetailsPanel.this.setLinkedAccount(CustomerDetailsPanel.this.listAccountTemp, CustomerDetailsPanel.this.accountHolder);
        }

        CustomerDetailsPanel.this.customerContextSummary = new CustomerContextSummary(CustomerDetailsPanel.this.institution, CustomerDetailsPanel.this.custIdTypeValue, CustomerDetailsPanel.this.custIdCode, CustomerDetailsPanel.this.accountHolder);
        CustomerDetailsPanel.this.customerContextSummary.setDlftAcc(CustomerDetailsPanel.this.radioGroupModel);
        CustomerDetailsPanel.this.complete(new AssignCardMainPanel.GoGenerateCard(CustomerDetailsPanel.this.customerContextSummary));
      }

    };
    this.generateCardButton.setOutputMarkupId(true);
    this.generateCardButton.setOutputMarkupPlaceholderTag(true);
    this.assignCardButtons.addButton(this.generateCardButton);

    this.accAjaxButton = new CortexAjaxButton("button",
            new Model<>(this.getString("add_additional_acc_btn")),
            CustomerDetailsPanel.this.form)
    {
      private static final long serialVersionUID = 1L;

      @Override
      protected void onSubmit(AjaxRequestTarget target, Form<?> form)
      {
        CustomerDetailsPanel.this.accountZoom.refreshContent();
        CustomerDetailsPanel.this.accountZoom.show(target);
        CustIdType idTypeModel = new PropertyModel<CustIdType>(CustomerDetailsPanel.this, "custIdTypeValue").getObject();
        CustomerDetailsPanel.this.accountZoomPanel.setCustId(CustomerDetailsPanel.this.custIdCode.getCode(), idTypeModel.getCustId());
      }

      @Override
      protected void onError(AjaxRequestTarget target, Form<?> form)
      {
        target.addComponent(CustomerDetailsPanel.this.form);
      }
    };
    this.assignCardButtons.addButton(accAjaxButton);

    this.assignCardCancel = new BoxedSubmitButton(new Model<String>(this.getString("assign_card_cancel")))
    {
      private static final long serialVersionUID = 1L;

      @Override
      public void onSubmit()
      {
        CustomerDetailsPanel.this.customerContextSummary = new CustomerContextSummary(CustomerDetailsPanel.this.institution, CustomerDetailsPanel.this.custIdTypeValue, CustomerDetailsPanel.this.custIdCode, null);
        //CustomerDetailsPanel.this.setAccountsSelection();
        CustomerDetailsPanel.this.complete(new AssignCardMainPanel.GoSearchCriteriaPanel(CustomerDetailsPanel.this.customerContextSummary));
      }
    };
    this.assignCardCancel.setDefaultFormProcessing(false);
    this.assignCardButtons.addButton(assignCardCancel);
    this.assignCardButtons.setEnabled(visibility);
    this.assignCardButtons.setOutputMarkupId(true);
    this.assignCardButtons.setOutputMarkupPlaceholderTag(true);
    parent.add(this.assignCardButtons);
  }

  protected Long countActiveCardsByAccountNumber(String accountnumber)
  {
    return customerService.countActiveCardsByAccountNumber(accountnumber);
  }

  protected void addPanComponent(WebMarkupContainer parent, boolean visibility)
  {
    this.panField = new TextFieldLine<>("panNumber", this.getString("agn_card_number"), new PropertyModel<>(this, "cardNumber"));
    this.panField.setMaxLength(19);
    this.panField.setMandatory(true);
    this.panField.setOutputMarkupId(true);
    this.panField.setOutputMarkupPlaceholderTag(true);
    this.panField.setVisible(visibility);
    parent.add(this.panField);
  }

  protected void addIssueCardBtn(WebMarkupContainer parent, boolean visibility)
  {

    this.issueCardButtons = new ButtonBox("issueCardBtn");
    this.submitAjaxButton = new CortexAjaxButton("button", new Model<String>(this.getString("issue_card_button")), CustomerDetailsPanel.this.form)
    {
      private static final long serialVersionUID = 1L;

      @Override
      protected void onSubmit(AjaxRequestTarget target, Form<?> form)
      {
        CustomerDetailsPanel.this.addIssueCard(CustomerDetailsPanel.this.accountHolder, target);
        CustomerDetailsPanel.this.setAccountsSelection();

      }

      @Override
      protected void onError(AjaxRequestTarget target, Form<?> form)
      {
        CustomerDetailsPanel.this.setAccountsSelection();

      }
    };

    this.submitAjaxButton.setOutputMarkupId(true);
    this.submitAjaxButton.setOutputMarkupPlaceholderTag(true);
    this.issueCardButtons.addButton(this.submitAjaxButton);
    this.boxedButton = (BoxedButton) new BoxedSubmitButton(new Model<String>(getString("issue_card_cancel")))
    {
      private static final long serialVersionUID = 6367619821111719002L;

      @Override
      public void onSubmit()
      {
        CustomerDetailsPanel.this.customerContextSummary = new CustomerContextSummary(CustomerDetailsPanel.this.institution, CustomerDetailsPanel.this.custIdTypeValue, CustomerDetailsPanel.this.custIdCode, CustomerDetailsPanel.this.accountHolder);
        CustomerDetailsPanel.this.customerContextSummary.setDlftAcc(CustomerDetailsPanel.this.radioGroupModel);
        CustomerDetailsPanel.this.customerContextSummary.setSelectedList(CustomerDetailsPanel.this.listAccount);
        CustomerDetailsPanel.this.customerContextSummary.setIssueCardCancel(true);
        CustomerDetailsPanel.this.complete(new AssignCardMainPanel.GoSearchCustomerResult(CustomerDetailsPanel.this.customerContextSummary));
      }
    }.setDefaultFormProcessing(false);
    this.boxedButton.setOutputMarkupId(true);
    this.boxedButton.setOutputMarkupPlaceholderTag(true);
    this.issueCardButtons.addButton(this.boxedButton);
    this.issueCardButtons.setVisible(visibility);
    this.issueCardButtons.setOutputMarkupId(true);
    this.issueCardButtons.setOutputMarkupPlaceholderTag(true);
    parent.add(this.issueCardButtons);
  }

  // actions
  protected void goSearchCustomerDetails()
  {
    CustIdType IdType = new PropertyModel<CustIdType>(this, "custIdTypeValue").getObject();
    String idCode = new PropertyModel<String>(this, "custIdCodeValue").getObject();
    CustIdCode code = new CustIdCode();
    code.setCode(idCode);
    code.setCustIdType(IdType);

    Util.logInfo("######## goSearchCustomerDetails");
    try
    {
      String user = CortexSession.get().getUserName();
      this.custIdCode = customerService.getCustIdCode(this.institution.getRealId(), IdType.getCustId(), code.getCode(), user);
      if (this.custIdCode == null)
      {
        this.error(this.getString("cust_id_code_invalid"));
        return;
      }
    }
    catch (CortexWebServiceException exp)
    {
      this.error(this.getString(exp.getMessage()));
      return;
    }
    this.customerContextSummary = new CustomerContextSummary(this.institution, IdType, this.custIdCode);
    this.complete(new AssignCardMainPanel.GoSearchCustomerResult(this.customerContextSummary));
  }

  protected void addIssueCard(AccountHolder accountHolder, AjaxRequestTarget requestTarget)
  {
    String panNumber = new PropertyModel<String>(CustomerDetailsPanel.this, "cardNumber").getObject();
    if (panNumber == null)
    {
      this.error(this.getString("card_number_empty"));
      return;
    }
    else
    {
      try
      {
        String cardNumber = null;
        PanCryptor panCryptor = BasicPanCryptor.getInstance();
        cardNumber = panCryptor.encryptPan(panNumber);
        this.card = customerService.getCard(cardNumber, this.institution.getRealId());
        if (this.card == null)
        {
          this.messagePanel.setDisplayMessage(this.getString("card_not_found"));
          setTitleForCardValidation(requestTarget);
        }
        else if (!this.card.getAccountHolder().getCustomerCode().equalsIgnoreCase("99999999"))
        {
          this.messagePanel.setDisplayMessage(this.getString("card_assign_another_cust"));
          setTitleForCardValidation(requestTarget);
        }
        else if (this.card.getBranch() == null)
        {
          this.messagePanel.setDisplayMessage(this.getString("card_branch_empty"));
          setTitleForCardValidation(requestTarget);
        }
        else
        {
          this.card.setPanDisplay(panNumber);
          setTitleConfirmationMsg(requestTarget, this.card);
        }
      }
      catch (PanEncryptionFailedException e)
      {
        this.messagePanel.setDisplayMessage(this.getString("agn_card_encryption_failed"));
        setTitleForCardValidation(requestTarget);
      }
      catch (CardNotFoundException exp)
      {
        this.messagePanel.setDisplayMessage(this.getString("card_not_found"));
        setTitleForCardValidation(requestTarget);
      }

    }
  }

  protected void refreshIssueCardPanel(AjaxRequestTarget requestTarget)
  {
    this.listView.setEnabled(true);
    this.assignCardButtons.setEnabled(true);
    this.panField.setVisible(false);
    if (this.issueCardButtons.isVisible())
    {
      this.issueCardButtons.setVisible(false);
    }
    this.setAccountsSelection();
    requestTarget.addComponent(CustomerDetailsPanel.this.assignCardButtons);
    requestTarget.addComponent(CustomerDetailsPanel.this.panField);
    requestTarget.addComponent(CustomerDetailsPanel.this.issueCardButtons);
    requestTarget.addComponent(CustomerDetailsPanel.this.outputArea);
  }

  protected void refreshSearchCriteriaPanel(AjaxRequestTarget requestTarget)
  {
    this.custIdCodeValue = "";
    this.custIdTypeValue.setCustId(-1L);
    this.customerLabel.setVisible(false);
    this.nameTextLabel.setVisible(false);
    this.nameOnCardTlf.setVisible(false);
    this.outputArea.setVisible(false);
    this.assignCardButtons.setVisible(false);
    this.listView.setVisible(false);
    this.panField.setVisible(false);
    this.issueCardButtons.setVisible(false);
    this.buttons.setEnabled(true);
    this.idTypeSelectLine.setEnabled(true);
    this.tlf.setEnabled(true);
    requestTarget.addComponent(this.tlf);
    requestTarget.addComponent(this.idTypeSelectLine);
    requestTarget.addComponent(this.buttons);
    requestTarget.addComponent(this.customerLabel);
    requestTarget.addComponent(this.nameTextLabel);
    requestTarget.addComponent(this.nameOnCardTlf);
    requestTarget.addComponent(this.panField);
    requestTarget.addComponent(this.assignCardButtons);
    requestTarget.addComponent(this.issueCardButtons);
    requestTarget.addComponent(this.outputArea);
  }

  protected void setTitleForCardValidation(AjaxRequestTarget requestTarget)
  {
    this.messagePanel.setAction("assignCardPanel");
    this.msgZoom.setTitle("Card Validation Error");
    this.msgZoom.refreshContent();
    this.msgZoom.show(requestTarget);
  }

  protected void setTitleConfirmationMsg(AjaxRequestTarget requestTarget, Card card)
  {
    this.messagePanel.setAction("confirmMsg");
    this.msgZoom.setTitle("Confirmation Message");
    this.popupMsg.setCardNumber(card.getPanDisplay());
    this.popupMsg.setCardProdDescription(card.getCardProduct().getCardProduct() + "  " + card.getCardProduct().getDescription());
    this.msgZoom.refreshContent();
    this.msgZoom.show(requestTarget);
    this.messagePanel.setMessageModel(this.popupMsg);
    this.setAccountsSelection();
    requestTarget.addComponent(this.outputArea);
  }

  protected void processIssuedCard(AjaxRequestTarget requestTarget)
  {
    if (this.card != null)
    {
      List<Account> accountList = new PropertyModel<List<Account>>(this.accountHolder, "accounts").getObject();
      CustIdType IdType = new PropertyModel<CustIdType>(this, "custIdTypeValue").getObject();
      String idCode = new PropertyModel<String>(this, "custIdCodeValue").getObject();
      String embossName = new PropertyModel<String>(this, "embossname").getObject();
      customerService.deleteCardLink(card);
      long customerId = 0L;
      try
      {
        customerId = customerService.getCustomerById(IdType.getCustId(), idCode);
      }
      catch (CustomerNotFoundException exception)
      {
        this.messagePanel.setDisplayMessage(exception.getMessage());
      }
      card.setEmbossedName(embossName);
      customerService.updateCard(card, getDefaultAccount(accountList), customerId);
      customerService.updateLinkForAccounts(card, getLinkAccounts(accountList));
      this.messagePanel.setAction("success");
      this.msgZoom.setTitle("Card Assignment");
      this.messagePanel.setDisplayMessage(this.getString("success_msg"));
      this.msgZoom.refreshContent();
      this.msgZoom.show(requestTarget);
      requestTarget.addComponent(this.outputArea);
    }
  }

  protected void setAccountsSelection()
  {
    //in Account selected is set to true then that checked would  not selected
    if (this.originalAccountList != null)
    {
      for (Account acc1 : this.originalAccountList)
      {

        if ((this.radioGroupModel != null && acc1.getRealId() == this.radioGroupModel.getRealId()) || this.accListRadioGroup.getDefaultModelObject() != null && acc1.getRealId() == ((Account) this.accListRadioGroup.getDefaultModelObject()).getRealId())
        {
          CustomerDetailsPanel.this.accListRadioGroup.setModel(new Model<>(acc1));
          break;
        }

      }
      if (this.radioGroupModel == null)
      {
        this.radioGroupModel = getDefaultAccount(this.originalAccountList);
      }
      if (this.listAccount != null && !this.listAccount.isEmpty())
      {
        this.checkGroup.setModel(new CollectionModel<>(this.listAccount));
      }
      else
      {
        this.listAccount = getLinkAccounts(this.originalAccountList);
        this.checkGroup.setModel(new CollectionModel<>(this.listAccount));
      }
    }
  }

  protected Account getDefaultAccount(List<Account> accountList)
  {
    Account out = null;
    String dacc = null;
    String accStr = new PropertyModel<String>(this, "dlftAcc").getObject();
    if (accStr != null && accountList != null && accountList.size() > 0)
    {
      dacc = accStr.substring(0, accStr.indexOf("^"));
      for (Account acc : accountList)
      {
        if (dacc != null & Long.parseLong(dacc) == acc.getRealId())
        {
          out = acc;
          break;
        }
      }
    }
    return out;
  }

  protected List<Account> getLinkAccounts(List<Account> accountList)
  {
    String accStr = new PropertyModel<String>(this, "dlftAcc").getObject();
    List<Account> listAccount = new ArrayList<>();
    if (accStr != null)
    {
      String selId = accStr.substring(accStr.indexOf("^") + 1, accStr.length() - 1);
      String[] selectedArr = selId.split("~");
      int i = 0;
      int j = selectedArr.length;
      for (Account acc : accountList)
      {
        if (selectedArr != null && selectedArr[i] != null && Long.parseLong(selectedArr[i]) == acc.getRealId())
        {
          acc.setSelected(true);
          listAccount.add(acc);
          i++;
          if (i >= j)
          {
            break;
          }
        }
      }
    }
    Account dlftAccount = getDefaultAccount(accountList);
    if (!listAccount.contains(dlftAccount))
    {
      listAccount.add(dlftAccount);
    }
    return listAccount;
  }

  protected void setAssignBarVisibility()
  {
    if (this.originalAccountList == null || this.originalAccountList != null && this.originalAccountList.size() == 0)
    {
      this.outputArea.setVisible(false);
      this.assignCardButtons.setVisible(false);
      this.nameTextLabel.setVisible(false);
      this.customerLabel.setVisible(false);
      this.nameOnCardTlf.setVisible(false);
      this.idTypeSelectLine.setEnabled(true);
      this.tlf.setEnabled(true);
      this.buttons.setEnabled(true);
    }
  }

  private void setLinkedAccount(Collection<Account> selectedAccounts,
          AccountHolder accHolder)
  {
    TransportList<Account> custAccountList = accHolder.getAccounts();
    if (!custAccountList.isEmpty() && !selectedAccounts.isEmpty())
    {
      for (Account selAccount : selectedAccounts)
      {
        for (Account customerAccount : custAccountList)
        {
          if (selAccount.getRealId() == customerAccount.getRealId())
          {
            customerAccount.setLinked(true);
            break;
          }

        }
      }
    }

  }

}
