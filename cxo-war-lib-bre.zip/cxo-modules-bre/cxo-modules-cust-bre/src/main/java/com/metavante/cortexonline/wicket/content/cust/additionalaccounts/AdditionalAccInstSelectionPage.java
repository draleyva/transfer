package com.metavante.cortexonline.wicket.content.cust.additionalaccounts;

import org.apache.wicket.PageParameters;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.spring.injection.annot.SpringBean;

import com.metavante.cortex.transport.objects.core.Institution;
import com.fis.cortex.transport.custid.services.CustomerService;
import com.metavante.cortexonline.wicket.BasePage;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlow;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowHolderPanel;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowManager;
import com.metavante.cortexonline.wicket.content.common.panels.SimpleSelectInstitutionPanel;
import com.metavante.cortexonline.wicket.content.cust.additionalaccounts.panels.AmendAccountsMainPanel;


/*
 * Add Additional Accounts Institution Selection page
 * 
 */

public class AdditionalAccInstSelectionPage extends BasePage implements
		WorkFlow {

	private static final int STATE_FAILURE = -1;
	private static final int STATE_START = 0;
	private static final int STATE_INSTSELECTED = 1;

	protected Institution institution;
	private WorkFlowHolderPanel panel;
	@SpringBean(name = "transportCustomerIdService")
	private CustomerService customerService;

	// construction
	public AdditionalAccInstSelectionPage(PageParameters parameters) {
		super(parameters);
		this.add(this.panel = new WorkFlowHolderPanel("c"));
		this.panel.setWorkFlow(this, STATE_START);
	}

	@Override
	public PageInfo getPageInfo() {
		BasePage.PageInfo pageInfo = this.panel.getPageInfo();
		pageInfo.setPageTitle(getString("amend_account_pg"));
		pageInfo.addAcsItem("amend_accounts");
		pageInfo.addTitle(getString("amend_account_tl"));
		return pageInfo;
	}

	// workflow
	public void process(WorkFlowManager manager) {
		switch (manager.getState()) {
		case STATE_START:
		    this.doSelectInstitution(manager);			
			break;
		case STATE_INSTSELECTED:
			this.doMain(manager);
			break;
		default:
			manager.terminate();
			this.setResponsePage(com.metavante.cortexonline.wicket.HomePage.class);
			break;
		}
	}
	
	private void doSelectInstitution(WorkFlowManager manager) 
	{	
		manager.setPanel(new SimpleSelectInstitutionPanel(new PropertyModel<Institution>(this, "institution")),STATE_INSTSELECTED, STATE_FAILURE);
	}
	
	private void doMain(WorkFlowManager manager) {
		manager.setPanel(new AmendAccountsMainPanel(this.institution), STATE_FAILURE, STATE_FAILURE);
	}

}
