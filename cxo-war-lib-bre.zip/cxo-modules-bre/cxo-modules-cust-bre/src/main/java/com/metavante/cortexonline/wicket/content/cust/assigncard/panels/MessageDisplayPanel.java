package com.metavante.cortexonline.wicket.content.cust.assigncard.panels;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.Model;
import com.fis.cortex.access.custid.view.Message;
import com.fis.cortex.wicket.base.CortexAjaxButton;
import com.fis.cortex.wicket.base.CortexModalWindow;
import com.metavante.cortexonline.wicket.components.buttonbox.ButtonBox;
import com.metavante.cortexonline.wicket.components.workflow.SelectEntityPanel;

/**
 * This class is used to display the messages in the pop-up screen 
 * TODO - class description.
 * 
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/assigncard/panels/MessageDisplayPanel.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */

public class MessageDisplayPanel extends SelectEntityPanel<Message> {

	private static final long serialVersionUID = 1L;
	private CortexModalWindow modalWindow;
	private Form<Message> form;
	private ButtonBox buttons;
	private ButtonBox buttonsLeft;
	private Label msg;
	private Label cardNumber;
	private Label cardNumberValue;
	private Label cardProduct;
	private Label cardProDescription;
	private CortexAjaxButton continueAjxBtn;
	private CortexAjaxButton cancelAjxButton;
	private Message message;

	public MessageDisplayPanel( final CustomerDetailsPanel mainPanel,
			final CortexModalWindow window, final IModel<Message> model,
			 String id) {
		super(id, model);
		this.message=model.getObject();
		this.modalWindow=window;
		form= new Form<Message>("form") {
			private static final long serialVersionUID = 1L;
			@Override
			protected void onSubmit() {}
			
		
		};	
		this.setOutputMarkupId(true);
		this.setOutputMarkupPlaceholderTag(true);
		this.add(this.form);
		this.addFormComponents(this.form);
		this.addCardInfo(this.form);
		this.addButtonsLeft(this.form);	
		this.addAjaxButton(this.form);
		
		
	}
	private void addButtonsLeft(WebMarkupContainer parent) {
		this.buttonsLeft = new ButtonBox("buttonsLeft");
		parent.add(this.buttonsLeft);
	}

	private void addAjaxButton(WebMarkupContainer parent) {
		this.buttons = new ButtonBox("buttons",false);
		IModel<String> model=null;
		if("success".equalsIgnoreCase(this.message.getAction())){
			model = new Model<String>(this.getString("issue_card_ok"));	
		}else{
			model = new Model<String>(this.getString("continue_button"));	
		}
		
		this.continueAjxBtn=new CortexAjaxButton("button",model,
				MessageDisplayPanel.this.form) {
			private static final long serialVersionUID = 1L;

			@Override
			protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
				target.addComponent(MessageDisplayPanel.this);
				if("confirmMsg".equalsIgnoreCase(MessageDisplayPanel.this.message.getAction())){
					MessageDisplayPanel.this.message.setAction("confirm");
				}
				MessageDisplayPanel.this.modalWindow.close(target);
				
			}
		};
		this.continueAjxBtn.setDefaultFormProcessing(false);
		this.continueAjxBtn.setOutputMarkupId(true);
		this.continueAjxBtn.setOutputMarkupPlaceholderTag(true);
		this.buttons.addButton(this.continueAjxBtn);	
		
		this.cancelAjxButton=new CortexAjaxButton("button",
				new Model<String>(this.getString("msg_panel_cancel")),
				MessageDisplayPanel.this.form) {
			private static final long serialVersionUID = 1L;

			@Override
			protected void onSubmit(AjaxRequestTarget target, Form<?> form) {
				if("confirmMsg".equalsIgnoreCase(MessageDisplayPanel.this.message.getAction())){
					MessageDisplayPanel.this.message.setAction("cancel");
				}
				target.addComponent(MessageDisplayPanel.this);
				MessageDisplayPanel.this.modalWindow.close(target);
				
			}
		};
		this.cancelAjxButton.setDefaultFormProcessing(false);
		this.cancelAjxButton.setVisible(false);
		this.cancelAjxButton.setOutputMarkupId(true);
		this.cancelAjxButton.setOutputMarkupPlaceholderTag(true);
		this.buttons.addButton(this.cancelAjxButton);					
		parent.add(this.buttons);
	}
	
	private void addFormComponents(WebMarkupContainer parent){
		this.msg=new Label("messageLabel",this.message.getMessage());
		this.msg.setVisible(true);
		parent.add(this.msg);
	}
	
	private void addCardInfo(WebMarkupContainer parent){
		this.cardNumber=new Label("cardNumber"," Card Number:");
		this.cardNumber.setVisible(false);
		parent.add(this.cardNumber);
		
		this.cardNumberValue=new Label("cardNumberValue",message.getCardNumber());
		this.cardNumberValue.setVisible(false);
		parent.add(this.cardNumberValue);
		
		this.cardProduct=new Label("cardProduct","Card Product:");
		this.cardProduct.setVisible(false);
		parent.add(this.cardProduct);
		
		this.cardProDescription=new Label("cardProductDescValue",message.getCardProdDescription());
		this.cardProDescription.setVisible(false);
		parent.add(this.cardProDescription);
	}
	
	public void setDisplayMessage(String message){
		this.message.setMessage(message);
	}
	
	public void setAction(String action){
		this.message.setAction(action);
	}
	public void setMessageModel(Message message){
		this.cardNumber.setVisible(true);
		this.cardNumberValue.setVisible(true);
		this.cardProduct.setVisible(true);
		this.cardProDescription.setVisible(true);
		this.msg.setVisible(false);
		this.cancelAjxButton.setVisible(true);
		this.message=message;
	}
	



}
