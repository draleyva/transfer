package com.metavante.cortexonline.wicket.content.cust;

import org.apache.wicket.PageParameters;

import com.metavante.cortexonline.wicket.BasePage;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlow;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowHolderPanel;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowManager;

public class CustomerScreenPage extends BasePage implements WorkFlow {

	private static final int STATE_FAILURE = -1;
	private static final int STATE_START = 0;
	private static final int STATE_INSTSELECTED = 1;


	private WorkFlowHolderPanel panel;

	public CustomerScreenPage(PageParameters parameters) {
		super(parameters);
		this.add(this.panel = new WorkFlowHolderPanel("panel"));
		this.panel.setWorkFlow(this, STATE_START);

	}

	@Override
	public PageInfo getPageInfo() {
		BasePage.PageInfo pageInfo = this.panel.getPageInfo();
		pageInfo.setPageTitle(getString("Customer_Account_Card"));
		pageInfo.addAcsItem(getString("cust_aac_crd"));
		pageInfo.addTitle(getString("CustomerIntitution"));
		return pageInfo;
	}


	public void process(WorkFlowManager manager) {
		switch (manager.getState()) {
			case STATE_START :
				break;
			case STATE_INSTSELECTED :
				break;
			default :
				break;
		}
		
	}

}
