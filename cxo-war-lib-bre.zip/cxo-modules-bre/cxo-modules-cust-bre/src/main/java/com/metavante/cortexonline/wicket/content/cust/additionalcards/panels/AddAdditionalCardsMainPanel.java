package com.metavante.cortexonline.wicket.content.cust.additionalcards.panels;
import org.apache.wicket.spring.injection.annot.SpringBean;

import com.fis.cortex.access.custid.view.AdditionalCardsContextSummary;
import com.fis.cortex.transport.custid.services.CustomerService;
import com.metavante.cortex.transport.objects.core.Institution;
import com.metavante.cortexonline.wicket.BasePage.PageInfo;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowManager;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowResult;
import com.metavante.cortexonline.wicket.content.cust.additionalcards.panels.AddAdditionalCardsHomePanel;
import com.metavante.cortexonline.wicket.content.cust.additionalcards.panels.PrimaryCardDetailsPanel;
import com.metavante.cortexonline.wicket.content.rules.panels.AbstractMainPanel;
import com.metavante.cortexonline.wicket.metadata.AcsInfo;

@AcsInfo(acsItem = "addin_crd_main")
public class AddAdditionalCardsMainPanel extends AbstractMainPanel{
	
	private static final long serialVersionUID = 1L;

	private static final int STATE_FAILURE = -1;
	private static final int STATE_START = 0;
	private static final int STATE_AFTERHOME = 1;
	private String pan;
	
	
	@SpringBean(name = "transportCustomerIdService")
	private CustomerService customerService;
	

	
	public static class GoPrimaryCardSearchResult extends WorkFlowResult {
		private static final long serialVersionUID = 1L;
		AdditionalCardsContextSummary additionalContextSummary;
		public GoPrimaryCardSearchResult(AdditionalCardsContextSummary additionalCardsContextSummary) {
			super(Status.REDIRECT);
            this.additionalContextSummary =additionalCardsContextSummary;
		}
	}	
	public static class GoAdditionalCardHome extends WorkFlowResult {
		private static final long serialVersionUID = 1L;		
		public GoAdditionalCardHome() {
			super(Status.REDIRECT);           
		}
	}
	
	public static class GetAdditionalCardHome extends WorkFlowResult {
		private static final long serialVersionUID = 1L;		
		public GetAdditionalCardHome() {
			super(Status.REDIRECT);           
		}
	}
	
	public AddAdditionalCardsMainPanel(Institution institution) {
		super(institution);
		this.getPanel().setWorkFlow(this, STATE_START);
		
	}
	
	public AddAdditionalCardsMainPanel(Institution institution, String pan) {
		super(institution);			
		this.pan=pan;
		this.getPanel().setWorkFlow(this, STATE_START);
	}
	
	// workflow

	public void process(WorkFlowManager manager) {
		switch (manager.getState()) {
		case STATE_START:	
			if(this.pan==null)
		      this.doHome(manager);		
			else
			  this.doHome(manager,this.pan);	
			break;	
		case STATE_AFTERHOME:			
			WorkFlowResult result = manager.getLastResult();
			if(result instanceof GoPrimaryCardSearchResult)
			  this.displayPrimaryCardDetails(manager);		
			else if(result instanceof GoAdditionalCardHome){
			  this.doHome(manager);
			}else{
			  this.displayPrimaryCardDetails(manager);
			}	
			break;		
		default:
			
			manager.terminate();
			this.setResponsePage(com.metavante.cortexonline.wicket.HomePage.class);
			break;
		}
	}
	
	@Override
	public PageInfo getPageInfo() {
		PageInfo pageInfo = super.getPageInfo();
		pageInfo.addTitle("Institution: " + this.institution.getCode());
		return pageInfo;
	}

	private void doHome(WorkFlowManager manager) {
		AdditionalCardsContextSummary additionalCardContextSummary = new AdditionalCardsContextSummary(this.institution,null);
		manager.setPanel(new AddAdditionalCardsHomePanel(additionalCardContextSummary), STATE_FAILURE, STATE_FAILURE, STATE_FAILURE,STATE_AFTERHOME, true);
		
	}
	
	private void doHome(WorkFlowManager manager,String pan) {		
		AdditionalCardsContextSummary additionalCardContextSummary = new AdditionalCardsContextSummary(this.institution,null);
		manager.setPanel(new AddAdditionalCardsHomePanel(additionalCardContextSummary,this.pan), STATE_FAILURE, STATE_FAILURE, STATE_FAILURE,STATE_AFTERHOME, true);
		
	}
	private void displayPrimaryCardDetails(WorkFlowManager manager) {
		GoPrimaryCardSearchResult result = (GoPrimaryCardSearchResult) manager.getLastResult();	
		manager.setPanel(new PrimaryCardDetailsPanel(result.additionalContextSummary), STATE_FAILURE, STATE_FAILURE, STATE_FAILURE,
				STATE_AFTERHOME, true);
	}
	


}
