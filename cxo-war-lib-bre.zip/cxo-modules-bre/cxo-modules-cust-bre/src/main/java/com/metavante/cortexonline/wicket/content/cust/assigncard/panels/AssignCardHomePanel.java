/**
 * <hr>
 * <h4>Copyright Metavante Technologies Ltd.</h4>
 */
package com.metavante.cortexonline.wicket.content.cust.assigncard.panels;

import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.model.CompoundPropertyModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.spring.injection.annot.SpringBean;
import com.fis.cortex.access.custid.view.CustIdCode;
import com.fis.cortex.access.custid.view.CustIdType;
import com.fis.cortex.access.custid.view.CustomerContextSummary;
import com.fis.cortex.transport.custid.exception.CortexWebServiceException;
import com.fis.cortex.transport.custid.services.CustomerService;
import com.metavante.cortexonline.wicket.CortexSession;
import com.metavante.cortex.transport.objects.core.Institution;
import com.metavante.cortexonline.wicket.components.ContextPanel;
import com.metavante.cortexonline.wicket.components.buttonbox.BoxedSubmitButton;
import com.metavante.cortexonline.wicket.components.buttonbox.ButtonBox;
import com.metavante.cortexonline.wicket.components.componentline.TextFieldLine;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowPanel;
import com.metavante.cortexonline.wicket.content.cust.components.CustomerIdTypeSelectLine;
import com.metavante.cortexonline.wicket.metadata.AcsInfo;

/**
 * Assign Card home screen. This is the main screen from which user will
 * configure Search criteria
 *
 * @author schinnas
 * @version $Id:
 * //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/assigncard/panels/AssignCardHomePanel.java#1
 * $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
@AcsInfo(acsItem = "agn_crd_home")
public class AssignCardHomePanel extends WorkFlowPanel
{
  private static final long serialVersionUID = 1L;

  private String custIdValue;
  private String custIdCodeValue;
  private ButtonBox buttons;

  @SpringBean(name = "transportCustomerIdService")
  private CustomerService customerService;

  private CustomerContextSummary customerContextSummary;

  // data
  protected Institution institution;
  private CustIdType custIdTypeValue;
  private CustIdCode custIdCode;

  // construction	
  public AssignCardHomePanel(CustomerContextSummary customerContextSummary)
  {
    this.setDefaultModel(new CompoundPropertyModel<AssignCardHomePanel>(this));
    this.institution = customerContextSummary.getInstitution();
    if (customerContextSummary.getCustIdType() != null)
    {
      custIdTypeValue = customerContextSummary.getCustIdType();
    }
    if (customerContextSummary.getCustIdCode() != null)
    {
      custIdCode = customerContextSummary.getCustIdCode();
      this.custIdCodeValue = custIdCode.getCode();
    }
    Form<Void> form = new Form<Void>("form")
    {
      private static final long serialVersionUID = 1L;

      @Override
      protected void onSubmit()
      {
        AssignCardHomePanel.this.goSearchCustomerDetails();
      }
    };
    this.add(form);
    this.addContext(this);
    this.addControls(form);
    this.addButtons(form);
  }

  protected void addContext(WebMarkupContainer parent)
  {
    parent.add(new ContextPanel("context").addInstitution(this.institution));
  }

  private void addControls(WebMarkupContainer parent)
  {
    parent.add(new CustomerIdTypeSelectLine("custIdType", this.getString("cust_id_type"), this.institution.getCode(), new PropertyModel<CustIdType>(this, "custIdTypeValue")).setMandatory(true).setExpanded(true));
    parent.add(new TextFieldLine<String>("custIdCode", this.getString("cust_id_code"), new PropertyModel<String>(this, "custIdCodeValue")).setMaxLength(32).setMandatory(true));
  }

  protected void addButtons(WebMarkupContainer parent)
  {
    this.buttons = new ButtonBox("buttons");
    this.buttons.addButton(new BoxedSubmitButton(new Model<>(this.getString("find_customer"))));
    parent.add(this.buttons);
  }

  // actions
  protected void goSearchCustomerDetails()
  {
    try
    {
      String username = CortexSession.get().getUserName();
      this.custIdCode = customerService.getCustIdCode(this.institution.getRealId(), this.custIdTypeValue.getCustId(), this.custIdCodeValue, username);
      //this.validationResult = 1234L;

      if (this.custIdCode == null)
      {
        this.error(this.getString("cust_id_code_invalid"));
        return;
      }
    }
    catch (CortexWebServiceException exp)
    {
      this.error(this.getString(exp.getMessage()));
      return;
    }
    
    customerContextSummary = new CustomerContextSummary(this.institution, this.custIdTypeValue, this.custIdCode);
    this.complete(new AssignCardMainPanel.GoSearchCustomerResult(customerContextSummary));
  }
}
