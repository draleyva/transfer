/**
 * <hr>
 * <h4>Copyright Metavante Technologies Ltd.</h4>
 */
package com.metavante.cortexonline.wicket.content.cust.components;

import java.util.ArrayList;
import java.util.List;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.markup.html.form.IChoiceRenderer;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.spring.injection.annot.SpringBean;

import com.fis.cortex.access.custid.view.CustIdType;
import com.fis.cortex.transport.custid.services.CustomerService;



import com.metavante.cortexonline.wicket.components.componentline.SelectFieldLine;

/**
 * Displays drop down list of CustomerIdType items
 * 
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/components/CustomerIdTypeSelectLine.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
public class CustomerIdTypeSelectLine extends SelectFieldLine<CustIdType> {

	private static final long serialVersionUID = 1L;
	@SpringBean(name = "transportCustomerIdService")
	private CustomerService customerService;	
    private String  institutionCode;

	public CustomerIdTypeSelectLine(String id, String label, String institutionCode, IModel<CustIdType> model) {
		super(id, label);
		this.institutionCode =institutionCode;	
		List<CustIdType> choices = this.getChoices();

		DropDownChoice<CustIdType> field = new DropDownChoice<CustIdType>(
				"select_field", model,choices,new IChoiceRenderer<CustIdType>() {
					private static final long serialVersionUID = 1L;

					public Object getDisplayValue(CustIdType object) {
						return object.getDescription();
					}

					public String getIdValue(CustIdType object, int index) {
						return object.getCustId()+"";
					}
					
					
				}){
    		    private static final long serialVersionUID = 1L;
    		   
		   };		
		
		field.setLabel(new Model<String>(label));

		this.addComponent(field);
	}
	
	protected List<CustIdType> getChoices()
	{
		List<CustIdType> idTypeList=null;	
		try
		{
		  idTypeList = this.customerService.getCustIdTypes(this.institutionCode);
		}catch(Exception exp){
		  idTypeList= new ArrayList<CustIdType>();
		  this.error(this.getString(exp.getMessage()));		
		}		
		return idTypeList;
	 }
}
