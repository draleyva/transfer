/**
 * <hr>
 * <h4>Copyright Metavante Technologies Ltd.</h4>
 */
package com.metavante.cortexonline.wicket.content.cust.additionalcards.panels;

import java.util.Date;

import com.fis.cortex.encryption.PanCryptor;
import com.fis.cortex.encryption.basic.BasicPanCryptor;
import com.fis.cortex.encryption.exceptions.PanEncryptionFailedException;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.model.CompoundPropertyModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.spring.injection.annot.SpringBean;
import com.cortex.common.exception.serverException;
import com.fis.cortex.access.custid.view.AccountHolder;
import com.fis.cortex.access.custid.view.AdditionalCardsContextSummary;
import com.fis.cortex.access.custid.view.Card;
import com.fis.cortex.access.custid.view.CardHolder;
import com.fis.cortex.access.custid.view.CardProduct;
import com.fis.cortex.access.custid.view.CardStatus;
import com.fis.cortex.transport.custid.exception.AdditionalsConstraintViolationException;
import com.fis.cortex.transport.custid.exception.CardNotFoundException;
import com.fis.cortex.transport.custid.exception.GeneralSqlException;
import com.fis.cortex.transport.custid.services.CustomerService;
import com.metavante.cortex.transport.objects.core.Institution;
import com.metavante.cortexonline.wicket.components.ContextPanel;
import com.metavante.cortexonline.wicket.components.buttonbox.BoxedSubmitButton;
import com.metavante.cortexonline.wicket.components.buttonbox.ButtonBox;
import com.metavante.cortexonline.wicket.components.componentline.DateFieldLine;
import com.metavante.cortexonline.wicket.components.componentline.TextFieldLine;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowPanel;
import com.metavante.cortexonline.wicket.content.cust.additionalcards.panels.AddAdditionalCardsMainPanel;
import com.metavante.cortexonline.wicket.metadata.AcsInfo;



/**
 * Customer Details screen. This is the main screen from which user
 * will configure accounts to user
 * 
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/additionalcards/panels/PrimaryCardDetailsPanel.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
@AcsInfo(acsItem = "addin_crd_det")
public class PrimaryCardDetailsPanel extends WorkFlowPanel {
	private static final long serialVersionUID = 1L;  
	private static final String DUMMY_CUST_CODE="99999999";
	private static final String CARD_STATUS_CODE="02";
	private static final String EMPTY=" ";
	@SpringBean(name = "transportCustomerIdService")
	private CustomerService customerService;	
	private AdditionalCardsContextSummary additionalCardContextSummary;
	// data
	protected Institution institution;   
	private Card primaryCard;
	private Card additionalCard;
	Form<Void> form;
	Label primaryCardLabel;
	Label cardHolderNameLabel;
	Label cardProductLabel;
	Label primaryCardValue;
	Label cardHolderNameValue;
	Label cardProductValue;
	TextFieldLine<String> titleComp;
	TextFieldLine<String> firstNameComp;
	TextFieldLine<String> lastNameComp;
	TextFieldLine<String> embossNameComp;
	DateFieldLine<Date> dobComp;
	TextFieldLine<String> additionalCardComp;
	private String title;
	private String firstname;
	private String lastname;
	private String embossname;
	private Date dateOfBirth;
	private String additionalCardPan;
	private AccountHolder accountHolder;
	private CardProduct cardProduct;
	private Card additionalCardObj;
	StringBuilder strBuilder;
	private ButtonBox  additionalCardButtonBox;
	BoxedSubmitButton issueAdditionalCardButton;
	BoxedSubmitButton issueAdditionalCardCancel;
	BoxedSubmitButton okButton;
	String fromIssueCardPage;
	
	
	

	// construction	
	public PrimaryCardDetailsPanel(AdditionalCardsContextSummary additionalCardsContextSummary)
	{
		this.setDefaultModel(new CompoundPropertyModel<PrimaryCardDetailsPanel>(this));		
		this.institution = additionalCardsContextSummary.getInstitution();
		if(additionalCardsContextSummary.getPrimaryCard()!=null&&additionalCardsContextSummary.getAdditionalCard()==null)
		{
		  this.primaryCard =additionalCardsContextSummary.getPrimaryCard();
		  this.accountHolder= this.primaryCard.getAccountHolder();
		  this.cardProduct=this.primaryCard.getCardProduct();
		}else{
		  this.primaryCard =additionalCardsContextSummary.getPrimaryCard();
		  this.accountHolder= this.primaryCard.getAccountHolder();
		  this.cardProduct=this.primaryCard.getCardProduct();
		  this.additionalCard =additionalCardsContextSummary.getAdditionalCard();
		  this.info(this.getString("additional_card_operation_success"));
	    }
		form = new Form<Void>("form") {
			private static final long serialVersionUID = 1L;
			@Override
			protected void onSubmit() {			
				
			}
			@Override
			protected void onError() {				
								
			}
		};		
		this.add(form);
		this.addContext(this);
		this.addControls(form);	
		this.addAdditionalCardControls(form,this.additionalCard ==null?true:false);
        this.addActionButtons(form,this.additionalCard ==null?true:false);		
		this.form.setOutputMarkupId(true);		
    }
	
	public PrimaryCardDetailsPanel(AdditionalCardsContextSummary additionalCardsContextSummary,String fromIssue)
	{
		this(additionalCardsContextSummary);
		this.fromIssueCardPage=fromIssue;
    }
	
   
	protected void addContext(WebMarkupContainer parent) {
		parent.add(new ContextPanel("context").addInstitution(this.institution).setEnabled(false));
	}
	
	protected void addControls(WebMarkupContainer parent) 
	{
		parent.add(this.primaryCardLabel=new Label("primaryCardNumber",this.getString("additional_card_primary_pan")));
		parent.add(this.primaryCardValue=new Label("panText",this.primaryCard.getPan()));	
		parent.add(this.cardHolderNameLabel=new Label("cardHolderName",this.getString("additional_card_holder_name")));
		strBuilder= new StringBuilder();		
		if(this.accountHolder!=null)
		{
			strBuilder.append(accountHolder.getTitle()!=null?accountHolder.getTitle()+EMPTY:EMPTY);
			strBuilder.append(accountHolder.getFirstName()!=null?accountHolder.getFirstName()+EMPTY:EMPTY);
			strBuilder.append(accountHolder.getLastName()!=null?accountHolder.getLastName():EMPTY);
			parent.add(this.cardHolderNameValue=new Label("cardHolderNameText",strBuilder.toString()));
	    }
		else
	    {
	    	parent.add(this.cardHolderNameValue=new Label("cardHolderNameText",EMPTY));
	    }
		parent.add(this.primaryCardLabel=new Label("cardProductName",this.getString("additional_card_crd_product")));
		if(this.cardProduct!=null)
		{
			parent.add(this.primaryCardValue=new Label("cardProductNameText",this.cardProduct.getCardProduct()+"-"+this.cardProduct.getDescription()));	
		}else{
			if(this.primaryCard.getCardProduct()!=null){
			   parent.add(this.primaryCardValue=new Label("cardProductNameText",this.primaryCard.getCardProduct().getCardProduct()+"-"+this.primaryCard.getCardProduct().getDescription()));
			}
		}
			
  }
  
  protected void addAdditionalCardControls(WebMarkupContainer parent,boolean isEnabled) 
  {
       this.titleComp =  new TextFieldLine<String>("title",this.getString("additional_card_title"), new PropertyModel<String>(this,"title"));
       
	   this.titleComp.setOutputMarkupId(true);
	   this.titleComp.setOutputMarkupPlaceholderTag(true);  
	   this.titleComp.setMandatory(true);
	   this.titleComp.setMaxLength(10);
	   if(this.additionalCard!=null){
		   this.title= this.additionalCard.getCardHolder().getTitle();
	   }
	   
	   this.titleComp.setEnabled(isEnabled);
	   parent.add(this.titleComp);
       this.firstNameComp =  new TextFieldLine<String>("firstName",this.getString("additional_card_firstname"), new PropertyModel<String>(this,"firstname"));	   
	   this.firstNameComp.setOutputMarkupId(true);
	   this.firstNameComp.setOutputMarkupPlaceholderTag(true); 
	   this.firstNameComp.setMandatory(true);
	   this.firstNameComp.setMaxLength(50);
	   if(this.additionalCard!=null)
	   {
		  this.firstname= this.additionalCard.getCardHolder().getFirstName();
	   }
	   this.firstNameComp.setEnabled(isEnabled);
	   parent.add(this.firstNameComp);
	   this.lastNameComp =  new TextFieldLine<String>("lastName",this.getString("additional_card_lastname"), new PropertyModel<String>(this,"lastname"));	   
	   this.lastNameComp.setOutputMarkupId(true);
	   this.lastNameComp.setOutputMarkupPlaceholderTag(true); 
	   this.lastNameComp.setMandatory(true);
	   this.lastNameComp.setMaxLength(50);
	   if(this.additionalCard!=null)
	   {
		  this.lastname= this.additionalCard.getCardHolder().getLastName();
	   }
	   this.lastNameComp.setEnabled(isEnabled);
	   parent.add(this.lastNameComp);
	   this.embossNameComp =  new TextFieldLine<String>("embossName",this.getString("additional_card_embossname"), new PropertyModel<String>(this,"embossname"));	   
	   this.embossNameComp.setOutputMarkupId(true);
	   this.embossNameComp.setOutputMarkupPlaceholderTag(true); 
	   this.embossNameComp.setMandatory(true);
	   this.embossNameComp.setMaxLength(51);
	   if(this.additionalCard!=null)
	   {
		  this.embossname= this.additionalCard.getEmbossedName();
	   }
	   this.embossNameComp.setEnabled(isEnabled);
	   parent.add(this.embossNameComp);
	   this.dobComp = new DateFieldLine<Date>("dob", this.getString("additional_card_dob"),new PropertyModel<Date>(this, "dateOfBirth"));	  	   
	   this.dobComp.setOutputMarkupId(true);
	   this.dobComp.setOutputMarkupPlaceholderTag(true); 
	   this.dobComp.setMandatory(true);
	   if(this.additionalCard!=null)
	   {
		  this.dateOfBirth= this.additionalCard.getCardHolder().getDateOfBirth();
	   }
	   this.dobComp.setEnabled(isEnabled);   
	   parent.add(this.dobComp);
	   this.additionalCardComp =  new TextFieldLine<String>("additionalCardPan",this.getString("additional_card_pan"), new PropertyModel<String>(this,"additionalCardPan"));	   
	   this.additionalCardComp.setOutputMarkupId(true);
	   this.additionalCardComp.setOutputMarkupPlaceholderTag(true); 
	   this.additionalCardComp.setMandatory(true);
	   this.additionalCardComp.setMaxLength(19);
	   if(this.additionalCard!=null)
	   {
		  this.additionalCardPan= this.additionalCard.getPan();
	   }
	   this.additionalCardComp.setEnabled(isEnabled);
	   parent.add(this.additionalCardComp);
 }
	
 protected void addActionButtons(WebMarkupContainer parent,boolean isEnabled) 
 {
	   this.additionalCardButtonBox = new ButtonBox("issueAdditionalCard",false);
	   this.issueAdditionalCardButton=new BoxedSubmitButton(new Model<String>(this.getString("additional_issue_card_btn"))){
	   private static final long serialVersionUID = 1L;
	    @Override
		public void onSubmit(){	
	    	boolean isNotProcessed=false;
	        if(PrimaryCardDetailsPanel.this.validateAdditionalCard())
	        {   	
		    	  try
		    	  {
		    		 PrimaryCardDetailsPanel.this.setAdditionalCardDetails(PrimaryCardDetailsPanel.this.additionalCardObj,PrimaryCardDetailsPanel.this.primaryCard); 
		    	     customerService.updateAdditionalCard(PrimaryCardDetailsPanel.this.primaryCard, PrimaryCardDetailsPanel.this.additionalCardObj);
		    	  }catch(AdditionalsConstraintViolationException exp){
		    		 this.error(this.getString(exp.getMessage())) ;
		    		 isNotProcessed=true;
		    	  }catch(GeneralSqlException sqlExp){
			    	 this.error(this.getString(sqlExp.getMessage())) ;
			    	 isNotProcessed=true;
			      }
		    	  if(!isNotProcessed){
		    	     PrimaryCardDetailsPanel.this.additionalCardContextSummary= new AdditionalCardsContextSummary(PrimaryCardDetailsPanel.this.institution,PrimaryCardDetailsPanel.this.primaryCard);
		    	     PrimaryCardDetailsPanel.this.additionalCardContextSummary.setAdditionalCard(PrimaryCardDetailsPanel.this.additionalCardObj);
		    	     PrimaryCardDetailsPanel.this.complete(new AddAdditionalCardsMainPanel.GoPrimaryCardSearchResult(PrimaryCardDetailsPanel.this.additionalCardContextSummary));
		    	  }
	        }	      
		 }
	   };
	   issueAdditionalCardButton.setOutputMarkupId(true);
	   issueAdditionalCardButton.setOutputMarkupPlaceholderTag(true);
	   issueAdditionalCardButton.setVisible(isEnabled);
	   this.additionalCardButtonBox.addButton(issueAdditionalCardButton);
	   
	   this.okButton=new BoxedSubmitButton(new Model<String>(this.getString("additional_card_ok_btn"))){
		   private static final long serialVersionUID = 1L;
		    @Override
			public void onSubmit(){	 
		    	PrimaryCardDetailsPanel.this.complete(new AddAdditionalCardsMainPanel.GoAdditionalCardHome());
		    }	      
	   };
	   this.okButton.setVisible(!isEnabled);
	   this.okButton.setOutputMarkupId(true);
	   this.okButton.setOutputMarkupPlaceholderTag(true);
	   this.additionalCardButtonBox.addButton(okButton);
	   
	   this.issueAdditionalCardCancel=new BoxedSubmitButton(new Model<String>(this.getString("additional_issue_cancel_btn"))) {
	   private static final long serialVersionUID = 1L;
		 @Override
		 public void onSubmit(){
			 if(PrimaryCardDetailsPanel.this.fromIssueCardPage==null){
			   PrimaryCardDetailsPanel.this.complete(new AddAdditionalCardsMainPanel.GoAdditionalCardHome());
			 }
		 }
	   };
	   this.issueAdditionalCardCancel.setDefaultFormProcessing(false);
	   this.issueAdditionalCardCancel.setVisible(isEnabled);
	   this.issueAdditionalCardCancel.setOutputMarkupId(true);
	   this.issueAdditionalCardCancel.setOutputMarkupPlaceholderTag(true);
	   this.additionalCardButtonBox.addButton(issueAdditionalCardCancel);	
	   this.additionalCardButtonBox.setOutputMarkupId(true);
	   this.additionalCardButtonBox.setOutputMarkupPlaceholderTag(true);
	   parent.add(this.additionalCardButtonBox);		
 }
	
	
 protected boolean validateAdditionalCard()
 {
	boolean isValidCard=true; 
    try
	{
		PanCryptor panCryptor = BasicPanCryptor.getInstance();
		String  additionalCardNumber =panCryptor.encryptPan(this.additionalCardPan);		
	    this.additionalCardObj= customerService.getCard(additionalCardNumber, this.institution.getRealId());
	    if(this.additionalCardObj!=null&&this.additionalCardObj.getAccountHolder()!=null){
			 AccountHolder accountHolder =this.additionalCardObj.getAccountHolder();
			 CardStatus  cardStatus=this.additionalCardObj.getCardStatus();
			 String statusCode=cardStatus.getStatusCode();
			 CardProduct additionalCardProduct=this.additionalCardObj.getCardProduct();
			 CardProduct primaryCardProduct=this.primaryCard.getCardProduct();
			 if(!DUMMY_CUST_CODE.equalsIgnoreCase(accountHolder.getCustomerCode())){
				 this.error(this.getString("additional_card_assigned_to_customer"));
				 isValidCard=false;		
			 }else if(!CARD_STATUS_CODE.equalsIgnoreCase(statusCode)){
				 this.error(this.getString("additional_card_invalid_status")+" : "+statusCode);
				 isValidCard=false;
			 }else if(primaryCardProduct.getRealId()!=additionalCardProduct.getRealId()){
				 this.error(this.getString("additional_card_invalid_product"));
				 isValidCard=false;
			 }		 
		  }else{
			  this.error(this.getString("card_not_found"));
			  isValidCard=false;
		  } 
	    
	}catch(PanEncryptionFailedException e){
			this.error(this.getString("agn_card_encryption_failed"));
			isValidCard=false;
	}catch(CardNotFoundException exp){
			this.error(this.getString("card_not_found"));
			isValidCard=false;
	}
    return isValidCard;
 } 
 

 
 private void setAdditionalCardDetails(Card additionalCard,Card primaryCard){
	additionalCard.setAccountHolder(primaryCard.getAccountHolder());
	additionalCard.setAccount(primaryCard.getAccount());
	additionalCard.setAdditionalNumber((short)1);
 	CardHolder cardHolder = new CardHolder();
 	cardHolder.setDateOfBirth(this.dateOfBirth);
 	cardHolder.setFirstName(this.firstname);
 	cardHolder.setLastName(this.lastname);
 	cardHolder.setTitle(this.title);
 	cardHolder.setIdNumber(EMPTY);
 	additionalCard.setEmbossedName(this.embossname);
 	additionalCard.setCardHolder(cardHolder);
}
 
 

}
