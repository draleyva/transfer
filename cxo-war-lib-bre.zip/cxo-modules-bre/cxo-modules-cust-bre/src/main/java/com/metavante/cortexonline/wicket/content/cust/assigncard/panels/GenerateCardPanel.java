/**
 * <hr>
 * <h4>Copyright Metavante Technologies Ltd.</h4>
 */
package com.metavante.cortexonline.wicket.content.cust.assigncard.panels;

import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.apache.wicket.ajax.AbstractDefaultAjaxBehavior;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.markup.ComponentTag;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.model.CompoundPropertyModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.spring.injection.annot.SpringBean;

import com.fis.cortex.access.custid.view.Account;
import com.fis.cortex.access.custid.view.AccountHolder;
import com.fis.cortex.access.custid.view.Card;
import com.fis.cortex.access.custid.view.CustomerContextSummary;
import com.fis.cortex.transport.custid.services.CustomerService;
import com.metavante.cortex.transport.objects.common.Branch;
import com.metavante.cortex.transport.objects.core.Institution;
import com.metavante.cortex.transport.objects.cards.CardProductSummary;
import com.metavante.cortex.transport.services.CardService;
import com.metavante.cortexonline.wicket.CortexSession;
import com.metavante.cortexonline.wicket.components.ContextPanel;
import com.metavante.cortexonline.wicket.components.buttonbox.BoxedSubmitButton;
import com.metavante.cortexonline.wicket.components.buttonbox.ButtonBox;
import com.metavante.cortexonline.wicket.content.cards.components.CardProductList;
import com.metavante.cortexonline.wicket.content.cust.components.BranchSelectLine;
import com.metavante.cortexonline.wicket.components.workflow.WorkFlowPanel;
import com.metavante.cortexonline.wicket.metadata.AcsInfo;

import com.cortex.common.lib.debugLib;

/**
 * Generate Card screen.
 * 
 * @author schinnas
 * @version $Id: //ps/cortex/latam/bre/java/cxo-bre/7.2/cxo-modules-bre/cxo-modules-cust-bre/src/main/java/com/metavante/cortexonline/wicket/content/cust/assigncard/panels/GenerateCardPanel.java#1 $ $DateTime: 2018/11/16 21:55:23 $ $Author: dtoca $
 */
@AcsInfo(acsItem = "agn_crd_gen_card")
public class GenerateCardPanel extends WorkFlowPanel {
	
	private static Log logger = LogFactory.getLog(GenerateCardPanel.class);
	private static final long serialVersionUID = 1L;
	private static final String CARD_PROD_LABEL="agn_card_card_product";
	private static final String BRANCH_LABEL="agn_card_branch";	
	private static final String CARD_PROD_SELECT_MSG="gen_card_select_card_product";
	private static final String GENERATE_CARD_BTN="gen_card_generate_card_btn";
	private static final String GEN_CARD_CANCEL_BTN="gen_card_cancel_btn";
	private CustomerContextSummary customerContextSummary;	
	private ButtonBox buttons;
	@SpringBean(name = "transportCustomerIdService")
	private CustomerService customerService;
	@SpringBean(name = "transportCardService")
	private CardService cardService;
	private List<CardProductSummary> cardProducts;
	private CardProductSummary cardProductSummary;
	private CardProductList cardProductList;
	private BranchSelectLine branchSelectLine;
	private Form<Void> form;
	private Label  cardProductLabel;	
	private BoxedSubmitButton generateCardButton;
	private BoxedSubmitButton cancelButton;
	private AccountHolder accountHolder;
	private Account defaultAccount;
	private Branch branch;
	
	protected Institution institution;
	
	private final static String CLASSNAME = "GenerateCardPanel";	
	

	// construction
	public GenerateCardPanel(CustomerContextSummary customerContextSummary) {
		logger.debug(" GenerateCardPanel ");
		this.setDefaultModel(new CompoundPropertyModel<GenerateCardPanel>(this));
		this.customerContextSummary=customerContextSummary;
		this.institution =this.customerContextSummary.getInstitution();		
		this.accountHolder=this.customerContextSummary.getAccountHolder();
		this.defaultAccount=this.customerContextSummary.getDlftAcc();
		this.form = new Form<Void>("form") {
			private static final long serialVersionUID = 1L;

			@Override
			protected void onSubmit() {				
			}
		};
		this.form.setOutputMarkupId(true);
		this.form.setOutputMarkupPlaceholderTag(true);
		this.add(this.form);
		this.addContext(this);
		this.addControls(this.form);
		this.addButtons(this.form);
		
	}

	protected void addContext(WebMarkupContainer parent) {
		parent.add(new ContextPanel("context").addInstitution(this.institution));
	}

	private void addControls(WebMarkupContainer parent) {
		this.branchSelectLine=new BranchSelectLine("deliveryBranch",this.getString(BRANCH_LABEL),this.institution, new PropertyModel<Branch>(this, "branch"));
		this.branchSelectLine.setOutputMarkupId(true);
		this.branchSelectLine.setOutputMarkupPlaceholderTag(true);
		this.branchSelectLine.setMandatory(true);
		this.branchSelectLine.add(new AbstractDefaultAjaxBehavior() {			
			private static final long serialVersionUID = 1L;

			protected void onComponentTag(ComponentTag tag) {
				super.onComponentTag(tag);
				String onchange = "{"
						+ generateCallbackScript("wicketAjaxGet('"
						+ getCallbackUrl()+ "'")
						+ "; return true;}";
				tag.put("onchange", onchange);
			}
			protected void respond(AjaxRequestTarget target) {
				
			}

		});
		parent.add(this.branchSelectLine);
		this.cardProductLabel= new Label("cardProductDisplayLabel", this.getString(GenerateCardPanel.CARD_PROD_LABEL));
		parent.add(this.cardProductLabel);
		this.cardProducts = this.cardService.getAllCardProducts(this.institution.getCode());		
		
		this.cardProducts = this.returnListSup(this.cardProducts);
		
		this.cardProductList = new CardProductList("cardProduct", this.cardProducts, new PropertyModel<CardProductSummary>(this, "cardProductSummary"));		
		this.cardProductList.setOutputMarkupId(true);
		this.cardProductList.setOutputMarkupPlaceholderTag(true);
		this.cardProductList.add(new AbstractDefaultAjaxBehavior() {			
			private static final long serialVersionUID = 1L;

			protected void onComponentTag(ComponentTag tag) {
				super.onComponentTag(tag);
				String onchange = "{"
						+ generateCallbackScript("wicketAjaxGet('"
						+ getCallbackUrl()+ "'")
						+ "; return true;}";
				tag.put("onchange", onchange);
			}
			protected void respond(AjaxRequestTarget target) {
				
			}

		});		
		parent.add(this.cardProductList);
	}

	
	private List<CardProductSummary> returnListSup(List<CardProductSummary> list) {
	
		CardProductSummary tmp = null; 
      
		for(CardProductSummary cardproduct : list) {
			debugLib.logDetail(CLASSNAME, cardproduct.getProduct() + "/" + cardproduct.getDescription());
            if(cardproduct.getProduct().equals("TSUP")){
               tmp = cardproduct;                
            }
        }       
        
		debugLib.logDetail(CLASSNAME, "Updating list");
		if (tmp!=null) {
			debugLib.logDetail(CLASSNAME, "Removing item");
			list.remove(tmp);
		}
		debugLib.logDetail(CLASSNAME, "Item removed");
        
        for(CardProductSummary cardproduct : list) {
			debugLib.logDetail(CLASSNAME, cardproduct.getProduct() + "/" + cardproduct.getDescription());
        }
	
	   return list;
	
	}
	
	private void addButtons(WebMarkupContainer parent) {
		this.buttons = new ButtonBox("buttons");
		
		this.generateCardButton =new BoxedSubmitButton(new Model<String>(this.getString(GENERATE_CARD_BTN))){
			private static final long serialVersionUID = 1L;
			
			public void onSubmit(){
				GenerateCardPanel.this.branch=new PropertyModel<Branch>(GenerateCardPanel.this, "branch").getObject();
				GenerateCardPanel.this.cardProductSummary=new PropertyModel<CardProductSummary>(GenerateCardPanel.this, "cardProductSummary").getObject();
				if(GenerateCardPanel.this.cardProductSummary!=null && GenerateCardPanel.this.branch!=null){
					try
					{						
					    String username=CortexSession.get().getUserName();
					    Card card=customerService.getGeneratedCard(GenerateCardPanel.this.institution,GenerateCardPanel.this.cardProductSummary.getProduct(),GenerateCardPanel.this.accountHolder,GenerateCardPanel.this.defaultAccount,GenerateCardPanel.this.branch,username);
					    GenerateCardPanel.this.complete(new AssignCardMainPanel.GoDisplayCard(card));
					 }catch(Exception exp){					
						GenerateCardPanel.this.error(GenerateCardPanel.this.getString(exp.getMessage()));
					 }finally{
						 customerService.updateAccountHolder(GenerateCardPanel.this.accountHolder); 
					 }
				  
				}else{
					this.error(this.getString(GenerateCardPanel.CARD_PROD_SELECT_MSG));
				}
			}
			
		};
		this.generateCardButton.setOutputMarkupId(true);
		this.generateCardButton.setOutputMarkupPlaceholderTag(true);
		this.buttons.addButton(generateCardButton);
		
		this.cancelButton =new BoxedSubmitButton(new Model<String>(this.getString(GEN_CARD_CANCEL_BTN))){
			private static final long serialVersionUID = 1L;	
			
			public void onSubmit(){
				GenerateCardPanel.this.complete(new AssignCardMainPanel.GoInstitutionSelection());
			}
			
		};
		this.cancelButton.setOutputMarkupId(true);
		this.cancelButton.setOutputMarkupPlaceholderTag(true);
		this.cancelButton.setDefaultFormProcessing(false);
		this.buttons.addButton(cancelButton);
		
		this.buttons.setOutputMarkupId(true);
		this.buttons.setOutputMarkupPlaceholderTag(true);
		parent.add(this.buttons);

	}	
	
}
