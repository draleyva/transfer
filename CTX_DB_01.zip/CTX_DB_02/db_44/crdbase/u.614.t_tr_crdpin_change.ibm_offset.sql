
CREATE OR REPLACE TRIGGER crdpin_change BEFORE UPDATE ON crdpin
REFERENCING OLD old_crdpin NEW new_crdpin
FOR EACH ROW
BEGIN
	:new_crdpin.verno_ctx := :old_crdpin.verno_ctx + 1;

	if ((:new_crdpin.pinblk != :old_crdpin.pinblk) 
		 or (:new_crdpin.ibm_offset != :old_crdpin.ibm_offset)) then
		:new_crdpin.pincount := :old_crdpin.pincount + 1;
		:new_crdpin.datechanged := tenant_local_date_by_crddet(:new_crdpin.crddet_id);
	end if;
END;
/