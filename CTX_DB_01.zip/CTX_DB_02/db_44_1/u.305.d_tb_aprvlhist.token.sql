
ALTER TABLE APRVLHIST ADD 
(	
	token			varchar2(19)
);

