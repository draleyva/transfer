
ALTER TABLE APRVLCODE ADD 
(	
	token			varchar2(19)
);

