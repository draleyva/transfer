
insert into keyblkhdr(short_descr, descr, keytype, tmpltyp, schmtag, verid, algo, modeuse, keyvernum, export, lmkid) values ('DEFAULT_IMP', ' ', 12, 0, 'S', '1', 'T', 'N', '00', 'N', 3);
insert into keyblkhdr(short_descr, descr, keytype, tmpltyp, schmtag, verid, algo, modeuse, keyvernum, export, lmkid) values ('DEFAULT_IMP', ' ', 13, 0, 'S', '1', 'T', 'N', '00', 'N', 3);
insert into keyblkhdr(short_descr, descr, keytype, tmpltyp, schmtag, verid, algo, modeuse, keyvernum, export, lmkid) values ('DEFAULT_IMP', ' ', 14, 0, 'S', '1', 'T', 'N', '00', 'N', 3);
insert into keyblkhdr(short_descr, descr, keytype, tmpltyp, schmtag, verid, algo, modeuse, keyvernum, export, lmkid) values ('DEFAULT_IMP', ' ', 15, 0, 'S', '1', 'T', 'N', '00', 'N', 3);
insert into keyblkhdr(short_descr, descr, keytype, tmpltyp, schmtag, verid, algo, modeuse, keyvernum, export, lmkid) values ('DEFAULT_IMP', ' ', 21, 0, 'S', '1', 'T', 'N', '00', 'N', 3);
insert into keyblkhdr(short_descr, descr, keytype, tmpltyp, schmtag, verid, algo, modeuse, keyvernum, export, lmkid) values ('DEFAULT_IMP', ' ', 24, 0, 'S', '1', 'T', 'N', '00', 'N', 3);
insert into keyblkhdr(short_descr, descr, keytype, tmpltyp, schmtag, verid, algo, modeuse, keyvernum, export, lmkid) values ('DEFAULT_IMP', ' ', 41, 0, 'S', '1', 'T', 'N', '00', 'N', 3);

