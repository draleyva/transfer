
alter table TknTxnReqLog add
(
	bnddevidx	number(5,0),
        tknusrid	varchar2(11),
        tknusrapptype	number(5,0),
        tknauthfacta	number(5,0),
        tknauthfactb	number(5,0),
        tknauthamt	float(16),
        tknreqtspid	varchar2(11)
);
