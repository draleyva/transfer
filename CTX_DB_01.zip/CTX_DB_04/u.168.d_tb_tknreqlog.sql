alter table tknreqlog add
(
	panissuedate	date,
	panactivationdate	date,
	orgtkntype	char(2),
	orgdevtype	number(5,0),
	orgdevid	varchar2(48)
);
