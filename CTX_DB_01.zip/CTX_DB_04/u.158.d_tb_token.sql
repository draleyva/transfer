
alter table Token add
(
	orgtoken		varchar2(19),
	orgtknasslevel		number(5,0),
	orgtknrequestorid	varchar2(11),
	orgtur			varchar2(48),
	tknreqtspid		varchar2(11)
);

