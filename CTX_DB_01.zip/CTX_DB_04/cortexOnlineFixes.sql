--Prpduct Subtype hace falta información
call addupd_strdescr('EN', 'pst', 0, 'Not supported (default)');
call addupd_strdescr('EN', 'pst', 1, 'Contra account validation');

--Pantalla Token
--La columna CRDHLDDISABLDPYMTCHN en la tabla token tiene valores que no debería tener 
Update cortex.token set CRDHLDDISABLDPYMTCHN = null where CRDHLDDISABLDPYMTCHN  is not null;

commit;

--Usuarios sin fecha de password
--Poblar el campo PswdSetDate en la tabla USR. 
update cortex.usr set PSWDSETDATE = SYSDATE  where PSWDSETDATE is null;

commit;