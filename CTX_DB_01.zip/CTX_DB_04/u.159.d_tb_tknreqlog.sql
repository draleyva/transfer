
alter table tknreqlog add
(
	bnddevidx		number(5,0),
        tknusrid		varchar2(11),
        tknusrapptype		number(5,0),
        mrchid			varchar2(8),
        mrchname		varchar2(256),
        orgtoken		varchar2(19),
        orgtknasslevel		number(5,0),
        orgtknrequestorid	varchar2(11),
        orgtur			varchar2(48),
        tknreqtspid		varchar2(11)
);		
