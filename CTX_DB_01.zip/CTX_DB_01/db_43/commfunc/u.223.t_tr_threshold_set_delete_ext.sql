create or replace trigger threshold_set_delete before delete on threshold_set
referencing old as old_rec
for each row
begin
	write_threshold_set_hist(:old_rec.id, 'D', :old_rec.set_code,
		:old_rec.inst_id, :old_rec.evalset_id, :old_rec.aggr_def_id,
		:old_rec.currcode, :old_rec.descr, :old_rec.limit_code, :old_rec.activity_id);
end;
/

