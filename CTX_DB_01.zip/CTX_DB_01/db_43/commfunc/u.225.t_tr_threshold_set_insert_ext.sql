create or replace trigger threshold_set_insert before insert on threshold_set
referencing new as new_rec
for each row
begin
	if ( :new_rec.id is NULL or :new_rec.id = 0 ) then
		select threshold_set_sequence.NEXTVAL into :new_rec.id from dual;
	end if;

	write_threshold_set_hist(:new_rec.id, 'A', :new_rec.set_code,
		:new_rec.inst_id, :new_rec.evalset_id, :new_rec.aggr_def_id,
		:new_rec.currcode, :new_rec.descr, :new_rec.limit_code, :new_rec.activity_id);
end;
/

