create or replace procedure write_threshold_set_hist
	(i_set_id	threshold_set_hist.set_id%type,
	 i_action	threshold_set_hist.action%type,
         i_set_code	threshold_set_hist.set_code%type,
         i_inst_id	threshold_set.inst_id%type,
         i_evalset_id	threshold_set_hist.evalset_id%type,
         i_aggr_def_id	threshold_set_hist.aggr_def_id%type,
         i_currcode	threshold_set_hist.currcode%type,
         i_descr	threshold_set_hist.descr%type,
		 i_limit_code threshold_set_hist.limit_code%type,
	 i_activity_id	threshold_set_hist.activity_id%type)
is
	x_timestamp	threshold_set_hist.timechg%type;
	in_inst_id	threshold_set.inst_id%type := i_inst_id;
begin

	-- get the system time
	select systimestamp into x_timestamp from dual;

	if in_inst_id is null then
		in_inst_id := 0;
	end if;

	insert into threshold_set_hist(set_id, timechg, action, set_code,
					inst_id, evalset_id, aggr_def_id,
						currcode, descr, limit_code, activity_id)
		values
			(i_set_id, x_timestamp, i_action, i_set_code,
			in_inst_id, i_evalset_id, i_aggr_def_id, i_currcode,
						i_descr, i_limit_code, i_activity_id);
end;

.
/

