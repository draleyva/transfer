CREATE OR REPLACE TRIGGER threshold_insert BEFORE INSERT on threshold
REFERENCING NEW AS new_rec
FOR EACH ROW
BEGIN

	if (:new_rec.id is null or :new_rec.id = 0) then
		select threshold_sequence.nextval into :new_rec.id from dual;
	end if;


	write_threshold_hist(:new_rec.id, 'A', :new_rec.set_id,
		:new_rec.max_value, :new_rec.max_count, :new_rec.time_period, :new_rec.percent_limit,
		:new_rec.priority, :new_rec.descr, :new_rec.activity_id);

END;
/

