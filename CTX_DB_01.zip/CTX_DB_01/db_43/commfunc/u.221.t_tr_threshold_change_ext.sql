CREATE OR REPLACE TRIGGER threshold_change BEFORE UPDATE on threshold
REFERENCING OLD AS old_rec NEW AS new_threshold
FOR EACH ROW
BEGIN
	:new_threshold.verno_ctx := :old_rec.verno_ctx + 1;

	write_threshold_hist(:old_rec.id, 'C', :old_rec.set_id,
		:old_rec.max_value, :old_rec.max_count, :old_rec.time_period, :old_rec.percent_limit,
		:old_rec.priority, :old_rec.descr, :old_rec.activity_id);

END;
/

