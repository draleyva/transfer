create or replace trigger threshold_delete before delete on threshold
referencing old as old_rec
for each row
begin
	write_threshold_hist(:old_rec.id, 'D', :old_rec.set_id,
		:old_rec.max_value, :old_rec.max_count, :old_rec.time_period, :old_rec.percent_limit,
		:old_rec.priority, :old_rec.descr, :old_rec.activity_id);
end;
/

