create or replace procedure write_threshold_hist
	(i_threshold_id	threshold_hist.threshold_id%type,
	 i_action	threshold_hist.action%type,
         i_set_id	threshold_hist.set_id%type,
         i_max_value	threshold_hist.max_value%type,
         i_max_count	threshold_hist.max_count%type,
         i_time_period	threshold_hist.time_period%type,
		 i_percent_limit	threshold_hist.percent_limit%type,
         i_priority	threshold_hist.priority%type,
         i_descr	threshold_hist.descr%type,
	 i_activity_id	threshold_hist.activity_id%type)
is
	x_timestamp	threshold_hist.timechg%type;
begin
	-- get the system time
	select systimestamp into x_timestamp from dual;

	insert into threshold_hist(threshold_id, timechg, action, set_id,
			max_value, max_count, time_period, percent_limit, priority, descr,
						activity_id)
		values
			(i_threshold_id, x_timestamp, i_action, i_set_id,
			i_max_value, i_max_count, i_time_period, i_percent_limit, i_priority,
						i_descr, i_activity_id);
end;

.
/

