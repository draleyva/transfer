create or replace trigger threshold_set_change before update on threshold_set
referencing old as old_rec new as newrec
for each row
begin
	:newrec.verno_ctx := :old_rec.verno_ctx + 1;

	write_threshold_set_hist(:old_rec.id, 'C', :old_rec.set_code,
		:old_rec.inst_id, :old_rec.evalset_id, :old_rec.aggr_def_id,
		:old_rec.currcode, :old_rec.descr, :old_rec.limit_code, :old_rec.activity_id);

end;
/

