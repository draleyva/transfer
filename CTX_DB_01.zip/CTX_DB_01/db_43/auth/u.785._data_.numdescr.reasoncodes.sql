
execute procedure addupd_numdescr('EN', 'reason', 4367, 'Auth reversal, last deferred advice');
