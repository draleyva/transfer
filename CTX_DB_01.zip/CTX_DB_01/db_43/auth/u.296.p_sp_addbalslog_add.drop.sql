-- #(@) BA784411 $Id: //prod/cortex/c/modules/auth/auth-6.4/src/crdb/patches_ora/u.296.p_sp_addbalslog_add.drop.sql#1 $
-- #(@) BA784411 $Author: jvenerac $
-- #(@) BA784411 $DateTime: 2022/05/19 14:39:56 $
-- #(@) BA784411 $Change: 271467 $
-- _________________________ End of P4 stamps ____________________

drop procedure accbalslog_add;

