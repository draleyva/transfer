call addupd_event('gppc_procerr', 1, 'Processing error (%s)', 'Processing Error', 'EN');
call addupd_event('gppc_valerr', 2, 'Validation error (%s)', 'Validation Error', 'EN');
call addupd_event('gppc_batch', 4, 'Card batch (%s)', 'Card batch', 'EN');
call addupd_event('gppc_success', 4, 'Cards generated (%s)', 'Cards generated', 'EN');
