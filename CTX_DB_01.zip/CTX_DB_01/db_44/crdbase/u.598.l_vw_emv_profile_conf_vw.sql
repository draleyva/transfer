CREATE OR REPLACE VIEW emv_profile_conf_vw
(prof_id, prof_shortdescr, prof_descr, prof_scheme, prof_chipref, prof_version, 
conf_id, conf_shortdescr, conf_descr, conf_emvoda, conf_icckeydev, conf_atclimit, conf_arqcfailact, conf_arqcfailrsp, conf_iccpinfmt, conf_scriptset, 
mc_id, mc_shortdescr, mc_descr, mc_appln_ctl, mc_appln_ctlcl, mc_accum1_ctl, mc_accum1_ctlcl, mc_accum2_ctl, mc_accum2_ctlcl, mc_cntr1_ctl, mc_cntr1_ctlcl, mc_cntr2_ctl, mc_cntr2_ctlcl, 
vis_id, vis_shortdescr, vis_descr, vis_emviddschconf, vis_emviddoptconf, 
amx_id, amx_shortdescr, amx_descr, upi_id, upi_shortdescr, upi_descr)
AS
select 
    emvprof.ID prof_id, 
    emvprof.SHORT_DESCR prof_shortdescr, 
    emvprof.DESCR prof_descr, 
    emvprof.SCHEME prof_scheme, 
    emvprof.CHIPREF prof_chipref, 
    emvprof.VERSION prof_version, 
    emvconf.ID conf_id, 
    emvconf.SHORT_DESCR conf_shortdescr, 
    emvconf.DESCR conf_descr, 
    emvconf.EMVODA conf_emvoda, 
    emvconf.ICCKEYDEV conf_icckeydev, 
    emvconf.ATCLIMIT conf_atclimit, 
    emvconf.ARQCFAILACT conf_arqcfailact, 
    emvconf.ARQCFAILRSP conf_arqcfailrsp, 
    emvconf.ICCPINFMT conf_iccpinfmt, 
    emvconf.SCRIPTSET conf_scriptset,
    emvconfmc.id,
    emvconfmc.short_descr,
    emvconfmc.descr,
    emvconfmc.appln_ctl,
    emvconfmc.appln_ctl_cl,
    emvconfmc.accum1_ctl,
    emvconfmc.accum1_ctl_cl,
    emvconfmc.accum2_ctl,
    emvconfmc.accum2_ctl_cl,
    emvconfmc.cntr1_ctl,
    emvconfmc.cntr1_ctl_cl,
    emvconfmc.cntr2_ctl,
    emvconfmc.cntr2_ctl_cl,
    emvconfvis.id,
    emvconfvis.short_descr,
    emvconfvis.descr,
    emvconfvis.emviddschconf, 
    emvconfvis.emviddoptconf, 
    emvconfamx.id,
    emvconfamx.short_descr,
    emvconfamx.descr, 
    emvconfupi.id,
    emvconfupi.short_descr,
    emvconfupi.descr
from EMVPROFILE emvprof 
INNER JOIN EMVCONF emvconf ON (emvprof.EMVCONF_ID = emvconf.ID)
LEFT OUTER JOIN EMVCONF_MC emvconfmc ON (emvconfmc.ID = emvprof.EMVCONF_X_ID and emvprof.SCHEME = 1)
LEFT OUTER JOIN EMVCONF_VIS emvconfvis ON (emvconfvis.ID = emvprof.EMVCONF_X_ID and emvprof.SCHEME = 0)  
LEFT OUTER JOIN EMVCONF_AMX emvconfamx ON (emvconfamx.ID = emvprof.EMVCONF_X_ID and emvprof.SCHEME = 2)
LEFT OUTER JOIN EMVCONF_UPI emvconfupi ON (emvconfupi.ID = emvprof.EMVCONF_X_ID and emvprof.SCHEME = 4);

