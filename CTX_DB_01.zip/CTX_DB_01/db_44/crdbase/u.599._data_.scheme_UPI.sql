insert into SCHEME(verno_ctx, scheme, impcmd)
        values (4, 'UPI', 'Union Pay Card');


