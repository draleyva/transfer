CREATE TRIGGER emvconf_upi_change BEFORE UPDATE ON emvconf_upi
REFERENCING OLD old_emvconf_upi NEW new_emvconf_upi
FOR EACH ROW
BEGIN
	:new_emvconf_upi.verno_ctx := :old_emvconf_upi.verno_ctx + 1;
END;
/

