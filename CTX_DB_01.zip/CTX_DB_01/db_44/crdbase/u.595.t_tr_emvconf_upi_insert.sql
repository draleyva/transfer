CREATE OR REPLACE TRIGGER emvconf_upi_insert BEFORE INSERT ON emvconf_upi
REFERENCING NEW AS new_emvconf_upi
FOR EACH ROW
BEGIN
        IF (:new_emvconf_upi.id IS NULL OR :new_emvconf_upi.id = 0) THEN
                SELECT emvconf_upi_sequence.nextval INTO :new_emvconf_upi.id FROM dual;
        END IF;
END;
/

