CREATE OR REPLACE VIEW emvconfupi AS
SELECT
	p.emvconf_x_id AS ecx_id,
	p.emvconf_id AS ec_id,
	c.short_descr  AS ec_shortdescr,
	c.emvoda,
	c.icckeydev,
	c.atclimit,
	c.arqcfailact,
	c.arqcfailrsp,
	c.iccpinfmt,
	c.scriptset,
	u.short_descr AS eca_shortdescr
FROM EMVPROFILE p
INNER JOIN EMVCONF c ON (c.id = p.emvconf_id)
INNER JOIN EMVCONF_UPI u ON (u.id = p.emvconf_x_id)
WHERE p.scheme=4;

