-- Schema for table: emvconf_upi

CREATE TABLE emvconf_upi
(
	verno_ctx		number(10,0)	default 1	not null,
	id			number(10,0)	default 0 	not null,
	short_descr		varchar2(20)	default ' '	not null,
	descr			varchar2(128)
);

CREATE SEQUENCE emvconf_upi_sequence START WITH 1 MAXVALUE 9999999999 CYCLE;

