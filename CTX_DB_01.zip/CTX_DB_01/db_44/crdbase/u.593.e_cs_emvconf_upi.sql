-- primary key and constraint from d_tb_emvconf_upi.sql

CREATE UNIQUE INDEX hash_emvconf_upi
	ON emvconf_upi (short_descr);

ALTER TABLE emvconf_upi
	ADD CONSTRAINT hash_emvconf_upi UNIQUE (short_descr);

CREATE UNIQUE INDEX pk_emvconf_upi
	ON emvconf_upi (id);

ALTER TABLE emvconf_upi ADD CONSTRAINT pk_emvconf_upi
	PRIMARY KEY (id); 
