insert into EMVCRPTVER(verno_ctx, gid, ver, crpttype, fieldlist, append, var) 
	values (1,4,1,0,'1,2,3,4,5,6,7,8,9,10,11','80', 0);
insert into EMVCRPTVER(verno_ctx, gid, ver, crpttype, fieldlist, append, var) 
	values (1,4,1,1,'1,2,3,4,5,6,7,8,9,10,11','80', 0);
insert into EMVCRPTVER(verno_ctx, gid, ver, crpttype, fieldlist, append, var) 
	values (1,4,1,2,'1,2,3,4,5,6,7,8,9,10,11','80', 0);
insert into EMVCRPTVER(verno_ctx, gid, ver, crpttype, fieldlist, append, var) 
	values (1,4,1,3,'1,2,3,4,5,6,7,8,9,10,11','80', 0);


