
alter table issuerapp add
(
        srcaddress      varchar2(64)
);

