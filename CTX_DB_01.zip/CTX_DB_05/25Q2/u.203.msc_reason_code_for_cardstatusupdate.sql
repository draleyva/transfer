create or replace procedure msc_crdtknreaoncodeupd as

t_maxtag     number;

begin


   select max(descrtag) into t_maxtag from descr;

   t_maxtag := t_maxtag + 1;

   insert into descr (descrtag, descr, lang) values (t_maxtag, '1801', 'EN');
   insert into msc (verno_ctx, tag, idx, mscmodule, descr, mask, string_t, long_t, short_t, double_t, date_t) values (0, 'MRC_REQ_TKN_DEACTIVATE',0, 'ds', t_maxtag, 2,'Due to card Deactivation', 0,0,0,'22630831');

 t_maxtag := t_maxtag + 1;

   insert into descr (descrtag, descr, lang) values (t_maxtag, '1802', 'EN');
   insert into msc (verno_ctx, tag, idx, mscmodule, descr, mask, string_t, long_t, short_t, double_t, date_t) values (0, 'MRC_REQ_TKN_SUSPEND',0, 'ds', t_maxtag, 2,'Due to card Suspend', 0,0,0,'22630831');

 t_maxtag := t_maxtag + 1;

   insert into descr (descrtag, descr, lang) values (t_maxtag, '1803', 'EN');
   insert into msc (verno_ctx, tag, idx, mscmodule, descr, mask, string_t, long_t, short_t, double_t, date_t) values (0, 'MRC_REQ_TKN_RESUME',0, 'ds', t_maxtag, 2,'Due to card Resume', 0,0,0,'22630831');


end;
/
.

CALL msc_crdtknreaoncodeupd();

DROP PROCEDURE msc_crdtknreaoncodeupd;

