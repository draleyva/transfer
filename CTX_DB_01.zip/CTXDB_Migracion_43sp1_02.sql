

SPOOL ./CTX_DB_02_out.txt

-- 44_1

@./CTX_DB_02/db_44_1/u.042.d_tb_additionals_add_type.sql
@./CTX_DB_02/db_44_1/u.304.d_tb_aprvlcode.token.sql
@./CTX_DB_02/db_44_1/u.305.d_tb_aprvlhist.token.sql
@./CTX_DB_02/db_44_1/u.842._data_.strdescr.resp_code.sql
@./CTX_DB_02/db_44_1/u.843._data_.strdescr.elim_resp_code.sql
@./CTX_DB_02/db_44_1/u.844._data_.strdescr.subtxncodes.sql
@./CTX_DB_02/db_44_1/u.845._data_.keyblkhdr_3deslmk_3des_default_imp.sql
@./CTX_DB_02/db_44_1/u.846._data_.keyblkhdr_aeslmk_3des_default_imp.sql


@./CTX_DB_03/u.158.p_sp_addupd_msc.sql
@./CTX_DB_03/u.560.d_tb_crdproduct_atctolerance_LATAM.sql
@./CTX_DB_03/u.561.d_tb_crddet_emvcrdseqno_LATAM.sql
@./CTX_DB_03/u.564.d_tb_crdpin.pin_len_LATAM.sql
@./CTX_DB_03/u.830.p_sp_get_issuer_tz4when_created__disabled.sql
@./CTX_DB_03/u.830.p_sp_get_issuer_tz4when_created__enabled.sql
@./CTX_DB_03/u.831.p_sp_get_timestamp.sql
@./CTX_DB_03/u.833.p_sp_tenant_local_date.sql


-- 44

@./CTX_DB_02/db_44/crdbase/u.600.d_tb_crdproduct.sql
@./CTX_DB_02/db_44/crdbase/u.601.h_ky_crdproduct.sql
@./CTX_DB_02/db_44/crdbase/u.602._data_numdescr_binspo.sql
@./CTX_DB_02/db_44/crdbase/u.608.p_sp_tenant_local_date_by_crddet.sql
@./CTX_DB_02/db_44/crdbase/u.609.t_tr_crdpin_insert.sql
@./CTX_DB_02/db_44/crdbase/u.610.t_tr_crdpin_change.sql
@./CTX_DB_02/db_44/crdbase/u.611.d_tb_crdformat_ibm_offset_new_fields.sql
@./CTX_DB_02/db_44/crdbase/u.612.d_tb_crdpin_ibm_offset_new_fields.sql
@./CTX_DB_02/db_44/crdbase/u.613._data_.clean_pinblk_ibmoffset_migration.sql
@./CTX_DB_02/db_44/crdbase/u.614.t_tr_crdpin_change.ibm_offset.sql


@./CTX_DB_04/u.158.d_tb_token.sql
@./CTX_DB_04/u.159.d_tb_tknreqlog.sql
@./CTX_DB_04/u.160.d_tb_tkntxnreqlog.sql
@./CTX_DB_04/u.167.d_tb_token.sql
@./CTX_DB_04/u.168.d_tb_tknreqlog.sql
@./CTX_DB_04/u.170.p_sp_get_instid_by_tknreqlog.sql
@./CTX_DB_04/u.171.p_sp_get_instid_by_tknrsplog.sql
@./CTX_DB_04/u.172.p_sp_get_timestamp_by_token.sql
@./CTX_DB_04/u.174.t_tr_tknreqlog_insert.sql
@./CTX_DB_04/u.176.t_tr_tknrsplog_insert.sql
@./CTX_DB_04/u.182.t_tr_token_insert.sql
@./CTX_DB_04/u.184.d_tb_tknreqlog.sql
@./CTX_DB_04/u.185.d_tb_tknreqlog.sql

commit;

SPOOL OFF


