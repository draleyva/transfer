

ALTER TABLE crdproduct ADD
(
	atctolerancebckwds       number(10,0)   default 0,
	atctolerancefwds         number(10,0)   default 0
);
