

ALTER TABLE crddet ADD
(
	emvcrdseqno       number(5,0)   default 0,
	emvcrdseqno_old   number(5,0)   default 0
);
