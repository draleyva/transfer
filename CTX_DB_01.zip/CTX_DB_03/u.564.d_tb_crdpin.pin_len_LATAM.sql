

ALTER TABLE crdpin ADD
(
	pin_len       number(5,0)   default 4 not null,
	org_pin_len   number(5,0)   default 4 not null
);
