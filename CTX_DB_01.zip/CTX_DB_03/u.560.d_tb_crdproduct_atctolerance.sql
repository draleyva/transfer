-- CTXDEV-1929: ATC tolerance for backwards and forwards

ALTER TABLE crdproduct ADD (
	atctolerancebckwds	number(10,0)	default 0,
	atctolerancefwds	number(10,0)	default 0
);

