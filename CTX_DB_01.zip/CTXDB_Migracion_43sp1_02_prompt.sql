

SPOOL ./CTX_DB_02_out.txt

-- 44_1


--prompt u.042.d_tb_additionals_add_type
--@./CTX_DB_02/db_44_1/u.042.d_tb_additionals_add_type.sql

prompt u.304.d_tb_aprvlcode.token
@./CTX_DB_02/db_44_1/u.304.d_tb_aprvlcode.token.sql

prompt u.305.d_tb_aprvlhist.token
@./CTX_DB_02/db_44_1/u.305.d_tb_aprvlhist.token.sql

prompt u.842._data_.strdescr.resp_code
@./CTX_DB_02/db_44_1/u.842._data_.strdescr.resp_code.sql

prompt u.843._data_.strdescr.elim_resp_code
@./CTX_DB_02/db_44_1/u.843._data_.strdescr.elim_resp_code.sql

prompt u.844._data_.strdescr.subtxncodes
@./CTX_DB_02/db_44_1/u.844._data_.strdescr.subtxncodes.sql

prompt u.845._data_.keyblkhdr_3deslmk_3des_default_imp
@./CTX_DB_02/db_44_1/u.845._data_.keyblkhdr_3deslmk_3des_default_imp.sql

--prompt u.846._data_.keyblkhdr_aeslmk_3des_default_imp
--@./CTX_DB_02/db_44_1/u.846._data_.keyblkhdr_aeslmk_3des_default_imp.sql

--


--prompt u.158.p_sp_addupd_msc
--@./CTX_DB_03/u.158.p_sp_addupd_msc.sql

prompt u.560.d_tb_crdproduct_atctolerance
@./CTX_DB_03/u.560.d_tb_crdproduct_atctolerance.sql

prompt u.561.d_tb_crddet_emvcrdseqno
@./CTX_DB_03/u.561.d_tb_crddet_emvcrdseqno.sql

prompt u.564.d_tb_crdpin.pin_len
@./CTX_DB_03/u.564.d_tb_crdpin.pin_len.sql

--prompt u.830.p_sp_get_issuer_tz4when_created__disabled
--@./CTX_DB_03/u.830.p_sp_get_issuer_tz4when_created__disabled.sql

prompt u.830.p_sp_get_issuer_tz4when_created__enabled
@./CTX_DB_03/u.830.p_sp_get_issuer_tz4when_created__enabled.sql

prompt u.831.p_sp_get_timestamp
@./CTX_DB_03/u.831.p_sp_get_timestamp.sql

prompt u.833.p_sp_tenant_local_date
@./CTX_DB_03/u.833.p_sp_tenant_local_date.sql


-- 44


prompt u.600.d_tb_crdproduct
@./CTX_DB_02/db_44/crdbase/u.600.d_tb_crdproduct.sql

prompt u.601.h_ky_crdproduct
@./CTX_DB_02/db_44/crdbase/u.601.h_ky_crdproduct.sql

prompt u.602._data_numdescr_binspo
@./CTX_DB_02/db_44/crdbase/u.602._data_numdescr_binspo.sql

prompt u.608.p_sp_tenant_local_date_by_crddet
@./CTX_DB_02/db_44/crdbase/u.608.p_sp_tenant_local_date_by_crddet.sql

prompt u.609.t_tr_crdpin_insert
@./CTX_DB_02/db_44/crdbase/u.609.t_tr_crdpin_insert.sql

prompt u.610.t_tr_crdpin_change
@./CTX_DB_02/db_44/crdbase/u.610.t_tr_crdpin_change.sql

prompt u.611.d_tb_crdformat_ibm_offset_new_fields
@./CTX_DB_02/db_44/crdbase/u.611.d_tb_crdformat_ibm_offset_new_fields.sql

prompt u.612.d_tb_crdpin_ibm_offset_new_fields
@./CTX_DB_02/db_44/crdbase/u.612.d_tb_crdpin_ibm_offset_new_fields.sql

prompt u.613._data_.clean_pinblk_ibmoffset_migration
@./CTX_DB_02/db_44/crdbase/u.613._data_.clean_pinblk_ibmoffset_migration.sql

prompt u.614.t_tr_crdpin_change.ibm_offset
@./CTX_DB_02/db_44/crdbase/u.614.t_tr_crdpin_change.ibm_offset.sql

--

prompt u.158.d_tb_token
@./CTX_DB_04/u.158.d_tb_token.sql

prompt u.159.d_tb_tknreqlog
@./CTX_DB_04/u.159.d_tb_tknreqlog.sql

prompt u.160.d_tb_tkntxnreqlog
@./CTX_DB_04/u.160.d_tb_tkntxnreqlog.sql

prompt u.167.d_tb_token
@./CTX_DB_04/u.167.d_tb_token.sql

prompt u.168.d_tb_tknreqlog
@./CTX_DB_04/u.168.d_tb_tknreqlog.sql

prompt u.170.p_sp_get_instid_by_tknreqlog
@./CTX_DB_04/u.170.p_sp_get_instid_by_tknreqlog.sql

prompt u.171.p_sp_get_instid_by_tknrsplog
@./CTX_DB_04/u.171.p_sp_get_instid_by_tknrsplog.sql

prompt u.172.p_sp_get_timestamp_by_token
@./CTX_DB_04/u.172.p_sp_get_timestamp_by_token.sql

prompt u.174.t_tr_tknreqlog_insert
@./CTX_DB_04/u.174.t_tr_tknreqlog_insert.sql

prompt u.176.t_tr_tknrsplog_insert
@./CTX_DB_04/u.176.t_tr_tknrsplog_insert.sql

prompt u.182.t_tr_token_insert
@./CTX_DB_04/u.182.t_tr_token_insert.sql

prompt u.184.d_tb_tknreqlog
@./CTX_DB_04/u.184.d_tb_tknreqlog.sql

prompt u.185.d_tb_tknreqlog
@./CTX_DB_04/u.185.d_tb_tknreqlog.sql

prompt cortexOnlineFixes
@./CTX_DB_04/cortexOnlineFixes.sql

prompt u.900.update_crdproduct.sql
@./CTX_DB_04/u.900.update_crdproduct.sql

commit;

SPOOL OFF




