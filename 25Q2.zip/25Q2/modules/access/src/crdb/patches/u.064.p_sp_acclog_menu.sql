create procedure acclog_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag		int;
define t_maxorder  int;
define t_menuorder int;
define i int;


	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag
		from descr;
    
    
    let t_menuorder = 0;
    
           
    select max(morder) into t_menuorder from menu where mitem ='au_' and usrgrp=p_usrgrp;
    
    let t_menuorder = t_menuorder + 1;
    

    let t_maxtag = t_maxtag + 1;
    --Account Update History
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Account Update History', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('au_accupdhis', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('au_accupdhis', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('au_','au_accupdhis',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    let t_maxtag = t_maxtag + 1;
    --Search Account Update log 
       
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Account Update Log', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_acclogsch', 'J2EF', ' ', 'iaacclogsearchon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_acclogsch', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('au_accupdhis','ia_acclogsch',t_maxtag,2,p_usrgrp,'J2EF');

end procedure;

execute procedure acclog_menu("cortex");

drop procedure acclog_menu;

