
-- dummy trigger to match Oracle serial id trigger
