
alter table usr modify
( 
	extusr		nvarchar(100)		not null
); 
