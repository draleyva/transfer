UPDATE ACSITEM SET COMMAND = 'usrgrpaddon.do' WHERE ACSITEM = 'ad_grpdesa';
UPDATE ACSITEM SET COMMAND ='usrgrpdescron.do' WHERE ACSITEM = 'ad_grpdesu';
