alter table nasuser
add
(
	lstlogtime	integer		default 0	not null,
	unslogdate	date		default TODAY	not null,
	unslogtime	integer		default 0	not null
);
