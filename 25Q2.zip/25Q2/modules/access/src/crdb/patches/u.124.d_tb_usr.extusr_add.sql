
alter table usr add
(
	extusr		nvarchar(100)		
);
