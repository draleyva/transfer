create procedure remove_card_program_menu( )
define	 t_tag_card_program integer;
define	 t_tag_add_card_program integer;
define	 t_tag_search_card_program integer;
	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
	select descrtag into t_tag_card_program from menu where acsitem='ia_crdprogrm';
	select descrtag into t_tag_add_card_program from menu where mitem = 'ia_crdprogrm' and acsitem='ia_crdprgdd';
	select descrtag into t_tag_search_card_program from menu where mitem = 'ia_crdprogrm' and acsitem='ia_crdprgsch';

	-- Add Card program
	delete from descr where descrtag = t_tag_add_card_program;
	delete from grpperm where acsitem = 'ia_crdprgdd';
	delete from menu where mitem = 'ia_crdprogrm' and acsitem='ia_crdprgdd';
	delete from acsitem where acsitem = 'ia_crdprgdd';
	
	-- Search Card program	
	delete from descr where descrtag = t_tag_search_card_program;
	delete from grpperm where acsitem = 'ia_crdprgsch';
	delete from menu where mitem = 'ia_crdprogrm' and acsitem='ia_crdprgsch';
	delete from acsitem where acsitem = 'ia_crdprgsch';

	-- Card program	
	delete from descr where descrtag = t_tag_card_program;
	delete from grpperm where acsitem = 'ia_crdprogrm';
	delete from menu where mitem = 'ia_maint' and acsitem='ia_crdprogrm';
	delete from acsitem where acsitem = 'ia_crdprogrm';
	
end procedure;

execute procedure remove_card_program_menu();

drop procedure remove_card_program_menu;
