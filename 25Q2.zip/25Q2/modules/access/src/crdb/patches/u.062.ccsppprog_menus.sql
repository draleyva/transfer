create procedure ccsppprog_menus(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;

    -- CreditCard > Maintanance > Payment Plan Program
    let t_menuorder = 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'ccs_maint' and usrgrp = p_usrgrp;
    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Payment Plan Program','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ccs_ppprog','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ccs_ppprog',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ccs_maint','ccs_ppprog',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- CreditCard > Maintanance > Payment Plan Program > Add
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ccs_ppprogd','J2EF',' ','ccs/ccsccsppprogdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ccs_ppprogd',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ccs_ppprog','ccs_ppprogd',t_maxtag,1,p_usrgrp,'J2EF');

    -- CreditCard > Maintanance > Payment Plan Program > Search
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ccs_ppprogs','J2EF',' ','ccs/ccsccsppprogsearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ccs_ppprogs',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ccs_ppprog','ccs_ppprogs',t_maxtag,2,p_usrgrp,'J2EF');

end procedure;

execute procedure ccsppprog_menus("cortex");

drop procedure ccsppprog_menus;
