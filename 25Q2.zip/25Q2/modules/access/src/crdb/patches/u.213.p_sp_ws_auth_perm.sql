create procedure ws_auth_perm(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    like acsitem.descrtag;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;    

    --CORE
    -- NewForexRate webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'NewForexRate Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_newforexrate','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_newforexrate',p_usrgrp,'Y','N',15);
	
	--AUTH
	-- New Account Authorization Override webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'New Acc Auth Override Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_newaccauthov','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_newaccauthov',p_usrgrp,'Y','N',15);
	
	-- Send Transaction webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Send Transaction Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_sendtxnreq','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_sendtxnreq',p_usrgrp,'Y','N',15);
	
	-- Get Limit Card Details webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Get Limit Card Details Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_getlimitcard','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_getlimitcard',p_usrgrp,'Y','N',15);
	
	-- Account Load webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Account Load Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_accload','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_accload',p_usrgrp,'Y','N',15);
	
	-- Account Unload webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Account Unload Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_accunload','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_accunload',p_usrgrp,'Y','N',15);
	
	-- Get Account Items webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Get Account Items Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_getaccitems','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_getaccitems',p_usrgrp,'Y','N',15);
		
	--CCS
	-- Update Account Limit webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Update Account Limit Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_updateacclim','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_updateacclim',p_usrgrp,'Y','N',15);
	
	-- Get Credit Account Statement Summary webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Get Credit Account Stmt sumry Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_getcraccstmt','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_getcraccstmt',p_usrgrp,'Y','N',15);
	
	-- New CCS Item webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'New CCS Item Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_newccsitem','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_newccsitem',p_usrgrp,'Y','N',15);
	
	-- Get Credit Account webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Get Credit Account Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_getcraccdeta','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_getcraccdeta',p_usrgrp,'Y','N',15);

	-- Update Account status webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Update Account status Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_updateaccoun','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_updateaccoun',p_usrgrp,'Y','N',15);
	
	-- Get Credit Account Closing Balance Details webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Get Credit Account Close Bal Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_getcraccclos','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_getcraccclos',p_usrgrp,'Y','N',15);
	
	-- Cancel CCS Pay Plan webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Cancel CCS Pay Plan Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_cancelccspay','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_cancelccspay',p_usrgrp,'Y','N',15);
	
	-- New Pay Plan webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'New Pay Plan Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_newpayplan','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_newpayplan',p_usrgrp,'Y','N',15);
	
	--CRDBASE
		
	-- Get Card Accounts webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Get Card Accounts Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_getcardaccou','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_getcardaccou',p_usrgrp,'Y','N',15);
	
	--  Update Card Status webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Update Card Status Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_updatecardst','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_updatecardst',p_usrgrp,'Y','N',15);
	
	-- Set Risk Profile webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Set Risk Profile Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_updatecardri','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_updatecardri',p_usrgrp,'Y','N',15);
	
	-- Get Card Status webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Get Card Status Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_getcardstatu','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_getcardstatu',p_usrgrp,'Y','N',15);
	
	-- Get Card Balance webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Get Card Balance Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_getcardbalan','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_getcardbalan',p_usrgrp,'Y','N',15);
	
	-- Check Card Pin webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Check Card Pin Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_checkcardpin','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_checkcardpin',p_usrgrp,'Y','N',15);
	
	-- Validate Card webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Validate Card Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_validatecard','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_validatecard',p_usrgrp,'Y','N',15);
	
	-- Issuer webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Issuer Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_directive','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_directive',p_usrgrp,'Y','N',15);
	
	-- Description lookup webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Description lookup Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_descrlookup','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_descrlookup',p_usrgrp,'Y','N',15);
	
		
	-- set Risk Override webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'set Risk Override Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_setriskoverr','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_setriskoverr',p_usrgrp,'Y','N',15);
	
	-- Get Customer Card Account Details webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Get Customer Card Acc Details Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_getcustcarda','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_getcustcarda',p_usrgrp,'Y','N',15);
	
	-- Reset Pin Tries webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Reset Pin Tries Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_resetpintrie','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_resetpintrie',p_usrgrp,'Y','N',15);
	
	-- Encrypt/Decrypt Pan webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Encrypt/Decrypt Pan Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_encdecpan','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_encdecpan',p_usrgrp,'Y','N',15);
	
	-- Get Fee webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Get Fee Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_getfee','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_getfee',p_usrgrp,'Y','N',15);
	
	-- Get PIN Status over SMS webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Get PIN Status over SMS Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_getsmspinsta','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_getsmspinsta',p_usrgrp,'Y','N',15);
	
	-- Send PIN over SMS webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Send PIN over SMS Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_sendsmspin','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_sendsmspin',p_usrgrp,'Y','N',15);
	
	-- Update SMS Status webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Update SMS Status Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_updatesmssta','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_updatesmssta',p_usrgrp,'Y','N',15);
	
	-- Update Account Balance (Account Adjustments) webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Update Account Balance Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_updateaccbal','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_updateaccbal',p_usrgrp,'Y','N',15);
	
	-- Flag Card Renew webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Flag Card Renew Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_flagcardrene','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_flagcardrene',p_usrgrp,'Y','N',15);
	
	--  Link Pregenerated Pin webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Link Pregenerated Pin Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_linkpregenpi','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_linkpregenpi',p_usrgrp,'Y','N',15);
	
	--  Validate PIN Mailer webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Validate PIN Mailer Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_validatepinm','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_validatepinm',p_usrgrp,'Y','N',15);
	
	-- Account Balance webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Account Balance Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_getaccountba','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_getaccountba',p_usrgrp,'Y','N',15);
	
	-- Allocate Pin Mailer webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Allocate Pin Mailer Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_allocatepinm','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_allocatepinm',p_usrgrp,'Y','N',15);
	
	--Get Pin Reference webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Get Pin Reference Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_getpinrefere','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_getpinrefere',p_usrgrp,'Y','N',15);
    
end procedure;

execute procedure ws_auth_perm('cortex');

drop procedure ws_auth_perm;
