create procedure login_logout_acsitems()

define t_maxtag    like acsitem.descrtag;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Login','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag,audit_src_code)
        values ('login','J2EF',' ',' ',' ',t_maxtag,'cxo');

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Logout','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag,audit_src_code)
        values ('logout','J2EF',' ',' ',' ',t_maxtag,'cxo');

end procedure;

execute procedure login_logout_acsitems();

drop procedure login_logout_acsitems;
