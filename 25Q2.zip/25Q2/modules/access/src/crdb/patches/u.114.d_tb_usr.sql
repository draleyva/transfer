alter table usr add
( 
	id		integer
);