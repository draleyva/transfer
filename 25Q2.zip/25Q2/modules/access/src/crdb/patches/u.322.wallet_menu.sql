
create procedure wallet_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag		int;
define t_maxorder  int;
define t_menuorder int;
define i int;


	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag
		from descr;
    
	let t_menuorder = 0;
           
    select max(morder) into t_menuorder from menu where mitem ='prdcnfmaint' and usrgrp=p_usrgrp;
    
    let t_menuorder = t_menuorder + 1;
    
    let t_maxtag = t_maxtag + 1;
	
	-- Wallet

    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Wallet', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_wal', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_wal', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('prdcnfmaint','ia_wal',t_maxtag,t_menuorder,p_usrgrp,'J2EM');
	
		let t_maxtag = t_maxtag + 1;
	
	insert into descr (descrtag, descr, lang) values (t_maxtag, 'Wallet Definition', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_waldef', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_waldef', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_wal','ia_waldef',t_maxtag,1,p_usrgrp,'J2EM');
	
	let t_maxtag = t_maxtag + 1;
    
	-- Add

    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Add', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag, mkc_flag, mkc_src_code) values ('ia_waldefd', 'J2EF', ' ', 'iawalletdefinitiondetailon.do', ' ', t_maxtag, '1', 'CTX');
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_waldefd', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_waldef','ia_waldefd',t_maxtag,1,p_usrgrp,'J2EF');

    let t_maxtag = t_maxtag + 1;
	
    -- Search 

    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Search', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_waldefsch', 'J2EF', ' ', 'iawalletdefinitionsearchon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_waldefsch', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_waldef','ia_waldefsch',t_maxtag,2,p_usrgrp,'J2EF');

    let t_maxtag = t_maxtag + 1;
	
	insert into descr (descrtag, descr, lang) values (t_maxtag, 'Wallet Maintenance', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_walitmsmaint', 'J2EF', ' ', 'iawalitmsmainton.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_walitmsmaint', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_wal','ia_walitmsmaint',t_maxtag,2,p_usrgrp,'J2EF');
	
	let t_maxtag = t_maxtag + 1;
	
	insert into descr (descrtag, descr, lang) values (t_maxtag, 'Wallet Maintenance Add', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag, mkc_flag, mkc_src_code) values ('ia_walitmadd', 'J2EF', ' ', 'iawalitmaddon.do', ' ', t_maxtag, '1', 'CTX');
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_walitmadd', p_usrgrp, 'Y', 'N', '15');
	
	let t_maxtag = t_maxtag + 1;
	
	insert into descr (descrtag, descr, lang) values (t_maxtag, 'Wallet Item Reactivate', 'EN');
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values ('ia_walitmract','J2EF',' ',' ',' ',t_maxtag);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_walitmract', p_usrgrp, 'Y', 'N', '15');
	
	let t_maxtag = t_maxtag + 1;
	
	insert into descr (descrtag, descr, lang) values (t_maxtag, 'Wallet Item Deactivate', 'EN');
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values ('ia_walitmdact','J2EF',' ',' ',' ',t_maxtag);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_walitmdact', p_usrgrp, 'Y', 'N', '15');
	
	
end procedure;

execute procedure wallet_menu("cortex");

drop procedure wallet_menu;
