create procedure des_rule_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_hm','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_cn_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_cns_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_cn_c','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_cn_c1','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_cn_e','J2EF',' ',' ',' ',t_maxtag);


    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_m',p_usrgrp,'Y','N',8);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_hm',p_usrgrp,'Y','N',8);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_cn_m',p_usrgrp,'Y','N',8);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_cns_e',p_usrgrp,'Y','N',8);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_cn_c',p_usrgrp,'Y','N',8);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_cn_c1',p_usrgrp,'Y','N',8);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_cn_e',p_usrgrp,'Y','N',8);


    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'des_' and usrgrp = p_usrgrp;   
    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    
    insert into descr(descrtag,descr,lang) values(t_maxtag,'DES Rule Context','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_rule','J2EF',' ','wicket/des/rule',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('des_','des_rule',t_maxtag,t_menuorder,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_rule',p_usrgrp,'Y','N',8);
    
end procedure;

execute procedure des_rule_menu('cortex');

drop procedure des_rule_menu;
