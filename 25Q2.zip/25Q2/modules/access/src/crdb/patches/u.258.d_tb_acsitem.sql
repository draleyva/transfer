ALTER TABLE acsitem ADD inst_appl char(1) default '0' NOT NULL;
