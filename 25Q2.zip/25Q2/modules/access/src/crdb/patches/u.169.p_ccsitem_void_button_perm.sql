-- add permissions to  'Void' button in Credit Account Item screen
INSERT INTO acsitem(acsitem,acstype,shortname,command,helpform,descrtag) VALUES('ccs_itemvoid','J2EF',' ',' ',' ',0);
INSERT INTO grpperm(acsitem,usrgrp,mask,extpswd,optag) VALUES('ccs_itemvoid','cortex','Y','N',15);
