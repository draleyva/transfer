create procedure mchip_emv_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

    ON EXCEPTION
    END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;
    
    let t_menuorder = 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'prdcnfmaint' and usrgrp = p_usrgrp;
    let t_menuorder = t_menuorder + 1;

    -- Issuer > Product Configuration > EMV Configuration
    let t_maxtag = t_maxtag + 1; 
    insert into descr(descrtag,descr,lang) values(t_maxtag,'EMV Configuration','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emv_conf','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emv_conf',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('prdcnfmaint','emv_conf',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- Issuer > Product Configuration > EMV Configuration > Add
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvcnf_cr_ed','J2EF',' ','wicket/emv/emvconfig?action=create',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvcnf_cr_ed',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('emv_conf','emvcnf_cr_ed',t_maxtag,1,p_usrgrp,'J2EF');

    -- Issuer > Product Configuration > EMV Configuration > Search
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvcnf_sel','J2EF',' ','wicket/emv/emvconfig',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvcnf_sel',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('emv_conf','emvcnf_sel',t_maxtag,2,p_usrgrp,'J2EF');

    -- Issuer > Product Configuration > EMV Configuration MasterCard
    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'EMV Configuration MasterCard','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emv_confmc','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emv_confmc',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('prdcnfmaint','emv_confmc',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- Issuer > Product Configuration > EMV Configuration MasterCard > Add
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvcnfmc_cr_ed','J2EF',' ','wicket/emv/emvconfigmc?action=create',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvcnfmc_cr_ed',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('emv_confmc','emvcnfmc_cr_ed',t_maxtag,1,p_usrgrp,'J2EF');

    -- Issuer > Product Configuration > EMV Configuration MasterCard > Search
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvcnfmc_sel','J2EF',' ','wicket/emv/emvconfigmc',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvcnfmc_sel',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('emv_confmc','emvcnfmc_sel',t_maxtag,2,p_usrgrp,'J2EF');
    
    -- Issuer > Product Configuration > EMV Configuration Visa
    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'EMV Configuration Visa','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emv_confvis','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emv_confvis',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('prdcnfmaint','emv_confvis',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- Issuer > Product Configuration > EMV Configuration Visa > Add
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvcnfvis_cr_ed','J2EF',' ','wicket/emv/emvconfigvis?action=create',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvcnfvis_cr_ed',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('emv_confvis','emvcnfvis_cr_ed',t_maxtag,1,p_usrgrp,'J2EF');

    -- Issuer > Product Configuration > EMV Configuration Visa > Search
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvcnfvis_sel','J2EF',' ','wicket/emv/emvconfigvis',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvcnfvis_sel',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('emv_confvis','emvcnfvis_sel',t_maxtag,2,p_usrgrp,'J2EF');

    -- Issuer > Product Configuration > EMV Configuration Amex
    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'EMV Configuration Amex','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emv_confamx','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emv_confamx',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('prdcnfmaint','emv_confamx',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- Issuer > Product Configuration > EMV Configuration Amex > Add
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvcnfamx_cr_ed','J2EF',' ','wicket/emv/emvconfigamx?action=create',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvcnfamx_cr_ed',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('emv_confamx','emvcnfamx_cr_ed',t_maxtag,1,p_usrgrp,'J2EF');

    -- Issuer > Product Configuration > EMV Configuration Amex > Search
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvcnfamx_sel','J2EF',' ','wicket/emv/emvconfigamx',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvcnfamx_sel',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('emv_confamx','emvcnfamx_sel',t_maxtag,2,p_usrgrp,'J2EF');

    -- Issuer > Product Configuration > EMV Profile
    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'EMV Profile','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emv_profile','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emv_profile',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('prdcnfmaint','emv_profile',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- Issuer > Product Configuration > EMV Profile > Add
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvprofil_cr_ed','J2EF',' ','wicket/emv/emvprofile?action=create',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvprofil_cr_ed',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('emv_profile','emvprofil_cr_ed',t_maxtag,1,p_usrgrp,'J2EF');

    -- Issuer > Product Configuration > EMV Profile > Search
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvprofile_sel','J2EF',' ','wicket/emv/emvprofile',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvprofile_sel',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('emv_profile','emvprofile_sel',t_maxtag,2,p_usrgrp,'J2EF');

    --Permissions
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvcnf_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvcnfmc_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvcnfvis_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvcnfamx_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvprofil_m','J2EF',' ',' ',' ',t_maxtag);

    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvcnf_m',p_usrgrp,'Y','N',8);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvcnfmc_m',p_usrgrp,'Y','N',8);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvcnfvis_m',p_usrgrp,'Y','N',8);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvcnfamx_m',p_usrgrp,'Y','N',8);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvprofil_m',p_usrgrp,'Y','N',8);

end procedure;

execute procedure mchip_emv_menu("cortex");

drop procedure mchip_emv_menu;

