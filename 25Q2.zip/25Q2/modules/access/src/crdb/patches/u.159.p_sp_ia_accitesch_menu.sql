create procedure ia_accitesch(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    like acsitem.descrtag;
define t_menuorder like menu.morder;

            ON EXCEPTION
            END EXCEPTION WITH RESUME;
    
    select max(descrtag) into t_maxtag from descr;
        
    let t_maxtag = t_maxtag + 1;
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'View Account Items', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_accitesch', 'J2EF', ' ', 'iaaccitemssearchon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_accitesch', p_usrgrp, 'Y', 'N', '15');

end procedure;

execute procedure ia_accitesch('cortex');

drop procedure ia_accitesch;

