create procedure crdproduct_emvprof_search_perm(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
	select max(descrtag) into t_maxtag
		from descr;
		
	let t_maxtag = t_maxtag + 1;

	insert into descr (descrtag, descr, lang) values (t_maxtag, 'Emv Card Product Profile Search', 'EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvprfzms','J2EF',' ','emvprofilesearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvprfzms',p_usrgrp,'Y','N',8);
	
end procedure;

execute procedure crdproduct_emvprof_search_perm("cortex");

drop procedure crdproduct_emvprof_search_perm;

