create procedure new_acsitem(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    like acsitem.descrtag;

	ON EXCEPTION

	END EXCEPTION WITH RESUME;

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Pin Mailer Produce Selection','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag,audit_src_code) values('ia_pinprodsel','J2EF',' ',' ',' ',t_maxtag,'cxo');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_pinprodsel',p_usrgrp,'Y','N',8);

end procedure;

execute procedure new_acsitem('cortex');

drop procedure new_acsitem;
