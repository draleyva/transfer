create procedure remove_fixaccount_entries()
	ON EXCEPTION
	END EXCEPTION WITH RESUME;

	delete from screenfield where acsitem='ia_fixaccdet';
	delete from grpperm where acsitem='ia_fixaccdet';
	delete from acsitem where acsitem='ia_fixaccdet';
	
end procedure;

execute procedure remove_fixaccount_entries();

drop procedure remove_fixaccount_entries;

