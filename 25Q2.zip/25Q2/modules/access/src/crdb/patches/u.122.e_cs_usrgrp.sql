
create unique index hash_usrgrp on  usrgrp (id);

alter table usrgrp add constraint unique (id) constraint hash_usrgrp;

