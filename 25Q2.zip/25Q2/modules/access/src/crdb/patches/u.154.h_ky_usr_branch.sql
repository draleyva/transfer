-- Additional keys for table: usr_branch

create  index fk_usr_branch_branch_id_usr_id
	on usr_branch (branch_id, user_id) ;

create index fk_usr_branch_branch_id
	on usr_branch (branch_id) ;

create index fk_usr_branch_usr_id
	on usr_branch (user_id) ;

alter table usr_branch add constraint 
	foreign key (branch_id)
		references branch (id) constraint fk_usr_branch_branch_id;

alter table usr_branch add constraint 
	foreign key (user_id)
		references usr (id) constraint fk_usr_branch_usr_id;

