alter table usrgrp add
( 
	id		integer
);