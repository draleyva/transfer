
create unique index hash_acsitem on  acsitem (id);

alter table acsitem add constraint unique (id) constraint hash_acsitem;

