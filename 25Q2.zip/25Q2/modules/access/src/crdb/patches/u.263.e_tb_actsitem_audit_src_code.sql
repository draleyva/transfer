-- Add  audit_src_code to acsitem

select 'Add audit_src_code in acsitem table...'  from systables where tabid = 1;

alter table acsitem add (	
	audit_src_code varchar(32)
);
