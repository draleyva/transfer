create procedure new_acsitem(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    like acsitem.descrtag;

	ON EXCEPTION

	END EXCEPTION WITH RESUME;

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Produce Pin mailer Button','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag,audit_src_code) values('ia_pinprodbtn','J2EF',' ',' ',' ',t_maxtag,'cxo');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_pinprodbtn',p_usrgrp,'Y','N',8);

end procedure;

execute procedure new_acsitem('cortex');

drop procedure new_acsitem;
