create procedure ccs_pp_apprule(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    like acsitem.descrtag;
define t_menuorder like menu.morder;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;    

    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'ccs_maint' and usrgrp = p_usrgrp;   
    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Auto Payment Plan Rule','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ccs_ccsapprule','J2EF',' ','ccs/wicket/ccs/autopaymentplans',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ccs_maint','ccs_ccsapprule',t_maxtag,t_menuorder,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ccs_ccsapprule',p_usrgrp,'Y','N',15);
    
end procedure;

execute procedure ccs_pp_apprule('cortex');

drop procedure ccs_pp_apprule;
