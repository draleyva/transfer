-- version update trigger on usr_branch table

drop trigger usr_branch_update;

select 'creating trigger for usr_branch table' from systables where tabid = 1;


create trigger usr_branch_update update
on
        usr_branch
referencing old as old new as new
for each row
(
        execute procedure increment_int(new.verno_ctx) into verno_ctx
);
