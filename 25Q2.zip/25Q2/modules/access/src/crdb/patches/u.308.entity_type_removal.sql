delete from entity_type_bk where entity_type_id=(select id from entity_type where code='usr');
delete from entity_type where code='usr';
