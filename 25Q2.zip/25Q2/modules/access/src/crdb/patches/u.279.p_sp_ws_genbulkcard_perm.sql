create procedure ws_genbulkcard_perm(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    like acsitem.descrtag;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

	select max(descrtag) into t_maxtag from descr;    
	
	--CORE
	-- Generate Bulk Cards webservice
	let t_maxtag = t_maxtag + 1;
	insert into descr(descrtag,descr,lang) values(t_maxtag,'Generate Bulk Cards Web Service','EN');

	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_genbulkcards','J2EF',' ',' ',' ',t_maxtag);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_genbulkcards',p_usrgrp,'Y','N',8);

end procedure;

execute procedure ws_genbulkcard_perm('cortex');

drop procedure ws_genbulkcard_perm;