create procedure keyblkhdr_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;

    -- Core > Key Maintenance > Key Block Header
    let t_menuorder = 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'co_keymaint' and usrgrp = p_usrgrp;
    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Key Block Header','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('keyblkhdr','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('keyblkhdr',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_keymaint','keyblkhdr',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

	-- Core > Key Maintenance > Key Block Header > Add
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Create/Edit Key Block Header','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag,mkc_flag) values('keyblkhdr_cr_ed','J2EF',' ','wicket/core/keyblkhdr?action=create',' ',t_maxtag,'1');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('keyblkhdr_cr_ed',p_usrgrp,'Y','N',8);
	let t_maxtag = t_maxtag + 1;
	insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('keyblkhdr','keyblkhdr_cr_ed',t_maxtag,1,p_usrgrp,'J2EF');
	
    -- Core > Key Maintenance > Key Block Header > Search
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search Key Block Header','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('keyblkhdr_sel','J2EF',' ','wicket/core/keyblkhdr',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('keyblkhdr_sel',p_usrgrp,'Y','N',8);
	let t_maxtag = t_maxtag + 1;
	insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('keyblkhdr','keyblkhdr_sel',t_maxtag,2,p_usrgrp,'J2EF');

    --Permissions
    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Key Block Header Main','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('keyblkhdr_m','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('keyblkhdr_m',p_usrgrp,'Y','N',8);                                                                                                                       
 
end procedure;

execute procedure keyblkhdr_menu("cortex");

drop procedure keyblkhdr_menu;
