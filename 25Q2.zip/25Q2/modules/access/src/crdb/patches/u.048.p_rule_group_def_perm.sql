create procedure rule_group_def_perm(p_usrgrp like usrgrp.usrgrp)
    
define t_maxtag	   int;
define i           int;


	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag
		from descr;
		
    let t_maxtag = t_maxtag + 1;
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Search', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_rulgdsch', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_rulgdsch', p_usrgrp, 'Y', 'N', '15');
    
    let t_maxtag = t_maxtag + 1;
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Add', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_rulgdgdd', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_rulgdgdd', p_usrgrp, 'Y', 'N', '15');

end procedure;

execute procedure rule_group_def_perm("cortex");

drop procedure rule_group_def_perm
