create procedure issuerdirectives(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    like acsitem.descrtag;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;    

    -- Issuerdirectives webservice
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Issuerdirectives Webservice','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_issuerdir','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_issuerdir',p_usrgrp,'Y','N',15);
    
end procedure;

execute procedure issuerdirectives('cortex');

drop procedure issuerdirectives;
