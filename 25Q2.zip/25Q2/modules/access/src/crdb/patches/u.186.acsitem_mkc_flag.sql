-- CCS Screens that will implement MKC functionality
UPDATE ACSITEM SET MKC_FLAG = '1' WHERE ACSITEM = 'ccs_accdeta';
