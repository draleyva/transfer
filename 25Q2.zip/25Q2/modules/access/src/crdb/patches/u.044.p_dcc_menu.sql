create procedure dcc_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag	   int;
define t_maxorder  int;
define t_menuorder int;
define i           int;


	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag
		from descr;
    
    
    let t_menuorder = 0;
    
           
    select max(morder) into t_menuorder from menu where mitem ='co_' and usrgrp=p_usrgrp;
    
    let t_menuorder = t_menuorder + 1;
    

    let t_maxtag = t_maxtag + 1;
    --DCC
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Dynamic Currency Conversion', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_dccdf', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_dccdf', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_','co_dccdf',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    let t_maxtag = t_maxtag + 1;
    --Add DCC 
       
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Add', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_dcc_cudd', 'J2EF', ' ', 'codcccurrdetailon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_dcc_cudd', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_dccdf','co_dcc_cudd',t_maxtag,2,p_usrgrp,'J2EF');

    let t_maxtag = t_maxtag + 1;
    --Search DCC
        
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Search', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_dcccusch', 'J2EF', ' ', 'codcccurrsearchon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_dcccusch', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_dccdf','co_dcccusch',t_maxtag,1,p_usrgrp,'J2EF');


end procedure;

execute procedure dcc_menu("cortex");

drop procedure dcc_menu;
