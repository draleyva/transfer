:
#
# @(#) - u.001.cashin.menus.sh - Korn shell script to
#       
#        install cashin menu system

TMPFILE=/tmp/$$.access.cashin.menu.infx.sql

acs_gen.infx data.001.CASHIN_ACSITEM data.001.CASHIN_DESCR data.001.CASHIN_MENU > $TMPFILE

dbaccess $DBNAME $TMPFILE

# if dbaccess exited ok, delete tmpfile
if [ $? -eq 0 ]; then
	echo "Install completed ok"
	rm $TMPFILE
else
	echo "Install of sql file [$TMPFILE] failed"
	echo "see file for details"
fi


