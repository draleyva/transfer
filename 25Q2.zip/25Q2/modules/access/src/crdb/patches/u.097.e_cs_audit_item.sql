

select 'creating indexes for audit_item' from systables where tabid = 1;

create unique index pk_audit_item on
	audit_item (id);

alter table audit_item add constraint
	primary key (id) constraint pk_audit_item;

	
