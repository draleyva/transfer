create procedure des_device_binding_perm(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;
	
	--des_bind_dev
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Device Bind','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_bind_dev','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_bind_dev',p_usrgrp,'Y','N',8);
	
	--des_unbind_dev
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Device Unbind','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_unbind_dev','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_unbind_dev',p_usrgrp,'Y','N',8);

    --des_tkn_device
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Token Devices Tab','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_tkn_device','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_tkn_device',p_usrgrp,'Y','N',8);

end procedure;

execute procedure des_device_binding_perm('cortex');
drop procedure des_device_binding_perm;
