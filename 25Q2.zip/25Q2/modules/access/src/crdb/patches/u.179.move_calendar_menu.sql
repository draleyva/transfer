create procedure move_calendar_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;
define t_count     int;
define t_tag       int;
define t_mitem     like menu.mitem;
define t_morder    int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;
    let t_menuorder = 0;
    select max(morder) into t_menuorder from menu where mitem ='co_' and usrgrp=p_usrgrp;

    -- Calendar Maintenance (Type)
    select count(*) into t_count from acsitem where acsitem='co_clndrt';
    if (t_count > 0) then
        -- Core 'co_clndrt' screen already exists
        update acsitem set command='\ ', acstype='J2EM' where acsitem='co_clndrt';
        select descrtag into t_tag from acsitem where acsitem='co_clndrt';
        update descr set descr='Calendar Maintenance' where descrtag=t_tag and lang='EN';
        update menu set descrtag=t_tag where acsitem='co_clndrt';
    else
        -- Core 'co_clndrt' screen non-existent
        let t_maxtag = t_maxtag + 1;
        insert into descr (descrtag, descr, lang) values (t_maxtag, 'Calendar Maintenance', 'EN');
        insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_clndrt', 'J2EM', ' ', '\ ', '\ ', t_maxtag);
        insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_clndrt', p_usrgrp, 'Y', 'N', '15');
        let t_menuorder = t_menuorder + 1;
        insert into menu (mitem, acsitem, descrtag, morder, usrgrp, acstype) values('co_', 'co_clndrt', t_maxtag, t_menuorder, p_usrgrp, 'J2EM');
    end if;
    select count(*) into t_count from acsitem where acsitem='ccs_clndrt';
    if (t_count > 0) then
        -- CCS 'ccs_clndrt' screen already exists
        update usrperm set acsitem='co_clndrt' where acsitem='ccs_clndrt';
        update grpperm set acsitem='co_clndrt' where acsitem='ccs_clndrt' and usrgrp!=p_usrgrp;
        delete from grpperm where acsitem='ccs_clndrt' and usrgrp=p_usrgrp;
        select descrtag into t_tag from acsitem where acsitem='co_clndrt';
        update menu set acsitem='co_clndrt', descrtag=t_tag where acsitem='ccs_clndrt' and usrgrp!=p_usrgrp;
        select mitem, morder into t_mitem, t_morder from menu where acsitem='ccs_clndrt' and usrgrp=p_usrgrp;
        delete from menu where acsitem='ccs_clndrt' and usrgrp=p_usrgrp;
        update menu set mitem=t_mitem, morder=t_morder where acsitem='co_clndrt' and usrgrp=p_usrgrp;
        update menu set mitem='co_clndrt' where mitem='ccs_clndrt';
        select descrtag into t_tag from acsitem where acsitem='ccs_clndrt';
        delete from acsitem where acsitem='ccs_clndrt';
        delete from descr where descrtag=t_tag;
    end if;

    -- Calendar Maintenance (Type) --> Add
    select count(*) into t_count from acsitem where acsitem='co_clndrta';
    if (t_count > 0) then
        -- Core 'co_clndrta' screen already exists
        update acsitem set command='clndrtypedetailon.do', acstype='J2EF' where acsitem='co_clndrta';
        select descrtag into t_tag from acsitem where acsitem='co_clndrta';
        update descr set descr='Add' where descrtag=t_tag and lang='EN';
        update menu set descrtag=t_tag where acsitem='co_clndrta';
    else
        -- Core 'co_clndrta' screen non-existent
        let t_maxtag = t_maxtag + 1;
        insert into descr (descrtag, descr, lang) values (t_maxtag, 'Add', 'EN');
        insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_clndrta', 'J2EF', ' ', 'clndrtypedetailon.do', '\ ', t_maxtag);
        insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_clndrta', p_usrgrp, 'Y', 'N', '15');
        insert into menu (mitem, acsitem, descrtag, morder, usrgrp, acstype) values('co_clndrt', 'co_clndrta', t_maxtag, 1, p_usrgrp, 'J2EF');
    end if;
    select count(*) into t_count from acsitem where acsitem='ccs_clndrta';
    if (t_count > 0) then
        -- CCS 'ccs_clndrta' screen already exists
        update usrperm set acsitem='co_clndrta' where acsitem='ccs_clndrta';
        update grpperm set acsitem='co_clndrta' where acsitem='ccs_clndrta' and usrgrp!=p_usrgrp;
        delete from grpperm where acsitem='ccs_clndrta' and usrgrp=p_usrgrp;
        select descrtag into t_tag from acsitem where acsitem='co_clndrta';
        update menu set acsitem='co_clndrta', descrtag=t_tag where acsitem='ccs_clndrta' and usrgrp!=p_usrgrp;
        delete from menu where acsitem='ccs_clndrta' and usrgrp=p_usrgrp;
        select descrtag into t_tag from acsitem where acsitem='ccs_clndrta';
        delete from acsitem where acsitem='ccs_clndrta';
        delete from descr where descrtag=t_tag;
    end if;

    -- Calendar Maintenance (Type) --> Search 
    select count(*) into t_count from acsitem where acsitem='co_clndrts';
    if (t_count > 0) then
        -- Core 'co_clndrts' screen already exists
        update acsitem set command='clndrtypesearchon.do', acstype='J2EF' where acsitem='co_clndrts';
        select descrtag into t_tag from acsitem where acsitem='co_clndrts';
        update descr set descr='Search' where descrtag=t_tag and lang='EN';
        update menu set descrtag=t_tag where acsitem='co_clndrts';
    else
        -- Core 'co_clndrts' screen non-existent
        let t_maxtag = t_maxtag + 1;
        insert into descr (descrtag, descr, lang) values (t_maxtag, 'Search', 'EN');
        insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_clndrts', 'J2EF', ' ', 'clndrtypesearchon.do', '\ ', t_maxtag);
        insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_clndrts', p_usrgrp, 'Y', 'N', '15');
        insert into menu (mitem, acsitem, descrtag, morder, usrgrp, acstype) values('co_clndrt', 'co_clndrts', t_maxtag, 2, p_usrgrp, 'J2EF');
    end if;
    select count(*) into t_count from acsitem where acsitem='ccs_clndrts';
    if (t_count > 0) then
        -- CCS 'ccs_clndrts' screen already exists
        update usrperm set acsitem='co_clndrts' where acsitem='ccs_clndrts';
        update grpperm set acsitem='co_clndrts' where acsitem='ccs_clndrts' and usrgrp!=p_usrgrp;
        delete from grpperm where acsitem='ccs_clndrts' and usrgrp=p_usrgrp;
        select descrtag into t_tag from acsitem where acsitem='co_clndrts';
        update menu set acsitem='co_clndrts', descrtag=t_tag where acsitem='ccs_clndrts' and usrgrp!=p_usrgrp;
        delete from menu where acsitem='ccs_clndrts' and usrgrp=p_usrgrp;
        select descrtag into t_tag from acsitem where acsitem='ccs_clndrts';
        delete from acsitem where acsitem='ccs_clndrts';
        delete from descr where descrtag=t_tag;
    end if;

    -- Calendar Date Maintenance
    select count(*) into t_count from acsitem where acsitem='co_clndrd';
    if (t_count > 0) then
        -- Core 'co_clndrd' screen already exists
        update acsitem set command='\ ', acstype='J2EM' where acsitem='co_clndrd';
        select descrtag into t_tag from acsitem where acsitem='co_clndrd';
        update descr set descr='Calendar Date Maintenance' where descrtag=t_tag and lang='EN';
        update menu set descrtag=t_tag where acsitem='co_clndrd';
    else
        -- Core 'co_clndrd' screen non-existent
        let t_maxtag = t_maxtag + 1;
        insert into descr (descrtag, descr, lang) values (t_maxtag, 'Calendar Date Maintenance', 'EN');
        insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_clndrd', 'J2EM', ' ', '\ ', '\ ', t_maxtag);
        insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_clndrd', p_usrgrp, 'Y', 'N', '15');
        let t_menuorder = t_menuorder + 1;
        insert into menu (mitem, acsitem, descrtag, morder, usrgrp, acstype) values('co_', 'co_clndrd', t_maxtag, t_menuorder, p_usrgrp, 'J2EM');
    end if;
    select count(*) into t_count from acsitem where acsitem='ccs_clndrd';
    if (t_count > 0) then
        -- CCS 'ccs_clndrd' screen already exists
        update usrperm set acsitem='co_clndrd' where acsitem='ccs_clndrd';
        update grpperm set acsitem='co_clndrd' where acsitem='ccs_clndrd' and usrgrp!=p_usrgrp;
        delete from grpperm where acsitem='ccs_clndrd' and usrgrp=p_usrgrp;
        select descrtag into t_tag from acsitem where acsitem='co_clndrd';
        update menu set acsitem='co_clndrd', descrtag=t_tag where acsitem='ccs_clndrd' and usrgrp!=p_usrgrp;
        select mitem, morder into t_mitem, t_morder from menu where acsitem='ccs_clndrd' and usrgrp=p_usrgrp;
        delete from menu where acsitem='ccs_clndrd' and usrgrp=p_usrgrp;
        update menu set mitem=t_mitem, morder=t_morder where acsitem='co_clndrd' and usrgrp=p_usrgrp;
        update menu set mitem='co_clndrd' where mitem='ccs_clndrd';
        select descrtag into t_tag from acsitem where acsitem='ccs_clndrd';
        delete from acsitem where acsitem='ccs_clndrd';
        delete from descr where descrtag=t_tag;
    end if;

    -- Calendar Date Maintenance --> Add
    select count(*) into t_count from acsitem where acsitem='co_clndrda';
    if (t_count > 0) then
        -- Core 'co_clndrda' screen already exists
        update acsitem set command='clndrdatedetailon.do', acstype='J2EF' where acsitem='co_clndrda';
        select descrtag into t_tag from acsitem where acsitem='co_clndrda';
        update descr set descr='Add' where descrtag=t_tag and lang='EN';
        update menu set descrtag=t_tag where acsitem='co_clndrda';
    else
        -- Core 'co_clndrda' screen non-existent
        let t_maxtag = t_maxtag + 1;
        insert into descr (descrtag, descr, lang) values (t_maxtag, 'Add', 'EN');
        insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_clndrda', 'J2EF', ' ', 'clndrdatedetailon.do', '\ ', t_maxtag);
        insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_clndrda', p_usrgrp, 'Y', 'N', '15');
        insert into menu (mitem, acsitem, descrtag, morder, usrgrp, acstype) values('co_clndrd', 'co_clndrda', t_maxtag, 1, p_usrgrp, 'J2EF');
    end if;
    select count(*) into t_count from acsitem where acsitem='ccs_clndrda';
    if (t_count > 0) then
        -- CCS 'ccs_clndrda' screen already exists
        update usrperm set acsitem='co_clndrda' where acsitem='ccs_clndrda';
        update grpperm set acsitem='co_clndrda' where acsitem='ccs_clndrda' and usrgrp!=p_usrgrp;
        delete from grpperm where acsitem='ccs_clndrda' and usrgrp=p_usrgrp;
        select descrtag into t_tag from acsitem where acsitem='co_clndrda';
        update menu set acsitem='co_clndrda', descrtag=t_tag where acsitem='ccs_clndrda' and usrgrp!=p_usrgrp;
        delete from menu where acsitem='ccs_clndrda' and usrgrp=p_usrgrp;
        select descrtag into t_tag from acsitem where acsitem='ccs_clndrda';
        delete from acsitem where acsitem='ccs_clndrda';
        delete from descr where descrtag=t_tag;
    end if;

    -- Calendar Date Maintenance --> Search 
    select count(*) into t_count from acsitem where acsitem='co_clndrds';
    if (t_count > 0) then
        -- Core 'co_clndrds' screen already exists
        update acsitem set command='clndrdatesearchon.do', acstype='J2EF' where acsitem='co_clndrds';
        select descrtag into t_tag from acsitem where acsitem='co_clndrds';
        update descr set descr='Search' where descrtag=t_tag and lang='EN';
        update menu set descrtag=t_tag where acsitem='co_clndrds';
    else
        -- Core 'co_clndrds' screen non-existent
        let t_maxtag = t_maxtag + 1;
        insert into descr (descrtag, descr, lang) values (t_maxtag, 'Search', 'EN');
        insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_clndrds', 'J2EF', ' ', 'clndrdatesearchon.do', '\ ', t_maxtag);
        insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_clndrds', p_usrgrp, 'Y', 'N', '15');
        insert into menu (mitem, acsitem, descrtag, morder, usrgrp, acstype) values('co_clndrd', 'co_clndrds', t_maxtag, 2, p_usrgrp, 'J2EF');
    end if;
    select count(*) into t_count from acsitem where acsitem='ccs_clndrds';
    if (t_count > 0) then
        -- CCS 'ccs_clndrds' screen already exists
        update usrperm set acsitem='co_clndrds' where acsitem='ccs_clndrds';
        update grpperm set acsitem='co_clndrds' where acsitem='ccs_clndrds' and usrgrp!=p_usrgrp;
        delete from grpperm where acsitem='ccs_clndrds' and usrgrp=p_usrgrp;
        select descrtag into t_tag from acsitem where acsitem='co_clndrds';
        update menu set acsitem='co_clndrds', descrtag=t_tag where acsitem='ccs_clndrds' and usrgrp!=p_usrgrp;
        delete from menu where acsitem='ccs_clndrds' and usrgrp=p_usrgrp;
        select descrtag into t_tag from acsitem where acsitem='ccs_clndrds';
        delete from acsitem where acsitem='ccs_clndrds';
        delete from descr where descrtag=t_tag;
    end if;

end procedure;

execute procedure move_calendar_menu('cortex');

drop procedure move_calendar_menu;
