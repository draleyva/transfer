create procedure add_threshold_acsitem(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    like acsitem.descrtag;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;    

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Edit Commission Threshold And Charge','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('fc_c_thach_e','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('fc_c_thach_e',p_usrgrp,'Y','N',15);
    
    select max(descrtag) into t_maxtag from descr;    

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Create Fee Threshold And Charge','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('fc_f_thach_c','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('fc_f_thach_c',p_usrgrp,'Y','N',15);
    
end procedure;

execute procedure add_threshold_acsitem('cortex');

drop procedure add_threshold_acsitem;
