create procedure numdescr_data(p_lang like numdescr.lang)

    insert into numdescr (verno_ctx, lang, descrtype, id, descr) 
    values(0, p_lang, 'fb', '1',  'ICC -> MSR disabled, ICC -> Key entry disabled, MSR -> Key entry disabled');
    insert into numdescr (verno_ctx, lang, descrtype, id, descr) 
    values(0, p_lang, 'fb', '2',  'ICC -> MSR enabled, ICC -> Key entry disabled, MSR -> Key entry disabled');
    insert into numdescr (verno_ctx, lang, descrtype, id, descr) 
    values(0, p_lang, 'fb', '3',  'ICC -> MSR disabled, ICC -> Key entry enabled, MSR -> Key entry disabled');
    insert into numdescr (verno_ctx, lang, descrtype, id, descr) 
    values(0, p_lang, 'fb', '4',  'ICC -> MSR disabled, ICC -> Key entry disabled, MSR -> Key entry enabled');
    insert into numdescr (verno_ctx, lang, descrtype, id, descr) 
    values(0, p_lang, 'fb', '5',  'ICC -> MSR enabled, ICC -> Key entry enabled, MSR -> Key entry disabled');
    insert into numdescr (verno_ctx, lang, descrtype, id, descr) 
    values(0, p_lang, 'fb', '6',  'ICC -> MSR disabled, ICC -> Key entry enabled, MSR -> Key entry enabled');
    insert into numdescr (verno_ctx, lang, descrtype, id, descr) 
    values(0, p_lang, 'fb', '7',  'ICC -> MSR enabled, ICC -> Key entry disabled, MSR -> Key entry enabled');
    insert into numdescr (verno_ctx, lang, descrtype, id, descr) 
    values(0, p_lang, 'fb', '8',  'ICC -> MSR enabled, ICC -> Key entry enabled, MSR -> Key entry enabled');

end procedure;

execute procedure numdescr_data("EN");
execute procedure numdescr_data("GB");

drop procedure numdescr_data;
