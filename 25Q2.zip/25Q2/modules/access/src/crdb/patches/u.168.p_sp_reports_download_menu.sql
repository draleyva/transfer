-- add menu to report download screen
create procedure reportdownload_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag		int;
define t_maxorder  int;
define t_menuorder int;
define i int;


	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag from descr;
    
    
    let t_menuorder = 0;
    select max(morder) into t_menuorder from menu where mitem ='co_reports' and usrgrp=p_usrgrp;
    let t_menuorder = t_menuorder + 1;

    let t_maxtag = t_maxtag + 1;
    -- Report download screen
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Download Generated Reports', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('rp_repdownl', 'J2EF', ' ', 'rpreportdownloadon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('rp_repdownl', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values ('co_reports','rp_repdownl',t_maxtag,t_menuorder,p_usrgrp,'J2EF');


end procedure;

execute procedure reportdownload_menu("cortex");

drop procedure reportdownload_menu;
