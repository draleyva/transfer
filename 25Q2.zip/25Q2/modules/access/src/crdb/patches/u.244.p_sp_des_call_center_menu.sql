create procedure clear_des_callcenter_menu( )

delete from descr where descrtag in (select descrtag from menu where acsitem in ('callcenter','callcent_cr_ed','callcent_sel','callcenter_m'));
delete from descr where descrtag in (select descrtag from acsitem where acsitem in ('callcenter','callcent_cr_ed','callcent_sel','callcenter_m'));

delete from menu where mitem in ('callcenter','callcent_cr_ed','callcent_sel','callcenter_m');
delete from menu where acsitem in ('callcenter','callcent_cr_ed','callcent_sel','callcenter_m');
delete from GRPPERM where acsitem in ('callcenter','callcent_cr_ed','callcent_sel','callcenter_m');
delete from acsitem where acsitem in ('callcenter','callcent_cr_ed','callcent_sel','callcenter_m');

end procedure;

create procedure des_callcenter_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'des_' and usrgrp = p_usrgrp;
    let t_menuorder = t_menuorder + 1;
    
    -- DES > Call Center
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Call Center','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_callcenter','J2EM',' ',' ',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('des_','des_callcenter',t_maxtag,t_menuorder,p_usrgrp,'J2EM');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_callcenter',p_usrgrp,'Y','N',8);
    
    -- DES > Call Center > Add
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_callc_cr_ed','J2EF',' ','wicket/des/callcenter?action=create',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_callc_cr_ed',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('des_callcenter','des_callc_cr_ed',t_maxtag,1,p_usrgrp,'J2EF');
	    
    -- DES > Call Center > Search
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_callc_sel','J2EF',' ','wicket/des/callcenter',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_callc_sel',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('des_callcenter','des_callc_sel',t_maxtag,2,p_usrgrp,'J2EF');

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_callcent_m','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_callcent_m',p_usrgrp,'Y','N',8);

end procedure;

SET CONSTRAINTS FK_GRPPERM_AI_ACSITEM DISABLED;
SET CONSTRAINTS FK_MENU_AI_ACSITEM DISABLED;
SET CONSTRAINTS FK_MENU_MI_ACSITEM DISABLED;

execute procedure clear_des_callcenter_menu();
drop procedure clear_des_callcenter_menu;

SET CONSTRAINTS FK_GRPPERM_AI_ACSITEM ENABLED;
SET CONSTRAINTS FK_MENU_AI_ACSITEM ENABLED;
SET CONSTRAINTS FK_MENU_MI_ACSITEM ENABLED;

execute procedure des_callcenter_menu('cortex');
drop procedure des_callcenter_menu;
