create procedure pandecryption_button(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag from descr;    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Access to Decrypt Pan button','EN');

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values ('ia_decpan','J2EF',' ',' ',' ',t_maxtag);

    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values ('ia_decpan',p_usrgrp,'Y','N',15);

end procedure;

execute procedure pandecryption_button('cortex');

drop procedure pandecryption_button;
