
alter table acsitem modify
( 
	id		serial		not null
); 
