create procedure iss_r_ircc_m(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    like acsitem.descrtag;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select descrtag into t_maxtag from acsitem where acsitem ='iss_r_irc_m';
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_r_ircc_m','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_r_ircc_m',p_usrgrp,'Y','N',15);
	
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_r_ccat_s','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_r_ccat_s',p_usrgrp,'Y','N',15);

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_r_cc_ce','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_r_cc_ce',p_usrgrp,'Y','N',15);	
    
end procedure;

execute procedure iss_r_ircc_m('cortex');

drop procedure iss_r_ircc_m;
