create procedure custseg_cat_perm(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('custseg_ct_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('custseg_ct_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('custseg_ct_c','J2EF',' ',' ',' ',t_maxtag);
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('custseg_ct_e','J2EF',' ',' ',' ',t_maxtag);
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('custseg_ct_ss','J2EF',' ',' ',' ',t_maxtag);


    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('custseg_ct_m',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('custseg_ct_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('custseg_ct_c',p_usrgrp,'Y','N',15);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('custseg_ct_e',p_usrgrp,'Y','N',15);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('custseg_ct_ss',p_usrgrp,'Y','N',15);


end procedure;

execute procedure custseg_cat_perm('cortex');

drop procedure custseg_cat_perm;
