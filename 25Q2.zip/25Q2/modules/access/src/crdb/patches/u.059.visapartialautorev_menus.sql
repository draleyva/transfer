create procedure visapartialautorev_menus(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;

    -- VISA > Add VISA Partial Automatic Reversal Transaction
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('vi_paurevdet','J2EF',' ','visapartialautorevdet.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('vi_paurevdet',p_usrgrp,'Y','N',15);

    -- VISA > Search for VISA Partial Automatic Reversal Transaction
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('vi_paurevsrc','J2EF',' ','ViVisaPartialAutoReversalDetailSearch.jsp',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('vi_paurevsrc',p_usrgrp,'Y','N',15);

end procedure;

execute procedure visapartialautorev_menus("cortex");

drop procedure visapartialautorev_menus;
