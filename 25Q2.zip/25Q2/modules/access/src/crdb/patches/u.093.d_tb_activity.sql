
select 'creating table ACTIVITY' from systables where tabid = 1;

create table ACTIVITY 
(
	verno_ctx	integer	  default 1	 not null,
        id int not null, 
	user_name varchar(16, 0) not null, 
	activitydatetime DATETIME YEAR TO SECOND not null, 
	activity_code varchar(255, 0) not null
)
lock mode row;

create sequence ACTIVITY_SEQUENCE start with 1;
