create procedure fallbackcnt_button(p_usrgrp like usrgrp.usrgrp)

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_crddlsfbc','J2EF',' ',' ',' ',0);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_crddlsfbc','cortex','Y','N',15);

end procedure;

execute procedure fallbackcnt_button("cortex");

drop procedure fallbackcnt_button;
