create procedure fill_entity_type_keys()

	update ACSITEM set AUDIT_SRC_CODE='cxo' where ACSITEM in ('ia_recresume', 'ia_reccancel', 'ia_crdsrctx');
	
end procedure;

execute procedure fill_entity_type_keys();

drop procedure fill_entity_type_keys;	
