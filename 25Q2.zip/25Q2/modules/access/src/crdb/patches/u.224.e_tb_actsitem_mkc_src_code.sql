-- Add  mkc_src_code to acsitem

select 'Add mkc_src_code in acsitem table...'  from systables where tabid = 1;

alter table acsitem add (	
	mkc_src_code varchar2(32)
);

update acsitem set mkc_src_code = 'CTX' where acsitem not like 'ccs%' and acsitem not like 'cxbr%'
;
update acsitem set mkc_src_code = 'CCS' where acsitem like 'ccs%'
;
update acsitem set mkc_src_code = 'BRANCH' where acsitem like 'cxbr%'
;

commit work;
