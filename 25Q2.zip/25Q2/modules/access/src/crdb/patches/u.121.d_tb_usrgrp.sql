
alter table usrgrp modify
( 
	id		serial		not null
); 
