
alter table ACSITEM add (MKC_FLAG char(1) default '0' not null);
