create procedure remove_currate_menu()

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    delete from usrperm where acsitem in ('co_curratdd', 'co_curratsch', 'rp_currate','co_currates');
    delete from grpperm where acsitem in ('co_curratdd', 'co_curratsch', 'rp_currate','co_currates');
    delete from menu where acsitem in ('co_curratdd', 'co_curratsch', 'rp_currate','co_currates');
    delete from acsitem where acsitem in ('co_curratdd', 'co_curratsch', 'rp_currate','co_currates');

end procedure;

execute procedure remove_currate_menu();

drop procedure remove_currate_menu;
