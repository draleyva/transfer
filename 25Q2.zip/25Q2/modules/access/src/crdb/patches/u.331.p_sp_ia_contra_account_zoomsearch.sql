create procedure contra_account_zoom_search(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
	select max(descrtag) into t_maxtag from descr;
		
	let t_maxtag = t_maxtag + 1;

	insert into descr (descrtag, descr, lang) values (t_maxtag, 'Contra Account Search', 'EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('zoomcontracc','J2EF',' ','contraaccountsearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('zoomcontracc',p_usrgrp,'Y','N',8);
	
end procedure;

execute procedure contra_account_zoom_search("cortex");

drop procedure contra_account_zoom_search;

