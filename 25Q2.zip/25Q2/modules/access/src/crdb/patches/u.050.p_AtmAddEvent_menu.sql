create procedure report_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag	   int;
define t_menuorder int;

ON EXCEPTION
	END EXCEPTION WITH RESUME;

select max(descrtag) into t_maxtag from descr;
 
let t_menuorder = 0;
     
            
select max(morder) into t_menuorder from menu where mitem ='aa_conf' and usrgrp=p_usrgrp;
     
let t_menuorder = t_menuorder + 1;
    
let t_maxtag = t_maxtag + 1;
    
--Add ATM Monitoring Analytical Report Menu
        
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'ATM Device Event', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('aa_evdef', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('aa_evdef', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('aa_conf','aa_evdef',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

let t_maxtag = t_maxtag + 1;

--Add ATM Monitoring Analytical Report Menu
        
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Add ', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('aa_dvcevdd', 'J2EF', ' ', 'aadvcevdetailon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('aa_dvcevdd', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('aa_evdef','aa_dvcevdd',t_maxtag,1,p_usrgrp,'J2EF');
    
end procedure;

execute procedure report_menu('cortex');


drop procedure report_menu;