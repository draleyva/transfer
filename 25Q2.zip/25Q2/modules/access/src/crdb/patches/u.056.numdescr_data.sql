create procedure numdescr_data(p_lang like numdescr.lang)

    insert into numdescr (verno_ctx, lang, descrtype, id, descr) 
    values(0, p_lang, 'tx', '96',  'VERIFICATION');

end procedure;

execute procedure numdescr_data("EN");
execute procedure numdescr_data("GB");

drop procedure numdescr_data;
