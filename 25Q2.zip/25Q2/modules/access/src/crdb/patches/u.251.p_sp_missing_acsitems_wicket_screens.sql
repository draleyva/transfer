create procedure missing_panel_acsitem(p_usrgrp like usrgrp.usrgrp) 

define t_maxtag    int;
define t_menuorder int;

         ON EXCEPTION
         END EXCEPTION WITH RESUME;
		 
    select max(descrtag) into t_maxtag from descr;    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Atm Barcode','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('atm_barcode_m','J2EF',' ',' ',' ',t_maxtag);
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Atm Barcode reference','EN');	
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('atm_barcd_m_ref','J2EF',' ',' ',' ',t_maxtag);
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Rule Dim value','EN');	
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_dim_value','J2EF',' ',' ',' ',t_maxtag);
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Describe Scope Dim Val','EN');	
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('dec_sc_d_v','J2EF',' ',' ',' ',t_maxtag);
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Select Account','EN');	
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('sel_account','J2EF',' ',' ',' ',t_maxtag);
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Bar Code Regular Expression','EN');	
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('brc_rg_ex_ma','J2EF',' ',' ',' ',t_maxtag);
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Describe Bar Code Regular Expression','EN');	
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('brc_rg_ex_md','J2EF',' ',' ',' ',t_maxtag);
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Bar Code info','EN');	
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('brc_inf_cont','J2EF',' ',' ',' ',t_maxtag);
	
    
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('atm_barcode_m',p_usrgrp,'Y','N',8);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('atm_barcd_m_ref',p_usrgrp,'Y','N',8);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_dim_value',p_usrgrp,'Y','N',8);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('dec_sc_d_v',p_usrgrp,'Y','N',8);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('sel_account',p_usrgrp,'Y','N',8);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('brc_rg_ex_ma',p_usrgrp,'Y','N',8);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('brc_rg_ex_md',p_usrgrp,'Y','N',8);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('brc_inf_cont',p_usrgrp,'Y','N',8);
	
    
end procedure;

execute procedure missing_panel_acsitem('cortex');

drop procedure missing_panel_acsitem;

