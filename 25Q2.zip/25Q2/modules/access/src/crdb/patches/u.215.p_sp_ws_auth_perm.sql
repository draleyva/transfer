create procedure ws_auth_perm(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    like acsitem.descrtag;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;    

    --CRDBASE
    -- Issuer Directives webservice
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Issuer Directives Webservice','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_issuerdirect','J2EF',' ',' ',' ',t_maxtag);
		
	-- Remove permissions for acsitems to be migrated below
	delete from grpperm where acsitem = 'ws_getcustcarda';
	delete from grpperm where acsitem = 'ws_setriskoverr';
	delete from grpperm where acsitem = 'ws_updatesmssta';
	delete from usrperm where acsitem = 'ws_getcustcarda';
	delete from usrperm where acsitem = 'ws_setriskoverr';
	delete from usrperm where acsitem = 'ws_updatesmssta';	
	
	-- Migrate existing group permissions under new acsitems
	update grpperm set acsitem = 'ws_issuerdirect' where acsitem = 'ws_issuerdir' and not exists (select * from grpperm where acsitem = 'ws_directive');
	update grpperm set acsitem = 'ws_issuerdirect' where acsitem = 'ws_directive' and not exists (select * from grpperm where acsitem = 'ws_issuerdir');
	update grpperm set acsitem = 'ws_setriskoverr' where acsitem = 'ws_setriskovr';
	update grpperm set acsitem = 'ws_updatesmssta' where acsitem = 'ws_updsmsstat';
	update grpperm set acsitem = 'ws_getcustcarda' where acsitem = 'ws_cardaccdet';

	-- Migrate existing user permissions under new acsitems
	update usrperm set acsitem = 'ws_issuerdirect' where acsitem = 'ws_issuerdir' and not exists (select * from usrperm where acsitem = 'ws_directive');
	update grpperm set acsitem = 'ws_issuerdirect' where acsitem = 'ws_directive' and not exists (select * from usrperm where acsitem = 'ws_issuerdir');
	update usrperm set acsitem = 'ws_setriskoverr' where acsitem = 'ws_setriskovr';
	update usrperm set acsitem = 'ws_updatesmssta' where acsitem = 'ws_updsmsstat';
	update usrperm set acsitem = 'ws_getcustcarda' where acsitem = 'ws_cardaccdet';
	
	-- Remove old permissions and acsitems
	delete from grpperm where acsitem in ('ws_directive', 'ws_issuerdir');
	delete from usrperm where acsitem in ('ws_directive', 'ws_issuerdir');
	delete from acsitem where acsitem in ('ws_directive', 'ws_issuerdir', 'ws_setriskovr', 'ws_updsmsstat', 'ws_cardaccdet');
    
end procedure;

execute procedure ws_auth_perm('cortex');

drop procedure ws_auth_perm;
