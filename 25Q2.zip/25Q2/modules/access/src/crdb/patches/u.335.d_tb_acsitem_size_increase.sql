ALTER TABLE acsitem MODIFY (acsitem	varchar(64));

ALTER TABLE statchgperm MODIFY (acsitem	varchar(64));

ALTER TABLE usrperm MODIFY (acsitem	varchar(64));

ALTER TABLE grpperm MODIFY (acsitem	varchar(64));

ALTER TABLE screenfield MODIFY (acsitem	varchar(64));

ALTER TABLE menu MODIFY (acsitem varchar(64));

ALTER TABLE menu MODIFY (mitem varchar(64));