-- BEFORE THE THIS PATCH IS APPLIED, THE t_mkc_url value needs to be set to the complete URL of the mkc application

create procedure mkc_url_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    like acsitem.descrtag;
define t_menuorder    like acsitem.descrtag;
define t_mkc_url    like acsitem.command;


	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    let t_mkc_url = 'http://localhost:8080/mkc-web';

    select max(descrtag) into t_maxtag from descr;    

    let t_maxtag = t_maxtag + 1;

    insert into descr(descrtag,descr,lang) values(t_maxtag,'Applications','EN');

    let t_menuorder = 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = p_usrgrp and usrgrp = p_usrgrp;
    let t_menuorder =  t_menuorder + 1;
	
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('apps_','J2EM',' ',' ',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values(p_usrgrp,'apps_',t_maxtag,t_menuorder,p_usrgrp,'URL');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('apps_',p_usrgrp,'Y','N',15);

	let t_menuorder = 0;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'MKC','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mkc','URL',' ',t_mkc_url,' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('apps_','mkc',t_maxtag,t_menuorder,p_usrgrp,'URL');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mkc',p_usrgrp,'Y','N',15);

end procedure;

execute procedure mkc_url_menu('cortex');

drop procedure mkc_url_menu;

