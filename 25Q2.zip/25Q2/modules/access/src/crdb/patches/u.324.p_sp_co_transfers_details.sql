create procedure co_transfers_details(p_usrgrp like usrgrp.usrgrp)

define t_maxtag int;

    ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;  
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values (t_maxtag,'TLog Query Transfers','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag,mkc_flag) values ('co_transdet','J2EF',' ','cotransfersdetailon.do',' ',t_maxtag,0);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values ('co_transdet',p_usrgrp,'Y','N',15);
end procedure;

execute procedure co_transfers_details('cortex');

drop procedure co_transfers_details;
