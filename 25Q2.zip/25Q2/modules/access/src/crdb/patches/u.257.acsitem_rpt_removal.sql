delete from grpperm where acsitem in('rp_atmstu','rp_atmstc');
delete from usrperm where acsitem in('rp_atmstu','rp_atmstc');
delete from screenfield where acsitem in('rp_atmstu','rp_atmstc');
delete from menu where acsitem in('rp_atmstu','rp_atmstc');
delete from acsitem where acsitem in('rp_atmstu','rp_atmstc');
