create procedure restore_ifm_entries(p_usrgrp like usrgrp.usrgrp)
define t_maxtag    like acsitem.descrtag;
	ON EXCEPTION
	END EXCEPTION WITH RESUME;
    select max(descrtag) into t_maxtag from descr;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_crdagpdd','J2EF',' ','cardacceptorgroupdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_crdagpdd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_cdagpsch','J2EF',' ','cardacceptorgroupsearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_cdagpsch',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_crdagmdd','J2EF',' ','cardacceptorgroupmemberdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_crdagmdd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ctrygpdd','J2EF',' ','countrygroupdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ctrygpdd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ctrygmdd','J2EF',' ','countrygroupmemberdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ctrygmdd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ctygpsch','J2EF',' ','countrygroupsearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ctygpsch',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmcadd','J2EF',' ','ifmifmcalendardetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmcadd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmcasch','J2EF',' ','ifmifmcalendarsearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmcasch',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmcgdd','J2EF',' ','ifmifmcgdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmcgdd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Replace Lost/Stolen Card Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmcgsch','J2EF',' ','iareplacelostorstolencardssearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmcgsch',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmchsch','J2EF',' ','ifmifmcgsearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmchsch',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmchdd','J2EF',' ','ifmifmchecksdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmchdd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmfedd','J2EF',' ','ifmifmfedetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmfedd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmfesch','J2EF',' ','ifmifmfesearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmfesch',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmpadd','J2EF',' ','ifmifmparamdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmpadd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmpasch','J2EF',' ','ifmifmparamsearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmpasch',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmrusch','J2EF',' ','ifmifmrulesearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmrusch',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmrudd','J2EF',' ','ifmifmruledetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmrudd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_rgchksch','J2EF',' ','ifmifmrgchecksearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_rgchksch',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_rgchkdd','J2EF',' ','ifmifmrgcheckdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_rgchkdd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_rgcrdsch','J2EF',' ','ifmifmrgcrdsearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_rgcrdsch',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_rgcrddd','J2EF',' ','ifmifmrgcrddetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_rgcrddd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_rgcprdd','J2EF',' ','ifmifmrgcrdproddetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_rgcprdd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_rgcprsch','J2EF',' ','ifmifmrgcrdprodsearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_rgcprsch',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmrgdd','J2EF',' ','ifmifmrgdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmrgdd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmrgsch','J2EF',' ','ifmifmrgsearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmrgsch',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmrpdd','J2EF',' ','ifmifmrptfilterdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmrpdd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_ifmrpsch','J2EF',' ','ifmifmrptfiltersearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_ifmrpsch',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_rptrldd','J2EF',' ','ifmifmrptrlistdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_rptrldd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_rptrlsch','J2EF',' ','ifmifmrptrlistsearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_rptrlsch',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_mccgrpdd','J2EF',' ','merchantcategorygroupdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_mccgrpdd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_mccgpmdd','J2EF',' ','merchantcategorygroupmemberdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_mccgpmdd',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Paypoint reconciliation failure','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ifm_mccgpsch','J2EF',' ','merchantcategorygroupsearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ifm_mccgpsch',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search for IFM Checks','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_zmchecks','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_zmchecks',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search for IFM Risk Groups','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_zmriskgrp','J2EF',' ','zoomifmriskgrpson.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_zmriskgrp',p_usrgrp,'Y','N',8);
	
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search for IFM Rules','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_zmifmrls','J2EF',' ','zoomifmruleson.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_zmifmrls',p_usrgrp,'Y','N',8);
end procedure;
execute procedure restore_ifm_entries('cortex');
drop procedure restore_ifm_entries;
