create unique index hash_usrinst
	on  usrinst  (usr, inst_id) ;

alter table  usrinst  add constraint 
	unique (usr, inst_id) constraint hash_usrinst ;


CREATE UNIQUE INDEX pk_usrinst
	ON  usrinst  (id) ;

ALTER TABLE  usrinst  ADD CONSTRAINT 
	PRIMARY KEY (id) CONSTRAINT pk_usrinst ;
