drop index unq_screenfield_search;

create unique index unq_screenfield_search on 
	screenfield (usrgrp, acsitem, screenfield, sftype) using btree;