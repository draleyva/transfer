create procedure balupdlog_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag		int;
define i int;


	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag
		from descr;
    

    let t_maxtag = t_maxtag + 1;
    --Search Online Balance Update log 
       
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Online Balance Update Log', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_balupdsch', 'J2EF', ' ', 'iabalupdlogsearchon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_balupdsch', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('au_accupdhis','ia_balupdsch',t_maxtag,2,p_usrgrp,'J2EF');

end procedure;

execute procedure balupdlog_menu("cortex");

drop procedure balupdlog_menu;
