update ACSITEM set AUDIT_SRC_CODE='cxo' where ACSITEM in ('fc_c_tos_m', 'fc_f_tos_m');

