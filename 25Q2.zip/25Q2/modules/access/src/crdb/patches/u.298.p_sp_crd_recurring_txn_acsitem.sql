create procedure crd_recur_txn_acsitem()

	ON EXCEPTION

	END EXCEPTION WITH RESUME;

	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_recresume','J2EF',' ',' ',' ',0);
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_reccancel','J2EF',' ',' ',' ',0);
	
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_recresume','cortex','Y','N',8);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_reccancel','cortex','Y','N',8);
	
end procedure;

execute procedure crd_recur_txn_acsitem();

drop procedure crd_recur_txn_acsitem;	