create procedure clear_des_token_menu( )

delete from descr where descrtag in (select descrtag from menu where acsitem in ('activate_tkn','deactiv_tkn','panassocupdate','resendactivecod','resetmobilepin','suspend_tkn','unsuspend_tkn','tkn_txnhis','tkn_dt_m','tkn_digit','tkn_mgmt','tkn_info','token_search','des_tokensch'));
delete from descr where descrtag in (select descrtag from acsitem where acsitem in ('activate_tkn','deactiv_tkn','panassocupdate','resendactivecod','resetmobilepin','suspend_tkn','unsuspend_tkn','tkn_txnhis','tkn_dt_m','tkn_digit','tkn_mgmt','tkn_info','token_search','des_tokensch'));

delete from menu where mitem in ('activate_tkn','deactiv_tkn','panassocupdate','resendactivecod','resetmobilepin','suspend_tkn','unsuspend_tkn','tkn_txnhis','tkn_dt_m','tkn_digit','tkn_mgmt','tkn_info','token_search','des_tokensch');
delete from menu where acsitem in ('activate_tkn','deactiv_tkn','panassocupdate','resendactivecod','resetmobilepin','suspend_tkn','unsuspend_tkn','tkn_txnhis','tkn_dt_m','tkn_digit','tkn_mgmt','tkn_info','token_search','des_tokensch');
delete from GRPPERM where acsitem in ('activate_tkn','deactiv_tkn','panassocupdate','resendactivecod','resetmobilepin','suspend_tkn','unsuspend_tkn','tkn_txnhis','tkn_dt_m','tkn_digit','tkn_mgmt','tkn_info','token_search','des_tokensch');
delete from acsitem where acsitem in ('activate_tkn','deactiv_tkn','panassocupdate','resendactivecod','resetmobilepin','suspend_tkn','unsuspend_tkn','tkn_txnhis','tkn_dt_m','tkn_digit','tkn_mgmt','tkn_info','token_search','des_tokensch');

end procedure;

create procedure des_token_actions_perm(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;
	
	--des_activat_tkn
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Activate token','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_activat_tkn','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_activat_tkn',p_usrgrp,'Y','N',8);
    
	-- des_deactiv_tkn
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Delete token','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_deactiv_tkn','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_deactiv_tkn',p_usrgrp,'Y','N',8);

	-- des_panassocupd
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Update Token to PAN association','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_panassocupd','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_panassocupd',p_usrgrp,'Y','N',8);

	-- des_resndactcod
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Resend Activation Code','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_resndactcod','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_resndactcod',p_usrgrp,'Y','N',8);

	-- des_resetmobpin
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Reset Mobile PIN','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_resetmobpin','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_resetmobpin',p_usrgrp,'Y','N',8);

	-- des_suspend_tkn
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Suspend token','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_suspend_tkn','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_suspend_tkn',p_usrgrp,'Y','N',8);

	-- des_unsusp_tkn
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Unsuspend token','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_unsusp_tkn','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_unsusp_tkn',p_usrgrp,'Y','N',8);

	-- des_tkn_txnhis (Token Transactions History Panel)
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Token Transation Request Log','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_tkn_txnhis','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_tkn_txnhis',p_usrgrp,'Y','N',8);
	
	-- des_tokensch (Token Search)
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Token Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_tokensch','J2EF',' ','wicket/des/tokensearch',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_tokensch',p_usrgrp,'Y','N',8);
	insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('des_','des_tokensch',t_maxtag,t_menuorder,p_usrgrp,'J2EM');
	
	select nvl(max(morder),0) into t_menuorder from menu where mitem = 'des_' and usrgrp = p_usrgrp;
    let t_menuorder = t_menuorder + 1;

	
	-- des_tkn_search (Token Search)
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Token Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_tkn_search','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_tkn_search',p_usrgrp,'Y','N',8);
	
	--  des_tkn_dt_m (Token Details Main Panel)
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Token Details Main Panel','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values(' des_tkn_dt_m','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values(' des_tkn_dt_m',p_usrgrp,'Y','N',8);
	
	--  des_tkn_digit (Token Digitalization Panel)
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Token Digitalization Panel','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values(' des_tkn_digit','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values(' des_tkn_digit',p_usrgrp,'Y','N',8);
	
	-- des_tkn_mgmt (Token Management Panel)
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Token Management Panel','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_tkn_mgmt','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_tkn_mgmt',p_usrgrp,'Y','N',8);
	
	-- des_tkn_info (Token Information Panel)
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Token Information Panel','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_tkn_info','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_tkn_info',p_usrgrp,'Y','N',8);
	

end procedure;

SET CONSTRAINTS FK_GRPPERM_AI_ACSITEM DISABLED;
SET CONSTRAINTS FK_MENU_AI_ACSITEM DISABLED;
SET CONSTRAINTS FK_MENU_MI_ACSITEM DISABLED;

execute procedure clear_des_token_menu();
drop procedure clear_des_token_menu;

SET CONSTRAINTS FK_GRPPERM_AI_ACSITEM ENABLED;
SET CONSTRAINTS FK_MENU_AI_ACSITEM ENABLED;
SET CONSTRAINTS FK_MENU_MI_ACSITEM ENABLED;

execute procedure des_token_actions_perm('cortex');
drop procedure des_token_actions_perm;
	  
	  
	  