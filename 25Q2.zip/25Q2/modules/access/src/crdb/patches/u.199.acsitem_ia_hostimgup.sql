UPDATE ACSITEM SET COMMAND = 'hostinterfacemgmtsearchon.do' WHERE ACSITEM = 'ia_hostimgup';
