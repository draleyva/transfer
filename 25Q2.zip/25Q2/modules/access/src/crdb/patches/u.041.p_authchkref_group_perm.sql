create procedure authchkref_group_perm(p_usrgrp like usrgrp.usrgrp)
    
define t_maxtag	   int;
define i           int;


	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag
		from descr;
		
    let t_maxtag = t_maxtag + 1;
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Search', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_auchrefsh', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_auchrefsh', p_usrgrp, 'Y', 'N', '15');
    
    let t_maxtag = t_maxtag + 1;
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Add', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_auchrefdd', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_auchrefdd', p_usrgrp, 'Y', 'N', '15');

end procedure;

execute procedure authchkref_group_perm("cortex");

drop procedure authchkref_group_perm
