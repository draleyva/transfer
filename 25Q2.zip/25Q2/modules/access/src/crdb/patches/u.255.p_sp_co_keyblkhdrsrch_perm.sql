create procedure keyblkhdr_search_perm(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
	select max(descrtag) into t_maxtag
		from descr;
		
	let t_maxtag = t_maxtag + 1;

	insert into descr (descrtag, descr, lang) values (t_maxtag, 'Search Key Block Header', 'EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('keyblkhdrs','J2EF',' ','keyblkhdrsearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('keyblkhdrs',p_usrgrp,'Y','N',8);
	
end procedure;

execute procedure keyblkhdr_search_perm("cortex");

drop procedure keyblkhdr_search_perm;

