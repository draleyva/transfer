
create unique index unq_usr_extusr on  usr (extusr);

alter table usr add constraint unique (extusr) constraint unq_usr_extusr;

