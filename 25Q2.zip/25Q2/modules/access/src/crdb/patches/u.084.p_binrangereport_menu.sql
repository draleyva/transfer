create procedure binrangereport_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;
    let t_menuorder = 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'ia_reports' and usrgrp = p_usrgrp;

    -- Issuer > Reports > Bin Range Usage Report
    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Bin Range Usage Report','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rp_binrange','J2EF',' ','rpbinrangeusagereporton.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rp_binrange',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_reports','rp_binrange',t_maxtag,t_menuorder,p_usrgrp,'J2EF');

end procedure;

execute procedure binrangereport_menu("cortex");

drop procedure binrangereport_menu;
