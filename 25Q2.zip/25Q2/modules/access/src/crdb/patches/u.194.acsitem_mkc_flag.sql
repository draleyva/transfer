﻿-- Cortex Screens that will implement MKC functionality
UPDATE ACSITEM SET MKC_FLAG = '1' WHERE ACSITEM = 'ifm_rga';
UPDATE ACSITEM SET MKC_FLAG = '1' WHERE ACSITEM = 'ifm_rgcrddd';
UPDATE ACSITEM SET MKC_FLAG = '1' WHERE ACSITEM = 'ifm_rgcprdd';
UPDATE ACSITEM SET MKC_FLAG = '1' WHERE ACSITEM = 'ifm_rgchkdd';
