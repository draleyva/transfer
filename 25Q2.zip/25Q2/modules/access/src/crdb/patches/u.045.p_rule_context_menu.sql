create procedure rule_context_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag	   int;
define t_maxorder  int;
define t_menuorder int;
define i           int;


	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag
		from descr;
    
    
    let t_menuorder = 0;
    
           
    select max(morder) into t_menuorder from menu where mitem ='co_' and usrgrp=p_usrgrp;
    
    let t_menuorder = t_menuorder + 1;
    

    let t_maxtag = t_maxtag + 1;
    --RULE CONTEXT
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Rule Context', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_rulct', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_rulct', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_','co_rulct',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    let t_maxtag = t_maxtag + 1;
    --Add RULE CONTEXT
       
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Add', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_rule_cdd', 'J2EF', ' ', 'corulecontextdetailon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_rule_cdd', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_rulct','co_rule_cdd',t_maxtag,2,p_usrgrp,'J2EF');

    let t_maxtag = t_maxtag + 1;
    --Search RULE CONTEXT
        
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Search', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_rulecsch', 'J2EF', ' ', 'corulecontextsearchon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_rulecsch', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_rulct','co_rulecsch',t_maxtag,1,p_usrgrp,'J2EF');


end procedure;

execute procedure rule_context_menu("cortex");

drop procedure rule_context_menu;
