create procedure pa_mrchscheme_def_menu(p_usrgrp  like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

    ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag from descr;    
	let t_menuorder = 0;
    select nvl(max(morder),0)  into t_menuorder from menu where mitem = 'pa_maint' and usrgrp = p_usrgrp;
    let t_menuorder =  t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Scheme Definition Maintenance','EN');
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag,mkc_flag) values('pa_mrchsch_def','J2EM',' ',' ',' ',t_maxtag,0);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pa_mrchsch_def',p_usrgrp,'Y','N',15);
	insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('pa_maint','pa_mrchsch_def',t_maxtag,t_menuorder,p_usrgrp,'J2EM');
    let t_maxtag = t_maxtag + 1;
    Insert into DESCR(VERNO_CTX,DESCRTAG,DESCR,LANG) values (1,t_maxtag,'Add','EN');
	Insert into acsitem (VERNO_CTX,ACSITEM,ACSTYPE,SHORTNAME,COMMAND,HELPFORM,DESCRTAG,MKC_FLAG) values (1,'pa_mrchscdefdd','J2EF',' ','pamrchschemedefdetailon.do',' ',t_maxtag,0);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pa_mrchscdefdd',p_usrgrp,'Y','N',15);
	insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('pa_mrchsch_def','pa_mrchscdefdd',t_maxtag,1,p_usrgrp,'J2EF');
	let t_maxtag = t_maxtag + 1;
    Insert into DESCR(VERNO_CTX,DESCRTAG,DESCR,LANG) values (1,t_maxtag,'Search','EN');
	Insert into acsitem (VERNO_CTX,ACSITEM,ACSTYPE,SHORTNAME,COMMAND,HELPFORM,DESCRTAG,MKC_FLAG) values (1,'pa_mrchscdefsch','J2EF',' ','pamrchschemedefsearchon.do',' ',t_maxtag,0);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pa_mrchscdefsch',p_usrgrp,'Y','N',15);
	insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('pa_mrchsch_def','pa_mrchscdefsch',t_maxtag,2,p_usrgrp,'J2EF');

    
end procedure;

execute procedure pa_mrchscheme_def_menu('cortex');

drop procedure pa_mrchscheme_def_menu;


