create procedure add_new_crdmaintenance_acsitems

	ON EXCEPTION

	END EXCEPTION WITH RESUME;

	-- Insert new ACSITEM for Card Maintenance Details Screen
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values ('ia_crdreprint','J2EF',' ',' ',' ',0);
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values ('ia_crdreissue','J2EF',' ',' ',' ',0);

	-- Assign ACSITEM to cortex group
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_crdreprint','cortex','Y','N',8);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_crdreissue','cortex','Y','N',8);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_crdreprint','ctxadmin','Y','N',15);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_crdreissue','ctxadmin','Y','N',15);
	
end procedure;

execute procedure add_new_crdmaintenance_acsitems();

drop procedure add_new_crdmaintenance_acsitems;	