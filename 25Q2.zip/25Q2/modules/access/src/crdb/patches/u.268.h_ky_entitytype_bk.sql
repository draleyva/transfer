alter table entity_type_bk add constraint
	( foreign key (entity_type_id)
		references entity_type (id) 
		constraint fk_entitytypebk_entitytype);
