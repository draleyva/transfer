create procedure forex_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag		int;
define t_maxorder  int;
define t_menuorder int;
define i int;


	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag
		from descr;
    
    
    let t_menuorder = 0;
    
           
    select max(morder) into t_menuorder from menu where mitem ='co_' and usrgrp=p_usrgrp;
    
    let t_menuorder = t_menuorder + 1;
    

    let t_maxtag = t_maxtag + 1;
    --Forex
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Forex', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_forex', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_forex', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_','co_forex',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    let t_maxtag = t_maxtag + 1;
    --Add Forex 
       
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Add', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_forexdd', 'J2EF', ' ', 'coforexdetailon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_forexdd', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_forex','co_forexdd',t_maxtag,2,p_usrgrp,'J2EF');

    let t_maxtag = t_maxtag + 1;
    --Search Forex
        
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Search', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_forexsch', 'J2EF', ' ', 'coforexsearchon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_forexsch', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_forex','co_forexsch',t_maxtag,1,p_usrgrp,'J2EF');


end procedure;

execute procedure forex_menu("cortex");

drop procedure forex_menu;
