create procedure authcheck_menu()


	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    update menu set mitem='au_maint' where acsitem='ia_authchmnu' or acsitem='ia_authcomnu';
    update descr set descr='Authorisation Checks' where descrtag in (select descrtag from menu where mitem='au_maint' and acsitem='ia_authchmnu');
    update descr set descr='Authorisation Conditions' where descrtag in (select descrtag from menu where mitem='au_maint' and acsitem='ia_authcomnu');

end procedure;

execute procedure authcheck_menu();

drop procedure authcheck_menu;
