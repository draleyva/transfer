
alter table usr modify
( 
	id		serial		not null
); 
