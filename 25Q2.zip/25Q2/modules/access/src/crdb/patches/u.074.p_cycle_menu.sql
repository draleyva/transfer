create procedure cycle_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;

    -- Core > Rule Context
    let t_menuorder = 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'co_' and usrgrp = p_usrgrp;
    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Cycle Maintenance','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_cycles','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_cycles',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_','co_cycles',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- Core > Cycle > Search
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_cycle_sel','J2EF',' ','wicket/common/cycle',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_cycle_sel',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_cycles','co_cycle_sel',t_maxtag,2,p_usrgrp,'J2EF');
    
    -- Core > Cycle > Create
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Create','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_cycle_new','J2EF',' ','wicket/common/cycle?action=create',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_cycle_new',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_cycles','co_cycle_new',t_maxtag,2,p_usrgrp,'J2EF');

    --Permissions
    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_cycle_det','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_cycle_det',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_instsel','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_instsel',p_usrgrp,'Y','N',15);

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_currsel','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_currsel',p_usrgrp,'Y','N',15);
 
end procedure;

execute procedure cycle_menu("cortex");

drop procedure cycle_menu;
