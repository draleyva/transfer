delete from descr where descrtag in (select descrtag from acsitem where acsitem in ('rule_th_c','rule_th_e'));
delete from screenfield where acsitem in ('rule_th_c','rule_th_e');
delete from usrperm where acsitem in ('rule_th_c','rule_th_e');
delete from grpperm where acsitem in ('rule_th_c','rule_th_e');
delete from menu where acsitem in ('rule_th_c','rule_th_e');
delete from acsitem where acsitem in ('rule_th_c','rule_th_e');
