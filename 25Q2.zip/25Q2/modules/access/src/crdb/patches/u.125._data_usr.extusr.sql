-----------------------------------------------------------------------------
--*
--* this script does the following :
--*
--*	* update all usr.extusr values from usr.usr column
--*
-----------------------------------------------------------------------------


-- procedure to update the given usr record
--
create procedure update_extusr(i_rowid integer,
				i_extusr like usr.extusr)
	returning integer;

	define err_num integer;
	define isam_err integer;
	define err_txt  char(200);
	
	on exception set err_num, isam_err, err_txt	-- catch all errrors and error messages
	begin
		trace 'Error occurred at ' || err_txt;
		return err_num;		-- and return error code
	end
	end exception;
	
	update usr set extusr = i_extusr
		where rowid = i_rowid;
		
	return 0;

end procedure; -- update_extusr


-- procedure to loop through all usr records
--
create procedure loopusr()

	define ret integer;
	define c_cnt	integer;
	define at_once	integer;
	define comfreq	integer;
	define c_rowid       integer;

	define c_extusr	like usr.extusr;
	
	set debug file to 'upd_usr_extusrs.log';

	let comfreq = 4000;
	let at_once = -1;
	let ret = -1;
	let c_cnt = 0;
	
	-- start transaction
	begin work;

	-- select usr from  where c_extusr = '' or null
	foreach seq_usr_temp_cur with hold for
		select rowid into c_rowid from usr
		where extusr = '' or extusr is null
		select usr into c_extusr from usr where rowid = c_rowid;
		--let c_extusr = select usr from usr where rowid = c_rowid; 
		let c_cnt = c_cnt + 1;
		trace 'Update  (' || c_rowid || ')';
		execute procedure update_extusr(c_rowid, c_extusr)
				into ret;

		-- exit if an error occurred
		if ret < 0 then
			rollback work;
			exit foreach;
		end if;
		
		-- commit for commit frequency
		if mod(c_cnt, comfreq) = 0 then
			commit work;
			begin work;
		end if;

		-- finish after done enough for this run
		if at_once > 0 and mod(c_cnt, at_once) = 0 then
			exit foreach;
		end if;

	end foreach;

	-- end transaction
	if ret = 0 then
		commit work;
	else
		if c_cnt > 0 then
			rollback work;
		else
			rollback work;
		end if;
	end if;

end procedure; -- loopusr

execute procedure loopusr();

drop procedure loopusr;
drop procedure update_extusr;

