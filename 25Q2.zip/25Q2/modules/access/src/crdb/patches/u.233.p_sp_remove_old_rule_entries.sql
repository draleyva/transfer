create procedure remove_old_rule_entries()
	ON EXCEPTION
	END EXCEPTION WITH RESUME;

	-- Remove Atom menu definition
	delete from grpperm where acsitem = 'co_atomd';
	delete from menu where acsitem ='co_atomd';
	delete from acsitem where acsitem = 'co_atomd';

	-- Remove Atom def
	delete from grpperm where acsitem = 'co_rule_add';
	delete from menu where acsitem ='co_rule_add';
	delete from acsitem where acsitem = 'co_rule_add';

	-- Remove Search Atom 
	delete from grpperm where acsitem = 'co_ruleasch';
	delete from menu where acsitem ='co_ruleasch';
	delete from acsitem where acsitem = 'co_ruleasch';

	-- Remove Rule context menu definition
	delete from grpperm where acsitem = 'co_rulct';
	delete from menu where acsitem ='co_rulct';
	delete from acsitem where acsitem = 'co_rulct';
	
	-- Remove Add Rule Contex 
	delete from grpperm where acsitem = 'co_rule_cdd';
	delete from menu where acsitem ='co_rule_cdd';
	delete from acsitem where acsitem = 'co_rule_cdd';

	-- Remove Rule context menu definition
	delete from grpperm where acsitem = 'co_ruldf';
	delete from menu where acsitem ='co_ruldf';
	delete from acsitem where acsitem = 'co_ruldf';

		-- Remove Search Rule Contex 
	delete from grpperm where acsitem = 'co_rulecsch';
	delete from menu where acsitem ='co_rulecsch';
	delete from acsitem where acsitem = 'co_rulecsch';

	-- Remove Add Rule Def
	delete from grpperm where acsitem = 'co_rule_ddd';
	delete from menu where acsitem ='co_rule_ddd';
	delete from acsitem where acsitem = 'co_rule_ddd';

	-- Remove Search Rule Def
	delete from grpperm where acsitem = 'co_ruledsch';
	delete from menu where acsitem ='co_ruledsch';
	delete from acsitem where acsitem = 'co_ruledsch';

	-- Remove Add Rule Group Search
	delete from grpperm where acsitem = 'co_rulegsch';
	delete from menu where acsitem ='co_rulegsch';
	delete from acsitem where acsitem = 'co_rulegsch';

	-- Remove Add Rule Group Def
	delete from grpperm where acsitem = 'co_rule_gdd';
	delete from menu where acsitem ='co_rule_gdd';
	delete from acsitem where acsitem = 'co_rule_gdd';

	-- Remove Add Rule Group Def
	delete from grpperm where acsitem = 'co_rulgdgdd';
	delete from menu where acsitem ='co_rulgdgdd';
	delete from acsitem where acsitem = 'co_rulgdgdd';
	
	-- Remove Add Rule Group Def Search
	delete from grpperm where acsitem = 'co_rulgdsch';
	delete from menu where acsitem ='co_rulgdsch';
	delete from acsitem where acsitem = 'co_rulgdsch';
	
end procedure;

execute procedure remove_old_rule_entries();

drop procedure remove_old_rule_entries;

