ALTER TABLE screenfield ADD (sftype smallint);

UPDATE screenfield set sftype=1;

ALTER TABLE screenfield MODIFY (sftype smallint not null);