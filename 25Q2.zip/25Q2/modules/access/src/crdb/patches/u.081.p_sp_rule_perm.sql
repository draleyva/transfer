create procedure rule_perm_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag from descr;    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');


    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_cat_c','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_to_c','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_to_c2','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_th_c','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_cat_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_to_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_th_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_tos_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_tos_v','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('risk_cns_e','J2EF',' ',' ',' ',t_maxtag);

    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_cat_c',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_to_c',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_to_c2',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_th_c',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_cat_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_to_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_th_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_tos_m',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_tos_v',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('risk_cns_e',p_usrgrp,'Y','N',15);
    
end procedure;

execute procedure rule_perm_menu('cortex');

drop procedure rule_perm_menu;
