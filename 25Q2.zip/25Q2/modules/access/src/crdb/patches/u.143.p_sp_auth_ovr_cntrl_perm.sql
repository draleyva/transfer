create procedure auth_ovr_cntrl(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    like acsitem.descrtag;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;

    -- Extended Authorization and Add Override Control
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_extauthcntrl','J2EF',' ','extauthcontrolson.do',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_addovercntrl','J2EF',' ','addovercntrl.do',' ',t_maxtag);

    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_extauthcntrl',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_addovercntrl',p_usrgrp,'Y','N',15);

end procedure;

execute procedure auth_ovr_cntrl('cortex');

drop procedure auth_ovr_cntrl;
