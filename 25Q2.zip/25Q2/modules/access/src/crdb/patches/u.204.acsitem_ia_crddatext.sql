UPDATE ACSITEM SET COMMAND = 'carddataextracton.do' WHERE ACSITEM = 'ia_crddatext';

