create procedure remove_ifm_entries()
	ON EXCEPTION
	END EXCEPTION WITH RESUME;

	-- CTXAPPSMAINT-3196
	delete from screenfield where acsitem='ifm_crdagpdd' or acsitem='ifm_cdagpsch' or acsitem='ifm_crdagmdd';
	delete from grpperm where acsitem='ifm_crdagpdd' or acsitem='ifm_cdagpsch' or acsitem='ifm_crdagmdd';
	delete from acsitem where acsitem='ifm_crdagpdd' or acsitem='ifm_cdagpsch' or acsitem='ifm_crdagmdd';

	-- CTXAPPSMAINT-3197
	delete from screenfield where acsitem='ifm_ctrygpdd' or acsitem='ifm_ctrygmdd' or acsitem='ifm_ctygpsch';
	delete from grpperm where acsitem='ifm_ctrygpdd' or acsitem='ifm_ctrygmdd' or acsitem='ifm_ctygpsch';
	delete from acsitem where acsitem='ifm_ctrygpdd' or acsitem='ifm_ctrygmdd' or acsitem='ifm_ctygpsch';

	-- CTXAPPSMAINT-3198
	delete from screenfield where acsitem='ifm_ifmcadd' or acsitem='ifm_ifmcasch' or acsitem='ifm_ifmcgdd' or acsitem='ifm_ifmcgsch';
	delete from grpperm where acsitem='ifm_ifmcadd' or acsitem='ifm_ifmcasch' or acsitem='ifm_ifmcgdd' or acsitem='ifm_ifmcgsch';	
	delete from acsitem where acsitem='ifm_ifmcadd' or acsitem='ifm_ifmcasch' or acsitem='ifm_ifmcgdd' or acsitem='ifm_ifmcgsch';

	-- CTXAPPSMAINT-3199
	delete from screenfield where acsitem='ifm_ifmchsch' or acsitem='ifm_ifmchdd' or acsitem='ifm_ifmfedd' or acsitem='ifm_ifmfesch';
	delete from grpperm where acsitem='ifm_ifmchsch' or acsitem='ifm_ifmchdd' or acsitem='ifm_ifmfedd' or acsitem='ifm_ifmfesch';
	delete from acsitem where acsitem='ifm_ifmchsch' or acsitem='ifm_ifmchdd' or acsitem='ifm_ifmfedd' or acsitem='ifm_ifmfesch';
	
	-- CTXAPPSMAINT-3200
	delete from screenfield where acsitem='ifm_ifmpadd' or acsitem='ifm_ifmpasch' or acsitem='ifm_ifmrusch' or acsitem='ifm_ifmrudd';
	delete from grpperm where acsitem='ifm_ifmpadd' or acsitem='ifm_ifmpasch' or acsitem='ifm_ifmrusch' or acsitem='ifm_ifmrudd';
	delete from acsitem where acsitem='ifm_ifmpadd' or acsitem='ifm_ifmpasch' or acsitem='ifm_ifmrusch' or acsitem='ifm_ifmrudd';

	-- CTXAPPSMAINT-3201
	delete from screenfield where acsitem='ifm_rgchksch' or acsitem='ifm_rgchkdd' or acsitem='ifm_rgcrdsch' or acsitem='ifm_rgcrddd';
	delete from grpperm where acsitem='ifm_rgchksch' or acsitem='ifm_rgchkdd' or acsitem='ifm_rgcrdsch' or acsitem='ifm_rgcrddd';
	delete from acsitem where acsitem='ifm_rgchksch' or acsitem='ifm_rgchkdd' or acsitem='ifm_rgcrdsch' or acsitem='ifm_rgcrddd';

	-- CTXAPPSMAINT-3202
	delete from screenfield where acsitem='ifm_rgcprdd' or acsitem='ifm_rgcprsch' or acsitem='ifm_ifmrgdd' or acsitem='ifm_ifmrgsch';
	delete from grpperm where acsitem='ifm_rgcprdd' or acsitem='ifm_rgcprsch' or acsitem='ifm_ifmrgdd' or acsitem='ifm_ifmrgsch';
	delete from acsitem where acsitem='ifm_rgcprdd' or acsitem='ifm_rgcprsch' or acsitem='ifm_ifmrgdd' or acsitem='ifm_ifmrgsch';

	-- CTXAPPSMAINT-3203
	delete from screenfield where acsitem='ifm_ifmrpdd' or acsitem='ifm_ifmrpsch' or acsitem='ifm_rptrldd' or acsitem='ifm_rptrlsch';
	delete from grpperm where acsitem='ifm_ifmrpdd' or acsitem='ifm_ifmrpsch' or acsitem='ifm_rptrldd' or acsitem='ifm_rptrlsch';
	delete from acsitem where acsitem='ifm_ifmrpdd' or acsitem='ifm_ifmrpsch' or acsitem='ifm_rptrldd' or acsitem='ifm_rptrlsch';

	-- CTXAPPSMAINT-3204
	delete from screenfield where acsitem='ifm_mccgrpdd' or acsitem='ifm_mccgpmdd' or acsitem='ifm_mccgpsch';
	delete from grpperm where acsitem='ifm_mccgrpdd' or acsitem='ifm_mccgpmdd' or acsitem='ifm_mccgpsch';
	delete from acsitem where acsitem='ifm_mccgrpdd' or acsitem='ifm_mccgpmdd' or acsitem='ifm_mccgpsch';

	-- CTXAPPSMAINT-3211
	delete from screenfield where acsitem='co_zmchecks' or acsitem='co_zmriskgrp' or acsitem='co_zmifmrls';
	delete from grpperm where acsitem='co_zmchecks' or acsitem='co_zmriskgrp' or acsitem='co_zmifmrls';
	delete from acsitem where acsitem='co_zmchecks' or acsitem='co_zmriskgrp' or acsitem='co_zmifmrls';
	
end procedure;

execute procedure remove_ifm_entries();

drop procedure remove_ifm_entries;

