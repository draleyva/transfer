-- Upload Search Results - Transaction statuses

	 execute procedure addupd_numdescr('EN', 'txnstats', 0, 'Pending');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 1, 'Batch Pending');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 2, 'Authorization reversal pending');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 3, 'Not on us transaction pending');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 4, 'Commission pending');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 5, 'Fee pending');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 6, 'ATM replenishment pending');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 7, 'CAC pending');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 8, 'Time out reversal pending');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 80, 'Sent');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 81, 'Batch sent');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 82, 'Authorization reversal sent');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 83, 'Not on us transaction sent');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 84, 'Commission sent');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 85, 'Fee sent');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 86, 'ATM replenishment sent');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 87, 'CAC sent');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 88, 'Time out reversal sent');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 90, 'Failed');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 91, 'Batch failed');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 92, 'Authorization reversal failed');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 93, 'Not on us transaction failed');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 94, 'Commission failed');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 95, 'Fee failed');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 96, 'ATM replenishment failed');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 97, 'CAC failed');
	
	 execute procedure addupd_numdescr('EN', 'txnstats', 98, 'Time out reversal failed');
