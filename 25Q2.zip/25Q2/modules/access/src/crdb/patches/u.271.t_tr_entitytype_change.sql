select 'creating trigger for entity_type table' from systables where tabid = 1;


CREATE TRIGGER entity_type_change UPDATE ON entity_type
REFERENCING OLD AS old NEW AS new
FOR EACH ROW
(
	execute procedure increment_int(new.verno_ctx ) into verno_ctx
);


