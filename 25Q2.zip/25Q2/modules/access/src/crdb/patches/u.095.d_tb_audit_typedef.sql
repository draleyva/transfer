
select 'creating table AUDIT_TYPEDEF' from systables where tabid = 1;

create table AUDIT_TYPEDEF 
(	
    id serial not null, 
	objecttype_id integer not null, 
	identifier1key varchar(255,0), 
	identifier2key varchar(255,0), 
	identifier3key varchar(255,0), 
	identifier4key varchar(255,0), 
	identifier1label varchar(255,0), 
	identifier2label varchar(255,0), 
	identifier3label varchar(255,0), 
	identifier4label varchar(255,0),
	idlabel varchar(255,0)
)
lock mode row;
