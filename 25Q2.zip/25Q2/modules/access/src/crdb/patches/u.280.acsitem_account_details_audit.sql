create procedure add_new_accdet_acsitems()

define t_maxtag    int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

	select max(descrtag) into t_maxtag from descr;
		
	let t_maxtag = t_maxtag + 1;
	insert into descr (descrtag, descr, lang) values (t_maxtag, 'Update Unset fields', 'EN');
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values ('ia_unsentupd','J2EF',' ',' ',' ',t_maxtag);
	
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_unsentupd','cortex','Y','N',8);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_unsentupd','ctxadmin','Y','N',15);

end procedure;

execute procedure add_new_accdet_acsitems();

drop procedure add_new_accdet_acsitems;	
