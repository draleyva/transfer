create procedure managepin(p_usrgrp like usrgrp.usrgrp)



	define t_maxtag		int;

	ON EXCEPTION END EXCEPTION WITH RESUME;

		

	select max(descrtag) into t_maxtag from descr;

	let t_maxtag = t_maxtag + 1;

	-- Add Report

	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag)

	values('ws_managepin','J2EF',' ',' ',' ',t_maxtag);

	insert into descr(descrtag,descr,lang)

	values(t_maxtag,'ManagePin Webservice','EN');

	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag)

	values('ws_managepin',p_usrgrp,'Y','N',15);

   

end procedure;



execute procedure managepin("cortex");



drop procedure managepin;



