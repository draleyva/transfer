alter table usr add
(
    email_address nvarchar(64) 
);

