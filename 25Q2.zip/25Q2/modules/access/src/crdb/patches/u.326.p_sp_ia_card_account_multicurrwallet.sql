create procedure ia_card_account_multicurrwallet(p_usrgrp like usrgrp.usrgrp)

define t_maxtag int;

    ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;  
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values (t_maxtag,'Card Account Multicurrency Wallet Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag,mkc_flag) values ('ia_crdaccmltcur','J2EF',' ','iacardaccountmulticurrwalletsearchon.do',' ',t_maxtag,0);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values ('ia_crdaccmltcur',p_usrgrp,'Y','N',15);
end procedure;

execute procedure ia_card_account_multicurrwallet('cortex');

drop procedure ia_card_account_multicurrwallet;
