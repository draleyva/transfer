-- Adding serial column id to usrinst table
--    drop the primary key constraint
--    add the id as an integer first
--    update it for all records
--    change the type of the column to serial

create procedure temp_usrinst_serial( )

	define usrinst_nb integer;
	define in_usr like usrinst.usr;
	define in_inst_id like usrinst.inst_id;
	
	let usrinst_nb = 1;
	
	alter table usrinst drop constraint pk_usrinst;
	
	alter table usrinst add
	(
		id          integer         default 0     not null
	);
	
	
	-- For each record in the table, update the id with the next
	-- usrinst_nb.
	foreach usrinst_res for
		select usr,
			   inst_id
		  into in_usr,
			   in_inst_id
		  from usrinst
		  
		update usrinst 
		   set id = usrinst_nb 
		 where usr = in_usr
		   and inst_id = in_inst_id;
		  
		 let usrinst_nb = usrinst_nb + 1;
	end foreach;
	
	alter table usrinst modify (id serial);

end procedure;

execute procedure temp_usrinst_serial();

drop procedure temp_usrinst_serial;
