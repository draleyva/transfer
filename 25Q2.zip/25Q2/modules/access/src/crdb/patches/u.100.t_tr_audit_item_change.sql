select 'creating update trigger for AUDIT_ITEM table' from systables where tabid = 1;

create trigger AUDIT_ITEM_change update on AUDIT_ITEM
referencing old as oldrec new as newrec
for each row
(
	execute procedure increment_int(newrec.verno_ctx) into verno_ctx
);

