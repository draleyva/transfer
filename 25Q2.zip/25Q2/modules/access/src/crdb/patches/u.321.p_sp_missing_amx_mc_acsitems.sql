create procedure missing_amx_mc_acsitems(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Amex Parent Batch Detail','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('amx_prntdet','J2EF',' ','amxparentbatchdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('amx_prntdet',p_usrgrp,'Y','N',15);

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Amex Parent Batch Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('amx_prntsrc','J2EF',' ','amxparentbatchsearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('amx_prntsrc',p_usrgrp,'Y','N',15);

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'MasterCard Parent Batch Detail','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mc_prntdet','J2EF',' ','mcparentbatchdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mc_prntdet',p_usrgrp,'Y','N',15);

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'MasterCard Parent Batch Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mc_prntsrc','J2EF',' ','mcparentbatchsearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mc_prntsrc',p_usrgrp,'Y','N',15);

end procedure;

execute procedure missing_amx_mc_acsitems('cortex');

drop procedure missing_amx_mc_acsitems;
