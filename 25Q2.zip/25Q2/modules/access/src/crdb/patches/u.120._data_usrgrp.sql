-----------------------------------------------------------------------------
--*
--* this script does the following :
--*
--*	* update all usrgrp.id values sequentially
--*
-----------------------------------------------------------------------------


-- procedure to update the given usrgrp record
--
create procedure update_id(i_rowid integer,
				i_id like usrgrp.id)
	returning integer;

	define err_num integer;
	define isam_err integer;
	define err_txt  char(200);
	
	on exception set err_num, isam_err, err_txt	-- catch all errrors and error messages
	begin
		trace 'Error occurred at ' || err_txt;
		return err_num;		-- and return error code
	end
	end exception;
	
	update usrgrp set id = i_id
		where rowid = i_rowid;
		
	return 0;

end procedure; -- update_id


-- procedure to loop through all usrgrp records
--
create procedure mainloop()

	define ret integer;
	define c_cnt	integer;
	define at_once	integer;
	define comfreq	integer;
  define c_rowid       integer;

	define c_id	like usrgrp.id;
	
	set debug file to 'upd_usrgrp_ids.log';

	let comfreq = 4000;
	let at_once = -1;
	let ret = -1;
	let c_cnt = 0;
	
	select max(id) into c_id from usrgrp
	where id = 0 or id is null;

	if c_id is null then
		let c_id = 0;
	end if;
	
	-- start transaction
	begin work;

	-- select hash fields from  where id = 0
	foreach seq_usrgrp_temp_cur with hold for
		select rowid into c_rowid from usrgrp
		where id = 0 or id is null

		let c_id = c_id + 1;
		let c_cnt = c_cnt + 1;
		trace 'Update  (' || c_rowid || ')';
		execute procedure update_id(c_rowid, c_id)
				into ret;

		-- exit if an error occurred
		if ret < 0 then
			rollback work;
			exit foreach;
		end if;
		
		-- commit for commit frequency
		if mod(c_cnt, comfreq) = 0 then
			commit work;
			begin work;
		end if;

		-- finish after done enough for this run
		if at_once > 0 and mod(c_cnt, at_once) = 0 then
			exit foreach;
		end if;

	end foreach;

	-- end transaction
	if ret = 0 then
		commit work;
	else
		if c_cnt > 0 then
			rollback work;
		else
			rollback work;
		end if;
	end if;

end procedure; -- mainloop

execute procedure mainloop();

drop procedure mainloop;
drop procedure update_id;

