create procedure des_approve_cardholder_verification_perm(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;
	
	--des_apcrdhldver
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Approve Cardholder Verification','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_apcrdhldver','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_apcrdhldver',p_usrgrp,'Y','N',8);

end procedure;

execute procedure des_approve_cardholder_verification_perm('cortex');
drop procedure des_approve_cardholder_verification_perm;
	  
	  
	  