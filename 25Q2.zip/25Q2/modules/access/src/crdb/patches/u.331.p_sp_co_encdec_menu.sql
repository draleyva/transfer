create procedure encdec_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;

    
    let t_menuorder = 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'co_' and usrgrp = p_usrgrp;
    let t_menuorder = t_menuorder + 1;
	
	-- Core > Encrypted Decimalization
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Encrypted Decimalization','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('encdec','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('encdec',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_','encdec',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

	-- Core > Encrypted Decimalization > Add
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Create/Edit Encrypted Decimalization','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag,mkc_flag,mkc_src_code,audit_src_code) values('encdec_cr_ed','J2EF',' ','wicket/core/encdec?action=create',' ',t_maxtag,'1','CTX','cxo');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('encdec_cr_ed',p_usrgrp,'Y','N',8);
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('encdec','encdec_cr_ed',t_maxtag,1,p_usrgrp,'J2EF');
	
    -- Core > Encrypted Decimalization > Search
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search Encrypted Decimalization','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('encdec_sel','J2EF',' ','wicket/core/encdec',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('encdec_sel',p_usrgrp,'Y','N',8);
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('encdec','encdec_sel',t_maxtag,2,p_usrgrp,'J2EF');

    --Permissions
    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Encrypted Decimalization Main','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('encdec_m','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('encdec_m',p_usrgrp,'Y','N',8);                                                                                                                       
 
end procedure;

execute procedure encdec_menu("cortex");

drop procedure encdec_menu;
