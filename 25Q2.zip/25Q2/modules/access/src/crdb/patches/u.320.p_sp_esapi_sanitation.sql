create procedure esapi_sanitation(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'ESAPI Sanitation Error','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_esapi','J2EF',' ',' ',' ',t_maxtag);
    
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_esapi',p_usrgrp,'Y','N',15);
    
end procedure;

execute procedure esapi_sanitation('cortex');

drop procedure esapi_sanitation;
