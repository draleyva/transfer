create procedure remove_script_runner_menu( )
	ON EXCEPTION
	END EXCEPTION WITH RESUME;

	-- Add Script Runner
	delete from descr where descrtag in (select distinct descrtag from menu where acsitem ='co_scrptadd');
	delete from grpperm where acsitem = 'co_scrptadd';
	delete from menu where mitem = 'co_scrptrun' and acsitem ='co_scrptadd';
	delete from acsitem where acsitem = 'co_scrptadd';
	
	-- Search Script Runner	
	delete from descr where descrtag in (select distinct descrtag from menu where acsitem ='co_scrptsch');
	delete from grpperm where acsitem = 'co_scrptsch';
	delete from menu where mitem = 'co_scrptrun' and acsitem ='co_scrptsch';
	delete from acsitem where acsitem = 'co_scrptsch';

	-- Script Runner	
	delete from descr where descrtag in (select distinct descrtag from menu where acsitem ='co_scrptrun');
	delete from grpperm where acsitem = 'co_scrptrun';
	delete from menu where mitem = 'co_' and acsitem ='co_scrptrun';
	delete from acsitem where acsitem = 'co_scrptrun';
	
end procedure;

execute procedure remove_script_runner_menu();

drop procedure remove_script_runner_menu;
