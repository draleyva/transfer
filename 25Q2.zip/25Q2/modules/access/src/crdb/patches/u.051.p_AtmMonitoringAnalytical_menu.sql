create procedure report_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag	   int;

ON EXCEPTION
	END EXCEPTION WITH RESUME;

select max(descrtag) into t_maxtag from descr;
 
let t_maxtag = t_maxtag + 1;
    
--Add ATM Monitoring Analytical Report Menu
        
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'ATM Monitoring Analytical', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('rp_atmstu', 'J2EF', ' ', 'rpatmstureporton.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('rp_atmstu', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('aa_reports','rp_atmstu',t_maxtag,1,p_usrgrp,'J2EF');


end procedure;

execute procedure report_menu('cortex');


drop procedure report_menu;
