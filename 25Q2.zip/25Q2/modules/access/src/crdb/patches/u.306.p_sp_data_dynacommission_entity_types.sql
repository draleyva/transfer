create procedure fill_dynacommission_entity_type_keys()

define t_entity_type_id          like entity_type.id;
define t_entity_type_bk_id       like entity_type_bk.id;

	ON EXCEPTION

	END EXCEPTION WITH RESUME;

	select max(id) into t_entity_type_id from entity_type;
	let t_entity_type_id = t_entity_type_id + 1;
	insert into entity_type(id, code, source_code) VALUES (t_entity_type_id, 'cat_isscomm', 'cxo');
	select max(id) into t_entity_type_bk_id from ENTITY_TYPE_BK;
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'institutionCode', 1, t_entity_type_id);
	let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'categoryValue', 2, t_entity_type_id);

	let t_entity_type_id = t_entity_type_id + 1;
	insert into entity_type(id, code, source_code) VALUES (t_entity_type_id, 'threshold_set', 'cxo');
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'institutionCode', 1, t_entity_type_id);
	let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'code', 2, t_entity_type_id);

	let t_entity_type_id = t_entity_type_id + 1;
	insert into entity_type(id, code, source_code) VALUES (t_entity_type_id, 'rule_evalset', 'cxo');
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'institutionCode', 1, t_entity_type_id);
	let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'setDimension', 2, t_entity_type_id);
	let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'classDimension', 3, t_entity_type_id);

	update ACSITEM set AUDIT_SRC_CODE='cxo' where ACSITEM in ('rule_sets','fc_c_icc_m','fc_c_cn_m','fc_c_cl_m','fc_c_tac_m','fc_f_thach_m');

end procedure;

execute procedure fill_dynacommission_entity_type_keys();

drop procedure fill_dynacommission_entity_type_keys();
