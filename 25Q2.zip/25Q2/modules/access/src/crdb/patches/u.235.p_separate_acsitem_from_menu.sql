create procedure copy_descr_update_acsitem(t_acsitem_acsitem like acsitem.acsitem,
	t_acsitem_descrtag like acsitem.descrtag)
	returning integer;

	define err_num integer;
	define isam_err integer;
	define err_txt char(200);
	define t_max_descrtag like descr.descrtag;
	define t_descr_descr like descr.descr;
	define t_descr_lang like descr.lang;

	on exception set err_num, isam_err, err_txt
	begin
		trace 'Error occurred at ' || err_txt;
		return err_num;		-- and return error code
	end
	end exception;

	select max(descrtag)+1 into t_max_descrtag
		from DESCR;

	foreach 
		select descr, lang
		into t_descr_descr, t_descr_lang
		from DESCR
		where descrtag = t_acsitem_descrtag
	begin
		insert into DESCR (descrtag, descr, lang)
			values (t_max_descrtag, t_descr_descr, t_descr_lang);
	end;
	end foreach;

	update ACSITEM set descrtag=t_max_descrtag
		where acsitem=t_acsitem_acsitem;

	return 0;

end procedure;


create procedure separate_acsitem_from_menu()
	define ret integer;
	define t_acsitem_acsitem like acsitem.acsitem;
	define t_acsitem_descrtag like acsitem.descrtag;

	let ret = -1;

	begin work;

	foreach 
		select acsitem, descrtag
		into t_acsitem_acsitem, t_acsitem_descrtag
		from ACSITEM
		where descrtag in (select descrtag from MENU)
	begin
		execute procedure copy_descr_update_acsitem(t_acsitem_acsitem,
			t_acsitem_descrtag)
				into ret;

		if ret < 0 then
			rollback work;
			exit foreach;
		end if;
	end;
	end foreach;

	-- end transaction
	if ret = 0 then
		commit work;
	else
		rollback work;
	end if;

end procedure;

execute procedure separate_acsitem_from_menu();

drop procedure separate_acsitem_from_menu;
drop procedure copy_descr_update_acsitem;
