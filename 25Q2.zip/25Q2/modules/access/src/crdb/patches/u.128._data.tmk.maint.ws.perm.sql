create procedure tmkencryption_wbservice_param(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;

    -- Fall-back settings
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Encryption - web service authentication','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_newtmk','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_newtmk',p_usrgrp,'Y','N',15);

end procedure;

execute procedure tmkencryption_wbservice_param("cortex");

drop procedure tmkencryption_wbservice_param;
