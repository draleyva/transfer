create view menuelement (usrgrp, mitem, acsitem, morder, acstype, title, title_lang)
		as
		select m.usrgrp, m.mitem, m.acsitem, m.morder, m.acstype, d.descr, d.lang
		from menu m left join descr d
					on d.descrtag = m.descrtag;
