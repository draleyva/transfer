create procedure crdprod_sel_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('crdprd_sel_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('crdprd_sel_hm','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('crdprdsel_cn_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('crdprdsel_cns_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('crdprdsel_cn_c','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('crdprdsel_cn_c1','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('crdprdsel_cn_e','J2EF',' ',' ',' ',t_maxtag);


    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('crdprd_sel_m',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('crdprd_sel_hm',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('crdprdsel_cn_m',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('crdprdsel_cns_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('crdprdsel_cn_c',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('crdprdsel_cn_c1',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('crdprdsel_cn_e',p_usrgrp,'Y','N',15);


    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'ia_maint' and usrgrp = p_usrgrp;   
    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Card Product Selection','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('crdprod_sel','J2EF',' ','wicket/issuer/crdprodsel',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_maint','crdprod_sel',t_maxtag,t_menuorder,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('crdprod_sel',p_usrgrp,'Y','N',15);
    
end procedure;

execute procedure crdprod_sel_menu('cortex');

drop procedure crdprod_sel_menu;
