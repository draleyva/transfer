create procedure card_limit_override_menu()

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    update acsitem set command='cardlimitoverridesearchon.do' where acsitem='ia_crdlimvs';

end procedure;

execute procedure card_limit_override_menu();

drop procedure card_limit_override_menu;
