CREATE UNIQUE INDEX pk_entitytype_bk
	ON  entity_type_bk  (id) using btree;

CREATE UNIQUE INDEX hash_entitytype_bk
	ON  entity_type_bk (code, entity_type_id) using btree;
	
alter table entity_type_bk
	add primary key (code, entity_type_id) constraint pk_entity_type_bk;	

