create procedure des_updtknassrc_perm(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
	select max(descrtag) into t_maxtag
		from descr;
		
	let t_maxtag = t_maxtag + 1;

	insert into descr (descrtag, descr, lang) values (t_maxtag, 'Update Token Assurance', 'EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_updtknassrc','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_updtknassrc',p_usrgrp,'Y','N',8);
	
end procedure;

execute procedure des_updtknassrc_perm("cortex");

drop procedure des_updtknassrc_perm;

