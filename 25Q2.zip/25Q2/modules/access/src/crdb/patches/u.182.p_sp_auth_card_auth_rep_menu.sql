create procedure add_CardAuthrepReport(p_usrgrp like usrgrp.usrgrp)

	define t_maxtag		int;
	define t_maxorder  int;

	ON EXCEPTION END EXCEPTION WITH RESUME;
		
	select max(descrtag) into t_maxtag from descr;
	let t_maxtag = t_maxtag + 1;
	select max(morder) into t_maxorder from menu where mitem ='au_reports' and usrgrp=p_usrgrp;
	let t_maxorder = t_maxorder + 1;

	-- Add Report
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag)
	values('rp_cardauthrep','J2EF',' ','wicket/authoriser/reports/cardauthrep','\ ',t_maxtag);
	insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype)
	values('au_reports','rp_cardauthrep',t_maxtag,t_maxorder,p_usrgrp,'J2EF');
	insert into descr(descrtag,descr,lang)
	values(t_maxtag,'Card Authorisation Report','EN');
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag)
	values('rp_cardauthrep',p_usrgrp,'Y','N',15);
   
end procedure;

execute procedure add_CardAuthrepReport("cortex");

drop procedure add_CardAuthrepReport;

