
create unique index hash_usr on  usr (id);

alter table usr add constraint unique (id) constraint hash_usr;

