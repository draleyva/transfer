alter table acsitem modify (acsitem char(15) not null);
alter table acsitem add constraint primary key(acsitem);

alter table menu modify (mitem char(15) not null);
alter table menu add constraint
    ( foreign key (mitem) references acsitem (acsitem) );
alter table menu modify (acsitem char(15) not null);
alter table menu add constraint
    ( foreign key (acsitem) references acsitem (acsitem) );

alter table grpperm modify (acsitem char(15) not null);
alter table grpperm add constraint
    ( foreign key (acsitem) references acsitem (acsitem) );

alter table usrperm modify (acsitem char(15) not null);
alter table usrperm add constraint
    ( foreign key (acsitem) references acsitem (acsitem) );
