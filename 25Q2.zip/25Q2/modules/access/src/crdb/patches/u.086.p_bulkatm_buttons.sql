create procedure bulkatm_buttons(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag from descr;    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Access to Bulk buttons','EN');

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values ('aa_bulkatm','J2EF',' ',' ',' ',t_maxtag);

    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values ('aa_bulkatm',p_usrgrp,'Y','N',15);

end procedure;

execute procedure bulkatm_buttons('cortex');

drop procedure bulkatm_buttons;
