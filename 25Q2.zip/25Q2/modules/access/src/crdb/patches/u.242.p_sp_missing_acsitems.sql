create procedure missing_acsitem(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    like acsitem.descrtag;

	ON EXCEPTION

	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Replace Lost/Stolen Card Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_replosts','J2EF',' ','iareplacelostorstolencardssearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_replosts',p_usrgrp,'Y','N',8);

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Customer / Accounts','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_cardacc','J2EF',' ','iacardaccounton.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_cardacc',p_usrgrp,'Y','N',8);

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Accitem Details','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_accitedd','J2EF',' ','iaaccitemsdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_accitedd',p_usrgrp,'Y','N',8);

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Account Statement Details','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ccs_stmta','J2EF',' ','ccsccsstatementdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ccs_stmta',p_usrgrp,'Y','N',8);

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'View Credit Account Item','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ccs_itema','J2EF',' ','ccsccsitemdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ccs_itema',p_usrgrp,'Y','N',8);

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'View Account Events','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ccs_acceva','J2EF',' ','ccsccsacceventdetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ccs_acceva',p_usrgrp,'Y','N',8);

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Card Notifications Details','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_crdnotdd','J2EF',' ','iacrdnotifydetailon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_crdnotdd',p_usrgrp,'Y','N',8);

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Due Amounts by Age of Debt','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ccs_amtdueage','J2EF',' ','ccsccsdueagecmpdetailson.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ccs_amtdueage',p_usrgrp,'Y','N',8);

    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Card Recurring Transaction List','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_crdsrctx','J2EF',' ','iacardsrecurringtransactionssearchon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_crdsrctx',p_usrgrp,'Y','N',8);

end procedure;

execute procedure missing_acsitem('cortex');

drop procedure missing_acsitem;
