create procedure emv_upi_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

    ON EXCEPTION
    END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;
    
    let t_menuorder = 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'prdcnfmaint' and usrgrp = p_usrgrp;
    let t_menuorder = t_menuorder + 1;

    -- Issuer > Product Configuration > EMV Configuration UPI
    let t_maxtag = t_maxtag + 1; 
    insert into descr(descrtag,descr,lang) values(t_maxtag,'EMV Configuration UnionPay','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emv_confupi','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emv_confupi',p_usrgrp,'Y','N',8);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('prdcnfmaint','emv_confupi',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- Issuer > Product Configuration > EMV Configuration UPI > Add
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Create/Edit UnionPay','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag,mkc_src_code,mkc_flag) values('emvcnfupi_cr_ed','J2EF',' ','wicket/emv/emvconfigupi?action=create',' ',t_maxtag,'CTX','1');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvcnfupi_cr_ed',p_usrgrp,'Y','N',8);
	let t_maxtag = t_maxtag + 1;
	insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('emv_confupi','emvcnfupi_cr_ed',t_maxtag,1,p_usrgrp,'J2EF');

    -- Issuer > Product Configuration > EMV Configuration UPI > Search
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search UnionPay','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvcnfupi_sel','J2EF',' ','wicket/emv/emvconfigupi',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvcnfupi_sel',p_usrgrp,'Y','N',8);
	let t_maxtag = t_maxtag + 1;
	insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('emv_confupi','emvcnfupi_sel',t_maxtag,2,p_usrgrp,'J2EF');
   
    --Permissions
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'UnionPay Main','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvcnfupi_m','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvcnfupi_m',p_usrgrp,'Y','N',8);
	
	let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'EMV Config UnionPay Zoom','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('emvupizoom_sel','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('emvupizoom_sel',p_usrgrp,'Y','N',8);

end procedure;

execute procedure emv_upi_menu("cortex");

drop procedure emv_upi_menu;

