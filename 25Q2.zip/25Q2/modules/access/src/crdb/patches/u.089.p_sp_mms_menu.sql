create procedure mms_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

    ON EXCEPTION
    END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;

    -- Merchant Management
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Merchants','EN');

    let t_menuorder = 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = p_usrgrp and usrgrp = p_usrgrp;
    let t_menuorder = t_menuorder + 1;

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_','J2EM',' ',' ',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values(p_usrgrp,'mms_',t_maxtag,t_menuorder,p_usrgrp,'J2EM');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_',p_usrgrp,'Y','N',15);
    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_commdef_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_commset_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_commtier_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_commset_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_feedef_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_feeset_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_feedef_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_feeset_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_catruleus_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_catset_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_catruleus_l','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_settlacc_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_settlacc_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_cntr_cur_a','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_contract_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_contract_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_paycal_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_paycaly_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_paycal_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_catrule_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_catrule_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_cat_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_cat_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_unit_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_unit_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_unit_curr_a','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_setaccus_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_setaccus_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_manadj_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_manfee_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_fee_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_itembtch_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_item_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_memoit_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_pymt_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_stmtpymt_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_stmt_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_fee_v','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_itembtch_v','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_item_v','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_memoit_v','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_pymt_v','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_stmt_v','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_contrpos_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_pos_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_cont_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_cont_s','J2EF',' ',' ',' ',t_maxtag);

    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_commdef_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_commset_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_commtier_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_commset_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_feedef_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_feeset_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_feedef_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_feeset_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_catruleus_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_catset_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_catruleus_l',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_settlacc_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_settlacc_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_cntr_cur_a',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_contract_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_contract_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_paycal_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_paycaly_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_paycal_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_catrule_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_catrule_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_cat_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_cat_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_unit_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_unit_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_unit_curr_a',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_setaccus_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_setaccus_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_manadj_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_manfee_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_fee_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_itembtch_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_item_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_memoit_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_pymt_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_stmtpymt_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_stmt_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_fee_v',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_itembtch_v',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_item_v',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_memoit_v',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_pymt_v',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_stmt_v',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_contrpos_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_pos_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_cont_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_cont_s',p_usrgrp,'Y','N',15);


    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'mms_' and usrgrp = p_usrgrp;   

    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Contracts','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_contracts','J2EF',' ','wicket/mms/contracts',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('mms_','mms_contracts',t_maxtag,1,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_contracts',p_usrgrp,'Y','N',15);

    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Items','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_items','J2EF',' ','wicket/mms/items',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('mms_','mms_items',t_maxtag,3,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_items',p_usrgrp,'Y','N',15);

    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Item Batches','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_itembtchs','J2EF',' ','wicket/mms/itembatches',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('mms_','mms_itembtchs',t_maxtag,4,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_itembtchs',p_usrgrp,'Y','N',15);

    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Memo Items','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_memoitems','J2EF',' ','wicket/mms/memoitems',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('mms_','mms_memoitems',t_maxtag,5,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_memoitems',p_usrgrp,'Y','N',15);

    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Fees','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_fees','J2EF',' ','wicket/mms/fees',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('mms_','mms_fees',t_maxtag,6,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_fees',p_usrgrp,'Y','N',15);

    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Payments','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_payments','J2EF',' ','wicket/mms/payments',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('mms_','mms_payments',t_maxtag,7,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_payments',p_usrgrp,'Y','N',15);

    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Statements','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_statements','J2EF',' ','wicket/mms/statements',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('mms_','mms_statements',t_maxtag,8,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_statements',p_usrgrp,'Y','N',15);

    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Units','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_units','J2EF',' ','wicket/mms/units',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('mms_','mms_units',t_maxtag,9,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_units',p_usrgrp,'Y','N',15);

    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Definitions','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_def','J2EM',' ',' ',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('mms_','mms_def',t_maxtag,10,p_usrgrp,'J2EM');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_def',p_usrgrp,'Y','N',15);

    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Item Categories','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_itcats','J2EF',' ','wicket/mms/itemcategories',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('mms_def','mms_itcats',t_maxtag,1,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_itcats',p_usrgrp,'Y','N',15);

    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Item Category Rules','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_itcatrules','J2EF',' ','wicket/mms/itemcategorisationrules',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('mms_def','mms_itcatrules',t_maxtag,2,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_itcatrules',p_usrgrp,'Y','N',15);

    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Payment Calendars','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('mms_paymcals','J2EF',' ','wicket/mms/paymentcalendars',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('mms_def','mms_paymcals',t_maxtag,3,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('mms_paymcals',p_usrgrp,'Y','N',15);

end procedure;

execute procedure mms_menu('cortex');

drop procedure mms_menu;
