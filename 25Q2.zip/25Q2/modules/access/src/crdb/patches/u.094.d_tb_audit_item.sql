
select 'creating table AUDIT_ITEM' from systables where tabid = 1;

create table AUDIT_ITEM
(
	verno_ctx	integer		default 0	not null,
	id		serial		not null,
	object_id		integer	not null,
	activity_id		integer	not null,
	auditdatetime	DATETIME YEAR TO SECOND	not null,
	preactiondata	text	not null,
	postactiondata	text	not null,
	objecttype	smallint	not null,
	identifier1		integer	not null,
	identifier2		integer	not null,
	identifier3		integer	not null,
	identifier4		integer	not null
)
lock mode row;


