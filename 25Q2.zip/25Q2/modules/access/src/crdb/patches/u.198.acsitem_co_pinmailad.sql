UPDATE ACSITEM SET COMMAND = 'pinmailerdetailon.do' WHERE ACSITEM = 'co_pinmailad';
