ALTER TABLE usrgrp MODIFY
(
    descr      varchar(200,0) NOT NULL
);
