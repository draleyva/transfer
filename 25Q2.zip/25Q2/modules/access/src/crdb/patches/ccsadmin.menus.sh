:
#
# @(#) - u.002.ccsadmin.menus.sh - Korn shell script to
#       
#        install ccsadmin menu system

TMPFILE=/tmp/$$.access.ccsadmin.menu.infx.sql

acs_gen.infx data.002.CCSADMIN_ACSITEM data.002.CCSADMIN_DESCR data.002.CCSADMIN_MENU > $TMPFILE

dbaccess $DBNAME $TMPFILE

# if dbaccess exited ok, delete tmpfile
if [ $? -eq 0 ]; then
	echo "Install completed ok"
	rm $TMPFILE
else
	echo "Install of sql file [$TMPFILE] failed"
	echo "see file for details"
fi


