CREATE UNIQUE INDEX pk_entitytype
	ON  entity_type  (id) using btree;

create unique index hash_entitytype 
	on  entity_type (code, source_code) using btree;

alter table entity_type add constraint 
	unique (code, source_code) constraint hash_entitytype;

ALTER TABLE  entity_type  ADD CONSTRAINT 
	PRIMARY KEY (id) CONSTRAINT pk_entitytype ;