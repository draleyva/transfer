select 'creating table ENTITY_TYPE' from systables where tabid = 1;

create table ENTITY_TYPE 
(
	verno_ctx		integer	  default 1	 	not null,
    id serial 		not null, 
	code 			varchar(32, 0) 			not null,
	source_code		varchar(32, 0)			not null
)
lock mode row;
