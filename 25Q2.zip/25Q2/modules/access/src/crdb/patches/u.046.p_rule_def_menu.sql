create procedure rule_def_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag	   int;
define t_maxorder  int;
define t_menuorder int;
define i           int;


	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag
		from descr;
    
    
    let t_menuorder = 0;
    
           
    select max(morder) into t_menuorder from menu where mitem ='co_' and usrgrp=p_usrgrp;
    
    let t_menuorder = t_menuorder + 1;
    

    let t_maxtag = t_maxtag + 1;
    --RULE DEF
    
    insert into msc (verno_ctx, tag, idx, mscmodule, descr, mask, string_t, long_t, short_t, double_t, date_t) values (0, 'pregenref',0, 'ia', t_maxtag, 2,' ', 0,0,0,'2007-10-15');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_ruldf', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_ruldf', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_','co_ruldf',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    let t_maxtag = t_maxtag + 1;
    --Add RULE DEF
       
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Add', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_rule_ddd', 'J2EF', ' ', 'coruledefdetailon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_rule_ddd', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_ruldf','co_rule_ddd',t_maxtag,2,p_usrgrp,'J2EF');

    let t_maxtag = t_maxtag + 1;
    --Search RULE DEF
        
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Search', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_ruledsch', 'J2EF', ' ', 'coruledefsearchon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_ruledsch', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_ruldf','co_ruledsch',t_maxtag,1,p_usrgrp,'J2EF');


end procedure;

execute procedure rule_def_menu("cortex");

drop procedure rule_def_menu;
