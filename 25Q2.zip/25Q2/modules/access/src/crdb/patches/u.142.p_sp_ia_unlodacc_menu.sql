create procedure ia_unlodacc(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    like acsitem.descrtag;
define t_menuorder like menu.morder;

            ON EXCEPTION
            END EXCEPTION WITH RESUME;
    
    select max(descrtag) into t_maxtag from descr;
        
    let t_maxtag = t_maxtag + 1;
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Post Adjustments', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_unlodacc', 'J2EF', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_unlodacc', p_usrgrp, 'Y', 'N', '15');
    
end procedure;

execute procedure ia_unlodacc('cortex');

drop procedure ia_unlodacc;


