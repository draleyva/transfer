create procedure mancloba_button(p_usrgrp like usrgrp.usrgrp)
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values ('pa_mancloba','J2EF',' ',' ',' ',0);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values ('pa_mancloba',p_usrgrp,'Y','N',15);
end procedure;

execute procedure mancloba_button('cortex');

drop procedure mancloba_button;
