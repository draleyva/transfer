create procedure co_tokendet(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    like acsitem.descrtag;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Token Data','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_tokendet','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_tokendet',p_usrgrp,'Y','N',15);
    
end procedure;

execute procedure co_tokendet('cortex');

drop procedure co_tokendet;
