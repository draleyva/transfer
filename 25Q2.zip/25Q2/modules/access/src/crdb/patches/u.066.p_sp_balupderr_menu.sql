create procedure balupderr_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag		int;
define i int;


	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag
		from descr;
    

    let t_maxtag = t_maxtag + 1;
    --Search Online Balance Update exception log 
       
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Online Balance Update Exception Log', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_balerrsch', 'J2EF', ' ', 'iabalupderrsearchon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_balerrsch', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('au_accupdhis','ia_balerrsch',t_maxtag,2,p_usrgrp,'J2EF');

end procedure;

execute procedure balupderr_menu("cortex");

drop procedure balupderr_menu;

