select 'creating update trigger for ACTIVITY table' from systables where tabid = 1;

create trigger ACTIVITY_change update on ACTIVITY
referencing old as oldrec new as newrec
for each row
(
	execute procedure increment_int(newrec.verno_ctx) into verno_ctx
);

