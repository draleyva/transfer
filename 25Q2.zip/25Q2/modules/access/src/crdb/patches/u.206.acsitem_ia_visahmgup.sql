UPDATE ACSITEM SET COMMAND = 'visahostmgmtsearchon.do' WHERE ACSITEM = 'ia_visahmgup';
