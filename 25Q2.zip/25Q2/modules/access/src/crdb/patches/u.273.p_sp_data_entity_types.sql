create procedure fill_entity_type_keys

define t_entity_type_id    		like entity_type.id;
define t_entity_type_bk_id    	like entity_type_bk.id;

	ON EXCEPTION

	END EXCEPTION WITH RESUME;
	
    select max(id) into t_entity_type_id from ENTITY_TYPE;
	let t_entity_type_id = t_entity_type_id + 1;
	insert into ENTITY_TYPE(ID, CODE, SOURCE_CODE) VALUES (t_entity_type_id, 'Tlog', 'cxo');
	select max(id) into t_entity_type_bk_id from ENTITY_TYPE_BK;
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'pan', 1, t_entity_type_id);
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'seqno', 2, t_entity_type_id);
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'txnCode', 3, t_entity_type_id);
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'retrievalReferenceNumber', 4, t_entity_type_id);
	let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'fncode', 5, t_entity_type_id);
	
	
	let t_entity_type_id = t_entity_type_id + 1;
	insert into ENTITY_TYPE(ID, CODE, SOURCE_CODE) VALUES (t_entity_type_id, 'Card', 'cxo');
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'pan', 1, t_entity_type_id);
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'seqno', 2, t_entity_type_id);
		
	let t_entity_type_id = t_entity_type_id + 1;
	insert into ENTITY_TYPE(ID, CODE, SOURCE_CODE) VALUES (t_entity_type_id, 'Crdproduct', 'cxo');
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'crdproduct', 1, t_entity_type_id);

	let t_entity_type_id = t_entity_type_id + 1;
	insert into ENTITY_TYPE(ID, CODE, SOURCE_CODE) VALUES (t_entity_type_id, 'Acsitem', 'cxo');
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'acsitem', 1, t_entity_type_id);	

	let t_entity_type_id = t_entity_type_id + 1;
	insert into ENTITY_TYPE(ID, CODE, SOURCE_CODE) VALUES (t_entity_type_id, 'Source', 'mkc');
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'code', 1, t_entity_type_id);	

	let t_entity_type_id = t_entity_type_id + 1;
	insert into ENTITY_TYPE(ID, CODE, SOURCE_CODE) VALUES (t_entity_type_id, 'Customer', 'cx-branch');
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'custcode', 1, t_entity_type_id);	
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'instcode', 2, t_entity_type_id);	

	let t_entity_type_id = t_entity_type_id + 1;
	insert into ENTITY_TYPE(ID, CODE, SOURCE_CODE) VALUES (t_entity_type_id, 'Card', 'cx-branch');
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'pan', 1, t_entity_type_id);
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'seqno', 2, t_entity_type_id);
	
	let t_entity_type_id = t_entity_type_id + 1;
	insert into ENTITY_TYPE(ID, CODE, SOURCE_CODE) VALUES (t_entity_type_id, 'cat_isscycfee', 'cxo');
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'institutionCode', 1, t_entity_type_id);
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'category', 2, t_entity_type_id);
	
	let t_entity_type_id = t_entity_type_id + 1;
	insert into ENTITY_TYPE(ID, CODE, SOURCE_CODE) VALUES (t_entity_type_id, 'cat_issfee', 'cxo');
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'institutionCode', 1, t_entity_type_id);
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'category', 2, t_entity_type_id);
	
	let t_entity_type_id = t_entity_type_id + 1;
	insert into ENTITY_TYPE(ID, CODE, SOURCE_CODE) VALUES (t_entity_type_id, 'rule_dimension', 'cxo');
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'context', 1, t_entity_type_id);
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'dimension', 2, t_entity_type_id);
	
	let t_entity_type_id = t_entity_type_id + 1;
	insert into ENTITY_TYPE(ID, CODE, SOURCE_CODE) VALUES (t_entity_type_id, 'rule_rule', 'cxo');
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'context', 1, t_entity_type_id);
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'ruleName', 2, t_entity_type_id);

	update ACSITEM set AUDIT_SRC_CODE='cxo' where ACSITEM in ('rv_autdetdet', 'ia_crddlsdet', 'ia_crdreprint', 'ia_crdreissue', 'ia_replostud', 
	'ia_decpan', 'ia_crdpromde', 'ad_acsitedd', 'rule_sets', 'fc_ef_m', 'fc_cf_m', 'fc_f_cfc_m', 'fc_f_ifc_m', 'rule_rule_new', 'rule_rule_det', 'rv_manrevdet', 'acc_r_cn_m');
	
end procedure;

execute procedure fill_entity_type_keys();

drop procedure fill_entity_type_keys;	
