create procedure generic_lookup_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;

    -- Core > Generic LookUp
    let t_menuorder = 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'co_' and usrgrp = p_usrgrp;
    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Generic LookUp','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('generic_lookup','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('generic_lookup',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_','generic_lookup',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- Core > Generic LookUp > Search
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('lkptyp_sel','J2EF',' ','wicket/core/genericlookup',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('lkptyp_sel',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('generic_lookup','lkptyp_sel',t_maxtag,2,p_usrgrp,'J2EF');
    
    -- Core > Generic LookUp > Create
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Create','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('lkptyp_cr_ed','J2EF',' ','wicket/core/genericlookup?action=create',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('lkptyp_cr_ed',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('generic_lookup','lkptyp_cr_ed',t_maxtag,2,p_usrgrp,'J2EF');

    --Permissions
    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('lkpcat_sel','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('lkpcat_sel',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('lkpcat_cr_ed','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('lkpcat_cr_ed',p_usrgrp,'Y','N',15);

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('lkpdata_sel','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('lkpdata_sel',p_usrgrp,'Y','N',15);
	
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('lkpdata_cr_ed','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('lkpdata_cr_ed',p_usrgrp,'Y','N',15);
 
end procedure;

execute procedure generic_lookup_menu("cortex");

drop procedure generic_lookup_menu;
