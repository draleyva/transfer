delete from grpperm where acsitem in('rp_vib2otf','rp_vib2itf','ia_crdreqimp','rp_repdownl','ia_chgteldet','rp_saptxns','ia_chgtelsch','pa_meoddet','rp_mrchdep','rp_mrchstmt',
'rp_mrchstmt','rp_mrchpst','rp_mrchbal','pa_meomdet','rp_saferpt','pa_meoydet','ia_blktelcod','vi_expbtodet','rp_mrchstmtrp2');
delete from usrperm where acsitem in('rp_vib2otf','rp_vib2itf','ia_crdreqimp','rp_repdownl','ia_chgteldet','rp_saptxns','ia_chgtelsch','pa_meoddet','rp_mrchdep','rp_mrchstmt',
'rp_mrchstmt','rp_mrchpst','rp_mrchbal','pa_meomdet','rp_saferpt','pa_meoydet','ia_blktelcod','vi_expbtodet','rp_mrchstmtrp2');
delete from screenfield  where acsitem in('rp_vib2otf','rp_vib2itf','ia_crdreqimp','rp_repdownl','ia_chgteldet','rp_saptxns','ia_chgtelsch','pa_meoddet','rp_mrchdep','rp_mrchstmt',
'rp_mrchstmt','rp_mrchpst','rp_mrchbal','pa_meomdet','rp_saferpt','pa_meoydet','ia_blktelcod','vi_expbtodet','rp_mrchstmtrp2');
delete from menu   where acsitem in('rp_vib2otf','rp_vib2itf','ia_crdreqimp','rp_repdownl','ia_chgteldet','rp_saptxns','ia_chgtelsch','pa_meoddet','rp_mrchdep','rp_mrchstmt',
'rp_mrchstmt','rp_mrchpst','rp_mrchbal','pa_meomdet','rp_saferpt','pa_meoydet','ia_blktelcod','vi_expbtodet','rp_mrchstmtrp2');
delete from acsitem where acsitem in('rp_vib2otf','rp_vib2itf','ia_crdreqimp','rp_repdownl','ia_chgteldet','rp_saptxns','ia_chgtelsch','pa_meoddet','rp_mrchdep','rp_mrchstmt',
'rp_mrchstmt','rp_mrchpst','rp_mrchbal','pa_meomdet','rp_saferpt','pa_meoydet','ia_blktelcod','vi_expbtodet','rp_mrchstmtrp2');
