create procedure vpandet_menus(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;

    -- Issuer > Maintenance > Virtual Pan
    let t_menuorder = 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'ia_maint' and usrgrp = p_usrgrp;
    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Virtual Pan','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_vpan','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_vpan',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_maint','ia_vpan',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- Issuer > Maintenance > Virtual Pan > Search
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_vpansrc','J2EF',' ','iavpansearch.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_vpansrc',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_vpan','ia_vpansrc',t_maxtag,2,p_usrgrp,'J2EF');

end procedure;

execute procedure vpandet_menus("cortex");

drop procedure vpandet_menus;
