

select 'creating indexes for activity' from systables where tabid = 1;

create unique index pk_activity on
	activity (id);

alter table activity add constraint
	primary key (id) constraint pk_activity;

	
