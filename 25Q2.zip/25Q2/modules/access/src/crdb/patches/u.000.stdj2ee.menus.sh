:
#
# @(#) - u.010.stdj2ee.menus.sh - Korn shell script to
#       
#        install standard j2ee menus, taken from an unload of ING system

TMPFILE=/tmp/$$.access.stdj2ee.menu.infx.sql

acs_gen.infx data.008.STDJ2EEMENUS_ACSITEM data.008.STDJ2EEMENUS_DESCR data.008.STDJ2EEMENUS_MENU > $TMPFILE

dbaccess $DBNAME $TMPFILE

# if dbaccess exited ok, delete tmpfile
if [ $? -eq 0 ]; then
	echo "Install completed ok"
	rm $TMPFILE
else
	echo "Install of sql file [$TMPFILE] failed"
	echo "see file for details"
fi


