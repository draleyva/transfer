select 'creating trigger for entity_type_bk table' from systables where tabid = 1;


CREATE TRIGGER entity_type_bk_change UPDATE ON entity_type_bk
REFERENCING OLD AS old NEW AS new
FOR EACH ROW
(
	execute procedure increment_int(new.verno_ctx ) into verno_ctx
);


