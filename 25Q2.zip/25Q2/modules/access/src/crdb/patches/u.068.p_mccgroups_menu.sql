create procedure mccgroups_menus(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;

    -- Core > Misc. Maintenance > MCC Groups
    let t_menuorder = 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'co_miscmaint' and usrgrp = p_usrgrp;
    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'MCC Groups','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_mccgromn','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_mccgromn',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_miscmaint','co_mccgromn',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- Core > Misc. Maintenance > MCC Groups
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_mccgrodd','J2EF',' ','comccgroupsdetailon.do',' ',t_maxtag);
    update acsitem set command='comccgroupsdetailon.do', acstype='J2EF', descrtag=t_maxtag where acsitem='co_mccgrodd';
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_mccgrodd',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_mccgromn','co_mccgrodd',t_maxtag,1,p_usrgrp,'J2EF');

    -- Core > Misc. Maintenance > MCC Groups
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_mccgrosch','J2EF',' ','comccgroupssearchon.do',' ',t_maxtag);
    update acsitem set command='comccgroupssearchon.do', acstype='J2EF', descrtag=t_maxtag where acsitem='co_mccgrosch';
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_mccgrosch',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_mccgromn','co_mccgrosch',t_maxtag,2,p_usrgrp,'J2EF');

end procedure;

execute procedure mccgroups_menus("cortex");

drop procedure mccgroups_menus;
