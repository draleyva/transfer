

select 'creating indexes for audit_typedef' from systables where tabid = 1;

create unique index pk_audit_typedef on
	audit_typedef (id);

alter table audit_typedef add constraint 
	primary key (id) constraint pk_audit_typedef;

	