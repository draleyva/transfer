select 'creating table ENTITY_TYPE_BK' from systables where tabid = 1;

create table ENTITY_TYPE_BK 
(
	verno_ctx				integer	  default 1	 not null,
    id serial 									not null, 
	code 					varchar(32, 0) 		not null, 
	key_part_order			integer	  			not null,
	entity_type_id			integer	  			not null
)
lock mode row;
