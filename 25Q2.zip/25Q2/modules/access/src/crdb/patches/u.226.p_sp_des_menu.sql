create procedure des_menu(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;

    select max(descrtag) into t_maxtag from descr;    
    let t_maxtag = t_maxtag + 1;

    select nvl(max(morder),0) into t_menuorder from menu where mitem = p_usrgrp and usrgrp = p_usrgrp;   
    let t_menuorder = t_menuorder + 1;
    
    insert into descr(descrtag,descr,lang) values(t_maxtag,'DES','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('des_','J2EM',' ',' ',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values(p_usrgrp,'des_',t_maxtag,t_menuorder,p_usrgrp,'J2EM');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('des_',p_usrgrp,'Y','N',8);
    
end procedure;

execute procedure des_menu('cortex');

drop procedure des_menu;
