create procedure co_crdrtovrcxt(p_usrgrp like usrgrp.usrgrp) 

define t_maxtag    int;
define t_menuorder int;

         ON EXCEPTION
         END EXCEPTION WITH RESUME;
		 
    select max(descrtag) into t_maxtag from descr;    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_cro_p','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('cro_filternew','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_cro_h','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_cro_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('cro_filters','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('cro_sets','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_cro_cn','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('cro_viewfilters','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('cro_viewsets','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_cro_cn_c','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_cro_cn_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_cro_cns_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('cro_filter_cn_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('cro_set_cn_m','J2EF',' ',' ',' ',t_maxtag);

    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_cro_p',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('cro_filternew',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_cro_h',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_cro_m',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('cro_filters',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('cro_sets',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_cro_cn',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('cro_viewfilters',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('cro_viewsets',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_cro_cn_c',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_cro_cn_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_cro_cns_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('cro_filter_cn_m',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('cro_set_cn_m',p_usrgrp,'Y','N',15);


    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'co_' and usrgrp = p_usrgrp;   
    let t_menuorder = t_menuorder + 1;
    let t_maxtag = t_maxtag + 1;
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_crdrtovrcxt','J2EF',' ','wicket/card/routing/override',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_','co_crdrtovrcxt',t_maxtag,t_menuorder,p_usrgrp,'J2EF');
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Card Routing Override','EN');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_crdrtovrcxt',p_usrgrp,'Y','N',15);

end procedure;

execute procedure co_crdrtovrcxt('cortex');

drop procedure co_crdrtovrcxt;

