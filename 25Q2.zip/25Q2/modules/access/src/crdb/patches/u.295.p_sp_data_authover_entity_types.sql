create procedure fill_authover_entity_type_keys

	ON EXCEPTION

	END EXCEPTION WITH RESUME;

	update ACSITEM set AUDIT_SRC_CODE='cxo' where ACSITEM in ('ia_authovrrd');

end procedure;

execute procedure fill_authover_entity_type_keys();

drop procedure fill_authover_entity_type_keys;
