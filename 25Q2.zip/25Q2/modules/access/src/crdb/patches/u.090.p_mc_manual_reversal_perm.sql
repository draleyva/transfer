create procedure mc_manual_reversal_perm(p_usrgrp like usrgrp.usrgrp)

define t_maxtag    int;
define t_menuorder int;

	ON EXCEPTION
	END EXCEPTION WITH RESUME;
	
    select max(descrtag) into t_maxtag from descr;    
    let t_maxtag = t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add Mastercard Manual Reversal','EN');

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values ('mc_icmnrvdet','J2EF',' ',' ',' ',t_maxtag);

    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values ('mc_icmnrvdet',p_usrgrp,'Y','N',15);

end procedure;

execute procedure mc_manual_reversal_perm('cortex');

drop procedure mc_manual_reversal_perm;
