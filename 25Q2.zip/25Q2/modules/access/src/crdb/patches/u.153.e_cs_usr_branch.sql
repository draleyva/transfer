-- pk key and constraint from d_tb_usr_branch.sql

create unique index pk_usr_branch
	on  usr_branch  (id) ;

alter table  usr_branch  add constraint 
	primary key (id) constraint pk_usr_branch ;

