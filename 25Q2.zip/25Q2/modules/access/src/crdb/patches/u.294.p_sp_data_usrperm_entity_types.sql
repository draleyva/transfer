create procedure fill_usrperm_entity_type_keys()

define t_entity_type_id          like entity_type.id;
define t_entity_type_bk_id       like entity_type_bk.id;

	ON EXCEPTION

	END EXCEPTION WITH RESUME;

	select max(id) into t_entity_type_id from ENTITY_TYPE;
	let t_entity_type_id = t_entity_type_id + 1;
	insert into ENTITY_TYPE(ID, CODE, SOURCE_CODE) VALUES (t_entity_type_id, 'usrperm', 'cxo');
	select max(id) into t_entity_type_bk_id from ENTITY_TYPE_BK;
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'user', 1, t_entity_type_id);
    let t_entity_type_bk_id = t_entity_type_bk_id + 1;
	insert into entity_type_bk(id, code, key_part_order, entity_type_id) values (t_entity_type_bk_id, 'acsitem', 2, t_entity_type_id);

	update ACSITEM set AUDIT_SRC_CODE='cxo' where ACSITEM in ('ad_usrperdd');

end procedure;

execute procedure fill_usrperm_entity_type_keys();

drop procedure fill_usrperm_entity_type_keys();
