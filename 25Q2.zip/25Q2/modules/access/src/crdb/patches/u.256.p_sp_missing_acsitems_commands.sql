create procedure missing_acsitems_commands()

	ON EXCEPTION

	END EXCEPTION WITH RESUME;

	update acsitem set command='iacardlimitdetailon.do' where acsitem='ia_crdlmdd';
	update acsitem set command='iaajaxdecryptpanon.do' where acsitem='ia_decpan';
	update acsitem set command='iacardactivationstatusupdateon.do' where acsitem='ia_crdactiupd';
	update acsitem set command='iacrdaccdetailon.do' where acsitem='ia_crdaccd';

end procedure;

execute procedure missing_acsitems_commands();

drop procedure missing_acsitems_commands;
