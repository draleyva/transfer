create or replace procedure pandecryption_button(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);

begin
    select max(descrtag) into t_maxtag from descr;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Access to Decrypt Pan button','EN');

    begin
        insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values ('ia_decpan','J2EF',' ',' ',' ',t_maxtag);
    exception
      when OTHERS then
        NULL;
    end;
    begin
        insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values ('ia_decpan',p_usrgrp,'Y','N',15);
    exception
      when OTHERS then
        NULL;
    end;
end;
.
/

call pandecryption_button('cortex');

drop procedure pandecryption_button;
