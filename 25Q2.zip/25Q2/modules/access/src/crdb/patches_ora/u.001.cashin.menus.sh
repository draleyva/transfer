:
#
# @(#) - u.001.cashin.menus.sh - Korn shell script to
#       
#        install cashin menu system

TMPFILE=/tmp/$$.access.cashin.menu.ora.sql

acs_gen.ora data.001.CASHIN_ACSITEM data.001.CASHIN_DESCR data.001.CASHIN_MENU > $TMPFILE

sqlplus $DBNAME < $TMPFILE

# if sqlplus exited ok, delete tmpfile
if [ $? -eq 0 ]; then
	echo "Install completed ok"
	rm $TMPFILE
else
	echo "Install of sql file [$TMPFILE] failed"
	echo "see file for details"
fi


