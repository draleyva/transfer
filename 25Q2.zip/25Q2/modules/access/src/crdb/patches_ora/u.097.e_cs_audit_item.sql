
create unique index pk_audit_item on
	audit_item (id);

alter table audit_item add constraint pk_audit_item
	primary key (id);

	
