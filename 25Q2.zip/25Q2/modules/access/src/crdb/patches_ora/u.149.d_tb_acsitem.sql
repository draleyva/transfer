
alter table acsitem modify (id      number(10,0) not null);

