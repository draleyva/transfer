alter table acsitem modify (acsitem varchar2(15))
/

alter table menu modify (mitem varchar2(15))
/

alter table menu modify (acsitem varchar2(15))
/

alter table grpperm modify (acsitem varchar2(15))
/

alter table usrperm modify (acsitem varchar2(15))
/
