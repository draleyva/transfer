
create or replace trigger usr_insert before insert

on usr

referencing new as new

for each row

begin

	if (:new.id is null or :new.id = 0) then

		select usr_sequence.nextval into :new.id from dual;

	end if;

end;



/

