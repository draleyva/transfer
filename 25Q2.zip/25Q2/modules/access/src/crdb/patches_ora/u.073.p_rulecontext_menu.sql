create or replace procedure rulecontext_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);
t_menuorder	number(10,0);

begin

    select max(descrtag) into t_maxtag from descr;

    -- Core > Rule Context
    t_menuorder := 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'co_' and usrgrp = p_usrgrp;
    t_menuorder := t_menuorder + 1;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Rule Context','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rulectx','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rulectx',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_','rulectx',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- Core > Rule Context > Search
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_ctxtsel','J2EF',' ','wicket/rules/context',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_ctxtsel',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('rulectx','rule_ctxtsel',t_maxtag,2,p_usrgrp,'J2EF');

    -- Core > Rule Atom 
    t_menuorder := t_menuorder + 1;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Rule Atom','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ruleatom','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ruleatom',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_','ruleatom',t_maxtag,t_menuorder,p_usrgrp,'J2EM');
    
    -- Core > Rule Atom > Search
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_atom_sel','J2EF',' ','wicket/rules/atom',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_atom_sel',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ruleatom','rule_atom_sel',t_maxtag,2,p_usrgrp,'J2EF');

    -- Core > Rule Atom > Create
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Create','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_atom_new','J2EF',' ','wicket/rules/atom?action=create',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_atom_new',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ruleatom','rule_atom_new',t_maxtag,2,p_usrgrp,'J2EF');
    
    --Permissions
    
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_accv','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_accv',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_acinstsel','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_acinstsel',p_usrgrp,'Y','N',15);

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_atom_det','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_atom_det',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_batom_sel','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_batom_sel',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_ctxout_m','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_ctxout_m',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_ctxtapl','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_ctxtapl',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_ctxtdet','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_ctxtdet',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_dimval_det','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_dimval_det',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_dimval_new','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_dimval_new',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_evlstp_det','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_evlstp_det',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_evlstp_new','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_evlstp_new',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_instctx','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_instctx',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_instctxdet','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_instctxdet',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_instcxtout','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_instcxtout',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_instdim','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_instdim',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_instdimdet','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_instdimdet',p_usrgrp,'Y','N',15);

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_outstp_det','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_outstp_det',p_usrgrp,'Y','N',15);

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_outstp_new','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_outstp_new',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_rule_det','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_rule_det',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_rule_new','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_rule_new',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_rules','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_rules',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rule_rule_sel','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rule_rule_sel',p_usrgrp,'Y','N',15);
    
end;
.
/

call rulecontext_menu('cortex');

drop procedure rulecontext_menu;
