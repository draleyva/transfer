-----------------------------------------------------------------------------
--*
--* this script does the following :
--*
--*	* update all usr.extusr values from usr.usr column
--*
-----------------------------------------------------------------------------

declare
	c_cnt number(10,0);
	c_extusr	usr.extusr%type;
	comfreq number(10,0) := 4000;
begin
	for cur_rec in (select rowid from usr where extusr = '' or extusr is null) loop
		begin
			select usr into c_extusr from usr 
			where rowid = cur_rec.rowid;
			
			c_cnt := c_cnt + 1;
			update usr set extusr = c_extusr
			where rowid = cur_rec.rowid;
			-- commit for commit frequency
			if mod(c_cnt, comfreq) = 0 then
				commit;
			end if;
		exception
			when others then
				rollback;
		end;
	end loop;
end;
/

exit;
/



