
create table AUDIT_TYPEDEF 
(	
    id number(10,0) not null, 
	objecttype_id number(10,0) not null, 
	identifier1key varchar2(255), 
	identifier2key varchar2(255), 
	identifier3key varchar2(255), 
	identifier4key varchar2(255), 
	identifier1label varchar2(255), 
	identifier2label varchar2(255), 
	identifier3label varchar2(255), 
	identifier4label varchar2(255),
	idlabel varchar2(255)
);