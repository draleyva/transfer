create or replace procedure binrangedet_perm(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);

begin

    select max(descrtag) into t_maxtag from descr;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_binrangedet','J2EF',' ','iabinrangedetails.do',' ',t_maxtag);

    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_binrangedet',p_usrgrp,'Y','N',15);

end;
.
/

call binrangedet_perm('cortex');

drop procedure binrangedet_perm;
