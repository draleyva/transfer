
create or replace trigger usrgrp_insert before insert

on usrgrp

referencing new as new

for each row

begin

	if (:new.id is null or :new.id = 0) then

		select usrgrp_sequence.nextval into :new.id from dual;

	end if;

end;



/

