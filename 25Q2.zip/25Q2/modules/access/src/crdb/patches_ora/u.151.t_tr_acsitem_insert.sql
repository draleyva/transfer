
create or replace trigger acsitem_insert before insert

on acsitem

referencing new as new

for each row

begin

	if (:new.id is null or :new.id = 0) then

		select acsitem_sequence.nextval into :new.id from dual;

	end if;

end;



/

