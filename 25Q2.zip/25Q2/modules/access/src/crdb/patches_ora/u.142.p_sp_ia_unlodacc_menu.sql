create or replace procedure ia_unlodacc(p_usrgrp  usrgrp.usrgrp%type) is

t_maxtag	acsitem.descrtag%type;
t_menuorder	menu.morder%type;

begin
    SELECT MAX(DESCRTAG) INTO T_MAXTAG FROM DESCR;
    t_maxtag := t_maxtag + 1;
    
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Post Adjustments','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_unlodacc','J2EF',' ',' ',' ',t_maxtag);    
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_unlodacc',p_usrgrp,'Y','N',15);
    
end;
/

call ia_unlodacc('cortex');

drop procedure ia_unlodacc;

