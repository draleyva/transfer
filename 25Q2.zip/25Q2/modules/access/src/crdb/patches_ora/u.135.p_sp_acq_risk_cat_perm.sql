create or replace procedure acq_risk_cat_perm(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);

begin
    select max(descrtag) into t_maxtag from descr;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('acq_s_r_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('acq_r_irc_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('acq_r_cat_s','J2EF',' ',' ',' ',t_maxtag);

    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('acq_s_r_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('acq_r_irc_m',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('acq_r_cat_s',p_usrgrp,'Y','N',15);


end;
.
/

call acq_risk_cat_perm('cortex');

drop procedure acq_risk_cat_perm;
