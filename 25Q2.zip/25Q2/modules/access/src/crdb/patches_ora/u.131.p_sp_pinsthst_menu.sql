create or replace procedure pinstatuschangehistory_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag 	number(10,0);

begin 

    select max(descrtag) into t_maxtag from descr;
        
    t_maxtag := t_maxtag + 1;
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Pin Status Change History', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_pindhstsr', 'J2EF', ' ', 'pinstatchghistsearch.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_pindhstsr', p_usrgrp, 'Y', 'N', '15');

end;
.
/
CALL pinstatuschangehistory_menu('cortex');

DROP PROCEDURE pinstatuschangehistory_menu;