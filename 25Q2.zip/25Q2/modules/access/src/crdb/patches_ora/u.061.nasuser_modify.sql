alter table nasuser
add
(
	lstlogtime	number(10,0)	default 0	not null,
	unslogdate	date		default sysdate	not null,
	unslogtime	number(10,0)	default 0	not null
)
/
