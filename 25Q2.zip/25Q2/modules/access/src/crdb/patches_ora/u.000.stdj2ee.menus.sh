:
#
# @(#) - u.010.stdj2ee.menus.sh - Korn shell script to
#       
#        install standard j2ee menus, taken from an unload of ING system

TMPFILE=/tmp/$$.access.stdj2ee.menu.ora.sql

acs_gen.ora data.008.STDJ2EEMENUS_ACSITEM data.008.STDJ2EEMENUS_DESCR data.008.STDJ2EEMENUS_MENU > $TMPFILE

sqlplus $DBNAME < $TMPFILE

# if sqlplus exited ok, delete tmpfile
if [ $? -eq 0 ]; then
	echo "Install completed ok"
	rm $TMPFILE
else
	echo "Install of sql file [$TMPFILE] failed"
	echo "see file for details"
fi


