create or replace procedure rule_group_perm(p_usrgrp usrgrp.usrgrp%type) is
    
t_maxtag 	number(10,0);
i 		number(10,0);

begin

    select max(descrtag) into t_maxtag from descr;
		
    t_maxtag := t_maxtag + 1;
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Search', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_rulegsch', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_rulegsch', p_usrgrp, 'Y', 'N', '15');
    
    t_maxtag := t_maxtag + 1;
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Add', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_rule_gdd', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_rule_gdd', p_usrgrp, 'Y', 'N', '15');

end;
.
/

CALL rule_group_perm('cortex');

DROP PROCEDURE rule_group_perm;
