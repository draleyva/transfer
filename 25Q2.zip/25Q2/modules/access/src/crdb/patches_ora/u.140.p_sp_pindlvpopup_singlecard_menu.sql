create or replace procedure pindlvmthsinglecard_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag 	number(10,0);

begin 

    select max(descrtag) into t_maxtag from descr;
        
    t_maxtag := t_maxtag + 1;
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Pin Delivery Method Update Single Card', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_zmpindlmthsc', 'J2EF', ' ', 'iazoompindeliverymethodsinglecardon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_zmpindlmthsc', p_usrgrp, 'Y', 'N', '15');

end;
.
/
CALL pindlvmthsinglecard_menu('cortex');

DROP PROCEDURE pindlvmthsinglecard_menu;

