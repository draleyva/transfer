
create or replace trigger AUDIT_ITEM_change before update on AUDIT_ITEM
referencing old as oldrec new as newrec
for each row
begin
	:newrec.verno_ctx := :oldrec.verno_ctx + 1;
end;
/

