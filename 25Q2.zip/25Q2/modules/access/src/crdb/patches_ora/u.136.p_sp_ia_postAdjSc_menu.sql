create or replace procedure ia_postAdjSc(p_usrgrp  usrgrp.usrgrp%type) is

t_maxtag	acsitem.descrtag%type;
t_menuorder	menu.morder%type;

begin
    SELECT MAX(DESCRTAG) INTO T_MAXTAG FROM DESCR;
    t_maxtag := t_maxtag + 1;
    
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Post Adjustments','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_postAdjSc','J2EF',' ',' ',' ',t_maxtag);    
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_postAdjSc',p_usrgrp,'Y','N',15);
    
end;
/

call ia_postAdjSc('cortex');

drop procedure ia_postAdjSc;