create or replace procedure authcheck_menu() is

begin 

    update menu set mitem='au_maint' where acsitem='ia_authchmnu' or acsitem='ia_authcomnu';
    update descr set descr='Authorisation Checks' where descrtag in (select descrtag from menu where mitem='au_maint' and acsitem='ia_authchmnu');
    update descr set descr='Authorisation Conditions' where descrtag in (select descrtag from menu where mitem='au_maint' and acsitem='ia_authcomnu');

end;
.
/

CALL authcheck_menu();

DROP PROCEDURE authcheck_menu;
