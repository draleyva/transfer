create or replace procedure pregenpinbtch_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag 	number(10,0);
t_maxorder  	number(10,0);
t_menuorder 	number(10,0);
i 		number(10,0);

begin 

    select max(descrtag) into t_maxtag from descr;
    
    t_menuorder := 0;
           
    select max(morder) into t_menuorder from menu where mitem ='ia_crdprod' and usrgrp=p_usrgrp;
    
    t_menuorder := t_menuorder + 1;
 
    t_maxtag := t_maxtag + 1;
   --PREGENPIN BATCH DEF
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Pregenerated Pin Batch', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_prpinbtch', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_prpinbtch', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_crdprod','ia_prpinbtch',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

   t_maxtag := t_maxtag + 1;
    --Add PREGENPIN BATCH 
       
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Add', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_prgbthadd', 'J2EF', ' ', 'iapregenpinbatchon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_prgbthadd', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_prpinbtch','ia_prgbthadd',t_maxtag,2,p_usrgrp,'J2EF');


end;
.
/

CALL pregenpinbtch_menu('cortex');

DROP PROCEDURE pregenpinbtch_menu;
