alter table usrgrp add
(
    id      number(10,0)
);

create sequence usrgrp_sequence start with 1;
