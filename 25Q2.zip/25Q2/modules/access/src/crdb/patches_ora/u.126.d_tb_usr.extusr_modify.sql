
alter table usr modify
(
	extusr      varchar2(100 CHAR) not null
);