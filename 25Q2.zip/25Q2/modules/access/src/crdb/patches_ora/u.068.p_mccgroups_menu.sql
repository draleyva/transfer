create or replace procedure mccgroups_menus(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);
t_menuorder	number(10,0);

begin

    select max(descrtag) into t_maxtag from descr;

    -- Core > Misc. Maintenance > MCC Groups
    t_menuorder := 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'co_miscmaint' and usrgrp = p_usrgrp;
    t_menuorder := t_menuorder + 1;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'MCC Groups','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_mccgromn','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_mccgromn',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_miscmaint','co_mccgromn',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- Core > Misc. Maintenance > MCC Groups > Add
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    begin
        insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_mccgrodd','J2EF',' ','comccgroupsdetailon.do',' ',t_maxtag);
    exception
      when DUP_VAL_ON_INDEX then
        update acsitem set command='comccgroupsdetailon.do', acstype='J2EF', descrtag=t_maxtag where acsitem='co_mccgrodd';
      when OTHERS then
        NULL;
    end;
    begin
        insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_mccgrodd',p_usrgrp,'Y','N',15);
    exception
      when OTHERS then
        NULL;
    end;
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_mccgromn','co_mccgrodd',t_maxtag,1,p_usrgrp,'J2EF');

    -- Core > Misc. Maintenance > MCC Groups > Search
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    begin
        insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('co_mccgrosch','J2EF',' ','comccgroupssearchon.do',' ',t_maxtag);
    exception
      when DUP_VAL_ON_INDEX then
        update acsitem set command='comccgroupssearchon.do', acstype='J2EF', descrtag=t_maxtag where acsitem='co_mccgrosch';
      when OTHERS then
        NULL;
    end;
    begin
        insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('co_mccgrosch',p_usrgrp,'Y','N',15);
    exception
      when OTHERS then
        NULL;
    end;
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_mccgromn','co_mccgrosch',t_maxtag,2,p_usrgrp,'J2EF');

end;
.
/

call mccgroups_menus('cortex');

drop procedure mccgroups_menus;
