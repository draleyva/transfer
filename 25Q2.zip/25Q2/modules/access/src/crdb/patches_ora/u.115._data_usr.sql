-----------------------------------------------------------------------------
--*
--* this script does the following :
--*
--*	* update all usr.id values sequentially
--*
-----------------------------------------------------------------------------

declare
	c_cnt number(10,0);
	c_id	usr.id%type;
	comfreq number(10,0) := 4000;
begin
	for cur_rec in (select rowid from usr where id = 0 or id is null) loop
		begin
			select usr_sequence.nextval
			into c_id
			from dual;
			
			c_cnt := c_cnt + 1;
			update usr set id = c_id
			where rowid = cur_rec.rowid;
			-- commit for commit frequency
			if mod(c_cnt, comfreq) = 0 then
				commit;
			end if;
		exception
			when others then
				rollback;
		end;
	end loop;
end;
/

exit;
/



