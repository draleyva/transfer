
create unique index hash_usrgrp on  usrgrp (id);

alter table  usrgrp  add constraint hash_usrgrp unique (id);

