create or replace procedure party_item(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);

begin

	select max(descrtag) into t_maxtag from descr;

    -- Party Contact Mechanism
    
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_cr_e_m_el_pu','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_e_el_ad','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_e_el','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_cm_el_mn','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_mg_pu_el','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_cr_md_el_ad','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_cre_md_el_pu','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_e_md_elc','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_mg_md_el','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_md_cm_el_mn','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_cm_el_tb','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_cmb_tb_cm','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_cm_pst_tb','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_cm_tlc_tb','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_md_elc_tb','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_md_pst_tb','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_md_tlc_tb','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_cmb_md_tb','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_cre_tlc_pu','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_e_tlc','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_e_tlc_ad','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_mg_tlc','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_cm_tlc_mn','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_cr_md_tlc_ad','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_ce_md_tlc_pu','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_e_md_tlc','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_md_mg_tlc','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_md_cm_tlc_mn','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_ce_pst_pu','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_ad_pu','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_ed_cm','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_e_pst_ad','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_mg_pst','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_cm_pst_mn','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_cm','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_md_cr_pst_ad','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_md_ce_pst_pu','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_e_md_cm','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_md_mg_pst','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_md_cm_pst_mn','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('pr_media_cm','J2EF',' ',' ',' ',t_maxtag);
	
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_cr_e_m_el_pu',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_e_el_ad',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_e_el',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_cm_el_mn',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_mg_pu_el',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_cr_md_el_ad',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_cre_md_el_pu',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_e_md_elc',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_mg_md_el',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_md_cm_el_mn',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_cm_el_tb',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_cmb_tb_cm',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_cm_pst_tb',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_cm_tlc_tb',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_md_elc_tb',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_md_pst_tb',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_md_tlc_tb',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_cmb_md_tb',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_cre_tlc_pu',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_e_tlc',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_e_tlc_ad',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_mg_tlc',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_cm_tlc_mn',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_cr_md_tlc_ad',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_ce_md_tlc_pu',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_e_md_tlc',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_md_mg_tlc',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_md_cm_tlc_mn',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_ce_pst_pu',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_ad_pu',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_ed_cm',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_e_pst_ad',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_mg_pst',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_cm_pst_mn',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_cm',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_md_cr_pst_ad',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_md_ce_pst_pu',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_e_md_cm',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_md_mg_pst',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_md_cm_pst_mn',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('pr_media_cm',p_usrgrp,'Y','N',15);


end;
/

call party_item('cortex');

drop procedure party_item;
