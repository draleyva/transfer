create or replace procedure fbrules_menus(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);
t_menuorder	number(10,0);

begin

    select max(descrtag) into t_maxtag from descr;

    -- Fall-back settings
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Edit Fall-back settings','EN');
    begin
        insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_fbruledd','J2EF',' ',' ',' ',t_maxtag);
    exception
      when DUP_VAL_ON_INDEX then
        update acsitem set command=' ', acstype='J2EF', descrtag=t_maxtag where acsitem='ia_fbruledd';
      when OTHERS then
        NULL;
    end;
    begin
        insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_fbruledd',p_usrgrp,'Y','N',15);
    exception
      when OTHERS then
        NULL;
    end;

end;
.
/

call fbrules_menus('cortex');

drop procedure fbrules_menus;
