
prompt creating usr_branch table ...

create table usr_branch
( 
	id			number(10)		not null ,
	verno_ctx		number(10)		default 1	not null,
	user_id			number(10)		not null,
	branch_id		number(10)		not null
);

create sequence usr_branch_sequence start with 1;

