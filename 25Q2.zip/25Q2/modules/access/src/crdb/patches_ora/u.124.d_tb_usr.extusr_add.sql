alter table usr add
(
    extusr      varchar2(100 CHAR)
);

