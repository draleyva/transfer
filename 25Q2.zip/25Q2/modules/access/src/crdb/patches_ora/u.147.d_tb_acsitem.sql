alter table acsitem add
(
    id      number(10,0)
);

create sequence acsitem_sequence start with 1;
