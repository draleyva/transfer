
create unique index pk_activity on
	activity (id);

alter table activity add constraint pk_activity
	primary key (id);

	
