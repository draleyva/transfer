
create table AUDIT_ITEM
(
	verno_ctx	number(10,0)		default 0	not null,
	id		number(10,0)		not null,
	object_id		number(10,0)	not null,
	activity_id		number(10,0)	not null,
	auditdatetime	timestamp(6)	not null,
	preactiondata	clob	not null,
	postactiondata	clob	not null,
	objecttype	number(5)	not null,
	identifier1		number(10,0)	not null,
	identifier2		number(10,0)	not null,
	identifier3		number(10,0)	not null,
	identifier4		number(10,0)	not null
);

create sequence AUDIT_ITEM_SEQUENCE start with 1;

