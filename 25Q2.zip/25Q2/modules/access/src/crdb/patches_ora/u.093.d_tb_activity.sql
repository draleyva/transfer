
create table ACTIVITY 
(
	verno_ctx	number(10,0)		default 0	not null,
    id number(10,0) not null, 
	user_name varchar2(16) not null, 
	activitydatetime timestamp (6) not null, 
	activity_code varchar2(255) not null
);

create sequence ACTIVITY_SEQUENCE start with 1;
