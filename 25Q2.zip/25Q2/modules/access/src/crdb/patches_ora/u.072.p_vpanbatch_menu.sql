create or replace procedure vpanbatch_menus(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);
t_menuorder	number(10,0);

begin

    select max(descrtag) into t_maxtag from descr;

     -- Issuer > Maintenance > Virtual Pan Profile
    t_menuorder := 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'ia_maint' and usrgrp = p_usrgrp;
    t_menuorder := t_menuorder + 1;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Virtual Pan Batch','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_vpanbat','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_vpanbat',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_maint','ia_vpanbat',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- Issuer > Maintenance > Virtual Pan Profile> Search
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_vpanbatsrc','J2EF',' ','iavpanbatchsearch.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_vpanbatsrc',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_vpanbat','ia_vpanbatsrc',t_maxtag,2,p_usrgrp,'J2EF');

end;
.
/

call vpanbatch_menus('cortex');

drop procedure vpanbatch_menus;
