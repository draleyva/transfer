create or replace procedure acclog_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);
t_menuorder	number(10,0);

begin
	
    select max(descrtag) into t_maxtag from descr;
    
    t_menuorder := 0;
    
           
    select nvl(max(morder),0) into t_menuorder from menu where mitem ='au_' and usrgrp=p_usrgrp;
    t_menuorder := t_menuorder + 1;
    t_maxtag := t_maxtag + 1;
    
    --Account Update History
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Account Update History', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('au_accupdhis', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('au_accupdhis', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('au_','au_accupdhis',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    t_maxtag := t_maxtag + 1;
    --Search Account Update log 
       
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Account Update Log', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_acclogsch', 'J2EF', ' ', 'iaacclogsearchon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_acclogsch', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('au_accupdhis','ia_acclogsch',t_maxtag,2,p_usrgrp,'J2EF');

end;
.
/

CALL acclog_menu('cortex');

DROP PROCEDURE acclog_menu;
