:
#
# @(#) - u.002.ccsadmin.menus.sh - Korn shell script to
#       
#        install ccsadmin menu system

TMPFILE=/tmp/$$.access.ccsadmin.menu.ora.sql

acs_gen.ora data.002.CCSADMIN_ACSITEM data.002.CCSADMIN_DESCR data.002.CCSADMIN_MENU > $TMPFILE

sqlplus $DBNAME < $TMPFILE

# if sqlplus exited ok, delete tmpfile
if [ $? -eq 0 ]; then
	echo "Install completed ok"
	rm $TMPFILE
else
	echo "Install of sql file [$TMPFILE] failed"
	echo "see file for details"
fi


