create or replace procedure tmkencryption_wbservice_param(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);
t_menuorder	number(10,0);

begin

    select max(descrtag) into t_maxtag from descr;

    -- Fall-back settings
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Encryption - web service authentication','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ws_newtmk','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ws_newtmk',p_usrgrp,'Y','N',15);
end;

/
call tmkencryption_wbservice_param('cortex');

drop procedure tmkencryption_wbservice_param;