create or replace procedure vpanprofile_menus(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);
t_menuorder	number(10,0);

begin

    select max(descrtag) into t_maxtag from descr;

     -- Issuer > Maintenance > Virtual Pan Profile
    t_menuorder := 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'ia_maint' and usrgrp = p_usrgrp;
    t_menuorder := t_menuorder + 1;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Virtual Pan Profile','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_vpanpro','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_vpanpro',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_maint','ia_vpanpro',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- Core > Misc. Maintenance > Virtual Pan Profile> Search
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_vpanprosrc','J2EF',' ','iavpansearch.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_vpanprosrc',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_vpanpro','ia_vpanprosrc',t_maxtag,2,p_usrgrp,'J2EF');

    -- Issuer > Maintenance > Virtual Pan Profile> Add
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_vpanprodet','J2EF',' ','iavpanprofiledetails.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_vpanprodet',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_vpanpro','ia_vpanprodet',t_maxtag,2,p_usrgrp,'J2EF');
    
end;
.
/

call vpanprofile_menus('cortex');

drop procedure vpanprofile_menus;
