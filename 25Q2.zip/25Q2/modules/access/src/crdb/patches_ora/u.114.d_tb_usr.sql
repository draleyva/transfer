alter table usr add
(
    id      number(10,0)
);

create sequence usr_sequence start with 1;
