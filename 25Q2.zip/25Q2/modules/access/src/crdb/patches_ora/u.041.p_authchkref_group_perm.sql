create or replace procedure authchkref_group_perm(p_usrgrp usrgrp.usrgrp%type) is
    
t_maxtag 	number(10,0);
i 		number(10,0);

begin

    select max(descrtag) into t_maxtag from descr;
		
    t_maxtag := t_maxtag + 1;
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Search', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_auchrefsh', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_auchrefsh', p_usrgrp, 'Y', 'N', '15');
    
    t_maxtag := t_maxtag + 1;
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Add', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_auchrefdd', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_auchrefdd', p_usrgrp, 'Y', 'N', '15');

end;
.
/

CALL authchkref_group_perm('cortex');

DROP PROCEDURE authchkref_group_perm;
