create or replace procedure forex_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag 	number(10,0);
t_maxorder  	number(10,0);
t_menuorder 	number(10,0);
i 		number(10,0);

begin 

    select max(descrtag) into t_maxtag from descr;
    
    
    t_menuorder := 0;
    
           
    select max(morder) into t_menuorder from menu where mitem ='co_' and usrgrp=p_usrgrp;
    
    t_menuorder := t_menuorder + 1;
 
    t_maxtag := t_maxtag + 1;
    
    --Forex
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Forex', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_forex', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_forex', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_','co_forex',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    t_maxtag := t_maxtag + 1;
    --Add Forex 
       
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Add', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_forexdd', 'J2EF', ' ', 'coforexdetailon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_forexdd', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_forex','co_forexdd',t_maxtag,2,p_usrgrp,'J2EF');
   
   t_maxtag := t_maxtag + 1;
    --Search Forex
        
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Search', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_forexsch', 'J2EF', ' ', 'coforexsearchon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_forexsch', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_forex','co_forexsch',t_maxtag,1,p_usrgrp,'J2EF');


end;
.
/

CALL forex_menu('cortex');

DROP PROCEDURE forex_menu;