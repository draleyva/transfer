
create unique index hash_acsitem on  acsitem (id);

alter table  acsitem  add constraint hash_acsitem unique (id);

