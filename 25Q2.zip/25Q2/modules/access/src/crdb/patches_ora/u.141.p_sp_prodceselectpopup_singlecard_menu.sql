create or replace procedure prodselpopupsinlcard_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag 	number(10,0);

begin 

    select max(descrtag) into t_maxtag from descr;
        
    t_maxtag := t_maxtag + 1;
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Produce Selection Pop Up Single Card', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_zmprdcslctsc', 'J2EF', ' ', 'iazoomproduceselectionsinglecardon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_zmprdcslctsc', p_usrgrp, 'Y', 'N', '15');

end;
.
/
CALL prodselpopupsinlcard_menu('cortex');

DROP PROCEDURE prodselpopupsinlcard_menu;

