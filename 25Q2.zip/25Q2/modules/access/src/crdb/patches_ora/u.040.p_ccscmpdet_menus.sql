create or replace procedure ccscmpdet_menus(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);
t_menuorder	number(10,0);

begin

    select max(descrtag) into t_maxtag from descr;

    -- CreditCard > Configuration > Component Details
    t_menuorder := 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'ccs_conf' and usrgrp = p_usrgrp;
    t_menuorder := t_menuorder + 1;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Component Details','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ccs_cmpdetmn','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ccs_cmpdetmn',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ccs_conf','ccs_cmpdetmn',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- CreditCard > Configuration > Component Details > Add
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    begin
        insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ccs_cmpdeta','J2EF',' ','ccs/ccsccscmpdetdetailon.do',' ',t_maxtag);
    exception
      when DUP_VAL_ON_INDEX then
        update acsitem set command='ccs/ccsccscmpdetdetailon.do', acstype='J2EF', descrtag=t_maxtag where acsitem='ccs_cmpdeta';
      when OTHERS then
        NULL;
    end;
    begin
        insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ccs_cmpdeta',p_usrgrp,'Y','N',15);
    exception
      when OTHERS then
        NULL;
    end;
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ccs_cmpdetmn','ccs_cmpdeta',t_maxtag,1,p_usrgrp,'J2EF');

    -- CreditCard > Configuration > Component Details > Search
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    begin
        insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ccs_cmpdets','J2EF',' ','ccs/ccsccscmpdetsearchon.do',' ',t_maxtag);
    exception
      when DUP_VAL_ON_INDEX then
        update acsitem set command='ccs/ccsccscmpdetsearchon.do', acstype='J2EF', descrtag=t_maxtag where acsitem='ccs_cmpdets';
      when OTHERS then
        NULL;
    end;
    begin
        insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ccs_cmpdets',p_usrgrp,'Y','N',15);
    exception
      when OTHERS then
        NULL;
    end;
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ccs_cmpdetmn','ccs_cmpdets',t_maxtag,2,p_usrgrp,'J2EF');

end;

call ccscmpdet_menus('cortex');

drop procedure ccscmpdet_menus;
