create or replace procedure numdescr_data(p_lang numdescr.lang%type) is

begin
	insert into numdescr (verno_ctx, lang, descrtype, id, descr)
	values(0, p_lang, 'tx', '96',  'VERIFICATION');

end;
/

call numdescr_data('EN');
call numdescr_data('GB');

drop procedure numdescr_data;
