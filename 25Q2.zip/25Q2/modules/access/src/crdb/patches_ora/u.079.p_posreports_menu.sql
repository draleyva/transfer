create or replace procedure posreports_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);
t_menuorder	number(10,0);

begin
    select max(descrtag) into t_maxtag from descr;
    t_menuorder := 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'pa_reports' and usrgrp = p_usrgrp;

    -- POS > Reports > POS Manually Closed Batches Report
    t_menuorder := t_menuorder + 1;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'POS Manually Closed Batches Report','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rp_posmancl','J2EF',' ','rpposmanclosreporton.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rp_posmancl',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('pa_reports','rp_posmancl',t_maxtag,t_menuorder,p_usrgrp,'J2EF');

    -- POS > Reports > POS Open Batches Report
    t_menuorder := t_menuorder + 1;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'POS Open Batches Report','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rp_posopenb','J2EF',' ','rpposopenbtchreporton.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rp_posopenb',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('pa_reports','rp_posopenb',t_maxtag,t_menuorder,p_usrgrp,'J2EF');

end;
.
/

call posreports_menu('cortex');

drop procedure posreports_menu;
