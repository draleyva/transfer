-- Insert trigger for AUDIT_ITEM

create or replace trigger AUDIT_ITEM_INSERT before insert on AUDIT_ITEM
referencing new as newrec
for each row
begin
	if ( :newrec.id is NULL or :newrec.id = 0 ) then
		select AUDIT_ITEM_SEQUENCE.NEXTVAL into :newrec.id from dual;
	end if;
end;
/