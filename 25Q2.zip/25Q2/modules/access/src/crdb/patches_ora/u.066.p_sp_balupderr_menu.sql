create or replace procedure balupderr_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag        number(10,0);
t_menuorder     number(10,0);

begin 
    select max(descrtag) into t_maxtag from descr;  
    
    t_menuorder := 0;
    
    select max(morder) into t_menuorder from menu where mitem ='au_' and usrgrp=p_usrgrp;
    
    t_menuorder := t_menuorder + 1;
 
    t_maxtag := t_maxtag + 1;

    --Search Online Balance Update exception log 
       
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Online Balance Update Exception Log', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_balerrsch', 'J2EF', ' ', 'iabalupderrsearchon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_balerrsch', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('au_accupdhis','ia_balerrsch',t_maxtag,2,p_usrgrp,'J2EF');

end;
.
/

CALL balupderr_menu('cortex');

DROP PROCEDURE balupderr_menu;

