create or replace procedure issuer_risk_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);
t_menuorder	number(10,0);

begin
    select max(descrtag) into t_maxtag from descr;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_r_cn_c','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_r_cn_c1','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_r_cn_e','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_riskhome','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_r_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_r_irc_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_r_cn_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_r_th_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_r_tos_m','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_r_cat_s','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_risk_th_c','J2EF',' ',' ',' ',t_maxtag);
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_risk_th_e','J2EF',' ',' ',' ',t_maxtag);

    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_r_cn_c',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_r_cn_c1',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_r_cn_e',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_riskhome',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_r_m',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_r_irc_m',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_r_cn_m',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_r_th_m',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_r_tos_m',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_r_cat_s',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_risk_th_c',p_usrgrp,'Y','N',15);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_risk_th_e',p_usrgrp,'Y','N',15);

    t_menuorder := 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'ia_' and usrgrp = p_usrgrp;
    t_menuorder := t_menuorder + 1;
    t_maxtag := t_maxtag + 1;
    
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Issuer Risk','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('iss_risk','J2EF',' ','wicket/issuer/risk',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_','iss_risk',t_maxtag,2,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('iss_risk',p_usrgrp,'Y','N',15);
    
end;
.
/

call issuer_risk_menu('cortex');

drop procedure issuer_risk_menu;
