
alter table usr modify (id      number(10,0) not null);