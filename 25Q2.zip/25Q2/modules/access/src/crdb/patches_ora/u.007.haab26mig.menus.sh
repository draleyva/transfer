:
#
# @(#) - u.007.haab26mig.menus.sh - Korn shell script to
#       
#        install branch charge report, card limits screen and card product limits screen

TMPFILE=/tmp/$$.access.haab26mig.menu.ora.sql

acs_gen.ora data.007.HAAB26MIG_ACSITEM data.007.HAAB26MIG_DESCR data.007.HAAB26MIG_MENU > $TMPFILE

sqlplus $DBNAME < $TMPFILE

# if sqlplus exited ok, delete tmpfile
if [ $? -eq 0 ]; then
	echo "Install completed ok"
	rm $TMPFILE
else
	echo "Install of sql file [$TMPFILE] failed"
	echo "see file for details"
fi


