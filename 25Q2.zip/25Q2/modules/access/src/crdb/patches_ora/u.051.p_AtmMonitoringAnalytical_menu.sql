create or replace procedure report_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag 	number(10,0);
t_maxorder  	number(10,0);
t_menuorder 	number(10,0);
i 		number(10,0);

begin 

    select max(descrtag) into t_maxtag from descr;
 
    t_maxtag := t_maxtag + 1;
    
    --Add Queue Definition 
        
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'ATM Monitoring Analytical', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('rp_atmstu', 'J2EF', ' ', 'rpatmstureporton.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('rp_atmstu', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('aa_reports','rp_atmstu',t_maxtag,1,p_usrgrp,'J2EF');


end;
.
/
CALL report_menu('cortex');

DROP PROCEDURE report_menu;
