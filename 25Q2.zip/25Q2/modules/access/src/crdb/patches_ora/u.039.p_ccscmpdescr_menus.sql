create or replace procedure ccscmpdescr_menus(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);
t_menuorder	number(10,0);

begin

    select max(descrtag) into t_maxtag from descr;

    -- CreditCard > Configuration > Component Descriptions
    t_menuorder := 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'ccs_conf' and usrgrp = p_usrgrp;
    t_menuorder := t_menuorder + 1;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Component Descriptions','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ccs_cmpdscmn','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ccs_cmpdscmn',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ccs_conf','ccs_cmpdscmn',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- CreditCard > Configuration > Component Descriptions > Add
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    begin
        insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ccs_cmpdscra','J2EF',' ','ccs/ccsccscmpdescrdetailon.do',' ',t_maxtag);
    exception
      when DUP_VAL_ON_INDEX then
        update acsitem set command='ccs/ccsccscmpdescrdetailon.do', acstype='J2EF', descrtag=t_maxtag where acsitem='ccs_cmpdscra';
      when OTHERS then
        NULL;
    end;
    begin
        insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ccs_cmpdscra',p_usrgrp,'Y','N',15);
    exception
      when OTHERS then
        NULL;
    end;
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ccs_cmpdscmn','ccs_cmpdscra',t_maxtag,1,p_usrgrp,'J2EF');

    -- CreditCard > Configuration > Component Descriptions > Search
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    begin
        insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ccs_cmpdscrs','J2EF',' ','ccs/ccsccscmpdescrsearchon.do',' ',t_maxtag);
    exception
      when DUP_VAL_ON_INDEX then
        update acsitem set command='ccs/ccsccscmpdescrsearchon.do', acstype='J2EF', descrtag=t_maxtag where acsitem='ccs_cmpdscrs';
      when OTHERS then
        NULL;
    end;
    begin
        insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ccs_cmpdscrs',p_usrgrp,'Y','N',15);
    exception
      when OTHERS then
        NULL;
    end;
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ccs_cmpdscmn','ccs_cmpdscrs',t_maxtag,2,p_usrgrp,'J2EF');

end;

call ccscmpdescr_menus('cortex');

drop procedure ccscmpdescr_menus;
