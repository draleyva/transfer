
create unique index unq_usr_extusr on  usr (extusr);

alter table  usr  add constraint unq_usr_extusr unique (extusr);

