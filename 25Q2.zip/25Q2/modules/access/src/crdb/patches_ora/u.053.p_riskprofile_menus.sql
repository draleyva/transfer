create or replace procedure riskprofile_menus(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);
t_menuorder	number(10,0);

begin

    select max(descrtag) into t_maxtag from descr;

    -- Issuer > Maintenance > Risk Profile
    t_menuorder := 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'ia_maint' and usrgrp = p_usrgrp;
    t_menuorder := t_menuorder + 1;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Risk Profile','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_riskprmn','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_riskprmn',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_maint','ia_riskprmn',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- Issuer > Maintenance > Risk Profile > Add
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    begin
        insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_riskprdd','J2EF',' ','iariskprofiledetailon.do',' ',t_maxtag);
    exception
      when DUP_VAL_ON_INDEX then
        update acsitem set command='iariskprofiledetailon.do', acstype='J2EF', descrtag=t_maxtag where acsitem='ia_riskprdd';
      when OTHERS then
        NULL;
    end;
    begin
        insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_riskprdd',p_usrgrp,'Y','N',15);
    exception
      when OTHERS then
        NULL;
    end;
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_riskprmn','ia_riskprdd',t_maxtag,1,p_usrgrp,'J2EF');

    -- Issuer > Maintenance > Risk Profile > Search
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    begin
        insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_riskprsch','J2EF',' ','iariskprofilesearchon.do',' ',t_maxtag);
    exception
      when DUP_VAL_ON_INDEX then
        update acsitem set command='iariskprofilesearchon.do', acstype='J2EF', descrtag=t_maxtag where acsitem='ia_riskprsch';
      when OTHERS then
        NULL;
    end;
    begin
        insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_riskprsch',p_usrgrp,'Y','N',15);
    exception
      when OTHERS then
        NULL;
    end;
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_riskprmn','ia_riskprsch',t_maxtag,2,p_usrgrp,'J2EF');

end;
.
/

call riskprofile_menus('cortex');

drop procedure riskprofile_menus;
