create or replace procedure bulkatm_buttons(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);

begin
    select max(descrtag) into t_maxtag from descr;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Access to Bulk buttons','EN');

    begin
        insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values ('aa_bulkatm','J2EF',' ',' ',' ',t_maxtag);
    exception
      when OTHERS then
        NULL;
    end;
    begin
        insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values ('aa_bulkatm',p_usrgrp,'Y','N',15);
    exception
      when OTHERS then
        NULL;
    end;
end;
.
/

call bulkatm_buttons('cortex');

drop procedure bulkatm_buttons;
