create or replace procedure emvscriptserver_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);
t_maxorder  number(10,0);

begin
	
    select max(descrtag) into t_maxtag from descr;
    
    select max(morder) into t_maxorder from menu where usrgrp = p_usrgrp and mitem = 'au_maint';

	-- EMV CMD SRC
    t_maxorder := t_maxorder + 1;

    t_maxtag := t_maxtag + 1;
    
	-- Add EMVCMDSRC as new sub menu    
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_emvcmdsrc','J2EM',' ',' ',' ',t_maxtag);
	insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('au_maint','ia_emvcmdsrc',t_maxtag,t_maxorder,p_usrgrp,'J2EM');
	insert into descr(descrtag,descr,lang) values(t_maxtag,'EMV Command Definition','EN');
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_emvcmdsrc',p_usrgrp,'Y','N',15);

	-- emvcmdsrc Add
	t_maxtag := t_maxtag + 1;

	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_emvcmddd','J2EF',' ','iaemvcmdsrcdetailon.do',' ',t_maxtag);
	insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_emvcmdsrc','ia_emvcmddd',t_maxtag,1,p_usrgrp,'J2EF');
	insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_emvcmddd',p_usrgrp,'Y','N',15);

	-- emvcmdsrc search

	t_maxtag := t_maxtag + 1;

	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_emvcmdsch','J2EF',' ','iaemvcmdsrcsearchon.do',' ',t_maxtag);
	insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_emvcmdsrc','ia_emvcmdsch',t_maxtag,2,p_usrgrp,'J2EF');
	insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_emvcmdsch',p_usrgrp,'Y','N',15);
	

	--EMV CMD AUTO
    t_maxorder := t_maxorder + 1;

    t_maxtag := t_maxtag + 1;
    
	-- Add EMVCMDSRC as new sub menu    
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_emvcmdaut','J2EM',' ',' ',' ',t_maxtag);
	insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('au_maint','ia_emvcmdaut',t_maxtag,t_maxorder,p_usrgrp,'J2EM');
	insert into descr(descrtag,descr,lang) values(t_maxtag,'EMV Automatic Command Definition','EN');
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_emvcmdaut',p_usrgrp,'Y','N',15);

	-- emvcmdsrc Add
	t_maxtag := t_maxtag + 1;

	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_emvcmadd','J2EF',' ','iaemvcmdautodetailon.do',' ',t_maxtag);
	insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_emvcmdaut','ia_emvcmadd',t_maxtag,1,p_usrgrp,'J2EF');
	insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_emvcmadd',p_usrgrp,'Y','N',15);

	-- emvcmdsrc search

	t_maxtag := t_maxtag + 1;

	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_emvcmasch','J2EF',' ','iaemvcmdautosearchon.do',' ',t_maxtag);
	insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_emvcmdaut','ia_emvcmasch',t_maxtag,2,p_usrgrp,'J2EF');
	insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_emvcmasch',p_usrgrp,'Y','N',15);
	
	--EMV CMD LOG
	
  t_maxorder := t_maxorder + 1;

	-- emvcmdsrc Add
	t_maxtag := t_maxtag + 1;

	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_emvcmldd','J2EF',' ',' ',' ',t_maxtag);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_emvcmldd',p_usrgrp,'Y','N',15);

	-- emvcmdsrc search

	t_maxtag := t_maxtag + 1;

	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_emvcmlsch','J2EF',' ','iaemvcmdlogsearchon.do',' ',t_maxtag);
	insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('au_maint','ia_emvcmlsch',t_maxtag,t_maxorder,p_usrgrp,'J2EF');
	insert into descr(descrtag,descr,lang) values(t_maxtag,'EMV Script Commands Log','EN');
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_emvcmlsch',p_usrgrp,'Y','N',15);
 	
    select max(morder) into t_maxorder from menu where usrgrp = p_usrgrp and mitem = 'au_custsup';

    t_maxorder := t_maxorder + 1;

    t_maxtag := t_maxtag + 1;
    
	-- Add EMVCMDSRC as new sub menu    
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_emvscr1','J2EM',' ',' ',' ',t_maxtag);
	insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('au_custsup','ia_emvscr1',t_maxtag,t_maxorder,p_usrgrp,'J2EM');
	insert into descr(descrtag,descr,lang) values(t_maxtag,'EMV Script Generation','EN');
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_emvscr1',p_usrgrp,'Y','N',15);

    
	-- emvcmdsrc Add
	t_maxtag := t_maxtag + 1;

	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_emvscr2','J2EF',' ','iaemvscriptgenerationon.do?fromwhere=card',' ',t_maxtag);
	insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_emvscr1','ia_emvscr2',t_maxtag,1,p_usrgrp,'J2EF');
	insert into descr(descrtag,descr,lang) values(t_maxtag,'Search by card','EN');
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_emvscr2',p_usrgrp,'Y','N',15);

	-- emvcmdsrc search

	t_maxtag := t_maxtag + 1;

	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_emvscr3','J2EF',' ','iaemvscriptgenerationon.do?fromwhere=cardproduct',' ',t_maxtag);
	insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_emvscr1','ia_emvscr3',t_maxtag,2,p_usrgrp,'J2EF');
	insert into descr(descrtag,descr,lang) values(t_maxtag,'Search by card product','EN');
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_emvscr3',p_usrgrp,'Y','N',15);
	
	
	insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_emvscrgen','J2EF',' ',' ',' ',0);
	insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_emvscrgen',p_usrgrp,'Y','N',15);
 	
    
end;
.
/

call  emvscriptserver_menu('cortex');
drop procedure emvscriptserver_menu;

