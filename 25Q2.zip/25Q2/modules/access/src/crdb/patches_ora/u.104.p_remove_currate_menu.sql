create or replace procedure remove_currate_menu is

begin

    delete from usrperm where acsitem in ('co_curratdd', 'co_curratsch', 'rp_currate','co_currates');
    delete from grpperm where acsitem in ('co_curratdd', 'co_curratsch', 'rp_currate','co_currates');
    delete from menu where acsitem in ('co_curratdd', 'co_curratsch', 'rp_currate','co_currates');
    delete from acsitem where acsitem in ('co_curratdd', 'co_curratsch', 'rp_currate','co_currates');

end;
.
/

call remove_currate_menu();

drop procedure remove_currate_menu;
