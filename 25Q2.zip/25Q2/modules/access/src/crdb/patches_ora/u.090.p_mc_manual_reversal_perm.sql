create or replace procedure mc_manual_reversal_perm(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);

begin
    select max(descrtag) into t_maxtag from descr;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add Mastercard Manual Reversal','EN');

    begin
        insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values ('mc_icmnrvdet','J2EF',' ',' ',' ',t_maxtag);
    exception
      when OTHERS then
        NULL;
    end;
    begin
        insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values ('mc_icmnrvdet',p_usrgrp,'Y','N',15);
    exception
      when OTHERS then
        NULL;
    end;
end;
.
/

call mc_manual_reversal_perm('cortex');

drop procedure mc_manual_reversal_perm;
