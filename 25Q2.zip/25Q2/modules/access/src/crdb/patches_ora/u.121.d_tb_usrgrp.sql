
alter table usrgrp modify (id      number(10,0) not null);