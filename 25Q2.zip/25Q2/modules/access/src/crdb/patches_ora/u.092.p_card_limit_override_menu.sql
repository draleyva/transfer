create or replace procedure card_limit_override_menu is

begin
    begin
        update acsitem set command='cardlimitoverridesearchon.do' where acsitem='ia_crdlimvs';
    exception
      when OTHERS then
        NULL;
    end;
end;
.
/

call card_limit_override_menu();

drop procedure card_limit_override_menu;
