alter table usr add
(
    email_address varchar2(64) 
);

