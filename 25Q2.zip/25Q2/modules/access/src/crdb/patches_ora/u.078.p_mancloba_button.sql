create or replace procedure mancloba_button(p_usrgrp usrgrp.usrgrp%type) is
begin
    begin
        insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values ('pa_mancloba','J2EF',' ',' ',' ',0);
    exception
      when OTHERS then
        NULL;
    end;
    begin
        insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values ('pa_mancloba',p_usrgrp,'Y','N',15);
    exception
      when OTHERS then
        NULL;
    end;
end;
.
/

call mancloba_button('cortex');

drop procedure mancloba_button;
