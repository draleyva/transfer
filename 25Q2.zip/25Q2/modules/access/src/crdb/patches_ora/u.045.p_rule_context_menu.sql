create or replace procedure rule_context_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag 	number(10,0);
t_maxorder  	number(10,0);
t_menuorder 	number(10,0);
i 		number(10,0);

begin 

    select max(descrtag) into t_maxtag from descr;
    
    t_menuorder := 0;
           
    select max(morder) into t_menuorder from menu where mitem ='co_' and usrgrp=p_usrgrp;
    
    t_menuorder := t_menuorder + 1;
 
    t_maxtag := t_maxtag + 1;
    --RULE CONTEXT
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Rule Context', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_rulct', 'J2EM', ' ', ' ', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_rulct', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_','co_rulct',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

   t_maxtag := t_maxtag + 1;
    --Add RULE CONTEXT
       
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Add', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_rule_cdd', 'J2EF', ' ', 'corulecontextdetailon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_rule_cdd', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_rulct','co_rule_cdd',t_maxtag,2,p_usrgrp,'J2EF');

   t_maxtag := t_maxtag + 1;
    --Search RULE CONTEXT
        
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Search', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('co_rulecsch', 'J2EF', ' ', 'corulecontextsearchon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('co_rulecsch', p_usrgrp, 'Y', 'N', '15');
    insert into menu (mitem,acsitem,descrtag,morder,usrgrp,acstype) values('co_rulct','co_rulecsch',t_maxtag,1,p_usrgrp,'J2EF');


end;
.
/

CALL rule_context_menu('cortex');

DROP PROCEDURE rule_context_menu;