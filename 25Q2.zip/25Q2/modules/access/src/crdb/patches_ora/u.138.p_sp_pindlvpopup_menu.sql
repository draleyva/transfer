create or replace procedure pindlvmth_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag 	number(10,0);

begin 

    select max(descrtag) into t_maxtag from descr;
        
    t_maxtag := t_maxtag + 1;
    
    insert into descr (descrtag, descr, lang) values (t_maxtag, 'Pin Delivery Method Update', 'EN');
    insert into acsitem (acsitem, acstype, shortname, command, helpform, descrtag) values ('ia_zmpindelmeth', 'J2EF', ' ', 'iazoompindeliverymethodon.do', ' ', t_maxtag);
    insert into grpperm (acsitem, usrgrp, mask, extpswd, optag) values ('ia_zmpindelmeth', p_usrgrp, 'Y', 'N', '15');

end;
.
/
CALL pindlvmth_menu('cortex');

DROP PROCEDURE pindlvmth_menu;

