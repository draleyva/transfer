create or replace procedure atmbarcode_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);
t_menuorder	number(10,0);

begin

    select max(descrtag) into t_maxtag from descr;

    -- ATM > Configuration > ATM Barcode Data Configuration
    t_menuorder := 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'aa_conf' and usrgrp = p_usrgrp;
    t_menuorder := t_menuorder + 1;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'ATM Barcode Data Configuration','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('atm_barcode','J2EM',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('atm_barcode',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('aa_conf','atm_barcode',t_maxtag,t_menuorder,p_usrgrp,'J2EM');

    -- ATM > Configuration > ATM Barcode Data Configuration > Add
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Add','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('brc_cr_ed','J2EF',' ','wicket/atm/barcode?action=create',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('brc_cr_ed',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('atm_barcode','brc_cr_ed',t_maxtag,1,p_usrgrp,'J2EF');

    -- ATM > Configuration > ATM Barcode Data Configuration > Search
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Search','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('brc_sel','J2EF',' ','wicket/atm/barcode',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('brc_sel',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('atm_barcode','brc_sel',t_maxtag,2,p_usrgrp,'J2EF');
    
    --Permissions
    
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,' ','EN');

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('brc_ref_sel','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('brc_ref_sel',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('brc_ref_cr_ed','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('brc_ref_cr_ed',p_usrgrp,'Y','N',15);

    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rg_ep_atr_sel','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rg_ep_atr_sel',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rg_ep_atr_cr_ed','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rg_ep_atr_cr_ed',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rg_ep_df_sel','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rg_ep_df_sel',p_usrgrp,'Y','N',15);
    
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('rg_ep_df_cr_ed','J2EF',' ',' ',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('rg_ep_df_cr_ed',p_usrgrp,'Y','N',15);
    
    
end;
.
/

call atmbarcode_menu('cortex');

drop procedure atmbarcode_menu;
