create or replace procedure ccs_pp_apprule(p_usrgrp  usrgrp.usrgrp%type) is

t_maxtag	acsitem.descrtag%type;
t_menuorder	menu.morder%type;

begin
    SELECT MAX(DESCRTAG) INTO T_MAXTAG FROM DESCR;
    t_menuorder := 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'ccs_maint' and usrgrp = p_usrgrp;
    t_menuorder := t_menuorder + 1;
    t_maxtag := t_maxtag + 1;
    
    insert into descr(descrtag,descr,lang) values(t_maxtag,'Auto Payment Plan Rule','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ccs_ccsapprule','J2EF',' ','ccs/wicket/ccs/autopaymentplans',' ',t_maxtag);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ccs_maint','ccs_ccsapprule',t_maxtag,t_menuorder,p_usrgrp,'J2EF');
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ccs_ccsapprule',p_usrgrp,'Y','N',15);
    
end;
/

call ccs_pp_apprule('cortex');

drop procedure ccs_pp_apprule;
