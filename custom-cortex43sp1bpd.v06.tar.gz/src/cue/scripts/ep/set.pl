
$num = 0;

#Find the local key
system(" dkey -tZPK -rLOCAL > keyout");
open(KEY,'keyout');
while(<KEY>)
{
	chop;
	s/Clear key: //;
	s/ //;
	print "KEY = $_ \n";
	$key = $_;
}

system(">enc_t");
open(DATA,'data');
while(<DATA>)
{
	chop;
	$num = $num + 1;
	@line=split('\|');

	$tk2_full = $line[0];

	$tk2 = $tk2_full;	
	$pan = $tk2_full;
	$tk2 =~ s/.*=//; 
	$pan =~ s/=.*//;
	$exp = substr($tk2,0,4);
	$svc = substr($tk2,4,3);
	$pvv = substr($tk2,7,3);
	$cvv = substr($tk2,10,3);
	if($num < 10)
	{
		$num = '0'.$num;
	}

	#Create the clear pin block
	$pinblk = `pblk $pan  $line[1]`;

	chop($pinblk);

	#Encrypt the pin blk under local key
	#print("key = $key  blk= $pinblk\n");
	system("t $key $pinblk > enc_t");	

	open(ENC,'enc_t');
	while (<ENC>)
	{
		if( /Enc:/ )
		{
			s/Enc: //;
			s/ //g;
			$pinblk = $_;
			chop($pinblk);
		}
	}
	close(<ENC>);

	print "CARD $num|$pan|$tk2_full|$exp|$pinblk|$num.00|F\n";
	         
}

