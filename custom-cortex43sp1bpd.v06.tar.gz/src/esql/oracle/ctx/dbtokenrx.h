/*------------------------------------------------------------------------*/
/**
 * @file	dbtokenrx.h
 *
 * @brief	TOKEN access routines (header)
 *
 * @author	Ruslans Vasiljevs
 *
 * @date	16/08/2022
 *
 * $Id:
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

#ifndef __DBTOKENRX_H
#define __DBTOKENRX_H
/*---------------------------Includes-----------------------------------*/
#include <dbtokenrh.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
extern int dbtoken_begin_scan_by_crddet_id(long crddet_id, const char *timestamp);
extern int dbtoken_get_next_by_crddet_id(TOKEN_t *p_token, long *p_count);
extern int dbtoken_close_scan_by_crddet_id(void);

extern int dbtoken_getby_crddet_id(long crddet_id, const char *timestamp, TOKEN_t *p_token, long *p_count);

#endif /* __DBTOKENRX_H */
