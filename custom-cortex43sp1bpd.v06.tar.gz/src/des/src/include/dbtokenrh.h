/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	TOKEN type defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	06 Mar 2020
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-2.0/src/des/src/include/dbtokenrh.h#1 $
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBTOKENRH_H
#define __DBTOKENRH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define TOKEN_WHENCREATED_BUFFSIZE 24
#define TOKEN_SCHEMEID_BUFFSIZE 2
#define TOKEN_PAN_BUFFSIZE 20
#define TOKEN_PANSUFFIX_BUFFSIZE 5
#define TOKEN_VPAN_BUFFSIZE 20
#define TOKEN_PANUR_BUFFSIZE 49
#define TOKEN_TOKEN_BUFFSIZE 20
#define TOKEN_TKNREQUESTORID_BUFFSIZE 12
#define TOKEN_WALLETID_BUFFSIZE 4
#define TOKEN_TUR_BUFFSIZE 49
#define TOKEN_TKNEXPIRYDATE_BUFFSIZE 11
#define TOKEN_TKNSTATUS_BUFFSIZE 2
#define TOKEN_TKNSTATUSTIMESTAMP_BUFFSIZE 24
#define TOKEN_PROVISIONINGSTATUS_BUFFSIZE 4
#define TOKEN_PROVISIONINGSTATUSTIMESTAMP_BUFFSIZE 24
#define TOKEN_TKNACTIVATIONTIMESTAMP_BUFFSIZE 24
#define TOKEN_TKNTYPE_BUFFSIZE 3
#define TOKEN_STORAGETECH_BUFFSIZE 3
#define TOKEN_ACCOUNTIND_BUFFSIZE 2
#define TOKEN_APPINSTANCEID_BUFFSIZE 49
#define TOKEN_ISSUERPRODID_BUFFSIZE 33
#define TOKEN_WPACCOUNTHASH_BUFFSIZE 65
#define TOKEN_WPACCOUNTID_BUFFSIZE 65
#define TOKEN_WPRECOM_BUFFSIZE 2
#define TOKEN_WPRECOMSTDVER_BUFFSIZE 11
#define TOKEN_WPRECOMREASONS_BUFFSIZE 17
#define TOKEN_POSCRDDEV_BUFFSIZE 4
#define TOKEN_DEVNAME_BUFFSIZE 21
#define TOKEN_MOBILENOSUFFIX_BUFFSIZE 16
#define TOKEN_DEVID_BUFFSIZE 49
#define TOKEN_DEVLOCATION_BUFFSIZE 26
#define TOKEN_DEVIPADDRESS_BUFFSIZE 16
#define TOKEN_TACID_BUFFSIZE 65
#define TOKEN_TACDATETIME_BUFFSIZE 24
#define TOKEN_FINALDECISION_BUFFSIZE 2
#define TOKEN_FINALDECISIONIND_BUFFSIZE 2
#define TOKEN_VTSDECISION_BUFFSIZE 3
#define TOKEN_CUSTAMTYPE_BUFFSIZE 2
#define TOKEN_CUSTAMVALUE_BUFFSIZE 165
#define TOKEN_CUSTAMID_BUFFSIZE 33
#define TOKEN_CUSTLANG_BUFFSIZE 4
#define TOKEN_CORRELATIONID_BUFFSIZE 15
#define TOKEN_SUSPENDERS_BUFFSIZE 17
#define TOKEN_DEVIMEI_BUFFSIZE 25
#define TOKEN_DEVOSID_BUFFSIZE 25
#define TOKEN_DEVCTRY_BUFFSIZE 4
#define TOKEN_DEVPROTMETHOD_BUFFSIZE 2
#define TOKEN_DEVPRESENTTYPE_BUFFSIZE 2
#define TOKEN_DEVSERIALNO_BUFFSIZE 33
#define TOKEN_DEVLOCATIONSRC_BUFFSIZE 2
#define TOKEN_DEVTIMEZONE_BUFFSIZE 6
#define TOKEN_DEVTIMEZONESET_BUFFSIZE 2
#define TOKEN_DEVBLUMAC_BUFFSIZE 25
#define TOKEN_DEVOSTYPE_BUFFSIZE 2
#define TOKEN_WPACCCTRY_BUFFSIZE 4

#define TOKEN_PK_PREP2 \
	TOKEN_PKid = p_TOKEN_PK->id;\

#define TOKEN_PK_PREP1 \
	token.id = :v1 
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table TOKEN
 */
typedef struct
{
	long	id;
	char	whencreated[24];
	long	inst_id;
	long	callcenter_id;
	long	crddet_id;
	char	schemeid[2];
	char	pan[20];
	char	pansuffix[5];
	char	vpan[20];
	char	panur[49];
	char	token[20];
	char	tknrequestorid[12];
	char	walletid[4];
	char	tur[49];
	long	tknexpirydate;
	char	tknstatus[2];
	char	tknstatustimestamp[24];
	char	provisioningstatus[4];
	char	provisioningstatustimestamp[24];
	char	tknactivationtimestamp[24];
	char	tkntype[3];
	char	storagetech[3];
	short	tknasslevel;
	char	accountind[2];
	short	pansource;
	char	appinstanceid[49];
	char	issuerprodid[33];
	char	wpaccounthash[65];
	char	wpaccountid[65];
	short	wpdevscore;
	short	wpaccscore;
	char	wprecom[2];
	char	wprecomstdver[11];
	char	wprecomreasons[17];
	short	devtype;
	char	poscrddev[4];
	char	devname[21];
	char	mobilenosuffix[16];
	char	devid[49];
	char	devlocation[26];
	char	devipaddress[16];
	char	tacid[65];
	char	tacdatetime[24];
	char	finaldecision[2];
	char	finaldecisionind[2];
	short	vtsscore;
	char	vtsdecision[3];
	short	activationattempts;
	char	custamtype[2];
	char	custamvalue[165];
	char	custamid[33];
	char	custlang[4];
	char	correlationid[15];
	short	contactlessusg;
	short	cofusg;
	short	walletusg;
	short	highvaluecust;
	char	suspenders[17];
	char	devimei[25];
	char	devosid[25];
	char	devctry[4];
	char	devprotmethod[2];
	char	devpresenttype[2];
	char	devserialno[33];
	char	devlocationsrc[2];
	char	devtimezone[6];
	char	devtimezoneset[2];
	char	devblumac[25];
	char	devostype[2];
	char	wpaccctry[4];
	short	wpphonescore;
} TOKEN_t;

/**
 * Structure of indicators for table  TOKEN 
 */
typedef struct
{
	short	id;
	short	whencreated;
	short	inst_id;
	short	callcenter_id;
	short	crddet_id;
	short	schemeid;
	short	pan;
	short	pansuffix;
	short	vpan;
	short	panur;
	short	token;
	short	tknrequestorid;
	short	walletid;
	short	tur;
	short	tknexpirydate;
	short	tknstatus;
	short	tknstatustimestamp;
	short	provisioningstatus;
	short	provisioningstatustimestamp;
	short	tknactivationtimestamp;
	short	tkntype;
	short	storagetech;
	short	tknasslevel;
	short	accountind;
	short	pansource;
	short	appinstanceid;
	short	issuerprodid;
	short	wpaccounthash;
	short	wpaccountid;
	short	wpdevscore;
	short	wpaccscore;
	short	wprecom;
	short	wprecomstdver;
	short	wprecomreasons;
	short	devtype;
	short	poscrddev;
	short	devname;
	short	mobilenosuffix;
	short	devid;
	short	devlocation;
	short	devipaddress;
	short	tacid;
	short	tacdatetime;
	short	finaldecision;
	short	finaldecisionind;
	short	vtsscore;
	short	vtsdecision;
	short	activationattempts;
	short	custamtype;
	short	custamvalue;
	short	custamid;
	short	custlang;
	short	correlationid;
	short	contactlessusg;
	short	cofusg;
	short	walletusg;
	short	highvaluecust;
	short	suspenders;
	short	devimei;
	short	devosid;
	short	devctry;
	short	devprotmethod;
	short	devpresenttype;
	short	devserialno;
	short	devlocationsrc;
	short	devtimezone;
	short	devtimezoneset;
	short	devblumac;
	short	devostype;
	short	wpaccctry;
	short	wpphonescore;
} TOKEN_IND_t;

/**
 * Structure to retrieve TOKEN by Primary Key PK_TOKEN
 */
typedef struct
{
	long	id;
} TOKEN_PK_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
#define TOKENadd(pdata)					TOKENadd_IND(pdata, NULL)
#define TOKENupdate(pdata)					TOKENupdate_IND(pdata, NULL)
#define TOKENgetbyTOKEN_PK(pdata, phash)			TOKENgetbyTOKEN_PK_IND(pdata, NULL, phash)
#define TOKENgetbyTOKEN_PK4upd(pdata, phash)			TOKENgetbyTOKEN_PK4upd_IND(pdata, NULL, phash)
#define TOKENupdbyTOKEN_PK(pdata, phash)			TOKENupdbyTOKEN_PK_IND(pdata, NULL, phash)
#define TOKENupdallbyTOKEN_PK(pdata, phash)			TOKENupdallbyTOKEN_PK_IND(pdata, NULL, phash)
#define TOKENdump(p_TOKEN)					TOKENdump_IND(p_TOKEN, NULL)
#define TOKENdumplev(p_TOKEN, dbglev)				TOKENdumplev_IND(p_TOKEN, NULL, dbglev)

extern	int	TOKENadd_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND);
extern	int	TOKENupdate_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND);
extern	int	TOKENdelete(TOKEN_t *p_TOKEN);

extern	void	TOKENdump_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND);
extern	void	TOKENdumplev_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND, int dbglev);

extern	char	*TOKEN_PKkey2str(char *out, TOKEN_PK_t *p_TOKEN_PK);
extern	int	TOKENgetbyTOKEN_PK_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND, TOKEN_PK_t *p_TOKEN_PK);
extern	int	TOKENgetbyTOKEN_PK4upd_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND, TOKEN_PK_t *p_TOKEN_PK);
extern	int	TOKENupdbyTOKEN_PK_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND, TOKEN_PK_t *p_TOKEN_PK);
extern	int	TOKENupdallbyTOKEN_PK_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND, TOKEN_PK_t *p_TOKEN_PK);
extern	int	TOKENdelbyTOKEN_PK( TOKEN_PK_t *p_TOKEN_PK);
extern	void	TOKENinitDflt(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND);

#endif
