/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	TOKEN access routines for managing database access (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	06 Mar 2020
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-2.0/src/des/src/include/dbtokenes.h#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __DBTOKENES_H
#define __DBTOKENES_H

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	extern	long	TOKENid;
	extern	char	TOKENwhencreated[24];
	extern	long	TOKENinst_id;
	extern	long	TOKENcallcenter_id;
	extern	long	TOKENcrddet_id;
	extern	char	TOKENschemeid[2];
	extern	char	TOKENpan[20];
	extern	char	TOKENpansuffix[5];
	extern	char	TOKENvpan[20];
	extern	char	TOKENpanur[49];
	extern	char	TOKENtoken[20];
	extern	char	TOKENtknrequestorid[12];
	extern	char	TOKENwalletid[4];
	extern	char	TOKENtur[49];
	extern	char	TOKENtknexpirydate[11];
	extern	char	TOKENtknstatus[2];
	extern	char	TOKENtknstatustimestamp[24];
	extern	char	TOKENprovisioningstatus[4];
	extern	char	TOKENprovisioningstatustimestamp[24];
	extern	char	TOKENtknactivationtimestamp[24];
	extern	char	TOKENtkntype[3];
	extern	char	TOKENstoragetech[3];
	extern	short	TOKENtknasslevel;
	extern	char	TOKENaccountind[2];
	extern	short	TOKENpansource;
	extern	char	TOKENappinstanceid[49];
	extern	char	TOKENissuerprodid[33];
	extern	char	TOKENwpaccounthash[65];
	extern	char	TOKENwpaccountid[65];
	extern	short	TOKENwpdevscore;
	extern	short	TOKENwpaccscore;
	extern	char	TOKENwprecom[2];
	extern	char	TOKENwprecomstdver[11];
	extern	char	TOKENwprecomreasons[17];
	extern	short	TOKENdevtype;
	extern	char	TOKENposcrddev[4];
	extern	char	TOKENdevname[21];
	extern	char	TOKENmobilenosuffix[16];
	extern	char	TOKENdevid[49];
	extern	char	TOKENdevlocation[26];
	extern	char	TOKENdevipaddress[16];
	extern	char	TOKENtacid[65];
	extern	char	TOKENtacdatetime[24];
	extern	char	TOKENfinaldecision[2];
	extern	char	TOKENfinaldecisionind[2];
	extern	short	TOKENvtsscore;
	extern	char	TOKENvtsdecision[3];
	extern	short	TOKENactivationattempts;
	extern	char	TOKENcustamtype[2];
	extern	char	TOKENcustamvalue[165];
	extern	char	TOKENcustamid[33];
	extern	char	TOKENcustlang[4];
	extern	char	TOKENcorrelationid[15];
	extern	short	TOKENcontactlessusg;
	extern	short	TOKENcofusg;
	extern	short	TOKENwalletusg;
	extern	short	TOKENhighvaluecust;
	extern	char	TOKENsuspenders[17];
	extern	char	TOKENdevimei[25];
	extern	char	TOKENdevosid[25];
	extern	char	TOKENdevctry[4];
	extern	char	TOKENdevprotmethod[2];
	extern	char	TOKENdevpresenttype[2];
	extern	char	TOKENdevserialno[33];
	extern	char	TOKENdevlocationsrc[2];
	extern	char	TOKENdevtimezone[6];
	extern	char	TOKENdevtimezoneset[2];
	extern	char	TOKENdevblumac[25];
	extern	char	TOKENdevostype[2];
	extern	char	TOKENwpaccctry[4];
	extern	short	TOKENwpphonescore;

	extern	long	TOKEN_PKid;
EXEC SQL END DECLARE SECTION;
/** @endcond */

/*---------------------------Macros-------------------------------------*/
#define TOKEN_HV \
:TOKENid,\
:TOKENwhencreated,\
:TOKENinst_id,\
:TOKENcallcenter_id,\
:TOKENcrddet_id,\
:TOKENschemeid,\
:TOKENpan,\
:TOKENpansuffix,\
:TOKENvpan,\
:TOKENpanur,\
:TOKENtoken,\
:TOKENtknrequestorid,\
:TOKENwalletid,\
:TOKENtur,\
:TOKENtknexpirydate,\
:TOKENtknstatus,\
:TOKENtknstatustimestamp,\
:TOKENprovisioningstatus,\
:TOKENprovisioningstatustimestamp,\
:TOKENtknactivationtimestamp,\
:TOKENtkntype,\
:TOKENstoragetech,\
:TOKENtknasslevel,\
:TOKENaccountind,\
:TOKENpansource,\
:TOKENappinstanceid,\
:TOKENissuerprodid,\
:TOKENwpaccounthash,\
:TOKENwpaccountid,\
:TOKENwpdevscore,\
:TOKENwpaccscore,\
:TOKENwprecom,\
:TOKENwprecomstdver,\
:TOKENwprecomreasons,\
:TOKENdevtype,\
:TOKENposcrddev,\
:TOKENdevname,\
:TOKENmobilenosuffix,\
:TOKENdevid,\
:TOKENdevlocation,\
:TOKENdevipaddress,\
:TOKENtacid,\
:TOKENtacdatetime,\
:TOKENfinaldecision,\
:TOKENfinaldecisionind,\
:TOKENvtsscore,\
:TOKENvtsdecision,\
:TOKENactivationattempts,\
:TOKENcustamtype,\
:TOKENcustamvalue,\
:TOKENcustamid,\
:TOKENcustlang,\
:TOKENcorrelationid,\
:TOKENcontactlessusg,\
:TOKENcofusg,\
:TOKENwalletusg,\
:TOKENhighvaluecust,\
:TOKENsuspenders,\
:TOKENdevimei,\
:TOKENdevosid,\
:TOKENdevctry,\
:TOKENdevprotmethod,\
:TOKENdevpresenttype,\
:TOKENdevserialno,\
:TOKENdevlocationsrc,\
:TOKENdevtimezone,\
:TOKENdevtimezoneset,\
:TOKENdevblumac,\
:TOKENdevostype,\
:TOKENwpaccctry,\
:TOKENwpphonescore

#define TOKEN_COL \
token.id,\
token.whencreated,\
token.inst_id,\
token.callcenter_id,\
token.crddet_id,\
token.schemeid,\
token.pan,\
token.pansuffix,\
token.vpan,\
token.panur,\
token.token,\
token.tknrequestorid,\
token.walletid,\
token.tur,\
token.tknexpirydate,\
token.tknstatus,\
token.tknstatustimestamp,\
token.provisioningstatus,\
token.provisioningstatustimestamp,\
token.tknactivationtimestamp,\
token.tkntype,\
token.storagetech,\
token.tknasslevel,\
token.accountind,\
token.pansource,\
token.appinstanceid,\
token.issuerprodid,\
token.wpaccounthash,\
token.wpaccountid,\
token.wpdevscore,\
token.wpaccscore,\
token.wprecom,\
token.wprecomstdver,\
token.wprecomreasons,\
token.devtype,\
token.poscrddev,\
token.devname,\
token.mobilenosuffix,\
token.devid,\
token.devlocation,\
token.devipaddress,\
token.tacid,\
token.tacdatetime,\
token.finaldecision,\
token.finaldecisionind,\
token.vtsscore,\
token.vtsdecision,\
token.activationattempts,\
token.custamtype,\
token.custamvalue,\
token.custamid,\
token.custlang,\
token.correlationid,\
token.contactlessusg,\
token.cofusg,\
token.walletusg,\
token.highvaluecust,\
token.suspenders,\
token.devimei,\
token.devosid,\
token.devctry,\
token.devprotmethod,\
token.devpresenttype,\
token.devserialno,\
token.devlocationsrc,\
token.devtimezone,\
token.devtimezoneset,\
token.devblumac,\
token.devostype,\
token.wpaccctry,\
token.wpphonescore

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_TOKEN_t
	{
		long	id;
		char	whencreated[24];
		long	inst_id;
		long	callcenter_id;
		long	crddet_id;
		char	schemeid[2];
		char	pan[20];
		char	pansuffix[5];
		char	vpan[20];
		char	panur[49];
		char	token[20];
		char	tknrequestorid[12];
		char	walletid[4];
		char	tur[49];
		char	tknexpirydate[11];
		char	tknstatus[2];
		char	tknstatustimestamp[24];
		char	provisioningstatus[4];
		char	provisioningstatustimestamp[24];
		char	tknactivationtimestamp[24];
		char	tkntype[3];
		char	storagetech[3];
		short	tknasslevel;
		char	accountind[2];
		short	pansource;
		char	appinstanceid[49];
		char	issuerprodid[33];
		char	wpaccounthash[65];
		char	wpaccountid[65];
		short	wpdevscore;
		short	wpaccscore;
		char	wprecom[2];
		char	wprecomstdver[11];
		char	wprecomreasons[17];
		short	devtype;
		char	poscrddev[4];
		char	devname[21];
		char	mobilenosuffix[16];
		char	devid[49];
		char	devlocation[26];
		char	devipaddress[16];
		char	tacid[65];
		char	tacdatetime[24];
		char	finaldecision[2];
		char	finaldecisionind[2];
		short	vtsscore;
		char	vtsdecision[3];
		short	activationattempts;
		char	custamtype[2];
		char	custamvalue[165];
		char	custamid[33];
		char	custlang[4];
		char	correlationid[15];
		short	contactlessusg;
		short	cofusg;
		short	walletusg;
		short	highvaluecust;
		char	suspenders[17];
		char	devimei[25];
		char	devosid[25];
		char	devctry[4];
		char	devprotmethod[2];
		char	devpresenttype[2];
		char	devserialno[33];
		char	devlocationsrc[2];
		char	devtimezone[6];
		char	devtimezoneset[2];
		char	devblumac[25];
		char	devostype[2];
		char	wpaccctry[4];
		short	wpphonescore;
	} HOST_TOKEN_t;

	typedef struct HOST_TOKEN_IND_t
	{
		short	id_ind;
		short	whencreated_ind;
		short	inst_id_ind;
		short	callcenter_id_ind;
		short	crddet_id_ind;
		short	schemeid_ind;
		short	pan_ind;
		short	pansuffix_ind;
		short	vpan_ind;
		short	panur_ind;
		short	token_ind;
		short	tknrequestorid_ind;
		short	walletid_ind;
		short	tur_ind;
		short	tknexpirydate_ind;
		short	tknstatus_ind;
		short	tknstatustimestamp_ind;
		short	provisioningstatus_ind;
		short	provisioningstatustimestamp_ind;
		short	tknactivationtimestamp_ind;
		short	tkntype_ind;
		short	storagetech_ind;
		short	tknasslevel_ind;
		short	accountind_ind;
		short	pansource_ind;
		short	appinstanceid_ind;
		short	issuerprodid_ind;
		short	wpaccounthash_ind;
		short	wpaccountid_ind;
		short	wpdevscore_ind;
		short	wpaccscore_ind;
		short	wprecom_ind;
		short	wprecomstdver_ind;
		short	wprecomreasons_ind;
		short	devtype_ind;
		short	poscrddev_ind;
		short	devname_ind;
		short	mobilenosuffix_ind;
		short	devid_ind;
		short	devlocation_ind;
		short	devipaddress_ind;
		short	tacid_ind;
		short	tacdatetime_ind;
		short	finaldecision_ind;
		short	finaldecisionind_ind;
		short	vtsscore_ind;
		short	vtsdecision_ind;
		short	activationattempts_ind;
		short	custamtype_ind;
		short	custamvalue_ind;
		short	custamid_ind;
		short	custlang_ind;
		short	correlationid_ind;
		short	contactlessusg_ind;
		short	cofusg_ind;
		short	walletusg_ind;
		short	highvaluecust_ind;
		short	suspenders_ind;
		short	devimei_ind;
		short	devosid_ind;
		short	devctry_ind;
		short	devprotmethod_ind;
		short	devpresenttype_ind;
		short	devserialno_ind;
		short	devlocationsrc_ind;
		short	devtimezone_ind;
		short	devtimezoneset_ind;
		short	devblumac_ind;
		short	devostype_ind;
		short	wpaccctry_ind;
		short	wpphonescore_ind;
	} HOST_TOKEN_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
#define TOKENdump(p_TOKEN)					TOKENdump_IND(p_TOKEN, NULL)
#define TOKENdumplev(p_TOKEN, dbglev)				TOKENdumplev_IND(p_TOKEN, NULL, dbglev)
extern	int	TOKENadd_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND);
extern	int	TOKENupdate_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND);
extern	int	TOKENdelete(TOKEN_t *p_TOKEN);
extern	void	TOKENdump_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND);
extern	void	TOKENdumplev_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND, int dbglev);

extern	int	TOKENhv2cs(TOKEN_t *p_TOKEN);
extern	void	TOKENcs2hv(TOKEN_t *p_TOKEN);
extern	int	TOKENhs2cs(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_IND, HOST_TOKEN_t *hsData, HOST_TOKEN_IND_t *hsInd);

extern	void	TOKENcs2hsINS(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_IND, HOST_TOKEN_t *hsData, HOST_TOKEN_IND_t *hsInd);
extern	void	TOKENcs2hs(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_IND, HOST_TOKEN_t *hsData, HOST_TOKEN_IND_t *hsInd);
extern	void	TOKEN_PKdumplev(TOKEN_PK_t *p_TOKEN_PK, int dbglev);
extern	char	*TOKEN_PKkey2str(char *out, TOKEN_PK_t *p_TOKEN_PK);
extern	int	TOKENgetbyTOKEN_PK_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND, TOKEN_PK_t *p_TOKEN_PK);
extern	int	TOKENgetbyTOKEN_PK4upd_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND, TOKEN_PK_t *p_TOKEN_PK);
extern	int	TOKENupdbyTOKEN_PK_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND, TOKEN_PK_t *p_TOKEN_PK);
extern	int	TOKENupdallbyTOKEN_PK_IND(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND, TOKEN_PK_t *p_TOKEN_PK);
extern	int	TOKENdelbyTOKEN_PK( TOKEN_PK_t *p_TOKEN_PK);

extern	void	TOKENinitDflt(TOKEN_t *p_TOKEN, TOKEN_IND_t *p_TOKEN_IND);
#endif
