/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDDESLIB Additional DES BPD variables 
 *
 * @author	Raul Torres
 *
 * @date	06 Mar 2020
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-2.0/src/des/src/include/bpddesdef.h#2 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/


#define BPD_RSPCOD_FIELDNOTFOUND         "12"    
#define BPD_RSPCOD_INVALIDMETHODID         "01"   
#define BPD_RSPCOD_YELLOWFLOWREJECT         "11"  

