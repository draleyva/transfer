/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDTKNREQLOG type defininitions (ORACLE)
 *
 * @author	Raul Torres
 *
 * @date	06 Mar 2020
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-2.0/src/des/src/bpddeslib/bpddbtknrsplogrh.h#1 $
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __BPDDBTKNREQLOGRH_H
#define __BPDDBTKNREQLOGRH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table TKNRSPLOG
 */
typedef struct
{
	long	tknreqlog_id;
	char	walletid[128+1];
	char	cardacceptorid[32+1];
	char	cardacceptorname[256+1];
	char	leveloftrust[32+1];
	char	captmethod[64+1];
	char	crdscore[1+1];
	char	reasoncode[100+1];
} BPDTKNREQLOG_t;

/**
 * Structure of indicators for table  TKNRSPLOG 
 */
typedef struct
{
	short	tknreqlog_id;
	short	walletid;
	short	cardacceptorid;
	short	cardacceptorname;
	short	leveloftrust;
	short	captmethod;
	short	crdscore;
	short	reasoncode;
} BPDTKNREQLOG_IND_t;

/**
 * Structure to retrieve BPDTKNREQLOG by Primary Key PK_BPDTKNREQLOG
 */
typedef struct
{
	long	tknreqlog_id;
} BPDTKNREQLOG_PK_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
#define BPDTKNREQLOGadd(pdata)					BPDTKNREQLOGadd_IND(pdata, NULL)

#define BPDTKNREQLOGdump(p_BPDTKNREQLOG)				TKNRSPLOGdump_IND(p_BPDTKNREQLOG, NULL)
#define BPDTKNREQLOGdumplev(p_BPDTKNREQLOG, dbglev)			TKNREQLOGdumplev_IND(p_BPDTKNREQLOG, NULL, dbglev)

extern	int	BPDTKNREQLOGadd_IND(BPDTKNREQLOG_t *p_BPDTKNREQLOG, BPDTKNREQLOG_IND_t *p_BPDTKNREQLOG_IND);

extern	void	BPDTKNREQLOGdump_IND(BPDTKNREQLOG_t *p_BPDTKNREQLOG, BPDTKNREQLOG_IND_t *p_BPDTKNREQLOG_IND);
extern	void	BPDTKNREQLOGdumplev_IND(BPDTKNREQLOG_t *p_BPDTKNRSPLOG, BPDTKNREQLOG_IND_t *p_BPDTKNREQLOG_IND, int dbglev);

#endif
