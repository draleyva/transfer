/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDTKNREQLOG access routines for managing database access (ORACLE)
 *
 * @author	Raul Torres
 *
 * @date	06 Mar 2020
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-2.0/src/des/src/bpddeslib/bpddbtknreqloges.h#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __BPDDBTKNREQLOGES_H
#define __BPDDBTKNREQLOGES_H

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/

/*---------------------------Macros-------------------------------------*/

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_BPDTKNREQLOG_t
	{
		long	tknreqlog_id;
		char	walletid[128+1];
		char	cardacceptorid[32+1];
		char	cardacceptorname[256+1];
		char	leveloftrust[32+1];
		char	captmethod[64+1];
		char	crdscore[1+1];
		char	reasoncode[100+1];
	} HOST_BPDTKNREQLOG_t;

	typedef struct HOST_BPDTKNREQLOG_IND_t
	{
		short	tknreqlog_id_ind;
		short	walletid_ind;
		short	cardacceptorid_ind;
		short	cardacceptorname_ind;
		short	leveloftrust_ind;
		short	captmethod_ind;
		short	crdscore_ind;
		short	reasoncode_ind;
	} HOST_BPDTKNREQLOG_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/

/*
#define BPDTKNREQLOGdump(p_BPDTKNREQLOG)				BPDTKNREQLOGdump_IND(p_BPDTKNREQLOG, NULL)
#define BPDTKNREQLOGdumplev(p_BPDTKNREQLOG, dbglev)			BPDTKNREQLOGdumplev_IND(p_BPDTKNREQLOG, NULL, dbglev)
*/
extern	int		BPDTKNREQLOGadd_IND(BPDTKNREQLOG_t *p_BPDTKNREQLOG, BPDTKNREQLOG_IND_t *p_BPDTKNREQLOG_IND);
extern	void	BPDTKNREQLOGcs2hsINS(BPDTKNREQLOG_t *p_BPDTKNREQLOG, BPDTKNREQLOG_IND_t *p_IND, HOST_BPDTKNREQLOG_t *hsData, HOST_BPDTKNREQLOG_IND_t *hsInd);
extern	void	BPDTKNREQLOGdump_IND(BPDTKNREQLOG_t *p_BPDTKNREQLOG, BPDTKNREQLOG_IND_t *p_BPDTKNREQLOG_IND);
extern	void	BPDTKNREQLOGdumplev_IND(BPDTKNREQLOG_t *p_BPDTKNEQPLOG, BPDTKNREQLOG_IND_t *p_BPDTKNREQLOG_IND, int dbglev);

#endif
