/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	JSON Interface Service - BPD Custom version 
 *
 * @details	JSONIF Tuxedo Service works on Tuxedo FML32 or String Buffer with JSON content.
 *		Received buffer is converted to JSON and RESTful call is made.
 *		Response is converted converted back to Tuxedo buffer with setting call info.
 *
 * @author	Raul Torres
 * @author	David Leyva
 *
 * @date	17 April 2024
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-2.0/src/des/src/bpdjsonif/bpdjsonifsvc.c#1 $
 *
 * @copyright	FIS Global
 */
/*---------------------------Includes-----------------------------------------*/
#include <portable.h>
#include <bpdjsonifsvc.h>
#include <jsonout.h>
#include <sluconv.h>

#include <sldbg.h>
#include <slfdbg.h>
#include <slclp.h>
#include <slcfp.h>
#include <slnfb.h>
#include <slntp.h>
#include <slstring.h>
#include <cortex.h>
#include <callinfo.h>
#include <jsonfb.h>
#include <tcpssl.h>
#include <urimap.h>

#include <jwe.h>
#include <jwecnf.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/

/** Name of JSON interface service. */
#define BPDJSONIFSVC    "BPDJSONIF"

/** Tagname used in traces. */
#define TAGNAME "BPDJSONIF"

/** Size of Tuxedo buffer for each client (63 KB). */
#define TUXEDO_BUFFER_SIZE 64512

/** Size of socket buffer for each client (64 KB). */
#define SOCKET_BUFFER_SIZE 0x10000

/** Timeout in milliseconds for Tuxedo call */
#define CALL_TIMEOUT 60000

/** Size of buffer for URI (4 KB). */
#define URI_SIZE 0x1000

/** Size of buffer for additiona HTTP headers */
#define ADD_HEADERS_BUFFER_SIZE 0x4000

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/

/** @cond INTERNAL */

ctxprivate int  M_dbglev = dbg_syswarn;			/**< debug level		*/
ctxprivate int  M_dbgbuf = FAIL;		/**< debug buffering		*/
ctxprivate char M_dbgfile[CTX_FILENAME_MAX];	/**< debug output name	*/

ctxprivate char M_html_buffer[SOCKET_BUFFER_SIZE];	/**< HTML buffer	*/

/** Tuxedo character set. */
ctxprivate char M_charset[32];

/** Name of client in HTTP header. */
ctxprivate const char M_agent_name[] = "bpdjsonif/1.0";

/** Array with configuration parameters for web server. */
ctxprivate cfp_parm webif_cfp_parm[]=
{
	{"TCP_NODELAY", parm_int, 0,
		FALSE,	&webif_param.nodelay, 0},
	{"SSL", parm_string, sizeof(webif_param.ssl_sect),
		FALSE,	(void *)webif_param.ssl_sect, 0},
	{"SSL_NAME", parm_string, sizeof(webif_param.ssl_name),
		FALSE,	(void *)webif_param.ssl_name, 0},
	{0}
};

/** String with usage of configuration parameters for web server. */
ctxprivate const char M_jsonif_cfp_usage[]=
	"Configuration file parameters for bpdjsonifsrv:\n"
	"\tMAPPING tag[:subsection] - Name of section with mapping Tuxedo Services to RESTfull calls.\n"
		"\t\tFormat of lines in mapping section is:\n"
			"\t\t\t<Tuxedo service> GET|DELETE|POST|PUT <URL> FML32|STRING JSON|XML\n"
	"\t[SSL tag[:subsection] ] - Name of section in configuration file for SSL parameters.\n"
	"\t[SSL_NAME name] - Name to verify received certificate or '*' to match all.\n"
	"\t[TCP_NODELAY flag] - For 1 sets TCP_NODELAY flag on sockets. For -1 it uses system default. "
		"Default 0 which disables TCP_NODELAY flag.\n"
	"\t[CHARSET charset] - Character set used by Tuxedo:\n"
		"\t\t\t\t- No conversion. Default.\n"
		"\t\tUTF-8\t\t- Verify and convert non UTF-8 characters to '?'.\n"
		"\t\tISO-8859-1\t- Convert to and from ISO-8859-1.\n"
		"\t\tISO-8859-2\t- Convert to and from ISO-8859-2.\n"
	"\t[JWE tag[:subsection] ] - Name of section in configuration file for JWE parameters.\n"
	"\n"
;

/** JWE configuration to be used for encryption and decryption of requests and responses */
ctxprivate jwecnf_t M_jwecnf;

/** @endcond */

/*---------------------------Prototypes---------------------------------*/

ctxpublic void BPDJSONIF(TPSVCINFO *p_svc);

/** @cond INTERNAL */
ctxprivate const char *jsonif_get_content_type(jsonif_client_t *clt);
ctxprivate int jsonif_process_fml32(jsonif_client_t *clt, FBFR **pp_fb, long size);
ctxprivate int jsonif_process_string(jsonif_client_t *clt, char **pp_sb, long size);
ctxprivate int jsonif_add_call_info(jsonif_client_t *clt, char *p_tb);
ctxprivate int jsonif_get_add_headers(slbuffer_t *sl_headers, char *p_sb);
ctxprivate int jsonif_filtered_header(const char* header, const char* value);
ctxprivate const char *override_content_type(char *buffer, size_t buffer_size, char *p_sb, const char *def);

/** @endcond */

/*---------------------------Functions----------------------------------*/

/*------------------------------------------------------------------------*/
/**
 * @brief	  Service entry point for processing JSON client requests
 *
 * @param[in]	  p_svc Service info
 *
 * @return	  void
 */
/*------------------------------------------------------------------------*/
ctxpublic void BPDJSONIF(TPSVCINFO *p_svc)
{
	int	ret = FAIL;
	char	type[NTP_TYPE_LEN+1];
	char	subtype[NTP_SUBTYPE_LEN+1];
	int	size;
	const char *req_type;
	jsonif_client_t clt;
	char	content_type[CALLINFO_CONTENT_TYPE_BUFSIZE] = { EOS };

	memset (&clt, 0, sizeof(clt));
	clt.webclt.parser.buffer = M_html_buffer;
	clt.webclt.parser.size = sizeof(M_html_buffer);
	clt.webclt.writer.databuf.buffer = M_html_buffer;
	clt.webclt.writer.databuf.size = sizeof(M_html_buffer);
	
	DBG_SETNAME(BPDJSONIFSVC);
	DBG_SETLEV(M_dbglev);
	if (FAIL < M_dbgbuf)
		DBG_SETBUF(M_dbgbuf);
	if (M_dbgfile[0])
		DBG_SETFILE(M_dbgfile);

	DBG_STAR(("%s service", p_svc->name));
	
	/* is mapped */
	ret = svcmap_find(p_svc->name, &clt.param);
	if ( SUCCEED == ret )
	{
		/* just parse URL address again */
		clt.uri = http_parse_url_address(
			clt.param.url, &clt.addr);
		clt.webclt.srv_addr = &clt.addr;
		clt.webclt.writer.connection = http_connection_close;
		clt.webclt.writer.version = http_version_1_1;
		clt.webclt.writer.encrypted = 
			(ENC_REQ == clt.param.req_rsp_enc || ENC_REQRSP == clt.param.req_rsp_enc);
		clt.webclt.parser.encrypted = 
			(ENC_RSP == clt.param.req_rsp_enc || ENC_REQRSP == clt.param.req_rsp_enc);
		if ( M_jwecnf.is_encryption && clt.webclt.writer.encrypted )
		{
			clt.webclt.writer.header_alg = M_jwecnf.def_header_alg;
		}		
		clt.content_type = ( clt.webclt.writer.encrypted ) ? 
			"application/apis.cortex.encryption+json; charset=UTF-8" :
			( ( clt.param.is_json ) ? 
				"application/json; charset=UTF-8" :
				"application/xml; charset=UTF-8" 
			);				
			
		/* what type of Tuxedo buffer is expected? */
		req_type = ( clt.param.is_fml32 ) ? "FML32" : "STRING";
		
		/* check Tuxedo buffer type */
		if ( p_svc->data )
		{
			size = ntp_types(p_svc->data, type, subtype);
			if ( 0 < size )
			{
				type[NTP_TYPE_LEN] = EOS;
				subtype[NTP_SUBTYPE_LEN] = EOS;
				DBG_PRINTF((dbg_progdetail, "Buffer type %s, subtype %s, size: %d",
					type, subtype, size));
				if (strcmp(req_type, type))
				{
					ret = FAIL;
					DBG_PRINTF((dbg_syserr, "Unsupported %s tuxedo buffer", type));
				}
			}
			else
			{
				ret = FAIL;
				DBG_PRINTF((dbg_syserr, "ntp_types failed(%d): %s",
					tperrno, tpstrerror(tperrno)));
			}
		}
		
		/* do call */
		if ( SUCCEED == ret )
		{
			if ( clt.param.is_fml32 )
			{
				if ( clt.param.is_json )
					ret = jsonif_process_fml32(&clt, (FBFR **)(&p_svc->data), size);
				else
				{
					ret = FAIL;
					DBG_PRINTF((dbg_syserr, "Unsupported conversion from FML32 to xml"));
				}
			}
			else
			{
				if ( !clt.webclt.writer.encrypted ) /* Don't override content type if encrypted */
				{
					clt.content_type = override_content_type(content_type, sizeof(content_type), 
						p_svc->data, clt.content_type);
				}
				ret = jsonif_process_string(&clt, &p_svc->data, size);
			}
		}
		
		/* process results of call */
		if ( SUCCEED == ret )
		{
			ret = jsonif_add_call_info(&clt, p_svc->data);
		}
	}
	else
	{
		DBG_PRINTF((dbg_syserr, "No mapping for %s service.",
			p_svc->name));
	}

	/* return if error occurred or TPRETURN was set */
	DBG_STAR(("ntp_return from : %s", p_svc->name));
	DBG_CLOSEFILE();

	ntp_return((SUCCEED == ret) ? TPSUCCESS : TPFAIL,
			0L, p_svc->data, 0L, 0L);
}

/** @cond INTERNAL */

/*------------------------------------------------------------------------*/
/**
 * @brief	  Override content type with value from callinfo
 *
 * @param[in,out] buffer Buffer for content type.
 * @param[in]	  buffer_size Size of buffer.
 * @param[in]	  p_sb Tuxedo string buffer from the call
 * @param[in]	  def Default content type value.
 *
 * @return	  Pointer to content type or default value.
 */
/*------------------------------------------------------------------------*/
ctxprivate const char *override_content_type(char *buffer, size_t buffer_size, char *p_sb, const char *def)
{
	FBFR *callinfo;
	const char *ret = def;
	FLDLEN len = buffer_size;
	
	callinfo = callinfo_alloc();
	if( callinfo )
	{
		if (SUCCEED == callinfo_get(p_sb, &callinfo))
		{
			ret = callinfo_get_content_type(callinfo, buffer, &len, def);
			if ( NULL == ret )
			{
				ret = def;
			}
			DBG_PRINTF((dbg_progdetail, "Setting content type: [%s]", ret));
		}
		ntp_free((char *)callinfo);
	}
	
	return ret;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	  Add to buffer with URL escape
 *
 * @param[in,out] uri HTTP output with output data.
 * @param[in]	  str String to be added to buffer
 * @param[in]	  skip List of characters shouldn't be escaped (eg. "/?")
 *
 * @retval	  SUCCEED
 * @retval	  FAIL
 */
/*------------------------------------------------------------------------*/
ctxprivate int uri_store(sldata_t *uri, const char *str, const char *skip)
{
	int	ret = SUCCEED;
	const char *s = str;
	const char *p;
	char escape[4];
	
	p = strpbrk(s, skip);
	while (p)
	{
		/* store previous characters */ 
		if ( p>s )
			ret |= sluconv_convert_chars_to_uft8(uri, s, p-s, sldata_output_uri);
		
		ret |= sldata_output_data(uri, p, 1);
		s = p+1;
		
		p = strpbrk(s, skip);
	}
	
	if (*s)
		ret |= sluconv_convert_chars_to_uft8(uri, s, strlen(s), sldata_output_uri);
	
	return ret;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	  Prepare query string with parameters from FML32 buffer
 *
 * @param[in,out] uri	HTTP output with output data.
 * @param[in,out] p_fb	Fielded buffer
 * @param[in]	  sep	Separator before added parameters.
 *
 * @retval	  SUCCEED
 * @retval	  FAIL
 */
/*------------------------------------------------------------------------*/
ctxprivate int jsonif_get_params_fml32(sldata_t *uri, FBFR *p_fb, char sep)
{
	int	ret = FAIL;
	const char *param = NULL;
	const char *value;
	char name[HTTPQUERY_PARAM_NAME_BUFSIZE];
	unsigned long len;
	int occ = 0;
	FLDID fldid = FIRSTFLDID;
	char s = sep;
	
	/* add FML32 to query string for GET and DELETE methods */
	int num = F_num(p_fb);
	DBG_PRINTF((dbg_progdetail, "Number of parameters in query string: %d", num));
	
	do
	{
		int next = F_next(p_fb, &fldid, &occ, NULL, NULL);
		if ( TRUE == next )
		{
			param = F_name(fldid);
			len = strlen(param);
			if (len >= sizeof(name) )
			{
				len = sizeof(name) - 1;
				DBG_PRINTF((dbg_syswarn, "Parameter name [%s] truncated", param));
			}
			memcpy(name, param, len); 
			name[len] = '\0';
			
			value = CF_find(p_fb, fldid, occ, NULL, FLD_STRING);
			if ( value )
			{
				if (s)
				{
					ret |= sldata_output_data(uri, &s, 1);
				}
				
				ret |= uri_store(uri, name, "/?");
				ret |= sldata_output_data(uri, "=", 1);
				ret |= uri_store(uri, value, "/?=");
				
				/* separator for the next parameter */
				s = '&';
			}
		}
		else
		{
			if ( next )
			{
				int err = F_errno();
				
				ret = FAIL;
				
				DBG_PRINTF((dbg_fatal, "Call F_next failed with error %d: %s.",
					err, F_strerror(err)));
			}
			
			break;
		}
	} while (SUCCEED==ret);

	return ret;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	  Prepare URI for FML32
 *
 * @param[in,out] uri HTTP output with output data.
 * @param[in]	uri_template URI template
 * @param[in,out] p_fb Fielded buffer
 * @param[in]	method HTTP method.
 *
 * @retval	  SUCCEED
 * @retval	  FAIL
 */
/*------------------------------------------------------------------------*/
ctxprivate int jsonif_get_uri_fml32(sldata_t *uri, const char *uri_template, FBFR *p_fb, int method)
{
	int	ret = FAIL;
	
	const char *p = uri_template;
	const char *q;
	const char *param = NULL;
	const char *value;
	int occ;
	char name[HTTPQUERY_PARAM_NAME_BUFSIZE];
	unsigned long len;
	
	/* process path */
	for( q=p; *q && *q!='?'; ++q)
	{
		switch(*q)
		{
			case '{': // open
				if (!param)
				{
					ret |= sldata_output_data(uri, p, q-p);
					p = q;
				}
				else
				{
					ret = FAIL;
				}
				param = q+1;
				break;
			
			case '}': // close
				if (param)
				{
					len = q-param;
					if (len >= sizeof(name) )
					{
						len = sizeof(name) - 1;
						DBG_PRINTF((dbg_syswarn, "Parameter name [%s] truncated", param));
					}
					memcpy(name, param, len); 
					name[len] = '\0';
					
					if (!httpquery_decode(name))
					{
						FLDID fldid = F_ldid(name);
						if (BADFLDID == fldid)
						{
							value = CF_find(p_fb, fldid, 0, NULL, FLD_STRING);
							if ( value )
							{
								ret |= uri_store(uri, value, "");
								F_del(p_fb, fldid, 0);
							}
						}
					}
					p = q+1;
				}
				else
				{
					ret = FAIL;
				}
				param = NULL;
				break;
		}
	}
	
	/* find what separator is needed for adding parameter */
	char s = '\0';
	if (*q)
	{
		++q;
		if(*q)
		{
			q += strlen(q);
			if (q[-1] != '&')
				s = '&';
		}
	}
	else
	{
		s = '?';
	}
	
	/* copy whole URI with query string */
	ret |= sldata_output_data(uri, p, q-p);
	
	/* add FML32 to query string for GET and DELETE methods */
	if (http_method_post > method)
	{
		ret |= jsonif_get_params_fml32(uri, p_fb, s);
	}
	
	/* add EOS */
	ret |= sldata_output_data(uri, "", 1);

	return ret;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	  Processing JSON client calls using Tuxedo Fielded Buffer
 *
 * @param[out]	  clt JSON Interface Web Client
 * @param[in,out] pp_fb Fielded buffer
 * @param[in,out] size  Size of String buffer
 *
 * @retval	  SUCCEED
 * @retval	  FAIL
 */
/*------------------------------------------------------------------------*/
ctxprivate int jsonif_process_fml32(jsonif_client_t *clt, FBFR **pp_fb, long size)
{
	int	ret = SUCCEED;
	static	char	uri_buf[URI_SIZE];
	sldata_t uri;
	UNUSED(size);
	
	if (*pp_fb)
	{
		DBG_DUMPFB(dbg_progdetail,"Input FB", *pp_fb);
		DBG_FBDIFFSTART(*pp_fb);
	}
	else
	{
		DBG_PRINTF((dbg_progdetail,"No Input FML32"));
	}

	/* prepare uri */
	sldata_init(&uri, uri_buf, sizeof(uri_buf));
	ret = jsonif_get_uri_fml32(&uri, clt->uri, *pp_fb, clt->param.method);
	
	/*  prepare HTML */
	ret |= http_output_request_headers(&clt->webclt.writer, 
		clt->param.method, &clt->addr, clt->uri,
		M_agent_name, clt->content_type, "");
	if (ret)
	{
		DBG_PRINTF((dbg_syserr, "Wrong parameters: method=%d, uri=%s, "
			"agent=%s, content_type=%s", 
		clt->param.method, clt->uri, M_agent_name, clt->content_type ));
	}
	
	/* write data */
	if ((SUCCEED == ret) && *pp_fb)
	{
		switch (clt->param.method)
		{
			case http_method_post:
			case http_method_put:
				ret |= jsonfb_output_json(&clt->webclt.writer.databuf, *pp_fb);
				break;
			
			default:
				if (F_num(*pp_fb))
				{
					DBG_PRINTF((dbg_progdetail,"For HTTP %s METHOD "
						"Input FML32 will be ignored", 
						G_http_method_name[clt->param.method]));
				}
				break;
		}
	}
	ret |= http_output_footer(&clt->webclt.writer);
	
	if ( SUCCEED == ret )
		ret = webif_call(&clt->webclt);

	/* prepare empty output fielded buffer */
	if (*pp_fb)
	{
		if ( FAIL == F_init(*pp_fb, (FLDLEN)F_sizeof(*pp_fb)) )
		{
			DBG_PRINTF((dbg_syserr, "F_init failed: %d (%s)",
				F_errno(), F_strerror(F_errno())));
			ret = FAIL;
		}
	}
	else
	{
		*pp_fb = (FBFR *)ntp_alloc("FML32", NULL, 0);
		if (*pp_fb)
		{
			size = ntp_types((char *)*pp_fb, NULL, NULL);
		}
		else
		{
			DBG_PRINTF((dbg_fatal, "Failed to alloc FB"));
			ret = FAIL;
		}
	}

	/* prepare Tuxedo Fielded Buffer */
	if ( SUCCEED == ret )
	{
		if (clt->webclt.parser.content_size)
		{
			ntp_free((char *)*pp_fb);
			
			/* alloc FB */
			*pp_fb = (FBFR *)ntp_alloc("FML32", NULL, TUXEDO_BUFFER_SIZE);
			if (*pp_fb)
			{
				/* JSON to FB */
				ret = jsonfb_read_json(&(clt->webclt.parser), *pp_fb);
				DBG_DUMPFB(dbg_progdetail,"Output FB", *pp_fb);
			}
			else
			{
				DBG_PRINTF((dbg_fatal, "Failed to alloc FB"));
				ret = FAIL;
			}
		}
	}

	/* print difference */
	if (*pp_fb)
	{
		DBG_FBDIFFEND(*pp_fb,DIFF_OPEN);
	}

	return ret;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	  Prepare query string with parameters from string buffer
 *
 * @param[in,out] uri HTTP output with output data.
 * @param[in]	callinfo Callinfo with parameters.
 * @param[in]	sep Separator before added parameters.
 *
 * @retval	  SUCCEED
 * @retval	  FAIL
 */
/*------------------------------------------------------------------------*/
ctxprivate int jsonif_get_params_string(sldata_t *uri, FBFR *callinfo, char sep)
{
	int	ret = SUCCEED;
	char	s = sep;
	
	/* add rest of parameters */
	int num = callinfo_num_parameter(callinfo);
	DBG_PRINTF((dbg_progdetail, "Number of parameters: %d", num));
	
	for (int i=0; i<num; ++i)
	{
		const char *param = NULL;
		const char *value = NULL;
		
		callinfo_find_parameter(callinfo, i, &param, &value);
		DBG_PRINTF((dbg_progdetail, "Parameter %d: %s = %s", i+1, param, value));
		
		if (s)
		{
			ret |= sldata_output_data(uri, &s, 1);
		}
		
		ret |= uri_store(uri, param, "/?");
		ret |= sldata_output_data(uri, "=", 1);
		ret |= uri_store(uri, value, "/?=");
		
		/* separator for the next parameter */
		s = '&';
	}

	return ret;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	  Prepare URI
 *
 * @param[in,out] uri HTTP output with output data.
 * @param[in]	  uri_template URI template
 * @param[in,out] p_sb Tuxedo string buffer with callinfo.
 *
 * @retval	  SUCCEED
 * @retval	  FAIL
 */
/*------------------------------------------------------------------------*/
ctxprivate int jsonif_get_uri_string(sldata_t *uri, const char *uri_template, char *p_sb)
{
	int	ret = FAIL;
	FBFR	*callinfo;
	
	/* get meta data */
	callinfo = callinfo_alloc();
	if( callinfo )
	{
		ret = callinfo_get(p_sb, &callinfo);
		
		const char *p = uri_template;
		const char *q;
		const char *param = NULL;
		const char *value;
		int occ;
		char name[HTTPQUERY_PARAM_NAME_BUFSIZE];
		unsigned long len;
		
		/* process path */
		for( q=p; *q && *q!='?'; ++q)
		{
			switch(*q)
			{
				case '{': // open
					if (!param)
					{
						ret |= sldata_output_data(uri, p, q-p);
						p = q;
					}
					else
					{
						ret = FAIL;
					}
					param = q+1;
					break;
				
				case '}': // close
					if (param)
					{
						len = q-param;
						if (len >= sizeof(name) )
						{
							len = sizeof(name) - 1;
							DBG_PRINTF((dbg_syswarn, "Parameter name [%s] truncated", param));
						}
						memcpy(name, param, len); 
						name[len] = '\0';
						
						if (!httpquery_decode(name))
						{
							occ = callinfo_findocc_parameter(callinfo, name, &value);
							if ( FAIL< occ )
							{
								ret |= uri_store(uri, value, "");
								callinfo_del_parameter(callinfo, occ);
							}
						}
						p = q+1;
					}
					else
					{
						ret = FAIL;
					}
					param = NULL;
					break;
			}
		}
		
		/* find what separator is needed for adding parameter */
		char s = '\0';
		if (*q)
		{
			++q;
			if(*q)
			{
				q += strlen(q);
				if (q[-1] != '&')
					s = '&';
			}
		}
		else
		{
			s = '?';
		}
		
		/* copy whole URI with query string */
		ret |= sldata_output_data(uri, p, q-p);
		
		/* add rest of parameters */
		ret |= jsonif_get_params_string(uri, callinfo, s);
		
		/* add EOS */
		ret |= sldata_output_data(uri, "", 1);
		
		ntp_free((char *)callinfo);
	}

	return ret;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	  Processing JSON client calls using Tuxedo String Buffer
 *
 * @param[out]	  clt JSON Interface Web Client
 * @param[in,out] pp_sb String buffer
 * @param[in,out] size  Size of String buffer
 *
 * @retval	  SUCCEED
 * @retval	  FAIL
 */
/*------------------------------------------------------------------------*/
ctxprivate int jsonif_process_string(jsonif_client_t *clt, char **pp_sb, long size)
{
	int	ret = SUCCEED;
static	char	uri_buf[URI_SIZE];
	sldata_t uri;
	char	add_headers[ADD_HEADERS_BUFFER_SIZE] = { EOS };
	slbuffer_t sl_headers = SLBUFFER_STATIC_INIT_SIZEOF(add_headers);
	char *source = *pp_sb;
	char buffer[TUXEDO_BUFFER_SIZE];
	slbuffer_t slbuffer = SLBUFFER_STATIC_INIT_SIZEOF(buffer);
	int len;
	const char *type;
	char *type_encrypted = "application/apis.cortex.encryption+json";

	if (source)
	{
		DBG_DEVPRINTF((dbg_progdetail,"Input text:\n%s", source));
	}
	else
	{
		DBG_PRINTF((dbg_progdetail,"No Input text"));
	}
	
	/* prepare uri */
	sldata_init(&uri, uri_buf, sizeof(uri_buf));
	ret = jsonif_get_uri_string(&uri, clt->uri, *pp_sb);
	
	/* prepare additional headers */
	ret = jsonif_get_add_headers(&sl_headers, *pp_sb);
	DBG_DEVPRINTF((dbg_progdetail,"Additional HTTP headers: [%s]", add_headers));
	
	/*  prepare HTML */
	ret |= http_output_request_headers(&clt->webclt.writer, 
		clt->param.method, &clt->addr, uri_buf,
		M_agent_name, clt->content_type, add_headers);

	if ( source )
	{
		len = strlen(source);
		/* prepare encrypted content */
		if ( 0 < len && clt->webclt.writer.encrypted)
		{
			ret = jwe_encrypt(source, len, clt->webclt.writer.header_alg, &slbuffer);
			if ( SUCCEED == ret )
			{
				source = slbuffer.data;
				len = slbuffer.position;
			}
		}
	}
	
	if ((SUCCEED == ret) && source)
	{
		switch (clt->param.method)
		{
			case http_method_post:
			case http_method_put:
				ret |= sldata_output_data(&clt->webclt.writer.databuf, 
					source, len);
				break;
			
			default:
				if (**pp_sb)
				{
					DBG_PRINTF((dbg_progdetail,"For HTTP %s METHOD "
						"Input text will be ignored", 
						G_http_method_name[clt->param.method]));
				}
				break;
		}
	}
	ret |= http_output_footer(&clt->webclt.writer);


	if ( SUCCEED == ret )
		ret = webif_call(&clt->webclt);

	/* prepare empty output string buffer */
	if (*pp_sb)
		**pp_sb = EOS;
	else
	{
		*pp_sb = ntp_alloc("STRING", NULL, 0);
		if (*pp_sb)
		{
			size = ntp_types(*pp_sb, NULL, NULL);
			**pp_sb = EOS;
		}
		else
		{
			DBG_PRINTF((dbg_fatal, "Failed to alloc SB"));
			ret = FAIL;
		}
	}
	
	/* return data */
	if ( SUCCEED == ret )
	{
		if ( clt->webclt.parser.content_size )
		{
			source = clt->webclt.parser.buffer + clt->webclt.parser.header_size;
			len = clt->webclt.parser.content_size;
			
			type = jsonif_get_content_type(clt);
			DBG_PRINTF((dbg_progdetail, "Response content type: [%s]", type));
			if ( !strncmp(type, type_encrypted, strlen(type_encrypted)) )
			{
				/* It is ok to receive encrypted content even if not expecting */
				clt->webclt.parser.encrypted = TRUE;
			}
			else if ( clt->webclt.parser.encrypted )
			{
				DBG_PRINTF((dbg_syserr, 
					"The response was expected to be encrypted, but content type is: [%s]",
					type));
				ret = FAIL;
				clt->webclt.parser.encrypted = FALSE;
			}
			/* Decrypt response */
			if ( clt->webclt.parser.encrypted )
			{
				slbuffer_reset(&slbuffer);
				ret = jwe_decrypt(source, len, &slbuffer, NULL);
				if ( SUCCEED == ret )
				{
					source = slbuffer.data;
					len = slbuffer.position;
				}
			}
			
			if ( SUCCEED == ret )
			{
				/* is buffer big enough */
				if ( size <= len )
				{
					ntp_free(*pp_sb);
					
					/* alloc SB */
					size = len + sizeof(char);
					*pp_sb = ntp_alloc("STRING", NULL, size);
					if (!*pp_sb)
					{
						DBG_PRINTF((dbg_fatal, "Failed to alloc SB"));
						ret = FAIL;
					}
				}
			}
			
			/* copy data */
			if ( SUCCEED == ret )
			{
				if (slmemcpy_s(*pp_sb, size-1, source, len))
				{
					ret = FAIL;
					DBG_PRINTF((dbg_syserr, "Not enough space for response"));
				}
				else
				{
					(*pp_sb)[len] = EOS;
					DBG_DEVPRINTF((dbg_progdetail,"Output text:\n%s", *pp_sb));
				}
			}
		}
	}

	return ret;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	  Add call info
 *
 * @param[out]	  clt JSON Interface Web Client
 *
 * @return	  Content type or NULL
 */
/*------------------------------------------------------------------------*/
ctxprivate const char *jsonif_get_content_type(jsonif_client_t *clt)
{
	const char *ret = NULL;
	
	if (clt->webclt.parser.content_type_offset)
	{
		ret = clt->webclt.parser.buffer + clt->webclt.parser.content_type_offset;
		while ( ' ' == *ret || '\t'== *ret )
			++ret;
		if (!*ret)
			ret = NULL;
	}

	return ret;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	  Add call info
 *
 * @param[out]	  clt JSON Interface Web Client
 * @param[in,out] p_tb Tuxedo buffer
 *
 * @retval	  SUCCEED
 * @retval	  FAIL
 */
/*------------------------------------------------------------------------*/
ctxprivate int jsonif_add_call_info(jsonif_client_t *clt, char *p_tb)
{
	int	ret = FAIL;
	FBFR	*callinfo;
	const char *type;
	
	/* add call info */
	callinfo = callinfo_alloc();
	if (callinfo)
	{
		/* set status line */
		callinfo_set_status_line(callinfo, 
			clt->webclt.parser.buffer + clt->webclt.parser.status_offset);
		
		/* set content type */
		if (clt->webclt.parser.encrypted)
		{
			/* Assuming that after decryption we have plain JSON */
			callinfo_set_content_type(callinfo, "application/json; charset=UTF-8");
		}
		else
		{
			type = jsonif_get_content_type(clt);
			if (type)
			{
				callinfo_set_content_type(callinfo, type);
			}
		}
		
		/* set the meta data attributes */
		ret = callinfo_set(p_tb, callinfo);
		
		tpfree((char *)callinfo);
	}
	else
	{
		DBG_PRINTF((dbg_syserr, "Memory allocation failed: %d:%s",
			ntp_errno(), ntp_strerror(ntp_errno())));
	}

	return ret;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	  Prepare additional HTTP headers
 *
 * @param[out]	  sl_headers buffer for headers.
 * @param[in]	  p_sb Tuxedo string buffer with callinfo.
 *
 * @retval	  SUCCEED
 * @retval	  FAIL
 */
/*------------------------------------------------------------------------*/
ctxprivate int jsonif_get_add_headers(slbuffer_t *sl_headers, char *p_sb)
{
	int	ret = FAIL;
	FBFR	*callinfo = NULL;
	int	num = 0;
	int	i;
	char header[HTTP_HEADER_NAME_SIZE];
	char value[HTTP_HEADER_VALUE_SIZE];
	slbuffer_t sl_header = SLBUFFER_STATIC_INIT_SIZEOF(header);
	slbuffer_t sl_value = SLBUFFER_STATIC_INIT_SIZEOF(value);
	
	/* get meta data */
	callinfo = callinfo_alloc();
	if( callinfo )
	{
		ret = callinfo_get(p_sb, &callinfo);
	}

	if ( SUCCEED == ret )
	{
		num = callinfo_num_header(callinfo);
		for ( i = 0; SUCCEED == ret && i < num; i++)
		{
			ret = callinfo_get_header(callinfo, i, &sl_header, &sl_value);
			if ( SUCCEED == ret )
			{
				if ( !jsonif_filtered_header(header, value) )
				{
					slbuffer_append_printf(sl_headers, "%s: %s\r\n",
						header, value);						
				}
			}
			
			slbuffer_reset(&sl_header);
			slbuffer_reset(&sl_value);
		}
	}
		
	if( callinfo )
	{
		ntp_free((char *)callinfo);
		callinfo = NULL;
	}

	return ret;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	  Check if header should be filtered - skipped from adding 
 *		  to HTTP request.
 *
 * @param[in]	  header HTTP header name.
 *
 * @retval	  TRUE
 * @retval	  FALSE
 */
/*------------------------------------------------------------------------*/
ctxprivate int jsonif_filtered_header(const char* header, const char* value)
{
	int ret = FALSE;
	
	if (!slstrcicmp(header, "Host"))
	{
		DBG_PRINTF((dbg_syswarn, "Host is defined through configuration. "
			"Skipping HTTP header [%s] with value [%s]. ", 
			header, value ));
		ret = TRUE;
	}
	else if (!slstrcicmp(header, "User-Agent"))
	{
		DBG_PRINTF((dbg_syswarn, "Agent is defined through configuration. "
			"Skipping HTTP header [%s] with value [%s]. ", 
			header, value ));
		ret = TRUE;
	}
	else if (!slstrcicmp(header, "Content-Type"))
	{
		DBG_PRINTF((dbg_syswarn, "Content type is defined through configuration or special functions. "
			"Skipping HTTP header [%s] with value [%s]. ", 
			header, value ));
		ret = TRUE;
	}
	else if (!slstrcicmp(header, "Access-Control-Allow-Origin"))
	{
		DBG_PRINTF((dbg_syswarn, "Access-Control-Allow-Origin is always *. "
			"Skipping HTTP header [%s] with value [%s]. ", 
			header, value ));
		ret = TRUE;
	}
	else if (!slstrcicmp(header, "Connection"))
	{
		DBG_PRINTF((dbg_syswarn, "Connection is defined through configuration. "
			"Skipping HTTP header [%s] with value [%s]. ", 
			header, value ));
		ret = TRUE;
	}
	else if (!slstrcicmp(header, "Content-Length"))
	{
		DBG_PRINTF((dbg_syswarn, "Content length is calculated. "
			"Skipping HTTP header [%s] with value [%s]. ", 
			header, value ));
		ret = TRUE;
	}	
	else
	{
		/* for sonar */
	}	
	
	return ret;
}

/** @endcond */

/*------------------------------------------------------------------------*/
/**
 * @brief	  Initialisation routine for BPDJSONIF service
 *
 * @param[in]	  fp Configuration file
 * @param[in]	  subsect Subsection name
 *
 * @retval	  SUCCEED   Initialised OK
 * @retval	  FAIL   Failed to initialise
 */
/*------------------------------------------------------------------------*/
ctxpublic int bpdjsonifsvc_init(FILE *fp, char *subsect)
{
	static cfp_parm cfp[] =
	{
		{"DEBUG", parm_int, 0, FALSE, (void *)&M_dbglev, 0},
		{"DBGBUF", parm_int, 0, FALSE, (void *)&M_dbgbuf, 0},
		{"DBGFILE", parm_string, sizeof(M_dbgfile), FALSE, (void *)&M_dbgfile, 0},
		{"MAPPING", parm_string, sizeof(svcmap_param.sect),
			FALSE,	(void *)svcmap_param.sect, 0},
		{"CHARSET", parm_string, sizeof(M_charset),
			FALSE,	&M_charset, 0},
		{"JWE", parm_string, sizeof(M_jwecnf.jwe_sect),
			FALSE,	(void *)M_jwecnf.jwe_sect, 0},			
		{0}
	};
	
	static cfp_parm *pp_cfp[2] = {webif_cfp_parm, cfp};
	
	int ret = SUCCEED;
	const char *service;
	svcmap_iter_t iter;

	fprintf(stderr, "bpdjsonif_init start with %s %s (%s)\n", TAGNAME, subsect, cfp_errparm());
	
	jwecnf_set_defaults(&M_jwecnf);	
	ret = cfp_parse_mult(fp, pp_cfp, 2, TAGNAME, subsect);
	
	if (SUCCEED == ret)
	{
		ret = svcmap_check_params(fp);
		if (SUCCEED == ret)
		{
			webif_check_params(fp);
		}
		
		if ( SUCCEED == ret )
		{
			DBG_PRINTF((dbg_progdetail, "Set Tuxedo [%s] character set.", M_charset ));
			ret = sluconv_set_chars_to_uft8(M_charset);
			if( ret )
			{
				DBG_PRINTF((dbg_syserr, "Unsupported conversion from [%s] character set to [UTF-8].", M_charset ));
			}
		}
		
		if ( SUCCEED == ret )
		{
			ret = sluconv_set_uft8_to_chars(M_charset);
			if( ret )
			{
				DBG_PRINTF((dbg_syserr, "Unsupported conversion to [%s] character set from [UTF-8].", M_charset ));
			}
		}

		if (SUCCEED == ret)
		{
			ret = jwecnf_init(fp, &M_jwecnf);
		}
	}
	
	/* show usage */
	if (SUCCEED != ret)
	{
		fputs(M_jsonif_cfp_usage, stderr);
		fputs(tcpssl_cfp_usage,stderr);
	}
	
	if (SUCCEED == ret)
	{
		service = svcmap_first(&iter);
		if ( service )
		{
			do
			{
				if (FAIL == ntp_advertise((char *)service, BPDJSONIF))
				{
					DBG_PRINTF((dbg_syserr, "tpadvertise %s failed %d %s",
						BPDJSONIFSVC, ntp_errno(), ntp_strerror(ntp_errno())));
					ret = FAIL;
					break;
				}
				
				service = svcmap_next(&iter);
			} while( service );
		}
	}
	
	return ret;
}

