/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Interface for fast map of Tuxedo service to REST service.
 *
 * @author	Raul Torres
 * @author	David Leyva
 * @date	17 April 2024
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-2.0/src/des/src/bpdjsonif/bpdjsonifsvc.h#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __BPDJSONIFSVC_H
#define __BPDJSONIFSVC_H

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-------------------------------------*/

#include <webif.h>
#include <svcmap.h>

/*---------------------------Externs--------------------------------------*/
/*---------------------------Macros---------------------------------------*/
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/

/** Tuxedo interface client. */
typedef struct jsonif_client
{
	/** Web server client. */
	webif_client_t webclt;
	
	/** Service parameters. */
	svcmap_value_t param;
	
	/** Content type HTTP header value */
	const char *content_type;
	
	/** Parsed address */
	http_addr_t addr;
	/** URI part of address */
	const char *uri;

} jsonif_client_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/

extern int bpdjsonifsvc_init(FILE *fp, char *subsect);

#ifdef __cplusplus
}
#endif

#endif
