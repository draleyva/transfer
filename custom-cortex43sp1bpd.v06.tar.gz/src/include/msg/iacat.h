/*-----------------------------------------------------------------------
 *
 * File		: iacat.h
 *
 * Author	: Perl /
 *
 * Created	: 19 Mar 24  07:33
 *
 * Purpose	: Mapping between messages and #defined used in 4GL scripts
 *
 * Comments	:
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __IACAT_H
#define __IACAT_H
/* #ident "%W%   %E%   %U%" */

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Macros-------------------------------------*/


#define CUSTACC_DEL_FAIL 1
#define INVAL_ACC_TYPE 2
#define INVAL_ACC_STAT 3
#define ACCLEN_MUST_BE 4
#define ACC_STAT_EXIST 5
#define ACC_TYPE_EXIST 6
#define LEN_1_15 7
#define CRDPROD_NOT_ISS 8
#define CRD_STAT_EXIST 9
#define INVAL_VALUES 10
#define STAT_NOT_CHANGED 11
#define STAT_UPD_FAIL 12
#define HIST_ADD_FAIL 13
#define ACC_NO_INVAL 14
#define REPTYPE_DENY 15
#define REPTYPE_SUSP 16
#define REPTYPE_FULL 17
#define REPTYPE_ERR 18
#define IID_EXIST 19
#define IID_INVALID 20
#define ACC_TYPE_INVAL 21
#define CRDPROD_INVALID 22
#define CRD_OUT_RANGE 23
#define CRD_STAT_INVALID 24
#define CHOOSE_CUST_FIRST 25
#define CHOOSE_CARD_FIRST 26
#define ACCOUNT_NOT_FILE 27
#define ACCOUNT_ON_FILE 28
#define CUSTOMER_NOT_FILE 29
#define CUSTOMER_ON_FILE 30
#define CARD_NOT_FILE 31
#define CARD_ON_FILE 32
#define ACCOUNT_IS_LINKED 33
#define PINBLK_NOT_VALID 34
#define DFT_IA_CURR_CODE 35
#define EXPDATE_GT_EFF 36
#define EXTRACTING_CARDS 37
#define UPDATING_CARDS 38
#define CARDS_PROD_OK 39
#define PINS_PROD_OK 40
#define EXTRACTING_PINS 41
#define UPDATING_PINS 42
#define FIRST_TRACK_CHAR 43
#define LAST_TRACK_CHAR 44
#define CVVLEN_3 45
#define EXPIRYLEN_4 46
#define LANGLEN_1 47
#define PVKILEN_1 48
#define PVKI_AND_PVV 49
#define LEN_0_15 51
#define AUTO_ADD_ACC 52
#define PANFMT_LEN 53
#define LEN_0_28 54
#define CURR_INVALID 55
#define ACTLIM_NOT_EXIST 56
#define GENERATE_ANYWAY 57
#define ENCKEY_NOT_EXIST 58
#define GENERATE_ANYWAY_1 59
#define VISA_EXCEPTION_FILE 60
#define CRDBTCH_STATUS_BASE 90
#define BTCH_OPEN_DSCR 91
#define BTCH_CLOSED_DSCR 92
#define BTCH_EXTRACTED_DSCR 93
#define BTCH_CRD_PRD_DSCR 94
#define BTCH_PIN_PRD_DSCR 95
#define BTCH_PINCRD_PRD_DSCR 96
#define BTCH_ISSUED_DSCR 97
#define CHQBKREQ_TAG 100
#define TXNACC_TAG 101
#define STMREQ_TAG 102
#define	LOGONLY_BASE	150
#define LOGONLY_CHEQUE 151
#define LOGONLY_STMT 152
#define	HOST_STAT_BASE	190
#define HOST_STAT_OFFLINE 190
#define HOST_STAT_ONLINE 191
#define HOST_STAT_SYNC 192
#define HOST_STAT_SYNCOFF 193
#define CPRD_INPUT 200
#define CPRD_REPORT 201
#define CPRD_CREATE 202
#define CPRD_PINPR 203
#define CPRD_CLOSE 204
#define CPRD_RPLCARD 205
#define CPRD_NEWPIN 206
#define CPRD_SPARE4 207
#define MAKE_ONE 210
#define MAKE_SEL 211
#define PVVLEN_4 220
#define SVCCODELEN_3 221
#define VALIDITYLEN_2 222
#define EMAREA1_FMT 223
#define PIN_LINEUP_OK 224
#define CLOSE_BATCH_OK 225
#define PIN_PRINTING 226
#define BAD_CBTCH_STAT 227
#define HOST_ON_FILE 230
#define HOST_NOT_FILE 231
#define HOST_CMD_SIGNON 232
#define HOST_CMD_SIGNOFF 233
#define HOST_CMD_ECHO 234
#define HOST_CMD_OK_CHAN 235
#define HOST_CMD_FAIL_CHAN 236
#define ACILEN_1 237
#define HOST_CHANS_1_8 238
#define HOST_CMD_DOWNLOAD 239
#define HOST_CMD_UPLOAD 240
#define DOWNLOAD_IN_PROGRESS 241
#define UPLOAD_IN_PROGRESS 242
#define CRDCUST_OPT 243
#define CRDTXN_OPT 244
#define CRDSTH_OPT 245
#define CRDPFX_IN_RANGE 246
#define PANLEN_MUSTBE 247
#define ISSLEN_MUSTBE 248
#define CRDPIN_OPT 249
#define PIN_TRIES_CHG 250
#define CALCULATING_CVV 251
#define CVV_CALC_FAILED 252
#define NAME_LE_24 253
#define HOST_CMD_VIEWUPLD 254
#define ALREADY_GOT_BATCH 255
#define ACTLIM_OPT 256
#define ADD_MORE_ACCS 257
#define NORM_OR_EMP 258
#define END_EXP_AFTER_START 259
#define ZAP_AUTH_OK 260
#define ENCCVK_OPT 261
#define ENCPVK_OPT 262
#define MARITAL_STAT 263
#define DR_CLASSNAME 264
#define CR_CLASSNAME 265
#define CRDACC_OPT 266
#define MARITAL_STAT_ACL 269
#define	EXF_STAT_BASE		270
#define EXF_STAT_NOT_PROCESSED 270
#define EXF_STAT_RSP_PENDING 271
#define EXF_STAT_PROCESSED 272
#define CLR_EXPFILE_OK 275
#define CLEARING_EXPFILE 276
#define CLR_EXPFILE_FAIL 277
#define EXPFILE_CLR_TO 278
#define DR_RENEW_OK 279
#define CRDS_USE_CORP 280
#define NOT_ALL_PINS_MADE 281
#define NOT_ALL_CARDS_MADE 282
#define NORMAL_STR 283
#define EMPLOYEE_STR 284
#define CALCULATING_PVV 285
#define PVV_CALC_FAILED 286
#define MAKE_PINS_FIRST 287
#define	FILE_CMD_DSCR_BASE	290
#define FILE_CMD_DSCR_DO_NOTHING 290
#define FILE_CMD_DSCR_ADD 291
#define FILE_CMD_DSCR_UPD 292
#define FILE_CMD_DSCR_DEL 293
#define FILE_CMD_DSCR_INQ 294
#define GENERATE_NEW_IID 295
#define	MTHCLT_ERR_BASE 300
#define CRDPROD_TYPE_BASE 350

#ifdef __cplusplus
}
#endif

#endif
