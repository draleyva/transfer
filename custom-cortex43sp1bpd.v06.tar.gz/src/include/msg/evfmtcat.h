/*-----------------------------------------------------------------------
 *
 * File		: evfmtcat.h
 *
 * Author	: Perl /
 *
 * Created	: 19 Mar 24  07:33
 *
 * Purpose	: Mapping between messages and #defined used in 4GL scripts
 *
 * Comments	:
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __EVFMTCAT_H
#define __EVFMTCAT_H
/* #ident "%W%   %E%   %U%" */

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Macros-------------------------------------*/


#define EVFMT_STR 1
#define EVFMT_MODEMFAIL 2
#define EVFMT_SVCFAIL 3
#define EVFMT_CONVFAIL 4
#define EVFMT_BACKUPFAIL 5
#define EVFMT_BACKUPCHG 6
#define EVFMT_BACKUPOK 7
#define EVFMT_FILERR 8
#define EVFMT_CMDERR 9
#define EVFMT_ENVERR 10
#define EVFMT_CONFIGERR 11
#define EVFMT_STARTUPFAIL 12
#define EVFMT_SHUTDOWNFAIL 13
#define EVFMT_DBOPENFAIL 14
#define EVFMT_BEGINFAIL 15
#define EVFMT_COMMITFAIL 16
#define EVFMT_DBFATAL 17
#define EVFMT_SYSTEMERR 18
#define EVFMT_TPALLOCFAIL 19
#define EVFMT_FALLOCFAIL 20
#define EVFMT_CARDRANGE 21
#define EVFMT_ZAPOK 22
#define EVFMT_ARCHOK 23
#define EVFMT_RESETTERM 24
#define EVFMT_RESETTERMOK 25
#define EVFMT_ATMHCMERR 26
#define EVFMT_ATMHCMOK 27
#define EVFMT_ATMSUPLOW 28
#define EVFMT_ATMSUPOUT 29
#define EVFMT_ATMDVCERR 30
#define EVFMT_ATMDVCSTA 31
#define EVFMT_ATMALARM 32
#define EVFMT_ATMAMBUSH 33
#define EVFMT_ATMBURGLE 34
#define EVFMT_ATMDVCOK 35
#define EVFMT_LOCKFAIL 36
#define EVFMT_ENCFILE 37
#define EVFMT_ENCSEED 38
#define EVFMT_ENCSTART 39
#define EVFMT_ENCPINFRMT 40
#define EVFMT_ENCDBERR 41
#define EVFMT_ENCPINXFER 42
#define EVFMT_ENCKEYGEN 43
#define EVFMT_ENCKEYCHECK 44
#define EVFMT_ENCGENPAR 45
#define EVFMT_ENCZMKCREATE 46
#define EVFMT_ENCKEYTRAN 47
#define EVFMT_PINGFAIL 50
#define EVFMT_BALHDR 51
#define EVFMT_BALHLB 52
#define EVFMT_BALTRL 53
#define EVFMT_BALCNT 54
#define EVFMT_BALVAL 55
#define EVFMT_BALACRD 56
#define EVFMT_BALCUR 57
#define EVFMT_BALACWR 58
#define EVFMT_BALFMT 59
#define EVFMT_BALSTRD 60
#define EVFMT_BALINST 61
#define EVFMT_BALDTRD 62
#define EVFMT_COMCTX 63
#define EVFMT_COMHOST 64
#define EVFMT_CONV 65
#define EVFMT_BADMSG 66
#define EVFMT_UPLSYNC 70
#define EVFMT_UPLSCAN 71
#define EVFMT_UPLREAD 72
#define EVFMT_UPLONL 73
#define EVFMT_UPLHOST 74
#define EVFMT_UPLHUPD 75
#define EVFMT_UPLTNEW 76
#define EVFMT_UPLTGET 77
#define EVFMT_UPLMADV 78
#define EVFMT_UPLUDEL 79
#define EVFMT_UPLUREJ 80
#define EVFMT_UPLUUPD 81
#define EVFMT_ENCZPKTMK 82
#define EVFMT_VIADMIN 83
#define EVFMT_VISTATID 84
#define EVFMT_VIREJCODE 85
#define EVFMT_VIMSGQUE 86
#define EVFMT_VIPOLLERR 87
#define EVFMT_VICOMOK 88
#define EVFMT_VIVICLT 89
#define EVFMT_PALOWCOM 90
#define EVFMT_PABTCHSRV 91
#define EVFMT_PASUSMRCH 92
#define EVFMT_PADUPBTCH 93
#define EVFMT_PASTARTDRV 94
#define EVFMT_PASIGNAL 95
#define EVFMT_PADEADDRV 96
#define EVFMT_VINAPERR 97
#define EVFMT_VILOWCOM 98
#define EVFMT_VIMSGCNV 99
#define EVFMT_PAMISSTRM 100
#define EVFMT_PAMISSMRCH 101
#define EVFMT_COSYSDATE_OK 102
#define EVFMT_COSYSDATE_ERR 103
#define EVFMT_MTHMSGQUE 104
#define EVFMT_MTHPOLLERR 105
#define EVFMT_MTHCOMOK 106
#define EVFMT_MTHCLT 107
#define EVFMT_CODATEREC_OK 108
#define EVFMT_CODATEREC_ERR 109

#ifdef __cplusplus
}
#endif

#endif
