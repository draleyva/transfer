/*-----------------------------------------------------------------------
 *
 * File		: cccat.h
 *
 * Author	: Perl /
 *
 * Created	: 19 Mar 24  07:33
 *
 * Purpose	: Mapping between messages and #defined used in 4GL scripts
 *
 * Comments	:
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __CCCAT_H
#define __CCCAT_H
/* #ident "%W%   %E%   %U%" */

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Macros-------------------------------------*/


#define CCAPPSTAT_0_2 1
#define CCAPPL_NUM 2
#define CCAPPL_CUST 3
#define CCAPPL_CARD 4
#define CCAPPL_ACC 5
#define CCAPP_APPROVE_FIRST 6
#define CCAPP_SET_COMPLETE 7
#define CCAPP_NOT_REPEND 8
#define CCAPPL_ACFIN 9
#define CCAPPL_ACHST 10
#define CCAPPL_STMT 11
#define CC_NO_CYCLE 12
#define CC_SOL_APROB 13
#define CC_CTA_APROB 14
#define CCAPPL_CHG 15
#define CCAPPL_AUTH 16
#define CC_OK_EOD 25
#define CC_EOD_PASS1 26
#define CC_EOD_PASS2 27
#define CC_NO_DEBIT_ACCNO 28
#define CC_CANT_BOUNCE 29
#define CC_BOUNCE_OK 30
#define CC_COMMENT 31
#define CC_PAY_PASS1 32
#define CC_PAY_PASS2 33
#define CC_OK_CYCLE 34
#define CC_CYCLE_PASS1 35
#define CC_CYCLE_PASS2 36
#define CC_LAST_STMT 37
#define CC_FIRST_STMT 38
#define CC_ISSUE_OK 39
#define CC_RENEW_OK 40
#define CC_TYPE_CHG_ERR 41
#define CC_PAY_LIST 42
#define CC_CC_ADJUST 43
#define CCRNWRPT_TAG 152
#define CCFOLRPT_TAG 153
#define CCAPPRPT_TAG 154
#define CCSTMRPT_TAG 155
#define CCPBLRPT_TAG 156
#define CCNRWRPT_TAG 157
#define CCDUXRPT_TAG 158
#define CCBVLRPT_TAG 159
#define CCEDRRPT_TAG 160
#define CCLBLRPT_TAG 161
#define CCRAPRPT_TAG 162
#define CCHTXRPT_TAG 163
#define CCCLXRPT_TAG 164
#define CCBALRPT_TAG 165
#define CCNCARPT_TAG 166
#define CCABSRPT_TAG 167
#define CCAPYRPT_TAG 168
#define CCVOORPT_TAG 169
#define	CACCHQDSC_BASE 170
#define CACCHQDSC_0 170
#define CACCHQDSC_1 171
#define CACCHQDSC_9 179
#define CCBOURPT_TAG 180
#define CCPCURPT_TAG 181
#define CCODURPT_TAG 183
#define CCDBTRPT_TAG 184
#define CCDDRRPT_TAG 185
#define CCOLIRPT_TAG 186
#define CCINCRPT_TAG 187
#define CCPSMRPT_TAG 188
#define CCEODRPT_TAG 189
#define CCCYBRPT_TAG 191
#define CCOVIRPT_TAG 192
#define CCODPRPT_TAG 193
#define CCSTDRPT_TAG 194
#define CCPCMRPT_TAG 195
#define CCCBZRPT_TAG 197
#define CCCHBRPT_TAG 199
#define CCE_COMM_OVER_LIM 200
#define CCE_COMM_FINANCE 201
#define CCE_COMM_REDEEM 202
#define CCE_COMM_OVER_DUE 203
#define CCE_COMM_INTL_SVC 204
#define CCE_COMM_REDEEMABLE 205
#define CCISFRPT_TAG 220
#define CC_DATE_MMDD 300
#define CC_INVALID_CCTXN 316
#define CC_CASH_DESCR 317
#define CC_DDEBIT_DESCR 318
#define CC_OURCHQ_DESCR 319
#define CC_FORCHQ_DESCR 320
#define CC_ZAP_AUTHS_OK 321
#define CC_ZAP_AUTHS_P1 322
#define CC_ZAP_AUTHS_P2 323
#define CC_ZAP_LT_NOW 324
#define CC_REPLACE_OK 325
#define CC_RPL_BADSTAT 326
#define CC_BAL_MUST_0 327
#define CC_BTCH_BADGRP 328
#define CC_OLDSTAT_BAD 329
#define CC_BTCH_OPEN 330
#define CC_ALREADY_REPLACED 331
#define CC_OVRD_DSC_BASE	340
#define CC_OVRD_DSC_0 340
#define CC_OVRD_DSC_1 341
#define CC_OVRD_DSC_2 342
#define CC_OVRD_DSC_3 343
#define CC_OVRD_DSC_4 344
#define CC_BAD_OVRD_STAT 350
#define CC_USE_CRD_STAT 351
#define CC_UNK_ACC_STAT 352
#define CC_ACS_ACCSTAT 353
#define CC_ACS_LISTSTAT 354
#define CC_ACCSTAT_NOMANCLR 355
#define CC_ACCSTAT_NOMANSET 356
#define CC_NO_BATCH 357
#define CC_CRD_NOT_CURR 358
#define CC_BTCH_NOT_BAL 359
#define CC_CYCLE_EXISTS 361
#define CC_DATE_1_28 362
#define CC_NXT_CYC_GT_LST 363
#define CC_NEXT_CYCLE 364
#define CC_CYCLE_AGAIN 365
#define CC_ACT_BLIST 366
#define CC_ACTING_BLIST 367
#define CC_NO_ISS_SCH 368
#define CC_CHG_BLIST 369
#define CC_CHGING_BLIST 370
#define CC_OK_EOY 371
#define CC_EOY_PASS1 372
#define CC_EOY_PASS2 373
#define CC_EOY_AFTER_CYCLE 374
#define CC_ISSADD_OK 375
#define CC_ISSUING_ADD 376
#define CC_OPENING_ACC 377
#define CC_OPEN_OK 378
#define CC_ISSUING 379
#define CC_RENEWING 380
#define CC_ACS_STARTEOD 385
#define CC_ACS_ENDEOD 386
#define CC_ACS_STARTCYC 387
#define CC_ACS_ENDCYC 388
#define CC_SAME_EOD_AGAIN 389
#define CC_REC_RENEW 390
#define CC_RECING_RENEW 391
#define CC_ACS_LIFEINS 392
#define CC_ACS_CRDLIM 393
#define CC_OK_INACT 394
#define CC_INACT_PASS1 395
#define CC_INACT_PASS2 396
#define CC_ACS_STARTINACT 397
#define CC_ACS_ENDINACT 398
#define EXPF_CRD_INVALID 420
#define CC_BLIST_DAY 421
#define CC_BLIST_ALREADY 422
#define CC_BLIST_NEXIST 423
#define CC_TXN_PROCD 425
#define CCLL_IN_BATCH 426
#define CC_SAME_DAC_AGAIN 427
#define VI_OK_DAC 428
#define CC_ACS_STARTDAC 429
#define CC_ACS_ENDDAC 430
#define CC_OK_MONTH 432
#define CC_MONTH_PASS1 433
#define CC_MONTH_PASS2 434
#define CC_MONTH_AGAIN 435
#define CC_ACS_STARTMON 436
#define CC_ACS_ENDMON 437
#define CC_PRV_REFUSED 438
#define CC_STMTDLV_INVAL 439
#define CCTXNDSC_BASE	1000
#define CCTXNDSC_PURCHASE 1655
#define CCEOD_WARN_BASE 2000
#define CCEOD_ERR_BASE 2020
#define CCEOD_EXC_BASE 2050
#define VISA_0312_ERR_BASE 10000

#ifdef __cplusplus
}
#endif

#endif
