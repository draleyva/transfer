/*-----------------------------------------------------------------------
 *
 * File		: mhcat.h
 *
 * Author	: Perl /
 *
 * Created	: 19 Mar 24  07:33
 *
 * Purpose	: Mapping between messages and #defined used in 4GL scripts
 *
 * Comments	:
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __MHCAT_H
#define __MHCAT_H
/* #ident "%W%   %E%   %U%" */

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Macros-------------------------------------*/


#define INV_MENU 1
#define EMPTY_MENU 2
#define USR_CORTEX 3
#define USR_CTX_ERR 4
#define GRP_CORTEX 5
#define GRP_CTX_ERR 6
#define USR_GRP_CORTEX 7
#define USR_GRP_CTX_ERR 8
#define PERMGRP_ERR 10
#define EXPERM_ERR 11
#define PSWD_ERR 12
#define USR_ERR 13
#define NOEXIST_ERR 14
#define NO_USR 15
#define NO_USRGRP 16
#define PSWD_IND 18
#define MASK_IND 19
#define FIND_IND 20
#define UPDATE_IND 21
#define ADD_IND 22
#define DEL_IND 23
#define ACSTYPE 24
#define NOT_EMPTY 25
#define NOT_ROOT 26
#define LIMIT 27
#define MISSFRMT_ERR 28
#define EVSEVERITY_ERR 29
#define DSCR_ERROR 31
#define FORM_NOT_ALLOWED 35
#define FORM_UNKNOWN_ERR 36
#define CLR_ACSLOG_YN 37
#define CLRACSLOG_WAIT 38
#define CLRACSLOG_FAIL 39
#define CLRACSLOG_LOG 40
#define MENU_IND 41
#define NOMENU_IND 42
#define MENU_CHAR 43
#define ULOG_SH_2 45
#define CLR_EVLOG_UPTO 46
#define CLEARING_EVLOG 47
#define CLR_EVLOG_FAILED 48
#define EVLOG_CLEARED 49
#define START_APP 50
#define EXIT_APP 51
#define ACSLOG_SELECT 52
#define ACSLOG_EXIT 53
#define DUP_USER 54
#define EVRPT_TAG 55
#define SEVERITY_BASE	300
#define SEVERITY_FATAL 301
#define SEVERITY_SYSERR 302
#define SEVERITY_WARN 303
#define SEVERITY_INFO 304
#define SEVERITY_DETAIL 305
#define MH_SHELL_BASE	350
#define MSG_CLRULOG_EPARAM 351
#define MSG_CLRULOG_USAGE 352
#define MSG_CLRULOG_EEMPTY 353

#ifdef __cplusplus
}
#endif

#endif
