/*-----------------------------------------------------------------------
 *
 * File		: rccat.h
 *
 * Author	: Perl /
 *
 * Created	: 19 Mar 24  07:33
 *
 * Purpose	: Mapping between messages and #defined used in 4GL scripts
 *
 * Comments	:
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __RCCAT_H
#define __RCCAT_H
/* #ident "%W%   %E%   %U%" */

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Macros-------------------------------------*/


#define	RCPT_LANG_OFF	200		/* multiply by lang for base	*/
#define	RCPT_TCODE_OFF	100		/* add to lang base for tcode 0	*/
#define	RCPT_LOGONLY_OFF	50	/* add to lang bse fr logonly 0	*/
#define	MINISTMT_BASE	40
#define RECEIPT_TOP 1
#define RECEIPT_BOTTOM 2
#define RECEIPT_PARTIAL 3
#define RECEIPT_ZERO 4
#define RECEIPT_REJECTED 5
#define RECEIPT_CAPTURED 6
#define PRINT_TOT_HDR 10
#define PRINT_TOT_DNOM 11
#define PRINT_TOT_LOAD 12
#define PRINT_TOT_DISP 13
#define PRINT_TOT_REM 14
#define PRINT_TOT_BUF1 15
#define PRINT_TOT_BUF2 16
#define PRINT_TOT_BUF3 17
#define PRINT_TOT_BUF4 18
#define PRINT_TOT_PBUF1 19
#define PRINT_TOT_PBUF2 20
#define PRINT_TOT_PBUF3 21
#define PRINT_TOT_PBUF4 22
#define ACC_SEL_SCRFMT 30
#define RIGHT_ARROW 31
#define PPD_LINE 32
#define RC_NOT_KNOWN 33
#define ENG_MINISTMT_ATM 41
#define ENG_MINISTMT_CHQ 42
#define ENG_MINISTMT_CASH 43
#define ENG_MINISTMT_XFER 44
#define ENG_MINISTMT_SO 45
#define ENG_LOG_0 50
#define ENG_LOG_1 51
#define ENG_LOG_2 52
#define ENG_01 101
#define ENG_21 121
#define ENG_24 124
#define ENG_31 131
#define ENG_38 138
#define ENG_40 140
#define ENG_90 190

#ifdef __cplusplus
}
#endif

#endif
