/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CUSTDET_X DAO structure definitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBCUST_XDAO_H
#define __DBCUST_XDAO_H

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table CUSTDET_X
 */
typedef struct
{
	long	id;
	long	custdet_id;
	char	usrdata1[33];
	char	usrdata2[33];
	char	usrdata3[33];
	char	usrdata4[33];
	char	usrdata5[33];
	char	usrdata6[33];
} CUSTDET_X_t;

#ifdef __cplusplus
/**
 * Structure for C++ interfacing of table CUSTDET_X
 */
struct CppClassCUSTDET_X_t : public CUSTDET_X_t
{
	CppClassCUSTDET_X_t (
		long _id = 0,
		long _custdet_id = 0,
		const char * _usrdata1 = "",
		const char * _usrdata2 = "",
		const char * _usrdata3 = "",
		const char * _usrdata4 = "",
		const char * _usrdata5 = "",
		const char * _usrdata6 = ""
		)
	{
		id = _id;
		custdet_id = _custdet_id;
		slstrcpy_sen(usrdata1, _usrdata1);
		slstrcpy_sen(usrdata2, _usrdata2);
		slstrcpy_sen(usrdata3, _usrdata3);
		slstrcpy_sen(usrdata4, _usrdata4);
		slstrcpy_sen(usrdata5, _usrdata5);
		slstrcpy_sen(usrdata6, _usrdata6);
	}
};
#endif /*__cplusplus*/
/**
 * Structure of indicators for table  CUSTDET_X 
 */
typedef struct
{
	short	id;
	short	custdet_id;
	short	usrdata1;
	short	usrdata2;
	short	usrdata3;
	short	usrdata4;
	short	usrdata5;
	short	usrdata6;
} CUSTDET_X_IND_t;

/**
 * Structure to retrieve CUSTDET_X by Primary Key PK_CUSTDET_X
 */
typedef struct
{
	long	id;
} CUSTDET_X_PK_t;

/**
 * Structure to retrieve CUSTDET_X by Primary Key FK_CUSTDET_X_ID_CUSTDET
 */
typedef struct
{
	long	custdet_id;
} FK_CUSTDET_X_ID_CUSTDET_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/

#endif
