/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	PIS12_LOG type defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBPIS12LOGRH_H
#define __DBPIS12LOGRH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
#include <dbpis12logbsd.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define PIS12_LOG_PK_PREP2 \
	PIS12_LOG_PKid = p_PIS12_LOG_PK->id;\

#define PIS12_LOG_PK_PREP1 \
	pis12_log.id = :v1 
#define PIS12_LOG_HASH_PREP2 \
	strscpy(PIS12_LOG_HASHtstamp, p_PIS12_LOG_HASH->tstamp);stp_right(PIS12_LOG_HASHtstamp);\

#define PIS12_LOG_HASH_PREP1 \
	pis12_log.tstamp = :v2 
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
#include <dbpis12logdao.h>
/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif
#define PIS12_LOGadd(pdata)					PIS12_LOGadd_IND(pdata, NULL)
#define PIS12_LOGupdate(pdata)					PIS12_LOGupdate_IND(pdata, NULL)
#define PIS12_LOGgetbyPIS12_LOG_PK(pdata, phash)		PIS12_LOGgetbyPIS12_LOG_PK_IND(pdata, NULL, phash)
#define PIS12_LOGgetbyPIS12_LOG_PK4upd(pdata, phash)		PIS12_LOGgetbyPIS12_LOG_PK4upd_IND(pdata, NULL, phash)
#define PIS12_LOGupdbyPIS12_LOG_PK(pdata, phash)		PIS12_LOGupdbyPIS12_LOG_PK_IND(pdata, NULL, phash)
#define PIS12_LOGupdallbyPIS12_LOG_PK(pdata, phash)		PIS12_LOGupdallbyPIS12_LOG_PK_IND(pdata, NULL, phash)
#define PIS12_LOGgetbyPIS12_LOG_HASH(pdata, phash)		PIS12_LOGgetbyPIS12_LOG_HASH_IND(pdata, NULL, phash)
#define PIS12_LOGgetbyPIS12_LOG_HASH4upd(pdata, phash)		PIS12_LOGgetbyPIS12_LOG_HASH4upd_IND(pdata, NULL, phash)
#define PIS12_LOGupdbyPIS12_LOG_HASH(pdata, phash)		PIS12_LOGupdbyPIS12_LOG_HASH_IND(pdata, NULL, phash)
#define PIS12_LOGupdallbyPIS12_LOG_HASH(pdata, phash)		PIS12_LOGupdallbyPIS12_LOG_HASH_IND(pdata, NULL, phash)
#define PIS12_LOGdump(p_PIS12_LOG)				PIS12_LOGdump_IND(p_PIS12_LOG, NULL)
#define PIS12_LOGdumplev(p_PIS12_LOG, dbglev)			PIS12_LOGdumplev_IND(p_PIS12_LOG, NULL, dbglev)

extern	int	PIS12_LOGadd_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND);
extern	int	PIS12_LOGupdate_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND);
extern	int	PIS12_LOGdelete(PIS12_LOG_t *p_PIS12_LOG);

extern	void	PIS12_LOGdump_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND);
extern	void	PIS12_LOGdumplev_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, int dbglev);

extern	char	*PIS12_LOG_PKkey2str(char *out, PIS12_LOG_PK_t *p_PIS12_LOG_PK);

extern	int	PIS12_LOGgetbyPIS12_LOG_PK_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_PK_t *p_PIS12_LOG_PK);
extern	int	PIS12_LOGgetbyPIS12_LOG_PK4upd_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_PK_t *p_PIS12_LOG_PK);
extern	int	PIS12_LOGupdbyPIS12_LOG_PK_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_PK_t *p_PIS12_LOG_PK);
extern	int	PIS12_LOGupdallbyPIS12_LOG_PK_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_PK_t *p_PIS12_LOG_PK);
extern	int	PIS12_LOGdelbyPIS12_LOG_PK( PIS12_LOG_PK_t *p_PIS12_LOG_PK);
extern	void	PIS12_LOGinitDflt(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND);

extern	char	*PIS12_LOG_HASHkey2str(char *out, PIS12_LOG_HASH_t *p_PIS12_LOG_HASH);

extern	int	PIS12_LOGgetbyPIS12_LOG_HASH_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_HASH_t *p_PIS12_LOG_HASH);
extern	int	PIS12_LOGgetbyPIS12_LOG_HASH4upd_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_HASH_t *p_PIS12_LOG_HASH);
extern	int	PIS12_LOGupdbyPIS12_LOG_HASH_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_HASH_t *p_PIS12_LOG_HASH);
extern	int	PIS12_LOGupdallbyPIS12_LOG_HASH_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_HASH_t *p_PIS12_LOG_HASH);
extern	int	PIS12_LOGdelbyPIS12_LOG_HASH( PIS12_LOG_HASH_t *p_PIS12_LOG_HASH);
extern	void	PIS12_LOGinitDflt(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND);

#ifdef __cplusplus
}
#endif

#endif
