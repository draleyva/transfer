/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CUSTDET_X buffer size defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBCUST_XBSD_H
#define __DBCUST_XBSD_H


#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define CUSTDET_X_USRDATA1_BUFFSIZE 33
#define CUSTDET_X_USRDATA2_BUFFSIZE 33
#define CUSTDET_X_USRDATA3_BUFFSIZE 33
#define CUSTDET_X_USRDATA4_BUFFSIZE 33
#define CUSTDET_X_USRDATA5_BUFFSIZE 33
#define CUSTDET_X_USRDATA6_BUFFSIZE 33

#ifdef __cplusplus
}
#endif

#endif
