/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	NMON_LOG buffer size defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBNMONLOGBSD_H
#define __DBNMONLOGBSD_H


#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define NMON_LOG_TSTAMP_BUFFSIZE 21
#define NMON_LOG_TABLENAME_BUFFSIZE 33
#define NMON_LOG_KEYDATA_BUFFSIZE 65
#define NMON_LOG_HINT_BUFFSIZE 2
#define NMON_LOG_NMONCODE_BUFFSIZE 5
#define NMON_LOG_NEWVALUE1_BUFFSIZE 65
#define NMON_LOG_OLDVALUE1_BUFFSIZE 65
#define NMON_LOG_NEWVALUE2_BUFFSIZE 65
#define NMON_LOG_OLDVALUE2_BUFFSIZE 65
#define NMON_LOG_NEWVALUE3_BUFFSIZE 65
#define NMON_LOG_OLDVALUE3_BUFFSIZE 65
#define NMON_LOG_NEWVALUE4_BUFFSIZE 65
#define NMON_LOG_OLDVALUE4_BUFFSIZE 65
#define NMON_LOG_NEWVALUE5_BUFFSIZE 65
#define NMON_LOG_OLDVALUE5_BUFFSIZE 65
#define NMON_LOG_NEWVALUE6_BUFFSIZE 65
#define NMON_LOG_OLDVALUE6_BUFFSIZE 65
#define NMON_LOG_NEWVALUE7_BUFFSIZE 65
#define NMON_LOG_OLDVALUE7_BUFFSIZE 65

#ifdef __cplusplus
}
#endif

#endif
