/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CRDSTATMAP type defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBCRDSTATMAPRH_H
#define __DBCRDSTATMAPRH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
#include <dbcrdstatmapbsd.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define CRDSTATMAP_PK_PREP2 \
	strscpy(CRDSTATMAP_PKext_statcode, p_CRDSTATMAP_PK->ext_statcode);stp_right(CRDSTATMAP_PKext_statcode);\

#define CRDSTATMAP_PK_PREP1 \
	crdstatmap.ext_statcode = :v1 
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
#include <dbcrdstatmapdao.h>
/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif
#define CRDSTATMAPadd(pdata)					CRDSTATMAPadd_IND(pdata, NULL)
#define CRDSTATMAPupdate(pdata)					CRDSTATMAPupdate_IND(pdata, NULL)
#define CRDSTATMAPgetbyCRDSTATMAP_PK(pdata, phash)		CRDSTATMAPgetbyCRDSTATMAP_PK_IND(pdata, NULL, phash)
#define CRDSTATMAPgetbyCRDSTATMAP_PK4upd(pdata, phash)		CRDSTATMAPgetbyCRDSTATMAP_PK4upd_IND(pdata, NULL, phash)
#define CRDSTATMAPupdbyCRDSTATMAP_PK(pdata, phash)		CRDSTATMAPupdbyCRDSTATMAP_PK_IND(pdata, NULL, phash)
#define CRDSTATMAPupdallbyCRDSTATMAP_PK(pdata, phash)		CRDSTATMAPupdallbyCRDSTATMAP_PK_IND(pdata, NULL, phash)
#define CRDSTATMAPdump(p_CRDSTATMAP)				CRDSTATMAPdump_IND(p_CRDSTATMAP, NULL)
#define CRDSTATMAPdumplev(p_CRDSTATMAP, dbglev)			CRDSTATMAPdumplev_IND(p_CRDSTATMAP, NULL, dbglev)

extern	int	CRDSTATMAPadd_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND);
extern	int	CRDSTATMAPupdate_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND);
extern	int	CRDSTATMAPdelete(CRDSTATMAP_t *p_CRDSTATMAP);

extern	void	CRDSTATMAPdump_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND);
extern	void	CRDSTATMAPdumplev_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND, int dbglev);

extern	char	*CRDSTATMAP_PKkey2str(char *out, CRDSTATMAP_PK_t *p_CRDSTATMAP_PK);

extern	int	CRDSTATMAPgetbyCRDSTATMAP_PK_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND, CRDSTATMAP_PK_t *p_CRDSTATMAP_PK);
extern	int	CRDSTATMAPgetbyCRDSTATMAP_PK4upd_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND, CRDSTATMAP_PK_t *p_CRDSTATMAP_PK);
extern	int	CRDSTATMAPupdbyCRDSTATMAP_PK_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND, CRDSTATMAP_PK_t *p_CRDSTATMAP_PK);
extern	int	CRDSTATMAPupdallbyCRDSTATMAP_PK_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND, CRDSTATMAP_PK_t *p_CRDSTATMAP_PK);
extern	int	CRDSTATMAPdelbyCRDSTATMAP_PK( CRDSTATMAP_PK_t *p_CRDSTATMAP_PK);
extern	void	CRDSTATMAPinitDflt(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND);

#ifdef __cplusplus
}
#endif

#endif
