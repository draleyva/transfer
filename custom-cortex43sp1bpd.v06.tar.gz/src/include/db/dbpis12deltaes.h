/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	PIS12_DELTA access routines for managing database access (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __DBPIS12DELTAES_H
#define __DBPIS12DELTAES_H

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	extern	long	PIS12_DELTAid;
	extern	char	PIS12_DELTAworkflow[17];
	extern	char	PIS12_DELTArecordtype[9];
	extern	char	PIS12_DELTAdataspecificationversion[6];
	extern	char	PIS12_DELTAclientidfromheader[17];
	extern	long	PIS12_DELTAcrddet_id;
	extern	long	PIS12_DELTAtoken_id;
	extern	short	PIS12_DELTApis12_type;
	extern	char	PIS12_DELTArecordcreationdate[11];
	extern	long	PIS12_DELTArecordcreationtime;
	extern	long	PIS12_DELTArecordcreationmilliseconds;
	extern	long	PIS12_DELTAgmtoffset;
	extern	char	PIS12_DELTAcustomeridfromheader[21];
	extern	char	PIS12_DELTAcustomeracctnumber[41];
	extern	char	PIS12_DELTAexternaltransactionid[33];
	extern	char	PIS12_DELTApan[20];
	extern	char	PIS12_DELTAtype[2];
	extern	char	PIS12_DELTAsubtype[3];
	extern	char	PIS12_DELTAcategory[2];
	extern	char	PIS12_DELTAassociation[2];
	extern	char	PIS12_DELTApanopendate[11];
	extern	char	PIS12_DELTAmembersincedate[11];
	extern	char	PIS12_DELTAissuingcountry[4];
	extern	char	PIS12_DELTAcardholdercity[41];
	extern	char	PIS12_DELTAcardholderstateprovince[6];
	extern	char	PIS12_DELTAcardholderpostalcode[11];
	extern	char	PIS12_DELTAcardholdercountrycode[4];
	extern	short	PIS12_DELTAnumberofpaymentids;
	extern	char	PIS12_DELTApaymentinstrumentid[31];
	extern	char	PIS12_DELTAstatus[3];
	extern	char	PIS12_DELTAstatusdate[11];
	extern	short	PIS12_DELTApinlength;
	extern	char	PIS12_DELTApinsetdate[11];
	extern	char	PIS12_DELTApintype[2];
	extern	char	PIS12_DELTAactiveindicator[2];
	extern	char	PIS12_DELTAnameoninstrument[41];
	extern	char	PIS12_DELTAexpirationdate[11];
	extern	char	PIS12_DELTAlastissuedate[11];
	extern	char	PIS12_DELTAplasticissuetype[2];
	extern	char	PIS12_DELTAincentive[2];
	extern	char	PIS12_DELTAcurrencycode[4];
	extern	double	PIS12_DELTAcurrencyconversionrate;
	extern	double	PIS12_DELTAcreditlimit;
	extern	double	PIS12_DELTAoverdraftlimit;
	extern	double	PIS12_DELTAdailyposlimit;
	extern	double	PIS12_DELTAdailycashlimit;
	extern	char	PIS12_DELTAcashbacklimitmode[2];
	extern	char	PIS12_DELTAmediatype[2];
	extern	char	PIS12_DELTAaipstatic[2];
	extern	char	PIS12_DELTAaipdynamic[2];
	extern	char	PIS12_DELTAaipverify[2];
	extern	char	PIS12_DELTAaiprisk[2];
	extern	char	PIS12_DELTAaipissuerauthentication[2];
	extern	char	PIS12_DELTAaipcombined[2];
	extern	char	PIS12_DELTAchipspecification[2];
	extern	char	PIS12_DELTAchipspecversion[4];
	extern	short	PIS12_DELTAofflinelowerlimit;
	extern	short	PIS12_DELTAofflineupperlimit;
	extern	char	PIS12_DELTAuserindicator01[2];
	extern	char	PIS12_DELTAuserindicator02[2];
	extern	char	PIS12_DELTAusercode1[4];
	extern	char	PIS12_DELTAusercode2[4];
	extern	char	PIS12_DELTAuserdata01[7];
	extern	char	PIS12_DELTAuserdata02[7];
	extern	char	PIS12_DELTAuserdata03[11];
	extern	char	PIS12_DELTAuserdata04[11];
	extern	char	PIS12_DELTAuserdata05[16];
	extern	char	PIS12_DELTAuserdata06[21];
	extern	char	PIS12_DELTAuserdata07[41];

	extern	long	PIS12_DELTA_PKid;
EXEC SQL END DECLARE SECTION;
/** @endcond */

/*---------------------------Macros-------------------------------------*/
#define PIS12_DELTA_HV \
:PIS12_DELTAid,\
:PIS12_DELTAworkflow,\
:PIS12_DELTArecordtype,\
:PIS12_DELTAdataspecificationversion,\
:PIS12_DELTAclientidfromheader,\
:PIS12_DELTAcrddet_id,\
:PIS12_DELTAtoken_id,\
:PIS12_DELTApis12_type,\
:PIS12_DELTArecordcreationdate,\
:PIS12_DELTArecordcreationtime,\
:PIS12_DELTArecordcreationmilliseconds,\
:PIS12_DELTAgmtoffset,\
:PIS12_DELTAcustomeridfromheader,\
:PIS12_DELTAcustomeracctnumber,\
:PIS12_DELTAexternaltransactionid,\
:PIS12_DELTApan,\
:PIS12_DELTAtype,\
:PIS12_DELTAsubtype,\
:PIS12_DELTAcategory,\
:PIS12_DELTAassociation,\
:PIS12_DELTApanopendate,\
:PIS12_DELTAmembersincedate,\
:PIS12_DELTAissuingcountry,\
:PIS12_DELTAcardholdercity,\
:PIS12_DELTAcardholderstateprovince,\
:PIS12_DELTAcardholderpostalcode,\
:PIS12_DELTAcardholdercountrycode,\
:PIS12_DELTAnumberofpaymentids,\
:PIS12_DELTApaymentinstrumentid,\
:PIS12_DELTAstatus,\
:PIS12_DELTAstatusdate,\
:PIS12_DELTApinlength,\
:PIS12_DELTApinsetdate,\
:PIS12_DELTApintype,\
:PIS12_DELTAactiveindicator,\
:PIS12_DELTAnameoninstrument,\
:PIS12_DELTAexpirationdate,\
:PIS12_DELTAlastissuedate,\
:PIS12_DELTAplasticissuetype,\
:PIS12_DELTAincentive,\
:PIS12_DELTAcurrencycode,\
:PIS12_DELTAcurrencyconversionrate,\
:PIS12_DELTAcreditlimit,\
:PIS12_DELTAoverdraftlimit,\
:PIS12_DELTAdailyposlimit,\
:PIS12_DELTAdailycashlimit,\
:PIS12_DELTAcashbacklimitmode,\
:PIS12_DELTAmediatype,\
:PIS12_DELTAaipstatic,\
:PIS12_DELTAaipdynamic,\
:PIS12_DELTAaipverify,\
:PIS12_DELTAaiprisk,\
:PIS12_DELTAaipissuerauthentication,\
:PIS12_DELTAaipcombined,\
:PIS12_DELTAchipspecification,\
:PIS12_DELTAchipspecversion,\
:PIS12_DELTAofflinelowerlimit,\
:PIS12_DELTAofflineupperlimit,\
:PIS12_DELTAuserindicator01,\
:PIS12_DELTAuserindicator02,\
:PIS12_DELTAusercode1,\
:PIS12_DELTAusercode2,\
:PIS12_DELTAuserdata01,\
:PIS12_DELTAuserdata02,\
:PIS12_DELTAuserdata03,\
:PIS12_DELTAuserdata04,\
:PIS12_DELTAuserdata05,\
:PIS12_DELTAuserdata06,\
:PIS12_DELTAuserdata07

#define PIS12_DELTA_COL \
pis12_delta.id,\
pis12_delta.workflow,\
pis12_delta.recordtype,\
pis12_delta.dataspecificationversion,\
pis12_delta.clientidfromheader,\
pis12_delta.crddet_id,\
pis12_delta.token_id,\
pis12_delta.pis12_type,\
pis12_delta.recordcreationdate,\
pis12_delta.recordcreationtime,\
pis12_delta.recordcreationmilliseconds,\
pis12_delta.gmtoffset,\
pis12_delta.customeridfromheader,\
pis12_delta.customeracctnumber,\
pis12_delta.externaltransactionid,\
pis12_delta.pan,\
pis12_delta.type,\
pis12_delta.subtype,\
pis12_delta.category,\
pis12_delta.association,\
pis12_delta.panopendate,\
pis12_delta.membersincedate,\
pis12_delta.issuingcountry,\
pis12_delta.cardholdercity,\
pis12_delta.cardholderstateprovince,\
pis12_delta.cardholderpostalcode,\
pis12_delta.cardholdercountrycode,\
pis12_delta.numberofpaymentids,\
pis12_delta.paymentinstrumentid,\
pis12_delta.status,\
pis12_delta.statusdate,\
pis12_delta.pinlength,\
pis12_delta.pinsetdate,\
pis12_delta.pintype,\
pis12_delta.activeindicator,\
pis12_delta.nameoninstrument,\
pis12_delta.expirationdate,\
pis12_delta.lastissuedate,\
pis12_delta.plasticissuetype,\
pis12_delta.incentive,\
pis12_delta.currencycode,\
pis12_delta.currencyconversionrate,\
pis12_delta.creditlimit,\
pis12_delta.overdraftlimit,\
pis12_delta.dailyposlimit,\
pis12_delta.dailycashlimit,\
pis12_delta.cashbacklimitmode,\
pis12_delta.mediatype,\
pis12_delta.aipstatic,\
pis12_delta.aipdynamic,\
pis12_delta.aipverify,\
pis12_delta.aiprisk,\
pis12_delta.aipissuerauthentication,\
pis12_delta.aipcombined,\
pis12_delta.chipspecification,\
pis12_delta.chipspecversion,\
pis12_delta.offlinelowerlimit,\
pis12_delta.offlineupperlimit,\
pis12_delta.userindicator01,\
pis12_delta.userindicator02,\
pis12_delta.usercode1,\
pis12_delta.usercode2,\
pis12_delta.userdata01,\
pis12_delta.userdata02,\
pis12_delta.userdata03,\
pis12_delta.userdata04,\
pis12_delta.userdata05,\
pis12_delta.userdata06,\
pis12_delta.userdata07

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_PIS12_DELTA_t
	{
		long	id;
		char	workflow[17];
		char	recordtype[9];
		char	dataspecificationversion[6];
		char	clientidfromheader[17];
		long	crddet_id;
		long	token_id;
		short	pis12_type;
		char	recordcreationdate[11];
		long	recordcreationtime;
		long	recordcreationmilliseconds;
		long	gmtoffset;
		char	customeridfromheader[21];
		char	customeracctnumber[41];
		char	externaltransactionid[33];
		char	pan[20];
		char	type[2];
		char	subtype[3];
		char	category[2];
		char	association[2];
		char	panopendate[11];
		char	membersincedate[11];
		char	issuingcountry[4];
		char	cardholdercity[41];
		char	cardholderstateprovince[6];
		char	cardholderpostalcode[11];
		char	cardholdercountrycode[4];
		short	numberofpaymentids;
		char	paymentinstrumentid[31];
		char	status[3];
		char	statusdate[11];
		short	pinlength;
		char	pinsetdate[11];
		char	pintype[2];
		char	activeindicator[2];
		char	nameoninstrument[41];
		char	expirationdate[11];
		char	lastissuedate[11];
		char	plasticissuetype[2];
		char	incentive[2];
		char	currencycode[4];
		double	currencyconversionrate;
		double	creditlimit;
		double	overdraftlimit;
		double	dailyposlimit;
		double	dailycashlimit;
		char	cashbacklimitmode[2];
		char	mediatype[2];
		char	aipstatic[2];
		char	aipdynamic[2];
		char	aipverify[2];
		char	aiprisk[2];
		char	aipissuerauthentication[2];
		char	aipcombined[2];
		char	chipspecification[2];
		char	chipspecversion[4];
		short	offlinelowerlimit;
		short	offlineupperlimit;
		char	userindicator01[2];
		char	userindicator02[2];
		char	usercode1[4];
		char	usercode2[4];
		char	userdata01[7];
		char	userdata02[7];
		char	userdata03[11];
		char	userdata04[11];
		char	userdata05[16];
		char	userdata06[21];
		char	userdata07[41];
	} HOST_PIS12_DELTA_t;

	typedef struct HOST_PIS12_DELTA_IND_t
	{
		short	id_ind;
		short	workflow_ind;
		short	recordtype_ind;
		short	dataspecificationversion_ind;
		short	clientidfromheader_ind;
		short	crddet_id_ind;
		short	token_id_ind;
		short	pis12_type_ind;
		short	recordcreationdate_ind;
		short	recordcreationtime_ind;
		short	recordcreationmilliseconds_ind;
		short	gmtoffset_ind;
		short	customeridfromheader_ind;
		short	customeracctnumber_ind;
		short	externaltransactionid_ind;
		short	pan_ind;
		short	type_ind;
		short	subtype_ind;
		short	category_ind;
		short	association_ind;
		short	panopendate_ind;
		short	membersincedate_ind;
		short	issuingcountry_ind;
		short	cardholdercity_ind;
		short	cardholderstateprovince_ind;
		short	cardholderpostalcode_ind;
		short	cardholdercountrycode_ind;
		short	numberofpaymentids_ind;
		short	paymentinstrumentid_ind;
		short	status_ind;
		short	statusdate_ind;
		short	pinlength_ind;
		short	pinsetdate_ind;
		short	pintype_ind;
		short	activeindicator_ind;
		short	nameoninstrument_ind;
		short	expirationdate_ind;
		short	lastissuedate_ind;
		short	plasticissuetype_ind;
		short	incentive_ind;
		short	currencycode_ind;
		short	currencyconversionrate_ind;
		short	creditlimit_ind;
		short	overdraftlimit_ind;
		short	dailyposlimit_ind;
		short	dailycashlimit_ind;
		short	cashbacklimitmode_ind;
		short	mediatype_ind;
		short	aipstatic_ind;
		short	aipdynamic_ind;
		short	aipverify_ind;
		short	aiprisk_ind;
		short	aipissuerauthentication_ind;
		short	aipcombined_ind;
		short	chipspecification_ind;
		short	chipspecversion_ind;
		short	offlinelowerlimit_ind;
		short	offlineupperlimit_ind;
		short	userindicator01_ind;
		short	userindicator02_ind;
		short	usercode1_ind;
		short	usercode2_ind;
		short	userdata01_ind;
		short	userdata02_ind;
		short	userdata03_ind;
		short	userdata04_ind;
		short	userdata05_ind;
		short	userdata06_ind;
		short	userdata07_ind;
	} HOST_PIS12_DELTA_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
#define PIS12_DELTAdump(p_PIS12_DELTA)				PIS12_DELTAdump_IND(p_PIS12_DELTA, NULL)
#define PIS12_DELTAdumplev(p_PIS12_DELTA, dbglev)		PIS12_DELTAdumplev_IND(p_PIS12_DELTA, NULL, dbglev)

extern	int	PIS12_DELTAadd_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND);
extern	int	PIS12_DELTAupdate_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND);
extern	int	PIS12_DELTAdelete(PIS12_DELTA_t *p_PIS12_DELTA);
extern	void	PIS12_DELTAdump_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND);
extern	void	PIS12_DELTAdumplev_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND, int dbglev);

extern	int	PIS12_DELTAhv2cs(PIS12_DELTA_t *p_PIS12_DELTA);
extern	void	PIS12_DELTAcs2hv(PIS12_DELTA_t *p_PIS12_DELTA);
extern	int	PIS12_DELTAhs2cs(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_IND, HOST_PIS12_DELTA_t *hsData, HOST_PIS12_DELTA_IND_t *hsInd);

extern	void	PIS12_DELTAcs2hsINS(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_IND, HOST_PIS12_DELTA_t *hsData, HOST_PIS12_DELTA_IND_t *hsInd);
extern	void	PIS12_DELTAcs2hs(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_IND, HOST_PIS12_DELTA_t *hsData, HOST_PIS12_DELTA_IND_t *hsInd);
extern	void	PIS12_DELTA_PKdumplev(PIS12_DELTA_PK_t *p_PIS12_DELTA_PK, int dbglev);
extern	char	*PIS12_DELTA_PKkey2str(char *out, PIS12_DELTA_PK_t *p_PIS12_DELTA_PK);

extern	int	PIS12_DELTAgetbyPIS12_DELTA_PK_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND, PIS12_DELTA_PK_t *p_PIS12_DELTA_PK);
extern	int	PIS12_DELTAgetbyPIS12_DELTA_PK4upd_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND, PIS12_DELTA_PK_t *p_PIS12_DELTA_PK);
extern	int	PIS12_DELTAupdbyPIS12_DELTA_PK_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND, PIS12_DELTA_PK_t *p_PIS12_DELTA_PK);
extern	int	PIS12_DELTAupdallbyPIS12_DELTA_PK_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND, PIS12_DELTA_PK_t *p_PIS12_DELTA_PK);
extern	int	PIS12_DELTAdelbyPIS12_DELTA_PK( PIS12_DELTA_PK_t *p_PIS12_DELTA_PK);

extern	void	PIS12_DELTAinitDflt(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND);

#ifdef __cplusplus
}
#endif

#endif
