/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	FPADREC buffer size defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBFPADRECBSD_H
#define __DBFPADRECBSD_H


#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define FPADREC_DATECREATED_BUFFSIZE 11
#define FPADREC_DATEUPDATED_BUFFSIZE 11
#define FPADREC_ACTIONCODE_BUFFSIZE 2
#define FPADREC_RSPCODE_BUFFSIZE 3
#define FPADREC_CRDACPTLOC_POSTCODE_BUFFSIZE 11
#define FPADREC_DECISION_CODE_1_BUFFSIZE 33
#define FPADREC_DECISION_CODE_2_BUFFSIZE 33
#define FPADREC_DECISION_CODE_3_BUFFSIZE 33
#define FPADREC_DECISION_CODE_4_BUFFSIZE 33
#define FPADREC_DECISION_CODE_5_BUFFSIZE 33
#define FPADREC_DECISION_CODE_6_BUFFSIZE 33
#define FPADREC_DECISION_CODE_7_BUFFSIZE 33
#define FPADREC_DECISION_CODE_8_BUFFSIZE 33
#define FPADREC_DECISION_CODE_9_BUFFSIZE 33
#define FPADREC_DECISION_CODE_10_BUFFSIZE 33

#ifdef __cplusplus
}
#endif

#endif
