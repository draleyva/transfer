/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CRDSTATMAP DAO structure definitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBCRDSTATMAPDAO_H
#define __DBCRDSTATMAPDAO_H

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table CRDSTATMAP
 */
typedef struct
{
	char	ctx_statcode[3];
	char	ext_statcode[6];
	char	descr[31];
} CRDSTATMAP_t;

#ifdef __cplusplus
/**
 * Structure for C++ interfacing of table CRDSTATMAP
 */
struct CppClassCRDSTATMAP_t : public CRDSTATMAP_t
{
	CppClassCRDSTATMAP_t (
		const char * _ctx_statcode = "",
		const char * _ext_statcode = "",
		const char * _descr = ""
		)
	{
		slstrcpy_sen(ctx_statcode, _ctx_statcode);
		slstrcpy_sen(ext_statcode, _ext_statcode);
		slstrcpy_sen(descr, _descr);
	}
};
#endif /*__cplusplus*/
/**
 * Structure of indicators for table  CRDSTATMAP 
 */
typedef struct
{
	short	ctx_statcode;
	short	ext_statcode;
	short	descr;
} CRDSTATMAP_IND_t;

/**
 * Structure to retrieve CRDSTATMAP by Primary Key PK_CRDSTATMAP
 */
typedef struct
{
	char	ext_statcode[6];
} CRDSTATMAP_PK_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/

#endif
