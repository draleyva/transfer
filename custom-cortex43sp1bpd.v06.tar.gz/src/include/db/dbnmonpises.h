/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	NMON_PIS access routines for managing database access (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __DBNMONPISES_H
#define __DBNMONPISES_H

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	extern	long	NMON_PISid;
	extern	char	NMON_PISctxdate[11];
	extern	char	NMON_PISworkflow[17];
	extern	char	NMON_PISrecordtype[9];
	extern	char	NMON_PISdataspecificationversion[6];
	extern	char	NMON_PISclientidfromheader[17];
	extern	char	NMON_PISrecordcreationdate[11];
	extern	long	NMON_PISrecordcreationtime;
	extern	long	NMON_PISrecordcreationmilliseconds;
	extern	short	NMON_PISgmtoffset;
	extern	char	NMON_PIScustomeridfromheader[21];
	extern	char	NMON_PIScustomeracctnumber[41];
	extern	char	NMON_PISexternaltransactionid[33];
	extern	char	NMON_PIStransactiondate[11];
	extern	long	NMON_PIStransactiontime;
	extern	char	NMON_PISnonmoncode[5];
	extern	char	NMON_PISnonmoncodeinitiator[2];
	extern	char	NMON_PISdecisioncode[2];
	extern	char	NMON_PIScontactmethod[2];
	extern	char	NMON_PIScontactmethodid[41];
	extern	char	NMON_PISservicerepresentativeid[21];
	extern	char	NMON_PISpan[20];
	extern	char	NMON_PISpaymentinstrumentid[31];
	extern	char	NMON_PISnewcustomerid[21];
	extern	char	NMON_PISnewcustomeracctnumber[41];
	extern	char	NMON_PISnewpan[20];
	extern	char	NMON_PISnewpaymentinstrumentid[31];
	extern	char	NMON_PISactioncode[3];
	extern	char	NMON_PISnewgivenname[31];
	extern	char	NMON_PISoldgivenname[31];
	extern	char	NMON_PISnewmiddlename[31];
	extern	char	NMON_PISoldmiddlename[31];
	extern	char	NMON_PISnewsurname[61];
	extern	char	NMON_PISoldsurname[61];
	extern	char	NMON_PISnewsuffix[11];
	extern	char	NMON_PISoldsuffix[11];
	extern	char	NMON_PISnewentityname[61];
	extern	char	NMON_PISoldentityname[61];
	extern	char	NMON_PISnewstreetline1[41];
	extern	char	NMON_PISoldstreetline1[41];
	extern	char	NMON_PISnewstreetline2[41];
	extern	char	NMON_PISoldstreetline2[41];
	extern	char	NMON_PISnewstreetline3[41];
	extern	char	NMON_PISoldstreetline3[41];
	extern	char	NMON_PISnewstreetline4[41];
	extern	char	NMON_PISoldstreetline4[41];
	extern	char	NMON_PISnewcity[41];
	extern	char	NMON_PISoldcity[41];
	extern	char	NMON_PISnewstateprovince[4];
	extern	char	NMON_PISoldstateprovince[4];
	extern	char	NMON_PISnewpostalcode[11];
	extern	char	NMON_PISoldpostalcode[11];
	extern	char	NMON_PISnewcountrycode[4];
	extern	char	NMON_PISoldcountrycode[4];
	extern	char	NMON_PISnewphone1[25];
	extern	char	NMON_PISoldphone1[25];
	extern	char	NMON_PISnewphone2[25];
	extern	char	NMON_PISoldphone2[25];
	extern	char	NMON_PISnewemailaddress[41];
	extern	char	NMON_PISoldemailaddress[41];
	extern	char	NMON_PISnewdate1[11];
	extern	char	NMON_PISolddate1[11];
	extern	char	NMON_PISnewdate2[11];
	extern	char	NMON_PISolddate2[11];
	extern	char	NMON_PISnewid1[21];
	extern	char	NMON_PISoldid1[21];
	extern	char	NMON_PISnewid2[21];
	extern	char	NMON_PISoldid2[21];
	extern	char	NMON_PISnewcode1[4];
	extern	char	NMON_PISoldcode1[4];
	extern	char	NMON_PISnewcode2[4];
	extern	char	NMON_PISoldcode2[4];
	extern	char	NMON_PISnewcode3[4];
	extern	char	NMON_PISoldcode3[4];
	extern	char	NMON_PISnewindicator1[2];
	extern	char	NMON_PISoldindicator1[2];
	extern	char	NMON_PISnewindicator2[2];
	extern	char	NMON_PISoldindicator2[2];
	extern	char	NMON_PISnewindicator3[2];
	extern	char	NMON_PISoldindicator3[2];
	extern	char	NMON_PISnewindicator4[2];
	extern	char	NMON_PISoldindicator4[2];
	extern	double	NMON_PISnewmonetaryvalue;
	extern	double	NMON_PISoldmonetaryvalue;
	extern	char	NMON_PIScurrencycode[4];
	extern	double	NMON_PIScurrencyconversionrate;
	extern	long	NMON_PISnewnumericvalue1;
	extern	long	NMON_PISoldnumericvalue1;
	extern	long	NMON_PISnewnumericvalue2;
	extern	long	NMON_PISoldnumericvalue2;
	extern	char	NMON_PISnewcharactervalue[11];
	extern	char	NMON_PISoldcharactervalue[11];
	extern	char	NMON_PISnewtext[61];
	extern	char	NMON_PISoldtext[61];
	extern	char	NMON_PISctxcomment[51];
	extern	char	NMON_PISuserindicator01[2];
	extern	char	NMON_PISuserindicator02[2];
	extern	char	NMON_PISuserindicator03[2];
	extern	char	NMON_PISuserindicator04[2];
	extern	char	NMON_PISuserindicator05[2];
	extern	char	NMON_PISusercode1[4];
	extern	char	NMON_PISusercode2[4];
	extern	char	NMON_PISusercode3[4];
	extern	char	NMON_PISusercode4[4];
	extern	char	NMON_PISusercode5[4];
	extern	char	NMON_PISuserdata01[7];
	extern	char	NMON_PISuserdata02[7];
	extern	char	NMON_PISuserdata03[7];
	extern	char	NMON_PISuserdata04[9];
	extern	char	NMON_PISuserdata05[9];
	extern	char	NMON_PISuserdata06[9];
	extern	char	NMON_PISuserdata07[11];
	extern	char	NMON_PISuserdata08[11];
	extern	char	NMON_PISuserdata09[16];
	extern	char	NMON_PISuserdata10[16];
	extern	char	NMON_PISuserdata11[21];
	extern	char	NMON_PISuserdata12[21];
	extern	char	NMON_PISuserdata13[41];
	extern	char	NMON_PISuserdata14[41];
	extern	char	NMON_PISuserdata15[61];
	extern	char	NMON_PISreserved_01[31];

	extern	long	NMON_PIS_PKid;
EXEC SQL END DECLARE SECTION;
/** @endcond */

/*---------------------------Macros-------------------------------------*/
#define NMON_PIS_HV \
:NMON_PISid,\
:NMON_PISctxdate,\
:NMON_PISworkflow,\
:NMON_PISrecordtype,\
:NMON_PISdataspecificationversion,\
:NMON_PISclientidfromheader,\
:NMON_PISrecordcreationdate,\
:NMON_PISrecordcreationtime,\
:NMON_PISrecordcreationmilliseconds,\
:NMON_PISgmtoffset,\
:NMON_PIScustomeridfromheader,\
:NMON_PIScustomeracctnumber,\
:NMON_PISexternaltransactionid,\
:NMON_PIStransactiondate,\
:NMON_PIStransactiontime,\
:NMON_PISnonmoncode,\
:NMON_PISnonmoncodeinitiator,\
:NMON_PISdecisioncode,\
:NMON_PIScontactmethod,\
:NMON_PIScontactmethodid,\
:NMON_PISservicerepresentativeid,\
:NMON_PISpan,\
:NMON_PISpaymentinstrumentid,\
:NMON_PISnewcustomerid,\
:NMON_PISnewcustomeracctnumber,\
:NMON_PISnewpan,\
:NMON_PISnewpaymentinstrumentid,\
:NMON_PISactioncode,\
:NMON_PISnewgivenname,\
:NMON_PISoldgivenname,\
:NMON_PISnewmiddlename,\
:NMON_PISoldmiddlename,\
:NMON_PISnewsurname,\
:NMON_PISoldsurname,\
:NMON_PISnewsuffix,\
:NMON_PISoldsuffix,\
:NMON_PISnewentityname,\
:NMON_PISoldentityname,\
:NMON_PISnewstreetline1,\
:NMON_PISoldstreetline1,\
:NMON_PISnewstreetline2,\
:NMON_PISoldstreetline2,\
:NMON_PISnewstreetline3,\
:NMON_PISoldstreetline3,\
:NMON_PISnewstreetline4,\
:NMON_PISoldstreetline4,\
:NMON_PISnewcity,\
:NMON_PISoldcity,\
:NMON_PISnewstateprovince,\
:NMON_PISoldstateprovince,\
:NMON_PISnewpostalcode,\
:NMON_PISoldpostalcode,\
:NMON_PISnewcountrycode,\
:NMON_PISoldcountrycode,\
:NMON_PISnewphone1,\
:NMON_PISoldphone1,\
:NMON_PISnewphone2,\
:NMON_PISoldphone2,\
:NMON_PISnewemailaddress,\
:NMON_PISoldemailaddress,\
:NMON_PISnewdate1,\
:NMON_PISolddate1,\
:NMON_PISnewdate2,\
:NMON_PISolddate2,\
:NMON_PISnewid1,\
:NMON_PISoldid1,\
:NMON_PISnewid2,\
:NMON_PISoldid2,\
:NMON_PISnewcode1,\
:NMON_PISoldcode1,\
:NMON_PISnewcode2,\
:NMON_PISoldcode2,\
:NMON_PISnewcode3,\
:NMON_PISoldcode3,\
:NMON_PISnewindicator1,\
:NMON_PISoldindicator1,\
:NMON_PISnewindicator2,\
:NMON_PISoldindicator2,\
:NMON_PISnewindicator3,\
:NMON_PISoldindicator3,\
:NMON_PISnewindicator4,\
:NMON_PISoldindicator4,\
:NMON_PISnewmonetaryvalue,\
:NMON_PISoldmonetaryvalue,\
:NMON_PIScurrencycode,\
:NMON_PIScurrencyconversionrate,\
:NMON_PISnewnumericvalue1,\
:NMON_PISoldnumericvalue1,\
:NMON_PISnewnumericvalue2,\
:NMON_PISoldnumericvalue2,\
:NMON_PISnewcharactervalue,\
:NMON_PISoldcharactervalue,\
:NMON_PISnewtext,\
:NMON_PISoldtext,\
:NMON_PISctxcomment,\
:NMON_PISuserindicator01,\
:NMON_PISuserindicator02,\
:NMON_PISuserindicator03,\
:NMON_PISuserindicator04,\
:NMON_PISuserindicator05,\
:NMON_PISusercode1,\
:NMON_PISusercode2,\
:NMON_PISusercode3,\
:NMON_PISusercode4,\
:NMON_PISusercode5,\
:NMON_PISuserdata01,\
:NMON_PISuserdata02,\
:NMON_PISuserdata03,\
:NMON_PISuserdata04,\
:NMON_PISuserdata05,\
:NMON_PISuserdata06,\
:NMON_PISuserdata07,\
:NMON_PISuserdata08,\
:NMON_PISuserdata09,\
:NMON_PISuserdata10,\
:NMON_PISuserdata11,\
:NMON_PISuserdata12,\
:NMON_PISuserdata13,\
:NMON_PISuserdata14,\
:NMON_PISuserdata15,\
:NMON_PISreserved_01

#define NMON_PIS_COL \
nmon_pis.id,\
nmon_pis.ctxdate,\
nmon_pis.workflow,\
nmon_pis.recordtype,\
nmon_pis.dataspecificationversion,\
nmon_pis.clientidfromheader,\
nmon_pis.recordcreationdate,\
nmon_pis.recordcreationtime,\
nmon_pis.recordcreationmilliseconds,\
nmon_pis.gmtoffset,\
nmon_pis.customeridfromheader,\
nmon_pis.customeracctnumber,\
nmon_pis.externaltransactionid,\
nmon_pis.transactiondate,\
nmon_pis.transactiontime,\
nmon_pis.nonmoncode,\
nmon_pis.nonmoncodeinitiator,\
nmon_pis.decisioncode,\
nmon_pis.contactmethod,\
nmon_pis.contactmethodid,\
nmon_pis.servicerepresentativeid,\
nmon_pis.pan,\
nmon_pis.paymentinstrumentid,\
nmon_pis.newcustomerid,\
nmon_pis.newcustomeracctnumber,\
nmon_pis.newpan,\
nmon_pis.newpaymentinstrumentid,\
nmon_pis.actioncode,\
nmon_pis.newgivenname,\
nmon_pis.oldgivenname,\
nmon_pis.newmiddlename,\
nmon_pis.oldmiddlename,\
nmon_pis.newsurname,\
nmon_pis.oldsurname,\
nmon_pis.newsuffix,\
nmon_pis.oldsuffix,\
nmon_pis.newentityname,\
nmon_pis.oldentityname,\
nmon_pis.newstreetline1,\
nmon_pis.oldstreetline1,\
nmon_pis.newstreetline2,\
nmon_pis.oldstreetline2,\
nmon_pis.newstreetline3,\
nmon_pis.oldstreetline3,\
nmon_pis.newstreetline4,\
nmon_pis.oldstreetline4,\
nmon_pis.newcity,\
nmon_pis.oldcity,\
nmon_pis.newstateprovince,\
nmon_pis.oldstateprovince,\
nmon_pis.newpostalcode,\
nmon_pis.oldpostalcode,\
nmon_pis.newcountrycode,\
nmon_pis.oldcountrycode,\
nmon_pis.newphone1,\
nmon_pis.oldphone1,\
nmon_pis.newphone2,\
nmon_pis.oldphone2,\
nmon_pis.newemailaddress,\
nmon_pis.oldemailaddress,\
nmon_pis.newdate1,\
nmon_pis.olddate1,\
nmon_pis.newdate2,\
nmon_pis.olddate2,\
nmon_pis.newid1,\
nmon_pis.oldid1,\
nmon_pis.newid2,\
nmon_pis.oldid2,\
nmon_pis.newcode1,\
nmon_pis.oldcode1,\
nmon_pis.newcode2,\
nmon_pis.oldcode2,\
nmon_pis.newcode3,\
nmon_pis.oldcode3,\
nmon_pis.newindicator1,\
nmon_pis.oldindicator1,\
nmon_pis.newindicator2,\
nmon_pis.oldindicator2,\
nmon_pis.newindicator3,\
nmon_pis.oldindicator3,\
nmon_pis.newindicator4,\
nmon_pis.oldindicator4,\
nmon_pis.newmonetaryvalue,\
nmon_pis.oldmonetaryvalue,\
nmon_pis.currencycode,\
nmon_pis.currencyconversionrate,\
nmon_pis.newnumericvalue1,\
nmon_pis.oldnumericvalue1,\
nmon_pis.newnumericvalue2,\
nmon_pis.oldnumericvalue2,\
nmon_pis.newcharactervalue,\
nmon_pis.oldcharactervalue,\
nmon_pis.newtext,\
nmon_pis.oldtext,\
nmon_pis.ctxcomment,\
nmon_pis.userindicator01,\
nmon_pis.userindicator02,\
nmon_pis.userindicator03,\
nmon_pis.userindicator04,\
nmon_pis.userindicator05,\
nmon_pis.usercode1,\
nmon_pis.usercode2,\
nmon_pis.usercode3,\
nmon_pis.usercode4,\
nmon_pis.usercode5,\
nmon_pis.userdata01,\
nmon_pis.userdata02,\
nmon_pis.userdata03,\
nmon_pis.userdata04,\
nmon_pis.userdata05,\
nmon_pis.userdata06,\
nmon_pis.userdata07,\
nmon_pis.userdata08,\
nmon_pis.userdata09,\
nmon_pis.userdata10,\
nmon_pis.userdata11,\
nmon_pis.userdata12,\
nmon_pis.userdata13,\
nmon_pis.userdata14,\
nmon_pis.userdata15,\
nmon_pis.reserved_01

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_NMON_PIS_t
	{
		long	id;
		char	ctxdate[11];
		char	workflow[17];
		char	recordtype[9];
		char	dataspecificationversion[6];
		char	clientidfromheader[17];
		char	recordcreationdate[11];
		long	recordcreationtime;
		long	recordcreationmilliseconds;
		short	gmtoffset;
		char	customeridfromheader[21];
		char	customeracctnumber[41];
		char	externaltransactionid[33];
		char	transactiondate[11];
		long	transactiontime;
		char	nonmoncode[5];
		char	nonmoncodeinitiator[2];
		char	decisioncode[2];
		char	contactmethod[2];
		char	contactmethodid[41];
		char	servicerepresentativeid[21];
		char	pan[20];
		char	paymentinstrumentid[31];
		char	newcustomerid[21];
		char	newcustomeracctnumber[41];
		char	newpan[20];
		char	newpaymentinstrumentid[31];
		char	actioncode[3];
		char	newgivenname[31];
		char	oldgivenname[31];
		char	newmiddlename[31];
		char	oldmiddlename[31];
		char	newsurname[61];
		char	oldsurname[61];
		char	newsuffix[11];
		char	oldsuffix[11];
		char	newentityname[61];
		char	oldentityname[61];
		char	newstreetline1[41];
		char	oldstreetline1[41];
		char	newstreetline2[41];
		char	oldstreetline2[41];
		char	newstreetline3[41];
		char	oldstreetline3[41];
		char	newstreetline4[41];
		char	oldstreetline4[41];
		char	newcity[41];
		char	oldcity[41];
		char	newstateprovince[4];
		char	oldstateprovince[4];
		char	newpostalcode[11];
		char	oldpostalcode[11];
		char	newcountrycode[4];
		char	oldcountrycode[4];
		char	newphone1[25];
		char	oldphone1[25];
		char	newphone2[25];
		char	oldphone2[25];
		char	newemailaddress[41];
		char	oldemailaddress[41];
		char	newdate1[11];
		char	olddate1[11];
		char	newdate2[11];
		char	olddate2[11];
		char	newid1[21];
		char	oldid1[21];
		char	newid2[21];
		char	oldid2[21];
		char	newcode1[4];
		char	oldcode1[4];
		char	newcode2[4];
		char	oldcode2[4];
		char	newcode3[4];
		char	oldcode3[4];
		char	newindicator1[2];
		char	oldindicator1[2];
		char	newindicator2[2];
		char	oldindicator2[2];
		char	newindicator3[2];
		char	oldindicator3[2];
		char	newindicator4[2];
		char	oldindicator4[2];
		double	newmonetaryvalue;
		double	oldmonetaryvalue;
		char	currencycode[4];
		double	currencyconversionrate;
		long	newnumericvalue1;
		long	oldnumericvalue1;
		long	newnumericvalue2;
		long	oldnumericvalue2;
		char	newcharactervalue[11];
		char	oldcharactervalue[11];
		char	newtext[61];
		char	oldtext[61];
		char	ctxcomment[51];
		char	userindicator01[2];
		char	userindicator02[2];
		char	userindicator03[2];
		char	userindicator04[2];
		char	userindicator05[2];
		char	usercode1[4];
		char	usercode2[4];
		char	usercode3[4];
		char	usercode4[4];
		char	usercode5[4];
		char	userdata01[7];
		char	userdata02[7];
		char	userdata03[7];
		char	userdata04[9];
		char	userdata05[9];
		char	userdata06[9];
		char	userdata07[11];
		char	userdata08[11];
		char	userdata09[16];
		char	userdata10[16];
		char	userdata11[21];
		char	userdata12[21];
		char	userdata13[41];
		char	userdata14[41];
		char	userdata15[61];
		char	reserved_01[31];
	} HOST_NMON_PIS_t;

	typedef struct HOST_NMON_PIS_IND_t
	{
		short	id_ind;
		short	ctxdate_ind;
		short	workflow_ind;
		short	recordtype_ind;
		short	dataspecificationversion_ind;
		short	clientidfromheader_ind;
		short	recordcreationdate_ind;
		short	recordcreationtime_ind;
		short	recordcreationmilliseconds_ind;
		short	gmtoffset_ind;
		short	customeridfromheader_ind;
		short	customeracctnumber_ind;
		short	externaltransactionid_ind;
		short	transactiondate_ind;
		short	transactiontime_ind;
		short	nonmoncode_ind;
		short	nonmoncodeinitiator_ind;
		short	decisioncode_ind;
		short	contactmethod_ind;
		short	contactmethodid_ind;
		short	servicerepresentativeid_ind;
		short	pan_ind;
		short	paymentinstrumentid_ind;
		short	newcustomerid_ind;
		short	newcustomeracctnumber_ind;
		short	newpan_ind;
		short	newpaymentinstrumentid_ind;
		short	actioncode_ind;
		short	newgivenname_ind;
		short	oldgivenname_ind;
		short	newmiddlename_ind;
		short	oldmiddlename_ind;
		short	newsurname_ind;
		short	oldsurname_ind;
		short	newsuffix_ind;
		short	oldsuffix_ind;
		short	newentityname_ind;
		short	oldentityname_ind;
		short	newstreetline1_ind;
		short	oldstreetline1_ind;
		short	newstreetline2_ind;
		short	oldstreetline2_ind;
		short	newstreetline3_ind;
		short	oldstreetline3_ind;
		short	newstreetline4_ind;
		short	oldstreetline4_ind;
		short	newcity_ind;
		short	oldcity_ind;
		short	newstateprovince_ind;
		short	oldstateprovince_ind;
		short	newpostalcode_ind;
		short	oldpostalcode_ind;
		short	newcountrycode_ind;
		short	oldcountrycode_ind;
		short	newphone1_ind;
		short	oldphone1_ind;
		short	newphone2_ind;
		short	oldphone2_ind;
		short	newemailaddress_ind;
		short	oldemailaddress_ind;
		short	newdate1_ind;
		short	olddate1_ind;
		short	newdate2_ind;
		short	olddate2_ind;
		short	newid1_ind;
		short	oldid1_ind;
		short	newid2_ind;
		short	oldid2_ind;
		short	newcode1_ind;
		short	oldcode1_ind;
		short	newcode2_ind;
		short	oldcode2_ind;
		short	newcode3_ind;
		short	oldcode3_ind;
		short	newindicator1_ind;
		short	oldindicator1_ind;
		short	newindicator2_ind;
		short	oldindicator2_ind;
		short	newindicator3_ind;
		short	oldindicator3_ind;
		short	newindicator4_ind;
		short	oldindicator4_ind;
		short	newmonetaryvalue_ind;
		short	oldmonetaryvalue_ind;
		short	currencycode_ind;
		short	currencyconversionrate_ind;
		short	newnumericvalue1_ind;
		short	oldnumericvalue1_ind;
		short	newnumericvalue2_ind;
		short	oldnumericvalue2_ind;
		short	newcharactervalue_ind;
		short	oldcharactervalue_ind;
		short	newtext_ind;
		short	oldtext_ind;
		short	ctxcomment_ind;
		short	userindicator01_ind;
		short	userindicator02_ind;
		short	userindicator03_ind;
		short	userindicator04_ind;
		short	userindicator05_ind;
		short	usercode1_ind;
		short	usercode2_ind;
		short	usercode3_ind;
		short	usercode4_ind;
		short	usercode5_ind;
		short	userdata01_ind;
		short	userdata02_ind;
		short	userdata03_ind;
		short	userdata04_ind;
		short	userdata05_ind;
		short	userdata06_ind;
		short	userdata07_ind;
		short	userdata08_ind;
		short	userdata09_ind;
		short	userdata10_ind;
		short	userdata11_ind;
		short	userdata12_ind;
		short	userdata13_ind;
		short	userdata14_ind;
		short	userdata15_ind;
		short	reserved_01_ind;
	} HOST_NMON_PIS_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
#define NMON_PISdump(p_NMON_PIS)				NMON_PISdump_IND(p_NMON_PIS, NULL)
#define NMON_PISdumplev(p_NMON_PIS, dbglev)			NMON_PISdumplev_IND(p_NMON_PIS, NULL, dbglev)

extern	int	NMON_PISadd_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND);
extern	int	NMON_PISupdate_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND);
extern	int	NMON_PISdelete(NMON_PIS_t *p_NMON_PIS);
extern	void	NMON_PISdump_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND);
extern	void	NMON_PISdumplev_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND, int dbglev);

extern	int	NMON_PIShv2cs(NMON_PIS_t *p_NMON_PIS);
extern	void	NMON_PIScs2hv(NMON_PIS_t *p_NMON_PIS);
extern	int	NMON_PIShs2cs(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_IND, HOST_NMON_PIS_t *hsData, HOST_NMON_PIS_IND_t *hsInd);

extern	void	NMON_PIScs2hsINS(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_IND, HOST_NMON_PIS_t *hsData, HOST_NMON_PIS_IND_t *hsInd);
extern	void	NMON_PIScs2hs(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_IND, HOST_NMON_PIS_t *hsData, HOST_NMON_PIS_IND_t *hsInd);
extern	void	NMON_PIS_PKdumplev(NMON_PIS_PK_t *p_NMON_PIS_PK, int dbglev);
extern	char	*NMON_PIS_PKkey2str(char *out, NMON_PIS_PK_t *p_NMON_PIS_PK);

extern	int	NMON_PISgetbyNMON_PIS_PK_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND, NMON_PIS_PK_t *p_NMON_PIS_PK);
extern	int	NMON_PISgetbyNMON_PIS_PK4upd_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND, NMON_PIS_PK_t *p_NMON_PIS_PK);
extern	int	NMON_PISupdbyNMON_PIS_PK_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND, NMON_PIS_PK_t *p_NMON_PIS_PK);
extern	int	NMON_PISupdallbyNMON_PIS_PK_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND, NMON_PIS_PK_t *p_NMON_PIS_PK);
extern	int	NMON_PISdelbyNMON_PIS_PK( NMON_PIS_PK_t *p_NMON_PIS_PK);

extern	void	NMON_PISinitDflt(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND);

#ifdef __cplusplus
}
#endif

#endif
