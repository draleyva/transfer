/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	NMON_PIS DAO structure definitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBNMONPISDAO_H
#define __DBNMONPISDAO_H

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table NMON_PIS
 */
typedef struct
{
	long	id;
	long	ctxdate;
	char	workflow[17];
	char	recordtype[9];
	char	dataspecificationversion[6];
	char	clientidfromheader[17];
	long	recordcreationdate;
	long	recordcreationtime;
	long	recordcreationmilliseconds;
	short	gmtoffset;
	char	customeridfromheader[21];
	char	customeracctnumber[41];
	char	externaltransactionid[33];
	long	transactiondate;
	long	transactiontime;
	char	nonmoncode[5];
	char	nonmoncodeinitiator[2];
	char	decisioncode[2];
	char	contactmethod[2];
	char	contactmethodid[41];
	char	servicerepresentativeid[21];
	char	pan[20];
	char	paymentinstrumentid[31];
	char	newcustomerid[21];
	char	newcustomeracctnumber[41];
	char	newpan[20];
	char	newpaymentinstrumentid[31];
	char	actioncode[3];
	char	newgivenname[31];
	char	oldgivenname[31];
	char	newmiddlename[31];
	char	oldmiddlename[31];
	char	newsurname[61];
	char	oldsurname[61];
	char	newsuffix[11];
	char	oldsuffix[11];
	char	newentityname[61];
	char	oldentityname[61];
	char	newstreetline1[41];
	char	oldstreetline1[41];
	char	newstreetline2[41];
	char	oldstreetline2[41];
	char	newstreetline3[41];
	char	oldstreetline3[41];
	char	newstreetline4[41];
	char	oldstreetline4[41];
	char	newcity[41];
	char	oldcity[41];
	char	newstateprovince[4];
	char	oldstateprovince[4];
	char	newpostalcode[11];
	char	oldpostalcode[11];
	char	newcountrycode[4];
	char	oldcountrycode[4];
	char	newphone1[25];
	char	oldphone1[25];
	char	newphone2[25];
	char	oldphone2[25];
	char	newemailaddress[41];
	char	oldemailaddress[41];
	long	newdate1;
	long	olddate1;
	long	newdate2;
	long	olddate2;
	char	newid1[21];
	char	oldid1[21];
	char	newid2[21];
	char	oldid2[21];
	char	newcode1[4];
	char	oldcode1[4];
	char	newcode2[4];
	char	oldcode2[4];
	char	newcode3[4];
	char	oldcode3[4];
	char	newindicator1[2];
	char	oldindicator1[2];
	char	newindicator2[2];
	char	oldindicator2[2];
	char	newindicator3[2];
	char	oldindicator3[2];
	char	newindicator4[2];
	char	oldindicator4[2];
	double	newmonetaryvalue;
	double	oldmonetaryvalue;
	char	currencycode[4];
	double	currencyconversionrate;
	long	newnumericvalue1;
	long	oldnumericvalue1;
	long	newnumericvalue2;
	long	oldnumericvalue2;
	char	newcharactervalue[11];
	char	oldcharactervalue[11];
	char	newtext[61];
	char	oldtext[61];
	char	ctxcomment[51];
	char	userindicator01[2];
	char	userindicator02[2];
	char	userindicator03[2];
	char	userindicator04[2];
	char	userindicator05[2];
	char	usercode1[4];
	char	usercode2[4];
	char	usercode3[4];
	char	usercode4[4];
	char	usercode5[4];
	char	userdata01[7];
	char	userdata02[7];
	char	userdata03[7];
	char	userdata04[9];
	char	userdata05[9];
	char	userdata06[9];
	char	userdata07[11];
	char	userdata08[11];
	char	userdata09[16];
	char	userdata10[16];
	char	userdata11[21];
	char	userdata12[21];
	char	userdata13[41];
	char	userdata14[41];
	char	userdata15[61];
	char	reserved_01[31];
} NMON_PIS_t;

#ifdef __cplusplus
/**
 * Structure for C++ interfacing of table NMON_PIS
 */
struct CppClassNMON_PIS_t : public NMON_PIS_t
{
	CppClassNMON_PIS_t (
		long _id = 0,
		long _ctxdate = 0,
		const char * _workflow = "",
		const char * _recordtype = "",
		const char * _dataspecificationversion = "",
		const char * _clientidfromheader = "",
		long _recordcreationdate = 0,
		long _recordcreationtime = 0,
		long _recordcreationmilliseconds = 0,
		short _gmtoffset = 0,
		const char * _customeridfromheader = "",
		const char * _customeracctnumber = "",
		const char * _externaltransactionid = "",
		long _transactiondate = 0,
		long _transactiontime = 0,
		const char * _nonmoncode = "",
		const char * _nonmoncodeinitiator = "",
		const char * _decisioncode = "",
		const char * _contactmethod = "",
		const char * _contactmethodid = "",
		const char * _servicerepresentativeid = "",
		const char * _pan = "",
		const char * _paymentinstrumentid = "",
		const char * _newcustomerid = "",
		const char * _newcustomeracctnumber = "",
		const char * _newpan = "",
		const char * _newpaymentinstrumentid = "",
		const char * _actioncode = "",
		const char * _newgivenname = "",
		const char * _oldgivenname = "",
		const char * _newmiddlename = "",
		const char * _oldmiddlename = "",
		const char * _newsurname = "",
		const char * _oldsurname = "",
		const char * _newsuffix = "",
		const char * _oldsuffix = "",
		const char * _newentityname = "",
		const char * _oldentityname = "",
		const char * _newstreetline1 = "",
		const char * _oldstreetline1 = "",
		const char * _newstreetline2 = "",
		const char * _oldstreetline2 = "",
		const char * _newstreetline3 = "",
		const char * _oldstreetline3 = "",
		const char * _newstreetline4 = "",
		const char * _oldstreetline4 = "",
		const char * _newcity = "",
		const char * _oldcity = "",
		const char * _newstateprovince = "",
		const char * _oldstateprovince = "",
		const char * _newpostalcode = "",
		const char * _oldpostalcode = "",
		const char * _newcountrycode = "",
		const char * _oldcountrycode = "",
		const char * _newphone1 = "",
		const char * _oldphone1 = "",
		const char * _newphone2 = "",
		const char * _oldphone2 = "",
		const char * _newemailaddress = "",
		const char * _oldemailaddress = "",
		long _newdate1 = 0,
		long _olddate1 = 0,
		long _newdate2 = 0,
		long _olddate2 = 0,
		const char * _newid1 = "",
		const char * _oldid1 = "",
		const char * _newid2 = "",
		const char * _oldid2 = "",
		const char * _newcode1 = "",
		const char * _oldcode1 = "",
		const char * _newcode2 = "",
		const char * _oldcode2 = "",
		const char * _newcode3 = "",
		const char * _oldcode3 = "",
		const char * _newindicator1 = "",
		const char * _oldindicator1 = "",
		const char * _newindicator2 = "",
		const char * _oldindicator2 = "",
		const char * _newindicator3 = "",
		const char * _oldindicator3 = "",
		const char * _newindicator4 = "",
		const char * _oldindicator4 = "",
		double _newmonetaryvalue = 0,
		double _oldmonetaryvalue = 0,
		const char * _currencycode = "",
		double _currencyconversionrate = 0,
		long _newnumericvalue1 = 0,
		long _oldnumericvalue1 = 0,
		long _newnumericvalue2 = 0,
		long _oldnumericvalue2 = 0,
		const char * _newcharactervalue = "",
		const char * _oldcharactervalue = "",
		const char * _newtext = "",
		const char * _oldtext = "",
		const char * _ctxcomment = "",
		const char * _userindicator01 = "",
		const char * _userindicator02 = "",
		const char * _userindicator03 = "",
		const char * _userindicator04 = "",
		const char * _userindicator05 = "",
		const char * _usercode1 = "",
		const char * _usercode2 = "",
		const char * _usercode3 = "",
		const char * _usercode4 = "",
		const char * _usercode5 = "",
		const char * _userdata01 = "",
		const char * _userdata02 = "",
		const char * _userdata03 = "",
		const char * _userdata04 = "",
		const char * _userdata05 = "",
		const char * _userdata06 = "",
		const char * _userdata07 = "",
		const char * _userdata08 = "",
		const char * _userdata09 = "",
		const char * _userdata10 = "",
		const char * _userdata11 = "",
		const char * _userdata12 = "",
		const char * _userdata13 = "",
		const char * _userdata14 = "",
		const char * _userdata15 = "",
		const char * _reserved_01 = ""
		)
	{
		id = _id;
		ctxdate = _ctxdate;
		slstrcpy_sen(workflow, _workflow);
		slstrcpy_sen(recordtype, _recordtype);
		slstrcpy_sen(dataspecificationversion, _dataspecificationversion);
		slstrcpy_sen(clientidfromheader, _clientidfromheader);
		recordcreationdate = _recordcreationdate;
		recordcreationtime = _recordcreationtime;
		recordcreationmilliseconds = _recordcreationmilliseconds;
		gmtoffset = _gmtoffset;
		slstrcpy_sen(customeridfromheader, _customeridfromheader);
		slstrcpy_sen(customeracctnumber, _customeracctnumber);
		slstrcpy_sen(externaltransactionid, _externaltransactionid);
		transactiondate = _transactiondate;
		transactiontime = _transactiontime;
		slstrcpy_sen(nonmoncode, _nonmoncode);
		slstrcpy_sen(nonmoncodeinitiator, _nonmoncodeinitiator);
		slstrcpy_sen(decisioncode, _decisioncode);
		slstrcpy_sen(contactmethod, _contactmethod);
		slstrcpy_sen(contactmethodid, _contactmethodid);
		slstrcpy_sen(servicerepresentativeid, _servicerepresentativeid);
		slstrcpy_sen(pan, _pan);
		slstrcpy_sen(paymentinstrumentid, _paymentinstrumentid);
		slstrcpy_sen(newcustomerid, _newcustomerid);
		slstrcpy_sen(newcustomeracctnumber, _newcustomeracctnumber);
		slstrcpy_sen(newpan, _newpan);
		slstrcpy_sen(newpaymentinstrumentid, _newpaymentinstrumentid);
		slstrcpy_sen(actioncode, _actioncode);
		slstrcpy_sen(newgivenname, _newgivenname);
		slstrcpy_sen(oldgivenname, _oldgivenname);
		slstrcpy_sen(newmiddlename, _newmiddlename);
		slstrcpy_sen(oldmiddlename, _oldmiddlename);
		slstrcpy_sen(newsurname, _newsurname);
		slstrcpy_sen(oldsurname, _oldsurname);
		slstrcpy_sen(newsuffix, _newsuffix);
		slstrcpy_sen(oldsuffix, _oldsuffix);
		slstrcpy_sen(newentityname, _newentityname);
		slstrcpy_sen(oldentityname, _oldentityname);
		slstrcpy_sen(newstreetline1, _newstreetline1);
		slstrcpy_sen(oldstreetline1, _oldstreetline1);
		slstrcpy_sen(newstreetline2, _newstreetline2);
		slstrcpy_sen(oldstreetline2, _oldstreetline2);
		slstrcpy_sen(newstreetline3, _newstreetline3);
		slstrcpy_sen(oldstreetline3, _oldstreetline3);
		slstrcpy_sen(newstreetline4, _newstreetline4);
		slstrcpy_sen(oldstreetline4, _oldstreetline4);
		slstrcpy_sen(newcity, _newcity);
		slstrcpy_sen(oldcity, _oldcity);
		slstrcpy_sen(newstateprovince, _newstateprovince);
		slstrcpy_sen(oldstateprovince, _oldstateprovince);
		slstrcpy_sen(newpostalcode, _newpostalcode);
		slstrcpy_sen(oldpostalcode, _oldpostalcode);
		slstrcpy_sen(newcountrycode, _newcountrycode);
		slstrcpy_sen(oldcountrycode, _oldcountrycode);
		slstrcpy_sen(newphone1, _newphone1);
		slstrcpy_sen(oldphone1, _oldphone1);
		slstrcpy_sen(newphone2, _newphone2);
		slstrcpy_sen(oldphone2, _oldphone2);
		slstrcpy_sen(newemailaddress, _newemailaddress);
		slstrcpy_sen(oldemailaddress, _oldemailaddress);
		newdate1 = _newdate1;
		olddate1 = _olddate1;
		newdate2 = _newdate2;
		olddate2 = _olddate2;
		slstrcpy_sen(newid1, _newid1);
		slstrcpy_sen(oldid1, _oldid1);
		slstrcpy_sen(newid2, _newid2);
		slstrcpy_sen(oldid2, _oldid2);
		slstrcpy_sen(newcode1, _newcode1);
		slstrcpy_sen(oldcode1, _oldcode1);
		slstrcpy_sen(newcode2, _newcode2);
		slstrcpy_sen(oldcode2, _oldcode2);
		slstrcpy_sen(newcode3, _newcode3);
		slstrcpy_sen(oldcode3, _oldcode3);
		slstrcpy_sen(newindicator1, _newindicator1);
		slstrcpy_sen(oldindicator1, _oldindicator1);
		slstrcpy_sen(newindicator2, _newindicator2);
		slstrcpy_sen(oldindicator2, _oldindicator2);
		slstrcpy_sen(newindicator3, _newindicator3);
		slstrcpy_sen(oldindicator3, _oldindicator3);
		slstrcpy_sen(newindicator4, _newindicator4);
		slstrcpy_sen(oldindicator4, _oldindicator4);
		newmonetaryvalue = _newmonetaryvalue;
		oldmonetaryvalue = _oldmonetaryvalue;
		slstrcpy_sen(currencycode, _currencycode);
		currencyconversionrate = _currencyconversionrate;
		newnumericvalue1 = _newnumericvalue1;
		oldnumericvalue1 = _oldnumericvalue1;
		newnumericvalue2 = _newnumericvalue2;
		oldnumericvalue2 = _oldnumericvalue2;
		slstrcpy_sen(newcharactervalue, _newcharactervalue);
		slstrcpy_sen(oldcharactervalue, _oldcharactervalue);
		slstrcpy_sen(newtext, _newtext);
		slstrcpy_sen(oldtext, _oldtext);
		slstrcpy_sen(ctxcomment, _ctxcomment);
		slstrcpy_sen(userindicator01, _userindicator01);
		slstrcpy_sen(userindicator02, _userindicator02);
		slstrcpy_sen(userindicator03, _userindicator03);
		slstrcpy_sen(userindicator04, _userindicator04);
		slstrcpy_sen(userindicator05, _userindicator05);
		slstrcpy_sen(usercode1, _usercode1);
		slstrcpy_sen(usercode2, _usercode2);
		slstrcpy_sen(usercode3, _usercode3);
		slstrcpy_sen(usercode4, _usercode4);
		slstrcpy_sen(usercode5, _usercode5);
		slstrcpy_sen(userdata01, _userdata01);
		slstrcpy_sen(userdata02, _userdata02);
		slstrcpy_sen(userdata03, _userdata03);
		slstrcpy_sen(userdata04, _userdata04);
		slstrcpy_sen(userdata05, _userdata05);
		slstrcpy_sen(userdata06, _userdata06);
		slstrcpy_sen(userdata07, _userdata07);
		slstrcpy_sen(userdata08, _userdata08);
		slstrcpy_sen(userdata09, _userdata09);
		slstrcpy_sen(userdata10, _userdata10);
		slstrcpy_sen(userdata11, _userdata11);
		slstrcpy_sen(userdata12, _userdata12);
		slstrcpy_sen(userdata13, _userdata13);
		slstrcpy_sen(userdata14, _userdata14);
		slstrcpy_sen(userdata15, _userdata15);
		slstrcpy_sen(reserved_01, _reserved_01);
	}
};
#endif /*__cplusplus*/
/**
 * Structure of indicators for table  NMON_PIS 
 */
typedef struct
{
	short	id;
	short	ctxdate;
	short	workflow;
	short	recordtype;
	short	dataspecificationversion;
	short	clientidfromheader;
	short	recordcreationdate;
	short	recordcreationtime;
	short	recordcreationmilliseconds;
	short	gmtoffset;
	short	customeridfromheader;
	short	customeracctnumber;
	short	externaltransactionid;
	short	transactiondate;
	short	transactiontime;
	short	nonmoncode;
	short	nonmoncodeinitiator;
	short	decisioncode;
	short	contactmethod;
	short	contactmethodid;
	short	servicerepresentativeid;
	short	pan;
	short	paymentinstrumentid;
	short	newcustomerid;
	short	newcustomeracctnumber;
	short	newpan;
	short	newpaymentinstrumentid;
	short	actioncode;
	short	newgivenname;
	short	oldgivenname;
	short	newmiddlename;
	short	oldmiddlename;
	short	newsurname;
	short	oldsurname;
	short	newsuffix;
	short	oldsuffix;
	short	newentityname;
	short	oldentityname;
	short	newstreetline1;
	short	oldstreetline1;
	short	newstreetline2;
	short	oldstreetline2;
	short	newstreetline3;
	short	oldstreetline3;
	short	newstreetline4;
	short	oldstreetline4;
	short	newcity;
	short	oldcity;
	short	newstateprovince;
	short	oldstateprovince;
	short	newpostalcode;
	short	oldpostalcode;
	short	newcountrycode;
	short	oldcountrycode;
	short	newphone1;
	short	oldphone1;
	short	newphone2;
	short	oldphone2;
	short	newemailaddress;
	short	oldemailaddress;
	short	newdate1;
	short	olddate1;
	short	newdate2;
	short	olddate2;
	short	newid1;
	short	oldid1;
	short	newid2;
	short	oldid2;
	short	newcode1;
	short	oldcode1;
	short	newcode2;
	short	oldcode2;
	short	newcode3;
	short	oldcode3;
	short	newindicator1;
	short	oldindicator1;
	short	newindicator2;
	short	oldindicator2;
	short	newindicator3;
	short	oldindicator3;
	short	newindicator4;
	short	oldindicator4;
	short	newmonetaryvalue;
	short	oldmonetaryvalue;
	short	currencycode;
	short	currencyconversionrate;
	short	newnumericvalue1;
	short	oldnumericvalue1;
	short	newnumericvalue2;
	short	oldnumericvalue2;
	short	newcharactervalue;
	short	oldcharactervalue;
	short	newtext;
	short	oldtext;
	short	ctxcomment;
	short	userindicator01;
	short	userindicator02;
	short	userindicator03;
	short	userindicator04;
	short	userindicator05;
	short	usercode1;
	short	usercode2;
	short	usercode3;
	short	usercode4;
	short	usercode5;
	short	userdata01;
	short	userdata02;
	short	userdata03;
	short	userdata04;
	short	userdata05;
	short	userdata06;
	short	userdata07;
	short	userdata08;
	short	userdata09;
	short	userdata10;
	short	userdata11;
	short	userdata12;
	short	userdata13;
	short	userdata14;
	short	userdata15;
	short	reserved_01;
} NMON_PIS_IND_t;

/**
 * Structure to retrieve NMON_PIS by Primary Key PK_NMON_PIS
 */
typedef struct
{
	long	id;
} NMON_PIS_PK_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/

#endif
