/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CRDPINMIGR type defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBCRDPINMIGRRH_H
#define __DBCRDPINMIGRRH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
#include <dbcrdpinmigrbsd.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define CRDPINMIGR_PK_PREP2 \
	CRDPINMIGR_PKid = p_CRDPINMIGR_PK->id;\

#define CRDPINMIGR_PK_PREP1 \
	crdpinmigr.id = :v1 
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
#include <dbcrdpinmigrdao.h>
/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif
#define CRDPINMIGRadd(pdata)					CRDPINMIGRadd_IND(pdata, NULL)
#define CRDPINMIGRupdate(pdata)					CRDPINMIGRupdate_IND(pdata, NULL)
#define CRDPINMIGRgetbyCRDPINMIGR_PK(pdata, phash)		CRDPINMIGRgetbyCRDPINMIGR_PK_IND(pdata, NULL, phash)
#define CRDPINMIGRgetbyCRDPINMIGR_PK4upd(pdata, phash)		CRDPINMIGRgetbyCRDPINMIGR_PK4upd_IND(pdata, NULL, phash)
#define CRDPINMIGRupdbyCRDPINMIGR_PK(pdata, phash)		CRDPINMIGRupdbyCRDPINMIGR_PK_IND(pdata, NULL, phash)
#define CRDPINMIGRupdallbyCRDPINMIGR_PK(pdata, phash)		CRDPINMIGRupdallbyCRDPINMIGR_PK_IND(pdata, NULL, phash)
#define CRDPINMIGRdump(p_CRDPINMIGR)				CRDPINMIGRdump_IND(p_CRDPINMIGR, NULL)
#define CRDPINMIGRdumplev(p_CRDPINMIGR, dbglev)			CRDPINMIGRdumplev_IND(p_CRDPINMIGR, NULL, dbglev)

extern	int	CRDPINMIGRadd_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND);
extern	int	CRDPINMIGRupdate_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND);
extern	int	CRDPINMIGRdelete(CRDPINMIGR_t *p_CRDPINMIGR);

extern	void	CRDPINMIGRdump_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND);
extern	void	CRDPINMIGRdumplev_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND, int dbglev);

extern	char	*CRDPINMIGR_PKkey2str(char *out, CRDPINMIGR_PK_t *p_CRDPINMIGR_PK);

extern	int	CRDPINMIGRgetbyCRDPINMIGR_PK_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND, CRDPINMIGR_PK_t *p_CRDPINMIGR_PK);
extern	int	CRDPINMIGRgetbyCRDPINMIGR_PK4upd_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND, CRDPINMIGR_PK_t *p_CRDPINMIGR_PK);
extern	int	CRDPINMIGRupdbyCRDPINMIGR_PK_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND, CRDPINMIGR_PK_t *p_CRDPINMIGR_PK);
extern	int	CRDPINMIGRupdallbyCRDPINMIGR_PK_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND, CRDPINMIGR_PK_t *p_CRDPINMIGR_PK);
extern	int	CRDPINMIGRdelbyCRDPINMIGR_PK( CRDPINMIGR_PK_t *p_CRDPINMIGR_PK);
extern	void	CRDPINMIGRinitDflt(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND);

#ifdef __cplusplus
}
#endif

#endif
