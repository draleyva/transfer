/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	FPADREC DAO structure definitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBFPADRECDAO_H
#define __DBFPADRECDAO_H

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table FPADREC
 */
typedef struct
{
	long	id;
	long	crddet_id;
	long	datecreated;
	long	timecreated;
	long	dateupdated;
	long	timeupdated;
	char	actioncode[2];
	char	rspcode[3];
	short	crdacptbus;
	char	crdacptloc_postcode[11];
	char	decision_code_1[33];
	char	decision_code_2[33];
	char	decision_code_3[33];
	char	decision_code_4[33];
	char	decision_code_5[33];
	char	decision_code_6[33];
	char	decision_code_7[33];
	char	decision_code_8[33];
	char	decision_code_9[33];
	char	decision_code_10[33];
} FPADREC_t;

#ifdef __cplusplus
/**
 * Structure for C++ interfacing of table FPADREC
 */
struct CppClassFPADREC_t : public FPADREC_t
{
	CppClassFPADREC_t (
		long _id = 0,
		long _crddet_id = 0,
		long _datecreated = 0,
		long _timecreated = 0,
		long _dateupdated = 0,
		long _timeupdated = 0,
		const char * _actioncode = "",
		const char * _rspcode = "",
		short _crdacptbus = 0,
		const char * _crdacptloc_postcode = "",
		const char * _decision_code_1 = "",
		const char * _decision_code_2 = "",
		const char * _decision_code_3 = "",
		const char * _decision_code_4 = "",
		const char * _decision_code_5 = "",
		const char * _decision_code_6 = "",
		const char * _decision_code_7 = "",
		const char * _decision_code_8 = "",
		const char * _decision_code_9 = "",
		const char * _decision_code_10 = ""
		)
	{
		id = _id;
		crddet_id = _crddet_id;
		datecreated = _datecreated;
		timecreated = _timecreated;
		dateupdated = _dateupdated;
		timeupdated = _timeupdated;
		slstrcpy_sen(actioncode, _actioncode);
		slstrcpy_sen(rspcode, _rspcode);
		crdacptbus = _crdacptbus;
		slstrcpy_sen(crdacptloc_postcode, _crdacptloc_postcode);
		slstrcpy_sen(decision_code_1, _decision_code_1);
		slstrcpy_sen(decision_code_2, _decision_code_2);
		slstrcpy_sen(decision_code_3, _decision_code_3);
		slstrcpy_sen(decision_code_4, _decision_code_4);
		slstrcpy_sen(decision_code_5, _decision_code_5);
		slstrcpy_sen(decision_code_6, _decision_code_6);
		slstrcpy_sen(decision_code_7, _decision_code_7);
		slstrcpy_sen(decision_code_8, _decision_code_8);
		slstrcpy_sen(decision_code_9, _decision_code_9);
		slstrcpy_sen(decision_code_10, _decision_code_10);
	}
};
#endif /*__cplusplus*/
/**
 * Structure of indicators for table  FPADREC 
 */
typedef struct
{
	short	id;
	short	crddet_id;
	short	datecreated;
	short	timecreated;
	short	dateupdated;
	short	timeupdated;
	short	actioncode;
	short	rspcode;
	short	crdacptbus;
	short	crdacptloc_postcode;
	short	decision_code_1;
	short	decision_code_2;
	short	decision_code_3;
	short	decision_code_4;
	short	decision_code_5;
	short	decision_code_6;
	short	decision_code_7;
	short	decision_code_8;
	short	decision_code_9;
	short	decision_code_10;
} FPADREC_IND_t;

/**
 * Structure to retrieve FPADREC by Primary Key HASH_FPADREC
 */
typedef struct
{
	long	crddet_id;
} FPADREC_HASH_t;

/**
 * Structure to retrieve FPADREC by Primary Key PK_FPADREC
 */
typedef struct
{
	long	id;
} FPADREC_PK_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/

#endif
