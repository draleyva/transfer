-- additional keys for table: crdstatmap
create index fk_crdstatmap_code_crdstatus
        on crdstatmap (ctx_statcode);

alter table crdstatmap
        add constraint fk_crdstatmap_code_crdstatus 
	foreign key (ctx_statcode)
	references crdstatus (statcode)
	on delete cascade;
