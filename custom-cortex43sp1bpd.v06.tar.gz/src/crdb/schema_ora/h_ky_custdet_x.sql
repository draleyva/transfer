-- additional keys for table: custdet_x
create unique index fk_custdet_x_id_custdet
        on custdet_x (custdet_id);

alter table custdet_x
        add constraint fk_custdet_x_id_custdet 
	foreign key (custdet_id)
	references custdet (id)
	on delete cascade;

