-- Schema for table: custdet_x

create table custdet_x
(
	verno_ctx		number(10,0)	default 1	not null,
	id			number(10,0)	not null,
	custdet_id		number(10,0)	default 0	not null,
	usrdata1		varchar2(32)	not null,
	usrdata2		varchar2(32)	not null,
	usrdata3		varchar2(32)	not null,
	usrdata4		varchar2(32)	not null,
	usrdata5		varchar2(32)	not null,
	usrdata6		varchar2(32)	not null
);

create sequence custdet_x_sequence start with 1;

