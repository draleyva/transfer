CREATE OR REPLACE TRIGGER custdet_x_change BEFORE UPDATE
ON
	custdet_x
REFERENCING OLD old_custdet_x NEW new_custdet_x
FOR EACH ROW
BEGIN
	:new_custdet_x.verno_ctx := :old_custdet_x.verno_ctx + 1;

	if (:old_custdet_x.usrdata1 != :new_custdet_x.usrdata1 ) then
		write_acslog('CUSTDET_X' ,:old_custdet_x.custdet_id ,
			'USRDATA1' ,:old_custdet_x.usrdata1 ,
			:new_custdet_x.usrdata1 );
	end if;   

	if (:old_custdet_x.usrdata2 != :new_custdet_x.usrdata2 ) then
		write_acslog('CUSTDET_X' ,:old_custdet_x.custdet_id ,
			'USRDATA2' ,:old_custdet_x.usrdata2 ,
			:new_custdet_x.usrdata2 );
	end if;   

	if (:old_custdet_x.usrdata3 != :new_custdet_x.usrdata3 ) then
		write_acslog('CUSTDET_X' ,:old_custdet_x.custdet_id ,
			'USRDATA3' ,:old_custdet_x.usrdata3 ,
			:new_custdet_x.usrdata3 );
	end if;   

	if (:old_custdet_x.usrdata4 != :new_custdet_x.usrdata4 ) then
		write_acslog('CUSTDET_X' ,:old_custdet_x.custdet_id ,
			'USRDATA4' ,:old_custdet_x.usrdata4 ,
			:new_custdet_x.usrdata4 );
	end if;   

	if (:old_custdet_x.usrdata5 != :new_custdet_x.usrdata5 ) then
		write_acslog('CUSTDET_X' ,:old_custdet_x.custdet_id ,
			'USRDATA5' ,:old_custdet_x.usrdata5 ,
			:new_custdet_x.usrdata5 );
	end if;   

	if (:old_custdet_x.usrdata6 != :new_custdet_x.usrdata6 ) then
		write_acslog('CUSTDET_X' ,:old_custdet_x.custdet_id ,
			'USRDATA6' ,:old_custdet_x.usrdata6 ,
			:new_custdet_x.usrdata6 );
	end if;   

END;
/
