-- Schema for table: crdstatmap

create table crdstatmap
(
	verno_ctx		number(10,0)	default 1	not null,
	ctx_statcode	char(2)			default '00'	not null,
	ext_statcode	varchar2(5)		not null,
	descr			varchar2(30)	not null
);
