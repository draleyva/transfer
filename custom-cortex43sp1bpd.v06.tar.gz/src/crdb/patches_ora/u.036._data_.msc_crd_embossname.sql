-- Insert 'crd_embossname_size' and 'crd_embossname_maxlength' in MSC table  for BPD
Insert into MSC (TAG,IDX,MSCMODULE,DESCR,MASK,STRING_T,LONG_T,SHORT_T,DOUBLE_T,DATE_T) values ('crd_embossname_size',0,'ia',0,0,' ',0,30,0,to_date('31-AUG-2263','DD-MON-RRRR'));
Insert into MSC (TAG,IDX,MSCMODULE,DESCR,MASK,STRING_T,LONG_T,SHORT_T,DOUBLE_T,DATE_T) values ('crd_embossname_maxlength',0,'ia',0,0,' ',0,20,0,to_date('31-AUG-2263','DD-MON-RRRR'));
commit;
