-- Update schema for table: PIS12_DELTA

ALTER TABLE PIS12_DELTA ADD
(
	workflow			varchar2(16)	default 'DEBIT'	not null,
	recordtype			varchar2(8)	default 'PIS12'	not null,
	dataspecificationversion	varchar2(5)	default '1.2'	not null,
	clientidfromheader		varchar2(16)	default 'BPDDB'	not null
);
