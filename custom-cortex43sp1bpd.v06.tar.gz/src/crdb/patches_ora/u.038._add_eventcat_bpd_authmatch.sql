

call addupd_event('authmatchok', 4, 'AUTHMATCH finished %s', 'Matching process', 'EN');

call addupd_event('authmatchok', 4, 'AUTHMATCH finished %s', 'Matching process', 'ES');

call addupd_event('authmatcherr', 3, 'AUTHMATCH finished with %s !!, check logs. upload.pl stopped', 'Matching process', 'EN');

call addupd_event('authmatcherr', 3, 'AUTHMATCH finished with %s !!, check logs. upload.pl stopped', 'Matching process', 'ES');

