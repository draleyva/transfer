--
-- EMVPROFILE_FALCONMON_UPDATE  (Trigger) 
--
CREATE OR REPLACE TRIGGER EMVPROFILE_FALCONMON_UPDATE AFTER UPDATE ON EMVPROFILE
REFERENCING OLD old_emvprofile NEW new_emvprofile
FOR EACH ROW
BEGIN
	IF (:old_emvprofile.scheme <> :new_emvprofile.scheme
		or :old_emvprofile.chipref <> :new_emvprofile.chipref) THEN
			pis12_addlog('EMVPROFILE', :new_emvprofile.id, 'U', ind2=>'1');
	END IF;
END;
/

