INSERT INTO DESCR (verno_ctx, descrtag, descr, lang)
	VALUES (1, (select max(descrtag)+1 from descr), 'Non-active Card Statuses', 'EN');

INSERT INTO DESCR (verno_ctx, descrtag, descr, lang)
	VALUES (1, (select max(descrtag) from descr), 'Non-active Card Statuses', 'GB');

INSERT INTO MSC (verno_ctx, tag, idx, mscmodule, descr, mask, string_t, long_t, short_t, double_t, date_t)  
	VALUES (1, 'crdstat_nonactive', 1, 'ia', (select max(descrtag) from descr), 1, '02', 0, 0, 0.00, to_date('2263-08-31','YYYY-MM-DD'));
