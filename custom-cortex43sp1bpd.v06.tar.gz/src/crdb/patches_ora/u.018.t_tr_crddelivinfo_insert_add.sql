
create or replace trigger crddelivinfo_insert before insert on crddelivinfo
referencing new as new_crddelivinfo
for each row
begin
        if (:new_crddelivinfo.id is null or :new_crddelivinfo.id = 0) then
                select crddelivinfo_sequence.nextval into :new_crddelivinfo.id from dual;
        end if;
end;
/

