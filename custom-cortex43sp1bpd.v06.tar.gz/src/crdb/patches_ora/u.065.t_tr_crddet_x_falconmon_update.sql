--
-- CRDDET_X_FALCONMON_UPDATE  (Trigger) 
--
CREATE OR REPLACE TRIGGER CRDDET_X_FALCONMON_UPDATE AFTER UPDATE ON CRDDET_X
REFERENCING OLD old_crddet_x NEW new_crddet_x
FOR EACH ROW
BEGIN
	IF (:new_crddet_x.datelstissued <> :old_crddet_x.datelstissued) THEN
		pis12_addlog('CRDDET_X', :new_crddet_x.crddet_id, 'U', ind2=>'1', ind3=>'1');
	END IF;
END;
/

