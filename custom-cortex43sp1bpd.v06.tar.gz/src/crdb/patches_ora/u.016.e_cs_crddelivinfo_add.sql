
create unique index pk_crddelivinfo
	on crddelivinfo (id);

alter table crddelivinfo
	add constraint pk_crddelivinfo primary key (id);