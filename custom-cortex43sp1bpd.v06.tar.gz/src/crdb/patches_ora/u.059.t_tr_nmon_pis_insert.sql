--
-- NMON_PIS_INSERT  (Trigger) 
--
CREATE OR REPLACE TRIGGER NMON_PIS_INSERT before insert ON NMON_PIS 
referencing new as new_nmon_pis
for each row
begin
    if (:new_nmon_pis.id is null or :new_nmon_pis.id = 0) then
        select nmon_pis_sequence.nextval into :new_nmon_pis.id from dual;
    end if;
end;
/

