
create or replace procedure fds_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag		number(10,0);
t_maxorder  number(10,0);
t_rporder		number(10,0);
i           number(5,0);
begin


select max(descrtag) into t_maxtag
		from descr;


       
select max(morder) into t_maxorder from menu where mitem ='au_'  and usrgrp=p_usrgrp;


update menu set morder = t_maxorder + 1 where morder = t_maxorder and mitem ='au_' and usrgrp=p_usrgrp;


t_maxtag := t_maxtag + 1;

   -- Add FDS as Authoriser Sub Menu    
   insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag)
   values('au_fds','J2EM',' ',' ',' ',t_maxtag);
   insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype)
   values('au_','au_fds',t_maxtag,t_maxorder,p_usrgrp,'J2EM');
   insert into descr(descrtag,descr,lang)
   values(t_maxtag,'Fraud Detection','EN');
   insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) 
   values('au_fds',p_usrgrp,'Y','N',15);
   

   
    -- Add Host Maintenance as the 1st submenu    
   t_maxtag := t_maxtag + 1;
   
   insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag)
   values('au_fdshost','J2EM',' ',' ',' ',t_maxtag);
   insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype)
   values('au_fds','au_fdshost',t_maxtag,1,p_usrgrp,'J2EM');
   insert into descr(descrtag,descr,lang)
   values(t_maxtag,'Host Maintenance','EN');
   insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) 
   values('au_fdshost',p_usrgrp,'Y','N',15);

   -- Add Host Maintenance Add as sub sub menu       
   t_maxtag := t_maxtag + 1;
   
   insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag)
   values('ia_fdshosdd','J2EF',' ','iafdshostdetailon.do',' ',t_maxtag);
   insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype)
   values('au_fdshost','ia_fdshosdd',t_maxtag,1,p_usrgrp,'J2EF');
   insert into descr(descrtag,descr,lang)
   values(t_maxtag,'Add','EN');
   insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) 
   values('ia_fdshosdd',p_usrgrp,'Y','N',15);
      
   -- Add Host Maintenance Search as sub sub menu       
   t_maxtag := t_maxtag + 1;

   insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag)
   values('ia_fdshossch','J2EF',' ','iafdshostsearchon.do',' ',t_maxtag);
   insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype)
   values('au_fdshost','ia_fdshossch',t_maxtag,2,p_usrgrp,'J2EF');
   insert into descr(descrtag,descr,lang)
   values(t_maxtag,'Search','EN');
   insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) 
   values('ia_fdshossch',p_usrgrp,'Y','N',15);

    -- Add Host Maintenance as the 2nd submenu    
   t_maxtag := t_maxtag + 1;
   
   insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag)
   values('au_fdsrule','J2EM',' ',' ',' ',t_maxtag);
   insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype)
   values('au_fds','au_fdsrule',t_maxtag,2,p_usrgrp,'J2EM');
   insert into descr(descrtag,descr,lang)
   values(t_maxtag,'Rule Maintenance','EN');
   insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) 
   values('au_fdsrule',p_usrgrp,'Y','N',15);

   -- Add Host Maintenance Add as sub sub menu       
   t_maxtag := t_maxtag + 1;
   
   insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag)
   values('ia_fdsruldd','J2EF',' ','iafdsrulesdetailon.do',' ',t_maxtag);
   insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype)
   values('au_fdsrule','ia_fdsruldd',t_maxtag,1,p_usrgrp,'J2EF');
   insert into descr(descrtag,descr,lang)
   values(t_maxtag,'Add','EN');
   insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) 
   values('ia_fdsruldd',p_usrgrp,'Y','N',15);
      
   -- Add Host Maintenance Search as sub sub menu       
   t_maxtag := t_maxtag + 1;

   insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag)
   values('ia_fdsrulsch','J2EF',' ','iafdsrulessearchon.do',' ',t_maxtag);
   insert into MENU(mitem,acsitem,descrtag,morder,usrgrp,acstype)
   values('au_fdsrule','ia_fdsrulsch',t_maxtag,2,p_usrgrp,'J2EF');
   insert into descr(descrtag,descr,lang)
   values(t_maxtag,'Search','EN');
   insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) 
   values('ia_fdsrulsch',p_usrgrp,'Y','N',15);

   -- no rules at the moment
   delete from menu where acsitem in ('au_fdsrule');
end;
/

-- Fix any old records in db
DELETE FROM MENU WHERE ACSITEM in    ('au_fds', 'au_fdshost', 'ia_fdshosdd', 'ia_fdshossch', 'au_fdsrule', 'ia_fdsruldd', 'ia_fdsrulsch');
DELETE FROM MENU WHERE MITEM in    ('au_fds', 'au_fdshost', 'ia_fdshosdd', 'ia_fdshossch', 'au_fdsrule', 'ia_fdsruldd', 'ia_fdsrulsch');
DELETE FROM GRPPERM WHERE ACSITEM in ('au_fds', 'au_fdshost', 'ia_fdshosdd', 'ia_fdshossch', 'au_fdsrule', 'ia_fdsruldd', 'ia_fdsrulsch');
DELETE FROM ACSITEM WHERE ACSITEM in ('au_fds', 'au_fdshost', 'ia_fdshosdd', 'ia_fdshossch', 'au_fdsrule', 'ia_fdsruldd', 'ia_fdsrulsch');

call fds_menu('cortex');
drop procedure fds_menu;


