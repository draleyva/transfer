--
-- CDSTHST_FALCONMON_INSERT  (Trigger) 
--
CREATE OR REPLACE TRIGGER CDSTHST_FALCONMON_INSERT AFTER INSERT ON CDSTHST 
REFERENCING NEW AS new_cdsthst
FOR EACH ROW
BEGIN
	IF (:new_cdsthst.old_statcode not in ('02') or :new_cdsthst.new_statcode not in ('00', '26')) THEN
		    nmon_addlog('CDSTHST', :new_cdsthst.crddet_id, 'I', '3102', 
				newvalue1=>TO_CHAR(:new_cdsthst.date_set, 'YYYYMMDD'),
				newvalue2=>:new_cdsthst.new_statcode,
				oldvalue2=>:new_cdsthst.old_statcode,
				newvalue3=>:new_cdsthst.time_set
		    );
    	END IF;
END;
/

