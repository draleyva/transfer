/*-----------------------------------------------------------------------
 * 
 * File		: pis12loghash.h
 * 
 * Author	: Ruslans Vasiljevs
 * 
 * Created	: 29/06/2022
 *
 * Purpose	: Functions of hashed tables for pis12gen
 * 
 * Comments	: 
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
 *-----------------------------------------------------------------------*/

#ifndef __PIS12LOGHASH_H
#define __PIS12LOGHASH_H
/*---------------------------Includes-----------------------------------*/
#include <uthash.h>

#include <dbpis12logrh.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define HASHMAP_ITER(head,el) HASH_ITER(hh,head,el,M_hash_tmp)
#define PIS12LOG_HASH_ITER(head,el) HASH_ITER(hh,head,el,M_loghash_tmp)

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
typedef struct 
{
    char tablename[PIS12_LOG_TABLENAME_BUFFSIZE];
    char keydata[PIS12_LOG_KEYDATA_BUFFSIZE];
    char indicator1[PIS12_LOG_INDICATOR1_BUFFSIZE];
    char indicator2[PIS12_LOG_INDICATOR2_BUFFSIZE];
    char indicator3[PIS12_LOG_INDICATOR3_BUFFSIZE];
    long crddet_breakpoint;
    long token_breakpoint;
    UT_hash_handle hh; /* makes this structure hashable */
} pis12log_hash_t;

typedef struct 
{
    long id;
    char *keyword;
    UT_hash_handle hh; /* makes this structure hashable */
} hashmap_t;

/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
ctxprivate pis12log_hash_t *M_loghash_tmp;
ctxprivate hashmap_t *M_hash_tmp;

/*---------------------------Prototypes---------------------------------*/
extern pis12log_hash_t *pis12loghash_add(pis12log_hash_t pis12log_hash);
extern pis12log_hash_t *pis12loghash_find(pis12log_hash_t *p_pis12log_hash);
extern void pis12loghash_delete(pis12log_hash_t *p_pis12log_hash);
extern int32_t pis12loghash_delete_all(void);
extern pis12log_hash_t *pis12loghash_get(void);
extern size_t pis12loghash_memory_size(void);

extern hashmap_t *crddetid_hashmap_add(hashmap_t crddetid_hashmap);
extern hashmap_t *crddetid_hashmap_find(long id);
extern void crddetid_hashmap_delete(hashmap_t *p_crddetid_hashmap);
extern int32_t crddetid_hashmap_delete_all(void);
extern hashmap_t *crddetid_hashmap_get(void);

extern hashmap_t *tokenid_hashmap_add(hashmap_t tokenid_hashmap);
extern hashmap_t *tokenid_hashmap_find(long id);
extern void tokenid_hashmap_delete(hashmap_t *p_tokenid_hashmap);
extern int32_t tokenid_hashmap_delete_all(void);
extern hashmap_t *tokenid_hashmap_get(void);

extern size_t hashmap_memory_size(void);

#endif /* __PIS12LOGHASH_H */
