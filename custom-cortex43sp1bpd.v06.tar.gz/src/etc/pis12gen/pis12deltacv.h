/*-----------------------------------------------------------------------
 * 
 * File		: pis12deltacv.h
 * 
 * Author	: Ruslans Vasiljevs
 * 
 * Created	: 26/07/2022
 *
 * Purpose	: PIS12_DELTA data conversion mapping
 * 
 * Comments	: 
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
 *-----------------------------------------------------------------------*/

#ifndef __PIS12DELTACV_H
#define __PIS12DELTACV_H
/*---------------------------Includes-----------------------------------*/
#include <portable.h>

#include <dbpis12deltarh.h>
#include <dbcdetrh.h>
#include <dbcprorh.h>
#include <dbcfmtrh.h>
#include <dbadetrh.h>
#include <dbcustrh.h>
#include <dbtokenrh.h>
#include <dbcplmrh.h>
#include <dbemvprofilerh.h>
#include <dbemvconfrh.h>
#include <dbinstrh.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define PIS12_TYPE_CARD		1
#define PIS12_TYPE_TOKEN	2

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
typedef struct PIS12_Data
{
    char		*timestamp;
    char		*keyword;
    TOKEN_t		token;
    CRDDET_t		crddet;
    CRDFORMAT_t		crdformat;
    CRDPRODUCT_t	crdproduct;
    ACCDET_t		accdet;
    CUSTDET_t		custdet;
    INST_t		inst;
    /* Lazy */
    CRDPRODLIM_t	crdprodlim;
    EMVPROFILE_t	emvprofile;
    EMVCONF_t		emvconf;
} PIS12_Data_t;

/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
ctxpublic void set_workflow(char *workflow);
ctxpublic void set_clientid(char *clientid);

ctxpublic int pis12_delta_map_crddet(PIS12_DELTA_t *p_pis12delta, PIS12_Data_t *p_pis12data, ctxbool errorignore);
ctxpublic int pis12_delta_map_token(PIS12_DELTA_t *p_pis12delta, PIS12_Data_t *p_pis12data, ctxbool errorignore);

#endif /* __PIS12DELTACV_H */
