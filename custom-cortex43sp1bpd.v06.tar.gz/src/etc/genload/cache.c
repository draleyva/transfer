/*-----------------------------------------------------------------------
 *
 * File		: cache.ec
 *
 * Author	: Graeme Thomas
 *
 * Created	: 1999-02-16
 *
 * Purpose	: Cache of database records
 *
 * Comments	: The routines in this file all have the same basic structure.
 *		: They maintain an array of allocated items, together with a
 *		: count of the numbers used and allocated.  When they're called
 *		: they search through the array for a valid entry.  If they
 *		: find one, they return it.  Otherwise, they search the
 *		: database for the item, and add it to the array.
 *
 * Ident	: $Id$
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include "constant.h"

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
static char rcsid[] = "$Id$";

/*---------------------------Prototypes---------------------------------*/
/*---------------------------Functions----------------------------------*/
/*--------------------------------------------------------------------------
 *
 * Function	: lookup_isocode
 *
 * Purpose	: find an isocode from an account
 *
 * Parameters	: p_accdet -> pointer to account details
 *		  p_isocode -> pointer to returned code
 *
 * Returns	: SUCCESS/FAIL
 *
 * Comments	: The instcode/typecode keys are cached
 *
 *------------------------------------------------------------------------*/
ctxpublic int lookup_isocode (ACCDET_t *p_accdet, short *p_isocode)
{
	int            ret = SUCCEED;
	ACCTYPE_t      acctyp;
	ACCTYPE_HASH_t acctyp_k;
	INST_t	inst;
	INST_PK_t	inst_k;
	int            i;
	typedef struct {
		char instcode[5];
		char typecode[3];
		short isocode;
	} iso_cache_t;
	static struct {
		int alloc;
		int used;
		iso_cache_t *ic;
	} cache;

	DBG_PRINTF((dbg_progdetail, "lookup_isocode: looking for <%ld>/<%s>",
				p_accdet->inst_id, p_accdet->typecode));
				
	inst_k.id = p_accdet->inst_id;
	if (SUCCEED != (ret = INSTgetbyINST_PK_cache (&inst, &inst_k)))
		DBG_PRINTF((dbg_syserr, "inst_id %ld", inst_k.id));
	
	/*
	 * See if the instcode/typecode are in the cache
	 */
	for (i = 0; i < cache.used; i++)
	{
		DBG_PRINTF((dbg_progdetail, "Cache [%d]: <%s>/<%s>",
			i, cache.ic[i].instcode, cache.ic[i].typecode));
		if (!strcmp (inst.instcode, cache.ic[i].instcode) &&
		    !strcmp (p_accdet->typecode, cache.ic[i].typecode))
		{
			*p_isocode = cache.ic[i].isocode;
			DBG_PRINTF((dbg_progdetail, "Found %d in cache",
							*p_isocode));
			return SUCCEED;
		}
	}

	/*
	 * They're not in the cache.  Try the hard way.
	 */
	acctyp_k.inst_id = p_accdet->inst_id;
	strscpy (acctyp_k.typecode, p_accdet->typecode);
	if (SUCCEED != ACCTYPEgetbyACCTYPE_HASH_cache (&acctyp, &acctyp_k))
	{
		DBG_PRINTF ((dbg_syserr, "lookup acctyp"));
		ret = FAIL;
	}
	else
	{
		*p_isocode = acctyp.isocode;
		DBG_PRINTF((dbg_progdetail, "Found %d in table", *p_isocode));
	}

	/*
	 * Now try to store the code in the cache. It isn't an error to fail
	 * to get the memory, as we have already found the code.
	 */
	if (ret == SUCCEED && cache.used >= cache.alloc)
	{
		int n = cache.alloc ? (cache.alloc << 1) : 4;
		iso_cache_t *icp;

		icp = (iso_cache_t *)realloc (cache.ic, n*sizeof (iso_cache_t));
		if (icp != NULL)
		{
			cache.ic    = icp;
			cache.alloc = n;
			DBG_PRINTF((dbg_progdetail, "Allocated %d cache", n));
		}
	}

	if (ret == SUCCEED && cache.used < cache.alloc)
	{
		strcpy (cache.ic[cache.used].instcode, inst.instcode);
		strcpy (cache.ic[cache.used].typecode, p_accdet->typecode);
		cache.ic[cache.used].isocode = acctyp.isocode;
		cache.used++;
		DBG_PRINTF((dbg_progdetail, "Used %d cache", cache.used));

	}

	return ret;
}

/*--------------------------------------------------------------------------
 *
 * Function	: lookup_crdproduct
 *
 * Purpose	: find a CRDPRODUCT record in the cache, or in the database
 *
 * Parameters	: key -> pointer to card product
 *
 * Returns	: Pointer to malloc'd structure, or NULL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxpublic CRDPRODUCT_t *lookup_crdproduct (char *key)
{
	int               ret = SUCCEED;
	CRDPRODUCT_t      cp;
	CRDPRODUCT_HASH_t cpk;
	int            i;
	static struct {
		int alloc;
		int used;
		CRDPRODUCT_t *cc;
	} cache;

	DBG_PRINTF((dbg_progdetail, "lookup_crdproduct: looking for <%s>",
				key));
	/*
	 * See if the card product is in the cache
	 */
	for (i = 0; i < cache.used; i++)
	{
		DBG_PRINTF((dbg_progdetail, "Cache [%d]: <%s>",
			i, cache.cc[i].crdproduct));
		if (!strcmp (key, cache.cc[i].crdproduct))
		{
			DBG_PRINTF((dbg_progdetail, "Found <%s> in cache",
						cache.cc[i].crdproduct));
			return cache.cc + i;
		}
	}

	/*
	 * It's not in the cache.  Try the hard way.
	 */
	strscpy (cpk.crdproduct, key);
	if (SUCCEED != CRDPRODUCTgetbyCRDPRODUCT_HASH_cache (&cp, &cpk))
	{
		DBG_PRINTF ((dbg_syserr, "lookup crdproduct"));
		ret = FAIL;
	}
	else
	{
		DBG_PRINTF((dbg_progdetail, "Found <%s> in table", key));
	}

	/*
	 * Now try to store the code in the cache.
	 */
	if (ret == SUCCEED && cache.used >= cache.alloc)
	{
		int n = cache.alloc ? (cache.alloc << 1) : 4;
		CRDPRODUCT_t *ccp;

		ccp = (CRDPRODUCT_t *)realloc (cache.cc,
						n*sizeof (CRDPRODUCT_t));
		if (ccp == NULL)
		{
			ret = FAIL;
			DBG_PRINTF ((dbg_syserr,
				"lookup_crdproduct: failed to get %d elements",
				n));
		}
		else
		{
			cache.cc    = ccp;
			cache.alloc = n;
			DBG_PRINTF((dbg_progdetail, "Allocated %d cache", n));
		}
	}

	if (ret == SUCCEED && cache.used < cache.alloc)
	{
		memcpy (&cache.cc[cache.used], &cp, sizeof (CRDPRODUCT_t));
		cache.used++;
		DBG_PRINTF((dbg_progdetail, "Used %d cache", cache.used));
	}

	return (ret == SUCCEED) ? (cache.cc + cache.used - 1) : NULL;
}

/*--------------------------------------------------------------------------
 *
 * Function	: lookup_crdformat
 *
 * Purpose	: find a CRDFORMAT record in the cache, or in the database
 *
 * Parameters	: key -> pointer to card format
 *
 * Returns	: Pointer to malloc'd structure, or NULL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxpublic CRDFORMAT_t *lookup_crdformat (char *key)
{
	int              ret = SUCCEED;
	CRDFORMAT_t      cp;
	CRDFORMAT_HASH_t cpk;
	int              i;
	static struct {
		int alloc;
		int used;
		CRDFORMAT_t *cc;
	} cache;

	DBG_PRINTF((dbg_progdetail, "lookup_crdformat: looking for <%s>",
				key));
	/*
	 * See if the card format is in the cache
	 */
	for (i = 0; i < cache.used; i++)
	{
		DBG_PRINTF((dbg_progdetail, "Cache [%d]: <%s>",
			i, cache.cc[i].iid));
		if (!strcmp (key, cache.cc[i].iid))
		{
			DBG_PRINTF((dbg_progdetail, "Found <%s> in cache",
						cache.cc[i].iid));
			return cache.cc + i;
		}
	}

	/*
	 * It's not in the cache.  Try the hard way.
	 */
	strscpy (cpk.iid, key);
	if (SUCCEED != CRDFORMATgetbyCRDFORMAT_HASH_cache (&cp, &cpk))
	{
		DBG_PRINTF ((dbg_syserr, "lookup crdformat"));
		ret = FAIL;
	}
	else
	{
		DBG_PRINTF((dbg_progdetail, "Found <%s> in table", key));
	}

	/*
	 * Now try to store the code in the cache.
	 */
	if (ret == SUCCEED && cache.used >= cache.alloc)
	{
		int n = cache.alloc ? (cache.alloc << 1) : 4;
		CRDFORMAT_t *ccp;

		ccp = (CRDFORMAT_t *)realloc (cache.cc,
						n*sizeof (CRDFORMAT_t));
		if (ccp == NULL)
		{
			ret = FAIL;
			DBG_PRINTF ((dbg_syserr,
				"lookup_crdformat: failed to get %d elements",
				n));
		}
		else
		{
			cache.cc    = ccp;
			cache.alloc = n;
			DBG_PRINTF((dbg_progdetail, "Allocated %d cache", n));
		}
	}

	if (ret == SUCCEED && cache.used < cache.alloc)
	{
		memcpy (&cache.cc[cache.used], &cp, sizeof (CRDFORMAT_t));
		cache.used++;
		DBG_PRINTF((dbg_progdetail, "Used %d cache", cache.used));
	}

	return (ret == SUCCEED) ? (cache.cc + cache.used - 1) : NULL;
}
