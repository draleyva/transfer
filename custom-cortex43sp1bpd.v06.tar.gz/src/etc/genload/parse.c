/*-----------------------------------------------------------------------
 *
 * File		: parse.ec
 *
 * Author	: Graeme Thomas
 *
 * Created	: 1998-11-04
 *
 * Purpose	:
 *
 * Comments	:
 *
 * Ident	: $Id$
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include "constant.h"
#include <coencpan.h>
#include <cdbcatissid.h>
#include <dbcatissfeerh.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
					/* NMR010987 WLi 01/3/2004      */
#define DEFAULT_PRFLANG		"GB"	/* default preferred language	*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/* This is the structure defined in the input file. The names have been	*/
/* changed (from the spec) to match the CRDDET fields.			*/
typedef struct {
	char	rechead[8];		/*   0	*/
	char	instcode[4];		/*   8	*/
	char	brncode[8];		/*  12	*/
	char	crdproduct[4];		/*  20	*/
	char	pan[19];		/*  24	*/
	char	seqno[1];		/*  43	*/
	char	additionalno[1];	/*  44	*/
	char	effdate[8];		/*  45	*/
	char	expdate[8];		/*  53	*/
	char	cyclen[2];		/*  61	*/
	char	currcode[3];		/*  63	*/
	char	amtauth[12];		/*  66	*/
	char	offlim[12];		/*  78	*/
	char	statcode[2];		/*  90	*/
	char	embossname[32];		/*  92	*/
	char	usrdata[30];		/* 124	*/
	char	kinship[10];		/* 154	*/
	char	accno[28];		/* 164	*/
	char	custcode[12];		/* 192	*/
	char	old_pan[19];		/* 204	*/
	char	old_seqno[1];		/* 223	*/
	char	priority[1];		/* 224	*/
	char	firstname[20];		/* 225	*/
	char	lastname[20];		/* 245	*/
	char	title[4];		/* 265	*/
	char	cycbegin[8];		/* 269	*/
	char	corp[1];		/* 277	*/
	char	corppan[19];		/* 278	*/
	char	corpseq[1];		/* 297	*/
	char	corpcust[8];		/* 298	*/
	char	debaccno[28];		/* 306	*/
        char 	acctypelim[2];		/* 334	*/
        char  	chgcycle[3];		/* 336	*/
        char  	totlim_amt[12];		/* 339	*/
        char  	cashlim_amt[12];	/* 351	*/
        char  	purchlim_amt[12];	/* 363	*/
        char  	totlim_num[4];		/* 375	*/
        char  	cashlim_num[4];		/* 379	*/
        char  	purchlim_num[4];	/* 383	*/
	char	delvaddr[1];		/* 387	*/	/* TR 5557 */
	char	svccode[3];		/* 388	*/	/* SK NMR013955 */
	char	cat_issfee_value[12];	/* 391	*/	/* sdods HYPO_DEV-28 */
	char	cat_isscycfee_value[12];/* 403	*/	/* sdods HYPO_DEV-28 */
	char	cat_isscomm_value[12];	/* 415	*/	/* sdods HYPO_DEV-28 */
	char	cat_issrisk_value[12];	/* 427	*/	/* sdods HYPO_DEV-28 */
	char	design_ref[12];		/* 442 */
} crdrec_t;				/* 451 total length */

/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
static char rcsid[] = "$Id$";

/* AS 4558: default chgcycle. If it's in ctxcfg, use that: set_dftchgcyc() */
ctxprivate char M_chgcycle[4]="001";
/* AS 4558: default chgcycle. If it's in ctxcfg, use that: set_dftacctl() */
ctxprivate char M_acctypelim[3]="01";
/*---------------------------Prototypes---------------------------------*/
ctxprivate int   parse_set (char_array_t *set, char_array_t *cap);
ctxprivate int   decode_file_hdr (char *buf);
ctxprivate char *reason_str (int reason);
ctxprivate long  calc_next_stmtdate (int cycle);
ctxprivate int   create_expdate( long effdate_num, long *p_expdate_num, int validity );
ctxprivate int verify_number(char *str);
ctxprivate int verify_telnumber(char *str);
ctxprivate int verify_email(char *str);

/*---------------------------Globals--------------------------------------*/
/*---------------------------Functions-----------------------------------*/

/*------------------------------------------------------------------------
 *
 * Function     : parse_hdr
 *
 * Purpose      : read record header
 *
 * Parameters   : buf -> buffer containing data read from file
 *
 * Returns      : malloc'd header
 *
 * Comments     :
 *
 *----------------------------------------------------------------------*/
ctxpublic Hdr *parse_hdr(char *buf)
{
	Hdr *hp = malloc (sizeof (Hdr));
	int  i;

	if (hp != NULL)
	{
		for (i = 0; i < HDR_LEN; i++)
		{
			if (!isdigit ((unsigned char)buf[i]))
				break;
		}

		if (i == HDR_LEN)
		{
			sscanf(buf  , "%02d", &hp->act);
			sscanf(buf+2, "%02d", &hp->seq);
			sscanf(buf+4, "%02d", &hp->type);
			sscanf(buf+6, "%02d", &hp->ver);
		}
		else
		{
			free (hp);
			hp = NULL;
		}
	}

	return hp;
}

/*------------------------------------------------------------------------
 *
 * Function     : loop_parse
 *
 * Purpose      : parses the file to perform a preliminary check
 *		  before processing the records it contains.
 *
 * Parameters   : rcp -> pointer to record count
 *		  fp  -> File pointer
 *
 * Returns      : SUCCEED/FAIL
 *
 * Comments     :
 *
 *----------------------------------------------------------------------*/
ctxpublic int loop_parse (long *rcp, FILE *fp)
{
	char buf[BUFSIZ];	/* Input buffer */
   	int  nrec;		/* Number of records allegedly in file */
	int  ret = SUCCEED;	/* Return value */
	Hdr *hp;		/* Header of record */
	char_array_t *cap;	/* List of failing records */
	int  last_act;		/* Last action code read */
	int  reason;		/* The reason for parse failure */
        int  parse_flag;        /* Used to indicate parse failure */

	/*
	 * Initialize memory for buffers
	 */
	memset(buf, NULL, sizeof(buf));
	memset(G_bak, NULL, sizeof(G_bak));
	cap = char_array_init (0);

	DBG_PRINTF((dbg_progdetail,"\n\n************************************"
				"*\n\n"));
	DBG_PRINTF((dbg_progdetail, "PARSE FILE"));
        
        parse_flag = SUCCEED;

	/*
	 * Read a record from the file
	 */
  	while ((read_line (buf, sizeof (buf), fp, rcp)) != NULL)
   	{
		/* NMR013959 - Initialise the error message */
		strcpy(G_errmsg, ERROR_TAG);
		hp = parse_hdr (buf);
		if (hp)
		{
			last_act = hp->act;
			if (isSet (hp->act))
			{
				char_array_t *set;

				set = char_array_init (4);

				if (read_set (buf, set, rcp, fp) != SUCCEED ||
				    parse_set (set, cap) != SUCCEED)
				{
					ret = FAIL;
DBG_PRINTF((dbg_progdetail, "read_set or parse_set failed"));
				}

				char_array_free (set);
			}
			else
			{
				if (verify_record (buf, &reason, &parse_flag, *rcp) != SUCCEED)
				{
DBG_PRINTF((dbg_proginfo, "verify record failed"));
					ret = FAIL;
					sprintf(ERROR_VAR, " Reason [%d][%s]:", reason, reason_str(reason));
					char_array_add(cap, 0, G_errmsg);
					char_array_add (cap, *rcp, buf);
					err_msg (*rcp, "check failure", G_bak, 0);
					DBG_PRINTF((dbg_syserr,
						"Reason code <%d> (%s)\n",
						reason, reason_str (reason)
						));
				}
			}

			if ((ret == SUCCEED) && hp && (hp->act == ACT_HDR))
			{
				decode_file_hdr (buf);
			}

			free ((char *)hp);
		}
	}

	if (last_act == ACT_TRL)
	{
		sscanf (G_bak + 28, "%08d", &nrec);

		/*
		 * We have parsed the file and the record count in the
		 * trailer record does not match the actual record count
		 */
		if (nrec != (*rcp - 2))
		{
			err_msg (*rcp, "record count", G_bak, 0);
		        ret = FAIL;
		}
	}
	else
	{
		DBG_PRINTF((dbg_syserr,"Last record of input file not a trailer record"));
		ret = FAIL;
	}

	/*
	 * Print out the erroneous records.
	 */
	create_error_file (cap);
	char_array_free (cap);
	cap = NULL;

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  read_set
 *
 * Purpose	:  read a set of records from the file
 *
 * Parameters	:  buf -> input buffer
 *		   set -> record set
 *		   rcp -> record count pointer
 *
 * Returns	:  SUCCEED/FAIL
 *
 * Comments	:  On success, the character array "set" is filled with
 *		   the set.
 *
 *----------------------------------------------------------------------*/
ctxpublic int read_set (char *buf, char_array_t *set, long *rcp, FILE *fp)
{
	fpos_t pos;		/* File position */
	Hdr   *hp;		/* Record header */
	int    ret = SUCCEED;	/* Return code */

	/*
	 * This loop breaks various coding guidelines, in that it stops
	 * in several places.  Sticking to the guidelines would, in this
	 * case, add complxity.  In general, the loop stops whenever we
	 * detect that the set has ended.  This occurs:
	 *
	 *	When we run out of memory to store the lines
	 *	When the file ends
	 *	When we read a bad record
	 *	When we read a record with sequence number zero
	 *
	 * That last reason is the normal loop exit.
	 */
	while (ret == SUCCEED)
	{
		/*
		 * Store the buffer.  We know that it's part of the
		 * set.
		 */
		if (char_array_add (set, *rcp, buf) != SUCCEED)
		{
			/*
			 * Memory failure
			 */
			ret = FAIL;
			break;
		}

		/*
		 * Note where we are in the file.  When we find the end of
		 * the current set, we'll reposition the file pointer to
		 * this position.
		 */
		fgetpos (fp, &pos);

		if (read_line (buf, BUFSIZ, fp, rcp) == NULL)
		{
			/*
			 * We shouldn't hit EOF in this loop, as there
			 * should be a file trailer record, at least.
			 */
			ret = FAIL;
			break;
		}

		hp = parse_hdr (buf);
		if (hp)
		{
			if (hp->seq == 0)
			{
				/*
				 * This is the normal exit from the loop
				 */
				break;
			}

			if (!isSet (hp->act))
			{
				/*
				 * The current record isn't part of the
				 * set, and yet it has a non-zero sequence
				 * number.  We'll stop the loop, and let
				 * the parser complain about it next time.
				 */
				ret = FAIL;
				break;
			}

			free ((char *)hp);
			hp = NULL;
		}
		else
		{
			/*
			 * We've read a bad record, so stop here as well
			 */
			ret = FAIL;
			break;
		}
	}

	free ((char *)hp);
	hp = NULL;
	fsetpos (fp, &pos);
	(*rcp)--;		/* Reset line counter */

DBG_PRINTF((dbg_progdetail, "read_set => %s", ret==SUCCEED?"SUCCEED":"FAIL"));
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  parse_set
 *
 * Purpose	:  Check a set of records for validity
 *
 * Parameters	:  set -> the record set
 *		   cap -> the failing records
 *
 * Returns	:  SUCCEED/FAIL
 *
 * Comments	:  On failure, the failing records are added to the list
 *
 *----------------------------------------------------------------------*/
ctxprivate int parse_set (char_array_t *set, char_array_t *cap)
{
	int   ret;
	long  data;
	long  rec_cnt = 0;
	char *buf;
	int   i;
	Hdr  *hp      = NULL;
	int   reason  = 0;
	ctxbool  oksofar = TRUE;
	int   maxtype = 0;
	int   act     = 0;
        int   parse_flag = SUCCEED;

	for (i = 0, ret = char_array_first (set, &data, &buf);
	     (ret == SUCCEED) && oksofar;
	     i++,   ret = char_array_next (set, &data, &buf))
	{
		if (verify_record (buf, &reason, &parse_flag, rec_cnt) == FAIL)
		{
			oksofar = FALSE;
		}
		else
		{
			hp = parse_hdr (buf);

			/*
			 * Record the action code for the set
			 */
			if ((hp != NULL) && (i == 0))
			{
				act = hp->act;
			}

			/*
			 * In order for a record in a set to be valid, it
			 * must have sequence numbers in order, and the
			 * type codes must be increasing.  All action codes
			 * must be the same.
			 */
			if ((hp == NULL) ||
			    (hp->seq != i) ||
			    (hp->type < maxtype) ||
			    (hp->type > maxtype + 1) ||
			    (hp->act != act)
			   )
			{
				oksofar = FALSE;
				reason = RDE_INVALID_SET;

                                if (parse_flag == SUCCEED)
                                 {
                                   sprintf(ERROR_VAR, " ---------- FILE NOT PROCESSED ---------");
                                   sprintf(ERROR_VAR, " FILE PARSING FAILED\n%s", ERROR_TAG);
                                   parse_flag = FAIL;
                                 }

                                sprintf(ERROR_VAR, " Invalid Record Set : Check that Sequence");
                                sprintf(ERROR_VAR, " Numbers are in order, Type codes are increasing");
                                sprintf(ERROR_VAR, " and all Action codes are the same: ");

			}
			else
			{
				maxtype = hp->type;
				/* Gap for address records */
				if (maxtype == 03)
				{
					maxtype = TYPE_POSTALADDR-1;
				}
			}
			free ((char *)hp);
		}
	}

	/*
	 * If we get here, and oksofar is TRUE, then we must perform one more
	 * check.  Otherwise, on error we add the set to the error set.
	 */
	/*
	 * Allow address types to differ from isSet(act)
	 */
	if (oksofar && maxtype != isSet (act) && maxtype < TYPE_POSTALADDR)
	{
		reason = RDE_INVALID_SET;
		oksofar = FALSE;
	}

	if (!oksofar)
	{
		sprintf(ERROR_VAR, " Reason [%d][%s]:", reason, reason_str(reason));
		char_array_add(cap, 0, G_errmsg);
		for (ret = char_array_first (set, &data, &buf), rec_cnt = data;
		     ret == SUCCEED;
		     ret = char_array_next (set, &data, &buf))
		{
			char_array_add (cap, data, buf);
		}
		err_msg (rec_cnt, "check set failure", "", 0);
		DBG_PRINTF((dbg_syserr,
			"Reason code <%d> (%s)\n",
			reason, reason_str (reason)
			));
	}

DBG_PRINTF((dbg_progdetail, "parse_set => %s", oksofar?"SUCCEED":"FAIL"));
	return oksofar ? SUCCEED : FAIL;
}

/*------------------------------------------------------------------------
 *
 * Function	:  decode_file_hdr
 *
 * Purpose	:  Extract the file number and processing date
 *
 * Parameters	:  buf -> the input line
 *
 * Returns	:  SUCCEED/FAIL
 *
 * Comments	:  On SUCCEED, sets the globals G_infilenum and G_inprdate
 *
 *----------------------------------------------------------------------*/
ctxprivate int decode_file_hdr (char *buf)
{
	int ret = SUCCEED;
	char filename[21];

DBG_PRINTF((dbg_progdetail, "Decoding file header <%s>", buf));
	if (sscanf (buf, "00000001%20c%8c%8c",
				filename, G_infilenum, G_inprdate) != 3)
	{
		ret = FAIL;
	}
DBG_PRINTF((dbg_progdetail, "Decoding file header %s", (ret==SUCCEED) ? "succeeded":"failed"));

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  reason_str
 *
 * Purpose	:  Give understandable reason codes
 *
 * Parameters	:  reason -> reason code
 *
 * Returns	:  Pointer to static string
 *
 * Comments	:  Should this be internationalized?
 *
 *----------------------------------------------------------------------*/
ctxprivate char *reason_str (int reason)
{
	char *ret;

	switch (reason)
	{
		case RDE_INVALID_LENGTH:
			ret = "Invalid length";
			break;

		case RDE_INVALID_CHAR:
			ret = "Invalid character";
			break;

		case RDE_INVALID_HEADER:
			ret = "Invalid record header";
			break;

		case RDE_INVALID_VERSION:
			ret = "Invalid record version";
			break;

		case RDE_INVALID_ACTION:
			ret = "Invalid action code";
			break;

		case RDE_EMPTY_FIELD:
			ret = "Mandatory field is empty";
			break;

		case RDE_INVALID_SET:
			ret = "Corrupted record set";
			break;

		case RDE_LEADING_BLANK:
			ret = "Leading blank in field";
			break;

		default:
			ret = "Unknown reason";
			break;
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : parse_acc
 *
 * Purpose      : Fill in an account details record from the input
 *		  version of it.
 *
 * Parameters   : buf -> input record
 *		  p_accdet -> account details
 *		  p_accdet_k -> account key fields
 *
 * Returns      : SUCCEED
 *
 * Comments     : The following fields are not taken from the input
 *		  record.  They are set to zero.
 *
 *			blkamt
 *			avlbal
 *			clrbal
 *			unclrbal
 *
 *----------------------------------------------------------------------*/
ctxpublic int parse_acc (char *buf, ACCDET_t *p_accdet, ACCDET_HASH_t *p_accdet_k,
			char *ccsinfo, INST_t *p_inst, BRANCH_t *p_branch, CUSTDET_t *p_cust)
{
	int ret = SUCCEED;
	char tmp[14];
	Hdr *hp = parse_hdr (buf);
	INST_HASH_t inst_k;
	BRANCH_HASH_t branch_k;
	CUSTDET_HASH_t custdet_k;

	/*
	 * Initialise memory for our accdet record to be copied into
    	 */
	memset((char *)&inst_k, 0, sizeof(INST_HASH_t));
	memset((char *)&branch_k, 0, sizeof(BRANCH_HASH_t));
	memset((char *)&custdet_k, 0, sizeof(CUSTDET_HASH_t));
	memset ((char *)p_accdet,   0, sizeof (ACCDET_t));
	memset ((char *)p_accdet_k, 0, sizeof (ACCDET_HASH_t));
	memset (tmp, 0, sizeof (tmp));

	/*
	 * Copy the record data from the buffer to our accdet record
 	 */
	memcpy (inst_k.instcode, buf +  8,  4);
	memcpy (branch_k.brncode,  buf + 12,  8);
	memcpy (p_accdet->accno,    buf + 20, 28);
	memcpy (p_accdet->currcode, buf + 48,  3);
	memcpy (p_accdet->typecode, buf + 51,  2);
	memcpy (p_accdet->statcode, buf + 53,  2);
	memcpy (custdet_k.custcode, buf + 55, 12);
	memcpy (tmp,                buf + 67, 12);
		p_accdet->credit_limit = atof (tmp);

	stp_right (inst_k.instcode);
	stp_right (p_accdet->accno);
	stp_right (p_accdet->currcode);
	stp_right (branch_k.brncode);
	stp_right (p_accdet->typecode);
	stp_right (p_accdet->statcode);
	stp_right (custdet_k.custcode);
	
	if ((SUCCEED == ret) &&
		(SUCCEED == INSTgetbyINST_HASH_cache (p_inst, &inst_k)))
	{
			p_accdet->inst_id = p_inst->id;
			branch_k.inst_id = p_inst->id;
			custdet_k.inst_id = p_inst->id;
	}
	
	if ((SUCCEED == ret) &&
            (SUCCEED == BRANCHgetbyBRANCH_HASH_cache (p_branch,
                                                        &branch_k)))
    {
		p_accdet->branch_id = p_branch->id;
    }

	if ((SUCCEED == ret) &&
		(SUCCEED == CUSTDETgetbyCUSTDET_HASH (p_cust, &custdet_k)))
	{
		p_accdet->custdet_id = p_cust->id;
	}

	ccsinfo[0]=EOS;

	if (hp->ver > 1)
	{
		memcpy (p_accdet->vipflag,  buf + 79,  1);
		if (p_accdet->vipflag[0] == ' ')
		{
			strscpy (p_accdet->vipflag, "0");
		}

		memcpy (tmp,                buf + 80,  1);
			tmp[1] = 0;
			p_accdet->classid = atoi (tmp);
	        if (hp->ver>2)  /* CCS, NMR009113 WLi 07/3/2003 */
        	{
                      	memcpy(ccsinfo, buf+81, 56);
                      	ccsinfo[56]=EOS;
                       	stp_right(ccsinfo);
                }

	}
	else
	{
		p_accdet->classid = CLASSID;
	}

	DBG_PRINTF((dbg_progdetail,"inst_id: <%ld>", p_accdet->inst_id));
	DBG_PRINTF((dbg_progdetail,"accno:    <%s>", p_accdet->accno));
	DBG_PRINTF((dbg_progdetail,"currcode: <%s>", p_accdet->currcode));
	DBG_PRINTF((dbg_progdetail,"custdet_id: <%ld>", p_accdet->custdet_id));
	DBG_PRINTF((dbg_progdetail,"branch_id:  <%ld>", p_accdet->branch_id));
	DBG_PRINTF((dbg_progdetail,"typecode: <%s>", p_accdet->typecode));
	DBG_PRINTF((dbg_progdetail,"classid:  <%hd>",p_accdet->classid));
	DBG_PRINTF((dbg_progdetail,"statcode: <%s>", p_accdet->statcode));
	DBG_PRINTF((dbg_progdetail,"vipflag:  <%s>", p_accdet->vipflag));
	DBG_PRINTF((dbg_progdetail,"cred_lim: <%f>", p_accdet->credit_limit));
	DBG_PRINTF((dbg_progdetail,"ccsinfo:  <%s>", ccsinfo));

 	p_accdet_k->inst_id = p_accdet->inst_id;
	strscpy (p_accdet_k->accno,    p_accdet->accno);
	strscpy (p_accdet_k->currcode, p_accdet->currcode);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : parse_crddet
 *
 * Purpose      : Fill in an card details record from the input
 *		  version of it.
 *
 * Parameters   : buf -> input record
 *		  p_crddet -> card details
 *		  p_crddet_k -> card key fields
 *		  pan_clr -> clear version of new pan (returned)
 *		  old_pan -> old pan
 *		  old_seqno -> old sequence number
 *		  priority  -> card priority
 *		  delvaddr -> delivery address
 *		  rec_cnt -> record number
 * 		  chargecard_data -> charge card fields
 *
 * Returns      : SUCCEED
 *
 * Comments     :  The old_pan, old_seqno, and priority fields are there
 *		   because they are not in the database card record.
 *
 *----------------------------------------------------------------------*/
ctxpublic int parse_crddet (char          *buf,
		  CRDDET_t      *p_crddet,
		  CRDDET_HASH_t *p_crddet_k,
		  char		*pan_clr,
		  char          *old_pan,
		  int           *old_seqno,
		  char          *priority,
		  char		*delvaddr,	/* TR 5557 */
		  long           rec_cnt,
		  charge_crd_flds *chargecard_data,
		  non_crddet_flds_t *p_non_crddet_flds,
		  ACCDET_t	*p_acc,
		  CRDPRODUCT_t	*p_crdp,
		  CRDFORMAT_t	*p_crdfrmt,
		  INST_t	*p_inst,
		  CRDPINMIGR_t	*p_crdpinmigr)
{
	int ret = SUCCEED;
	char tmp[14];
	CUSTDET_t cust_tmp;
	CUSTDET_HASH_t cust_k;
	CRDFORMAT_PK_t  crdfrmt_k;
	INST_HASH_t inst_k;
	BRANCH_HASH_t branch_k;
	BRANCH_t branch_tmp;	
	CRDPRODUCT_HASH_t crdprod_k;
	CRDPRODUCT_t crdprod_tmp;
	ACCDET_HASH_t accdet_k;
	Hdr *hp;
	char temp_str[33] = { 0 };
	char* str1 = NULL;
	char* str2 = NULL;
	char name1[33];
	char name2[33];
	char cat_issfee_value[CAT_ISSFEE_CATVALUE_BUFFSIZE];
	char cat_isscycfee_value[CAT_ISSFEE_CATVALUE_BUFFSIZE];
	char cat_isscomm_value[CAT_ISSFEE_CATVALUE_BUFFSIZE];
	char cat_issrisk_value[CAT_ISSFEE_CATVALUE_BUFFSIZE];
	crdrec_t	*p_crdrec = (crdrec_t*)buf;
	char	*pan_enc = NULL;
	
	long	rsplen=0L;
	FBFR	*p_lfb=NULL;
	char	rule_retdata[RULE_EVALSET_RET_DATA0_BUFFSIZE] = {0};

	hp = parse_hdr (buf);

	memset ((char *)p_acc,   0, sizeof (ACCDET_t));
	memset ((char *)p_crddet,   0, sizeof (CRDDET_t));
	memset ((char *)p_crddet_k, 0, sizeof (CRDDET_HASH_t));
	memset (old_pan,            0, 20);
	memset (tmp,                0, sizeof (tmp));
	memset ((char *)chargecard_data,   0, sizeof (charge_crd_flds));
	memset ((char *)&inst_k, 0, sizeof (INST_HASH_t));
	memset ((char *)&branch_tmp,   0, sizeof (BRANCH_t));
	memset ((char *)&branch_k, 0, sizeof (BRANCH_HASH_t));
	memset ((char *)&crdprod_k, 0, sizeof (CRDPRODUCT_HASH_t));
	memset ((char *)&crdfrmt_k, 0, sizeof (CRDFORMAT_PK_t));
	memset ((char *)&accdet_k, 0, sizeof (ACCDET_HASH_t));
	memset ((char *)&cust_tmp,   0, sizeof (CUSTDET_t));
	memset ((char *)&cust_k, 0, sizeof (CUSTDET_HASH_t));
	memset ((char *)p_crdp, 0, sizeof (CRDPRODUCT_t));
	memset ((char *)p_crdfrmt, 0, sizeof (CRDFORMAT_t));
	memset ((char *)p_inst, 0, sizeof (INST_t));

#define CRDRECSZ(x) sizeof(p_crdrec->x)
	/* HYPOM-1140 ZG 08.02.2007. Remove trailing spaces */
#define CRDCPY(x) do { memcpy(p_crddet->x, p_crdrec->x, sizeof(p_crdrec->x)); \
			stp_right(p_crddet->x); } while(0)
#define TMPCPY(x) do{memcpy(tmp, p_crdrec->x, sizeof(p_crdrec->x)); tmp[sizeof(p_crdrec->x)] = EOS;}while(0)
	/* HYPOM-1140 ZG 08.02.2007. Remove trailing spaces */
#define CCRDCPY(x) do { memcpy(chargecard_data->x, p_crdrec->x, sizeof(chargecard_data->x)-1); \
			stp_right(chargecard_data->x); } while(0)

	memcpy(inst_k.instcode, p_crdrec->instcode, sizeof(p_crdrec->instcode));
	memcpy(branch_k.brncode, p_crdrec->brncode, sizeof(p_crdrec->brncode));
	memcpy(crdprod_k.crdproduct, p_crdrec->crdproduct, sizeof(p_crdrec->crdproduct));
	CRDCPY(pan);

	/* keep copy of clear PAN */
	strcpy(pan_clr, p_crddet->pan);

	/* sdods PCI DSS, 07/01/2009, encrypt PAN */
	if(NULL == (pan_enc = encryptPan( p_crddet->pan, NULL )))
		return (FAIL);

	memcpy(p_crddet->pan, pan_enc, sizeof(p_crddet->pan));

	TMPCPY(seqno);
		p_crddet->seqno = atoi (tmp);
	TMPCPY(additionalno);
		p_crddet->additionalno = atoi (tmp);

	/* if effdate is blank use unix date */
	if(strlen((char*)p_crdrec)>OFFSET(crdrec_t,effdate)
			&& p_crdrec->effdate[0] != ' ')
	{
		TMPCPY(effdate);
		p_crddet->effdate = atol (tmp);
	}
	/* MC - 20/12/00 - Bug 4745 - Do not use default for amendments */
	else if( hp->act != 2 )
	{
		p_crddet->effdate = local_date();
	}

	TMPCPY(expdate);
		p_crddet->expdate = atol (tmp);

	TMPCPY(cyclen);
		p_crddet->cyclen = atoi (tmp);
	if (hp->ver > 1
		&& strlen((char*)p_crdrec)>OFFSET(crdrec_t,cycbegin)
			&& p_crdrec->cycbegin[0] != ' '
				&& strncmp(p_crdrec->cycbegin, "00000000", 8))
	{
		TMPCPY(cycbegin);
		p_crddet->cycbegin = atoi (tmp);
	}
	/* MC - 20/12/00 - Bug 4745 - Do not use default for amendments */
	else if( hp->act != 2 )
	{
		p_crddet->cycbegin = local_date();
	}
	memcpy(accdet_k.currcode, p_crdrec->currcode, sizeof(p_crdrec->currcode));
	TMPCPY(amtauth);
		p_crddet->amtauth = atof (tmp);
		p_crddet->amtrem  = p_crddet->amtauth;
	TMPCPY(offlim);
		p_crddet->offlim = atof (tmp);
	CRDCPY(statcode);
	/* CN NMR010778 24/2/04 Business Debit
	 * was also copying start of usrdata,
	 * changed to use sizeof (p_crdrec) rather than sizeof (p_crddet)
	 */
	memcpy(	p_crddet->embossname,
		p_crdrec->embossname, CRDRECSZ(embossname));
	stp_right(p_crddet->embossname); /* HYPOM-1140 */

	/*
	 * MG BPD_MAINT-21 userdata is now used
	 * by PIN migration and corporate cards
	 * the processing of both need to be done
	 * in the same place to prent possible issues.
	 */
	/*CRDCPY(usrdata);*/

	CRDCPY(kinship);
	memcpy(accdet_k.accno, p_crdrec->accno, sizeof(p_crdrec->accno));
	memcpy(cust_k.custcode, p_crdrec->custcode, sizeof(p_crdrec->custcode));
	memcpy(old_pan, p_crdrec->old_pan, CRDRECSZ(old_pan));
	stp_right(old_pan); /* HYPOM-1140 */
	TMPCPY(old_seqno);
		*old_seqno = atoi (tmp);
	memcpy (priority,             p_crdrec->priority, CRDRECSZ(priority));
	/* TH 15/5/99 Default priority to '0' */
	if (EOS == priority[0] || ' ' == priority[0])
		priority[0] = '0';

	/* TR 4481 - If priority != 0 or 1 then set to default (0) */
	/*NMR020453 MV, 2007.02.08, added priority 2*/
	if (!strchr("012", priority[0]))
	{
		priority[0] = '0';
	}

	/* TR 5557 Added support for CRDBTCH.delvaddr */
	if (hp->ver > 4)
	{
		memcpy (delvaddr, p_crdrec->delvaddr, CRDRECSZ(delvaddr));
	}
	/* Default delvaddr to 0 */
	if (EOS == delvaddr[0] || ' ' == delvaddr[0])
	{
		delvaddr[0] = '0';
	}

	/********************************************************/
	/* TH 2/7/99 Spec 1.4 was changed to explicitly support	*/
	/* corporate cards in Record V3, and specifically	*/
	/* exclude from previous versions (code in here before	*/
	/* was incorrect). So use corp flag if present, else	*/
	/* default to NORMAL (non-corporate)			*/
	/********************************************************/
	if (hp->ver > 2
		&& strlen((char*)p_crdrec)>OFFSET(crdrec_t,corp)
			&& p_crdrec->corp[0] != ' ')
	{
		p_crddet->corp[0] = p_crdrec->corp[0];
	}
	else
	{
		p_crddet->corp[0] = CARD_CORP_NORMAL;
	}

	stp_right(inst_k.instcode);
	stp_right(branch_k.brncode);
	stp_right(cust_k.custcode);
	stp_right(accdet_k.accno);
	stp_right(accdet_k.currcode);
	stp_right(crdprod_k.crdproduct);

	if ( (SUCCEED == ret) && (SUCCEED != INSTgetbyINST_HASH_cache (p_inst, &inst_k)) )
	{
		DBG_PRINTF((dbg_syserr,"Institution [%s] not found", inst_k.instcode));
		ret = FAIL;
	}
	else
	{
		accdet_k.inst_id = p_inst->id;
		branch_k.inst_id = p_inst->id;
		cust_k.inst_id = p_inst->id;
	}


	if ( (SUCCEED == ret) && (SUCCEED != CUSTDETgetbyCUSTDET_HASH (&cust_tmp, &cust_k)) )
	{				
		p_crddet->date_birth = 0;
		ret = FAIL;
	}
	else	
	{
		p_crddet->date_birth = cust_tmp.date_birth;
		p_crddet->custdet_id = cust_tmp.id;
		p_acc->custdet_id = cust_tmp.id;
	}

	/* if there is a first name and a last name in the card record */
	if (strlen((char*)p_crdrec)>OFFSET(crdrec_t,lastname)
			&& p_crdrec->firstname[0] != ' '
			&& p_crdrec->lastname[0] != ' ')
	{
		/* copy them to the card detail record */
		CRDCPY(firstname);
		CRDCPY(lastname);

		/* if the embossname in the card detail record is blank */
		if (EOS == p_crddet->embossname[0]) /* HYPOM-1140 */
		{
			/* then make it up using the first and last name */
			/* CN NMR010778 15/3/04 Business Debit
			 * restrict length of emboss name to sizeof (p_crdrec)
			 * rather than sizeof (p_crddet)
			 */
			make_embname(p_crddet->embossname, p_crdrec->lastname,
				p_crdrec->firstname,CRDRECSZ(embossname));
		}

	}
	else if (strlen((char*)p_crdrec)>OFFSET(crdrec_t,lastname)
			&& p_crdrec->firstname[0] == ' '
			&& p_crdrec->lastname[0] == ' '
			&& p_crddet->embossname[0] == ' ')
	{
		STRSCPY(p_crddet->firstname, cust_tmp.firstname);
		STRSCPY(p_crddet->lastname, cust_tmp.lastname);

		make_embname(p_crddet->embossname, p_crdrec->lastname,
			p_crdrec->firstname,CRDRECSZ(embossname));
	}
	else
	{
	       /*
		* The real name is not passed in a single record, so the
		* emboss name will have to be dissected if its there !
		* Note: we cannot
		* use the name in the customer record as this will not be
		* the same if this is an additional card
		*/

		if( strlen((char*)p_crdrec)>OFFSET(crdrec_t,embossname)
			&& p_crdrec->embossname[0] != ' ')
		{
			STRSCPY(temp_str,p_crddet->embossname);

			str1 = strtok(temp_str," ");
			if(NULL != str1)
				STRSCPY(name1,str1);

			str2 = strtok(NULL,"\0");
			if(NULL != str2)
			{
				STRSCPY(name2,str2);
				strip_leading(name2,' ');
			}

			if(NULL == str2)
			{
				if(NULL == str1)
				{
					/* no name supplied */
					STRSCPY(p_crddet->firstname, " ");
					STRSCPY(p_crddet->lastname, " ");
				}
				else
				{
					/* only one name supplied */
					STRSCPY(p_crddet->firstname, " ");
					STRSCPY(p_crddet->lastname, name1);
				}
			}
			else
			{
				/* two names supplied */
				STRSCPY(p_crddet->firstname, name1);
				STRSCPY(p_crddet->lastname, name2);
			}
		}
		else
		{
			/*report an error there is no first name, last name
			  or embossname supplied */
			DBG_PRINTF ((dbg_syserr,
		"THERE IS NO FIRST NAME, LAST NAME OR EMBOSSNAME SUPPLIED!"));
		}
	}

	/*
	 * MG BPD_MAINT-21 PIN offset migration.
	 * Do not copy this piece of code to any other stdimp:
	 * 1st - It's crap
	 * 2nd - It's BPD specific
	 */
	if (   (   hp->ver < 3
	        && 0 != strncmp(p_crdrec->usrdata, " ", 1))
	    || (   hp->ver > 2
	        && CARD_CORP_NORMAL == p_crdrec->corp[0]
	        && 0 != strncmp(p_crdrec->usrdata, " ", 1)))
	{
		memcpy(p_crdpinmigr->pan_old, p_crdrec->usrdata, 19);
		stp_right(p_crdpinmigr->pan_old);
		memcpy(p_crdpinmigr->expdate, p_crdrec->usrdata + 19, 4);
		memcpy(p_crdpinmigr->pin_offset, p_crdrec->usrdata + 23, 4);
		/*
		 * If we have PIN offset, we do not wanna this
		 * data to stay in CRDDET.usrdata!
		 */
		STRSCPY(p_crddet->usrdata, " ");
	}
	else
	{
		/* There's no PIN offset in the data. */
		CRDCPY(usrdata);
	}

	if (hp->ver > 1
		&& strlen((char*)p_crdrec)>OFFSET(crdrec_t,title)
			&& p_crdrec->title[0] != ' ')
	{
		CRDCPY(title);
	}
	else
	{
		STRSCPY(p_crddet->title, " ");
	}

	if ( (SUCCEED == ret) && (SUCCEED != BRANCHgetbyBRANCH_HASH_cache (&branch_tmp, &branch_k)) )
	{
		ret = FAIL;
	}	
	else
	{
		p_crddet->branch_id = branch_tmp.id;
	}
		
	/* Get Crdproduct if cat_params is 'S*' in custdet
	 * and card product in input file is 'AUTO'				*/
	if( (SUCCEED == ret) &&	
		!strcmp(crdprod_k.crdproduct, AUTO_CRDPRODUCT) && 
		(cust_tmp.cat_params[0] && cust_tmp.cat_params[0] == 'S'))
	{
		if(NULL==(p_lfb=(FBFR *)ntp_alloc("FML", NULL, 0))
		|| SUCCEED!=CF_chg(p_lfb, I_INST_ID, 0,
						(char *)&cust_tmp.inst_id, 0, FLD_LONG)
		|| SUCCEED!=CF_chg(p_lfb, I_CUSTCATPARAMS, 0,
						(char *)cust_tmp.cat_params, 0, FLD_STRING)
		|| FAIL==ntp_call(CRDPRODMAP, (char *)p_lfb,
						0L, (char **)&p_lfb, &rsplen, 0)
		|| !F_pres(p_lfb, I_RULE_RETDATA, 0)
		|| SUCCEED!=CF_get(p_lfb, I_RULE_RETDATA, 0,
						(char *)rule_retdata, 0, FLD_STRING))
		{
			DBG_PRINTF((dbg_syserr,"Call Service CRDPRODMAP Failed"));
			ret=FAIL;
		}
		else
		{
			strncpy(crdprod_k.crdproduct, 
				rule_retdata, sizeof(crdprod_k.crdproduct));
		}
		ntp_free((char *)p_lfb);
	}
	else if (SUCCEED == ret && 
			!strcmp(crdprod_k.crdproduct, AUTO_CRDPRODUCT))
	{
		DBG_PRINTF((dbg_syserr,"The card product is AUTO, "
					"but the custdet.cat_params [%s] is an incorrect value", 
					cust_tmp.cat_params));
		ret=FAIL;
	}
	
	/*
	 * Verify the crdproduct 
	 */
	if ((SUCCEED == ret) &&
            (SUCCEED != (ret = CRDPRODUCTgetbyCRDPRODUCT_HASH_cache (p_crdp,
                                                        &crdprod_k))))
	{
			DBG_PRINTF((dbg_syserr,"Can't find card product: %s", 
					crdprod_k.crdproduct));
			ret = FAIL;
	}
	
	if (SUCCEED == ret)
	{
		p_crddet->crdproduct_id = p_crdp->id;
		
		crdfrmt_k.id = p_crdp->crdformat_id;
		if (SUCCEED != CRDFORMATgetbyCRDFORMAT_PK_cache (p_crdfrmt,
                                                        &crdfrmt_k))
		{
			DBG_PRINTF ((dbg_syserr, "Can't find card format <%s>",
							crdfrmt_k.id));
		}
		else
		{
			p_crddet->classid = p_crdfrmt->classid;
			STRSCPY (p_crddet->pvki, p_crdfrmt->pvki);

			/* check if the following optional fields are blank
			if they are then take the values from crdformat info */

			DBG_PRINTF ((dbg_progdetail, "cyclen =  <%d>",
							p_crddet->cyclen));
		/* MC - 20/12/00 - Bug 4745 - Do not use default for amendments */
			if( ( p_crddet->cyclen == 0 ) && ( hp->act != 2 ) )
			{
				p_crddet->cyclen = p_crdfrmt->cyclen;
				DBG_PRINTF ((dbg_progdetail, "new cyclen =  <%hd>",
							p_crddet->cyclen));
			}
			DBG_PRINTF ((dbg_progdetail, "amtauth =  <%f>",
							p_crddet->amtauth));
			DBG_PRINTF ((dbg_progdetail, "amtrem =  <%f>",
							p_crddet->amtrem));
		/* MC - 20/12/00 - Bug 4745 - Do not use default for amendments */
			if( ( p_crddet->amtauth == 0 ) && ( hp->act != 2 ) )
			{
				p_crddet->amtauth = p_crdfrmt->cycauth;
				p_crddet->amtrem  = p_crddet->amtauth;
				DBG_PRINTF ((dbg_progdetail, "new amtrem =  <%f>",
							p_crddet->amtrem));
				DBG_PRINTF ((dbg_progdetail, "new amtauth =  <%f>",
							p_crddet->amtauth));
			}
			DBG_PRINTF ((dbg_progdetail, "offlim =  <%f>",
							p_crddet->offlim));
		/* MC - 20/12/00 - Bug 4745 - Do not use default for amendments */
			if( ( p_crddet->offlim == 0 ) && ( hp->act != 2 ) )
			{
				p_crddet->offlim = p_crdfrmt->offauth;
				DBG_PRINTF ((dbg_progdetail, "new offlim =  <%f>",
							p_crddet->offlim));
			}
			DBG_PRINTF ((dbg_progdetail, "statcode =  <%s>",
							p_crddet->statcode));
		/* MC - 20/12/00 - Bug 4745 - Do not use default for amendments */
			if( (EOS == p_crddet->statcode[0]) && ( hp->act != 2 ) ) /* HYPOM-1140 */
			{
				strcpy(p_crddet->statcode, p_crdfrmt->dfltstatcode);
				DBG_PRINTF ((dbg_progdetail, "new statcode =  <%s>",
							p_crddet->statcode));
			}
		/* MC - 20/12/00 - Bug 4745 - Do not use default for amendments */
			if( (EOS == p_acc->currcode[0]) && ( hp->act != 2 ) ) /* HYPOM-1140 */
			{
				strcpy(p_acc->currcode, p_crdfrmt->currcode);
			}
		/* MC - 20/12/00 - Bug 4745 - Do not use default for amendments */
			if( ( p_crddet->expdate == 0 ) && ( hp->act != 2 ) )
			{
					if( SUCCEED !=
				  create_expdate(p_crddet->effdate, &p_crddet->expdate,p_crdfrmt->validity))
					{
							DBG_PRINTF((dbg_syserr,"Error creating expdate"));
							return( FAIL );
					}
			}
		}
	}

	if ((SUCCEED == ret) &&
            (SUCCEED != ACCDETgetbyACCDET_HASH (p_acc,
                                                        &accdet_k)))
	{
			DBG_PRINTF((dbg_syserr,"accno: %s, currcode : %s", p_acc->accno, p_acc->currcode));
			ret = FAIL;
	}
	if (SUCCEED == ret)
		p_crddet->accdet_id = p_acc->id;
		
        if (hp->ver > 3)
        {
                CCRDCPY(debaccno);
		/* AS 4558: If acctypelim is not set in the record
		   set it to the default */
		if ( ' ' == p_crdrec->acctypelim[0] ) /* empty rec */
		{
			/* TR 6417 We were doing a strcpy into
			 * p_crdrec which means we have a 0 in the middle
			 * which means we only print half of it out in the
			 * error file */
			strscpy(chargecard_data->acctypelim, M_acctypelim);
		}
		else
		{
                	CCRDCPY(acctypelim);
		}
                TMPCPY(chgcycle);
			/* AS 4558: If chgcycle is not set in the record
			   set it to the default
			  if tmp is empty or is spaces then use default PJB
			*/
			if ( EOS == tmp[0] || ' ' == tmp[0] )
			{
				strscpy(tmp, M_chgcycle);
			}
                        chargecard_data->chgcycle = atoi (tmp);
                TMPCPY(totlim_amt);
                        chargecard_data->totlim_amt = atof (tmp);
                TMPCPY(cashlim_amt);
                        chargecard_data->cashlim_amt = atof (tmp);
                TMPCPY(purchlim_amt);
                        chargecard_data->purchlim_amt = atof (tmp);
                TMPCPY(totlim_num);
                        chargecard_data->totlim_num = atoi (tmp);
                TMPCPY(cashlim_num);
                        chargecard_data->cashlim_num = atoi (tmp);
                TMPCPY(purchlim_num);
                        chargecard_data->purchlim_num = atoi (tmp);
        }

        /* SK NMR013955 Copy Service Code to card record */
        if (hp->ver > 5)
        {
                strscpy(p_crddet->svccode,p_crdrec->svccode);
		stp_right(p_crddet->svccode);
        }
	else
		p_crddet->svccode[0] = 0;

	/* set defaults for card category ID's */
	p_crddet->cat_isscomm_id = p_crddet->cat_issrisk_id =
		p_non_crddet_flds->cat_issfee_id =
		p_non_crddet_flds->cat_isscycfee_id = 1;

	/* sdods HYPO_DEV-28 Copy category values and convert to IDs */
	if( hp->ver > 6 )
	{
/* copy from input record into local variable and strip spaces */
#define copycat(c) do {strscpy(c, p_crdrec->c); stp_right(c);} while(0);

		copycat(cat_issfee_value);
		copycat(cat_isscycfee_value);
		copycat(cat_isscomm_value);
		copycat(cat_issrisk_value);

/* lookup category value if not empty and store in given c structure
 * return SUCCEED if value is empty string */
#define lookupcat(V, v, iid, cs)  (*cat_iss##v##_value \
		? CAT_ISS##V##getid(&cs->cat_iss##v##_id, iid, cat_iss##v##_value) \
			: SUCCEED)

		if( SUCCEED != lookupcat(FEE, fee, p_inst->id,  p_non_crddet_flds)
		 || SUCCEED != lookupcat(CYCFEE, cycfee, p_inst->id, p_non_crddet_flds)
		 || SUCCEED != lookupcat(COMM, comm, p_inst->id, p_crddet)
		 || SUCCEED != lookupcat(RISK, risk, p_inst->id, p_crddet) )
		{
			DBG_PRINTF((dbg_syserr, "A Category Value was not "
							"recognised"));
			ret = FAIL;
		}
	}
	
	/* mvitolins HAAB_09_002_WO-3 27/11/2009 */
	if ( hp->ver > 7 )
	{
		TMPCPY(design_ref);
		strscpy(p_non_crddet_flds->design_ref, tmp);
	} 
	else
	{
		p_non_crddet_flds->design_ref[0]=EOS;
	}

	/*
	 * Display the copied data for a visual verification
	 */
	DBG_PRINTF((dbg_progdetail,"instcode:    <%s>", p_inst->instcode));
	DBG_PRINTF((dbg_progdetail,"brncode:     <%s>", branch_tmp.brncode));
	DBG_PRINTF((dbg_progdetail,"crdproduct:  <%s>", p_crdp->crdproduct));
	DBG_PRINTF((dbg_progdetail,"branch_id:   <%ld>",p_crddet->branch_id));
	DBG_PRINTF((dbg_progdetail,"crdproduct_id:<%ld>",p_crddet->crdproduct_id));
	DBG_PRINTF((dbg_progdetail,"accdet_id:   <%ld>",p_crddet->accdet_id));
	DBG_PRINTF((dbg_progdetail,"custdet_id:  <%ld>",p_crddet->custdet_id));
	DBG_PRINTF((dbg_progdetail,"classid:     <%hd>",p_crddet->classid));
	DBG_PRINTF((dbg_progdetail,"pan:         <%s>", p_crddet->pan));
	DBG_PRINTF((dbg_progdetail,"seqno:       <%hd>",p_crddet->seqno));
	DBG_PRINTF((dbg_progdetail,"accno:       <%s>", p_acc->accno));
	DBG_PRINTF((dbg_progdetail,"currcode:    <%s>", p_acc->currcode));
	DBG_PRINTF((dbg_progdetail,"expdate:     <%ld>",p_crddet->expdate));
	DBG_PRINTF((dbg_progdetail,"effdate:     <%ld>",p_crddet->effdate));
	DBG_PRINTF((dbg_progdetail,"cyclen:      <%hd>",p_crddet->cyclen));
	DBG_PRINTF((dbg_progdetail,"cycbegin:    <%ld>",p_crddet->cycbegin));
	DBG_PRINTF((dbg_progdetail,"amtauth:     <%f>",p_crddet->amtauth));
	DBG_PRINTF((dbg_progdetail,"amtrem:      <%f>",p_crddet->amtrem));
	DBG_PRINTF((dbg_progdetail,"blkamt:      <%f>",p_crddet->blkamt));
	DBG_PRINTF((dbg_progdetail,"statcode:    <%s>", p_crddet->statcode));
	DBG_PRINTF((dbg_progdetail,"batch:       <%ld>",p_crddet->batch));
	DBG_PRINTF((dbg_progdetail,"crdsmade:    <%hd>",p_crddet->crdsmade));
	DBG_PRINTF((dbg_progdetail,"pinsmade:    <%hd>",p_crddet->pinsmade));
	DBG_PRINTF((dbg_progdetail,"cvv:         <%s>", p_crddet->cvv));
	DBG_PRINTF((dbg_progdetail,"pvki:        <%s>", p_crddet->pvki));
	DBG_PRINTF((dbg_progdetail,"pvv:         <%s>", p_crddet->pvv));
	DBG_PRINTF((dbg_progdetail,"lang:        <%s>", p_crddet->lang));
	DBG_PRINTF((dbg_progdetail,"title:       <%s>", p_crddet->title));
	DBG_PRINTF((dbg_progdetail,"firstname:   <%s>", p_crddet->firstname));
	DBG_PRINTF((dbg_progdetail,"lastname:    <%s>", p_crddet->lastname));
	DBG_PRINTF((dbg_progdetail,"discret:     <%s>", p_crddet->discret));
	DBG_PRINTF((dbg_progdetail,"usrdata:     <%s>", p_crddet->usrdata));
	DBG_PRINTF((dbg_progdetail,"svccode:     <%s>", p_crddet->svccode));
	DBG_PRINTF((dbg_progdetail,"aci:         <%s>", p_crddet->aci));
	DBG_PRINTF((dbg_progdetail,"offauth:     <%f>",p_crddet->offauth));
	DBG_PRINTF((dbg_progdetail,"cust_id_num: <%s>",p_crddet->cust_id_num));
	DBG_PRINTF((dbg_progdetail,"kinship:     <%s>", p_crddet->kinship));
	DBG_PRINTF((dbg_progdetail,"date_statchg:<%ld>",p_crddet->date_statchg));
	DBG_PRINTF((dbg_progdetail,"old_cvv:     <%s>", p_crddet->old_cvv));
	DBG_PRINTF((dbg_progdetail,"old_expdate: <%ld>",p_crddet->old_expdate));
	DBG_PRINTF((dbg_progdetail,"renew:       <%s>", p_crddet->renew));
	DBG_PRINTF((dbg_progdetail,"corp:        <%s>", p_crddet->corp));
	DBG_PRINTF((dbg_progdetail,"date_birth:  <%ld>",p_crddet->date_birth));
	DBG_PRINTF((dbg_progdetail,"offlim:      <%lf>",p_crddet->offlim));
	DBG_PRINTF((dbg_progdetail,"cvc:         <%s>", p_crddet->cvc));
	DBG_PRINTF((dbg_progdetail,"oldcvc:      <%s>", p_crddet->oldcvc));
	DBG_PRINTF((dbg_progdetail,"embossname:  <%s>", p_crddet->embossname));
	DBG_PRINTF((dbg_progdetail,"additionalno:<%hd>",p_crddet->additionalno));
	DBG_PRINTF((dbg_progdetail,"custcode:<%s>",cust_tmp.custcode));
        DBG_PRINTF((dbg_progdetail,"debaccno:    <%s>", chargecard_data->debaccno));
        DBG_PRINTF((dbg_progdetail,"acctypelim: <%s>", chargecard_data->acctypelim));
        DBG_PRINTF((dbg_progdetail,"chgcycle:   <%d>", chargecard_data->chgcycle));
        DBG_PRINTF((dbg_progdetail,"totlim_amt: <%ld>", chargecard_data->totlim_amt));
        DBG_PRINTF((dbg_progdetail,"cashlim_amt: <%ld>", chargecard_data->cashlim_amt));
        DBG_PRINTF((dbg_progdetail,"purchlim_amt:<%ld>", chargecard_data->purchlim_amt));
        DBG_PRINTF((dbg_progdetail,"totlim_num: <%d>", chargecard_data->totlim_num));
        DBG_PRINTF((dbg_progdetail,"cashlim_num:<%d>", chargecard_data->cashlim_num));
        DBG_PRINTF((dbg_progdetail,"purchlim_num:<%d>", chargecard_data->purchlim_num));
/*sdods... (category values)*/
	DBG_PRINTF((dbg_progdetail,"cat_issfee_id:<%ld>",
		 p_non_crddet_flds->cat_issfee_id));
	DBG_PRINTF((dbg_progdetail,"cat_isscycfee_id:<%ld>",
		 p_non_crddet_flds->cat_isscycfee_id));
	DBG_PRINTF((dbg_progdetail,"cat_isscomm_id:<%ld>",
			  p_crddet->cat_isscomm_id));
	DBG_PRINTF((dbg_progdetail,"cat_issrisk_id:<%ld>",
			  p_crddet->cat_issrisk_id));

	/* MG BPD_MAINT-21 PIN offset. */
	DBG_PRINTF((dbg_progdetail, "PIN offset old pan: <%s>",
				    p_crdpinmigr->pan_old));
	DBG_PRINTF((dbg_progdetail, "PIN offset old expdate: <%s>",
				    p_crdpinmigr->expdate));
	DBG_PRINTF((dbg_progdetail, "PIN offset:      <%s>",
				    p_crdpinmigr->pin_offset));

	/*
	 * Copy the table keys
	 */
	strscpy (p_crddet_k->pan, p_crddet->pan);
	p_crddet_k->seqno =  p_crddet->seqno;

	DBG_PRINTF((dbg_progdetail,"k_pan:   <%s>", p_crddet_k->pan));
	DBG_PRINTF((dbg_progdetail,"k_seqno: <%d>",p_crddet_k->seqno));
	DBG_PRINTF((dbg_progdetail,"old_pan: <%s>", old_pan));
	DBG_PRINTF((dbg_progdetail,"old_seq: <%d>",*old_seqno));

	/*
	 * Convert embossing data if required
	 */
	if (G_emconv != NULL)
	{
		strconv_in (p_crddet->embossname, G_emconv);
		DBG_PRINTF((dbg_progdetail,"embossname:  <%s>",
		        p_crddet->embossname));
	}
	DBG_PRINTF((dbg_progdetail,"ret: <%d>",ret));
	
	free ((char *)hp);
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : parse_ccappl
 *
 * Purpose      : Fill in an card application record from the input
 *		  version of it.
 *
 * Parameters   : buf -> input record
 *		  p_ccappl -> card application
 *
 * Returns      : SUCCEED
 *
 * Comments     :
 *
 *----------------------------------------------------------------------*/
ctxpublic int parse_ccappl (char *buf, CCAPPL_t *p_ccappl)
{
	int ret = SUCCEED;

	memset ((char *)p_ccappl, 0, sizeof (CCAPPL_t));

	/*
	 * Copy our buffer into ccappl
	 */
	memcpy (p_ccappl->appldata1, buf +   8,16);
	memcpy (p_ccappl->appldata2, buf +  24,16);
	memcpy (p_ccappl->appldata3, buf +  40,16);
	memcpy (p_ccappl->appldata4, buf +  56,16);
	memcpy (p_ccappl->appldata5, buf +  72,16);
	memcpy (p_ccappl->appldata6, buf +  88,16);
	memcpy (p_ccappl->appldata7, buf + 104,16);
	memcpy (p_ccappl->appldata8, buf + 120,16);

	memcpy (p_ccappl->tickbox1,  buf + 136, 1);
	memcpy (p_ccappl->tickbox2,  buf + 137, 1);
	memcpy (p_ccappl->tickbox3,  buf + 138, 1);
	memcpy (p_ccappl->tickbox4,  buf + 139, 1);
	memcpy (p_ccappl->tickbox5,  buf + 140, 1);
	memcpy (p_ccappl->tickbox6,  buf + 141, 1);
	memcpy (p_ccappl->tickbox7,  buf + 142, 1);
	memcpy (p_ccappl->tickbox8,  buf + 143, 1);
	memcpy (p_ccappl->tickbox9,  buf + 144, 1);
	memcpy (p_ccappl->tickbox10, buf + 145, 1);
	memcpy (p_ccappl->tickbox11, buf + 146, 1);
	memcpy (p_ccappl->tickbox12, buf + 147, 1);
	memcpy (p_ccappl->tickbox13, buf + 148, 1);
	memcpy (p_ccappl->tickbox14, buf + 149, 1);
	memcpy (p_ccappl->tickbox15, buf + 150, 1);
	memcpy (p_ccappl->tickbox16, buf + 151, 1);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : parse_cust
 *
 * Purpose      : Fill in an customer details record from the input
 *		  version of it.
 *
 * Parameters   : buf -> input record
 *		  p_ccappl -> customer details
 *
 * Returns      : SUCCEED
 *
 * Comments     :
 *
 *----------------------------------------------------------------------*/
ctxpublic int parse_cust (char *buf, CUSTDET_t *p_custdet, 
						CUSTDET_HASH_t *p_custdet_k, CUSTDET_X_t *p_custdet_x)
{
	int ret = SUCCEED;
	char tmp[9];
	Hdr *hp;
	INST_t	inst;
	INST_HASH_t	inst_k;

	hp=parse_hdr (buf);
	/*
	 * Initialise memory for our custdet record
	 */
	memset((char *)&inst_k, 0, sizeof(INST_HASH_t));
	memset((char *)&inst, 0, sizeof(INST_t));
	memset((char *)p_custdet, 0, sizeof(CUSTDET_t));
	memset((char *)p_custdet_k, 0, sizeof(CUSTDET_HASH_t ));
	memset((char *)p_custdet_x, 0, sizeof(CUSTDET_X_t ));
	memset(tmp, NULL, sizeof(tmp));

	/*
	 * Copy the buffer into the custdet record
	 */

	memcpy(inst_k.instcode,      buf +  8, 4);
	stp_right(inst_k.instcode);
	memcpy(p_custdet->custcode,      buf + 20, 12);
	/* <7087> */
	/* Changing number of read bytes from 2 to 1 */
	memcpy(tmp,                      buf + 32, 1);
		tmp[1] = 0;
		p_custdet->typeid = atoi(tmp);
	/* </7087> */
	memcpy(p_custdet->lastname,      buf + 33,20);
	memcpy(p_custdet->firstname,     buf + 53,20);
	memcpy(p_custdet->title,         buf + 73, 4);
	if (buf[73] == '1')
		p_custdet->sex[0] = 'F';
	else
		p_custdet->sex[0] = 'M';
	if (buf[74] == '1')
		p_custdet->married[0] = 'M';
	else
		p_custdet->married[0] = 'S';

	memcpy(tmp,                      buf + 79, 2);
		tmp[2] = 0;
		p_custdet->prof_code = atoi (tmp);
	memcpy(p_custdet->addrl1,        buf + 81,35);
	memcpy(p_custdet->addrl2,        buf +116,35);
	memcpy(p_custdet->addrl3,        buf +151,35);
	memcpy(p_custdet->home_city,     buf +186,20);
	memcpy(p_custdet->home_tel,      buf +206,20);
	memcpy(p_custdet->postcode,      buf +226,10);
	memcpy(p_custdet->po_box,        buf +236, 8);
	memcpy(p_custdet->work_addr1,    buf +244,30);
	memcpy(p_custdet->work_addr2,    buf +279,30);
	memcpy(p_custdet->work_addr3,    buf +314,30);
	memcpy(p_custdet->work_city,     buf +349,20);
	memcpy(p_custdet->work_tel,      buf +369,20);
	/*
	 * GT 1999-08-05
	 * There is a problem with work postcodes.  They are defined in the
	 * database as only being 8 characters.  The "fix" is to truncate the
	 * imported value, and warn the user if the 9th and 10th characters
	 * are not blank.
	 */
	memcpy(p_custdet->work_postcode, buf +389, 8);
	if (buf[397] != ' ' || buf[398] != ' ')
	{
		DBG_PRINTF ((dbg_syswarn, "Work postcode too long: <%.10s>",
			buf+389));
	}

	/* Birth date omitted */
	/*
	 * GT 1999-08-05
	 * There is a problem with dates of birth.  The DoB is given in the
	 * imported custdet record, but there was no DoB field in the database
	 * CUSTDET table.  Conversely, there is a DoB field in the CRDDET table,
	 * but no such field in the imported crddet record.  The fix is to add
	 * a DoB field to CUSTDET, and fill in the DoB field from that in
	 * CRDDET.
	 */
	memcpy(tmp,                      buf +399, 8);
		tmp[8] = 0;
		p_custdet->date_birth = atol (tmp);
	memcpy(p_custdet->id_number,     buf +407,12);
	memcpy(p_custdet->mailshots,     buf +419,1);
		if (p_custdet->mailshots[0] == ' ')
		{
			p_custdet->mailshots[0] = '0';
		}
	memcpy(p_custdet->usrdata1,      buf +420,12);
	memcpy(p_custdet->usrdata2,      buf +432,12);
	memcpy(p_custdet->usrdata3,      buf +444,12);

	/* Version 2 - CCS 1.1 additional data, NMR010987 WLi 01/3/2004 */
	if (hp->ver > 1)
	{
		memcpy(p_custdet->prflang, buf+456, 2);
		if (!strncmp(p_custdet->prflang, "  ", 2))
				strscpy(p_custdet->prflang, DEFAULT_PRFLANG);
		memcpy(tmp, buf+454, 1);
		tmp[1]=EOS;
		p_custdet->addrind=atoi(tmp);
		/* NMR012664 - VM - Additional fields in custdet V3 record */
		if(hp->ver > 2)
		{
			memcpy(p_custdet->email, buf+459, 64);
			memcpy(p_custdet->fax, buf+523, 20);
			memcpy(p_custdet->usrdata4, buf+543, 32);
		}
	}
	else    /* default values */
	{
			strscpy(p_custdet->prflang, DEFAULT_PRFLANG);
			p_custdet->addrind=0;
	}
	
	memcpy(p_custdet->national_id, buf+575, 22);
	memcpy(p_custdet->cat_params, buf+597, 127);
	
	/* Parse custdet_x record information */
	memcpy(p_custdet_x->usrdata1, buf+724, 32);
	memcpy(p_custdet_x->usrdata2, buf+756, 32);
	memcpy(p_custdet_x->usrdata3, buf+788, 32);
	memcpy(p_custdet_x->usrdata4, buf+820, 32);
	memcpy(p_custdet_x->usrdata5, buf+852, 32);
	memcpy(p_custdet_x->usrdata6, buf+884, 32);

	/*
	 * set stmt_code to work if it is a corporate card, else home.
	 */
	if(p_custdet->typeid == 2)
	{
		p_custdet->stmt_code = 2;
	}
	else
	{
		p_custdet->stmt_code = 1;
	}

	p_custdet->date_accepted = G_sysdate;
	
	if (SUCCEED == INSTgetbyINST_HASH_cache (&inst, &inst_k))
		p_custdet->inst_id = inst.id;

	/*
  	 * Copy the record keys into the correct fields
	 */
	p_custdet_k->inst_id = p_custdet->inst_id;
	strscpy( p_custdet_k->custcode, p_custdet->custcode );

	/*
 	 * Display the copied data to allow for a visual check
	 */
	DBG_PRINTF((dbg_progdetail,"instcode:  <%s>", inst_k.instcode));
	DBG_PRINTF((dbg_progdetail,"custcode:  <%s>", p_custdet->custcode));
	DBG_PRINTF((dbg_progdetail,"title:     <%s>", p_custdet->title));
	DBG_PRINTF((dbg_progdetail,"firstname: <%s>", p_custdet->firstname));
	DBG_PRINTF((dbg_progdetail,"lastname:  <%s>", p_custdet->lastname));
	DBG_PRINTF((dbg_progdetail,"addrl1:    <%s>", p_custdet->addrl1));
	DBG_PRINTF((dbg_progdetail,"addrl2:    <%s>", p_custdet->addrl2));
	DBG_PRINTF((dbg_progdetail,"addrl3:    <%s>", p_custdet->addrl3));
	DBG_PRINTF((dbg_progdetail,"home_city: <%s>", p_custdet->home_city));
	DBG_PRINTF((dbg_progdetail,"postcode:  <%s>", p_custdet->postcode));
	DBG_PRINTF((dbg_progdetail,"email:     <%s>", p_custdet->email));
	DBG_PRINTF((dbg_progdetail,"fax:       <%s>", p_custdet->fax));
	DBG_PRINTF((dbg_progdetail,"usrdata4:  <%s>", p_custdet->usrdata4));
	DBG_PRINTF((dbg_progdetail,"national_id: <%s>", p_custdet->national_id));
	DBG_PRINTF((dbg_progdetail,"cat_params:  <%s>", p_custdet->cat_params));
	
	DBG_PRINTF((dbg_progdetail,"For Custdet_x record"));
	DBG_PRINTF((dbg_progdetail,"usrdata1:  <%s>", p_custdet_x->usrdata1));
	DBG_PRINTF((dbg_progdetail,"usrdata2:  <%s>", p_custdet_x->usrdata2));
	DBG_PRINTF((dbg_progdetail,"usrdata3:  <%s>", p_custdet_x->usrdata3));
	DBG_PRINTF((dbg_progdetail,"usrdata4:  <%s>", p_custdet_x->usrdata4));
	DBG_PRINTF((dbg_progdetail,"usrdata5:  <%s>", p_custdet_x->usrdata5));
	DBG_PRINTF((dbg_progdetail,"usrdata6:  <%s>", p_custdet_x->usrdata6));

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : parse_crdstmt
 *
 * Purpose      : parse line to populate crdstmt record
 *
 * Parameters   : char *: pointer to buffer (card import record)
 *		  CRDSTMT_t * pointer to CRDSTMT_t structure
 *		  CRDSTMT_k * pointer to CRDSTMT_HASH_t structure
 *
 * Returns      : SUCCEED/FAIL
 *
 * Comments     : Only the PAN and seqno are passed in the import file so
 *		  all other variables have to be set to defaults.
 *
 *----------------------------------------------------------------------*/
ctxpublic int parse_crdstmt (char *buf, CRDSTMT_t *p_crdstmt, CRDSTMT_HASH_t *p_crdstmt_k)
{
	int ret = SUCCEED;
	char tmp[2];
	char *pan_enc;
	CRDDET_t crddet;
	CRDDET_HASH_t crddet_k;

	memset ((char *)&crddet_k,   0, sizeof (CRDDET_t));
	memset ((char *)p_crdstmt,   0, sizeof (CRDSTMT_t));
	memset ((char *)p_crdstmt_k, 0, sizeof (CRDSTMT_HASH_t));

	memcpy (crddet_k.pan, buf + 24, 19);

	/* sdods PCI DSS 07/01/2009, NMR023311 */
	if( NULL == (pan_enc = encryptPan(crddet_k.pan, NULL)) )
		return FAIL;
	else
		strcpy(crddet_k.pan, pan_enc);

	memcpy (tmp,            buf + 43,  1);
		tmp[1] = 0;
		crddet_k.seqno = atoi (tmp);

	/* set all other values to defaults */
	p_crdstmt->stmtcycle = 30;
	p_crdstmt->stmtprndate = 22630831L;
	p_crdstmt->prvstmtdate = G_sysdate;
	p_crdstmt->nxtstmtdate = calc_next_stmtdate (p_crdstmt->stmtcycle);

	if (SUCCEED == (ret = CRDDETgetbyCRDDET_HASH (&crddet, &crddet_k)))
		p_crdstmt->crddet_id = crddet.id;
	/*
	 * copy to the key
	 */
	p_crdstmt_k->crddet_id = p_crdstmt->crddet_id;
	p_crdstmt_k->stmtprndate = p_crdstmt->stmtprndate;

	/* Display it all */

	DBG_PRINTF((dbg_progdetail,"pan:        <%s>", crddet_k.pan));
	DBG_PRINTF((dbg_progdetail,"seqno:      <%d>", crddet_k.seqno));
	DBG_PRINTF((dbg_progdetail,"crddet_id:  <%ld>", p_crdstmt->crddet_id));
	DBG_PRINTF((dbg_progdetail,"prvstmtdate:<%ld>",p_crdstmt->prvstmtdate));
	DBG_PRINTF((dbg_progdetail,"nxtstmtdate:<%ld>",p_crdstmt->nxtstmtdate));
	DBG_PRINTF((dbg_progdetail,"stmtprndate:<%ld>",p_crdstmt->stmtprndate));
	DBG_PRINTF((dbg_progdetail,"stmtcycle:  <%d>", p_crdstmt->stmtcycle));
	DBG_PRINTF((dbg_progdetail,"crddet_id:  <%ld>", p_crdstmt_k->crddet_id));
	DBG_PRINTF((dbg_progdetail,"stmtprndate:<%ld>",p_crdstmt_k->stmtprndate));

	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function     : parse_corpcrdlnk
 *
 * Purpose      : parse line to populate corpcrdlnk record
 *
 * Parameters   : char *: pointer to buffer (card import record)
 *                CORPCRDLNK_t * pointer to CORPCRDLNK_t structure
 *                CORPCRDLNK_k * pointer to CORPCRDLNK_HASH_t structure
 *
 * Returns      : SUCCEED/FAIL
 *
 * Comments     :
 *
 *----------------------------------------------------------------------*/
ctxpublic int parse_corpcrdlnk (char *buf, CORPCRDLNK_t *p_corpcrdlnk, CORPCRDLNK_HASH_t *p_corpcrdlnk_k,
							CRDDET_HASH_t *p_crddet, CRDDET_HASH_t *p_pri_crddet)
{
	int ret = SUCCEED;
	char tmp[2];
	char *pan_enc;
	CRDDET_t crddet, pri_crddet;

	memset ((char *)p_corpcrdlnk,   0, sizeof (CORPCRDLNK_t));
	memset ((char *)p_crddet,   0, sizeof (CRDDET_t));
	memset ((char *)p_crddet,   0, sizeof (CRDDET_t));
	memset ((char *)p_corpcrdlnk_k, 0, sizeof (CORPCRDLNK_HASH_t));

	memcpy(p_crddet->pan, buf + 24, 19);

	/* sdods PCI DSS 07/01/2009, NMR023311 */
	if( NULL == (pan_enc = encryptPan(p_crddet->pan, NULL)) )
		return FAIL;
	else
		strcpy(p_crddet->pan, pan_enc);

	memcpy(tmp,           buf + 43, 1);
	tmp[1] = 0;
	p_crddet->seqno = atoi(tmp);

	memcpy(p_pri_crddet->pan, buf + 274, 19);
	memcpy(tmp,           buf + 293, 1);
	tmp[1] = 0;
	p_pri_crddet->seqno = atoi(tmp);
	/* mvitolin HAAB_09_012_WO-1 01/15/2010 
	 * strip trailing spaces */ 
	stp_right(p_crddet->pan);
	stp_right(p_pri_crddet->pan);
	DBG_PRINTF((dbg_progdetail,"pan:         <%s>", p_crddet->pan));
	DBG_PRINTF((dbg_progdetail,"seqno:       <%d>",p_crddet->seqno));
	DBG_PRINTF((dbg_progdetail,"crddet_id:  <%ld>", p_corpcrdlnk->crddet_id));
	DBG_PRINTF((dbg_progdetail,"pri_pan:     <%s>", p_pri_crddet->pan));
	DBG_PRINTF((dbg_progdetail,"pri_seqno:   <%d>",p_pri_crddet->seqno));
	
	if (SUCCEED == (ret = CRDDETgetbyCRDDET_HASH (&crddet, p_crddet)))
		p_corpcrdlnk->crddet_id = crddet.id;
	
	if (ret == SUCCEED && SUCCEED == (ret = CRDDETgetbyCRDDET_HASH (&pri_crddet, p_pri_crddet)))
		p_corpcrdlnk->pri_crddet_id = pri_crddet.id;
	
	if(ret == SUCCEED)
		p_corpcrdlnk_k->crddet_id = p_corpcrdlnk->crddet_id;

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function     : parse_crdpin
 *
 * Purpose      : parse line to populate crdpin record
 *
 * Parameters   : char *: pointer to buffer (card import record)
 *                CRDPIN_t * pointer to CRDPIN_t structure
 *                CRDPIN_k * pointer to CRDPIN_HASH_t structure
 *
 * Returns      : SUCCEED/FAIL
 *
 * Comments     : Only the PAN and seqno are passed in the import file so
 *                all other variables have to be set to defaults.
 *
 *----------------------------------------------------------------------*/
ctxpublic int parse_crdpin (char *buf, CRDPIN_t *p_crdpin, CRDPIN_HASH_t *p_crdpin_k)
{
	int ret = SUCCEED;
	char tmp[2];
	char	*pan_enc;
	CRDDET_t crddet;
	CRDDET_HASH_t crddet_k;

	memset ((char *)p_crdpin,   0, sizeof (CRDPIN_t));
	memset ((char *)p_crdpin_k, 0, sizeof (CRDPIN_HASH_t));

	memcpy (crddet_k.pan, buf + 24, 19);

	/* sdods PCI DSS 07/01/2009, NMR023311 */
	if( NULL == (pan_enc = encryptPan(crddet_k.pan, NULL)) )
		return FAIL;
	else
		strcpy(crddet_k.pan, pan_enc);

	memcpy (tmp,            buf + 43,  1);
		tmp[1] = 0;
		crddet_k.seqno = atoi (tmp);

	DBG_PRINTF((dbg_progdetail,"pan:         <%s>", crddet_k.pan));
	DBG_PRINTF((dbg_progdetail,"seqno:       <%d>",crddet_k.seqno));
	DBG_PRINTF((dbg_progdetail,"pintries:    <%ld>",p_crdpin->pintries));
	DBG_PRINTF((dbg_progdetail,"pinblk:      <%s>",p_crdpin->pinblk));

	if (SUCCEED == (ret = CRDDETgetbyCRDDET_HASH (&crddet, &crddet_k)))
		p_crdpin->crddet_id = crddet.id;
		
	p_crdpin_k->crddet_id = p_crdpin->crddet_id;

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : parse_merchant
 *
 * Purpose      : Fill in a merchant details record from the input
 *		  version of it.
 *
 * Parameters   : buf -> input record
 *		  p_merchant -> merchant details
 *		  p_merchant_k -> merchant key
 *
 * Returns      : SUCCEED
 *
 * Comments     : TR 4786 - Added for merchant import
 *
 *----------------------------------------------------------------------*/
ctxpublic int parse_merchant (char *buf, MERCHANT_t *p_merchant, MERCHANT_HASH_t *p_merchant_k)
{
	int ret = SUCCEED;
	char tmp[13];
	INST_t	inst;
	INST_HASH_t	inst_k;

	/*
	 * Initialise memory for merchant record
	 */
	memset((char *)p_merchant, 0, sizeof(MERCHANT_t));
	memset((char *)p_merchant_k, 0, sizeof(MERCHANT_HASH_t ));
	memset((char *)&inst, 0, sizeof(INST_t));
	memset((char *)&inst_k, 0, sizeof(INST_HASH_t ));



	memcpy(inst_k.instcode,buf + 8,4);
	memcpy(p_merchant->brncode,buf + 12,8);
	memcpy(p_merchant->mrchno,buf + 20,15);
	memcpy(p_merchant->posflag,buf + 35,1);
	memcpy(p_merchant->vipflag,buf + 36,1);
	memcpy(tmp,buf + 37,1);
	tmp[1]=0;
	p_merchant->mrchstat=atoi(tmp);
	memcpy(p_merchant->name,buf + 38,25);
	memcpy(p_merchant->trading_as,buf + 63,25);
	memcpy(p_merchant->phy_address1,buf + 88,25);
	memcpy(p_merchant->phy_address2,buf + 113,25);
	memcpy(p_merchant->phy_city,buf + 138,20);
	memcpy(p_merchant->phy_state,buf + 158,3);
	memcpy(p_merchant->phy_postcode,buf + 161,15);
	memcpy(p_merchant->phy_countrycode,buf + 176,3);
	memcpy(p_merchant->address1,buf + 179,25);
	memcpy(p_merchant->address2,buf + 204,25);
	memcpy(p_merchant->city,buf + 229,20);
	memcpy(p_merchant->state,buf + 249,3);
	memcpy(p_merchant->postcode,buf + 252,15);
	memcpy(p_merchant->countrycode,buf + 267,3);
	memcpy(p_merchant->reg_address1,buf + 270,25);
	memcpy(p_merchant->reg_address2,buf + 295,25);
	memcpy(p_merchant->reg_city,buf + 320,20);
	memcpy(p_merchant->reg_state,buf + 340,3);
	memcpy(p_merchant->reg_postcode,buf + 343,15);
	memcpy(p_merchant->reg_countrycode,buf + 358,3);
	memcpy(p_merchant->head_office,buf + 361,15);
	memcpy(p_merchant->rnc,buf + 376,20);
	memcpy(p_merchant->taxreg,buf + 396,25);
	memcpy(p_merchant->contact1,buf + 421,20);
	memcpy(p_merchant->contact2,buf + 441,20);
	memcpy(p_merchant->contact3,buf + 461,20);
	memcpy(p_merchant->telno1,buf + 481,20);
	memcpy(p_merchant->telno2,buf + 501,20);
	memcpy(p_merchant->telno3,buf + 521,20);
	memcpy(p_merchant->faxno,buf + 541,20);
	memcpy(p_merchant->telex,buf + 561,20);
	memcpy(p_merchant->email,buf + 581,30);
	memcpy(tmp,buf + 611,12);
	tmp[12]=0;
	p_merchant->msc=atof(tmp);
	memcpy(p_merchant->msc_charge,buf + 623,1);
	memcpy(p_merchant->msc_calc,buf + 624,1);
	memcpy(tmp,buf + 625,4);
	tmp[4]=0;
	p_merchant->msc_table=atoi(tmp);
	memcpy(tmp,buf + 629,12);
	tmp[12]=0;
	p_merchant->retenamt=atof(tmp);
	memcpy(tmp,buf + 641,12);
	tmp[12]=0;
	p_merchant->retenpc=atof(tmp);
	memcpy(tmp,buf + 653,1);
	tmp[1]=0;
	p_merchant->stmtto=atoi(tmp);
	memcpy(tmp,buf + 654,1);
	tmp[1]=0;
	p_merchant->stmtto_ho=atoi(tmp);
	memcpy(p_merchant->stmtfreq,buf + 655,1);
	memcpy(p_merchant->paymtype,buf + 656,1);
	memcpy(p_merchant->paymto,buf + 657,1);
	memcpy(p_merchant->sortcode,buf + 658,9);
	memcpy(p_merchant->accno,buf + 667,28);
	memcpy(p_merchant->accnm,buf + 695,30);
	memcpy(p_merchant->contrno,buf + 725,8);
	memcpy(tmp,buf + 733,8);
	tmp[8]=0;
	p_merchant->contrdate=atol(tmp);
	memcpy(p_merchant->contrsign,buf + 741,3);
	memcpy(tmp,buf + 744,8);
	tmp[8]=0;
	p_merchant->contrcnx=atol(tmp);

	/* If the contract termination date is not set, set
	** it to default of 31/08/2263
	*/
	if ( 0 == p_merchant->contrcnx )
	{
		p_merchant->contrcnx = 22630831L;
	}

	memcpy(tmp,buf + 752,4);
	tmp[4]=0;
	p_merchant->cyclen=atoi(tmp);
	memcpy(tmp,buf + 756,8);
	tmp[8]=0;
	p_merchant->cycbegin=atol(tmp);
	memcpy(tmp,buf + 764,4);
	tmp[4]=0;
	p_merchant->no_imprntrs = atoi(tmp);
	memcpy(p_merchant->zonegeog,buf + 768,3);
	memcpy(p_merchant->zonecomer,buf + 771,3);
	memcpy(p_merchant->zonepostal,buf + 774,3);
	memcpy(p_merchant->currcode,buf + 777,3);
	memcpy(tmp,buf + 780,4);
	tmp[4]=0;
	p_merchant->acptbus=atoi(tmp);
	memcpy(p_merchant->taxcode,buf + 784,1);
	memcpy(p_merchant->official,buf + 785,3);
	memcpy(p_merchant->usrdata1,buf + 788,12);
	memcpy(p_merchant->usrdata2,buf + 800,12);
	memcpy(p_merchant->usrdata3,buf + 812,12);

	/* If statement is to be sent to the physical address
	** and the physical address is not set copy physical
	** address from correspondance address
	*/
	if ( (2 == p_merchant->stmtto) && (0 == *(stp_right(p_merchant->phy_address1))))
	{
		strscpy(p_merchant->phy_address1,p_merchant->address1);
		strscpy(p_merchant->phy_address2,p_merchant->address2);
		strscpy(p_merchant->phy_city,p_merchant->city);
		strscpy(p_merchant->phy_postcode,p_merchant->postcode);
		strscpy(p_merchant->phy_countrycode,p_merchant->countrycode);
	}

	/* If statement is to be sent to the registered address
	** and the registered address is not set copy registered
	** address from correspondance address
	*/
	if ( (3 == p_merchant->stmtto) && (0 == *(stp_right(p_merchant->reg_address1))))
	{
		strscpy(p_merchant->reg_address1,p_merchant->address1);
		strscpy(p_merchant->reg_address2,p_merchant->address2);
		strscpy(p_merchant->reg_city,p_merchant->city);
		strscpy(p_merchant->reg_postcode,p_merchant->postcode);
		strscpy(p_merchant->reg_countrycode,p_merchant->countrycode);
	}

	DBG_PRINTF((dbg_progdetail,"instcode:		<%s>",inst_k.instcode));
	DBG_PRINTF((dbg_progdetail,"brncode:		<%s>",p_merchant->brncode));
	DBG_PRINTF((dbg_progdetail,"mrchno:		<%s>",p_merchant->mrchno));
	DBG_PRINTF((dbg_progdetail,"posflag:		<%s>",p_merchant->posflag));
	DBG_PRINTF((dbg_progdetail,"vipflag:		<%s>",p_merchant->vipflag));
	DBG_PRINTF((dbg_progdetail,"mrchstat:		<%d>",p_merchant->mrchstat));
	DBG_PRINTF((dbg_progdetail,"name:		<%s>",p_merchant->name));
	DBG_PRINTF((dbg_progdetail,"trading_as:		<%s>",p_merchant->trading_as));
	DBG_PRINTF((dbg_progdetail,"phy_address1:	<%s>",p_merchant->phy_address1));
	DBG_PRINTF((dbg_progdetail,"phy_address2:	<%s>",p_merchant->phy_address2));
	DBG_PRINTF((dbg_progdetail,"phy_city:		<%s>",p_merchant->phy_city));
	DBG_PRINTF((dbg_progdetail,"phy_state:		<%s>",p_merchant->phy_state));
	DBG_PRINTF((dbg_progdetail,"phy_postcode:	<%s>",p_merchant->phy_postcode));
	DBG_PRINTF((dbg_progdetail,"phy_countrycode:	<%s>",p_merchant->phy_countrycode));
	DBG_PRINTF((dbg_progdetail,"address1:		<%s>",p_merchant->address1));
	DBG_PRINTF((dbg_progdetail,"address2:		<%s>",p_merchant->address2));
	DBG_PRINTF((dbg_progdetail,"city:		<%s>",p_merchant->city));
	DBG_PRINTF((dbg_progdetail,"state:		<%s>",p_merchant->state));
	DBG_PRINTF((dbg_progdetail,"postcode:		<%s>",p_merchant->postcode));
	DBG_PRINTF((dbg_progdetail,"countrycode:	<%s>",p_merchant->countrycode));
	DBG_PRINTF((dbg_progdetail,"reg_address1:	<%s>",p_merchant->reg_address1));
	DBG_PRINTF((dbg_progdetail,"reg_address2:	<%s>",p_merchant->reg_address2));
	DBG_PRINTF((dbg_progdetail,"reg_city:		<%s>",p_merchant->reg_city));
	DBG_PRINTF((dbg_progdetail,"reg_state:		<%s>",p_merchant->reg_state));
	DBG_PRINTF((dbg_progdetail,"reg_postcode:	<%s>",p_merchant->reg_postcode));
	DBG_PRINTF((dbg_progdetail,"reg_countrycode:	<%s>",p_merchant->reg_countrycode));
	DBG_PRINTF((dbg_progdetail,"head_office:	<%s>",p_merchant->head_office));
	DBG_PRINTF((dbg_progdetail,"rnc:		<%s>",p_merchant->rnc));
	DBG_PRINTF((dbg_progdetail,"taxreg:		<%s>",p_merchant->taxreg));
	DBG_PRINTF((dbg_progdetail,"contact1:		<%s>",p_merchant->contact1));
	DBG_PRINTF((dbg_progdetail,"contact2:		<%s>",p_merchant->contact2));
	DBG_PRINTF((dbg_progdetail,"contact3:		<%s>",p_merchant->contact3));
	DBG_PRINTF((dbg_progdetail,"telno1:		<%s>",p_merchant->telno1));
	DBG_PRINTF((dbg_progdetail,"telno2:		<%s>",p_merchant->telno2));
	DBG_PRINTF((dbg_progdetail,"telno3:		<%s>",p_merchant->telno3));
	DBG_PRINTF((dbg_progdetail,"faxno:		<%s>",p_merchant->faxno));
	DBG_PRINTF((dbg_progdetail,"telex:		<%s>",p_merchant->telex));
	DBG_PRINTF((dbg_progdetail,"email:		<%s>",p_merchant->email));
	DBG_PRINTF((dbg_progdetail,"msc:		<%f>",p_merchant->msc));
	DBG_PRINTF((dbg_progdetail,"msc_charge:		<%s>",p_merchant->msc_charge));
	DBG_PRINTF((dbg_progdetail,"msc_calc:		<%s>",p_merchant->msc_calc));
	DBG_PRINTF((dbg_progdetail,"msc_table:		<%d>",p_merchant->msc_table));
	DBG_PRINTF((dbg_progdetail,"retenamt:		<%f>",p_merchant->retenamt));
	DBG_PRINTF((dbg_progdetail,"retenpc:		<%f>",p_merchant->retenpc));
	DBG_PRINTF((dbg_progdetail,"stmtto:		<%d>",p_merchant->stmtto));
	DBG_PRINTF((dbg_progdetail,"stmtto_ho:		<%d>",p_merchant->stmtto_ho));
	DBG_PRINTF((dbg_progdetail,"stmtfreq:		<%s>",p_merchant->stmtfreq));
	DBG_PRINTF((dbg_progdetail,"paymtype:		<%s>",p_merchant->paymtype));
	DBG_PRINTF((dbg_progdetail,"paymto:		<%s>",p_merchant->paymto));
	DBG_PRINTF((dbg_progdetail,"sortcode:		<%s>",p_merchant->sortcode));
	DBG_PRINTF((dbg_progdetail,"accno:		<%s>",p_merchant->accno));
	DBG_PRINTF((dbg_progdetail,"accnm:		<%s>",p_merchant->accnm));
	DBG_PRINTF((dbg_progdetail,"contrno:		<%s>",p_merchant->contrno));
	DBG_PRINTF((dbg_progdetail,"contrdate:		<%ld>",p_merchant->contrdate));
	DBG_PRINTF((dbg_progdetail,"contrsign:		<%s>",p_merchant->contrsign));
	DBG_PRINTF((dbg_progdetail,"contrcnx:		<%ld>",p_merchant->contrcnx));
	DBG_PRINTF((dbg_progdetail,"cyclen:		<%d>",p_merchant->cyclen));
	DBG_PRINTF((dbg_progdetail,"cycbegin:		<%ld>",p_merchant->cycbegin));
	DBG_PRINTF((dbg_progdetail,"no_imprntrs:	<%d>",p_merchant->no_imprntrs));
	DBG_PRINTF((dbg_progdetail,"zonegeog:		<%s>",p_merchant->zonegeog));
	DBG_PRINTF((dbg_progdetail,"zonecomer:		<%s>",p_merchant->zonecomer));
	DBG_PRINTF((dbg_progdetail,"zonepostal:		<%s>",p_merchant->zonepostal));
	DBG_PRINTF((dbg_progdetail,"currcode:		<%s>",p_merchant->currcode));
	DBG_PRINTF((dbg_progdetail,"acptbus:		<%d>",p_merchant->acptbus));
	DBG_PRINTF((dbg_progdetail,"taxcode:		<%s>",p_merchant->taxcode));
	DBG_PRINTF((dbg_progdetail,"official:		<%s>",p_merchant->official));
	DBG_PRINTF((dbg_progdetail,"usrdata1:		<%s>",p_merchant->usrdata1));
	DBG_PRINTF((dbg_progdetail,"usrdata2:		<%s>",p_merchant->usrdata2));
	DBG_PRINTF((dbg_progdetail,"usrdata3:		<%s>",p_merchant->usrdata3));

	if (SUCCEED == INSTgetbyINST_HASH_cache (&inst, &inst_k))
		p_merchant->inst_id = inst.id;

	p_merchant_k->inst_id = p_merchant->inst_id;
	strscpy(p_merchant_k->mrchno, p_merchant->mrchno);


	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : parse_mrchscheme
 *
 * Purpose      : Fill in a merchant scheme details record from the input
 *		  version of it.
 *
 * Parameters   : buf -> input record
 *		  p_mrchscheme -> merchant details
 *		  p_mrchscheme_k -> merchant key
 *
 * Returns      : SUCCEED
 *
 * Comments     : TR 4786 - Added for merchant import
 *
 *----------------------------------------------------------------------*/
ctxpublic int parse_mrchscheme (char *buf, MRCHSCHEME_t *p_mrchscheme, MRCHSCHEME_HASH_t *p_mrchscheme_k)
{
	int ret = SUCCEED;
	char tmp[13];
	INST_t	inst;
	INST_HASH_t	inst_k;
	MERCHANT_t	merchant;
	MERCHANT_HASH_t	merchant_k;

	/*
	 * Initialise memory for merchant scheme record
	 */
	memset((char *)&inst, 0, sizeof(INST_t));
	memset((char *)&inst_k, 0, sizeof(INST_HASH_t));
	memset((char *)&merchant, 0, sizeof(MERCHANT_t));
	memset((char *)&merchant_k, 0, sizeof(MERCHANT_HASH_t));
	memset((char *)p_mrchscheme, 0, sizeof(MRCHSCHEME_t));
	memset((char *)p_mrchscheme_k, 0, sizeof(MRCHSCHEME_HASH_t ));


	memcpy(inst_k.instcode,	buf +  8, 4);
	memcpy(merchant_k.mrchno,	buf + 12, 15);
	memcpy(p_mrchscheme->scheme,	buf + 27, 12);
	memcpy(tmp,			buf + 39, 12);
	tmp[12]=0;
	p_mrchscheme->floorlim = atof(tmp);
	memcpy(tmp,			buf + 51, 12);
	tmp[12]=0;
	p_mrchscheme->msc = atof(tmp);
	memcpy(tmp,			buf + 63, 12);
	tmp[12]=0;
	p_mrchscheme->msc_intl = atof(tmp);
	memcpy(tmp,			buf + 75, 4);
	tmp[4]=0;
	p_mrchscheme->crdacptbus = atoi(tmp);
	memcpy(p_mrchscheme->schmrchno,	buf + 79, 15);

	/* If the schmrchno field not set copy it from
	** the mrchno field
	*/
        if  (0 == *(stp_right(p_mrchscheme->schmrchno)))
        {
                strscpy(p_mrchscheme->schmrchno,merchant_k.mrchno);
	}

	DBG_PRINTF((dbg_progdetail,"instcode:	<%s>",inst_k.instcode));
	DBG_PRINTF((dbg_progdetail,"mrchno:	<%s>",merchant_k.mrchno));
	DBG_PRINTF((dbg_progdetail,"scheme:	<%s>",p_mrchscheme->scheme));
	DBG_PRINTF((dbg_progdetail,"floorlim:	<%f>",p_mrchscheme->floorlim));
	DBG_PRINTF((dbg_progdetail,"msc:	<%f>",p_mrchscheme->msc));
	DBG_PRINTF((dbg_progdetail,"msc_intl:	<%f>",p_mrchscheme->msc_intl));
	DBG_PRINTF((dbg_progdetail,"crdacptbus:	<%d>",p_mrchscheme->crdacptbus));
	DBG_PRINTF((dbg_progdetail,"schmrchno:	<%s>",p_mrchscheme->schmrchno));

	if (SUCCEED == INSTgetbyINST_HASH_cache (&inst, &inst_k))
	{
		merchant_k.inst_id = inst.id;
		
		if (SUCCEED == MERCHANTgetbyMERCHANT_HASH (&merchant, &merchant_k))
			p_mrchscheme->merchant_id = merchant.id;
	}
		
	p_mrchscheme_k->merchant_id = p_mrchscheme->merchant_id;
	strscpy(p_mrchscheme_k->scheme, p_mrchscheme->scheme);

	return ret;
}
/*------------------------------------------------------------------------
 *
 * Function     : parse_termpos
 *
 * Purpose      : Fill in a termpos details record from the input
 *		  version of it.
 *
 * Parameters   : buf -> input record
 *		  p_termpos -> merchant details
 *		  p_termpos_k -> merchant key
 *
 * Returns      : SUCCEED
 *
 * Comments     : TR 4786 - Added for merchant import
 *
 *----------------------------------------------------------------------*/
ctxpublic int parse_termpos (char *buf, TERMPOS_t *p_termpos, UNQ_TERMPOS_TERMCODE_t *p_termpos_k)
{
	int ret = SUCCEED;
	char tmp[5];
	INST_t	inst;
	INST_HASH_t	inst_k;
	MERCHANT_t	merchant;
	MERCHANT_HASH_t	merchant_k;

	/*
	 * Initialise memory for our termpos record
	 */
	memset((char *)&inst, 0, sizeof(INST_t));
	memset((char *)&inst_k, 0, sizeof(INST_HASH_t));
	memset((char *)&merchant, 0, sizeof(MERCHANT_t));
	memset((char *)&merchant_k, 0, sizeof(MERCHANT_HASH_t));
	memset((char *)p_termpos, 0, sizeof(TERMPOS_t));
	memset((char *)p_termpos_k, 0, sizeof(UNQ_TERMPOS_TERMCODE_t));


	memcpy(tmp,			buf +  8, 4);
	tmp[4] = 0;
	p_termpos->typeid = atoi(tmp);
	memcpy(p_termpos->termcode,	buf + 12, 16);
	memcpy(tmp,			buf + 28, 1);
	tmp[1] = 0;
	p_termpos->testflag = atoi(tmp);
	memcpy(merchant_k.mrchno,	buf + 29, 15);
	memcpy(inst_k.instcode,	buf + 44, 4);
	memcpy(tmp,			buf + 48, 4);
	tmp[4] = 0;
	p_termpos->termno = atoi(tmp);
	memcpy(p_termpos->location, 	buf + 52, 30);

	DBG_PRINTF((dbg_progdetail,"typeid:	<%d>",p_termpos->typeid));
	DBG_PRINTF((dbg_progdetail,"termcode:	<%s>",p_termpos->termcode));
	DBG_PRINTF((dbg_progdetail,"testflag:	<%d>",p_termpos->testflag));
	DBG_PRINTF((dbg_progdetail,"mrchno:	<%s>",merchant_k.mrchno));
	DBG_PRINTF((dbg_progdetail,"instcode:	<%s>",inst_k.instcode));
	DBG_PRINTF((dbg_progdetail,"termno:	<%d>",p_termpos->termno));
	DBG_PRINTF((dbg_progdetail,"location:	<%s>",p_termpos->location));

	if (SUCCEED == INSTgetbyINST_HASH_cache (&inst, &inst_k))
	{
		merchant_k.inst_id = inst.id;
		
		if (SUCCEED == MERCHANTgetbyMERCHANT_HASH (&merchant, &merchant_k))
			p_termpos->merchant_id = merchant.id;
	}
	
	strscpy(p_termpos_k->termcode, p_termpos->termcode);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : parse_limits
 *
 * Purpose      : Fill in wither ACCLIMIT or CRDLIMIT depending on
 *		  the limit type of the record
 *
 * Parameters   : buf -> input record
 *		  p_acclimit -> ACCLIMIT details
 *		  p_acclimit_k -> ACCLIMIT key
 *		  p_crdlimit -> CRDLIMIT details
 *		  p_crdlimit_k -> CRDLIMIT key
 *
 * Returns      : SUCCEED
 *
 * Comments     : LM NMR010653 - Added for LIMITS import
 *
 *----------------------------------------------------------------------*/
ctxpublic int parse_limits (char *buf, ACCLIMIT_t *p_acclimit,
		ACCLIMIT_HASH_t *p_acclimit_k, CRDLIMIT_t *p_crdlimit,
			CRDLIMIT_HASH_t *p_crdlimit_k, short *limtype, ctxbool *dateset)
{
	int	ret = SUCCEED;
	char	tmp[13];
        Hdr *hp;
	char	*pan_enc;
	INST_t	inst;
	INST_HASH_t	inst_k;
	ACCDET_t	accdet;
	ACCDET_HASH_t	accdet_k;
	CRDDET_t	crddet;
	CRDDET_HASH_t	crddet_k;

        hp=parse_hdr (buf);

	memset((char *)&inst, 0, sizeof(INST_t));
	memset((char *)&inst_k, 0, sizeof(INST_HASH_t));
	memset((char *)&accdet, 0, sizeof(ACCDET_t));
	memset((char *)&accdet_k, 0, sizeof(ACCDET_HASH_t));
	memset((char *)&crddet, 0, sizeof(CRDDET_t));
	memset((char *)&crddet_k, 0, sizeof(CRDDET_HASH_t));

	/* Lets get the LIMIT type first as this will determine	*/
	/* what table we're adding to				*/
	memcpy (tmp, buf + 12, 2);
	tmp[2] = 0;
	*limtype = atoi(tmp);

	*dateset = FALSE;	 /*RJW NMR017200 20060826 */

	/* If its a Card Limit, just initialise the CRDLIMIT struct	*/
	if (LIMITS_CRD == *limtype)
	{
		/*
		* Initialise memory for acclimit record
		*/
		memset((char *)p_crdlimit, 0, sizeof(CRDLIMIT_t));
		memset((char *)p_crdlimit_k, 0, sizeof(CRDLIMIT_HASH_t));

		memcpy (inst_k.instcode, 	buf +  8, 4);
		memcpy (crddet_k.pan,	buf + 14, 28);
		memcpy (tmp,			buf + 42, 10);
		tmp[10] = 0;
		crddet_k.seqno = atoi(tmp);
		memcpy (tmp,			buf + 52, 3);
		tmp[3] = 0;
		p_crdlimit->cycle_len = atoi(tmp);
		memcpy (tmp,			buf + 55, 12);
		tmp[12] = 0;
		p_crdlimit->totlim_amt = atof(tmp);
		memcpy (tmp,			buf + 67, 12);
		tmp[12] = 0;
		p_crdlimit->cashlim_amt = atof(tmp);
		memcpy (tmp,			buf + 79, 12);
		tmp[12] = 0;
		p_crdlimit->purchlim_amt = atof(tmp);
		memcpy (tmp,			buf + 91, 4);
		tmp[4] = 0;
		p_crdlimit->totlim_num = atoi(tmp);
		memcpy (tmp,			buf + 95, 4);
		tmp[4] = 0;
		p_crdlimit->cashlim_num = atoi(tmp);
		memcpy (tmp,			buf + 99, 4);
		tmp[4] = 0;
		p_crdlimit->purchlim_num = atoi(tmp);

		/* HYPOM-1158 ZG 01.03.2007. Remove trailing spaces */
		stp_right(inst_k.instcode);
		stp_right(crddet_k.pan);

		/* sdods NMR023311, encrypt PAN */
		if( NULL == (pan_enc = encryptPan(crddet_k.pan, NULL)) )
			return FAIL;

		strcpy(crddet_k.pan, pan_enc);

		/*RJW NMR017200 20060826*/
		/*Record version (2) enables the cycle_begin date to be set*/
		p_crdlimit->cycle_begin =0;
		if (hp->ver > 1)
		{
			memcpy (tmp,		buf + 103, 8);
			tmp[8] =0;
			p_crdlimit->cycle_begin = atoi(tmp);
		}

		if (0 == p_crdlimit->cycle_begin)
		{
			p_crdlimit->cycle_begin = local_date();
		} else {
			/*Date specified in record*/
			*dateset = TRUE;
		}

		p_crdlimit->cash_amt_td = 0;
		p_crdlimit->cash_num_td = 0;
		p_crdlimit->purch_amt_td = 0;
		p_crdlimit->purch_num_td = 0;

		if (SUCCEED == CRDDETgetbyCRDDET_HASH (&crddet, &crddet_k))
			p_crdlimit_k->crddet_id = crddet.id;
		
		p_crdlimit_k->crddet_id = p_crdlimit->crddet_id;
		DBG_PRINTF((dbg_progdetail, "CRDLIMIT rec..."));
		DBG_PRINTF((dbg_progdetail,"instcode:	<%s>",
						inst_k.instcode));
		DBG_PRINTF((dbg_progdetail,"pan:	<%s>",
						crddet_k.pan));
		DBG_PRINTF((dbg_progdetail,"seqno:	<%hd>",
						crddet_k.seqno));
		DBG_PRINTF((dbg_progdetail,"cycle_len:	<%hd>",
						p_crdlimit->cycle_len));
		DBG_PRINTF((dbg_progdetail,"totlim_amt:	<%f>",
						p_crdlimit->totlim_amt));
		DBG_PRINTF((dbg_progdetail,"cashlim_amt: <%f>",
						p_crdlimit->cashlim_amt));
		DBG_PRINTF((dbg_progdetail,"purchlim_amt: <%f>",
						p_crdlimit->purchlim_amt));
		DBG_PRINTF((dbg_progdetail,"totlim_num:	<%d>",
						p_crdlimit->totlim_num));
		DBG_PRINTF((dbg_progdetail,"cashlim_num: <%d>",
						p_crdlimit->cashlim_num));
		DBG_PRINTF((dbg_progdetail,"purchlim_num: <%d>",
						p_crdlimit->purchlim_num));
		DBG_PRINTF((dbg_progdetail,"cycle_begin: <%ld>",
						p_crdlimit->cycle_begin)); /*RJW NMR017200 20060826*/
	}
	else if (LIMITS_ACC == *limtype)
	{
		/*
		* Initialise memory for acclimit record
		*/
		memset((char *)p_acclimit, 0, sizeof(ACCLIMIT_t));
		memset((char *)p_acclimit_k, 0, sizeof(ACCLIMIT_HASH_t));

		memcpy (inst_k.instcode, 	buf +  8, 4);
		memcpy (accdet_k.accno,	buf + 14, 28);
		memcpy (accdet_k.currcode,	buf + 42, 10);
		memcpy (tmp,			buf + 52, 3);
		tmp[3] = 0;
		p_acclimit->cycle_len = atoi(tmp);
		memcpy (tmp,			buf + 55, 12);
		tmp[12] = 0;
		p_acclimit->totlim_amt = atof(tmp);
		memcpy (tmp,			buf + 67, 12);
		tmp[12] = 0;
		p_acclimit->cashlim_amt = atof(tmp);
		memcpy (tmp,			buf + 79, 12);
		tmp[12] = 0;
		p_acclimit->purchlim_amt = atof(tmp);
		memcpy (tmp,			buf + 91, 4);
		tmp[4] = 0;
		p_acclimit->totlim_num = atoi(tmp);
		memcpy (tmp,			buf + 95, 4);
		tmp[4] = 0;
		p_acclimit->cashlim_num = atoi(tmp);
		memcpy (tmp,			buf + 99, 4);
		tmp[4] = 0;
		p_acclimit->purchlim_num = atoi(tmp);

		/* HYPOM-1158 ZG 01.03.2007. Remove trailing spaces */
		stp_right(inst_k.instcode);
		stp_right(accdet_k.accno);
		stp_right(accdet_k.currcode);

                /*RJW NMR017200 20060826*/
                /*Record version (2) enables the cycle_begin date to be set*/
                p_acclimit->cycle_begin =0;
                if (hp->ver > 1)
                {
                        memcpy (tmp,            buf + 103, 8);
                        tmp[8] =0;
                        p_acclimit->cycle_begin = atoi(tmp);
                }

                if (0 == p_acclimit->cycle_begin)
		{
                        p_acclimit->cycle_begin = local_date();
		} else {
			/*Date specified in record*/
			*dateset = TRUE;
		}

		p_acclimit->cash_amt_td = 0;
		p_acclimit->cash_num_td = 0;
		p_acclimit->purch_amt_td = 0;
		p_acclimit->purch_num_td = 0;

		if (SUCCEED == INSTgetbyINST_HASH_cache (&inst, &inst_k))
		{
			accdet_k.inst_id = inst.id;
			
			if (SUCCEED == ACCDETgetbyACCDET_HASH (&accdet, &accdet_k))
				p_acclimit->accdet_id = accdet.id;
		}
		
		p_acclimit_k->accdet_id = p_acclimit->accdet_id;

		DBG_PRINTF((dbg_progdetail, "ACCLIMIT rec..."));
		DBG_PRINTF((dbg_progdetail,"instcode:	<%s>",
						inst_k.instcode));
		DBG_PRINTF((dbg_progdetail,"accno:	<%s>",
						accdet_k.accno));
		DBG_PRINTF((dbg_progdetail,"currcode:	<%s>",
						accdet_k.currcode));
		DBG_PRINTF((dbg_progdetail,"cycle_len:	<%hd>",
						p_acclimit->cycle_len));
		DBG_PRINTF((dbg_progdetail,"totlim_amt:	<%f>",
						p_acclimit->totlim_amt));
		DBG_PRINTF((dbg_progdetail,"cashlim_amt: <%f>",
						p_acclimit->cashlim_amt));
		DBG_PRINTF((dbg_progdetail,"purchlim_amt: <%f>",
						p_acclimit->purchlim_amt));
		DBG_PRINTF((dbg_progdetail,"totlim_num:	<%d>",
						p_acclimit->totlim_num));
		DBG_PRINTF((dbg_progdetail,"cashlim_num: <%d>",
						p_acclimit->cashlim_num));
		DBG_PRINTF((dbg_progdetail,"purchlim_num: <%d>",
						p_acclimit->purchlim_num));
		DBG_PRINTF((dbg_progdetail,"cycle_begin: <%ld>",
						p_acclimit->cycle_begin)); /*RJW NMR017200 20060826*/
	}
	else
	{
		DBG_PRINTF((dbg_syserr, "Invalid LIMIT TYPE"));
		ret = FAIL;
	}


	return (ret);
}

/*------------------------------------------------------------------------
 *
 * Function     : parse_card_adddata
 *
 * Purpose      : parse line to populate card_adddata record
 *
 * Parameters   : char *: pointer to buffer (card additional data stdimp record)
 *                CRDDET_HASH_t *p_crddet_k pointer to crddet key fields
 *                card_adddata_t *p_card_adddata pointer card addition data
 *
 * Returns      : SUCCEED/FAIL
 *
 * Comments     : CN 8577
 *
 *      M_card_adddata_rec[] =
 *      {
 *              TYPEROW (n,   8, M,  1, "rechead"),      Record header
 *              TYPEROW (n,  19, M,  1, "pan" ),         Card serial number
 *              TYPEROW (n,   1, M,  1, "seqno"),        Card sequence number
 *              TYPEROW (n,   3, O,  1, "cvv2"),         CVV2 value
 *              0
 *      };
 *----------------------------------------------------------------------*/
ctxpublic int parse_card_adddata ( char            *buf,
                                CRDDET_HASH_t   *p_crddet_k,
                                card_adddata_t  *p_card_adddata)
{
        int ret = SUCCEED;
        char tmp[2];
	char	*pan_enc;

        memset ((char *)p_crddet_k, 0, sizeof (CRDDET_HASH_t));
        memset ((char *)p_card_adddata, 0, sizeof (card_adddata_t));

        memcpy(p_crddet_k->pan,         buf + 8, 19);
        memcpy(tmp,                     buf + 27, 1);
        tmp[1] = 0;
        p_crddet_k->seqno = atoi(tmp);
        memcpy(p_card_adddata->cvv2,    buf + 28, 3);

	/* sdods NMR023311, encrypt PAN */
	if( NULL == (pan_enc = encryptPan(p_crddet_k->pan, NULL)) )
		return FAIL;
	else
		strcpy(p_crddet_k->pan, pan_enc);

        DBG_PRINTF((dbg_progdetail,"pan:         <%s>",p_crddet_k->pan));
        DBG_PRINTF((dbg_progdetail,"seqno:       <%d>",p_crddet_k->seqno));
        DBG_PRINTF((dbg_progdetail,"cvv2:        <%s>",p_card_adddata->cvv2));

        return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : parse_postal_addr
 *
 * Purpose      : Fill in a postal address details record from the input
 *		  version of it.
 *
 * Parameters   : buf -> input record
 *		  p_p_addr -> postal address details
 *		  p_p_addr_k -> postal address key
 *		  p_prt_pcmp -> purpose party details
 *		  p_prt_person_k -> person key
 *
 * Returns      : SUCCEED
 *
 * Comments     : TR 4786 - Added for merchant import
 *
 *----------------------------------------------------------------------*/
ctxpublic int parse_postal_addr (char *buf, PRT_CM_P_ADDR_t *p_p_addr, 
								PRT_CM_P_ADDR_PK_t *p_p_addr_k,
								PRT_PCMP_t *p_prt_pcmp,
								UNQ_PRT_PERSON_CUSTDET_ID_t *p_prt_person_k)
{
	int ret = SUCCEED;
	INST_t	inst;
	INST_HASH_t	inst_k;
	CUSTDET_t	custdet;
	CUSTDET_HASH_t	custdet_k;
	PRT_CMT_PK_t prt_cmt_k;
	PRT_CMT_t prt_cmt;
	PRT_CMPT_PK_t prt_cmpt_k;
	PRT_CMPT_t prt_cmpt;
	UNQ_PRT_PERSON_CUSTDET_ID_t prt_person_k;
	char tmp[5];

	/*
	 * Initialise memory for our termpos record
	 */
	memset((char *)p_p_addr, 0, sizeof(PRT_CM_P_ADDR_t));
	memset((char *)p_p_addr_k, 0, sizeof(PRT_CM_P_ADDR_PK_t));
	memset((char *)p_prt_pcmp, 0, sizeof(PRT_PCMP_t));
	memset((char *)p_prt_person_k, 0, sizeof(UNQ_PRT_PERSON_CUSTDET_ID_t));
	memset((char *)&inst, 0, sizeof(INST_t));
	memset((char *)&inst_k, 0, sizeof(INST_HASH_t));
	memset((char *)&custdet, 0, sizeof(CUSTDET_t));
	memset((char *)&custdet_k, 0, sizeof(CUSTDET_HASH_t));
	memset((char *)&prt_cmt, 0, sizeof(PRT_CMT_t));
	memset((char *)&prt_cmt_k, 0, sizeof(PRT_CMT_PK_t));
	memset((char *)&prt_cmpt, 0, sizeof(PRT_CMPT_t));
	memset((char *)&prt_cmpt_k, 0, sizeof(PRT_CMPT_PK_t));

	memcpy(inst_k.instcode,			buf +  8, 4);
	memcpy(custdet_k.custcode,		buf +  12, 12);
	memcpy(tmp,	buf +  24, 4);
	tmp[4] = 0;
	prt_cmpt_k.id = atoi(tmp);
	memcpy(tmp,	buf +  28, 4);
	tmp[4] = 0;
	prt_cmt_k.id = atoi(tmp);
	memcpy(p_p_addr->address_1,		buf +  32, 40);
	memcpy(p_p_addr->address_2,		buf +  72, 40);
	memcpy(p_p_addr->address_3,		buf +  112, 40);
	memcpy(p_p_addr->address_4,		buf +  152, 40);
	memcpy(p_p_addr->address_5,		buf +  192, 40);
	memcpy(p_p_addr->directions,	buf +  232, 255);
	memcpy(p_p_addr->city,			buf +  487, 40);
	memcpy(p_p_addr->postal_code,	buf +  527, 10);
	memcpy(p_p_addr->country_isocode,	buf +  537, 3);
	memcpy(p_p_addr->province,	buf +  540, 40);
	memcpy(p_p_addr->ctxterritory,	buf +  580, 40);
	memcpy(p_p_addr->ctxstate,	buf +  620, 40);
	memcpy(p_p_addr->county,	buf +  660, 40);
	memcpy(p_p_addr->region,	buf +  700, 40);	

	DBG_PRINTF((dbg_progdetail,"instcode:			<%s>",inst_k.instcode));
	DBG_PRINTF((dbg_progdetail,"custcode:			<%s>",custdet_k.custcode));
	DBG_PRINTF((dbg_progdetail,"contact_purpose:	<%hd>",prt_cmpt_k.id));
	DBG_PRINTF((dbg_progdetail,"contact_type:		<%hd>",prt_cmt_k.id));
	DBG_PRINTF((dbg_progdetail,"address_1:			<%s>",p_p_addr->address_1));
	DBG_PRINTF((dbg_progdetail,"address_2:			<%s>",p_p_addr->address_2));
	DBG_PRINTF((dbg_progdetail,"address_3:			<%s>",p_p_addr->address_3));
	DBG_PRINTF((dbg_progdetail,"address_4:			<%s>",p_p_addr->address_4));
	DBG_PRINTF((dbg_progdetail,"address_5:			<%s>",p_p_addr->address_5));
	DBG_PRINTF((dbg_progdetail,"directions:			<%s>",p_p_addr->directions));
	DBG_PRINTF((dbg_progdetail,"city:				<%s>",p_p_addr->city));
	DBG_PRINTF((dbg_progdetail,"postal_code:		<%s>",p_p_addr->postal_code));
	DBG_PRINTF((dbg_progdetail,"country_isocode:	<%s>",p_p_addr->country_isocode));
	DBG_PRINTF((dbg_progdetail,"province:			<%s>",p_p_addr->province));
	DBG_PRINTF((dbg_progdetail,"ctxterritory:		<%s>",p_p_addr->ctxterritory));
	DBG_PRINTF((dbg_progdetail,"ctxstate:				<%s>",p_p_addr->ctxstate));
	DBG_PRINTF((dbg_progdetail,"county:				<%s>",p_p_addr->county));
	DBG_PRINTF((dbg_progdetail,"region:				<%s>",p_p_addr->region));

	if (SUCCEED != (ret = INSTgetbyINST_HASH_cache (&inst, &inst_k)))
		DBG_PRINTF((dbg_syserr,"Failed to get Inst for %s",
					inst_k.instcode));
	else
		custdet_k.inst_id = inst.id;
	
	if (SUCCEED == ret &&
		SUCCEED != (ret = CUSTDETgetbyCUSTDET_HASH (&custdet, &custdet_k)))
		DBG_PRINTF((dbg_syserr,"Failed to get Custdet for %s",
						custdet_k.custcode));
	else
		p_prt_person_k->custdet_id = custdet.id;
		
	if (SUCCEED == ret &&
		SUCCEED != (ret = PRT_CMTgetbyPRT_CMT_PK(&prt_cmt, &prt_cmt_k)))
		DBG_PRINTF((dbg_syserr,"Failed to get contact type for %hd",
					prt_cmt_k.id));
	else
	{
		p_p_addr->prt_cmt_id = prt_cmt.id;
		p_prt_pcmp->prt_cmt_id = prt_cmt.id;
	}
		
	if (SUCCEED == ret &&
		SUCCEED != (ret = PRT_CMPTgetbyPRT_CMPT_PK(&prt_cmpt, &prt_cmpt_k)))
		DBG_PRINTF((dbg_syserr,"Failed to get contact propuse type for %hd",
					prt_cmpt_k.id));
	else
	{
		p_prt_pcmp->prt_cmpt_id = prt_cmpt.id;
	}
		
	p_p_addr_k->prt_cmt_id = p_p_addr->prt_cmt_id;
	
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : parse_electro_addr
 *
 * Purpose      : Fill in a electronic address details record from the input
 *		  version of it.
 *
 * Parameters   : buf -> input record
 *		  p_e_addr -> electronic address details
 *		  p_e_addr_k -> electronic address key
 *		  p_prt_pcmp -> purpose party details
 *		  p_prt_person_k -> person key
 *
 * Returns      : SUCCEED
 *
 * Comments     : TR 4786 - Added for merchant import
 *
 *----------------------------------------------------------------------*/
ctxpublic int parse_electro_addr (char *buf, PRT_CM_E_ADDR_t *p_e_addr, 
								PRT_CM_E_ADDR_PK_t *p_e_addr_k,
								PRT_PCMP_t *p_prt_pcmp,
								UNQ_PRT_PERSON_CUSTDET_ID_t *p_prt_person_k)
{
	int ret = SUCCEED;
	INST_t	inst;
	INST_HASH_t	inst_k;
	CUSTDET_t	custdet;
	CUSTDET_HASH_t	custdet_k;
	PRT_CMT_PK_t prt_cmt_k;
	PRT_CMT_t prt_cmt;
	PRT_CMPT_PK_t prt_cmpt_k;
	PRT_CMPT_t prt_cmpt;
	UNQ_PRT_PERSON_CUSTDET_ID_t prt_person_k;
	char tmp[5];

	/*
	 * Initialise memory for our termpos record
	 */
	memset((char *)p_e_addr, 0, sizeof(PRT_CM_E_ADDR_t));
	memset((char *)p_e_addr_k, 0, sizeof(PRT_CM_E_ADDR_PK_t));
	memset((char *)p_prt_pcmp, 0, sizeof(PRT_PCMP_t));
	memset((char *)p_prt_person_k, 0, sizeof(UNQ_PRT_PERSON_CUSTDET_ID_t));
	memset((char *)&inst, 0, sizeof(INST_t));
	memset((char *)&inst_k, 0, sizeof(INST_HASH_t));
	memset((char *)&custdet, 0, sizeof(CUSTDET_t));
	memset((char *)&custdet_k, 0, sizeof(CUSTDET_HASH_t));
	memset((char *)&prt_cmt, 0, sizeof(PRT_CMT_t));
	memset((char *)&prt_cmt_k, 0, sizeof(PRT_CMT_PK_t));
	memset((char *)&prt_cmpt, 0, sizeof(PRT_CMPT_t));
	memset((char *)&prt_cmpt_k, 0, sizeof(PRT_CMPT_PK_t));

	memcpy(inst_k.instcode,			buf +  8, 4);
	memcpy(custdet_k.custcode,		buf +  12, 12);
	memcpy(tmp,	buf +  24, 4);
	tmp[4] = 0;
	prt_cmpt_k.id = atoi(tmp);
	memcpy(tmp,	buf +  28, 4);
	tmp[4] = 0;
	prt_cmt_k.id = atoi(tmp);
	memcpy(p_e_addr->electronic_address,		buf +  32, 100);

	DBG_PRINTF((dbg_progdetail,"instcode:			<%s>",inst_k.instcode));
	DBG_PRINTF((dbg_progdetail,"custcode:			<%s>",custdet_k.custcode));
	DBG_PRINTF((dbg_progdetail,"contact_purpose:	<%hd>",prt_cmpt_k.id));
	DBG_PRINTF((dbg_progdetail,"contact_type:		<%hd>",prt_cmt_k.id));
	DBG_PRINTF((dbg_progdetail,"electronic_address:	<%s>",p_e_addr->electronic_address));

	if (SUCCEED != (ret = INSTgetbyINST_HASH_cache (&inst, &inst_k)))
		DBG_PRINTF((dbg_syserr,"Failed to get Inst for %s",
					inst_k.instcode));
	else
		custdet_k.inst_id = inst.id;
	
	if (SUCCEED == ret &&
		SUCCEED != (ret = CUSTDETgetbyCUSTDET_HASH (&custdet, &custdet_k)))
		DBG_PRINTF((dbg_syserr,"Failed to get Custdet for %s",
						custdet_k.custcode));
	else
		p_prt_person_k->custdet_id = custdet.id;
	
	if (SUCCEED == ret &&
		SUCCEED != (ret = PRT_CMTgetbyPRT_CMT_PK(&prt_cmt, &prt_cmt_k)))
		DBG_PRINTF((dbg_syserr,"Failed to get contact type for %hd",
					prt_cmt_k.id));
	else
	{
		p_e_addr->prt_cmt_id = prt_cmt.id;
		p_prt_pcmp->prt_cmt_id = prt_cmt.id;
	}
		
	if (SUCCEED == ret &&
		SUCCEED != (ret = PRT_CMPTgetbyPRT_CMPT_PK(&prt_cmpt, &prt_cmpt_k)))
		DBG_PRINTF((dbg_syserr,"Failed to get contact propuse type for %hd",
					prt_cmpt_k.id));
	else
	{
		p_prt_pcmp->prt_cmpt_id = prt_cmpt.id;
	}
		
	p_e_addr_k->prt_cmt_id = p_e_addr->prt_cmt_id;
	
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : parse_telco
 *
 * Purpose      : Fill in a telecommunication address details record from the input
 *		  version of it.
 *
 * Parameters   : buf -> input record
 *		  p_cm_telco -> telecommunication address details
 *		  p_cm_telco_k -> telecommunication address key
 *		  p_prt_pcmp -> purpose party details
 *		  p_prt_person_k -> person key
 *
 * Returns      : SUCCEED
 *
 * Comments     : TR 4786 - Added for merchant import
 *
 *----------------------------------------------------------------------*/
ctxpublic int parse_telco (char *buf, PRT_CM_TELCO_NO_t *p_cm_telco, 
								PRT_CM_TELCO_NO_PK_t *p_cm_telco_k,
								PRT_PCMP_t *p_prt_pcmp,
								UNQ_PRT_PERSON_CUSTDET_ID_t *p_prt_person_k)
{
	int ret = SUCCEED;
	INST_t	inst;
	INST_HASH_t	inst_k;
	CUSTDET_t	custdet;
	CUSTDET_HASH_t	custdet_k;
	PRT_CMT_PK_t prt_cmt_k;
	PRT_CMT_t prt_cmt;
	PRT_CMPT_PK_t prt_cmpt_k;
	PRT_CMPT_t prt_cmpt;
	UNQ_PRT_PERSON_CUSTDET_ID_t prt_person_k;
	char tmp[5];

	/*
	 * Initialise memory for our termpos record
	 */
	memset((char *)p_cm_telco, 0, sizeof(PRT_CM_TELCO_NO_t));
	memset((char *)p_cm_telco_k, 0, sizeof(PRT_CM_TELCO_NO_PK_t));
	memset((char *)p_prt_pcmp, 0, sizeof(PRT_PCMP_t));
	memset((char *)p_prt_person_k, 0, sizeof(UNQ_PRT_PERSON_CUSTDET_ID_t));
	memset((char *)&inst, 0, sizeof(INST_t));
	memset((char *)&inst_k, 0, sizeof(INST_HASH_t));
	memset((char *)&custdet, 0, sizeof(CUSTDET_t));
	memset((char *)&custdet_k, 0, sizeof(CUSTDET_HASH_t));
	memset((char *)&prt_cmt, 0, sizeof(PRT_CMT_t));
	memset((char *)&prt_cmt_k, 0, sizeof(PRT_CMT_PK_t));
	memset((char *)&prt_cmpt, 0, sizeof(PRT_CMPT_t));
	memset((char *)&prt_cmpt_k, 0, sizeof(PRT_CMPT_PK_t));

	memcpy(inst_k.instcode,			buf +  8, 4);
	memcpy(custdet_k.custcode,		buf +  12, 12);
	memcpy(tmp,	buf +  24, 4);
	tmp[4] = 0;
	prt_cmpt_k.id = atoi(tmp);
	memcpy(tmp,	buf +  28, 4);
	tmp[4] = 0;
	prt_cmt_k.id = atoi(tmp);
	memcpy(p_cm_telco->area_code,		buf +  32, 10);
	memcpy(p_cm_telco->contact_no,		buf +  42, 13);
	memcpy(p_cm_telco->extension_no,		buf +  55, 10);
	memcpy(p_cm_telco->country_prefix,		buf +  65, 3);

	DBG_PRINTF((dbg_progdetail,"instcode:			<%s>",inst_k.instcode));
	DBG_PRINTF((dbg_progdetail,"custcode:			<%s>",custdet_k.custcode));
	DBG_PRINTF((dbg_progdetail,"contact_purpose:	<%hd>",prt_cmpt_k.id));
	DBG_PRINTF((dbg_progdetail,"contact_type:		<%hd>",prt_cmt_k.id));
	DBG_PRINTF((dbg_progdetail,"area_code:			<%ld>",p_cm_telco->area_code));
	DBG_PRINTF((dbg_progdetail,"contact_no:			<%ld>",p_cm_telco->contact_no));
	DBG_PRINTF((dbg_progdetail,"extension_no:		<%ld>",p_cm_telco->extension_no));
	DBG_PRINTF((dbg_progdetail,"country_prefix:		<%d>",p_cm_telco->country_prefix));

	if (SUCCEED != (ret = INSTgetbyINST_HASH_cache (&inst, &inst_k)))
		DBG_PRINTF((dbg_syserr,"Failed to get Inst for %s",
					inst_k.instcode));
	else
		custdet_k.inst_id = inst.id;
	
	if (SUCCEED == ret &&
		SUCCEED != (ret = CUSTDETgetbyCUSTDET_HASH (&custdet, &custdet_k)))
		DBG_PRINTF((dbg_syserr,"Failed to get Custdet for %s",
						custdet_k.custcode));
	else
		p_prt_person_k->custdet_id = custdet.id;
		
	if (SUCCEED == ret &&
		SUCCEED != (ret = PRT_CMTgetbyPRT_CMT_PK(&prt_cmt, &prt_cmt_k)))
		DBG_PRINTF((dbg_syserr,"Failed to get contact type for %hd",
					prt_cmt_k.id));
	else
	{
		p_cm_telco->prt_cmt_id = prt_cmt.id;
		p_prt_pcmp->prt_cmt_id = prt_cmt.id;
	}
		
	if (SUCCEED == ret &&
		SUCCEED != (ret = PRT_CMPTgetbyPRT_CMPT_PK(&prt_cmpt, &prt_cmpt_k)))
		DBG_PRINTF((dbg_syserr,"Failed to get contact propuse type for %hd",
					prt_cmpt_k.id));
	else
	{
		p_prt_pcmp->prt_cmpt_id = prt_cmpt.id;
	}
		
	p_cm_telco_k->prt_cmt_id = p_cm_telco->prt_cmt_id;
	
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  calc_next_stmtdate
 *
 * Purpose      :
 *
 * Parameters   :  cycle, code for statement cycle
 *
 * Returns      :  long, date of next statement
 *
 * Comments     :
 *
 *------------------------------------------------------------------------*/
ctxprivate long calc_next_stmtdate (int cycle)
{
	long ret = 0;
	int day = 0;
	int month = 0;
	int year = 0;

	day = G_sysdate % 100;
	month = (G_sysdate % 10000) / 100;
	year = G_sysdate / 10000;

	DBG_PRINTF((dbg_progdetail,"Statement Cycle <%d>",cycle));

	if (day > 28)
	{
		day = 1;
		month++;
		if (month > 12)
		{
		        year++;
		        month = 1;
		}
	}

	if (cycle == 0)
		ret = 22630831;
	else if (cycle == 15)
	{
		if(day < 15)
		{
		        day = 15;
		}
		else
		{
		        day = 1;
		        month++;
		        if(month > 12)
		        {
		                year++;
		                month = 1;
		        }
		}
	}
	else  /**** cycle must be 30, 60 or 90 ****/
	{
		month += cycle/30;
		if(month > 12)
		{
		        year++;
		        month -= 12;
		}
	}

	if (ret == 0)
		ret = (year*10000) + (month*100) + (day);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  create_expdate
 *
 * Purpose      :  Converts date to be the current month plus the
 *                 number of months specified in validity and the last day of
 *		   the month
 *                 in YYYYMMDD numeric.
 *
 * Parameters   :  p_expdate_num - pointer to converted date (output)
 *                 validity - number to increment by
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :
 *
 *------------------------------------------------------------------------*/
ctxprivate int     create_expdate( long effdate_num, long *p_expdate_num,
				int validity )
{
        int     ret = SUCCEED;
        long    year, month, day;
        char    *thisfn = "create_expdate";
        char    date_str[9];

        DBG_PRINTF((dbg_progdetail, "Entered %s", thisfn));

        sprintf(date_str, "%ld", effdate_num);

        DBG_PRINTF((dbg_progdetail, "%s:date is <%s>, validity %d",
                        thisfn, date_str, validity));

        if( 1 != sscanf(date_str,"%4ld",&year) )
        {
		sprintf(ERROR_VAR, "Error extracting year from date:");
                DBG_PRINTF((dbg_syserr, "%s:Error extracting year from date",
                                thisfn));
                ret = FAIL;
        }

        if( FAIL != ret && 1 != sscanf(date_str+4,"%2ld",&month) )
        {
		sprintf(ERROR_VAR, "Error extracting month from date:");
                DBG_PRINTF((dbg_syserr, "%s:Error extracting month from date",
                                 thisfn));
                ret = FAIL;
        }

        /*-------------------------------------------------*/
        /* Increment month by value in crdformat.validity  */
        /* and set day to the first of the following month */
        /*-------------------------------------------------*/
        validity++;
        year += validity / 12;
        month += validity % 12;

        if( FAIL != ret )
        {
                *p_expdate_num = 10000*year + 100*month + 01;

                /*------------------------------------------------------*/
                /* Subtracting one from expdate to make it the last day */
		/* of the last month 					*/
                /*------------------------------------------------------*/
                if (FAIL == (*p_expdate_num = date_plus(*p_expdate_num, -1) ) )
                {
			sprintf(ERROR_VAR, "Error subtracting day from %ld:", *p_expdate_num);
                        DBG_PRINTF((dbg_syserr, "Error subtracting day from "
                                        "%ld", *p_expdate_num));
                        ret = FAIL;
                }
        }

        DBG_PRINTF((ret == FAIL ? dbg_syserr : dbg_progdetail,
                        "%s:ret: %d  Date: <%s> converted date: %08ld",
                        thisfn, ret, date_str, *p_expdate_num ));

        DBG_PRINTF((dbg_progdetail, "Leaving %s", thisfn));

        return( ret );
}
/*------------------------------------------------------------------------
 *
 * Function     : set_dftchgcyc
 *
 * Purpose      : set the M_chgcycle variable with the config value
 *
 * Parameters   : string containing the config value
 *
 * Returns      :
 *
 * Comments     : AS added Job 4558
 *
 *----------------------------------------------------------------------*/

ctxpublic void set_dftchgcyc( char *chgcle  )
{
	strscpy( M_chgcycle, chgcle );
}

/*------------------------------------------------------------------------
 *
 * Function     : set_dftchgcyc
 *
 * Purpose      : set the M_acctypelim variable with the config value
 *
 * Parameters   : string containing the config value
 *
 * Returns      :
 *
 * Comments     : AS added job 4558
 *
 *----------------------------------------------------------------------*/

ctxpublic void set_dftacctl( char *atl  )
{
	strscpy( M_acctypelim, atl );
}

/*------------------------------------------------------------------------
 *
 * Function     : parse_corp_flds
 *
 * Purpose      : Get corporate card fields from card import record
 *
 * Parameters   : buf           - input record
 *                p_corpflds    - returned fields info
 *
 * Returns      : SUCCEED
 *
 * Comments     : NMR011193 WLi 20/4/2004
 *
 *----------------------------------------------------------------------*/
ctxpublic int parse_corp_flds(char *buf, corp_crd_flds_t *p_corpflds)
{
        int     ret=SUCCEED;
        Hdr             *hp;
        crdrec_t        *p_crdrec=(crdrec_t*)buf;
        char    tmp[20];
	char *pan_enc;

        hp=parse_hdr(buf);

        /* Initialise memory for our accdet record to be copied into */
        memset((char *)p_corpflds, 0, sizeof(corp_crd_flds_t));
        p_corpflds->corpflag=CARD_CORP_NORMAL;
        if (hp->ver>2)
        {
                p_corpflds->corpflag=p_crdrec->corp[0];
                memcpy(p_corpflds->corppan, p_crdrec->corppan,
                                        sizeof(p_crdrec->corppan));
                stp_right(p_corpflds->corppan);

		/* sdods PCI DSS, NMR023311, encrypt PAN */
		if( NULL == (pan_enc = encryptPan(p_corpflds->corppan, NULL)) )
			return FAIL;
		else
			strcpy(p_corpflds->corppan, pan_enc);

                p_corpflds->corpseq=(short)(p_crdrec->corpseq[0]-'0');
                memcpy(p_corpflds->corpcust, p_crdrec->corpcust,
                                        sizeof(p_crdrec->corpcust));
                stp_right(p_corpflds->corpcust);
        }

        return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : verify_number
 *
 * Purpose      : Verify a string is a number
 *
 * Parameters   : str           - input string
 *                int    - returned result
 *
 * Returns      : SUCCEED
 *
 * Comments     : 
 *
 *----------------------------------------------------------------------*/
ctxprivate int verify_number(char *str)
{
	int ret = SUCCEED, i = 0;
	
	for(i = 0; i < strlen(str); i++)
	{
		if(str[i] < '0' || str[i] > '9')
		{
			DBG_PRINTF((dbg_syserr, "The caracter %c of the position %d "
						"is not correct", str[i], i));
			ret = FAIL;
		}
	}
}

/*------------------------------------------------------------------------
 *
 * Function     : verify_telnumber
 *
 * Purpose      : Verify a string is a tel number
 *
 * Parameters   : str           - input string
 *                int    - returned result
 *
 * Returns      : SUCCEED
 *
 * Comments     : 
 *
 *----------------------------------------------------------------------*/
ctxprivate int verify_telnumber(char *str)
{
	int ret = SUCCEED, i = 0;
	
	for(i = 0; i < strlen(str); i++)
	{
		if((str[i] < '0' || str[i] > '9') && 
			str[i] != ' ' && str[i] != '+' && str[i] != '-')
		{
			DBG_PRINTF((dbg_syserr, "The caracter %c of the position %d "
						"is not correct", str[i], i));
			ret = FAIL;
		}
	}
}

/*------------------------------------------------------------------------
 *
 * Function     : verify_email
 *
 * Purpose      : Verify a string is an email
 *
 * Parameters   : str           - input string
 *                int    - returned result
 *
 * Returns      : SUCCEED
 *
 * Comments     : 
 *
 *----------------------------------------------------------------------*/
ctxprivate int verify_email(char *str)
{
	int ret = SUCCEED, i = 0;
	char *ptr, at_char = '@', dot_char = '.'; 

	if(!(ptr = strchr(str, at_char)))
	{
		DBG_PRINTF((dbg_syserr, "The format of the email: %s"
					"is not correct", str));
		ret = FAIL;
	}
	
	if (SUCCEED == ret && 
		(!(ptr = strchr(ptr, dot_char))
		|| (ptr = strchr(ptr, at_char))))
	{
		DBG_PRINTF((dbg_syserr, "The format of the email: %s"
					"is not correct", str));
		ret = FAIL;
	}
}
