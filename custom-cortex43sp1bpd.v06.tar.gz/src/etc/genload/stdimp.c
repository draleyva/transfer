/*-----------------------------------------------------------------------
 *
 * File		: stdimp.ec
 *
 * Author	: Graeme Thomas
 *
 * Created	: 1998-11-05
 *
 * Purpose	: Standard import
 *
 * Comments	:
 *
 * Ident	: $Id$
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#define ALLOC
#include "constant.h"
#include "parse.h"
#include "function.h"
#include "slplck.h"

/*---------------------------Externs------------------------------------*/
extern ctxpublic void set_crdbtchusr(char *crdbtchusr);
/*---------------------------Macros-------------------------------------*/
#define	TAGNM	"GENLD"
#define MAXNUMCARD_TAG "maxnumcard"

/* HYPOM-1121 ZG 16.02.2007. */
#define	EVTAG_SDIPARSEFAIL	"sdiparsefail"
#define	EVTAG_SDIPRMECFAIL	"sdiprmecfail"

/*---------------------------Enums--------------------------------------*/
/* HYPOM-1121 ZG 16.02.2007. */
enum
{
	ERRTYPE_PARSE,	/* Parsing error				*/
	ERRTYPE_PRMEC 	/* Processing error: max error count exceeded	*/
};

/*---------------------------Typedefs-----------------------------------*/
typedef struct {
	int act;
	int type;
	int (*f) (char *, long);
} func_tab_t;

/*---------------------------Globals------------------------------------*/

/* NMR013950 - Descriptive error messages for the macros defined in constant.h */
ctxprivate char *G_err_descr[] = {
	/* ERR_ERROR		0 */	"Error occured",
	/* ERR_DUPLICATE	1 */	"Duplicate record",
	/* ERR_NOTFOUND		2 */	"Record not found",
	/* ERR_DB		3 */	"Database error",
	/* ERR_PARSE		4 */	"Parsing error",
        /* ERR_CONSTR           5 */    "Constraint error",
};

/* HYPOM-1121 ZG 20.02.2007. */
ctxprivate char *G_err_pattern[] = {
	/* E_DUPLICATE	*/	"Duplicate %s record (%s)",
	/* E_NOTFOUND	*/	"%s record not found (%s)",
	/* E_PARSE	*/	"Failed to copy %s record from buffer (%s)",
	/* E_DELETE	*/	"Failed to delete %s record (%s)",
        /* E_CONSTRAINT */      "Constraint Error with %s record (%s)",
        /* E_ERROR      */      "Unexpected Error with %s record (%s)",
};

/*---------------------------Statics------------------------------------*/
ctxprivate char rcsid[] = "$Id$";

ctxprivate int M_record_sets[MAX_ACT];

ctxprivate int M_commit_rec_cnt = 0;
ctxprivate int M_abort_rec_cnt = 0;
ctxprivate int M_commit_set_cnt = 0;
ctxprivate int M_abort_set_cnt = 0;

ctxprivate FILE *M_f = NULL;
ctxprivate char M_infile[CTX_FILENAME_MAX];

ctxprivate char    M_dbgfile[CTX_FILENAME_MAX] = "";
ctxprivate int M_recbeforeset = 0;		/* number of last record processed,
					   before, we began current group*/

ctxprivate int M_startrec;			/* record number on which to
					   begin processing from 	*/


ctxprivate int M_max_err = 10;		/* Max num of errors, 10 is default */
ctxprivate int M_dbglev = 5;		/* default debug level of 5 */ 
ctxprivate int M_dbgbuf = 0;		/* default buffer of 0 (screen) */
ctxprivate ctxbool M_allowDifferentBranches = FALSE;
ctxprivate char M_subsect[1024] = "";	/* Subsection of config file    */
ctxprivate long M_batchprinc = -1;

ctxprivate func_tab_t M_proc_func[]= 	{
	{ACT_HDR,       TYPE_HDR,     0},
	{ACT_ADD,       TYPE_CUST,    pr_add_cust},
	{ACT_ADD,       TYPE_ACC,     pr_add_acc},
	{ACT_ADD,       TYPE_CRD,     pr_add_card},
	{ACT_ADD,       TYPE_CRDACC,  pr_add_crdacc},
	{ACT_AMEND,     TYPE_CUST,    pr_amend_cust},
	{ACT_AMEND,     TYPE_ACC,     pr_amend_acc},
	{ACT_AMEND,     TYPE_CRD,     pr_amend_card},
	{ACT_DEL,       TYPE_CUST,    pr_del_cust},
	{ACT_DEL,       TYPE_ACC,     pr_del_acc},
	{ACT_DEL,       TYPE_CRD,     pr_del_card},
	{ACT_DEL,       TYPE_CRDACC,  pr_del_crdacc},
	{ACT_ACCADD,    TYPE_ACC,     pr_account_add},
	{ACT_ASSOC_ADD, TYPE_CRD,     pr_add_assoc_card}, /* Bug 4647 */ 
	{ACT_REISS_CRD, TYPE_CRD,     pr_reiss_card},
	{ACT_REP_LOST,  TYPE_CRD,     pr_rep_lost},
	{ACT_REP_FRAUD, TYPE_CRD,     pr_rep_fraud},
	{ACT_REN_CRD,   TYPE_CRD,     pr_ren_card},
	{ACT_REISS_PIN, TYPE_CRD,     pr_reiss_PIN},
	{ACT_CRDAPPL,   TYPE_CUST,    pr_card_appl},
	{ACT_CRDAPPL,   TYPE_ACC,     pr_card_appl},
	{ACT_CRDAPPL,   TYPE_CRD,     pr_card_appl},
	{ACT_CRDAPPL,   TYPE_CRDAPPL, pr_card_appl},
	{ACT_NEW_CRD,   TYPE_CUST,    pr_new_card},
	{ACT_NEW_CRD,   TYPE_ACC,     pr_new_card},
	{ACT_NEW_CRD,   TYPE_CRD,     pr_new_card},
	{ACT_NEW_CRD,   TYPE_POSTALADDR, pr_new_card},
	{ACT_NEW_CRD,   TYPE_ELECTROADDR, pr_new_card},
	{ACT_NEW_CRD,   TYPE_TELCO,   pr_new_card},
	{ACT_TRL,       TYPE_TRL,     pr_file_trailer},

	/* TR 4786 - New functions for merchant import */
	{ACT_ADD,	TYPE_MERCHANT,		pr_add_merchant},
	{ACT_ADD,	TYPE_MRCHSCHEME,	pr_add_mrchscheme},
	{ACT_ADD,	TYPE_TERMPOS,		pr_add_termpos},
	{ACT_AMEND,	TYPE_MERCHANT,		pr_amend_merchant},
	{ACT_AMEND,	TYPE_MRCHSCHEME,	pr_amend_mrchscheme},
	{ACT_AMEND,	TYPE_TERMPOS,		pr_amend_termpos},
	{ACT_DEL,	TYPE_MERCHANT,		pr_del_merchant},
	{ACT_DEL,	TYPE_MRCHSCHEME,	pr_del_mrchscheme},
	{ACT_DEL,	TYPE_TERMPOS,		pr_del_termpos},
	/* LMM - New functions for the ACCLIMIT record type	*/
	{ACT_ADD,	TYPE_LIMITS,		pr_add_limits},
	{ACT_AMEND,	TYPE_LIMITS,		pr_amend_limits},
	{ACT_DEL,	TYPE_LIMITS,		pr_del_limits},
	/* Additional Address */
	/* New recs for Postal Address records	*/
	{ ACT_ADD,	TYPE_POSTALADDR, 	pr_add_postal_addr},
	{ ACT_DEL,	TYPE_POSTALADDR,	pr_del_postal_addr},
	/* New recs for Electronic Address records	*/
	{ ACT_ADD,	TYPE_ELECTROADDR, 	pr_add_electro_addr},
	{ ACT_DEL,	TYPE_ELECTROADDR,	pr_del_electro_addr},
	/* New recs for Telco records	*/
	{ ACT_ADD,	TYPE_TELCO, 	pr_add_telco},
	{ ACT_DEL,	TYPE_TELCO,	pr_del_telco},
	{-1,            -1,           0}
};

/*---------------------------Prototypes---------------------------------*/
ctxprivate int  init (int argc, char **argv);
ctxprivate int  init_pins (char *pins);
ctxprivate void init_record_sets (void);
ctxprivate int  init_stmts (char *stmts);
ctxprivate int  parse_csv (char *buf, char *sep, char ***parray, int *pcount);
ctxprivate int  uninit (void);
ctxprivate int  map_funct (char *buf, long rec_cnt);
ctxprivate int  process_rec (char* buf, long rec_cnt);
ctxprivate int  loop_process (long *rcp);
ctxprivate int process_set (char_array_t *set, char_array_t *cap, long *rcp);
/* 13971 - additional card can belong to different branch */
ctxpublic ctxbool allowDifferentBranches (void);
/* HYPOM-1121 ZG 16.02.2007. */
ctxprivate int log_ev_fail(int errtype);

/* proc_lock() is in bgco/core/coproc.c to prevent concurrency problems */
/* Added for NMR 3193 by M.Davey 20 Mar 2000                            */
ctxpublic	int	proc_lock (char *file, int mode);

/*---------------------------Functions----------------------------------*/
/*------------------------------------------------------------------------
 *
 * Function     :  main
 *
 * Purpose      :  Start point of program execution
 *
 * Parameters   :  argc -> number of arguments passed on the command line
 *		   argv -> command line arguments in string form.
 *
 * Returns      :  program exit state (0 = normal termination)
 *
 * Comments     :
 *
 *----------------------------------------------------------------------*/
ctxpublic int main (int argc, char ** argv)
{
   	int  ret;
	long rec_cnt = 0;
	
	char	lockfile[]="stdimp.lock"; /* Name of lock file to lock */
		                            /* process with proc_lock()  */
	ctxbool	process_locked = FALSE;    /* TRUE if locked the process */

	static  ctxbool    force_process = FALSE; /* if set to true, file will be*/
                                       /* processed even if duplicate */

	ret = init (argc, argv);

	/*
	 * Check if tuxedo is up and running
	 * If not then report a fatal error
	 */
	if (SUCCEED == ret)
	{
       		ret = clt_basic_init ("vi", "B2IMP");

        	if (SUCCEED != ret)
        	{
        	    DBG_PRINTF((dbg_fatal, "Cannot init Tuxedo"));
        	}
	}
	
	/* Call proc_lock() in coproc.c to lock the process */
	if (SUCCEED==ret)	/* NMR010607 WLi 08/1/2003 */
		ret = proc_lock (lockfile, SLM_SET);

	if (FAIL == ret)
	{
		DBG_PRINTF((dbg_fatal,"Failed to lock process (with lockfile %s)",lockfile));
		DBG_PRINTF((dbg_fatal,"  Either fatal error or another stdimp process is alive"));
		process_locked = FALSE;
		ret = FAIL;
	}
	else
	{
		DBG_PRINTF((dbg_proginfo,"Locked process with lock file [%s]",lockfile));
		process_locked = TRUE;
	}

	/*
	 * Begin parsing the file for errors
 	 */
	if (SUCCEED == ret)
	{
		ret = loop_parse (&rec_cnt, M_f);

		if (SUCCEED == ret)
		{
			DBG_PRINTF((dbg_progdetail,"\n\n*********************"
					"****************\n\n"));
            		DBG_PRINTF((dbg_progdetail, "%ld RECORDS PARSED OK",
					rec_cnt));
			DBG_PRINTF((dbg_progdetail,"\n***********************"
					"**************\n\n"));
		}
		else
		{
            		DBG_PRINTF((dbg_progdetail, "%d RECORDS PARSED FAILED",
					rec_cnt));
                        printf(ERROR_VAR, "ERROR: This file has failed parsing. NO records processed");
			log_ev_fail(ERRTYPE_PARSE);
		}
	}

	/*
	 * If there are no errors, then process the records
	 */
	if (SUCCEED == ret)
	{
		rewind (M_f);

		if (SUCCEED == (ret = loop_process (&rec_cnt)))
		{
            		DBG_PRINTF((dbg_syserr, "%ld records processed",
					rec_cnt));
		}
		else
		{
			log_ev_fail(ERRTYPE_PRMEC);
		}
	}
	
	/* Finished program - release lockfile  */
        /* (if locked in the first place)       */
	if (TRUE == process_locked)
	{
		if (FAIL == proc_lock (lockfile, SLM_FREE))
		{
			DBG_PRINTF((dbg_syswarn,"Warning: Error releasing lockfile %s",lockfile));
		}
		else
		{
			DBG_PRINTF((dbg_proginfo,"Process lock released"));
		}
	}

	/*
	 * Uninitialize (tidy up) after we have processed the file
	 */
	if (SUCCEED == ret)
	{
		uninit ();
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : init
 *
 * Purpose      : initialize
 *
 * Parameters   : argc -> number of command line parameters passed
 *		  argv -> command line parameters in string format
 *
 * Returns      : SUCCEED/FAIL
 *
 * Comments     : LM (10/1/2001: Adding ctxbool ccardlimchks to config parms
 *		  to toggle between checking limits on the master account
 *		  before approving new corporate charge-cards (as used b4 this)
 *		  and ignoring these checks (as used by Slavonska)
 *
 *----------------------------------------------------------------------*/
ctxprivate int init (int argc, char **argv)
{
	int   ret   = SUCCEED;
        FILE *fp    = NULL;
        static ctxbool  dupcustok = FALSE;	/* TH 6/7/99 allow duplicates?	*/
        static ctxbool  dupaccok = FALSE;
	static ctxbool  ccardchklims = TRUE;
	static int   batch_status = BTCH_CLOSED;
	static int   re_batch_status = BTCH_CLOSED;	/* TR 5557 Allow a  */
							/* different status */
							/* for renewed and  */
							/* reissued batches */
        static char  emmap[CTX_FILENAME_MAX];
	static char  stmts[CTX_FILENAME_MAX];
	static char  pins[CTX_FILENAME_MAX];
	static char official[4];
	static char chgcycle[4]="";	/* AS 4558 */
	static char acctypelim[3]="";	/* AS 4558 */
	static ctxbool synccorpexpdate = FALSE;
	static ctxbool duplimok = FALSE;
	static ctxbool ccs_installed = FALSE;
	/* mvitolin HAAB_10_004_WO-1 16/07/2010 */
	static char noupdstatcode[256] = {EOS};
	static char override_noupdstatus[256] = {EOS};
	static char crdbtchusr[CRDBTCH_USR_BUFFSIZE] = "";
	
	/*
	 * Accepted command line parameters for this program
	 */
	ctxprivate clp_parm clp[] =
        {
        {'d',	parm_long,    	1,	TRUE, 	&G_prvrecdate	},
        {'s',	parm_long,     	1,	TRUE, 	&G_filenum 	},
  		{'f',	parm_string, sizeof(M_infile),TRUE,M_infile	},
        {'D',	parm_int,     	1,	FALSE, 	&M_dbglev 	},
        {'B',	parm_int,     	1,	FALSE, 	&M_dbgbuf 	},
		{'n',	parm_int,	    1,	FALSE, 	&M_startrec 	},
 		{'e',   parm_int,	    1,	FALSE,	&M_max_err	},
		{'x',	parm_string, sizeof(M_subsect),FALSE, M_subsect },
		{'b',	parm_long, 1     ,FALSE, &M_batchprinc },
	        {0},
        };

	/*
	 * Parameters this program will look for in the configuration file
	 */
	ctxprivate cfp_parm cfp[] =
	{
		{"EMMAP",  parm_string, sizeof(emmap), FALSE, (void *)emmap, 0},
		{"CRDSTMT", parm_string,sizeof(stmts), FALSE, (void *)stmts, 0},
		{"CRDPIN", parm_string, sizeof(pins) , FALSE, (void *)pins,  0},
		/* MC - 30/05/01 - This parameter must be non-mandatory
		 * ( ie FALSE ) both for backward compatibility of
		 * configuration and flexibility of use!
		 */
                {"DBGFILE", parm_string,
                        sizeof(M_dbgfile), FALSE, (void *)&M_dbgfile, 0},
		/* TH 6/7/99 allow duplicates? */
		{"DUPCUSTOK" , parm_truebool, 1      , FALSE, &dupcustok, 0},
		{"DUPACCTOK" , parm_truebool, 1      , FALSE, &dupaccok, 0},
		/* JW 22/7/99 being used at Hermis? */
		{"BTCHSTAT", parm_int, 1, FALSE, &batch_status, 0},
		/* TR 5557 status for renewed & reissued batches */
		{"REBTCHSTAT", parm_int, 1, FALSE, &re_batch_status, 0},
		/* MC - Bug 4558 - 20/10/00 */
		{"OFFICIAL", parm_string, 4, FALSE, (void *)official, 0},
		/* AS 4558: read the chgcycle (not mandatory field) */
		{"CHGCYCLE", parm_string, sizeof(chgcycle), FALSE, 
						(void *)chgcycle, 0},
		/* AS 4558: read the acctyplim (not mandatory field) */
		{"ACCTYEPLIM", parm_string, sizeof(acctypelim), FALSE, 
						(void *)acctypelim, 0},
		{"CCARDCHKLIMS", parm_falsebool, 1, FALSE, &ccardchklims, 0},
		/* LM Sync corpexpdate for new Business Debit product	*/
		{"SYNCEXPCORPDATE", parm_truebool, 1, FALSE, 
							&synccorpexpdate, 0},
		{"DUPLIMOK", parm_truebool, 1, FALSE, &duplimok, 0},
		{"CCSINSTALLED", parm_truebool, 1, FALSE, &ccs_installed, 0},
		/* 13971 - additional card can belong to different branch */
		{"ALLOWDIFBRNCODE", parm_truebool, 1, FALSE, &M_allowDifferentBranches, 0},
		{"NOUPDSTATUS",  parm_string,   sizeof(noupdstatcode), FALSE, 
					(void *)noupdstatcode,  0},
		{"OVERRIDE_NOUPDSTATUS",parm_string, sizeof(override_noupdstatus),
				FALSE,  (void *)override_noupdstatus,  0},
		{"NOTPCALL", parm_truebool, 0, FALSE, (void *)&M_notp},
		{"CRDBTCHUSR", parm_string, sizeof(crdbtchusr), FALSE,
						(void *)crdbtchusr, 0},
		{0}
        };

	/*
	 * Setup the program name used in the debug.
	 */
	DBG_SETNAME("STDIMP");

	/*
	 * Parse the programs command line and display usage message
	 * if the required switches are not found
	 */
 	if (SUCCEED != (ret = clp_parse (argc, argv, clp)))
        {
                fprintf (stderr, "\nUsage:\t%s -dprvrecdate(YYYYMMDD)"
			" -sfilenum -finfile -[optional switches]"
			"\n\nOptional switches:"
			"\n\t\t-D[debug level]"
			"\n\t\t-B[debug buffer]"
			"\n\t\t-e[max errors]"
			"\n\t\t-x[ctxcfg subsection]"
			/* "\n\t\t-n[starting record number]" */
			"\n\nExamples:"
			"\n\t\tstdimp -d19980314 -s1 -fstdimp.dat"
			"\n\t\tstdimp -d19980404 -s1 -fstdimp.dat -D3 -B1"
			"\n\n\n\n"
			,argv[0]);
        }
	else
	{
		/*
		 * Set the debug level and debug buffer for this program
		 */
		DBG_SETLEV(M_dbglev);     /* Set the debug level (default 5) */
		DBG_SETBUF(M_dbgbuf);     /* Set the debug buffer (default 0)*/
	}

	DBG_PRINTF((dbg_proginfo, "M_batchprinc [%d]", M_batchprinc));
	set_batchprinc(M_batchprinc); 
	
	/*
	 * Get additional parameters from the configuration file (ctxcfg)
	 */
        if (SUCCEED == ret)
        {
                fp = cfp_open ();

                if (!fp)
                {
                        ret = FAIL;
                        fprintf(stderr, "couldn't open config file\n");
                }
                else if (SUCCEED != (ret = cfp_parse (fp, cfp, TAGNM, M_subsect)))
                {
		        fprintf (stderr, "cfp failed\n");
        	}
		else /* MC - 30/05/01 Only set debug file if non-NULL */
		{
			if( NULL != M_dbgfile[0] )
			{
				fprintf( stderr, "Setting debug file to %s\n",
							M_dbgfile );
				DBG_SETFILE( M_dbgfile );
			}
			else
			{
				fprintf( stderr, "Not Setting debug file\n" );
			}
		}
	}

	/* MC - 23/10/00 - Bug 4558 */
	if( ( SUCCEED == ret ) && ( strlen( official ) > 0 ) )
	{
		/* set global value in function.ec module */
		set_official( official );
	}

	/* AS 4558 22/10/00 4558 */
	if( (SUCCEED == ret) && ( strlen(chgcycle) > 0 ) )
	{
		/* set global value in parse.ec */
		set_dftchgcyc( chgcycle );
	}

	/* AS 4558 22/10/00 4558 */
	if( (SUCCEED == ret) && ( strlen(acctypelim) > 0 ) )
	{
		/* set global value in parse.ec */
		set_dftacctl( acctypelim );
	}

	if (SUCCEED == ret)
	{
		set_ccs_installed(ccs_installed);
	}

        if (SUCCEED == ret && NULL == (M_f = fopen (M_infile, "r" )))
        {
                DBG_PRINTF((dbg_fatal, "fopen of: %s failed. %s",
                         M_infile, strerror (errno)));

                ret = FAIL;
        }

        if (SUCCEED == ret && SUCCEED != sql_open (getenv ("DBNAME")))
        {
                DBG_PRINTF((dbg_fatal, "sql open failed"));
                ret = FAIL;
        }

        if (SUCCEED == ret)
        {
		init_record_sets ();
		ret = recdesc_init ();
   	}

	if (SUCCEED == ret)
	{
		set_dupcustok(dupcustok);
		set_dupaccok(dupaccok);
		set_batch_status (batch_status);
		/* TR 5557 if REBTCHSTAT not set set it to BTCHSTAT in case */
		/* that has been set					    */
		if ( re_batch_status == BTCH_CLOSED )
		{
			re_batch_status = batch_status;
		}
		set_re_batch_status (re_batch_status);
		set_ccardchklims(ccardchklims);
		set_synccorpexpdate(synccorpexpdate);
		set_duplimok(duplimok);
		
		/* mvitolin HAAB_10_004_WO-1 16/07/2010 */
		set_noupdstatus(noupdstatcode);
		set_override_noupdstatus(override_noupdstatus);

		DBG_PRINTF((dbg_progdetail, "CRDBTCHUSR - %s",
				crdbtchusr[0] ? "SET" : "NOT_SET"));
		if(crdbtchusr[0])
		{
			set_crdbtchusr(crdbtchusr);
		}
		
		if (M_subsect[0])
		{
			DBG_PRINTF((dbg_progdetail, "Using ctxcfg subsection [%s]", M_subsect));
		}
	}

        if (ret != FAIL)
        {
		/*
		 * Attempt to create string conversion structures.
		 */
                if (emmap[0] != '\0')
                {
                        DBG_PRINTF((dbg_progdetail,
                                "Attempting to use [%s]", emmap));
                        G_emconv = strconv_new (emmap);
                }
                else
                {
                        DBG_PRINTF((dbg_progdetail, "No emmap present"));
                }

		/*
		 * Create array of card products that need a CRDSTMT
		 * record adding
		 */
		if (stmts[0] != '\0')
		{
			DBG_PRINTF((dbg_progdetail,
                                "Attempting to convert [%s]", stmts));
			ret = init_stmts (stmts);
		}
		else
		{
			DBG_PRINTF((dbg_progdetail, "No CRDSTMT present"));
		}

		/*
		 * Create array of card products that need a CRDPIN
		 * record adding
		 */
                if (pins[0] != '\0')
                {
                        DBG_PRINTF((dbg_progdetail,
                                "Attempting to convert [%s]", pins));
                        ret = init_pins (pins);
                }
                else
                {
                        DBG_PRINTF((dbg_progdetail, "No CRDPIN present"));
                }
        }

/*JJA 30/9/1999 - NMR002723 START*/
        if (SUCCEED != (get_msc (MAXNUMCARD_TAG,1, FLD_LONG, 
					(void *)&G_crdbtch_size)))
	{
		G_crdbtch_size = DEFAULT_CRDBTCH_SIZE;
	}

	if (G_crdbtch_size<1)
	{
		G_crdbtch_size = DEFAULT_CRDBTCH_SIZE; 
	}
/*JJA 30/9/1999 - NMR002723 END*/

	if (SUCCEED == ret)
	{
		ret = get_msc (CURSYSDATE_TAG, 1, FLD_DATE, (void *)&G_sysdate);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : init_pins
 *
 * Purpose      : read in the card products that need a CRDPIN record creating
 *		  from the config file
 *
 * Parameters   : pins -> the line from the config file
 *
 * Returns      : SUCCEED/FAIL
 *
 * Comments     : On success the global variables G_pins_needed and
 *		  G_pins_cnt are initialized.  The former will contain
 *		  an array of char pointers, with each being a field
 *		  from the file.  No attempt is made to parse each
 *		  field.
 *
 *----------------------------------------------------------------------*/
ctxprivate int init_pins (char *pins)
{
	int ret = parse_csv (pins, ",", &G_pins_needed, &G_pins_cnt);

	if (ret == SUCCEED)
	{
		DBG_PRINTF((dbg_progdetail, "<%d> pins needed records",
				G_pins_cnt));
	}
	else
	{
		DBG_PRINTF((dbg_syswarn, "pins parsing failed"));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : init_stmts
 *
 * Purpose      : read in the card products that need a CRDSTMT record creating
 *                from the config file
 *
 * Parameters   : stmts -> the line from the config file
 *
 * Returns      : SUCCEED/FAIL
 *
 * Comments     : On success the global variables G_stmts_needed and
 *		  G_stmts_cnt are initialized.  The former will contain
 *		  an array of char pointers, with each being a field
 *		  from the file.  No attempt is made to parse each
 *		  field.
 *
 *----------------------------------------------------------------------*/
ctxprivate int init_stmts (char *stmts)
{
	int ret = parse_csv (stmts, ",", &G_stmts_needed, &G_stmts_cnt);

	if (ret == SUCCEED)
	{
		DBG_PRINTF((dbg_progdetail, "<%d> stmts needed records",
				G_stmts_cnt));
	}
	else
	{
		DBG_PRINTF((dbg_syswarn, "stmts parsing failed"));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  parse_csv
 *
 * Purpose	:  Parse a line with fields separated by a given character
 *		   into its constituent fields.  It returns a field count
 *		   and an array of character pointers.
 *
 * Parameters	:  buf - pointer to the input line
 *		   sep - pointer to separator characters
 *		   parray - pointer to the returned array
 *		   pcount - pointer to the field count
 *
 * Returns	:  SUCCEED/FAIL
 *		   On success, the field count and array are populated
 *
 * Comments	:  The field array is malloc'd memory, and it must be
 *		   freed by the caller.
 *
 *----------------------------------------------------------------------*/
ctxprivate int parse_csv (char *buf, char *sep, char ***parray, int *pcount)
{
        int ret = SUCCEED;
        int count = 0;
        int i = 0;
        char *chp = NULL;

        /*
	 * Find out how many entries we need to allocate space for,
	 * and add one, just in case the last entry doesn't have a
	 * comma after it.  This may be overkill.
         */

        for (i = 0; buf[i] != EOS; i++)
                if (buf[i] == ',')
                        count++;
	count++;

	*parray = (char **)calloc (count, sizeof (char *));
	if (*parray == NULL)
	{
		ret = FAIL;
	}

	for (i = 0;
	     ret == SUCCEED && NULL != (chp = strtok (buf, sep));
	     i++)
	{
		/*
		 * Make strtok work properly for next time
		 */
		buf = NULL;

		/*
		 * Remove leading and trailing spaces
		 */
		stp_right (chp);
		strip_leading (chp, ' ');

		/*
		 * Allocate enough memory, and store the string
		 */
		(*parray)[i] = malloc (strlen (chp) + 1);
		if ((*parray)[i] == NULL)
		{
			ret = FAIL;
			break;
		}
		else
		{
			strcpy ((*parray)[i], chp);
		}
	}

	if (ret == SUCCEED)
	{
		*pcount = i;
	}
	else
	{
		/*
		 * Tidy up
		 */
		if (*parray)
		{
			for (i = 0; i < count; i++)
			{
				free ((*parray)[i]);
			}

			free ((char *)(*parray));
		}
		*pcount = 0;
	}

        return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : uninit
 *
 * Purpose      : wrap up everything
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *----------------------------------------------------------------------*/
ctxprivate int uninit (void)
{
	int ret = SUCCEED;
	int i;

	/*
	 * Free the conversion buffers
	 */
	strconv_free (G_emconv);

	/*
	 * Free the pins array
	 */
	if (G_pins_needed)
	{
		for (i = 0; i < G_pins_cnt; i++)
		{
			free (G_pins_needed[i]);
		}

		free ((char *)G_pins_needed);
	}

	/*
	 * Free the stmts array
	 */
	if (G_stmts_needed)
	{
		for (i = 0; i < G_stmts_cnt; i++)
		{
			free (G_stmts_needed[i]);
		}

		free ((char *)G_stmts_needed);
	}

	/*
	 * Output the totals
	 */
	DBG_PRINTF((dbg_always,"\n----------------------------------------------\n\n"));

	DBG_PRINTF((dbg_always,"<%d> standalone records committed",
		M_commit_rec_cnt));
	DBG_PRINTF((dbg_always,"<%d> standalone records aborted",
		M_abort_rec_cnt));
	DBG_PRINTF((dbg_always,"<%d> record sets committed",
		M_commit_set_cnt));
        DBG_PRINTF((dbg_always,"<%d> record sets aborted",
		M_abort_set_cnt));

	DBG_PRINTF((dbg_always,"\n\n----------------------------------------------\n"));

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : init_record_sets
 *
 * Purpose      : Set up a table of action code, stating which ones
 *		  are sets.  For sets, it also records the maximum
 *		  record type expected.
 *
 * Parameters   : NONE
 *
 * Returns      : NONE
 *
 * Comments     : This routine uses lots of hard-coded constants.
 *		  If we ever introduce a set command which requires
 *		  non-consecutive record types, this may require changing.
 *
 *----------------------------------------------------------------------*/
ctxprivate void init_record_sets (void)
{
	int i;

	for (i = 0; i < 20; i++)
		M_record_sets[i] = 0;

	M_record_sets[20] = TYPE_CRDAPPL;
	M_record_sets[21] = TYPE_CRD;
	for (i = 22; i < 50; i++)
		M_record_sets[i] = TYPE_CUST;

	for (i = 50; i < 70; i++)
		M_record_sets[i] = 0;

	for (i = 70; i < 99; i++)
		M_record_sets[i] = TYPE_CUST;

	M_record_sets[99] = 0;

	return;
}

/*------------------------------------------------------------------------
 *
 * Function     : isSet
 *
 * Purpose      : check if record belongs to a set
 *
 * Parameters   : act -> Action code
 *
 * Returns      : ctxbool
 *
 * Comments     : The routine uses the global M_record_sets
 *
 *----------------------------------------------------------------------*/
ctxpublic int isSet (int act)
{
	return M_record_sets[act];
}

/*------------------------------------------------------------------------
 *
 * Function     :  err_msg
 *
 * Purpose      :  print error notification
 *
 * Parameters   :  line -> line number on which error occured
 *		   cmd -> command being executed when error occured
 *		   buf -> message to be associated with this error
 *
 * Returns      :  NONE
 *
 * Comments     :
 *
 *----------------------------------------------------------------------*/
ctxpublic void err_msg (int line, char *cmd, char *buf, int err_ext)
{
	G_err_cnt++;
        DBG_PRINTF((dbg_syserr, "\n***** Line %d of %s Cmd: %s failed\n%s\n",
		line, M_infile, cmd, buf ));
        DBG_PRINTF((dbg_progdetail, "no of errors: <%ld>", G_err_cnt ));
	sprintf(ERROR_VAR, "%s [%s]", cmd, G_err_descr[err_ext]);
}

/*------------------------------------------------------------------------
 *
 * Function	:  create_error_file
 *
 * Purpose	:  Create a file of erroneous records
 *
 * Parameters	:  cap -> Erroneous records
 *
 * Returns	:  void
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/

ctxpublic void create_error_file (char_array_t *cap)
{
	char  *outfile = NULL;
	size_t len;
	int    i;
	FILE  *fp;
	ctxbool   oksofar = TRUE;
	char   csd[] = " CORTEX STATIC DATA ";
	long   data;
	char  *buf;

	/*
	 * If the array is empty, there's no point in proceeding
	 */
	if (char_array_used (cap) == 0)
	{
		oksofar = FALSE;
	}

	if (oksofar)
	{
		/*
		 * Allocate enough memory for the output file
		 */
		len = strlen (M_infile);
		outfile = (char *)malloc (len + 5);
		if (outfile == NULL)
		{
			DBG_PRINTF((dbg_syserr,
				"Memory allocation error: outfile"));
			oksofar = FALSE;
		}
	}

	if (oksofar)
	{
		/*
		 * Try to find a suitable output file.
		 * The names tried are <name>.e<nn>, where the name is the
		 * input file, and <nn> ranges from <00> to <99>.  We try
		 * the first one that doesn't exist.
		 */
		for (i = 0; i < 100; i++)
		{
			sprintf (outfile, "%s.e%02d", M_infile, i);
			fp = fopen (outfile, "r");
			if (fp)
			{
				fclose (fp);
				fp = NULL;
			}
			else
			{
				break;
			}
		}

		if (i == 100)
		{
			DBG_PRINTF((dbg_syserr,
				"Cannot open error file %s.enn",
				M_infile));
			oksofar = FALSE;
		}
	}

	if (oksofar)
	{
		/*
		 * Open the file for writing.
		 */
		fp = fopen (outfile, "w");
		if (fp == NULL)
		{
			DBG_PRINTF((dbg_syserr,
				"Cannot open error file %s",
				outfile));
			oksofar = FALSE;
		}
		else
		{
			DBG_PRINTF((dbg_progdetail,
				"Opened error file %s",
				outfile));
		}
	}

	if (oksofar)
	{
		fprintf (fp, "00000001%20.20s%8.8s%8.8s\n",
					csd, G_infilenum, G_inprdate);
		for (i = char_array_first (cap, &data, &buf);
		     i == SUCCEED;
		     i = char_array_next  (cap, &data, &buf))
		{
			fprintf (fp, "%s\n", buf);
		}
		fprintf (fp, "99009901%s%08d\n", csd, char_array_sdirows (cap));
		fclose (fp);

	}

	free (outfile);
}

/*------------------------------------------------------------------------
 *
 * Function	:  read_line
 *
 * Purpose	:  Read a line from the input file
 *
 * Parameters	:  buf -> buffer for input line
 *		   len -> size of buffer
 *		   fp  -> FILE pointer
 *		   counter -> line counter
 *
 * Returns	:  Pointer to buffer, or NULL on error
 *
 * Comments	:  The trailing newline is removed, and a copy of
 *		   the line is stored in G_bak.
 *
 *----------------------------------------------------------------------*/
ctxpublic char *read_line (char *buf, size_t len, FILE *fp, long *counter)
{
	char *ret;

  	if ((ret = fgets (buf, len, fp)) != NULL)
   	{
		(*counter)++;

		/*
		 * Remove trailing newline
		 */
		if (buf[0] && '\n' == buf[strlen(buf) -1] )
			buf[strlen(buf)-1] = 0;

		DBG_PRINTF((dbg_progdetail, "rec_cnt = <%d>", *counter));
		DBG_PRINTF((dbg_progdetail, "buf= <%s>", buf));

		strscpy (G_bak, buf);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : loop_process
 *
 * Purpose      : reads the lines of data from the file and
 *		  uses them to manipulate the database
 *
 * Parameters   : NONE
 *
 * Returns      : SUCCEED/FAIL
 *
 * Comments     :
 *
 *----------------------------------------------------------------------*/
ctxprivate int loop_process (long *rcp)
{
	char buf[BUFSIZ];
	int ret = SUCCEED;
	char_array_t *cap;
	Hdr *hp;

	/*
	 * Initialise memory for our buffers
	 */
        memset (buf, 0, sizeof (buf));
	cap = char_array_init (0);
	*rcp = 0L;

	DBG_PRINTF((dbg_progdetail,"\n\n***************PROCESS LINE**********"
			"************\n\n"));

	/*
	 * Loop until we reach the last (known) record
	 */
	while (read_line (buf, BUFSIZ, M_f, rcp) != NULL)
	{
		/*
		 * Display the number of errors encountered
		 * while processing this file.
		 */
		DBG_PRINTF((dbg_progdetail, "G_err_cnt = <%d>", G_err_cnt));
		DBG_PRINTF((dbg_progdetail, "Init error message buffer"));

		/* NMR013959 - Initialize the error message */
		strcpy(G_errmsg, ERROR_TAG);

		/*
		 * If we have encountered too many error within the
		 * file then exit after displaying a suitable error
		 * message
		 */
		if (G_err_cnt > M_max_err)
		{
			DBG_PRINTF((dbg_syserr, "error number"
					" exceeded M_max_err"));
			
			/* NMR014609
			 * Ensure we flush all crd batches to 
			 * the CRDBTCH table
			 */
			pr_file_trailer(NULL,0);
			ret = FAIL;
			break;
		}

		hp = parse_hdr (buf);
		if (isSet (hp->act))
		{
			char_array_t *set;

			set = char_array_init (4);

			if ((read_set (buf, set, rcp, M_f) != SUCCEED) ||
			    (process_set (set, cap, rcp) != SUCCEED))
			{
				ret = FAIL;
DBG_PRINTF((dbg_progdetail, "read_set or process_set failed"));
			}

			char_array_free (set);
		}
		else
		{
			ret = process_rec (buf, *rcp);
			if (SUCCEED != ret)
			{
				/* NMR013959 - VM - Add the error message to err file */
				char_array_add (cap, 0, G_errmsg);
				char_array_add (cap, *rcp, G_bak);
			}
		}

		free ((char *)hp);
	}

	M_commit_rec_cnt -= 2;	/* Don't count header & trailer */

	create_error_file (cap);
	char_array_free (cap);
	cap = NULL;

	/* HYPOM-1121 ZG 16.02.2007. */
	if (FAIL == ret && G_err_cnt <= M_max_err)
	{
		/* loop_process() will return FAIL only when max error count 
			has been exceeded and the processing of an SDI file 
			has been interrupted, this is not an error for a 
			particular row !!!
		*/
		ret = SUCCEED;
	}

        return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : map_funct
 *
 * Purpose      : find the function corresponding to the action code and
 *		  rec type in data struct Funct
 *
 * Parameters   : buf -> Record
 *		  rec_cnt -> Input line number
 *
 * Returns      : SUCCEED/FAIL
 *
 * Comments     : Returns FAIL if we didn't find a function capable of
 *		  correctly processing our record, or if the function
 *		  that we found returned an error.  It is not an error
 *		  for the table to contain a NULL function pointer.
 *
 *----------------------------------------------------------------------*/
ctxprivate int map_funct (char *buf, long rec_cnt)
{
        int         ret = FAIL;
	func_tab_t *ftp;
	Hdr        *hp = parse_hdr (buf);

	/*
	 * Search for the correct function to process the record
	 * search by type and action code.  The table is terminated
	 * by a negative action code.
	 */
	for (ftp = M_proc_func; ftp->act >= 0; ftp++)
        {
		if ((ftp->act == hp->act) && (ftp->type == hp->type))
                {
			if (ftp->f)
			{
				ret = (ftp->f) (buf, rec_cnt);
			}
			else
			{
				ret = SUCCEED;
			}
			break;
                }
        }

	free ((char *)hp);
        return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     : process_rec
 *
 * Purpose      : Process an individual record
 *
 * Parameters   : buf -> buffer of data read from file
 *		: rec_cnt -> line number
 *
 * Returns      :
 *
 * Comments     :
 *
 *----------------------------------------------------------------------*/
ctxprivate int process_rec (char* buf, long rec_cnt)
{
	int ret = SUCCEED;

	/*
	 * Initialise sql and then call the appropriate function to
	 * process the record
	 */
	if (SUCCEED == (ret = sql_begin ()))
	{
		ret = map_funct (buf, rec_cnt);
	}
	else
	{
		ret = FAIL;
		DBG_PRINTF((dbg_fatal, "sql begin failed"));
	}

	/*
	 * If record processing succeeded, then commit the record
	 * otherwise abort sql and return with a FAIL code
	 */
	if (SUCCEED != ret)
	{
		M_abort_rec_cnt++;
		invalidate_batches ();
		sql_abort();	/* Can't handle errors */
	}
	else
	{
		M_commit_rec_cnt++;
		validate_batches ();
		ret = sql_commit();
	}
	
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  process_set
 *
 * Purpose	:  process a set of records
 *
 * Parameters	:  
 *
 * Returns	:  SUCCEED/FAIL
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int process_set (char_array_t *set, char_array_t *cap, long *rcp)
{
	int   ret;
	long  data;
	char *buf;
	int   i;
	ctxbool  oksofar = TRUE;

	if (SUCCEED != sql_begin ())
	{
		oksofar = FALSE;
		DBG_PRINTF((dbg_fatal, "sql begin failed"));
	}

	for (ret = char_array_first (set, &data, &buf);
	     (ret == SUCCEED) && oksofar;
	     ret = char_array_next (set, &data, &buf))
	{
		strcpy(G_bak, buf);
		if (SUCCEED != map_funct (buf, data))
		{
			oksofar = FALSE;
		}
	}

	/*
	 * If record processing succeeded, then commit the record
	 * otherwise abort sql and return with a FAIL code
	 */
	if (!oksofar)
	{
		M_abort_rec_cnt++;
		invalidate_batches ();
		ret = sql_abort();

		/* NMR013950 - VM - Add the error message to the error file */
		char_array_add (cap, 0, G_errmsg);
		for (ret = char_array_first (set, &data, &buf);
		     (ret == SUCCEED);
		     ret = char_array_next (set, &data, &buf))
		{
			char_array_add (cap, data, buf);
		}
	}
	else
	{
		M_commit_set_cnt++;
		validate_batches ();
		ret = sql_commit();
	}
	
	return oksofar ? SUCCEED : FAIL;
}
/*------------------------------------------------------------------------
 *
 * Function     :  allowDifferentBranches
 *
 * Purpose      :  
 *
 * Parameters   :  argc -> number of arguments passed on the command line
 *		   argv -> command line arguments in string form.
 *
 * Returns      :  value of the boolean flag 
 *
 * Comments     :
 *
 *----------------------------------------------------------------------*/
ctxpublic ctxbool allowDifferentBranches (void)
{
	return M_allowDifferentBranches;
}

/*------------------------------------------------------------------------
 *
 * Function     : log_ev_fail
 *
 * Purpose      : Log a FAIL event
 *
 * Parameters   : 
 *
 * Returns      : SUCCEED/FAIL
 *
 * Comments     : HYPOM-1121
 *
 *----------------------------------------------------------------------*/
ctxprivate int log_ev_fail(int errtype)
{
        int	ret = SUCCEED;

	switch(errtype)
	{
		case ERRTYPE_PARSE:
			ret = ev_call(EVTAG_SDIPARSEFAIL, M_infile);
			break;
		case ERRTYPE_PRMEC:
			ret = ev_call(EVTAG_SDIPRMECFAIL, M_infile);
			break;
	}

        return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  err_msg2
 *
 * Purpose      :  print error notification
 *
 * Parameters   :  line -> line number on which error occured
 *		   cmd -> command being executed when error occured
 *		   buf -> message to be associated with this error
 *
 * Returns      :  
 *
 * Comments     :  HYPOM-1121 ZG 20.02.2007.
 *
 *----------------------------------------------------------------------*/
ctxpublic void err_msg2(int line, int err_type, char *obj_name, char *descr, char *buf)
{
	char tmp[256];
	G_err_cnt++;
	sprintf(tmp, G_err_pattern[err_type], obj_name, descr);
        DBG_PRINTF((dbg_syserr, "\n***** Line %d of %s: %s\n%s\n",
		line, M_infile, tmp, buf));
        DBG_PRINTF((dbg_progdetail, "no of errors: <%ld>", G_err_cnt ));
	sprintf(ERROR_VAR, " Record (%d): %s", line, tmp);
}

