/*-----------------------------------------------------------------------
 * 
 * File		: falcon2if.c
 * 
 * Author	: Ruslans Vasiljevs
 * 
 * Created	: 09/05/2022
 *
 * Purpose	: FALCON2's services
 *
 * Comments	: 
 * 
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
 *-----------------------------------------------------------------------*/
/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>

#include <sldbg.h>
#include <slfdbg.h>
#include <slcfp.h>
#include <slnfb.h>
#include <slntp.h>
#include <slgtp.h>

#include <cortex.h>
#include <cotxnmon.h>
#include <comsgtyp.h>
#include <enc.h>
#include <fds.h>

#include <coint.fd.h>
#include <cust_prod.fd.h>

#include <falcon2cv.h>
#include <falcon2.h>

/*---------------------------Externs------------------------------------*/
extern int	fs_process( FBFR **pp_fb );
extern int	fs_init(char *lanhost, char *srvnm, char *hostname);

/*---------------------------Macros-------------------------------------*/
#define	SRVNM_LEN	64
#define	RSPCODE_LEN	6

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
ctxprivate char	*M_tagnm = "FALCON2IF";

/*private char	M_lanhost[SRVNM_LEN];  		   host for driver	*/
ctxprivate char	M_lansvc[SRVNM_LEN];  		/* service for driver	*/
ctxprivate char	M_hostname[5] = {EOS};		/* Hostdet.hostname	*/
ctxprivate char	M_svcnm[16+1] = "FALCON2IF";	/* Service name to advertise */

/*---------------------------Prototypes---------------------------------*/
ctxpublic int	falcon2if_init( FILE *fp, char *subsect );
ctxpublic void	FALCON2IF(TPSVCINFO *p_svc);
ctxprivate int	proc_req( FBFR **pp_fb, char *service, char *lanhost );


/*------------------------------------------------------------------------
 *
 * Function	: falcon2if_init
 *
 * Purpose	:  
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int	falcon2if_init( FILE *fp, char *subsect )
{
	int	ret = SUCCEED;
	
	ctxprivate cfp_parm cfp[] =
	{
		{"SVCNM",	parm_string, sizeof(M_svcnm),		FALSE,	M_svcnm,		0},
		{"HOSTNAME",	parm_string, sizeof(M_hostname),	TRUE,	(void *)M_hostname,	0},
		{0}
	};
	char	buf[CTX_FILENAME_MAX];
	char	*p;


	ret = cfp_parse(fp, cfp, M_tagnm, subsect);
	if( SUCCEED != ret )
	{
		fprintf(stderr, "FALCON2IF init failed %s %s (%s)\n",
			M_tagnm, subsect, cfp_errparm());
	}
	else
	{
		DBG_SETNAME("FALCON2IF");
	}

	/* This function required so that large messages are 
	 * handled properly */
	gtp_usebig();

	if( FAIL != ret )
	{
		ret = falcon2_init("");
	}

	if( FAIL != ret )
	{
		if (SUCCEED != (ret = enc_init(NULL)))
			DBG_PRINTF((dbg_syserr, "Encryptor did not init"));
	}

	if( FAIL != ret )
		ret = fs_init(""/*M_lanhost*/, M_lansvc, M_hostname);

	if (SUCCEED == ret)
	{
		if (FAIL == ntp_advertise(M_svcnm, FALCON2IF))
		{
			DBG_PRINTF((dbg_syserr, "tpadvertise %s failed %d %s",
				M_svcnm,
				ntp_errno(), ntp_strerror(ntp_errno())));
			ret = FAIL;
		}
	}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	:  falcon2if_uninit
 *
 * Purpose	:  
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic void	falcon2if_uninit()
{
	falcon2_uninit();
}

/*--------------------------------------------------------------------------
 *
 * Function	: FALCON2IF
 *
 * Purpose	: Service entry point for FALCON2 net transaction
 *
 * Parameters	: Usual for service
 *
 * Returns	: tpreturn
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxpublic void	FALCON2IF( TPSVCINFO *p_svc )
{
	int	ret = SUCCEED;
	FBFR	*p_fb = (FBFR *)NULL;
	short famode = FA_MODE_SCORING;
	short fdsaction = FDSSEND_REQUEST;
	short *p_fdsaction = NULL;

	p_fb = MAKE_BIGGER(p_svc->data);

	DBG_MONSTART(p_fb, M_tagnm);
	DBG_SETNAME("FALCON2IF");

	DBG_SETDUMPMODE(p_fb, DUMP_ATSTART);
	DBG_SETNAMEBYPAN(p_fb);
	DBG_STAR_PUTS(("FALCON2IF service"));
	DBG_FBDIFFSTARTL(dbg_progdetail, p_fb);

	if (!F_pres(p_fb, CS_FA_MODE, 0))
	{
		ret = F_chg(p_fb, CS_FA_MODE, 0, (char *)&famode, 0L);
	}

	if (!FBISNETMGT(p_fb))
	{
		p_fdsaction = (short *)CF_find(p_fb, I_FDSACTION, 0, NULL, FLD_SHORT);

		if ( (FBISADV(p_fb) || FBISCBREV(p_fb)) && !FBISORIG(p_fb) 
		    && (NULL == p_fdsaction || FDSSEND_REQUEST == *p_fdsaction || FDSSEND_REQNOTIF == *p_fdsaction))
		{
			DBG_PRINTF((dbg_syserr, "Repeated online advices/reversal are not to Falcon"));
			goto no_proc;
		}

		if (NULL == p_fdsaction)
		{
			ret = F_chg(p_fb, I_FDSACTION, 0, (char *)&fdsaction, 0);
		}
		else if (FDSSEND_NOTIFY != *p_fdsaction && FDSSEND_REQNOTIF != *p_fdsaction)
		{
			DBG_PRINTF((dbg_proginfo, "FALCON call not required in given workflow"));
			goto no_proc;
		}
	}

	if (SUCCEED == ret)
	{
		ret = proc_req(&p_fb,M_lansvc,""/*M_lanhost*/);		
	}

no_proc:
	DBG_FBDIFFENDL(dbg_progdetail,p_fb,DIFF_CLOSE);
	DBG_PRINTF((dbg_progdetail, "FALCON2IF Return: %s", SUCCEED == ret ? "TPSUCCESS" : "TPFAIL" ));
	DBG_STAR_PUTS(("ntp_return from FALCON2IF"));

	DBG_CLOSEFILE();
	DBG_FLUSH();

	/* update original FB pointer to reallocated FB */
	p_svc->data = (char*)p_fb;

	DBG_MONPRINT(p_fb, M_tagnm);

	ntp_return((SUCCEED == ret)
		? TPSUCCESS
		: TPFAIL,
		tpu_data,
		(char *)p_fb,
		0L,
		0L);
}

/*--------------------------------------------------------------------------
 *
 * Function	: proc_req
 *
 * Purpose	: Generic procedure to process request
 *
 * Parameters	: Usual for service
 *		  service - name of the network service used by host driver
 *		  lanhost - network name of the box with the low level driver
 *
 * Returns	: SUCCEED/FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int	proc_req(FBFR **pp_fb, char *service, char *lanhost )
{
	int	ret = SUCCEED;

	if (FAIL != ret)
		ret = fs_process(pp_fb);

	return ret;
}
