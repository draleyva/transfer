/*-----------------------------------------------------------------------
 * 
 * File		: icbscv.c
 *
 * Author	: Alex Butikov
 *
 * Created	: Jan 2011
 *
 * Purpose	: ICBS conversion functions etc. 
 *
 * Comments	:
 *
 * Ident	: @(#) $Id: //depot/cortex/v2/main/src/bgif/iso93H/msgcv/iso93Hcv.c#3$
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
*-----------------------------------------------------------------------*/
/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <cortex.h>
#include <slfdbg.h>
#include <sldbg.h>
#include <slntp.h>
#include <slnfb.h>
#include <sldtm.h>

#include <cocurr.h>
#include <coint.fd.h>
#include <cocrd.fd.h>
#include <copath.h>
#include <cocbf.h>
#include <cocbfdef.h>
#include <coevent.h>
#include <cocurr.h>
#include <coevent.h>
#include <comsgtyp.h>

#include <icbscv.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
static	ctxbool	M_init = FALSE;
ctxprivate	char	M_headerorg[ICBS_HEADER_LENGTH + 1];/* original header	*/
static char     M_basefe[FE_LEN+1];     /* BASEFE                       */

/*---------------------------Prototypes---------------------------------*/
ctxpublic void ICBSCVIN(  TPSVCINFO *p_svc );
ctxpublic void ICBSCVOUT( TPSVCINFO *p_svc );

ctxprivate int	init( void );
ctxprivate int	build_rsp_hdr( char *p_buf, FBFR *p_fb );
ctxprivate int	build_new_hdr(char *p_buf, FBFR *p_fb);
ctxprivate int	build_hdr( char *p_buf, FBFR *p_fb );
ctxprivate int	check_header( char *p_natmsg, FBFR *p_fb );
ctxprivate short	sf_gen_rsp( FBFR *p_fb, int nfield );

/*------------------------------------------------------------------------
 *
 * Function	:  sf_gen_rsp
 *
 * Purpose	:  Generate response when the message format is wrong
 *		  
 * Parameters	:  
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate short	sf_gen_rsp( FBFR* p_fb, int nfield )
{
	short	ret = SUCCEED;
	char	sznatmsg[1024] = "";
	char	szerrfld[4] = "";
	FLDLEN	len;

	len = sizeof(sznatmsg);
	if( FAIL != (ret = CF_get(p_fb, I_NATMSG, 0, sznatmsg, &len, FLD_STRING)) )
	{
		if( ICBS_HEADER_ERR == nfield )
			sprintf(szerrfld, "%03d", 999);
		else
			sprintf(szerrfld, "%03d", nfield);
		memcpy(sznatmsg + 4, szerrfld, 3);
		ret = F_chg(p_fb, I_NATMSG, 0, sznatmsg, len);
	}
		
	return ret;
}


/*------------------------------------------------------------------------
*
* Function	: ICBSCVIN
*
* Purpose	: ICBS converts message from native to FML
*
* Parameters	: p_svc - normal TP call
*
* Returns	: void
*
* Comments	: This is callable as a Tuxedo service
*
*----------------------------------------------------------------------*/
ctxpublic void ICBSCVIN(TPSVCINFO *p_svc )
{
 	int		ret = SUCCEED;
	static FBFR	*p_fb;

	DBG_TIMER(dbg_proginfo, "ICBSCVIN START");

	p_fb = MAKE_BIGGER (p_svc->data);

	ret = icbscvin(p_fb);

	DBG_TIMER(dbg_proginfo, "ICBSCVIN END");
	DBG_FLUSH();

	ntp_return(SUCCEED == ret
		   ? TPSUCCESS
		   : TPFAIL,
		   0L,
		   (char *)p_fb,
		   0L,
		   0L);
}

/*------------------------------------------------------------------------
*
* Function	: icbscvin
*
* Purpose	: Convert ICBS input
*
* Parameters	: p_fb - fielded buffer to convert
*
* Returns	: SUCCEED / FAIL
*
* Comments	: This is callable as a linked function
*
*------------------------------------------------------------------------*/
ctxpublic int icbscvin(FBFR *p_fb)
{
	int 		ret = SUCCEED;
	char 		*p_natmsg;
	char		*p_tmpbuf = NULL;
	FLDLEN		natmsglen;
	int		nfield = ICBS_HEADER_ERR;
	
	DBG_PRINTF((dbg_syswarn, "Converting incoming message..."));
	
	if ( NULL == (p_natmsg = F_find(p_fb, I_NATMSG, 0, &natmsglen ) ) )
	{
		DBG_PRINTF((dbg_syserr, "Error: no I_NATMSG in buffer"));
		ret = FAIL;
	}
	else if ( !(p_tmpbuf = malloc((size_t)natmsglen)) )
	{
		DBG_PRINTF((dbg_syserr, "Error: memory allocation failed"));
		ret = FAIL;
	}
	else
	{
		memcpy(p_tmpbuf, p_natmsg, (size_t)natmsglen);
		if (DBG_GETLEV() > dbg_proginfo)
			DBG_DUMP(dbg_progdetail, "Message", p_tmpbuf, natmsglen);
	}

	if (SUCCEED == ret && !M_init)
	{
 		M_init = TRUE;
		ret = init();
	}

	if( FAIL != ret )
	{
 		ret = jiso_i2f(p_tmpbuf + ICBS_HEADER_LENGTH, p_fb, &nfield);

		if( FAIL != ret )
			ret = check_header(p_tmpbuf, p_fb);

		if( FAIL == ret )
			sf_gen_rsp( p_fb, nfield );	
	}

	if ( FAIL != ret )
		DBG_DUMPFB(dbg_proginfo, "Converted buffer:", p_fb);
	else			
 		DBG_PRINTF((dbg_fatal, "Error: Message conversion failed"));

	free(p_tmpbuf);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: ICBSCVOUT
 *
 * Purpose	: ICBS converts message from FML to native
 *
 * Parameters	: p_svc - normal TP call
 *
 * Returns	: void
 *
 * Comments	:
 *
 *----------------------------------------------------------------------*/
ctxpublic void ICBSCVOUT(TPSVCINFO *p_svc)
{
 	int	 	ret = SUCCEED;
 	static FBFR	*p_fb;

	DBG_TIMER(dbg_proginfo, "ICBSCVOUT START");
 	p_fb = MAKE_BIGGER (p_svc->data);

	ret = icbscvout(p_fb);

	DBG_TIMER(dbg_proginfo, "ICBSCVOUT END");
 	DBG_FLUSH();
	
	ntp_return(SUCCEED == ret ? TPSUCCESS : TPFAIL,
		   0L,
		   (char *)p_fb,
		   0L,
		   0L);
}

/*------------------------------------------------------------------------
 *
 * Function	: icbscvout
 *
 * Purpose	: Convert VIS output
 *
 * Parameters	: p_fb - fielded buffer to convert
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: This is callable as a linked function
 *
 *------------------------------------------------------------------------*/
ctxpublic int icbscvout(FBFR *p_fb)
{
	char		buf[1024];
 	int		len;
 	int		ret = SUCCEED;
	char		*svcnm = CONACCSVC;
	long		rsplen = 0L;
	char		ife[5];
	short		txncode;
	char		txnsrc = '0';


	DBG_PRINTF((dbg_syswarn, "Converting outgoing message..."));
	
	memset( buf, 0, sizeof(buf) );
	memset( ife, 0, sizeof(ife) );

	if (!M_init)
 	{
 		M_init = TRUE;
 		ret = init();
 	}

	if ( FBISNETMGT(p_fb) )
	{
		ret = CF_chg(p_fb, C_TXNSRC, 0, &txnsrc, 0, FLD_CHAR);
	}
	
	if( jiso_use_conacc() && FBISREQ(p_fb) && 
			(FBISAUTH(p_fb) || FBISFIN(p_fb) || FBISCBREV(p_fb)) )
	{
		if( jiso_use_basefe() )
		{
			if( FAIL == CF_chg(p_fb, I_BASEFE, 0, M_basefe,	(FLDLEN)0, FLD_STRING) )
				return( FAIL );
				
			DBG_PRINTF((dbg_proginfo, "Using %s as I_BASEFE",M_basefe));
		}
		else
		{
       		 	if( F_pres(p_fb, I_IFE, 0 ) )
			{
				if( FAIL == F_get(p_fb, I_IFE, 0, (char *)ife, 0) )
					return( FAIL );
				else
					if( FAIL == CF_chg(p_fb, I_BASEFE, 0, ife, (FLDLEN)0, FLD_STRING) )
						return( FAIL );
			}
			else
			{
				DBG_PRINTF((dbg_syserr, "Missing I_IFE"));
				return( FAIL );
			}
		}

		if(FAIL==CF_get(p_fb,C_TXNCODE,0,(char * )&txncode,0,FLD_SHORT))
			return( FAIL );

		if( MTC_MAX_CREDIT > txncode )
		{

			DBG_PRINTF((dbg_proginfo, "Calling CONACC"));

			if (FAIL == ntp_call(svcnm,
					     (char*)p_fb,
					     0L,
					     (char **)&p_fb,
					     &rsplen,
					     0))
			{
				DBG_PRINTF((dbg_syserr,
				    "ntp_call %s failed %d [%s]", svcnm,
			            ntp_errno(), 
				    ntp_strerror(ntp_errno()) ));

				ev_svcfail(svcnm, ntp_errno() );

				return FAIL;
			}
		}
	}

	DBG_DUMPFB(dbg_progdetail,"Converting fielded buffer:", p_fb);

	if ( SUCCEED == ret )
		ret = jiso_f2i(p_fb, buf + ICBS_HEADER_LENGTH, &len);

	if ( SUCCEED == ret )
		ret = build_hdr(buf, p_fb);

	if ( SUCCEED == ret && DBG_GETLEV() > dbg_proginfo )
		DBG_DUMP(dbg_progdetail,"Full message:", buf, len + ICBS_HEADER_LENGTH);
		
	if ( SUCCEED == ret &&
	    FAIL == F_chg(p_fb, I_NATMSG, 0, buf, (FLDLEN)len + ICBS_HEADER_LENGTH) ) 
 	{
		DBG_PRINTF((dbg_fatal,"Error: Failed add I_NATMSG to fielded buffer"));
 		ret = FAIL;
 	}

	return ret;
 }

/*--------------------------------------------------------------------------
 *
 * Function	: init
 *
 * Purpose	: Initialise functions
 *
 * Parameters	: void
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate int init(void)
{
 	int ret = FAIL;

				/* initialise msg translation	*/
	ret = jiso_init();

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: build_rsp_hdr
 *
 * Purpose	:
 *
 * Parameters	: buf - location for build
 *		  p_fb - fielded buffer containing incoming header
 *		  len - length of message excluding header ie the ISO bit !! 
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate int build_rsp_hdr(char *p_buf, FBFR *p_fb)
{
 	int	ret = SUCCEED;

	DBG_PRINTF((dbg_progdetail,"Using original header"));
	memcpy(p_buf, M_headerorg, ICBS_HEADER_LENGTH);

	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	: build_new_hdr
 *
 * Purpose	:
 *
 * Parameters	: buf - location for build
 *		 len - length of message excluding header ie the ISO bit !! 
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: We are acquirer
 *
 *------------------------------------------------------------------------*/
ctxprivate int build_new_hdr(char *p_buf, FBFR *p_fb)
{
 	int	ret = SUCCEED;

	DBG_PRINTF((dbg_progdetail,"Building new header"));
	
	strncpy( p_buf, "ISO",  3 );
	if( FBISNETMGT(p_fb) )
		strncpy( p_buf + ICBS_PRID_OFF, "08",  2 );
	else if ( FBISATM(p_fb) )
		strncpy( p_buf + ICBS_PRID_OFF, "01",  2 );
	else
		strncpy( p_buf + ICBS_PRID_OFF, "02",  2 );
		
	strncpy( p_buf + ICBS_RLNO_OFF, "40",  2 );
	strncpy( p_buf + ICBS_STAT_OFF, "000", 3 );
	strncpy( p_buf + ICBS_ORCO_OFF, "4",   1 );
	strncpy( p_buf + ICBS_RECO_OFF, "0",   1 );
	
	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	: build_hdr
 *
 * Purpose	:
 *
 * Parameters	: p_buf - location for build
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: if there is not I_NATMSG we assume that it is a new
 *		 outgoing request message (we acting as acquirer);
 *		 otherwise it is response message (we are issuer)
 *
 *------------------------------------------------------------------------*/
ctxprivate int build_hdr(char *p_buf, FBFR *p_fb)
{
 	int	ret = SUCCEED;

	if( FBISREQ(p_fb) )	
		ret = build_new_hdr( p_buf, p_fb );
	else if (NULL == F_find(p_fb, I_NATMSG, 0, NULL))
		ret = FAIL;
	else
		ret = build_rsp_hdr( p_buf, p_fb );
		
	if( SUCCEED == ret )
	{
		if ( DBG_GETLEV() > dbg_proginfo )
			DBG_DUMP(dbg_progdetail, "Message header:", p_buf, ICBS_HEADER_LENGTH);
	}
	else
	{
		DBG_PRINTF((dbg_fatal,"Error: Failed to add header"));
	}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	: check_header
 *
 * Purpose	: Check incomming header. If there is something wrong,
 *		  change to deny 
 *
 * Parameters	: p_natmsg - native message
 *		  p_fb - fielded buffer
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int check_header(char *p_natmsg, FBFR *p_fb)
{
	long	rej_code = FAIL;
	int	ret = SUCCEED;
	char	tmp[10] = "";

	/* 
	   Save the original header before we check, so we know 
	   what to send back even checking fails
	*/
	DBG_PRINTF((dbg_progdetail,"Parsing header..."));
	
	memset(M_headerorg, NULL, sizeof(M_headerorg));
	if( !strncpy(M_headerorg, p_natmsg, ICBS_HEADER_LENGTH) )
	{
		ret = FAIL;
	}

	strncpy(tmp, p_natmsg+ICBS_PRID_OFF, ICBS_PRID_LEN); tmp[ICBS_PRID_LEN] = EOS;
	DBG_PRINTF((dbg_progdetail,"Product Indicator: [%s]", tmp));

	strncpy(tmp, p_natmsg+ICBS_RLNO_OFF, ICBS_RLNO_LEN); tmp[ICBS_RLNO_LEN] = EOS;
	DBG_PRINTF((dbg_progdetail,"Release Number:    [%s]", tmp));

	strncpy(tmp, p_natmsg+ICBS_STAT_OFF, ICBS_STAT_LEN); tmp[ICBS_STAT_LEN] = EOS;
	DBG_PRINTF((dbg_progdetail,"Status           : [%s]", tmp));

	if( FAIL == (rej_code = atol(tmp)) )
	{
		ret = FAIL;
		DBG_PRINTF((dbg_progdetail,"Error: Invalid status code. Failed to parse header."));
	}

	strncpy(tmp, p_natmsg+ICBS_ORCO_OFF, ICBS_ORCO_LEN); tmp[ICBS_ORCO_LEN] = EOS;
	DBG_PRINTF((dbg_progdetail,"Originator Code:   [%s]", tmp));

	strncpy(tmp, p_natmsg+ICBS_RECO_OFF, ICBS_RECO_LEN); tmp[ICBS_RECO_LEN] = EOS;
	DBG_PRINTF((dbg_progdetail,"Responder Code:    [%s]", tmp));

	if( FAIL == F_chg( p_fb, I_REJECTCODE, 0, (char *)&rej_code, 0 ) )
		return(FAIL);

	return( ret );
}

ctxpublic int check_message_body (char *p_iso, FBFR *p_fb, int *nfield);

ctxpublic void simple_msg_format_test (char *p_iso, FBFR *p_fb, int *nfield)
{
	jiso_init();

	/* First check the header */
	if( FAIL == check_header(p_iso, p_fb) )
	{
		DBG_PRINTF(( dbg_progdetail, "INCORRECT HEADER" ));
	}
	else
	{
		DBG_PRINTF(( dbg_progdetail, "HEADER OK" ));
		/* If thats OK check the body of the message */
		if (FAIL == check_message_body
				(p_iso + ICBS_HEADER_LENGTH, p_fb, nfield) )
		{
			DBG_PRINTF(( dbg_progdetail, "MESSAGE ERROR" ));
		}
		else
		{
			DBG_PRINTF(( dbg_progdetail, "MESSAGE OK" ));
		}
	}
	/* And thats it! */
}
ctxpublic void fill_M_headerorg(FBFR *p_fb)
{
	/* This is used by the self-testing tools */
	build_new_hdr( M_headerorg, p_fb );
}


/*------------------------------------------------------------------------
 *
 * Function	:  jiso_set_basefe 
 *
 * Purpose	: 
 *		  
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxpublic	void jiso_set_basefe(char *basefe)
{
	strcpy(M_basefe,basefe);

	DBG_PRINTF(( dbg_progdetail, "basefe flag set to %s",
		M_basefe ));

	return;
}

/*------------------------------------------------------------------------
 *
 * Function	:  jiso_use_basefe
 *
 * Purpose	: 
 *		  
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxpublic	ctxbool jiso_use_basefe(void)
{
	if(M_basefe[0] == 0)
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

