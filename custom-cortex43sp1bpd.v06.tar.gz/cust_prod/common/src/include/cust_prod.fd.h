/*-----------------------------------------------------------------------
 *
 * File        : cust_prod.fd
 *
 * Author      : Ruslans Vasiljevs
 *
 * Created     : 02 May 2022
 *
 * Purpose     : Custom product message field table definition for BPD
 *
 * Comments    :
 *
 * Ident	: @(#) $Id$
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS Global.
 *-----------------------------------------------------------------------*/
#ifndef __CUST_PROD_FD
#define __CUST_PROD_FD
/*	fname	fldid            */
/*	-----	-----            */
#define	CS_FA_TRAN_CODE	((FLDID32)167832160)	/* number: 60000	 type: string */
#define	CS_FA_DECISION_CODE	((FLDID32)167832161)	/* number: 60001	 type: string */
#define	CS_FA_ERROR_CODE	((FLDID32)167832162)	/* number: 60002	 type: string */
#define	CS_FA_MODE	((FLDID32)60003)	/* number: 60003	 type: short */
#define	CS_FA_WAITTIME	((FLDID32)33614436)	/* number: 60004	 type: long */
#define	CS_FA_ADDDATA	((FLDID32)335604325)	/* number: 60005	 type: fml32 */
#define	CS_FA_CRDSTATCODEUPD	((FLDID32)167832166)	/* number: 60006	 type: string */
#define	CS_FA_FDSNTFY	((FLDID32)167832167)	/* number: 60007	 type: string */
#endif
