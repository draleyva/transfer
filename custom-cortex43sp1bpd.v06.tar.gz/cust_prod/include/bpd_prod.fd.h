/*-----------------------------------------------------------------------
 *
 * File        : cust_prod.fd
 *
 * Author      : Raul Torres
 *
 * Created     : 30 April 2020
 *
 * Purpose     : Custom message field table definition (template)
 *		  for 4.2 systems
 *
 * Comments    :
 *
 * Ident	: @(#) $Id$
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS Global.
 *-----------------------------------------------------------------------*/
#ifndef __CUST_PROD_FD
#define __CUST_PROD_FD
/*	fname	fldid            */
/*	-----	-----            */
#define	D_WALLETPROVIDERID	((FLDID32)167852161)	/* number: 80001	 type: string */
#define	D_CAPTUREMETHOD	((FLDID32)167852162)	/* number: 80002	 type: string */
#define	D_LEVELOFTRUST	((FLDID32)167852163)	/* number: 80003	 type: string */
#define	D_DEVICESCORE	((FLDID32)167852164)	/* number: 80004	 type: string */
#define	BPDTKN_ISPRIMARY	((FLDID32)167852165)	/* number: 80005	 type: string */
#define	BPDTKN_ACTION	((FLDID32)167852166)	/* number: 80006	 type: string */
#define	BPDTKN_ERRORCODE	((FLDID32)167852167)	/* number: 80007	 type: string */
#define	BPDTKN_NOTIF_TYPE	((FLDID32)167852168)	/* number: 80008	 type: string */
#define	BPDTKN_ORIGIN	((FLDID32)167852169)	/* number: 80009	 type: string */
#define	BPDTKN_ORIGIN_NAME	((FLDID32)167852170)	/* number: 80010	 type: string */
#define	BPDTKN_TONUMMOVIL	((FLDID32)167852171)	/* number: 80011	 type: string */
#define	BPDTKN_TOEMAIL	((FLDID32)167852172)	/* number: 80012	 type: string */
#define	BPDTKN_CC_EMAILS	((FLDID32)167852173)	/* number: 80013	 type: string */
#define	BPDTKN_BCC_EMAILS	((FLDID32)167852174)	/* number: 80014	 type: string */
#define	BPDTKN_ATTACHMENTS	((FLDID32)167852175)	/* number: 80015	 type: string */
#define	BPDTKN_APP_SIGNATURE	((FLDID32)167852176)	/* number: 80016	 type: string */
#define	BPDTKN_MESSAGE_TYPE	((FLDID32)167852177)	/* number: 80017	 type: string */
#define	BPDTKN_PRIORITY	((FLDID32)167852178)	/* number: 80018	 type: string */
#define	BPDTKN_USE_TEMPLATE	((FLDID32)167852179)	/* number: 80019	 type: string */
#define	BPDTKN_TEMPLATE_ID	((FLDID32)167852180)	/* number: 80020	 type: string */
#define	BPDTKN_IS_STMT_REQ	((FLDID32)167852181)	/* number: 80021	 type: string */
#define	BPDTKN_PRODUCT_NUMBER	((FLDID32)167852182)	/* number: 80022	 type: string */
#define	BPDTKN_PRODUCT_MONEDO	((FLDID32)167852183)	/* number: 80023	 type: string */
#define	BPDTKN_NOMBRE_CLIENTE	((FLDID32)167852184)	/* number: 80024	 type: string */
#define	BPDTKN_OTP	((FLDID32)167852185)	/* number: 80025	 type: string */
#define	BPDTKN_BODY_TEXT	((FLDID32)167852186)	/* number: 80026	 type: string */
#define	BPDTKN_EMAIL_SUBJECT	((FLDID32)167852187)	/* number: 80027	 type: string */
#define	BPDTKN_TKNRQMERCHANTID	((FLDID32)167852188)	/* number: 80028	 type: string */
#define	BPDTKN_TKNRQNAME	((FLDID32)167852189)	/* number: 80029	 type: string */
#define	BPDTKN_PROVATTEMPTONDEV	((FLDID32)167852190)	/* number: 80030	 type: string */
#define	BPDTKN_TSPSCORE	((FLDID32)167852191)	/* number: 80031	 type: string */
#define	BPDTKN_ACCOUNTSCORE	((FLDID32)167852192)	/* number: 80032	 type: string */
#define	BPDTKN_PHONENUMBERSCORE	((FLDID32)167852193)	/* number: 80033	 type: string */
#define	BPDTKN_CARDSCORE	((FLDID32)167852194)	/* number: 80034	 type: string */
#define	BPDTKN_WALLETSCORE	((FLDID32)167852195)	/* number: 80035	 type: string */
#define	BPDTKN_REASONCODES	((FLDID32)167852196)	/* number: 80036	 type: string */
#define	BPDTKN_XCORRELATIONID	((FLDID32)167852197)	/* number: 80037	 type: string */
#define	BPDTKN_XISSUERID	((FLDID32)167852198)	/* number: 80038	 type: string */
#define	BPDTKN_CRDSTREASON	((FLDID32)167852199)	/* number: 80039	 type: string */
#define	BPDTKN_FPANDETAILS	((FLDID32)167852200)	/* number: 80040	 type: string */
#define	BPDTKN_FPANLASTDIGITS	((FLDID32)167852201)	/* number: 80041	 type: string */
#define	BPDTKN_FPANBIN	((FLDID32)167852202)	/* number: 80042	 type: string */
#define	BPDTKN_OLDDATEEXP	((FLDID32)167852203)	/* number: 80043	 type: string */
#define	BPDTKN_NEWDATEEXP	((FLDID32)167852204)	/* number: 80044	 type: string */
#define	BPDTKN_LANG	((FLDID32)167852205)	/* number: 80045	 type: string */
#define	BPDTKN_SND_CRDDET_ID	((FLDID32)33634478)	/* number: 80046	 type: long */
#define	BPDTKN_NTF_CRDDET_ID	((FLDID32)33634479)	/* number: 80047	 type: long */
#define	BPDTKN_OLDSTCOD	((FLDID32)167852208)	/* number: 80048	 type: string */
#define	BPDPWDSAFE_SRV	((FLDID32)167852209)	/* number: 80049	 type: string */
#define	BPDPWDSAFE_PARAM	((FLDID32)167852210)	/* number: 80050	 type: string */
#define	BPDPWDSAFE_AUTH	((FLDID32)167852211)	/* number: 80051	 type: string */
#define	BPDPWDSAFE_METHOD	((FLDID32)167852212)	/* number: 80052	 type: string */
#define	BPDPWDSAFE_CONFLICTOP	((FLDID32)167852213)	/* number: 80053	 type: string */
#define	BPDPWDSAFE_DURATION	((FLDID32)80054)	/* number: 80054	 type: short */
#define	BPDPWDSAFE_ACCOUNTID	((FLDID32)80055)	/* number: 80055	 type: short */
#define	BPDPWDSAFE_SYSTEMID	((FLDID32)80056)	/* number: 80056	 type: short */
#define	BPDPWDSAFE_BODY	((FLDID32)167852217)	/* number: 80057	 type: string */
#define	BPDTKN_STORAGEID	((FLDID32)167852218)	/* number: 80058	 type: string */
#define	BPDTKN_TOKENSTORATYPE	((FLDID32)167852219)	/* number: 80059	 type: string */
#define	BPDTKN_MANUFACTURER	((FLDID32)167852220)	/* number: 80060	 type: string */
#define	BPDTKN_DEVSTATUS	((FLDID32)167852221)	/* number: 80061	 type: string */
#define	BPDTKN_BRAND	((FLDID32)167852222)	/* number: 80062	 type: string */
#define	BPDTKN_MODEL	((FLDID32)167852223)	/* number: 80063	 type: string */
#define	BPDTKN_TAC	((FLDID32)167852224)	/* number: 80064	 type: string */
#define	BPDTKN_OSVERSION	((FLDID32)167852225)	/* number: 80065	 type: string */
#define	BPDTKN_FIRMWAREVERSION	((FLDID32)167852226)	/* number: 80066	 type: string */
#define	BPDTKN_PHONENUMBER	((FLDID32)167852227)	/* number: 80067	 type: string */
#define	BPDTKN_FOURLASTDIGPHON	((FLDID32)167852228)	/* number: 80068	 type: string */
#define	BPDTKN_DEVICENAME	((FLDID32)167852229)	/* number: 80069	 type: string */
#define	BPDTKN_DEVICEID	((FLDID32)167852230)	/* number: 80070	 type: string */
#define	BPDTKN_ANDROIDLASTTWO	((FLDID32)167852231)	/* number: 80071	 type: string */
#define	BPDTKN_DEVICEPARENTID	((FLDID32)167852232)	/* number: 80072	 type: string */
#define	BPDTKN_LANGUAGE	((FLDID32)167852233)	/* number: 80073	 type: string */
#define	BPDTKN_DEVICESTATEFLAGS	((FLDID32)167852234)	/* number: 80074	 type: string */
#define	BPDTKN_SERIALNUMBER	((FLDID32)167852235)	/* number: 80075	 type: string */
#define	BPDTKN_TIMEZONE	((FLDID32)167852236)	/* number: 80076	 type: string */
#define	BPDTKN_TIMEZONESETTINGS	((FLDID32)167852237)	/* number: 80077	 type: string */
#define	BPDTKN_SIMSERIALNUMBER	((FLDID32)167852238)	/* number: 80078	 type: string */
#define	BPDTKN_IMEI	((FLDID32)167852239)	/* number: 80079	 type: string */
#define	BPDTKN_PHONELOSTTIME	((FLDID32)167852240)	/* number: 80080	 type: string */
#define	BPDTKN_NETWORKOPERATOR	((FLDID32)167852241)	/* number: 80081	 type: string */
#define	BPDTKN_NETWORKTYPE	((FLDID32)167852242)	/* number: 80082	 type: string */
#define	BPDTKN_DEVBINDREF	((FLDID32)167852243)	/* number: 80083	 type: string */
#define	BPDTKN_IDVLSTPURPOSE	((FLDID32)167852244)	/* number: 80084	 type: string */
#define	BPDTKN_CUSTAMVALUE	((FLDID32)167852245)	/* number: 80085	 type: string */
#define	BPDTKN_OTPSOURCE	((FLDID32)167852246)	/* number: 80086	 type: string */
#define	BPDTKN_VIRTUALCARDID	((FLDID32)167852247)	/* number: 80087	 type: string */
#define	BPDTKN_WALLETCARDREFID	((FLDID32)167852248)	/* number: 80088	 type: string */
#define	BPDTKN_OLDNEWSTAT	((FLDID32)167852249)	/* number: 80089	 type: string */
#define	BPDTKN_DEV_CRDDET_ID	((FLDID32)33634522)	/* number: 80090	 type: long */
#define	BPDTKN_DEV_STR_B	((FLDID32)167852251)	/* number: 80091	 type: string */
#define	BPDTKN_CVM	((FLDID32)167852252)	/* number: 80092	 type: string */
#define	BPDTKN_CUSTATMVALUE	((FLDID32)167852253)	/* number: 80093	 type: string */
#define	BPDTKN_CUSAMTYPE	((FLDID32)167852254)	/* number: 80094	 type: string */
#define	BPDTKN_ACT_METHOD_TYPE	((FLDID32)167852255)	/* number: 80095	 type: string */
#define	BPDTKN_PAN_DISPLAY	((FLDID32)167852260)	/* number: 80100	 type: string */
#define	BPD_ISO_FB4	((FLDID32)134297829)	/* number: 80101	 type: double */
#endif
