/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	  Service Handlers
 *
 * @author	  Marcin Odrzywolski
 *
 * @date	  23 Apr 2021
 *
 * $Id$
 *
 * @copyright    FIS Global
 */
/*------------------------------------------------------------------------*/

#pragma once

#if __cplusplus < 201703L 
	#error "Header requires C++17"
	#include <stophere>
#endif


/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>

#include <coint.fd.h>
#include <cocrd.fd.h>
#include <enc.fd.h>

#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <sstream>
#include <TuxWrappers.hh>
#include <CtxUtils.hh>
#include <Logging.hh>
#include <CurrencyLookup.hh>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
enum fncode_t : uint16_t { fncode_list_all, fncode_translate, fncode_generate, fncode_print, fncode_commission, fncode_upper }; /**< Supported calls */
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/

/*---------------------------Prototypes---------------------------------*/


namespace ctxcc
{
	struct Handler
	{
		/*------------------------------------------------------------------------*/
		/**
		 * @brief       Handles unknown function call
		 *
		 * @param[in,out]  fb fielded buffer
		 * @param[in]  curr currency lookup cache
		 *
		 * @retval SUCCEED on success
		 * @retval FAIL otherwise
		 */
		/*------------------------------------------------------------------------*/
		static int Error([[maybe_unused]] ctxcc::tux::FBuf &fb, [[maybe_unused]] CurrencyLookup &curr)
		{
			ctxcc_Log(dbg_progdetail) << "unknown fncode";
			return SUCCEED;
		}

		/*------------------------------------------------------------------------*/
		/**
		 * @brief       Handles listall function call
		 *
		 * @param[in,out]  fb fielded buffer
		 * @param[in]  curr currency lookup cache
		 *
		 * @retval SUCCEED on success
		 * @retval FAIL otherwise
		 */
		/*------------------------------------------------------------------------*/
		static int Listall([[maybe_unused]] ctxcc::tux::FBuf &fb, [[maybe_unused]] CurrencyLookup &curr)
		{
			std::for_each(curr.getAll().begin(), curr.getAll().end(),
					[&](auto& e)
					{
						fb.add(I_CURRALPHA, e.second.mAlphacode).add(I_CURRNUM, e.second.mCurrcode);
					}
				);
			return SUCCEED;
		}

		/*------------------------------------------------------------------------*/
		/**
		 * @brief       Handles generate function call
		 *
		 * @param[in,out]  fb fielded buffer
		 * @param[in]  curr currency lookup cache
		 *
		 * @retval SUCCEED on success
		 * @retval FAIL otherwise
		 */
		/*------------------------------------------------------------------------*/
		static int Generate([[maybe_unused]] ctxcc::tux::FBuf &fb, [[maybe_unused]] CurrencyLookup &curr)
		{
			std::vector<std::string> currIncl, currExcl;
			getListFromService("CPPDEMO2", currIncl);
			getListFromService("CPPDEMO3", currExcl);

			auto addit = [&](std::string a, uint16_t n)
			{
				fb.add<decltype(a)>(I_CURRALPHA, a).add<decltype(n)>(I_CURRNUM, n);
			};

			auto allowed = [&](const std::decay<decltype(curr.getAll())>::type::value_type &v)
			{
				if(std::find(currExcl.begin(), currExcl.end(), v.second.mAlphacode) != currExcl.end())
					return false;
				
				return true;
			};

			auto process = [&](const std::decay<decltype(curr.getAll())>::type::value_type &v)
			{
				if(allowed(v))
					addit(v.second.mAlphacode, std::stoi(v.second.mCurrcode));
			};

			//add all currencies from cache to fb excluding ones blacklisted by CPPDEMO3 service
			std::for_each(curr.getAll().begin(), curr.getAll().end(), process);

			return SUCCEED;
		}

		/*------------------------------------------------------------------------*/
		/**
		 * @brief       Handles translate function call
		 *
		 * @param[in,out]  fb fielded buffer
		 * @param[in]  curr currency lookup cache
		 *
		 * @retval SUCCEED on success
		 * @retval FAIL otherwise
		 */
		/*------------------------------------------------------------------------*/
		static int Translate([[maybe_unused]] ctxcc::tux::FBuf &fb, [[maybe_unused]] CurrencyLookup &curr)
		{
			auto [b,e] = ctxcc::tux::PackIterator<std::string>(fb, std::array<FLDID,1>{I_CURRALPHA});

			//add alphacode translation of I_CURRALPHA
			std::for_each(b, e, 	[&](auto &e)
						{
							fb.add<uint16_t>(I_CURRNUM, curr.a2n(std::get<0>(e) ));
						}
					);

			return SUCCEED;
		}

		/*------------------------------------------------------------------------*/
		/**
		 * @brief       Handles print function call
		 *
		 * @param[in,out]  fb fielded buffer
		 * @param[in]  curr currency lookup cache
		 *
		 * @retval SUCCEED on success
		 * @retval FAIL otherwise
		 */
		/*------------------------------------------------------------------------*/
		static int Print([[maybe_unused]] ctxcc::tux::FBuf &fb, [[maybe_unused]] CurrencyLookup &curr)
		{
			ctxcc_Log(dbg_progdetail) << "Printing";
			auto [b,e] = ctxcc::tux::PackIterator<std::string, std::string>(fb, std::array<FLDID,2>{I_CURRALPHA, I_CURRNUM});

			//list I_CURRALPHA, I_CURRNUM pairs to log file
			std::for_each(b, e, 	[&](auto &e)
						{
							ctxcc_Log(dbg_progdetail) << std::get<0>(e) << " - " <<  std::get<1>(e);
						}
					);
			return SUCCEED;
		}

		/*------------------------------------------------------------------------*/
		/**
		 * @brief       Handles commission function call
		 *
		 * @param[in,out]  fb fielded buffer
		 * @param[in]  curr currency lookup cache
		 *
		 * @retval SUCCEED on success
		 * @retval FAIL otherwise
		 */
		/*------------------------------------------------------------------------*/
		static int Commission([[maybe_unused]] ctxcc::tux::FBuf &fb, [[maybe_unused]] CurrencyLookup &curr)
		{
			if(!fb.ispresent_all({C_AMTTXN,C_AMTBILL}))
			{
				fb.set<int>(C_RSPCODE, 0, 1).add<std::string>(I_REJMSG, "Essential fields missing");
				return SUCCEED;
			}

			double txn, bill;
			std::optional<double> txnorg;
			auto amts = std::tie(txn, bill, txnorg);
			ctxcc::tux::GetSetContext<double,double,std::optional<double>> context( fb, std::array<FLDID,3>{C_AMTTXN,C_AMTBILL,C_AMTTXNORG}, 0, amts );

			/* add commission */
			txn *= 1.23;
			bill = bill * 1.23 + 1;

			if(txnorg.has_value())
				txnorg = 0.5;

			return SUCCEED;
		}

		/*------------------------------------------------------------------------*/
		/**
		 * @brief       Handles upper function call
		 *
		 * @param[in,out]  fb fielded buffer
		 * @param[in]  curr currency lookup cache
		 *
		 * @retval SUCCEED on success
		 * @retval FAIL otherwise
		 */
		/*------------------------------------------------------------------------*/
		static int Upper([[maybe_unused]] ctxcc::tux::FBuf &fb, [[maybe_unused]] CurrencyLookup &curr)
		{
			//make K_CVV uppercase
			fb.apply<std::string>(K_CVV, 0, [](auto &s){ std::transform(s.begin(), s.end(), s.begin(), ::toupper); } );

			return SUCCEED;
		}

	private:
		/*------------------------------------------------------------------------*/
		/**
		 * @brief       Retreives a vector of I_CURRALPHA values from provided service
		 *
		 * @param[in]  service service name to be called
		 * @param[out]  curr vector of I_CURRALPHA values
		 *
		 */
		/*------------------------------------------------------------------------*/
		static void getListFromService(const char *service, std::vector<std::string> &curr)
		{
			curr.clear();

			ctxcc::tux::FBuf fb;

			fb.serviceCall(service);

			auto [b,e] = ctxcc::tux::PackIterator<std::string>(fb, std::array<FLDID,1>{I_CURRALPHA});
			std::for_each(b, e, 	[&](auto &e)
						{
							curr.push_back( std::get<0>(e) );
						}
					);
		}
	};
}

