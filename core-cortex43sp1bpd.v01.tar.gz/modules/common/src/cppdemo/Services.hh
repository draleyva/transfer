/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	  Service
 *
 * @author	  Marcin Odrzywolski
 *
 * @date	  23 Apr 2021
 *
 * $Id$
 *
 * @copyright    FIS Global
 */
/*------------------------------------------------------------------------*/


#pragma once

#if __cplusplus < 201703L 
	#error "Header requires C++17"
	#include <stophere>
#endif


/*---------------------------Includes-----------------------------------*/

#include <portable.h>
#include <stdio.h>
#include <stdlib.h>

#include <cosvinit.h>

#include <sldbg.h>
#include <slfdbg.h>
#include <slnfb.h>
#include <slntp.h>
#include <slcfp.h>

#include <coint.fd.h>
#include <cocrd.fd.h>
#include <enc.fd.h>

#include <string>
#include <deque>
#include <memory>
#include <map>
#include <sstream>
#include <TuxWrappers.hh>
#include <CtxUtils.hh>
#include <Logging.hh>
#include <TuxService.hh>
#include <TuxApplication.hh>
#include <CurrencyLookup.hh>
#include <Handler.hh>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/

/*---------------------------Prototypes---------------------------------*/


namespace ctxcc
{

	/*------------------------------------------------------------------------*/
	/**
	 * @brief       Demo tuxedo service no 1 - configuration
	 *
	 */
	/*------------------------------------------------------------------------*/
	struct CppDemoConfig : public ::ctxcc::tux::TuxServiceConfig
	{
		std::string	mParam; /**< Dummy parameter */
	};

	/*------------------------------------------------------------------------*/
	/**
	 * @brief       Demo tuxedo service no 1
	 *
	 * @tparam[in]  ServiceEntry service entry function
	 * @tparam[in]  ServiceName service name
	 * @tparam[in]  ConfigType configuration type
	 *
	 */
	/*------------------------------------------------------------------------*/
	template<auto ServiceEntry, char const *ServiceName, typename ConfigType=CppDemoConfig>
	class CppDemoService1 : public ::ctxcc::tux::TuxService<ServiceEntry, ServiceName, ConfigType>
	{
	public:
		typedef std::shared_ptr<CppDemoService1> Ptr;
		typedef ::ctxcc::tux::TuxService<ServiceEntry, ServiceName, ConfigType> BaseClass;

		/*------------------------------------------------------------------------*/
		/**
		 * @brief	Establishes processing dispatcher
		 *
		 * @param[in]	fncode function code
		 *
		 * @return function handling further processing
		 */
		/*------------------------------------------------------------------------*/
		std::function<int(ctxcc::tux::FBuf&, CurrencyLookup&)> dispatch(fncode_t fncode)
		{
			switch(fncode)
			{
			case fncode_list_all:
				return Handler::Listall;
			case fncode_translate:
				return Handler::Translate;
			case fncode_generate:
				return Handler::Generate;
			case fncode_print:
				return Handler::Print;
			case fncode_commission:
				return Handler::Commission;
			case fncode_upper:
				return Handler::Upper;
			default:
				return Handler::Error;
			}
		}

		/*------------------------------------------------------------------------*/
		/**
		 * @brief	Process incoming tuxedo call
		 *
		 * @param[in]	fb fielded buffer
		 *
		 * @retval SUCCEED on success
		 * @retval FAIL otherwise
		 */
		/*------------------------------------------------------------------------*/
		virtual int processCall([[maybe_unused]] ctxcc::tux::FBuf &fb)
		{
			ctxcc_Log(dbg_progdetail) << "Hello from c++ class1";

			/* fetch cache */
			mCurrency.fetchIfNeeded();

			fncode_t fncode = static_cast<fncode_t>(fb.get<uint16_t>(C_FNCODE));

			/* dispatch processing based on C_FNCODE */
			return dispatch(fncode)(fb, mCurrency);
		}

	private:
		CurrencyLookup	mCurrency;
	};

	/*------------------------------------------------------------------------*/
	/**
	 * @brief       Demo tuxedo service no 2
	 *
	 * @tparam[in]  ServiceEntry service entry function
	 * @tparam[in]  ServiceName service name
	 * @tparam[in]  ConfigType configuration type
	 *
	 */
	/*------------------------------------------------------------------------*/
	template<auto ServiceEntry, char const *ServiceName, typename ConfigType=CppDemoConfig>
	class CppDemoService2 : public  ctxcc::tux::TuxService<ServiceEntry, ServiceName, ConfigType>
	{
	public:
		typedef std::shared_ptr<CppDemoService2> Ptr;
		typedef ctxcc::tux::TuxService<ServiceEntry, ServiceName, ConfigType> BaseClass;


		/*------------------------------------------------------------------------*/
		/**
		 * @brief	Process incoming tuxedo call
		 *
		 * @param[in]	fb fielded buffer
		 *
		 * @retval SUCCEED on success
		 * @retval FAIL otherwise
		 */
		/*------------------------------------------------------------------------*/
		virtual int processCall([[maybe_unused]] ctxcc::tux::FBuf &fb)
		{
			ctxcc_Log(dbg_progdetail) << "Hello from c++ class2";
			std::array<std::string,2> currInclude={"pln", "usd"};

			/* Return list of included currencies (currInclude) */
			std::for_each(	currInclude.begin(),
					currInclude.end(), 
					[&fb](auto& e)
					{
						fb.add(I_CURRALPHA, toUpper(e));
					}
				);

			return SUCCEED;
		}
	};

	/*------------------------------------------------------------------------*/
	/**
	 * @brief       Demo tuxedo service no 3
	 *
	 * @tparam[in]  ServiceEntry service entry function
	 * @tparam[in]  ServiceName service name
	 * @tparam[in]  ConfigType configuration type
	 *
	 */
	/*------------------------------------------------------------------------*/
	template<auto ServiceEntry, char const *ServiceName, typename ConfigType=CppDemoConfig>
	class CppDemoService3 : public  ctxcc::tux::TuxService<ServiceEntry, ServiceName, ConfigType>
	{
	public:
		typedef std::shared_ptr<CppDemoService3> Ptr;
		typedef ctxcc::tux::TuxService<ServiceEntry, ServiceName, ConfigType> BaseClass;

		/*------------------------------------------------------------------------*/
		/**
		 * @brief	Process incoming tuxedo call
		 *
		 * @param[in]	fb fielded buffer
		 *
		 * @retval SUCCEED on success
		 * @retval FAIL otherwise
		 */
		/*------------------------------------------------------------------------*/
		virtual int processCall([[maybe_unused]] ctxcc::tux::FBuf &fb)
		{
			ctxcc_Log(dbg_progdetail) << "Hello from c++ class3";
			std::array<std::string,2> currExclude={"CHF", "BIF"};

			/* Return list of excluded currencies (currExclude) */
			std::for_each(	currExclude.begin(),
					currExclude.end(), 
					[&fb](auto& e)
					{
						fb.add(I_CURRALPHA, e);
					}
				);

			return SUCCEED;
		}
	};

}


