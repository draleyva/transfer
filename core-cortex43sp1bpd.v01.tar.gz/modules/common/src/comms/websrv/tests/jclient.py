#!/usr/bin/env python3

## @package jclient
#
#  @ingroup websrv_tests
#
#  @author  Wieslaw Grygo
#
#  @date    15 Apr 2015
#
#  @brief   Client for testing Rest servers using JSON content type.
#
#  $Id: //prod/cortex/c/modules/common/common-6.4/src/comms/websrv/tests/jclient.py#7 $
#
#  @copyright FIS Global
#

import socket
import struct
import errno
import time
import datetime
import string
import ssl
import json
import base64

from optparse import OptionParser

##
# @brief    Initialize data for speed mesure
#
# @return   None
#
def init_speed():
    global last
    last=datetime.datetime.now()

##
# @brief    Print speed for given number of operations
# 
# @param    [in] count Number of operations
# 
# @return   None
#
def print_speed(count):
    global last
    prev=last
    last=datetime.datetime.now()
    d=last-prev
    s=d.days*86400+d.seconds+d.microseconds*0.000001
    print(count/s)
    
##
# @brief    Connect to server using SSL optionaly
# 
# @param    [in] addr Address of server
# @param    [in] options Program options
# 
# @return   Returns (error, socket) 
#
def connect_server(addr,options):
    sock=None
    if options.ssl:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock = ssl.wrap_socket(sock,
            certfile=options.cert,
            keyfile=options.key,
            ca_certs=options.CAfile,
            cert_reqs=ssl.CERT_REQUIRED)
        sock.connect(addr)
        return (0,sock)
    else:
        if True:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            #sock = ssl.wrap_socket(sock) #, cert_reqs=ssl.CERT_REQUIRED)
            sock.connect(addr)
            return (0,sock)
        else:
            while True:
                if not sock:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    
                err=sock.connect_ex(addr)
                if err:
                    if err==errno.EADDRNOTAVAIL:
                        pass
                    elif err==errno.EAGAIN:
                        sock.close()
                        sock=None
                    else:
                        return (err,None)
                else:
                    return (err,sock)
        
    
##
# @brief    Send group of messages
# 
# @param    [in] addr Address of server
# @param    [in] count Number of operations
# @param    [in] msg Message to send
# @param    [in] options Program options
#
# @return   None
#
def send_group(addr,count,msg,options):
    connection = False
    for i in range(0,count):
        if not connection:
            l = 0
            (err,sock) = connect_server(addr,options)
            if err:
                print( 'Error on socket', errno.errorcode[err])
                continue
            
        # request
        if options.block:
            for m in range(0,len(msg),options.block):
                sock.sendall(msg[m:m+options.block])
                time.sleep(options.slow)
        else:
            sock.sendall(msg)

        # response
        head = []
        read = 0
        buf = ''
        pos = 0
        while read >= 0:
            # read data
            if options.ssl:
                data = sock.recv()
            else:
                data = sock.recv(4096)
            if len(data)==0:
                break
            buf += data

            pos = buf.find("\n", pos)
            while pos != -1:
                pos += 1
                if buf[pos-4:pos]=="\r\n\r\n":
                    head = buf[:pos-4].split("\r\n")
                    buf = buf[pos:]
                    pos = 0;
                    
                    prop = {}
                    for line in head[1:]:
                        (key,val)=line.split(': ',1)
                        prop[key] = val
                        
                    if 'Content-Length' in prop:
                        read = long(prop['Content-Length'])
                        while read > len(buf):
                            if options.ssl:
                                data = sock.recv()
                            else:
                                data = sock.recv(4096)
                            if len(data)==0:
                                read = -1
                                break
                            buf += data
                        data = buf[:read]
                        buf = buf[read:]
                        read = 0;
                    else:
                        data = ''

                    # can we reuse connection ?
                    connection = False
                    if 'Connection' in prop and prop['Connection']=='keep-alive':
                        connection = True

                    # do we reach limit of reusing of connection
                    l += 1
                    if l>=options.reuse:
                        connection = False
                        
                    if options.show:
                        print('<<<')
                        for val in head:
                            print(val)
                        print('')
                        if data:
                            print(data)
                        print('<<<')
                        print('')
                    if options.decode:
                        if data:
                            # read
                            obj=json.loads(data)
                            #change
                            for key, value in obj.iteritems():
                                if key in options.decode:
                                    print("[[[", key)
                                    print(base64.b64decode(value))
                                    print("]]]")
                                    #obj[key] = base64.b64decode(value)
                            # print
                            #print json.dumps(obj, sort_keys=False, indent=4, separators=(',', ': '))
                    if options.data:
                        print('<---')
                        print(repr(string.join(head,'\r\n')+'\r\n\r\n'+data))
                        print('')

                    read = -1
                    break

                #cheks rest
                pos = buf.find("\n",pos)
                #print "Pos :", pos
            
            # mark data searched
            pos = len(buf)
        
        # loop clean
        if not connection:
            sock.close()       

    # final clean
    if connection:
        sock.close()
        
    print_speed(count)
            

##
# @brief    Test Speed on socket pair.
# 
# @param    [in] msg Message to send
# @param    [in] count Number of operations
#
# @return   None
#
def test_speed(msg,count):
    
    pair = socket.socketpair()
    
    out = []
    init_speed()
    for i in range(count):
        pair[1].sendall(msg)
        
        out = []
        buf = ''
        num = 0
        tab = []
        size = 0
        last = 0
        read = 2
        while read:
            data = pair[0].recv(4096)
            if len(data)==0:
                break
            buf += data
            while last+read <= len(buf):
                # are we waiting for size
                if read == 2:
                    # get size
                    #safe
                    #(size,) = struct.unpack_from('!H',buf,last)
                    #fast
                    size = ord(buf[last+1]) + (ord(buf[last])<<8)
                    
                    # get size
                    if size:
                        read += size
                        continue
                    elif (num&1)==0:
                        read = 0
                        break
                
                # store value
                num += 1
                if False:
                    tab.append(buf[last+2:last+read])
                    if len(tab)==2:
                        out.append(tab)
                        tab = []

                # read next
                last += read
                read = 2;
        
    print_speed(count)
    print(out)
            

##
# @brief    Split string into chunks
# 
# @param    [in] input String to split
# @param    [in] count Number of bytes in chunk
#
# @return   None
#
def split(input, size):
    return [input[start:start+size] for start in range(0, len(input), size)]

##
# @brief    Main function
# 
# @return   None
#
def main():
    # Parser of commandline parameters
    parser = OptionParser(add_help_option=False)

    parser.add_option("-?", "--help", action="help")

    parser.add_option("-s", dest="service",
        help="Service to connect")
    parser.add_option("-b", type="int", dest="block", default=0,
        help="Send data in blocks and wait after each send.")
    parser.add_option("-S", type="float", dest="slow", default=0.1,
        help="Wait time after each block is send.")
    parser.add_option("-e", dest="extra", default=None,
        metavar="EXTRA", help="Extra data appened to HTTP request")  
    parser.add_option("-h", dest="hostname", default=None,
        metavar="HOST", help="Address of host")
    parser.add_option("-j", dest="json", default=None,
        metavar="JSON", help="JSON data")  
    parser.add_option("-q", dest="query", default="simppost",
        metavar="URI", help="HTTP uri")  
    parser.add_option("-m", dest="method", default="GET",
        metavar="METHOD", help="HTTP method")  
    parser.add_option("-r", type="int", dest="reuse", default=0,
        help="How many messages to send in one connection.")
    parser.add_option("-R", dest="request", default=None,
        metavar="REQUEST", help="Full HTTP request for tesing server error handling")  
    
    parser.add_option("-n", type="int", dest="num", default=0,
        help="How many messages to send.")
    parser.add_option("-g", type="int", dest="group", default=1000,
        help="Print speed for group of messages.")
    
    parser.add_option("-c", type="int", dest="chunked", default=0,
        help="Enable HTTP chunk encoding and set chunk size.")
    parser.add_option("-t", dest="transfer", default=None,
        help="Add Transfer-Encoding header.")
    parser.add_option("-l", type="int", dest="length", default=0,
        help="Add length header.")
    
    parser.add_option("-p", dest="show", default=False, action="store_true",
        help="Print result.")
    parser.add_option("-d", dest="data", default=False, action="store_true",
        help="Print raw data.")
    parser.add_option("-D", dest="decode", default=None, action="append",
        help="Decode property in JSON data using base64")

    parser.add_option("-X", dest="ssl", default=False, action="store_true",
        help="Use SSL.")
    
    parser.add_option("--CAfile", dest="CAfile", default=None,
        metavar="file", help="File with CA certificates for SSL")

    parser.add_option("--cert", dest="cert", default=None,
        metavar="file", help="File with client certificate for SSL")

    parser.add_option("--key", dest="key", default=None,
        metavar="file", help="File with key for client certificate")

    (options, args) = parser.parse_args()

    if not options.service:
        parser.error("Option -s is rquired! Use -? or --help to see usage information.")
        
    #if options.ssl:
    #    import ssl

    # prepare data for sending
    args.append('')
    
    # resolve address and use first value
    addresses = socket.getaddrinfo(options.hostname, options.service, socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP, socket.AI_PASSIVE)
    (family, socktype, proto, canonname, sockaddr) = addresses[0]
    
    inbuf  = options.method + " /" + options.query + " HTTP/1.1\r\n"
    if options.hostname:
        inbuf += "Host: " + options.hostname + "\r\n"
    inbuf += "User-Agent: jclient.py/0.1\r\n"
    inbuf += "Content-type: application/json\r\n"
    
    if options.reuse:
        inbuf += "Connection: keep-alive\r\n"
    else:
        inbuf += "Connection: close\r\n"

    if options.length > 0:
        inbuf +=  "Content-Length: " + str(options.length) + "\r\n"

    if options.transfer:
        inbuf +=  "Transfer-Encoding: " + options.transfer + "\r\n"

    if options.json!=None:
        options.json = options.json.decode('string_escape') 
        if options.chunked > 0:
            if not options.transfer:
                inbuf +=  "Transfer-Encoding: chunked\r\n"
            inbuf +=  "\r\n"
            for chunk in split(options.json, options.chunked):
                inbuf += "%X\r\n" % (len(chunk))
                inbuf +=  chunk + "\r\n"
            inbuf +=  "0\r\n"
            inbuf +=  "\r\n"
        else:
            if options.length <= 0:
                inbuf +=  "Content-Length: " + str(len(options.json)) + "\r\n"
            inbuf +=  "\r\n"
            #print 'HTTP Header size:', len(inbuf)
            inbuf +=  options.json
    else:
        inbuf +=  "\r\n"
        
    if options.extra!=None:
        inbuf +=  options.extra

    #print 'Whole HTTP request size:', len(inbuf)

    if options.request:
        #print "request:", repr(options.request)
        inbuf = options.request.decode('string_escape')
        #print "escaped:", repr(inbuf)
    
    if options.show:
        print('>>>')
        print(inbuf)
        print('>>>')
        print('')
    if options.data:
        print('--->')
        print(repr(inbuf))
        print('')
        
    if options.num >= 0:
        init_speed()
        if options.num:
            # main
            for g in range(options.num/options.group):
                send_group(sockaddr,options.group,inbuf,options)
            # rest
            g = options.num % options.group
            if g:
                send_group(sockaddr,g,inbuf,options)
        else:
            while True:
                send_group(sockaddr,options.group,inbuf,options)
    else:
        test_speed(inbuf,options.group)

main()
