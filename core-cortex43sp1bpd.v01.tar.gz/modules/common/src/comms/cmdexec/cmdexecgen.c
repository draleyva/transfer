/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Implementation for executing commands.
 *
 * @details	wrapper generic function to call cmdexec
 *
 * @author	Jason Veneracion
 *
 * @date	24 Jan 2020
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/comms/cmdexec/cmdexecgen.c#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
/*---------------------------Includes-------------------------------------*/

#include <portable.h>
#include <unistd.h>
#include <sys/wait.h> 
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <stdio.h>
#include <signal.h>

#include <slbuffer.h>
#include <cmdexec.h>
#include <sldbg.h>

/*---------------------------Externs--------------------------------------*/
/*---------------------------Macros---------------------------------------*/
/* pipes */
/** Index of pipe read FD. */
#define PIPE_READ 0
/** Index of pipe write FD. */
#define PIPE_WRITE 1
/** Number of pipe FD. */
#define PIPE_ALL_FD 2
/*---------------------------Typedefs-------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Globals--------------------------------------*/
/** File descriptor of null device stream. */
ctxpublic int cmdexec_null_fd = FAIL;

/*---------------------------Functions------------------------------------*/


/** @cond INTERNAL */

/*------------------------------------------------------------------------*/
/**
 * @brief	Init signal handlers to defaults before exec* is called.
 * 
 * @param[in,out] p_cmdexec Command to be initialized
 *
 * @retval	SUCCEED
 * @retval	FAIL
 */
/*------------------------------------------------------------------------*/
ctxprivate int cmdexecgen_inithndlrs(cmdexec_exec_t *p_cmdexec)
{
	int ret = SUCCEED;
	int pipe_out[PIPE_ALL_FD];
	int pipe_err[PIPE_ALL_FD];

	cmdexec_null_fd = open("/dev/null", O_RDWR);
	if (FAIL==cmdexec_null_fd)
	{
		DBG_PRINTF((dbg_syserr, 
			"Unable to open /dev/null file."));
		ret = FAIL;
	}
	
	p_cmdexec->in_fd = cmdexec_null_fd;
	p_cmdexec->out_fd = cmdexec_null_fd;
	p_cmdexec->err_fd = cmdexec_null_fd;
	p_cmdexec->exec_err_fd = cmdexec_null_fd;

	return ret;
}


/*------------------------------------------------------------------------*/
/**
 * @brief	Setup the command, set the parameters and structure memberes
 * 
 * @param[in,out] p_cmdexec Command to be initialized
 * @param[in] 	  p_buf_cmd Source string
 * @param[in,out] p_buf_copy Copy of buffer
 *
 * @retval	SUCCEED
 * @retval	FAIL
 */
/*------------------------------------------------------------------------*/
ctxprivate int cmdrun_set(cmdexec_cmd_t *p_cmd, slbuffer_t *p_buf_cmd, slbuffer_t *p_buf_copy)
{
	int ret = SUCCEED;
static char *parmlist[MAXPARMLIST];
	int  numargs = 0; 

	char *p_str;
	
	/* copy buffer */ 
	slbuffer_append_buffer_e(p_buf_copy, p_buf_cmd);
	
	/* set up the arg list */ 
	p_str = p_buf_copy->data;
	while (NULL != p_str)
	{
		parmlist[numargs] = p_str;
		p_str = strchr(p_str, ' ');
		DBG_PRINTF((dbg_progdetail, "p_str= [%s]", p_str));
		
		if (NULL != p_str)
		{
			*p_str = '\0';
			p_str++;
		}
		DBG_PRINTF((dbg_progdetail, "p_str= [%s]", p_str));
		
		numargs++;
	}
	
	parmlist[numargs] = NULL;
	p_cmd->command = p_buf_copy->data;
	p_cmd->argv = parmlist;
	p_cmd->argc = numargs; 
	
	
	DBG_PRINTF((dbg_progdetail, "p_buf_copy= [%s][%d]", p_buf_copy->data, p_buf_cmd->size));
	
	for (int ctr = 0; ctr < numargs; ctr++)
	{
		DBG_PRINTF((dbg_progdetail, "parmlist[%d] = %s", ctr, parmlist[ctr]));
	}
	
	return ret;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Reset signal handlers to defaults before exec* is called.
 *
 * @retval	SUCCEED
 * @retval	FAIL
 */
/*------------------------------------------------------------------------*/
ctxprivate void cmdexecgen_close(void)
{
	if (cmdexec_null_fd>0)
	{
		close(cmdexec_null_fd);
		cmdexec_null_fd = FAIL;
	}

}
/** @endcond */

/*------------------------------------------------------------------------*/
/**
 * @brief	Execute given command with changing std* streams.
 *
 * @param[in,out] exec_cmd Command to be executed.
 * @param[in] 	  wait wait for child process to finish
 *
 * @return	This function never returns.
 */
/*------------------------------------------------------------------------*/
ctxpublic int cmdexec_exec_gen(slbuffer_t *p_buf_cmd, ctxbool dowait, pid_t *pid)
{
	cmdexec_cmd_t cmd_run = {NULL, FAIL, FAIL, NULL};
	cmdexec_exec_t exec_run;
	char *buf_cmd = calloc(p_buf_cmd->size, sizeof(char));
	slbuffer_t locbuf ; 
	int ret = SUCCEED;
	pid_t lpid; 

	ret = slbuffer_init(&locbuf, buf_cmd, sizeof(buf_cmd)*p_buf_cmd->size);
	
	if (SUCCEED == ret)
	{
		ret = cmdexecgen_inithndlrs(&exec_run);
	}
	
	if (SUCCEED == ret)
	{
		ret = cmdrun_set(&cmd_run, p_buf_cmd, &locbuf);
		exec_run.cmd = &cmd_run; 
	}

	if (SUCCEED == ret)
	{
		lpid = cmdout_exec_command(&exec_run);

		if (NULL != pid)
		{
			*pid = lpid;
		}
		
		if (dowait)
		{
			wait(NULL);
		}
	}
	
	cmdexecgen_close();
	
	/* free buffer */ 
	if (NULL != buf_cmd)
	{
		free(buf_cmd);
	}

	DBG_PRINTF((dbg_progdetail, "Exiting = [%d]", ret));
	
	return ret; 
}


/*--------------------------------------------------------------------------*/

#ifdef TESTTEST
#include <slclp.h>


/*--------------------------------------------------------------------------
 *
 * Function     : main
 *
 * Purpose      : Test harness
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :
 *
 *------------------------------------------------------------------------*/
ctxpublic int main(int argc, char **argv)
{
        int     ret=SUCCEED;
        ctxprivate int     func;
        ctxprivate char    testdata[1024];
	char	cmd[256];
	slbuffer_t	slbuf_cmd;
        ctxprivate clp_parm        clp[] =
        {
                {'f', parm_int, 1, TRUE, (void *)&func, 0},
                {'d', parm_string, sizeof(testdata), FALSE, testdata, 0},
                {0}
        };

        memset(testdata, 0, sizeof(testdata));
        if (SUCCEED!=(ret=clp_parse(argc, argv, clp)))
        {
                printf("Usage:\t%s -f func [-d testdata]\n"
                        "\tfunc:        function to test::\n"
                        "\t     0 - cmdexec_exec_gen\n"
                                , argv[0]);

		return FAIL;
	}
        
        DBG_SETNAME("TESTTEST");
        DBG_SETLEV(dbg_progdetail);
        
        if (0==func)
        {
		printf("test data [%s]\n", testdata);

		slbuffer_init(&slbuf_cmd, cmd, sizeof(cmd)); 
		slbuffer_append_printf(&slbuf_cmd, "%s", testdata);

		ret = cmdexec_exec_gen( &slbuf_cmd );     
		
		printf("Test returns [%d]\n", ret);
		
        }
        
        return 0;
}
#endif
