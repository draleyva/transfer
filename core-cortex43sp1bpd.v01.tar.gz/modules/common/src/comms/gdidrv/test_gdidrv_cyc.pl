#!/usr/bin/perl -w
#-----------------------------------------------------------------------
#
# File		: test_gdidrv_cyc.pl
#
# Author	: Weifeng Li
#
# Created	: 01 December 2008
#
# Purpose	: Test gdidrv with a whole cycle
#
# Comments	: 1. input request from STDIN
# 		  2. send request to request driver
# 		  3. receive request from response driver
# 		  4. input response from STDIN
# 		  5. send response to response driver
# 		  6. receive response from request driver
#
#-----------------------------------------------------------------------
# Copyright (c) Nomad Software Ltd.
#-----------------------------------------------------------------------
use strict;
use Socket;
use ctxsldbg;
use ctxslclp;
use ctxslcfp;
use vars qw($AUTOFLUSH);
use IPC::SysV qw(S_IRWXU IPC_R IPC_CREAT IPC_NOWAIT);

my $M_soc;		# the socket
my %M_req;
my %M_rsp;

#-----------------------------------------------------------------------
#
# Function	:  main
#
# Purpose	:  main loop
# 
# Parameters	:  none
# 
# Returns	:  none
# 
# Comments	:  
#
#-----------------------------------------------------------------------
main();
sub main
{
	my $ret;
	my %clp;
	my $portreq;
	my $portrsp;
	my $port;
	my $req;
	my $msg;
 
	# command line options
	$clp{e}=0;
	$clp{T}="";
	$clp{s}="";
	$clp{S}="";
	$clp{D}=dbg_progdetail;
	$clp{F}="";
	dbg_setname("TESTDRV");
	$ret=clp_parse(\%clp, ['e', 'w'], ['t'], undef);
	if ($ret)
	{
		$clp{T}=$clp{t} if !$clp{T};
		dbg_setlev($clp{D});
		dbg_setfile($clp{F});
		dbg_printf(dbg_proginfo, "Req drv: %s/%s", $clp{t},
				$clp{s}?$clp{s}:"-");
		dbg_printf(dbg_proginfo, "Rsp drv: %s/%s", $clp{T},
				$clp{S}?$clp{S}:"-");
		# read ctxcfg
		$ret=cfp_parse(\%M_req, undef, $clp{t}, $clp{s},
				["NETADDR", "MSGQUEUE"], 1);
		$ret=cfp_parse(\%M_rsp, undef, $clp{T}, $clp{S},
				["NETADDR", "MSGQUEUE"], 1) if $ret;
	}
	if ($ret)
	{
		dbg_printf(dbg_proginfo, "Req port/que: %s/%s",
				$M_req{NETADDR}, $M_req{MSGQUEUE});
		dbg_printf(dbg_proginfo, "Rsp port/que: %s/%s",
				$M_rsp{NETADDR}, $M_rsp{MSGQUEUE});
		$AUTOFLUSH=1;
		$M_req{NETADDR}=get_port($M_req{NETADDR});
		$M_rsp{NETADDR}=get_port($M_rsp{NETADDR});
		$ret=0 if !$M_req{NETADDR} or !$M_rsp{NETADDR};
		$M_req{QID}=get_mqid($M_req{MSGQUEUE}) if $ret;
		$M_rsp{QID}=get_mqid($M_rsp{MSGQUEUE}) if $ret;
		$ret=0 if $ret and (!$M_req{QID} or !$M_rsp{QID});
	}
	# if -e set, send request and upper/echo automatically
	# if -w set, send request and wait for response
	$msg=input_msg(1) if $ret;
	$ret=send_msg($M_req{NETADDR}, $msg) if $ret;
	$ret=read_msg($M_rsp{QID}, \$msg, 1) if $ret and !$clp{w};
	print "req: $msg\n" if $ret;
	$msg=input_msg(0) if $ret and !$clp{e} and !$clp{w};
	$msg=uc($msg) if $ret and $clp{e};
	$ret=send_msg($M_rsp{NETADDR}, $msg) if $ret and !$clp{w};
	$ret=read_msg($M_req{QID}, \$msg, 0) if $ret;
	print "rsp: $msg\n";

	exit 0;
}

#-----------------------------------------------------------------------
#
# Function	:  get_port
#
# Purpose	:  Get port by service name
# 
# Parameters	:  svc
# 
# Returns	:  the port name
# 
# Comments	:  
#
#-----------------------------------------------------------------------
sub get_port()
{
	my ($svc)=@_;
	my $ret=0;

	$ret=$svc;
	$ret=getservbyname($svc, 'tcp') if $svc !~ /^[0-9]*$/;
	if (!$svc)
	{
		dbg_printf(dbg_syserr, "Invalid port: %s", $svc);
		$ret=0;
	}

	return $ret;
}

#-----------------------------------------------------------------------
#
# Function	:  get_mqid
#
# Purpose	:  Get message queue ID
# 
# Parameters	:  key		- the message key
# 
# Returns	:  the socket
# 
# Comments	:  
#
#-----------------------------------------------------------------------
sub get_mqid
{
	my ($msgkey)=@_;
	my $ret;

	$ret=msgget(hex($msgkey), IPC_R);
	dbg_printf(dbg_syserr, "Failed to get queue 0x%d", $msgkey) if !$ret;

	return $ret;
}


#-----------------------------------------------------------------------
#
# Function	:  input_msg
#
# Purpose	:  Get message from STDIN
# 
# Parameters	:  none
# 
# Returns	:  the message
# 
# Comments	:  
#
#-----------------------------------------------------------------------
sub input_msg()
{
	my ($req)=@_;
	my $ret="";

	printf("Please input %s:", $req?"request":"response");
	$ret=<STDIN>;
	chop($ret);
	$ret=($req?"Request":"Response")." message" if !$ret;

	return $ret;
}

#-----------------------------------------------------------------------
#
# Function	:  connect_server
#
# Purpose	:  Connect to the server as a client
# 
# Parameters	:  port		- the port number of the server
# 
# Returns	:  the socket
# 
# Comments	:  
#
#-----------------------------------------------------------------------
sub send_msg
{
	my ($port, $msg)=@_;
	my $ret=1;
	my $soc;
	my $sin;
	my $tmp;

	if (!socket($soc, PF_INET, SOCK_STREAM, getprotobyname('tcp')))
	{
		dbg_printf(dbg_syserr, "Failed to create socket");
		$ret=0;
	}
	else
	{
		$AUTOFLUSH=1;
		$sin=sockaddr_in($port, inet_aton("localhost")) if $ret;
		if (!connect($soc, $sin))
		{
			dbg_printf(dbg_syserr, "Failed to connect to "
					."the driver %d", $port);
			$ret=0;
		}
		elsif (!send($soc, "\0\0\0\2".$msg, 0))
		{
      			dbg_printf(dbg_syserr, "Failed to send");
			$ret=0;
		}
		while ($ret and !recv($soc, $tmp, 65536, 0))
		{
			last if $tmp eq "\0\0\0\0";
			$ret=0;
			if ($tmp eq "\0\0\0\1")
			{
				dbg_printf(dbg_syserr,
					"Driver failed to send message");
			}
			else
			{
				dbg_printf(dbg_syserr, "Driver failure");
			}
		}
		close $soc;
	}

	return $ret;
}

#-----------------------------------------------------------------------
#
# Function	:  read_msg
#
# Purpose	:  Connect to the server as a client
# 
# Parameters	:  port		- the port number of the server
# 
# Returns	:  the socket
# 
# Comments	:  
#
#-----------------------------------------------------------------------
sub read_msg
{
	my ($qid, $ref, $req)=@_;
	my $ret=1;
	my $id;
	my $msg;
	my $ev;

	$msg="";
	while ($ret)
	{
		if (!($ret=msgrcv($qid, $msg, 1024, 0, 0)))
		{
			dbg_printf(dbg_syserr, "Failed to read message");
			last;
		}
		dbg_dump(dbg_proginfo, ($req?"Request":"Response")."Message",
				$msg, length($msg));
		next if substr($msg,4,2) eq "01" or substr($msg,4,2) eq "02";
		last;
	}
	$$ref=substr($msg, 4);

	return $ret;
}

