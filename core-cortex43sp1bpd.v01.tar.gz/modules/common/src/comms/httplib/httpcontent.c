/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Implementation for checking HTTP content type.
 *
 * @remark	Refactored from jsonfb.c
 *
 * @author	Wieslaw Grygo
 *
 * @date	05 Aug 2016
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/comms/httplib/httpcontent.c#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
/*---------------------------Includes-------------------------------------*/

#include <portable.h>
#include <httpcontent.h>
#include <sldbg.h>

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/msg.h>
#include <assert.h>

/*---------------------------Externs--------------------------------------*/
/*---------------------------Macros---------------------------------------*/

/** @cond INTERNAL */

/** Macro returns lower case version of c if c in upper case otherwise c. */
#define LOWER_CASE(c) ((('A'<=(c)) && ('Z'>=(c)))?(char)((c)-'A'+'a'):(char)(c))

/** check white space in JSON format */
#define IS_CONTENT_WHITESPACE(c) ((' '==(c)) || ('\t'==(c)))
/** check if this is a separator for content type */
#define IS_CONTENT_SEPARATOR(c) (('/'==(c)) || ('='==(c)) || (';'==(c)) || ('\"'==(c)))

/** Length of token */
#define TOKLEN(tok) ((tok).end - (tok).start)

/** @endcond */

/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/

/** @cond INTERNAL */

/** Token in the Content-Type Header Field */
typedef struct
{
	/** beginning of token */
	const char *start;
	/** end of token */
	const char *end;
} httpcontent_token_t;

/** @endcond */

/*---------------------------Prototypes-----------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Globals--------------------------------------*/
/*---------------------------Functions------------------------------------*/

/** @cond INTERNAL */

/*------------------------------------------------------------------------*/
/**
 * @brief	Compare token with string ignoring case.
 *
 * @param[in]	ptok Token that may have upper-case characters.
 * @param[in]	lstr String with no upper-case characters and at least as long as token.
 *
 * @retval	TRUE
 * @retval	FALSE
 */
/*------------------------------------------------------------------------*/
ctxprivate int httpcontent_compare_token_lowercase(httpcontent_token_t *ptok, const char *lstr)
{
	const char *p = ptok->start;
	const char *e = ptok->end;
	const char *str = lstr;
	int ret = TRUE;
	
	while ( p<e )
	{
		/* different chars? */
		if (*p != *str)
		{
			/* token char isn't upper-case? */
			if (LOWER_CASE(*p) != *str)
			{
				ret = FALSE;
				break;
			}
		}
		
		++p;
		++str;
	}
	
	return ret;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Parse token in the Content-Type Header Field
 *
 * @param[in]	str String to parsed
 * @param[out]	ptok Token read from string.
 *
 * @return	End of parsed data.
 */
/*------------------------------------------------------------------------*/
ctxprivate char *httpcontent_parse_content_token(char *str, httpcontent_token_t *ptok)
{
	char *cnt = str;
	
	/* skip whitespaces */
	while ( IS_CONTENT_WHITESPACE(*cnt) )
	{
		++cnt;
	}
	
	ptok->start = cnt;
	/* read till white space or end of string */
	for ( ; (*cnt) && (!IS_CONTENT_WHITESPACE(*cnt)); ++cnt )
	{
		/* stop at separator */
		if ( IS_CONTENT_SEPARATOR(*cnt) )
		{
			break;
		}
	}
	ptok->end = cnt;
	return cnt;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Parse separator in the Content-Type Header Field
 *
 * @param[in]	str String to parsed
 * @param[out]	psep First not white space character.
 *
 * @return	End of parsed data. After white spaces and first separator.
 */
/*------------------------------------------------------------------------*/
ctxprivate char *httpcontent_parse_content_separator(char *str, char *psep)
{
	char *cnt = str;
	
	/* skip whitespaces */
	while ( IS_CONTENT_WHITESPACE(*cnt) )
	{
		++cnt;
	}
	
	/* read first non white space character */
	*psep = *cnt;
	
	/* skip separator */
	if ( IS_CONTENT_SEPARATOR(*cnt) )
	{
		++cnt;
	}
	
	return cnt;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Parse content type parameter value
 *
 * @details	Value can be simple token or quoted string.
 *
 * @param[in]	str String to parsed
 * @param[out]	pvalue Value read from string. As "" is ok, error is returned as token with NULL values.
 *
 * @return	End of parsed data.
 */
/*------------------------------------------------------------------------*/
ctxprivate char *httpcontent_parse_content_param_value(char *str, httpcontent_token_t *pvalue)
{
	char *cnt = str;
	char *out;
	
	/* parse token or quoted string */
	cnt = httpcontent_parse_content_token(cnt, pvalue);
	if ( !TOKLEN(*pvalue) )
	{
		/* no token */
		if  ('"'==*cnt)
		{
			++cnt;
			out = cnt;
			pvalue->start = out;
			while ('\"'!=*cnt)
			{
				/* quote? */
				if ('\\'==*cnt)
				{
					++cnt;
				}
				
				if (*cnt)
				{
					*out = *cnt;
					++out;
					++cnt;
				}
				else
				{
					/* report error */
					--cnt;
					out = NULL;
					pvalue->start = NULL;
					break;
				}
			}
			
			++cnt;
			pvalue->end = out;
		}
		else
		{
			pvalue->start = NULL;
			pvalue->end = NULL;
		}
	}

	return cnt;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Parse content type parameters and optionally set token for charset value.
 *
 * @param[in]	str String to parsed
 * @param[out]	p_charset_value Charset value read from string.
 *
 * @return	End of parsed data.
 */
/*------------------------------------------------------------------------*/
ctxprivate int httpcontent_parse_content_type_params(char *str, httpcontent_token_t *p_charset_value)
{
	static const char charset[] = "charset";
	
	int run = TRUE;
	char *cnt = str;
	char sep;
	httpcontent_token_t name;
	char equal;
	httpcontent_token_t value;
	
	/* default for charset value*/
	p_charset_value->start = NULL;
	p_charset_value->end = NULL;
	
	/* parse: *[; parameter ]*/
	do
	{
		/* separator */
		cnt = httpcontent_parse_content_separator(cnt, &sep);
		switch ( sep )
		{
		case ';':
			/* parse parameter: name = value */
			cnt = httpcontent_parse_content_token(cnt, &name);
			cnt = httpcontent_parse_content_separator(cnt, &equal);
			cnt = httpcontent_parse_content_param_value(cnt, &value);
			
			/* Check parsed values, value.start is NULL in case of parser error. */
			if ( (TOKLEN(name)) && ('='==equal) && (value.start) )
			{
				/* is this charset parameter? */
				if ((CSTRLEN(charset) == TOKLEN(name)) && 
					(TRUE==httpcontent_compare_token_lowercase(&name, charset)) )
				{
					/* copy charset value token */
					p_charset_value->start = value.start;
					p_charset_value->end = value.end;
				}
			}
			else
			{
				/* wrong format */
				run = FAIL;
			}
			break;
		
		case '\0':
			/* EOS is ok */
			run = SUCCEED;
			break;
		
		default:
			/* separator ';' is required before more data */
			run = FAIL;
			break;
		}
	} while ( TRUE==run );
	
	return run;
}

/** @endcond */

/*------------------------------------------------------------------------*/
/**
 * @brief	Check if this is JSON content type with right parameters.
 *
 * details	Check mime type and subtype names case sensitive.
 *		With optional charset name compared case insensitive.
 *		More info on: http://www.w3.org/Protocols/rfc1341/4_Content-Type.html
 *
 * @param[in,out] parser HTTP parser with request data.
 * @param[in]	mime_type MIME type of HTTP content. Not empty.
 * @param[in]	mime_subtype MIME subtype of HTTP content. Not empty.
 * @param[in]	mime_charset Charset used by HTTP content. Not empty.
 *
 * @retval	SUCCEED
 * @retval	FAIL
 */
/*------------------------------------------------------------------------*/
ctxpublic int httpcontent_check(http_parser_t *parser, 
	const char *mime_type, const char *mime_subtype,
	const char *mime_charset)
{
	int ret = FAIL;
	char sep;
	char *cnt;
	httpcontent_token_t cnt_type;
	httpcontent_token_t cnt_subtype;
	httpcontent_token_t cnt_charset = {NULL, NULL};
	
	size_t mime_type_len =strlen(mime_type);
	size_t mime_subtype_len =strlen(mime_subtype);
	size_t mime_charset_len =strlen(mime_charset);
	
	/* All parameters are given? */
	if ( (!mime_type_len) || (!mime_subtype_len) || (!mime_charset_len) )
	{
		DBG_PRINTF((dbg_syserr, "Wrong parameters for function checking HTTP Content-Type"));
		return FAIL;
	}
	
	/* parse: type / subtype *[; parameter ] */
	if ( parser->content_type_offset )
	{
		cnt = parser->buffer + parser->content_type_offset;
		
		/* parse: type / subtype */
		cnt = httpcontent_parse_content_token(cnt, &cnt_type);
		cnt = httpcontent_parse_content_separator(cnt, &sep);
		cnt = httpcontent_parse_content_token(cnt, &cnt_subtype);
		
		/* check parsed values */
		if ( (TOKLEN(cnt_type)) && ('/'==sep) && (TOKLEN(cnt_subtype)) )
		{
			/* parse parameters: *[; parameter ]*/
			ret = httpcontent_parse_content_type_params(cnt, &cnt_charset);
		}
		
		/* check type/subtype and optionally charset */
		if (SUCCEED==ret)
		{
			/* is this: type/subtype */
			if ( (mime_type_len==TOKLEN(cnt_type)) &&
				(!memcmp(cnt_type.start, mime_type, mime_type_len)) &&
				(mime_subtype_len==TOKLEN(cnt_subtype)) &&
				(!memcmp(cnt_subtype.start, mime_subtype, mime_subtype_len)) )
			{
				/* is charset set?*/
				if (cnt_charset.start)
				{
					/* is it a good charset? */
					if ( (mime_charset_len != TOKLEN(cnt_charset)) ||
						(FALSE==httpcontent_compare_token_lowercase(&cnt_charset, mime_charset)) )
					{
						ret = FAIL;
						
						DBG_PRINTF((dbg_syswarn, 
							"Content type charset parameter should have value %s.",
							mime_charset));
					}
				}
			}
			else
			{
				ret = FAIL;
				DBG_PRINTF((dbg_syswarn, "Content type MIME should have value: %s/%s.",
					mime_type, mime_subtype));
			}
		}
		else
		{
			DBG_PRINTF((dbg_syswarn, "Wrong format for Content-Type in HTTP headers: %s",
				parser->buffer + parser->content_type_offset));
		}
	}
	else
	{
		DBG_PRINTF((dbg_syswarn, "No Content-Type in HTTP headers"));
	}
	
	return ret;
}

