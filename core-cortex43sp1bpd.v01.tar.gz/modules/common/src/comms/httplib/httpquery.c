/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Implementation for parsing HTTP Query String.
 *
 * @remark	Refactored from jsonfb.c
 *
 * @author	Wieslaw Grygo
 *
 * @date	05 Aug 2016
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/comms/httplib/httpquery.c#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
/*---------------------------Includes-------------------------------------*/

#include <portable.h>
#include <httpquery.h>
#include <sldbg.h>

#include <ctype.h>
#include <string.h>

/*---------------------------Externs--------------------------------------*/
/*---------------------------Macros---------------------------------------*/

/** @cond INTERNAL */

/** Convert proper hex digit character into int */
#define HEXCHR2UINT(c) ((((unsigned char)(c))&0xF)+9*(((unsigned)(c))>>6))
/** Number of bits per hex digit. */
#define BITS_PER_HEX_DIGIT 4

/** @endcond */

/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Globals--------------------------------------*/
/*---------------------------Functions------------------------------------*/

/*------------------------------------------------------------------------*/
/**
 * @brief	Parse HTTP query string and put data into FB.
 *
 * @param[in]	parser HTTP parser with request data.
 * @param[out]	query HTTP query string parser.
 *
 * @retval	TRUE	There are arguments. 
 * @retval	FALSE	No or empty query string.
 */
/*------------------------------------------------------------------------*/
ctxpublic int httpquery_init(http_parser_t *parser, httpquery_t *query)
{
	query->pos = parser->buffer + parser->search_offset;
	query->name = NULL;
	query->value = NULL;
	query->out = query->pos;
	
	
	int run = FALSE;
	/* is there non empty query string */
	if ( parser->search_offset+1 < parser->fragment_offset )
	{
		run = TRUE;
	}
	
	return run;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Parse HTTP query string and return next parameter.
 *
 * @param[in,out] query HTTP query string parser.
 *
 * @retval	TRUE	Parameter is returned in strings query->name and query->value.
 *			Strings are ended with EOS character.
 *			Lengths of strings are query->value-query->name-1 and query->out-query->value-1.
 * @retval	SUCCEED	All parameters already processed.
 * @retval	FAIL
 */
/*------------------------------------------------------------------------*/
ctxpublic int httpquery_get(httpquery_t *query)
{
	int ret = SUCCEED;
	int loop;
	char c;
	
	query->name = query->out;
	query->value = NULL;
	
	/* is there non empty query string */
	c = *(query->pos);
	if ( c )
	{
		ret = FAIL;
		loop = TRUE;
		do
		{
			c = *(query->pos);
			++(query->pos);
			switch (c)
			{
			case '=':
				if ( !query->value )
				{
					c = EOS;
					ret = TRUE;
					query->value = query->out + 1;
				}
				break;
			
			case '&':
				c = '\0';
				loop = FALSE;
				break;
			
			case '\0':
				--(query->pos);
				loop = FALSE;
				break;
			
			case '+':
				c = ' ';
				break;
			
			case '%':
				if ( (isxdigit(query->pos[0])) && (isxdigit(query->pos[1])) )
				{
					c = ( HEXCHR2UINT(query->pos[0]) << BITS_PER_HEX_DIGIT ) | HEXCHR2UINT(query->pos[1]);
					query->pos += 2;
				}
				else
				{
					--(query->pos);
					ret = FAIL;
					loop = FALSE;
				}
				
				break;
			
			default:
				/* nothing to do */
				break;
			}
			
			*(query->out) = c;
			++(query->out);
		} while (loop);
	}
	
	return ret;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Decode URL encoded string in place.
 *
 * @param[in,out] str URL encoded string to be decoded in place.
 *
 * @retval	str	Position in string with error.
 * @retval	NULL	All converted without problem.
 */
/*------------------------------------------------------------------------*/
ctxpublic char *httpquery_decode(char *str)
{
	char *err = NULL;
	char *out = str;
	char c = *str;
	char *p;
	
	/* check format */
	for( p=strchr(str, '%'); p; p=strchr(p+3, '%') )
	{
		if ( (!isxdigit(p[1])) || (!isxdigit(p[2])) )
		{
			err = p;
			break;
		}
	}

	if (!err)
	{
		p = str;
		
		/* check char by char */
		while(c)
		{
			if( '%'==c )
			{
				c = ( HEXCHR2UINT(p[1]) << BITS_PER_HEX_DIGIT ) | HEXCHR2UINT(p[2]);
				p+=2;
			}
			else if( '+'==c ) 
			{
				c = ' ';
			}
			else
			{
				/* nothing to do */
			}
			
			*out = c;
			++out;
			++p;
			c=*p;
		}
		
		*out = EOS;
	}
	
	return err;
}

