#!/usr/bin/env python3

## @package hclient
#
#  @author  Wieslaw Grygo
#
#  @date    20 Nov 2018
#
#  @brief   HSM client for testing HSM server.
#
#  $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/hsmenc/tests/hclient.py#4 $
#
#  @copyright FIS Global
#

import socket
import struct
import errno
import time
import datetime
import sys
import ssl

from optparse import OptionParser


##
# @brief    Make message
#
# @param    [in] message Message to send
#
# @return   message
#
def make_message(message):
    return struct.pack('!H', len(message)) + message

##
# @brief    Initialize data for speed mesure
#
# @return   None
#
def init_speed():
    global last
    last = datetime.datetime.now()

##
# @brief    Print speed for given number of operations
# 
# @param    [in] count Number of operations
# 
# @return   None
#
def print_speed(count):
    global last
    prev = last
    last = datetime.datetime.now()
    d = last-prev
    s = d.days*86400+d.seconds+d.microseconds*0.000001
    print(count/s)
    
##
# @brief    Connect to server
# 
# @param    [in] addr Address of server
# @param    [in] options Program options
# 
# @return   Returns (error, socket) 
#
def connect_server(addr,options):
    sock = None
    if options.ssl:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock = ssl.wrap_socket(sock,
            certfile=options.cert,
            keyfile=options.key,
            ca_certs=options.CAfile,
            cert_reqs=ssl.CERT_REQUIRED)
        sock.connect(addr)
        return (0,sock)
    else:
        if True:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            #sock = ssl.wrap_socket(sock) #, cert_reqs=ssl.CERT_REQUIRED)
            sock.connect(addr)
            return (0,sock)
        else:
            while True:
                if not sock:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    
                err=sock.connect_ex(addr)
                if err:
                    if err==errno.EADDRNOTAVAIL:
                        pass
                    elif err==errno.EAGAIN:
                        sock.close()
                        sock = None
                    else:
                        return (err,None)
                else:
                    return (err,sock)
        
    
##
# @brief    Send group of messages
# 
# @param    [in] addr Address of server
# @param    [in] count Number of operations
# @param    [in] msg Message to send
# @param    [in] options Program options
#
# @return   None
#
def send_group(addr, count, msg, options):
    for i in range(count):
        (err,sock) = connect_server(addr,options)
        if err==0:
            sock.sendall(msg)
            #print "Send:", repr(msg) 
            buf = ''
            size = 0
            last = 0
            read = 2
            while read:
                # if options.ssl:
                    # data = sock.recv()
                # else:
                data = sock.recv(4096)
                if len(data)==0:
                    break
                buf += data
                while last+read <= len(buf):
                    # are we waiting for size
                    if read == 2:
                        # get size
                        #safe
                        #(size,) = struct.unpack_from('!H',buf,last)
                        #fast
                        size = ord(buf[last+1]) + (ord(buf[last])<<8)
                        
                        # get size
                        if size:
                            read += size
                            continue
                    
                    # store value
                    print("received message:", repr(buf[last+2:last+read]))
                    
                    # read next
                    last += read
                    read = 2;
                read = 0;
        else:
            print('Error on socket', errno.errorcode[err])
        if sock:
            sock.close()
        
    if options.wait:
        time.sleep(options.wait)
    print_speed(count)

##
# @brief    Main function
# 
# @return   None
#
def main():
    # Parser of commandline parameters
    parser = OptionParser(add_help_option=False)

    parser.add_option("-?", "--help", action="help")

    parser.add_option("-s", dest="service",
        help="Service to connect")
    parser.add_option("-h", dest="hostname", default=None,
        metavar="HOST", help="Address of host")
    parser.add_option("-m", dest="message", default='Ok',
        help="What to send.")
    
    parser.add_option("-n", type="int", dest="num", default=0,
        help="How many messages to send.")
    parser.add_option("-g", type="int", dest="group", default=1000,
        help="Print speed for group of messages.")
    parser.add_option("-w", type="float", dest="wait", default=0.0,
            metavar="N", help="Wait N seconds after sending group of messages (default 0.0).")
    

    parser.add_option("-X", dest="ssl", default=False, action="store_true",
        help="Use SSL.")
    
    parser.add_option("--CAfile", dest="CAfile", default=None,
        metavar="file", help="File with CA certificates for SSL")

    parser.add_option("--cert", dest="cert", default=None,
        metavar="file", help="File with client certificate for SSL")

    parser.add_option("--key", dest="key", default=None,
        metavar="file", help="File with key for client certificate")

    (options, args) = parser.parse_args()

    if not options.service:
        parser.error("Option -s is required! Use -? or --help to see usage information.")

    # resolve address and use first value
    addresses = socket.getaddrinfo(options.hostname, options.service, socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP, socket.AI_PASSIVE)
    (family, socktype, proto, canonname, sockaddr) = addresses[0]
    
    # message.decode('string_escape') #
    #print "request:", repr(options.message)
    #print "request decoded:", repr(options.message.decode('string_escape'))
    
    msg = make_message(options.message.decode('string_escape'))
    
    init_speed()
    if options.num:
        # main
        for g in range(options.num/options.group):
            send_group(sockaddr,options.group,msg,options)
        # rest
        g = options.num % options.group
        if g:
            send_group(sockaddr,g,msg,options)
    else:
        while True:
            send_group(sockaddr,options.group,msg,options)

main()
