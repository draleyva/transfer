/*-----------------------------------------------------------------------
 * 
 * File		: ctxpancrypt.c
 * 
 * Author	: Madars Vitolins 
 * 
 * Created	: 10 Dec 2007
 * 
 * Purpose	: Do the pan encrypt/decryption and print it to stdout
 * 
 * Comments	: 
 * 	
 * Ident	: @(#) $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/ctxpanenc/ctxpanenc.c#1 $
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.					 
 *-----------------------------------------------------------------------*/
/*---------------------------Includes-----------------------------------*/
#include <portable.h>

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <ctype.h>

#include <cortex.h>
#include <sldtm.h>
#include <sldbg.h>
#include <slclp.h>
#include <slcfp.h>
#include <slntp.h>
#include <coencpan.h>
#include <enc.h>
#include <dbtlogrh.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Defines------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
ctxpublic int	main(int argc, char** argv);
ctxprivate int	init(int argc, char** argv);
ctxprivate int	uninit(void);
ctxprivate int	enc_pan(void);
ctxprivate void	at_exit(void);

/*---------------------------Statics------------------------------------*/
static char rcsid[] = "$Id";


static char	M_pan[TLOG_PAN_BUFFSIZE];
static ctxbool	M_decrypt = FALSE;

/*------------------------------------------------------------------------
 *
 * Function	:  main
 *
 * Purpose	:  Main processing
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *------------------------------------------------------------------------*/
ctxpublic int main(int argc, char **argv)
{
	int ret = SUCCEED;

	ret = init(argc, argv);

	if (SUCCEED == ret)
	{
		ret = enc_pan();
	}

	uninit();

	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  init
 *
 * Purpose	:  
 *
 * Parameters	:  
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:  
 *
 *------------------------------------------------------------------------*/
ctxprivate int init(int argc, char **argv)
{
	int	ret = SUCCEED;
	static int 	dbglev = -1;

	ctxprivate clp_parm clp[] =
	{
		{'p', parm_string, sizeof(M_pan), TRUE, M_pan, 0},
		{'d', parm_truebool, 0, FALSE,(void *)&M_decrypt, 0},
		{'D', parm_int, 0, FALSE, (void *) &dbglev, 0},
		{0}
	};

	if (SUCCEED == ret)
	{
		ret = clp_parse(argc, argv, clp);
	}

	DBG_SETNAME("PANENC");

	if (-1 < dbglev)
        {
        	DBG_SETLEV(dbglev);
        }

	if (SUCCEED != ret)
	{
		fprintf(stderr, 
		"Usage: ctxpanenc -p PAN [-d] [-D dbg_level]\n"
			"use -d for pan decryption\n");
		return FAIL;
	}

	atexit(at_exit);

	return ret;
}

/*------------------------------------------------------------------------------
 *
 * Function	:  at_exit
 *
 * Purpose	:  Release the semaphore at process termination
 *
 * Parameters	:  void
 *
 * Returns	:  void
 *
 * Comments	:
 *
 *----------------------------------------------------------------------------*/
ctxprivate void at_exit(void)
{
	DBG_PRINTF((dbg_progdetail, "at_exit: Disconnecting from tuxedo"));
	ntp_term();
}

/*------------------------------------------------------------------------
 *
 * Function	:  uninit
 *
 * Purpose	:  Tidy up
 *
 * Parameters	:  
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:  
 *
 *------------------------------------------------------------------------*/
ctxprivate int uninit(void)
{
	int	ret = SUCCEED;

	return ret;
}

/*----------------------------------------------------------------------
 *
 * Function             : enc_pan
 *
 * Purpose              : Encrypts or decrypts pan and prints to STDOUT 
 *
 * Parameters           : none
 *
 * Returns              : SUCCEED/FAIL
 *
 * Comments             :
 *
 *----------------------------------------------------------------------*/
ctxprivate int enc_pan(void)
{
	int ret = SUCCEED;
	char *newpan=NULL;

	if (!M_decrypt)
	{
		newpan =  encryptPan(M_pan, NULL);
	} else
	{
		newpan = decryptPan(NULL, M_pan);
	}

	if (NULL==newpan)
		ret = FAIL;
	else
		fprintf(stdout, "%s", newpan);

	return ret;
}

