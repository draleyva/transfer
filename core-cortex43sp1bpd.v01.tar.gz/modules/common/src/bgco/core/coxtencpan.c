/*-----------------------------------------------------------------------*/
/**
 *
 * @file
 *
 * @brief	External PAN Encryption/Decryption Library
 *
 * @remarks	Product support the FIS Tokenisation Solution only.
 *
 * @author	Dimitris Fourkiotis
 *
 * @date	13 Oct 2021
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/coxtencpan.c#1 $
 *
 * @copyright	FIS Global 
 *
 */
 /*-----------------------------------------------------------------------*/
#include <portable.h>

#include <cortex.h>
#include <enc.h>
#include <coxtencpan.h>
#include <cotux.h>

#include <slhexdecode.h>
#include <sldbg.h>
#include <slntp.h>

#include <cocrd.fd.h>
#include <enc.fd.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define XT_TOKEN_LEN	18	/**< FIS Token Length */
/** Allowed first character for an FIS Token */
#define XT_START_CHARS	"GHJKLMNPQRSTUVWX"
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Inlines------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
ctxprivate int call_xt_service(short func, const char *in_pan, char *out_pan,
				size_t out_pan_size, const char *svcname);

/*------------------------------------------------------------------------*/
/**
 * @brief	Check if PAN is a token or not.
 *
 * @param[in]	value	The value to check.
 *
 * @return	TRUE or FALSE, depending if the value is a token or not.
 *
 * @remarks	The function implements stricter condition than IST.
 */
 /*----------------------------------------------------------------------*/
ctxpublic ctxbool is_xtencrypted_pan (const char *value)
{
	ctxbool isXTEncrypted = FALSE;
	char first_char_str[2] = {EOS, EOS}; /* string to hold the first char */

	/* Cortex' stricter check.
	 * IST has: isaccii(*value) && isupper(*value) */
	isXTEncrypted = (  value
			&& EOS != *value
			&& (first_char_str[0]=*value,
			SUCCEED == are_valid_chars(first_char_str,
						XT_START_CHARS)) );

	return isXTEncrypted;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Decrypt PAN calling the external solution, using service name as indicated in svcname.
 *
 * @param[out]	clrpan 		If not NULL, save the clear pan in memory address
 * @param[in]	clrpansize	clrpan size (including EOS)
 * @param[in]	encpan		The encrypted PAN to decrypt
 * @param[in]	svcname		Interface service name to the external PAN system.
 *
 * @return	Clear PAN or NULL if failed.
 *
 * @remarks	The function performs a tpcall to reach the external solution.
 * 		The returned pointer is only valid until the next call to the function.
 */
 /*----------------------------------------------------------------------*/
ctxpublic char *xt_decryptPanSizeSvc(char *clrpan, size_t clrpansize, const char *encpan, const char *svcname)
{
	int ret = SUCCEED;
	static char clrpan_tmp[PAN_LEN_MAX] = {EOS};
	static char *p_clrpan = NULL;

	ret = call_xt_service(EF_DECPAN, encpan, clrpan_tmp, sizeof(clrpan_tmp), svcname);
	if ( SUCCEED == ret )
	{
		if ( clrpan )
		{
			ret = slstrcpy_s(clrpan, clrpansize, clrpan_tmp);
			if ( SUCCEED != ret )
			{
				p_clrpan = NULL;
				ret = FAIL;
			}
		}

		if ( SUCCEED == ret )
		{
			p_clrpan = clrpan_tmp;
		}
	}
	else
	{
		if ( clrpan )
		{
			*clrpan = EOS;
		}
		p_clrpan = NULL;
	}

	return p_clrpan;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Decrypt PAN calling the external solution.
 *
 * @param[out]	clrpan 		If not NULL, save the clear pan in memory address
 * @param[in]	clrpansize	clrpan size (including EOS)
 * @param[in]	encpan		The encrypted PAN to decrypt
 *
 * @return	Clear PAN or NULL if failed.
 *
 * @remarks	The function performs a tpcall to reach the external solution.
 *		This function is a proxy to existing ENCPAN service.
 * 		The returned pointer is only valid until the next call to the function.
 */
 /*----------------------------------------------------------------------*/
ctxpublic char *xt_decryptPanSize(char *clrpan, size_t clrpansize, const char *encpan)
{
	return xt_decryptPanSizeSvc(clrpan, clrpansize, encpan, ENCPANSVC);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Encrypt PAN calling the external solution, using service name as indicated in svcname.
 *
 * @param[out]	encpan 		If not NULL, save the encrypted pan in memory address
 * @param[in]	encpansize	encpan size (including EOS)
 * @param[in]	clrpan		The clear PAN to encrypt
 * @param[in]	svcname		Interface service name to the external PAN system.
 *
 * @return	Encrypted PAN or NULL if failed.
 *
 * @remarks	The function performs a tpcall to reach the external solution.
* 		The returned pointer is only valid until the next call to the function.
 */
 /*----------------------------------------------------------------------*/
ctxpublic char *xt_encryptPanSizeSvc(char *encpan, size_t encpansize, const char *clrpan, const char *svcname)
{
	int ret = SUCCEED;
	static char encpan_tmp[PAN_LEN_MAX] = {EOS};
	static char *p_encpan = NULL;

	ret = call_xt_service(EF_ENCPAN, clrpan, encpan_tmp, sizeof(encpan_tmp), svcname);
	if ( SUCCEED == ret )
	{
		if ( encpan )
		{
			ret = slstrcpy_s(encpan, encpansize, encpan_tmp);
			if ( SUCCEED != ret )
			{
				p_encpan = NULL;
				ret = FAIL;
			}
		}

		if ( SUCCEED == ret )
		{
			p_encpan = encpan_tmp;
		}
	}
	else
	{
		if ( encpan )
		{
			*encpan = EOS;
		}
		p_encpan = NULL;
	}

	return p_encpan;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Encrypt PAN calling the external solution.
 *
 * @param[out]	encpan 		If not NULL, save the encrypted pan in memory address
 * @param[in]	encpansize	encpan size (including EOS)
 * @param[in]	clrpan		The clear PAN to encrypt
 *
 * @return	Encrypted PAN or NULL if failed.
 *
 * @remarks	The function performs a tpcall to reach the external solution.
 *		This function is a proxy to existing ENCPAN service.
 * 		The returned pointer is only valid until the next call to the function.
 */
 /*----------------------------------------------------------------------*/
ctxpublic char *xt_encryptPanSize(char *encpan, size_t encpansize, const char *clrpan)
{
	return xt_encryptPanSizeSvc(encpan, encpansize, clrpan, ENCPANSVC);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Call the external solution.
 *
 * @param[in]	func		Operation to perform (EF_DECPAN or EF_ENCPAN)
 * @param[in]	in_pan		Input PAN (may be clear or encrypted depending the value
 * 				of func)
 * @param[out]	out_pan		Output PAN (may be clear or encrypted depending the value
 * 				of func)
 * @param[in]	out_pan_size	Size of out_pan memory space.
 * @param[in]	svcname		Interface service name to the external PAN system.
 *
 * @retval	SUCCEED		Call completed successfully and out_pan contains the pan.
 * @retval	FAIL		If any error occured; out_pan is undefined.
 */
 /*----------------------------------------------------------------------*/
ctxprivate int call_xt_service(short func, const char *in_pan, char *out_pan,
				size_t out_pan_size, const char *svcname)
{
	int ret = SUCCEED;
	FBFR *p_fb = NULL;
	FLDLEN len;
	FLDID fldid = BADFLDID;

	p_fb = (FBFR *)ntp_alloc("FML", NULL, 0);
	if ( NULL == p_fb )
	{
		DBG_PRINTF((dbg_syserr, "FML alloc failed"));
		ret = FAIL;
	}

	fldid = (func == EF_DECPAN ? C_PAN : C_PAN_CLR);
	if( SUCCEED == ret
	 && ( FAIL == F_chg(p_fb, fldid, 0, (char *)in_pan, (FLDLEN)0)
	   || FAIL == F_chg(p_fb, K_FUNCODE, 0, (char *)&func, (FLDLEN)0)) )
	{
		DBG_PRINTF((dbg_syserr, "Failed to prepare Fielded Buffer"));
		ret = FAIL;
	}

	if( SUCCEED == ret )
	{
		fldid = (func == EF_DECPAN ? C_PAN_CLR : C_PAN);
		ret = cotux_call(svcname, "xtencpan library", &p_fb);
		if ( SUCCEED == ret )
		{
			ret = F_get(p_fb, fldid, 0, out_pan, (FLDLEN *)&out_pan_size);
			if ( SUCCEED != ret )
			{
				DBG_PRINTF((dbg_syserr, "Could not get PAN from "
							"fielded buffer."));
				ret = FAIL;
			}
		}
	}

	if ( p_fb )
	{
		ntp_free((char *)&p_fb );
	}

	return ret;
}