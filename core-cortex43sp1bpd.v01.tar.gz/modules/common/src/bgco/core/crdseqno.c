/*------------------------------------------------------------------------*/
/**
 * @file	
 *
 * @brief       Card sequence number evaluation.
 *
 * @remarks
 *
 * @author      Alberto Gomez Rueda
 *
 * @date        15 Nov 21
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/crdseqno.c#1 $
 *
 * @copyright   FIS Global
 */
/*------------------------------------------------------------------------*/
/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>

#include <sldbg.h>

#include <cortex.h>
#include <cocrd.fd.h>
#include <coint.fd.h>

#include <crdseqno.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/

/**
 * @brief	Return the card sequence number depending on the field mask. 
 *
 * @param[in]	p_fb		Fielded buffer 
 * @param[out]	p_crdseqno	returns the card. seqno. 
 * @param[in]	crdseqno_fldmsk	field mask to implement the logic 
 *				for the source of seq. number 
 * @param[in]	dfltseqno	Default sequence number to use, 
 *				must be equal or greater than zero 
 *				or FAIL. In this last case, 
 *				function will return FAIL 
 * @return	SUCCEED/FAIL
 *
 * @remarks	Card sequence number will be returned based on the
 *		presence of the corresponding mask, otherwise
 *		defult card. seqno received will be returned.
 */
/*----------------------------------------------------------------------*/
ctxpublic int get_crdseqno_fb(FBFR *p_fb, short *p_crdseqno, short crdseqno_fldmsk, 
									short dfltseqno)
{
	int ret = SUCCEED;
	int i = 0;
	ctxbool loaded = FALSE;
	ctxbool allow_dflt = FALSE;

	struct {
		FLDID	field;
		short	fldmsk;
		ctxbool	allow_dflt;
	}scan_fb[]=
	{
		{C_EMVCRDSEQNO,	EMVSEQNO_FLDMSK, FALSE},
		{I_APPLSEQNO,	APPSEQNO_FLDMSK, FALSE},
		{C_CRDSEQNO,	CTXSEQNO_FLDMSK, TRUE},
		{BADFLDID, 0, FALSE}
	};

	/* check that input parameters are valid */
	if(   NULL == p_fb 
	   || NULL == p_crdseqno )
	{
		DBG_PRINTF((dbg_syserr, "Fail: invalid input parameters: "
						"FB[%s], crdseqno[%s]",
						NULL==p_fb ? "NULL" : "OK",
						NULL==p_crdseqno ? "NULL" : "OK"));
		return FAIL;
	}

	DBG_PRINTF((dbg_progdetail, "crdseqno_fldmsk[%d] EMVSEQNO[%s] APPSEQNO[%s] CTXSEQNO[%s]", 
					crdseqno_fldmsk, 
					(crdseqno_fldmsk & EMVSEQNO_FLDMSK) ? "TRUE" : "FALSE", 
					(crdseqno_fldmsk & APPSEQNO_FLDMSK) ? "TRUE" : "FALSE", 
					(crdseqno_fldmsk & CTXSEQNO_FLDMSK) ? "TRUE" : "FALSE"));

	/* scan FB for SEQNO fields and get first that is present */
	for(i = 0; scan_fb[i].field != BADFLDID && !loaded; i++)
	{
		if((crdseqno_fldmsk & scan_fb[i].fldmsk) 
			&& F_pres(p_fb, scan_fb[i].field, 0))
		{
			if(SUCCEED == CF_get(p_fb, scan_fb[i].field, 
						0, (char *)p_crdseqno, 0, FLD_SHORT))
			{
				DBG_PRINTF((dbg_progdetail, "Card Sequence number taken "
								"from [%s]", 
								F_name(scan_fb[i].field) ));
				loaded = TRUE;
			}
			else
			{
				DBG_PRINTF((dbg_syserr,"Error: failed to get %s", 
							F_name(scan_fb[i].field) ));
				return FAIL;
			}
		}
	}

	/* if CRDSEQNO was not loaded from FB, 
	 * then check if default value is provided */
	if(!loaded && FAIL < dfltseqno)
	{
		allow_dflt = FALSE;
		for(i = 0; scan_fb[i].field != BADFLDID; i++)
		{
			/* check if default value is allowed to be set 
			 * for the fields in crdseqno_fldmsk */
			if((crdseqno_fldmsk & scan_fb[i].fldmsk) 
				&& scan_fb[i].allow_dflt)
			{
				/* do the OR operation for each */
				allow_dflt |= TRUE;
			}
		}

		if(allow_dflt)
		{
			*p_crdseqno = dfltseqno;
			DBG_PRINTF((dbg_syswarn, "Card Sequence number was not retrieved, "
							"set to default [%d]", *p_crdseqno));
			loaded = TRUE;
		}
		else
		{
			DBG_PRINTF((dbg_syswarn,"Default Card Sequence number is not allowed"));
		}
	}
	
	/* last check, if CRDSEQNO still not loaded - return FAIL */
	if (!loaded)
	{
		DBG_PRINTF((dbg_syserr, "Card Sequence number was not retrieved, FAIL"));
		*p_crdseqno = FAIL;
		ret = FAIL;
	}

	return ret;
}

