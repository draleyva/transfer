/*---------------------------------------------------------------------------*/
/**
 * @file
 *
 * @author	Dimitris Fourkiotis
 *
 * @brief	Unit tests for coenc library, coencpanfb object, encryption enabled
 * 		variants
 *
 * @remark	As DOENCPAN uses a static variable, encryption and non-encryption
 * 		tests must be run as separate binaries. Do not mix the cases.
 *
 * 		As the secure functions (*_se*) zap the destination buffer, this
 * 		affects the behaviour of the functions being tested. If this ever
 * 		will be fixed, tests will start failing, in which case they will need
 * 		to be adjusted as well.
 *
 * @date	07 Apr 2020
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/coencpanfb.c#1 $
 *
 * @copyright	FIS Global
 */
/*---------------------------------------------------------------------------*/
/** @cond INTERNAL */
/*------------------------------Includes-------------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sldbg.h>
#include <slntp.h>
#include <slnfb.h>

#include <coencpanfb.h>

#include <cocrd.fd.h>

#include <CppUTest/TestHarness_c.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>

/*------------------------------Externs--------------------------------------*/
/*------------------------------Inlines--------------------------------------*/
/*------------------------------Macros---------------------------------------*/
/** Maximum PAN buffer size */
#define MAX_PAN_SIZE	19+1
/*------------------------------Enums----------------------------------------*/
/*------------------------------Typedefs-------------------------------------*/
/*------------------------------Globals--------------------------------------*/
/*------------------------------Statics--------------------------------------*/
static FBFR *M_fml32 = NULL;
/*------------------------------Prototypes-----------------------------------*/

/*------------------------------------------------------------------------*/
/**
 * @brief	Setup function for tests in the common_coenc_coencpanfb group
 *
 * @param[in]	common_coenc_coencpanfb Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_coenc_coencpanfb)
{
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);

	CHECK_EQUAL_C_INT(SUCCEED, setenv("CTXENCPAN", "TRUE", 1));
	M_fml32 = (FBFR *)ntp_alloc("FML", NULL, 0);
	CHECK_C(NULL != M_fml32);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_coenc_coencpanfb group
 *
 * @param[in]	common_coenc_coencpanfb Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_coenc_coencpanfb)
{
	ntp_free((char *)M_fml32);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Encrypt and add the pan in the Fielded Buffer.
 *
 * @param[in]	common_coenc_coencpanfb Test group
 * @param[in]	test_coencpanfb_encryptPanFb_encPan Test description
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpanfb, test_coencpanfb_encryptPanFb_encPan)
{
#if IS_EXT_PANSVC()	
	char *clr_pan = "We62100000000000ec";
#else
	char *clr_pan = "D16FCC1A194711D822D";
#endif
	char *fb_pan = "5413330009091064";

	char *fb_enc_pan = NULL;

	CHECK_EQUAL_C_INT(SUCCEED, F_add(M_fml32, C_PAN_CLR, fb_pan, 0));
	CHECK_EQUAL_C_INT(SUCCEED, encryptPanFb(M_fml32, clr_pan));
	fb_enc_pan = F_find(M_fml32, C_PAN, 0, NULL);
	CHECK_C(NULL != fb_enc_pan);
	CHECK_EQUAL_C_STRING(clr_pan, fb_enc_pan);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Encrypt a long pan and add it in the Fielded Buffer, causing
 * 		an overflow.
 *
 * @param[in]	common_coenc_coencpanfb Test group
 * @param[in]	test_coencpanfb_encryptPanFb_longEncPan Test description
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpanfb, test_coencpanfb_encryptPanFb_longEncPan)
{
#if IS_EXT_PANSVC()
	char *clr_pan = "J5186150731459937a0000000000";
#else
	char *clr_pan = "D16FCC1A194711D822DFFFFF";
#endif
	char *fb_pan = "5413330009091064";
	char *fb_enc_pan = NULL;

	CHECK_EQUAL_C_INT(SUCCEED, F_add(M_fml32, C_PAN_CLR, fb_pan, 0));
	CHECK_EQUAL_C_INT(SUCCEED, encryptPanFb(M_fml32, clr_pan));
	fb_enc_pan = F_find(M_fml32, C_PAN, 0, NULL);
	CHECK_C(NULL != fb_enc_pan);
	CHECK_EQUAL_C_STRING("", fb_enc_pan);
	if ( IS_CTXPROF_ALLOWED(CTXPROF_COREDUMP) )
	{
		CHECK_C(-1 != system("rm core_*"));
	}
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Decrypt the pan (C_PAN) and add it as C_PAN_CLR..
 *
 * @param[in]	common_coenc_coencpanfb Test group
 * @param[in]	test_coencpanfb_decryptPanFb_clrPan Test description
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpanfb, test_coencpanfb_decryptPanFb_clrPan)
{
	char *enc_pan = "5413330009091064";
	char *clr_pan = NULL;

	CHECK_EQUAL_C_INT(SUCCEED, F_add(M_fml32, C_PAN, enc_pan, 0));
	CHECK_EQUAL_C_INT(SUCCEED, decryptPanFb(M_fml32));
	clr_pan = F_find(M_fml32, C_PAN_CLR, 0, NULL);
	CHECK_C(NULL != clr_pan);
	CHECK_EQUAL_C_STRING(clr_pan, enc_pan);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test case for common_coenc_coencpanfb group 
 *		Both clear PAN and suffix not present.
 *
 * @param[in]	common_coenc_coencpanfb		Test group
 * @param[in]	test_coencpanfb_set_pan_suffix_notpres	Test case
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpanfb, test_coencpanfb_set_pan_suffix_notpres)
{
	int ret;
	
	ret = set_pan_suffix(M_fml32, C_PAN_SUFFIX, C_PAN_CLR, 4);
	CHECK_C(SUCCEED == ret);
	ret = F_pres(M_fml32, C_PAN_SUFFIX, 0);
	CHECK_C(!ret);

}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test case for common_coenc_coencpanfb group 
 *		Suffix not present but clear PAN present.
 *
 * @param[in]	common_coenc_coencpanfb		Test group
 * @param[in]	test_coencpanfb_set_pan_suffix_panpres	Test case
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpanfb, test_coencpanfb_set_pan_suffix_panpres)
{
	int ret;
	char clr_pan[19] = "123456789098765432";
	char suffix[5] = {EOS};
	FLDLEN	fldlen = sizeof(suffix);
	
	CF_chg(M_fml32, C_PAN_CLR, 0, clr_pan, 0, FLD_STRING);
	
	ret = set_pan_suffix(M_fml32, C_PAN_SUFFIX, C_PAN_CLR, 4);
	CHECK_C(SUCCEED == ret);
	ret = F_get(M_fml32, C_PAN_SUFFIX, 0, suffix, &fldlen);
	CHECK_C(SUCCEED == ret);
	CHECK_C(strcmp(suffix, "5432")==0);

}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test case for common_coenc_coencpanfb group 
 *		Suffix and clear PAN present. Suffix should'n change.
 *
 * @param[in]	common_coenc_coencpanfb		Test group
 * @param[in]	test_coencpanfb_set_pan_suffix_sufpres	Test case
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpanfb, test_coencpanfb_set_pan_suffix_sufpres)
{
	int ret;
	char clr_pan[19] = "123456789098765432";
	char suffix[5] = "8888";
	char suffix2[5] = {EOS};
	FLDLEN	fldlen = sizeof(suffix);
	
	CF_chg(M_fml32, C_PAN_CLR, 0, clr_pan, 0, FLD_STRING);
	CF_chg(M_fml32, C_PAN_SUFFIX, 0, suffix, 0, FLD_STRING);
	
	ret = set_pan_suffix(M_fml32, C_PAN_SUFFIX, C_PAN_CLR, 4);
	CHECK_C(SUCCEED == ret);
	ret = F_get(M_fml32, C_PAN_SUFFIX, 0, suffix2, &fldlen);
	CHECK_C(SUCCEED == ret);
	CHECK_C(strcmp(suffix2, suffix)==0);

}

