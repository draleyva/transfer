/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Unit tests for core library, coproc object
 *
 * @remarks	Memory leaks should be tested on Linux with valgrind i.e.
 *		valgrind --leak-check=yes ./test/test_stdlib
 *
 * @author	Jason Veneracion
 *
 * @date	03 April 2020
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/coproc.c#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sldbg.h>
#include <slstring.h>
#include <dberr.h>
#include <coproc.h>

#include <CppUTest/TestHarness_c.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
/*---------------------------Functions------------------------------------*/
/** @cond INTERNAL */

/*------------------------------------------------------------------------*/
/**
 * @brief	Setup function for tests in the common_core_coproc group
 *
 * @param[in]	common_core_coproc Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_core_coproc)
{
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_core_coproc group
 *
 * @param[in]	common_core_coproc Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_core_coproc)
{
     ;
}


/*------------------------------------------------------------------------*/
/**
 * @brief	Test coproc
 *
 * @param[in]	common_core_coproc Test group
 * @param[in]	test_coproc_test1 Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_coproc, test_coproc_test1)
{
	int ret;
	char file[] = "slplck.lock";

	CHECK_C(SUCCEED == setenv("CTXUSR", "./", 1));
	
	ret = proc_lock (file, SLM_SET);
	printf ("ret is %d, expecting %d\n", ret, SUCCEED);
	CHECK_C(SUCCEED == ret);

	ret = proc_lock (file, SLM_SET);
	printf ("ret is %d, expecting %d\n", ret, FAIL);
	CHECK_C(FAIL == ret);
}



