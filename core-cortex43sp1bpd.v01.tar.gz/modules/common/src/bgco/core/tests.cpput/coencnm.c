/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Unit tests for core library, coencnm object
 *
 * @remarks	Memory leaks should be tested on Linux with valgrind i.e.
 *		valgrind --leak-check=yes ./test/test_stdlib
 *
 * @author	Jason Veneracion
 *
 * @date	31 March 2020
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/coencnm.c#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <slnfb.h>
#include <sldbg.h>
#include <sldtm.h>
#include <slstring.h>
#include <dberr.h>
#include <coencnm.h>

#include <CppUTest/TestHarness_c.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define FIRSTNAME_MAX_LEN	20
#define LASTNAME_MAX_LEN	20
#define TITLE_MAX_LEN		4
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
/*---------------------------Functions------------------------------------*/
/** @cond INTERNAL */

/*------------------------------------------------------------------'------*/
/**
 * @brief	Setup function for tests in the common_core_coencnm group
 *
 * @param[in]	common_core_coencnm Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_core_coencnm)
{
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_core_coencnm group
 *
 * @param[in]	common_core_coencnm Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_core_coencnm)
{
     ;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test coencnm
 *
 * @param[in]	common_core_coencnm Test group
 * @param[in]	test_get_instcode_cache Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_coencnm, test_coencnm_test1)
{
	int	ret = FAIL; 
	char 	encodedname[ISO_NAME_LEN+1] = "";
	char 	lastname[LASTNAME_MAX_LEN+1] = "Walker";
	char 	firstname[FIRSTNAME_MAX_LEN+1] = "Johnny";
	char 	title[TITLE_MAX_LEN+1] = "Mr"; 

	ret = iso_encname(encodedname, lastname, firstname, title, sizeof(encodedname)); 
	
	CHECK_C(FAIL != ret); 
	CHECK_C(0==strcmp("Walker/Johnny.Mr", encodedname));
	
}

