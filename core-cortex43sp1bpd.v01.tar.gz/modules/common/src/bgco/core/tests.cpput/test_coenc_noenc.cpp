/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Unit tests for coenc library
 *
 * @author	Dimitris Fourkiotis
 *
 * @date	30 Mar 2020
 *
 * @remark	This file contains tests that assume encryption IS NOT enabled. As
 * 		DOENCPAN macro is using a static global, enc/non-enc tests must
 * 		be executed as separate binaries
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/test_coenc_noenc.cpp#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <CppUTest/TestHarness_c.h>
#include <CppUTest/CommandLineTestRunner.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
/*---------------------------Functions----------------------------------*/
/** @cond INTERNAL */

/*---------------------------< coencpan >---------------------------*/
TEST_GROUP_C_WRAPPER(common_coenc_noenc_coencpan)
{
	TEST_GROUP_C_SETUP_WRAPPER(common_coenc_noenc_coencpan);
	TEST_GROUP_C_TEARDOWN_WRAPPER(common_coenc_noenc_coencpan);
};
/* Encrypt cases */
TEST_C_WRAPPER(common_coenc_noenc_coencpan, test_coencpan_encryptPanSize)
TEST_C_WRAPPER(common_coenc_noenc_coencpan, test_coencpan_encryptPanSize_ovrflw)
TEST_C_WRAPPER(common_coenc_noenc_coencpan, test_coencpan_encryptPanSize_longPan)
TEST_C_WRAPPER(common_coenc_noenc_coencpan, test_coencpan_encryptPan)
TEST_C_WRAPPER(common_coenc_noenc_coencpan, test_coencpan_encryptPan_longPan)
/* Decrypt cases */
TEST_C_WRAPPER(common_coenc_noenc_coencpan, test_coencpan_decryptPanSize)
TEST_C_WRAPPER(common_coenc_noenc_coencpan, test_coencpan_decryptPanSize_ovrflw)
TEST_C_WRAPPER(common_coenc_noenc_coencpan, test_coencpan_decryptPan)
/* Translate cases */
TEST_C_WRAPPER(common_coenc_noenc_coencpan, test_coencpan_translatePan)

/*------------------------------------------------------------------------*/
/**
 * @brief	Test runner
 *
 * @param[in]	argc - Number of command line parameters
 * @param[in]	argv - Array with command line parameters
 *
 * @retval	SUCCEED
 * @retval	FAIL
 */
/*------------------------------------------------------------------------*/
int main(int argc, char **argv)
{
	return RUN_ALL_TESTS(argc, argv);
}
/** @endcond */

