/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Unit tests for core library, cocchrfr object
 *
 * @remarks	Memory leaks should be tested on Linux with valgrind i.e.
 *		valgrind --leak-check=yes ./test/test_stdlib
 *
 * @author	Jason Veneracion
 *
 * @date	31 March 2020
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/cocchrfr.c#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <slnfb.h>
#include <sldbg.h>
#include <sldtm.h>
#include <slstring.h>
#include <dberr.h>
#include <cocchrfr.h>

#include <CppUTest/TestHarness_c.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
/*---------------------------Functions------------------------------------*/
/** @cond INTERNAL */

/*------------------------------------------------------------------------*/
/**
 * @brief	Setup function for tests in the common_core_cocchrfr group
 *
 * @param[in]	common_core_cocchrfr Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_core_cocchrfr)
{
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_core_cocchrfr group
 *
 * @param[in]	common_core_cocchrfr Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_core_cocchrfr)
{
     ;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test cocchrfr
 *
 * @param[in]	common_core_cocchrfr Test group
 * @param[in]	test_cochrfr_test1 Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_cocchrfr, test_cocchrfr_test1)
{
	int	ret = SUCCEED; 
	char	svcprx[80] ="test";
	long	svcid = 100;
	char	svcname[128] = "";
	char	tag[128] = "cacherefrsvc";
	
	ret = cchrfr_log_svc(svcprx, svcid, svcname);
	CHECK_C(SUCCEED == ret); 
	
	if (SUCCEED == ret)
	{
		ret = cchrfr_del_svc(svcprx, svcid);
		CHECK_C(SUCCEED == ret); 
	}
	
}

