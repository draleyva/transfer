/*---------------------------------------------------------------------------*/
/**
 * @file	
 * 
 * @author	Dimitris Fourkiotis
 *
 * @brief	Unit tests for coenc library, conecpan object, encryption disabled
 *
  * @remark	As DOENCPAN uses a static variable, encryption and non-encryption
 * 		tests must be run as separate binaries. Do not mix the cases.
 *
 * @date	20 Mar 2020
 * 
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/coencpan_noenc.c#1 $
 *
 * @copyright	FIS Global
 */
/*---------------------------------------------------------------------------*/
/** @cond INTERNAL */
/*------------------------------Includes-------------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sldbg.h>

#include <coencpan.h>

#include <CppUTest/TestHarness_c.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>

/*------------------------------Externs--------------------------------------*/
/*------------------------------Inlines--------------------------------------*/
/*------------------------------Macros---------------------------------------*/
/** Maximum PAN buffer size */
#define MAX_PAN_SIZE	19+1
/*------------------------------Enums----------------------------------------*/
/*------------------------------Typedefs-------------------------------------*/
/*------------------------------Globals--------------------------------------*/
/*------------------------------Statics--------------------------------------*/
/*------------------------------Prototypes-----------------------------------*/

/*------------------------------------------------------------------------*/
/**
 * @brief	Setup function for tests in the common_coenc_noenc_coencpan group
 *
 * @param[in]	common_coenc_noenc_coencpan Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_coenc_noenc_coencpan)
{
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);

	CHECK_EQUAL_C_INT(SUCCEED, unsetenv("CTXENCPAN"));
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_coenc_noenc_coencpan group
 *
 * @param[in]	common_coenc_noenc_coencpan Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_coenc_noenc_coencpan)
{
	;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan encryption.
 *
 * @param[in]	common_coenc_noenc_coencpan Test group
 * @param[in]	test_coencpan_encryptPanSize_encPan Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_noenc_coencpan, test_coencpan_encryptPanSize)
{
	const char *clr_pan = "5413330002001064";
	char *enc_pan = NULL;
	char enc_pan_buf[MAX_PAN_SIZE] = {EOS};

	enc_pan = encryptPanSize(clr_pan, enc_pan_buf, sizeof(enc_pan_buf));
	CHECK_C(NULL != enc_pan);
	CHECK_EQUAL_C_STRING(enc_pan, clr_pan);
	CHECK_EQUAL_C_STRING(enc_pan_buf, clr_pan);

}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan encryption and verify overflow behaviour.
 *
 * @param[in]	common_coenc_noenc_coencpan Test group
 * @param[in]	test_coencpan_encryptPan_ovrflw Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_noenc_coencpan, test_coencpan_encryptPanSize_ovrflw)
{
	const char *clr_pan = "5413330002001064";
	char *enc_pan = NULL;
	char short_enc_pan_buf[MAX_PAN_SIZE-5] = {EOS};

	enc_pan = encryptPanSize(clr_pan, short_enc_pan_buf, sizeof(short_enc_pan_buf));
	CHECK_C(NULL == enc_pan);
	CHECK_EQUAL_C_CHAR(EOS, *short_enc_pan_buf);
	if ( IS_CTXPROF_ALLOWED(CTXPROF_COREDUMP) )
	{
		CHECK_C(-1 != system("rm core_*"));
	}

}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan encryption for an imaginary pan longer than
 * 		(MAX_PAN_SIZE-1)
 *
 * @param[in]	common_coenc_noenc_coencpan Test group
 * @param[in]	test_coencpan_encryptPanSize Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_noenc_coencpan, test_coencpan_encryptPanSize_longPan)
{
	const char *long_clr_pan = "54133300020010640099";
	char *enc_pan = NULL;
	char enc_pan_buf[MAX_PAN_SIZE] = {EOS};

	enc_pan = encryptPanSize(long_clr_pan, enc_pan_buf, sizeof(enc_pan_buf));
	CHECK_C(NULL == enc_pan);
	CHECK_EQUAL_C_CHAR(EOS, *enc_pan_buf);
	if ( IS_CTXPROF_ALLOWED(CTXPROF_COREDUMP) )
	{
		CHECK_C(-1 != system("rm core_*"));
	}
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan encryption (static return).
 *
 * @param[in]	common_coenc_noenc_coencpan Test group
 * @param[in]	test_coencpan_encryptPan Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_noenc_coencpan, test_coencpan_encryptPan)
{
	char *clr_pan = "5413330002001064";
	char *enc_pan = NULL;
	char enc_pan_buf[MAX_PAN_SIZE] = {EOS};

	enc_pan = encryptPan(clr_pan, enc_pan_buf);
	CHECK_C(NULL != enc_pan);
	CHECK_EQUAL_C_STRING(enc_pan, clr_pan);
	CHECK_EQUAL_C_CHAR(EOS, *enc_pan_buf);

}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan encryption (static return), for a pan longer than
 * 		(MAX_PAN_SIZE-1)
 *
 * @param[in]	common_coenc_noenc_coencpan Test group
 * @param[in]	test_coencpan_encryptPan Test description
 *
 * @remarks	Difference with test_coencpan_encryptPanSize_longPan is that
 * 		since we don't request to store in the buffer, the input clear
 * 		(long) pan is returned with no exception.
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_noenc_coencpan, test_coencpan_encryptPan_longPan)
{
	char *long_clr_pan = "54133300020010640099";
	char *enc_pan = NULL;
	char enc_pan_buf[MAX_PAN_SIZE] = {EOS};

	enc_pan = encryptPan(long_clr_pan, enc_pan_buf);
	CHECK_C(NULL != enc_pan);
	CHECK_EQUAL_C_STRING(enc_pan, long_clr_pan);
	CHECK_EQUAL_C_CHAR(EOS, *enc_pan_buf);

}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan decryption and validate overflow.
 *
 * @param[in]	common_coenc_noenc_coencpan Test group
 * @param[in]	test_coencpan_decryptPanSize_ovrflw Test description
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_noenc_coencpan, test_coencpan_decryptPanSize_ovrflw)
{
	const char *enc_pan = "D16FCC1A194711D822D";
	char *clr_pan = NULL;
	char short_clr_pan_buf[MAX_PAN_SIZE-5] = {EOS};

	clr_pan = decryptPanSize(short_clr_pan_buf, sizeof(short_clr_pan_buf), enc_pan);
	CHECK_C(NULL == clr_pan);
	CHECK_EQUAL_C_CHAR(EOS, *short_clr_pan_buf);
	if ( IS_CTXPROF_ALLOWED(CTXPROF_COREDUMP) )
	{
		CHECK_C(-1 != system("rm core_*"));
	}
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan decryption.
 *
 * @param[in]	common_coenc_noenc_coencpan Test group
 * @param[in]	test_coencpan_encryptPanSize_encPan Test description
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_noenc_coencpan, test_coencpan_decryptPanSize)
{
	const char *enc_pan = "D16FCC1A194711D822D";
	char *clr_pan = NULL;
	char clr_pan_buf[MAX_PAN_SIZE] = {EOS};

	clr_pan = decryptPanSize(clr_pan_buf, sizeof(clr_pan_buf), enc_pan);
	CHECK_C(NULL != clr_pan);
	CHECK_EQUAL_C_STRING(enc_pan, clr_pan);
	CHECK_EQUAL_C_STRING(clr_pan_buf, clr_pan);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan decryption (static return).
 *
 * @param[in]	common_coenc_noenc_coencpan Test group
 * @param[in]	test_coencpan_decryptPan Test description
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_noenc_coencpan, test_coencpan_decryptPan)
{
	char *enc_pan = "D16FCC1A194711D822D";
	char *clr_pan = NULL;
	char clr_pan_buf[MAX_PAN_SIZE] = {EOS};

	clr_pan = decryptPan(clr_pan_buf, enc_pan);
	CHECK_C(NULL != clr_pan);
	CHECK_EQUAL_C_STRING(enc_pan, clr_pan);
	CHECK_EQUAL_C_CHAR(EOS, *clr_pan_buf);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan translation.
 *
 * @param[in]	common_coenc_noenc_coencpan Test group
 * @param[in]	test_coencpan_translatePan Test description
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_noenc_coencpan, test_coencpan_translatePan)
{
	char *old_enc_pan = "D16FCC1A194711D822D";
	char new_enc_pan_buf[MAX_PAN_SIZE] = {EOS};
	char *ret_new_enc_pan = NULL;

	ret_new_enc_pan = translatePan(old_enc_pan, NULL);
	CHECK_C(NULL != ret_new_enc_pan);
	CHECK_EQUAL_C_STRING(old_enc_pan, ret_new_enc_pan);
	CHECK_C(ret_new_enc_pan == old_enc_pan);
	CHECK_C(EOS == *new_enc_pan_buf);

	ret_new_enc_pan = translatePan(old_enc_pan, new_enc_pan_buf);
	CHECK_EQUAL_C_STRING(ret_new_enc_pan, new_enc_pan_buf);
	CHECK_C(ret_new_enc_pan == old_enc_pan);
}

/** @endcond */

