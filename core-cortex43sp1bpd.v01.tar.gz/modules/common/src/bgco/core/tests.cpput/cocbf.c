/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Unit tests for core library, cocbf object
 *
 * @remarks	Memory leaks should be tested on Linux with valgrind i.e.
 *		valgrind --leak-check=yes ./test/test_stdlib
 *
 * @author	Jason Veneracion
 *
 * @date	31 March 2020
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/cocbf.c#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <slntp.h>
#include <slnfb.h>
#include <sldbg.h>
#include <sldtm.h>
#include <slstring.h>
#include <dberr.h>
#include <cocbf.h>

#include <cocrd.fd.h>
#include <cocbfdef.h>

#include <CppUTest/TestHarness_c.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
/*---------------------------Functions------------------------------------*/
/** @cond INTERNAL */

/*------------------------------------------------------------------------*/
/**
 * @brief	Setup function for tests in the common_core_cocbf group
 *
 * @param[in]	common_core_cocbf Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_core_cocbf)
{
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_core_cocbf group
 *
 * @param[in]	common_core_cocbf Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_core_cocbf)
{
     ;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test cocbf
 *
 * @param[in]	common_core_cocbf Test group
 * @param[in]	test_cocbf_test1 Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_cocbf, test_cocbf_test1)
{
	int ret;
	short s;
	long date = 20200401, tempdate = 0;
	long time = 100000; 
	long stan = 123456; /* 6 digits only  */ 
	char tempstring[100] = ""; 
	FLDLEN len = 0; 
        char action, rspcode[2+1];

	FBFR *p_fb = (FBFR *)ntp_alloc("FML", NULL, 4096);
	CHECK_C(p_fb != NULL);

	s = MCL_AUTH;
	CHECK_C(FAIL != CF_chg(p_fb, C_MSGCLS, 0, (char *)&s, 0, FLD_SHORT));
	CHECK_C(s == cbf_get_msg_class(p_fb));

	s = MFN_REQ;
	CF_chg(p_fb, C_MSGFN, 0, (char *)&s, 0, FLD_SHORT);
	CHECK_C(s == cbf_get_msg_function(p_fb));

	s = MOR_ACQRPT;
	CF_chg(p_fb, C_TXNSRC, 0, (char *)&s, 0, FLD_SHORT);
	CHECK_C(cbf_chk_rpt(p_fb));
	s = MOR_ACQ;
	CF_chg(p_fb, C_TXNSRC, 0, (char *)&s, 0, FLD_SHORT);
	CHECK_C(!cbf_chk_rpt(p_fb));
	ret = cbf_update_to_rpt(p_fb);
	CHECK_C(cbf_chk_rpt(p_fb));
	ret = cbf_update_to_orig(p_fb);
	CHECK_C(!cbf_chk_rpt(p_fb));

	s = MAC_AUTH_APP;
	CF_chg(p_fb, C_ACTIONCODE, 0, (char *)&s, 0, FLD_SHORT);
	CHECK_C(cbf_chk_accept(p_fb));
	s = MAC_AUTH_DENIED;
	CF_chg(p_fb, C_ACTIONCODE, 0, (char *)&s, 0, FLD_SHORT);
	CHECK_C(!cbf_chk_accept(p_fb));

	ret = cbf_gen_rsp(p_fb, MAC_AUTH_APP, MRS_AAPP_HWI);
	CHECK_C(SUCCEED == ret);
	if (SUCCEED == ret)
	{
		CF_get(p_fb, C_ACTIONCODE, 0, (char *)&action, 0, FLD_CHAR); 
		CHECK_C(action == MAC_AUTH_APP); 
		CF_get(p_fb, C_RSPCODE, 0, (char *)rspcode, 0, FLD_STRING);
		CHECK_C(0 == strcmp(rspcode, MRS_AAPP_HWI));
	}

	/* ----- test cbf_gen_rsp2   ----- */ 

	F_del(p_fb, C_ACTIONCODE, 0); 
	F_del(p_fb, C_RSPCODE, 0); 
	ret = cbf_gen_rsp2(p_fb, MAC_AUTH_APP, MRS_AAPP_VIP, 
			RSPSRC_INTERFACE, RSPREAS_NET_BANNED, RJR_IF_REJECT, NULL, 
			"Test message");
	CHECK_C(SUCCEED == ret);
	if (SUCCEED == ret)
	{
		CF_get(p_fb, C_ACTIONCODE, 0, (char *)&action, 0, FLD_CHAR); 
		CHECK_C(action == MAC_AUTH_APP); 
		CF_get(p_fb, C_RSPCODE, 0, (char *)rspcode, 0, FLD_STRING);
		CHECK_C(0 == strcmp(rspcode, MRS_AAPP_VIP));
	}	
	/* ----- test cbf_gen_accept   ----- */ 

	F_del(p_fb, C_ACTIONCODE, 0); 
	F_del(p_fb, C_RSPCODE, 0); 
	ret = cbf_gen_accept(p_fb);
	CHECK_C(SUCCEED == ret);
	if (SUCCEED == ret)
	{
		CF_get(p_fb, C_ACTIONCODE, 0, (char *)&action, 0, FLD_CHAR); 
		CHECK_C(action == MAC_AUTH_APP); 
		CF_get(p_fb, C_RSPCODE, 0, (char *)rspcode, 0, FLD_STRING);
		CHECK_C(0 == strcmp(rspcode, MRS_AAPP_APP));
	}	
	/* ----- test cbf_set_rrn   ----- */ 

	CF_chg(p_fb, C_DATEXMIT, 0,  (char *)&date, 0, FLD_LONG); 
	CF_chg(p_fb, C_TIMEXMIT, 0,  (char *)&time, 0, FLD_LONG);
	CF_chg(p_fb, C_STAN,     0,  (char *)&stan, 0, FLD_LONG);
	
	ret = cbf_set_rrn(p_fb);
	CHECK_C(SUCCEED == ret);
	if (SUCCEED == ret )
	{
		len = sizeof(tempstring);
		CF_get(p_fb, C_RRN, 0, (char *)tempstring, &len, FLD_STRING); 
		CHECK_C(0 ==strcmp("009210123456", tempstring)); /* expect STAN value */ 
	}
	
	/* ----- test cbf_set_dtxmit   ----- */ 
	ret = cbf_set_dtxmit(p_fb); 
	CHECK_C(SUCCEED == ret);
	if (SUCCEED == ret)
	{
		date = utc_date(); 
		CF_get(p_fb, C_DATEXMIT, 0, (char *)&tempdate, 0, FLD_LONG); 
		
		CHECK_C(date == tempdate);
	}
	
	ntp_free((char *)p_fb);
	F_print(p_fb);
}

