/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Unit tests for core library, cosvcnm object
 *
 * @remarks	Memory leaks should be tested on Linux with valgrind i.e.
 *		valgrind --leak-check=yes ./test/test_stdlib
 *
 * @author	Jason Veneracion
 *
 * @date	03 April 2020
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/cosvcnm.c#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sldbg.h>
#include <slstring.h>
#include <dberr.h>
#include <cosvcnm.h>


#include <CppUTest/TestHarness_c.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
/*---------------------------Functions------------------------------------*/
/** @cond INTERNAL */

/*------------------------------------------------------------------------*/
/**
 * @brief	Setup function for tests in the common_core_cosvcnm group
 *
 * @param[in]	common_core_cosvcnm Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_core_cosvcnm)
{
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_core_cosvcnm group
 *
 * @param[in]	common_core_cosvcnm Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_core_cosvcnm)
{
     ;
}


/*------------------------------------------------------------------------*/
/**
 * @brief	Test cosvcnm
 *
 * @param[in]	common_core_cosvcnm Test group
 * @param[in]	test_cosvcnm_test1 Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_cosvcnm, test_cosvcnm_test1)
{
	int ret = SUCCEED;
	int ctr = 0; 
	char svcnames[10][50] = {"serv_alpha:SA", "serv_bravo:SB", "serv_charlie:SC", 
			"serv_delta:SD", "serv_echo:SE", "serv_foxtrot:SF", 
			"serv_golf:SG", "serv_hotel:SH", "serv_india:SI", 
			"serv_juliet:SJ" };
	
	/* it looks like it can only add if there are aliases and : */ 
	for (ctr = 0; ctr < 10 && SUCCEED == ret; ctr++)
	{
		ret = add_svcnm(svcnames[ctr]);
		CHECK_C(SUCCEED == ret);
	}
	
	if (SUCCEED == ret)
	{
		/* remove : and alias as it seems to only store first part of the string*/ 
		svcnames[0][strlen(svcnames[0])-3] = EOS; 
		CHECK_C(0 == strcmp(svcnames[0], ntp_svcnm_getfirst())); 
	}
	
	for (ctr = 1; ctr < 10 && SUCCEED == ret; ctr++)
	{
		/* remove : and alias as it seems to only store first part of the string*/ 
		svcnames[ctr][strlen(svcnames[ctr])-3] = EOS; 
		CHECK_C(0 == strcmp(svcnames[ctr], ntp_svcnm_getnext()));
	}

	
}




