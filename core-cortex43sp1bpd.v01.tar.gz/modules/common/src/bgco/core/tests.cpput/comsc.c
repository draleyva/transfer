/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Unit tests for core library, comsc object
 *
 * @remarks	Memory leaks should be tested on Linux with valgrind i.e.
 *		valgrind --leak-check=yes ./test/test_stdlib
 *
 * @author	Jason Veneracion
 *
 * @date	02 April 2020
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/comsc.c#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <slnfb.h>
#include <sldbg.h>
#include <slstring.h>
#include <dberr.h>
#include <comsc.h>

#include <dbmscrh.h>

#include <CppUTest/TestHarness_c.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>

/*---------------------------Externs------------------------------------*/

/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
/*---------------------------Functions------------------------------------*/
/** @cond INTERNAL */

/*------------------------------------------------------------------------*/
/**
 * @brief	Setup function for tests in the common_core_comsc group
 *
 * @param[in]	common_core_comsc Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_core_comsc)
{
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_core_comsc group
 *
 * @param[in]	common_core_comsc Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_core_comsc)
{
	;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test retrieving a numeric value, using the function for strings
 *
 * @param[in]	common_core_comsc Test group
 * @param[in]	test_comsc_get_msc_numeric_str Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_comsc, test_comsc_get_msc_numeric_str)
{
	char data[MSC_TAG_BUFFSIZE] = {EOS};
	
	CHECK_EQUAL_C_INT(FAIL, get_msc_numeric("printservice", 1, FLD_STRING, data));
	CHECK_EQUAL_C_INT(FAIL, get_msc_numeric4upd("printservice", 1, FLD_STRING, data));
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test retrieving a string
 *
 * @param[in]	common_core_comsc Test group
 * @param[in]	test_comsc_get_msc_string Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_comsc, test_comsc_get_msc_string)
{
	char data[MSC_TAG_BUFFSIZE] = {EOS};

	CHECK_EQUAL_C_INT(SUCCEED, get_msc_string("printservice", 1, data, sizeof(data), FALSE));
	CHECK_EQUAL_C_STRING("ENCPRINT", data);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test retrieving a string, causing buffer overflow
 *
 * @param[in]	common_core_comsc Test group
 * @param[in]	test_comsc_get_msc_string_ovrflw Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_comsc, test_comsc_get_msc_string_ovrflw)
{
	char short_data[5] = {EOS};

	CHECK_EQUAL_C_INT(FAIL, get_msc_string("printservice", 1, short_data, sizeof(short_data), FALSE));
	CHECK_EQUAL_C_CHAR(EOS, *short_data);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test retrieving a numeric tag, type FLD_SHORT
 *
 * @param[in]	common_core_comsc Test group
 * @param[in]	test_comsc_get_msc_numeric_short Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_comsc, test_comsc_get_msc_numeric_short)
{
	short data_short = 0;

	CHECK_EQUAL_C_INT(SUCCEED, get_msc_numeric("amexfilenum", 2, FLD_SHORT, (void *)&data_short));
	CHECK_EQUAL_C_INT(1, data_short);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test retrieving a numeric tag, type FLD_LONG
 *
 * @param[in]	common_core_comsc Test group
 * @param[in]	test_comsc_get_msc_numeric_long Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_comsc, test_comsc_get_msc_numeric_long)
{
	long data_long = 0;

	CHECK_EQUAL_C_INT(SUCCEED, get_msc_numeric("maxnumcard", 1, FLD_LONG, (void *)&data_long));
	CHECK_EQUAL_C_INT(100, data_long);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test retrieving a numeric tag, type FLD_DATE
 *
 * @param[in]	common_core_comsc Test group
 * @param[in]	test_comsc_get_msc_numeric_date Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_comsc, test_comsc_get_msc_numeric_date)
{
	long data_date = 0;

	CHECK_EQUAL_C_INT(SUCCEED, get_msc_numeric("accusrdata", 1, FLD_DATE, (void *)&data_date));
	CHECK_EQUAL_C_INT(22630831, data_date);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test retrieving a numeric tag, type FLD_DOUBLE
 *
 * @param[in]	common_core_comsc Test group
 * @param[in]	test_comsc_get_msc_numeric_date Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_comsc, test_comsc_get_msc_numeric_double)
{
	double data_double = -1.0;

	CHECK_EQUAL_C_INT(SUCCEED, get_msc_numeric("nxtbtchid", 1, FLD_DOUBLE, (void *)&data_double));
	CHECK_C(0.0 == data_double);
}


/*------------------------------------------------------------------------*/
/**
 * @brief	Test retrieving a string tag, checking exclusive lock
 *
 * @param[in]	common_core_comsc Test group
 * @param[in]	test_comsc_get_msc_string_lock Test description
 *
 * @remarks	Not sure how to test the exclusive lock, this test is not executed.
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_comsc, test_comsc_get_msc_string_lock)
{
	char data[MSC_TAG_BUFFSIZE] = {EOS};

	sql_abort();
	sql_begin();
	CHECK_EQUAL_C_INT(SUCCEED, get_msc_string("printservice", 1, data, sizeof(data), TRUE));
	CHECK_EQUAL_C_INT(FAIL, get_msc_string("printservice", 1, data, sizeof(data), TRUE));

}
