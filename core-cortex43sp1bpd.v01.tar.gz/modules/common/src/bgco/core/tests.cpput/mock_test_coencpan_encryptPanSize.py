#!/usr/bin/env python3

import sys
import os

aa_tuxFlds = {} # a dictionary with all the fields present in request

ctxprofile = os.environ['CTXPROFILE']
ctxprofile = int(ctxprofile[-18:], 16)

# CTXPROF_XT_PANSVC value
xt_pansvc = 0x0000000000001000

while True:
    input = sys.stdin.readline()
    
    if input == "\n":
        break

    input = input.strip("\n")

    fields = input.split("\t")

    aa_tuxFlds[fields[0]] = fields[1]

# add the encrypted PAN value
if ctxprofile & xt_pansvc:
    pan="We62100000000000ec"
else:
    pan="D65B7F93F9076E63293"

aa_tuxFlds["C_PAN"] = pan

# create output fielded buffer
for key in aa_tuxFlds.keys():
        print("+{}\t{}".format(key, aa_tuxFlds.get(key)))

#mark termination of the fielded buffer
print("")
