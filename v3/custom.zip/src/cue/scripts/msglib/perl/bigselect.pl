require "$ENV{'CUEMSGLIB'}/perl/SQLfunctions.pl";

sub init_bigselects 
{
	
	#Define card related select
	$crd_fields = " 
	crddet.amtrem,
	crddet.cycbegin,
	crddet.statcode,
	crddet.accno, 
	crddet.currcode, 
(crdvel.num_purch1+crdvel.num_purch2+crdvel.num_purch3) crdvel_num_purch,
(crdvel.val_purch1+crdvel.val_purch2+crdvel.val_purch3) crdvel_val_purch,
(crdvel.num_cash1+crdvel.num_cash2+crdvel.num_cash3) crdvel_val_cash,
(crdvel.val_cash1+crdvel.val_cash2+crdvel.val_cash3) crdvel_val_cash";

	$crd_conditions = "
	from crddet, OUTER crdvel
	where crddet.pan = ##PAN 
	and  crddet.seqno = ##SEQNO 
	and  crdvel.pan        = crddet.pan
	and  crdvel.seqno      = crddet.seqno
	and  crdvel.currcode   = crddet.currcode";
	
	#Define account related select
	$acc_fields = "
	accdet.accno, 
	accdet.currcode, 
	accdet.avlbal,
	accdet.blkamt, 
	accdet.credit_limit,
	acclimit.cash_amt_td,
	acclimit.cash_num_td,
	acclimit.purch_amt_td,
	acclimit.purch_num_td,
	acclimit.cycle_begin  ";

	$acc_conditions = "
	from crddet, crdacc, accdet, outer acclimit
	where crddet.pan       = ##PAN 
	and   crddet.seqno     = ##SEQNO 
	and   crddet.pan       = crdacc.pan
	and   crddet.seqno     = crdacc.seqno
	and   crdacc.accno     = accdet.accno
	and   crdacc.currcode  = accdet.currcode
	and   crdacc.instcode  = accdet.instcode
	and   acclimit.accno   = accdet.accno
	and   acclimit.currcode = accdet.currcode
	and   acclimit.instcode = accdet.instcode;";

	#initialise the card labels array with the crd fields
	@labels = split(/\,/,$crd_fields);
	foreach $f ( @labels ) 
	{
		$f =~ s/[ 	]+//g;
		$f =~ s/\n//g;
		$f =~ s/\(.*\)//g;
		push (@crd_labels, $f);
	}

	#initialise the card labels array with the crd fields
	@labels = split(/\,/,$acc_fields);
	foreach $f ( @labels ) 
	{
		$f =~ s/[ 	]+//g;
		$f =~ s/\n//g;
		$f =~ s/\(.*\)//g;
		push (@acc_labels, $f);
	}

#	print $crd_conditions;
#	foreach $name (@crd_labels) 
#	{ print "\nCrd label: $name "; }

	#Also init the tlog select
	&init_tlog_select;

}
 
sub build_acc_select {
	local ($pan, $seqno, *array) = @_;
	local ($select,$conditions,$SQLresults);
	local ($label,$acc,@accounts);
	
	#Build the select
	$conditions = $acc_conditions;
	$conditions =~ s/##PAN/'$pan' /;
	$conditions =~ s/##SEQNO/'$seqno' /;
	$select = "select ".$acc_fields." ".$conditions ;
	#print "$select\n";
	
	#Execute the select 
	$SQLresults = &runSQL($select);	
	chop($SQLresults);

	#Break the accounts up line by line 
	@accounts = split (/\n/,$SQLresults);
	
	foreach $acc (@accounts) {

		#For each returned line
		@acc = split (/\|/,$acc);

		foreach $i (0..$#acc_labels) {
		$acc_results{$acc_labels[$i]} = $acc[$i]; }

		$accno = $acc_results{'accdet.accno'};

		foreach $i (0..$#acc_labels) {
		$label = "Account($accno):[$acc_labels[$i]]";
		$array{$label} = $acc[$i]; }

	}

	$SQLresults;
}

sub build_crd_select {
	local ($pan, $seqno, *array) = @_;
	local ($select,$conditions,$SQLresults);

	#Build the select
	$conditions = $crd_conditions;
	$conditions =~ s/##PAN/'$pan' /;
	$conditions =~ s/##SEQNO/'$seqno' /;
	$select = "select ".$crd_fields." ".$conditions ;
	#print "$select\n";
	
	#Execute the select 
	$SQLresults = &runSQL($select);	
	chop($SQLresults);

	@results = split(/\|/,$SQLresults);

	foreach $i (0..$#crd_labels) {
		$array{$crd_labels[$i]} = $results[$i]; }

}

sub big_before {
	local ($pan, $seqno) = @_;

	#Clear out the big before array.
	undef %bigbefore;

	#Retrieve and store the card fields
	&build_crd_select($pan,$seqno,\%bigbefore);

	#Retrieve and build the account fields
	&build_acc_select($pan,$seqno,\%bigbefore);	

	#@keys = keys %bigbefore;	
	#foreach $name (sort @keys) 
	#{ print "\nBefore $name := [$bigbefore{$name}]"; }

}

sub big_after {
	local ($pan, $seqno) = @_;
	local ($SQLresults,@results);

	undef %big_after;

	#Retrieve and store the card fields
	&build_crd_select($pan,$seqno,\%bigafter);

	#Retrieve and build the account fields
	&build_acc_select($pan,$seqno,\%bigafter);	

#	@keys = keys %bigafter;	
#	foreach $name (sort @keys) 
#	{ print "\nAfter $name := [$bigafter{$name}]"; }

}

sub big_difference {

	local ($dif,@keys);

	$dif = "FALSE";
	@keys = keys %bigbefore;	
	foreach $name (@keys) 
	{ 
		if ($bigbefore{$name} ne $bigafter{$name}){
			print "$name\t Before:[$bigbefore{$name}] \tAfter:[$bigafter{$name}] \n";
			$dif = "TRUE";
		}

	}

	if ($dif eq "FALSE" ) { print "No Database Changes Detected.....\n";}

}

sub init_tlog_select  {


	$tlog_fields = "
		tlog.rrn,
		tlog.pan,
		tlog.msgcls,
		tlog.msgfn,
		tlog.txnsrc,
		tlog.msgclsorg,
		tlog.msgfnorg,
		tlog.txnstatus,
		tlog.amttxn,
		tlog.curtxn,
		tlog.acnum1,
		tlog.actioncode,
		tlog.rspcode ,
		tlog.inbtchid,
		tlog.inbtchseq,
		tlog.route_iid,
		tlog.aiid,
		tlog.afe,
		tlog.ife,
		tlog.amtset,
		tlog.curset,
		tlogerr.progname,
		tlogerr.dbgtext ";

	$tlog_conditions = "
		from tlog , outer tlogerr
		where tlog.id = ##TLOGID
		and tlog.id = tlogerr.tlogid;";

	#initialise the tlog labels array with the tlog fields
	@labels = split(/\,/,$tlog_fields);
	foreach $f ( @labels ) 
	{
		$f =~ s/[ 	]+//g;
		$f =~ s/\n//g;
		$f =~ s/\(.*\)//g;
		push (@tlog_labels, $f);
	}
}

sub dump_tlog {

	local ($tlogid) = @_;
	local ($select,$conditions,$SQLresults);
	
	#Build the select
	$conditions = $tlog_conditions;
	$conditions =~ s/##TLOGID/$tlogid /;
	$select = "select ".$tlog_fields." ".$conditions ;
	#print "$select\n";
	
	#Execute the select 
	$SQLresults = &runSQL($select);	
	chop($SQLresults);

	@results = split(/\|/,$SQLresults);
	
	print "Dump of Tlog Record ID:[$tlogid]\n";

	foreach $i (0..$#tlog_labels) {

		$results[$i] =~ s/^ +//;
		if ($results[$i] ne "" ) {
			print "$tlog_labels[$i]:\t[$results[$i]]\n"; 
		}
	}
}

#Test Harness
#&init_bigselects;
#&big_before("5547951000000003","0");
#&big_after("5547951000000003","0");
#$bigafter{"crddet.amtrem"} = "22";
#&dump_tlog("10964");
#&big_difference ;
#

1;

