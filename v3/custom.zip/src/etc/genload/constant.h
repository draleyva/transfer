/*-----------------------------------------------------------------------
 * Author       : Graeme Thomas
 *
 * Created      : 1998-11-07
 *
 * Purpose      :
 *
 * Comments     :
 *
 * Ident        : $Id$
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
/*---------------------------Constants------------------------------------*/
#ifndef __CONSTANT_H
#define __CONSTANT_H
/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <errno.h>
#include <ctype.h>
#include <cortex.h>
#include <cprdefs.h>
#include <sldbg.h>
#include <slluhn.h>
#include <slclp.h>
#include <slntp.h>
#include <slnfb.h>
#include <slcfp.h>
#include <sldtm.h>
#include <slstrip.h>
#include <slstrconv.h>
#include <comsc.h>

#include <coint.fd.h>
#include <enc.h>
#include <comsc.h>
#include <coevent.h>
#include <coclinit.h>
#include <dberr.h>

#include <dbcdet_xrh.h>		/* CRDDET_X */
#include <dbcrdpinmigrrh.h>	/* CRDPINMIGR */
#include <dbcustrh.h>           /* CUSTDET      */
#include <dbadetrh.h>           /* ACCDET */
#include <dbbrnrh.h>           /* BRANCH */
#include <dbinstrh.h>           /* INST */
#include <dbcfmtrh.h>		/* CRDPRODUCT	*/
#include <dbatyprh.h>           /* ACCTYPE */
#include <dbcdetrh.h>		/* CRDDET	*/
#include <dbcrbtrh.h>		/* CRDBTCH	*/
#include <dbcfmtrh.h>		/* CRDFMTR	*/
#include <dbcprorh.h>		/* CRDPRODUCT	*/
#include <dbcrdarh.h>		/* CRDACC*/
#include <dbcshsrh.h>		/* CRDSTHST*/
#include <dbcvelrh.h>		/*CRDVEL*/
#include <dbcpinrh.h>		/*CRDPIN*/
#include <dbccaprh.h>		/* CCAPPL	*/
#include <dbcaadrh.h>		/* CCAPPLADD	*/
#include <dbcrstrh.h>		/* CRDSTMT	*/
#include <dbcpinrh.h>		/* CRDPIN	*/
#include <dbcpclrh.h>		/* CORPCRDLNK	*/
#include <dbcacdrh.h>		/* CACCDET	*/
#include <dbaclmrh.h>		/* ACCLIMIT	*/
/* ---- CCS Start ---- */
#include <dbccsaccdetrh.h>      /* CCSACCDET    */
#include <dbccsschemerh.h>      /* CCSSCHEME, NMR009113 WLi 7/3/2003 */
/* ---- CCS End ------ */
/* TR 4786 - Extra tables needed for Merchant import */
#include <dbmrchrh.h>		/* MERCHANT	*/
#include <dbmschrh.h>		/* MRCHSCHEME	*/
#include <dbtposrh.h>		/* TERMPOS	*/
#include <dbmmonrh.h>		/* MRCHMON	*/
#include <dbpdefrh.h>		/* POSDEF	*/
#include <dbmmtdrh.h>		/* MRCHMTD	*/
#include <dbmontotrh.h>		/* MRCHMONTOT	*/

#include <dbcrdstbycrddet_id.h>	/* CRDSTMTgetbycrddet_id */
#include <dbcshsrh.h>		/* CDSTHST, NMR005373 WLi 13/03/2001 */
#include <dbaddsrh.h>		/* ADDITIONALS - Bug 4647 - MC 05/04/01 */
#include <dbclmrh.h>		/* CRDLIMIT - NMR010653	*/

/* ---- Additional information Custdet_x ---- */
#include <dbcust_xrh.h> /* PRT_CM_TELCO_NO */
/* ---- Additional Address (PARTY Module) ---- */
#include <dbprt_cmtrh.h> /* PRT_CMT */
#include <dbprt_cmptrh.h> /* PRT_CMPT */
#include <dbprt_pcmprh.h> /* PRT_PCMP */
#include <dbprt_prtrh.h> /* PRT_PRT */
#include <dbprt_pcmp_mediarh.h> /* PRT_PCMP_MEDIA */
#include <dbprt_cmrh.h>	/* PRT_CM */
#include <dbprt_partyrh.h> /* PRT_PERSON */
#include <dbprt_personrh.h> /* PRT_PERSON */
#include <dbprt_cm_paddrrh.h> /* PRT_CM_P_ADDR */
#include <dbprt_cm_eaddrrh.h> /* PRT_CM_E_ADDR */
#include <dbprt_cm_telnorh.h> /* PRT_CM_TELCO_NO */

#include <dbruleevalsetrh.h>	/* RULE_EVALSET_RET_DATA0_BUFFSIZE */
#include <genrules.h>		/* GENRULE */

#include <iacrdfmt.h>
#include "chararray.h"
#include "recdesc.h"
#include "parse.h"

#include <slstring.h>

/*---------------------------Externs------------------------------------*/
CLASS int        G_pins_cnt      I(= 0);
CLASS int        G_stmts_cnt     I(= 0);
CLASS char     **G_pins_needed   I(= NULL);
CLASS char     **G_stmts_needed  I(= NULL);
CLASS long       G_prvrecdate    I(= 0);
CLASS long       G_filenum       I(= 0);
CLASS char       G_infilenum[8];
CLASS char       G_inprdate[8];
CLASS char       G_bak[BUFSIZ];
CLASS long       G_err_cnt       I(= 0);
CLASS strconv_s *G_emconv        I(= NULL);
CLASS long       G_sysdate       I(= -1);
CLASS int        G_crdbtch_size  I(=100); /*JJA 30/9/1999 - NMR002723*/
ctxpublic char	G_errmsg[BUFSIZ];
/*---------------------------Macros-------------------------------------*/
#define STRSCPY(d, s)   strscpy(d, 0 == *s ? DB_EMPTY_STR : s )

#define PRG_NM "STATIC_IMPORT"
#ifdef  INFORMIX
#define DB_EMPTY_STR    " "
#else
#define DB_EMPTY_STR    ""
#endif

#define CLASSID 1

#define MAX_ACT 100
/*#define CRDBTCH_SIZE 100 - Replaced with G_crdbtch_size - JJA - NMR002723*/
#define  DEFAULT_CRDBTCH_SIZE 100

/* Record Types */
#define TYPE_HDR	0
#define TYPE_CUST	1
#define TYPE_ACC	2
#define TYPE_CRD	3
#define TYPE_CRDAPPL	4
#define TYPE_CRDEXPORT	5
#define TYPE_CRDACC	6
#define TYPE_CRDADATA   9
/* TR 4786 new types for merchant import */
#define TYPE_MERCHANT	7
#define TYPE_MRCHSCHEME	8
#define TYPE_TERMPOS	9
#define TYPE_LIMITS	10
#define TYPE_POSTALADDR	12
#define TYPE_TELCO	13
#define TYPE_ELECTROADDR	14
#define TYPE_TRL	99

/* Action Codes */
#define ACT_HDR		0
#define ACT_ADD		1
#define ACT_AMEND	2
#define ACT_DEL		3
#define ACT_ACCADD	4
/* Bug 4647 - MC 05/04/01
 * The Action Code 4 needs to be applicable for an associated add of
 * either accounts or cards.  The ACT_ACCADD above is an original
 * misnomer which is used purely for adding an associated account.
 */
#define ACT_ASSOC_ADD	4	/* New for Bug 4647 */
#define ACT_REISS_CRD	10
#define ACT_REP_LOST	11
#define ACT_REN_CRD	12
#define ACT_REISS_PIN	13
#define ACT_REP_FRAUD	14
#define ACT_CRDAPPL	20
#define ACT_NEW_CRD	21
#define ACT_TRL		99

#define RDE_INVALID_LENGTH	1
#define RDE_INVALID_CHAR	2
#define RDE_INVALID_HEADER	3
#define RDE_INVALID_VERSION	4
#define RDE_INVALID_ACTION	5
#define RDE_EMPTY_FIELD		6
#define RDE_INVALID_SET		7
#define RDE_LEADING_BLANK	8
#define LIMITS_CRD		1
#define LIMITS_ACC		2

/* NMR012692 - Temporary card batch type used for issuing additional cards
 * will be changed to CBTCH_ISSUE before inserting into database
 */
#define CBTCH_ISSUE_ADDNL_CARD	99

/*
 * NMR013959 - VM - Added facility to add error message to sdi error file
 * All error messages will start with tag ERROR_TAG
 */
#define ERROR_TAG	"ERROR:"
#define ERROR_VAR	(G_errmsg + strlen(G_errmsg))

/*
 * Macros for error numbers.
 * stdimp.ec defines the detailed message whos array
 * posistions are these macros.
 */
#define ERR_ERROR	0
#define ERR_DUPLICATE	1
#define ERR_NOTFOUND	2
#define ERR_DB		3
#define ERR_PARSE	4

#define NEVER_DATE	22630831
#define DFT_PRT_TYPE 0 /* 0 - main card holder */
#define NON_SOLICITATION "0"

#define AUTO_CRDPRODUCT	"AUTO"	/* Auto crdproduct.crdproduct	*/

/*---------------------------Enums--------------------------------------*/
/* HYPOM-1121 ZG 20.02.2007. */
enum
{
	E_DUPLICATE,
	E_NOTFOUND,
	E_PARSE,
	E_DELETE,
	E_CONSTRAINT,
	E_ERROR
};
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Statics------------------------------------*/
static ctxbool	M_notp  = FALSE; /*Not to use TPCALL*/
/*---------------------------Prototypes---------------------------------*/
/*
 * stdimp.ec
 */
ctxpublic int   isSet(int act);
/* NMR013959 - Added new parameter to explain the error using a macro */
ctxpublic void  err_msg (int line, char *cmd, char *buf, int err_ext);
ctxpublic void  create_error_file (char_array_t *cap);
ctxpublic char *read_line (char *buf, size_t len, FILE *fp, long *counter);

/* HYPOM-1121 ZG 20.02.2007. */
ctxpublic void err_msg2(int line, int err_type, char *obj_name, char *descr, char *buf);

/*
 * parse.c
 */
ctxpublic int loop_parse (long *rcp, FILE *fp);
ctxpublic int read_set (char *buf, char_array_t *set, long *rcp, FILE *fp);
ctxpublic int parse_acc (char *buf, ACCDET_t *p_accdet, ACCDET_HASH_t *p_accdet_k,
			char *ccsinfo, INST_t *p_inst, BRANCH_t *p_branch, CUSTDET_t *p_cust);
ctxpublic int parse_crddet (char     *buf,
		  CRDDET_t        *p_crddet,
		  CRDDET_HASH_t   *p_crddet_k,
		  char            *pan_clr,
		  char            *old_pan,
		  int             *old_seqno,
		  char            *priority,
		  char		  *delvaddr,
		  long             rec_cnt,
		  charge_crd_flds *chargecard_data,
		  non_crddet_flds_t *non_crddet_flds,
		  ACCDET_t	*p_acc,
		  CRDPRODUCT_t	*p_crdp,
		  CRDFORMAT_t	*p_crdfrmt,
		  INST_t	*p_inst,
		  CRDPINMIGR_t	*p_crdpinmigr);
ctxpublic int parse_ccappl (char *buf, CCAPPL_t *p_ccappl);
ctxpublic int parse_cust (char *buf, CUSTDET_t *p_custdet, 
						CUSTDET_HASH_t *p_custdet_k, CUSTDET_X_t *p_custdet_x);
ctxpublic int parse_crdstmt (char *buf, CRDSTMT_t *p_crdstmt, CRDSTMT_HASH_t *p_crdstmt_k);
ctxpublic int parse_crdpin (char *buf, CRDPIN_t *p_crdpin, CRDPIN_HASH_t *p_crdpin_k);
ctxpublic int parse_corpcrdlnk (char *buf, CORPCRDLNK_t *p_corpcrdlnk, CORPCRDLNK_HASH_t *p_corpcrdlnk_k,
							CRDDET_HASH_t *p_crddet, CRDDET_HASH_t *p_pri_crddet);
ctxpublic int parse_card_adddata ( char            *buf,           /* CN 8577 */
                                CRDDET_HASH_t   *p_crddet_k,
                                card_adddata_t  *p_card_adddata);


/* TR 4786 - Functions added for Merchant import */
ctxpublic int parse_merchant (char *buf, MERCHANT_t *p_merchant, MERCHANT_HASH_t *p_merchant_k);
ctxpublic int parse_mrchscheme (char *buf, MRCHSCHEME_t *p_mrchscheme, MRCHSCHEME_HASH_t *p_mrchscheme_k);
ctxpublic int parse_termpos (char *buf, TERMPOS_t *p_termpos, UNQ_TERMPOS_TERMCODE_t *p_termpos_k);


/* RJW NMR017200 20060826 add address flag*/
ctxpublic int parse_limits (char *buf, ACCLIMIT_t *p_acclimit,
	ACCLIMIT_HASH_t *p_acclimit_k, CRDLIMIT_t *p_crdlimit,
			CRDLIMIT_HASH_t *p_crdlimit_k, short *limtype, ctxbool *dateset);
			
/* ---- Additional Address (PARTY Module) ---- */
ctxpublic int parse_postal_addr (char *buf, PRT_CM_P_ADDR_t *p_p_addr, 
								PRT_CM_P_ADDR_PK_t *p_p_addr_k,
								PRT_PCMP_t *p_prt_pcmp,
								UNQ_PRT_PERSON_CUSTDET_ID_t *p_prt_person_k);
ctxpublic int parse_electro_addr (char *buf, PRT_CM_E_ADDR_t *p_e_addr, 
								PRT_CM_E_ADDR_PK_t *p_e_addr_k,
								PRT_PCMP_t *p_prt_pcmp,
								UNQ_PRT_PERSON_CUSTDET_ID_t *p_prt_person_k);
ctxpublic int parse_telco (char *buf, PRT_CM_TELCO_NO_t *p_cm_telco, 
								PRT_CM_TELCO_NO_PK_t *p_cm_telco_k,
								PRT_PCMP_t *p_prt_pcmp,
								UNQ_PRT_PERSON_CUSTDET_ID_t *p_prt_person_k);

/*
 * function.ec
 */
ctxpublic int pr_add_cust (char *buf, long rec_cnt);
ctxpublic int pr_add_acc (char *buf, long rec_cnt);
ctxpublic int pr_add_card (char *buf, long rec_cnt);
ctxpublic int pr_add_assoc_card( char * buf, long rec_cnt ); /* Bug 4647 */
ctxpublic int pr_add_crdacc (char *buf, long rec_cnt);
ctxpublic int pr_amend_cust (char *buf, long rec_cnt);
ctxpublic int pr_amend_acc (char *buf, long rec_cnt);
ctxpublic int pr_amend_card (char *buf, long rec_cnt);
ctxpublic int pr_del_cust (char *buf, long rec_cnt);
ctxpublic int pr_del_acc (char *buf, long rec_cnt);
ctxpublic int pr_del_card (char *buf, long rec_cnt);
ctxpublic int pr_del_crdacc (char *buf, long rec_cnt);
ctxpublic int pr_account_add (char *buf, long rec_cnt);
ctxpublic int pr_reiss_card (char *buf, long rec_cnt);
ctxpublic int pr_rep_lost (char *buf, long rec_cnt);
ctxpublic int pr_rep_fraud (char *buf, long rec_cnt);
ctxpublic int pr_ren_card (char *buf, long rec_cnt);
ctxpublic int pr_reiss_PIN (char *buf, long rec_cnt);
ctxpublic int pr_card_appl (char *buf, long rec_cnt);
ctxpublic int pr_new_card (char *buf, long rec_cnt);
ctxpublic int pr_card_adddata (char *buf, long rec_cnt);   /* CN 8577 */
ctxpublic int pr_file_trailer (char *buf, long rec_cnt);

/* TR 4786 - New functions for merchant import */
ctxpublic int pr_add_merchant (char *buf, long rec_cnt);
ctxpublic int pr_add_mrchscheme (char *buf, long rec_cnt);
ctxpublic int pr_add_termpos (char *buf, long rec_cnt);
ctxpublic int pr_amend_merchant (char *buf, long rec_cnt);
ctxpublic int pr_amend_mrchscheme (char *buf, long rec_cnt);
ctxpublic int pr_amend_termpos (char *buf, long rec_cnt);
ctxpublic int pr_del_merchant (char *buf, long rec_cnt);
ctxpublic int pr_del_mrchscheme (char *buf, long rec_cnt);
ctxpublic int pr_del_termpos (char *buf, long rec_cnt);

/* LMM NMR010653: - New functions for ACCLIMIT record	*/
ctxpublic int pr_add_limits(char *buf, long rec_cnt);
ctxpublic int pr_amend_limits(char *buf, long rec_cnt);
ctxpublic int pr_del_limits(char *buf, long rec_cnt);

/* New Fuctions for Additional Address record */
ctxpublic int pr_add_postal_addr (char *buf, long rec_cnt);
ctxpublic int pr_add_electro_addr (char *buf, long rec_cnt);
ctxpublic int pr_add_telco (char *buf, long rec_cnt);
ctxpublic int pr_del_postal_addr (char *buf, long rec_cnt);
ctxpublic int pr_del_electro_addr (char *buf, long rec_cnt);
ctxpublic int pr_del_telco (char *buf, long rec_cnt);

ctxpublic void validate_batches (void);
ctxpublic void invalidate_batches (void);
ctxpublic void set_dupcustok(ctxbool);
ctxpublic void set_dupaccok(ctxbool);
ctxpublic void set_batch_status (int batch_status);
ctxpublic void set_re_batch_status (int re_batch_status);
ctxpublic void set_ccardchklims (ctxbool ccardchklims);
ctxpublic void set_official( char * offcl_str );
ctxpublic void set_synccorpexpdate (ctxbool synccorpexpdate);
ctxpublic void set_duplimok (ctxbool duplimok);
/* 13971 - additional card can belong to different branch */
ctxpublic ctxbool allowDifferentBranches (void);

/*
 * cache.ec
 */
ctxpublic int lookup_isocode (ACCDET_t *p_accdet, short *p_isocode);
ctxpublic CRDPRODUCT_t *lookup_crdproduct (char *key);
ctxpublic CRDFORMAT_t *lookup_crdformat (char *key);

#endif
