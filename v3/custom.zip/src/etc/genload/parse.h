/*-----------------------------------------------------------------------
 * Author       : Graeme Thomas
 *
 * Created      : 1998-11-07
 *
 * Purpose      : Standard import parsing routines
 *
 * Comments     :
 *
 * Ident        : $Id$
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __PARSE_H
#define __PARSE_H
/*---------------------------Includes-----------------------------------*/
#include <coembnm.h>
/*---------------------------Typedefs-----------------------------------*/
typedef struct {
	int act;
	int type;
	int seq;
	int ver;
} Hdr; 


typedef struct {
	char debaccno [29];
	char acctypelim [3];
	int  chgcycle;
	double  totlim_amt;
	double  cashlim_amt;
	double  purchlim_amt;
	short  totlim_num;
	short cashlim_num;
	short purchlim_num;
} charge_crd_flds;

/*
 * CN 8577 card additional data record
 */
typedef struct {
        char    cvv2[4];
} card_adddata_t;


/* NMR011193 WLi 20/4/2004 */
typedef struct
{
	char    corpflag;
	char    corppan[20];
	short   corpseq;
	char    corpcust[9];
} corp_crd_flds_t;

/* sdods HYPO_DEV-28 adding CRDDET_X */
typedef struct
{
	char	design_ref[CRDDET_X_DESIGN_REF_BUFFSIZE];
	char	usrdata1[CRDDET_X_USRDATA1_BUFFSIZE];
	char	usrdata2[CRDDET_X_USRDATA2_BUFFSIZE];
	char	usrdata3[CRDDET_X_USRDATA3_BUFFSIZE];
	char	usrdata4[CRDDET_X_USRDATA4_BUFFSIZE];
	char	usrdata5[CRDDET_X_USRDATA5_BUFFSIZE];
	long	cat_issfee_id;
	long	cat_isscycfee_id;
} non_crddet_flds_t;

#define HDR_LEN	8
/*---------------------------Prototypes---------------------------------*/
ctxpublic Hdr *parse_hdr (char *buf);
ctxpublic void set_dftchgcyc( char *chgcle  );
ctxpublic void set_dftacctl( char *atl  );
ctxpublic int parse_corp_flds(char *buf, corp_crd_flds_t *p_corpflds);

/*---------------------------Globals------------------------------------*/

#endif
