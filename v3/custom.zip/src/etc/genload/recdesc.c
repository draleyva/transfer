/*-----------------------------------------------------------------------
 * 
 * File		: recdesc.c
 * 
 * Author	: Graeme Thomas
 * 
 * Created	: 1998-11-04
 * 
 * Purpose	: Record descriptions, and routines to use them
 * 
 * Comments	: 
 * 	
 * Ident	: $Id$
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.					 
 *-----------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include "constant.h"
#include <ctype.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*
 * Concatenate two symbols
 */
#define	CONCAT(a,b)	a##b

/*
 * Define a row type.  The fields are the type, length, usage, version,
 * and name
 */
#define TYPEROW(t,l,u,v,n)	{0, l, v, CONCAT(RD_,t), CONCAT(RD_,u), n}

/*---------------------------Enums--------------------------------------*/
enum field_type  { RD_a,  RD_an, RD_n, RD_d, RD_f };
enum field_usage { RD_CK, RD_FK, RD_O, RD_M };

/*---------------------------Typedefs-----------------------------------*/
typedef struct {
	int              offset;
	int              length;
	int              version;
	enum field_type  type;
	enum field_usage usage;
	char            *name;
} field_t;

typedef struct {
	int      action_code;
	int      record_type;
	int      max_version;
	field_t *fields;
	int     *lengths;
} record_t;
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
static char rcsid[] = "$Id$";

/*
 * Record header.  Defined as mandatory in all records.
 */
ctxprivate field_t M_record_hdr[] =
	{
		TYPEROW (n, 2, M,  1, "actioncode"),	/* Action code */
		TYPEROW (n, 2, M,  1, "recseq"),	/* Record sequence */
		TYPEROW (n, 2, M,  1, "rectype"),	/* Record type */
		TYPEROW (n, 2, M,  1, "recver"),	/* Record version */
		{0}
	};

/*
 * File header.  Must be the first record in each file.
 */
ctxprivate field_t M_file_hdr[] =
	{
		TYPEROW (n,  8, M,  1, "rechead"),	/* Record header */
		TYPEROW (a, 20, O,  1, "filename"),	/* File name */
		TYPEROW (n,  8, M,  1, "filenum"),	/* File number */
		TYPEROW (d,  8, M,  1, "processdate"),	/* Processing date */
		{0}
	};

/*
 * Customer record.  Used in:
 *	Add customer
 *	Amend customer
 *	Delete customer
 *	Card application
 *	New card
 */
ctxprivate field_t M_cust_rec[] =
	{
		TYPEROW (n,   8, M,  1, "rechead"),	/* Record header */
		TYPEROW (an,  4, CK, 1, "instcode"),	/* Institution code */
		TYPEROW (an,  8, O,  1, "branch"),	/* Branch code */
		TYPEROW (an,  12, CK, 1, "custcode"),	/* Customer code */
		TYPEROW (n,   1, M,  1, "custtype"),	/* Customer type */
		TYPEROW (an, 20, M,  1, "lastname"),	/* Customer last name */
		TYPEROW (an, 20, M,  1, "firstname"),	/* Customer first name */
		TYPEROW (an,  4, O,  1, "title"),	/* Customer title */
		TYPEROW (n,   1, M,  1, "sex" ),	/* Sex */
		TYPEROW (n,   1, M,  1, "married"),	/* Married */
		TYPEROW (n,   2, O,  1, "profession"),	/* Profession code */
		TYPEROW (an, 35, O,  1, "homeaddr1"),	/* Home address 1 */
		TYPEROW (an, 35, O,  1, "homeaddr2"),	/* Home address 2 */
		TYPEROW (an, 35, O,  1, "homeaddr3"),	/* Home address 3 */
		TYPEROW (an, 20, M,  1, "homecity"),	/* Home city */
		TYPEROW (an, 20, O,  1, "hometel"),	/* Home telephone */
		TYPEROW (an, 10, O,  1, "homepcode"),	/* Home postcode */
		TYPEROW (an,  8, O,  1, "pobox"),	/* Home PO box */
		TYPEROW (an, 35, O,  1, "workaddr1"),	/* Work address 1 */
		TYPEROW (an, 35, O,  1, "workaddr2"),	/* Work address 2 */
		TYPEROW (an, 35, O,  1, "workaddr3"),	/* Work address 3 */
		TYPEROW (an, 20, O,  1, "workcity"),	/* Work city */
		TYPEROW (an, 20, O,  1, "worktel"),	/* Work telephone */
		TYPEROW (an, 10, O,  1, "workpcode"),	/* Work postcode */
		TYPEROW (d,   8, O,  1, "birthdate"),	/* Date of birth */
		TYPEROW (an, 12, O,  1, "idnumber"),	/* Identification number */
		TYPEROW (n,   1, O,  1, "mailshots"),	/* Send mailshots */
		TYPEROW (an, 12, O,  1, "userdata1"),	/* User data 1 */
		TYPEROW (an, 12, O,  1, "userdata2"),	/* User data 2 */
		TYPEROW (an, 12, O,  1, "userdata3"),	/* User data 3 */
                /* Ver 2, CCS 1.1 additional data, NMR010987 WLi 01/3/2004 */
                TYPEROW (an,  2, O,  2, "prflang"),     /* Preferred language */
                TYPEROW (n,   1, O,  2, "addrind"),     /* Type of addr to use*/
		/* Ver 3, CCS additional data, NMR012664 - VM */
                TYPEROW (an, 64, O,  3, "email"),       /* Email address */
                TYPEROW (an, 20, O,  3, "fax"),         /* Fax number */
                TYPEROW (an, 32, O,  3, "usrdata4"),    /* User data 4 */
		/* CUSTDET_X record */
		TYPEROW (an, 22, O,  4, "national_id"),    /* National ID Number */
		TYPEROW (an, 127, O,  4, "cat_params"),    /* Categorisation parameters (BPD income level) */
		TYPEROW (an, 32, M,  4, "cust_id_ind"),    /* Customer ID Indicator, stored in CUSTDET_X.userdata1 */
		TYPEROW (an, 32, O,  4, "prim_off_no"),    /* Customer ID Indicator, stored in CUSTDET_X.userdata2 */
		TYPEROW (an, 32, O,  4, "passport_no"),    /* Customer ID Indicator, stored in CUSTDET_X.userdata3 */
		TYPEROW (an, 32, O,  4, "nax_id_no"),    /* Customer ID Indicator, stored in CUSTDET_X.userdata4 */
		TYPEROW (an, 32, O,  4, "segmnt"),    /* Customer ID Indicator, stored in CUSTDET_X.userdata5 */
		TYPEROW (an, 32, O,  4, "short_name"),    /* Customer ID Indicator, stored in CUSTDET_X.userdata6 */
				
		{0}
	};

/*
 * Account record.  Used in:
 *	Add account
 *	Amend account
 *	Delete account
 *	Card application
 *	New card
 * See also: assoc_account_rec
 */
ctxprivate field_t M_account_rec[] =
	{
		TYPEROW (n,   8, M,  1, "rechead"),	/* Record header */
		TYPEROW (an,  4, CK, 1, "instcode"),	/* Institution code */
		TYPEROW (an,  8, FK, 1, "branch"),	/* Branch code */
		TYPEROW (an, 28, CK, 1, "accno"),	/* Account number */
		TYPEROW (n,   3, CK, 1, "acccur"),	/* Account currency code */
		TYPEROW (an,  2, FK, 1, "acctype"),	/* Account type */
		TYPEROW (an,  2, FK, 1, "accstatus"),	/* Account status */
		TYPEROW (an,  12, FK, 1, "custcode"),	/* Customer code */
		TYPEROW (f,  12, M,  1, "creditlim"),	/* Credit limit */
		TYPEROW (an,  1, O,  2, "vipflag"),	/* VIP flag */
		TYPEROW (n,   1, O,  2, "classid"),	/* Class ID */
                                                        /* NMR9113 WLi 7/3/03 */
		/* NMR012664 - VM - ccsinfo record length extended */
                TYPEROW (an, 56, O,  3, "ccsinfo"),     /* CCS information */
		{0}
	};

/*
 * Associated Account record.  Used in:
 *	Add associated account
 * See also: account_rec
 * This is the same as the standard acount record, except that certain
 * "mandatory" fields are optional.
 */
ctxprivate field_t M_assoc_account_rec[] =
	{
		TYPEROW (n,   8, M,  1, "rechead"),	/* Record header */
		TYPEROW (an,  4, CK, 1, "instcode"),	/* Institution code */
		TYPEROW (an,  8, FK, 1, "branch"),	/* Branch code */
		TYPEROW (an, 28, CK, 1, "accno"),	/* Account number */
		TYPEROW (n,   3, CK, 1, "acccur"),	/* Account currency code */
		TYPEROW (an,  2, FK, 1, "acctype"),	/* Account type */
		TYPEROW (an,  2, FK, 1, "accstatus"),	/* Account status */
		TYPEROW (an,  12, FK, 1, "custcode"),	/* Customer code */
		TYPEROW (f,  12, O,  1, "creditlim"),	/* Credit limit */
		TYPEROW (an,  1, O,  2, "vipflag"),	/* VIP flag */
		TYPEROW (n,   1, O,  2, "classid"),	/* Class ID */
		{0}
	};

/*
 * Card record
 * Used in:
 *	Amend card
 *	Card reissue
 *	Card replace
 *	Card renew
 *	Delete card
 */
ctxprivate field_t M_card_rec[] =
	{
		TYPEROW (n,   8, M,  1, "rechead"),	/* Record header */
		TYPEROW (an,  4, FK, 1, "instcode"),	/* Institution code */
		TYPEROW (an,  8, FK, 1, "branch"),	/* Branch code */
		TYPEROW (an,  4, FK, 1, "crdproduct"),	/* Card product */
		TYPEROW (n,  19, CK, 1, "pan" ),	/* Card serial number */
		TYPEROW (n,   1, CK, 1, "seqno"),	/* Card sequence number */
		TYPEROW (n,   1, M,  1, "additional"),	/* Additional card number */
		TYPEROW (d,   8, O,  1, "effective"),	/* Effective date */
		TYPEROW (d,   8, O,  1, "expiry"),	/* Expiry date */
		TYPEROW (n,   2, O,  1, "cyclen"),	/* Cycle length */
		TYPEROW (n,   3, O,  1, "currcode"),	/* Card currency code */
		TYPEROW (f,  12, O,  1, "cyclim"),	/* Cycle limit (online) */
		TYPEROW (f,  12, O,  1, "offlim"),	/* Daily limit (offline) */
		TYPEROW (an,  2, O, 1, "statcode"),	/* Card status */
		TYPEROW (an, 32, O,  1, "emboss"),	/* Name to emboss */
		TYPEROW (an, 30, O,  1, "usrdata"),	/* User data */
		TYPEROW (an, 10, O,  1, "kinship"),	/* Relationship to primary */
		TYPEROW (an, 28, O, 1, "accno"),	/* Account number */
		TYPEROW (an,  12, FK, 1, "custcode"),	/* Customer code */
		TYPEROW (n,  19, O,  1, "oldpan"),	/* PAN of card being replaced */
		TYPEROW (n,   1, O,  1, "oldseqno"),	/* Seqno of card being replaced */
		TYPEROW (n,   1, O,  1, "urgent"),	/* Urgent issue */
		TYPEROW (an, 20, O,  2, "firstname"),	/* First name */
		TYPEROW (an, 20, O,  2, "lastname"),	/* Last name */
		TYPEROW (an,  4, O,  2, "title"),	/* Title */
		TYPEROW (d,   8, O,  2, "cycbegin"),	/* cycbegin */
		TYPEROW (n,   1, O,  3, "corp"),	/* corporate */
		TYPEROW (n,  19, O,  3, "corppan"),	/* corporate PAN */
		TYPEROW (n,   1, O,  3, "corpseq"),	/* corporate seq */
		TYPEROW (an,  8, O,  3, "corpcust"),	/* corporate cust */
		TYPEROW (an, 28, O,  4, "debaccno"),  	/* Debit-account number for charge cards*/ 
		TYPEROW (an,  2, O,  4, "acctypelim"),	/* Account limit type */
		TYPEROW (n,   3, O,  4, "chgcycle"),	/* Charge cycle number */
		TYPEROW (f,  12, O,  4, "totlim_amt"),	/* Max value of all transations per cycle */ 
		TYPEROW (f,  12, O,  4, "cashlim_amt"),	/* Max amount of cash transations per cycle */ 
		TYPEROW (f,  12, O,  4, "purchlim_amt"),/* Max value of purchase transations per cycle */ 
		TYPEROW (n,   4, O,  4, "totlim_num"),	/* Max number of all transations per cycle */ 
		TYPEROW (n,   4, O,  4, "cashlim_num"),	/* Max number of cash transations per cycle */ 
		TYPEROW (n,   4, O,  4, "purchlim_num"),/* Max number of purchase transations per cycle */ 
		TYPEROW (n,   1, O,  5, "delvaddr"),	/* TR 5557 Delivery address Home or Bank */
		TYPEROW (n,   3, O,  6, "svccode"),	/* SK NMR013955 Service Code */
	/* sdods HYPO_DEV-28 04/09/2009, issuer categorisation values */
		TYPEROW (an, 12, O,  7, "cat_issfee"),	/* fee category */
		TYPEROW (an, 12, O,  7, "cat_isscycfee"),/*cyclic-fee category*/
		TYPEROW (an, 12, O,  7, "cat_isscomm"),	/* commission category*/
		TYPEROW (an, 12, O,  7, "cat_issrisk"),	/* risk category */
		/* mvitolins HAAB_09_002_WO-3 27/11/2009 */
		TYPEROW (an, 12, O,  8, "design_ref"),	/* card design reference */
		{0}
	};

/*
 * New card record
 * Used in:
 *	Add card
 *	New card
 *	pr_add_assoc_card   - MC 05/04/01 - Bug 4647 
 * It differs from a normal card record in that the PAN and seqno are
 * optional.
 */
ctxprivate field_t M_newcard_rec[] =
	{
		TYPEROW (n,   8, M,  1, "rechead"),	/* Record header */
		TYPEROW (an,  4, FK, 1, "instcode"),	/* Institution code */
		TYPEROW (an,  8, FK, 1, "branch"),	/* Branch code */
		TYPEROW (an,  4, FK, 1, "crdproduct"),	/* Card product */
		TYPEROW (n,  19, O,  1, "pan" ),	/* Card serial number */
		TYPEROW (n,   1, O,  1, "seqno"),	/* Card sequence number */
/* changed from M to O, NMR004647 WLi 12/07/2001 */
		TYPEROW (n,   1, O,  1, "additional"),	/* Additional card number */
		TYPEROW (d,   8, O,  1, "effective"),	/* Effective date */
		TYPEROW (d,   8, O,  1, "expiry"),	/* Expiry date */
		TYPEROW (n,   2, O, 1, "cyclen"),	/* Cycle length */
		TYPEROW (n,   3, O,  1, "currcode"),	/* Card currency code */
		TYPEROW (f,  12, O,  1, "cyclim"),	/* Cycle limit (online) */
		TYPEROW (f,  12, O,  1, "offlim"),	/* Daily limit (offline) */
		TYPEROW (an,  2, O, 1, "statcode"),	/* Card status */
		TYPEROW (an, 32, O,  1, "emboss"),	/* Name to emboss */
		TYPEROW (an, 30, O,  1, "usrdata"),	/* User data */
		TYPEROW (an, 10, O,  1, "kinship"),	/* Relationship to primary */
		TYPEROW (an, 28, O, 1, "accno"),	/* Account number */
		TYPEROW (an,  12, FK, 1, "custcode"),	/* Customer code */
		TYPEROW (n,  19, O,  1, "oldpan"),	/* PAN of card being replaced */
		TYPEROW (n,   1, O,  1, "oldseqno"),	/* Seqno of card being replaced */
		TYPEROW (n,   1, O,  1, "urgent"),	/* Urgent issue */
		TYPEROW (an, 20, O,  2, "firstname"),	/* First name */
		TYPEROW (an, 20, O,  2, "lastname"),	/* Last name */
		TYPEROW (an,  4, O,  2, "title"),	/* Title */
		TYPEROW (d,   8, O,  2, "cycbegin"),	/* cycbegin */
		TYPEROW (n,   1, O,  3, "corp"),	/* corporate */
		TYPEROW (n,  19, O,  3, "corppan"),	/* corporate PAN */
		TYPEROW (n,   1, O,  3, "corpseq"),	/* corporate seq */
		TYPEROW (an,  8, O,  3, "corpcust"),	/* corporate cust */
		TYPEROW (an, 28, O,  4, "debaccno"),  	/* Debit-account number for charge cards*/ 
		TYPEROW (an,  2, O,  4, "acctypelim"),	/* Account limit type */
		TYPEROW (n,   3, O,  4, "chgcycle"),	/* Charge cycle number */
		TYPEROW (f,  12, O,  4, "totlim_amt"),	/* Max value of all transations per cycle */ 
		TYPEROW (f,  12, O,  4, "cashlim_amt"),	/* Max amount of cash transations per cycle */ 
		TYPEROW (f,  12, O,  4, "purchlim_amt"),/* Max value of purchase transations per cycle */ 
		TYPEROW (n,   4, O,  4, "totlim_num"),	/* Max number of all transations per cycle */ 
		TYPEROW (n,   4, O,  4, "cashlim_num"),	/* Max number of cash transations per cycle */ 
		TYPEROW (n,   4, O,  4, "purchlim_num"),/* Max number of purchase transations per cycle */ 
		TYPEROW (n,   1, O,  5, "delvaddr"),    /* TR 5557 Delivery address Home or Bank */
		TYPEROW (n,   3, O,  6, "svccode"),	/* SK NMR013955 Service Code */
	/* sdods HYPO_DEV-28 04/09/2009, issuer categorisation values */
		TYPEROW (an, 12, O,  7, "cat_issfee"),	/* fee category */
		TYPEROW (an, 12, O,  7, "cat_isscycfee"),/*cyclic-fee category*/
		TYPEROW (an, 12, O,  7, "cat_isscomm"),	/* commission category*/
		TYPEROW (an, 12, O,  7, "cat_issrisk"),	/* risk category */
		/* mvitolins HAAB_09_002_WO-3 27/11/2009 */
		TYPEROW (an, 12, O,  8, "design_ref"),	/* card design reference */
		{0}
	};

/*
 * Card record
 * Used in:
 *	Card replace
 */
ctxprivate field_t M_repcard_rec[] =
	{
		TYPEROW (n,   8, M,  1, "rechead"),	/* Record header */
		TYPEROW (an,  4, FK, 1, "instcode"),	/* Institution code */
		TYPEROW (an,  8, FK, 1, "branch"),	/* Branch code */
		TYPEROW (an,  4, FK, 1, "crdproduct"),	/* Card product */
		TYPEROW (n,  19, O,  1, "pan" ),	/* Card serial number */
		TYPEROW (n,   1, O,  1, "seqno"),	/* Card sequence number */
		TYPEROW (n,   1, M,  1, "additional"),	/* Additional card number */
		TYPEROW (d,   8, O,  1, "effective"),	/* Effective date */
		TYPEROW (d,   8, O,  1, "expiry"),	/* Expiry date */
		TYPEROW (n,   2, O, 1, "cyclen"),	/* Cycle length */
		TYPEROW (n,   3, O,  1, "currcode"),	/* Card currency code */
		TYPEROW (f,  12, O,  1, "cyclim"),	/* Cycle limit (online) */
		TYPEROW (f,  12, O,  1, "offlim"),	/* Daily limit (offline) */
		TYPEROW (an,  2, O, 1, "statcode"),	/* Card status */
		TYPEROW (an, 32, O,  1, "emboss"),	/* Name to emboss */
		TYPEROW (an, 30, O,  1, "usrdata"),	/* User data */
		TYPEROW (an, 10, O,  1, "kinship"),	/* Relationship to primary */
		TYPEROW (an, 28, O, 1, "accno"),	/* Account number */
		TYPEROW (an,  12, FK, 1, "custcode"),	/* Customer code */
		TYPEROW (n,  19, M,  1, "oldpan"),	/* PAN of card being replaced */
		TYPEROW (n,   1, M,  1, "oldseqno"),	/* Seqno of card being replaced */
		TYPEROW (n,   1, O,  1, "urgent"),	/* Urgent issue */
		TYPEROW (an, 20, O,  2, "firstname"),	/* First name */
		TYPEROW (an, 20, O,  2, "lastname"),	/* Last name */
		TYPEROW (an,  4, O,  2, "title"),	/* Title */
		TYPEROW (d,   8, O,  2, "cycbegin"),	/* cycbegin */
		TYPEROW (n,   1, O,  3, "corp"),	/* corporate */
		TYPEROW (n,  19, O,  3, "corppan"),	/* corporate PAN */
		TYPEROW (n,   1, O,  3, "corpseq"),	/* corporate seq */
		TYPEROW (an,  8, O,  3, "corpcust"),	/* corporate cust */
		TYPEROW (an, 28, O,  4, "debaccno"),  	/* Debit-account number for charge cards*/ 
		TYPEROW (an,  2, O,  4, "acctypelim"),	/* Account limit type */
		TYPEROW (n,   3, O,  4, "chgcycle"),	/* Charge cycle number */
		TYPEROW (f,  12, O,  4, "totlim_amt"),	/* Max value of all transations per cycle */ 
		TYPEROW (f,  12, O,  4, "cashlim_amt"),	/* Max amount of cash transations per cycle */ 
		TYPEROW (f,  12, O,  4, "purchlim_amt"),/* Max value of purchase transations per cycle */ 
		TYPEROW (n,   4, O,  4, "totlim_num"),	/* Max number of all transations per cycle */ 
		TYPEROW (n,   4, O,  4, "cashlim_num"),	/* Max number of cash transations per cycle */ 
		TYPEROW (n,   4, O,  4, "purchlim_num"),/* Max number of purchase transations per cycle */ 
		TYPEROW (n,   1, O,  5, "delvaddr"),    /* TR 5557 Delivery address Home or Bank */
		TYPEROW (n,   3, O,  6, "svccode"),	/* SK NMR013955 Service Code */
	/* sdods HYPO_DEV-28 04/09/2009, issuer categorisation values */
		TYPEROW (an, 12, O,  7, "cat_issfee"),	/* fee category */
		TYPEROW (an, 12, O,  7, "cat_isscycfee"),/*cyclic-fee category*/
		TYPEROW (an, 12, O,  7, "cat_isscomm"),	/* commission category*/
		TYPEROW (an, 12, O,  7, "cat_issrisk"),	/* risk category */
		/* mvitolins HAAB_09_002_WO-3 27/11/2009 */
		TYPEROW (an, 12, O,  8, "design_ref"),	/* card design reference */
		{0}
	};

/*
 * Key card record
 * Used in:
 * It differs from a normal card record in that all non-key fields are
 * optional.
 */
ctxprivate field_t M_keycard_rec[] =
	{
		TYPEROW (n,   8, M,  1, "rechead"),	/* Record header */
		TYPEROW (an,  4, FK, 1, "instcode"),	/* Institution code */
		TYPEROW (an,  8, O,  1, "branch"),	/* Branch code */
		TYPEROW (an,  4, O,  1, "crdproduct"),	/* Card product */
		TYPEROW (n,  19, CK, 1, "pan" ),	/* Card serial number */
		TYPEROW (n,   1, CK, 1, "seqno"),	/* Card sequence number */
		TYPEROW (n,   1, O,  1, "additional"),	/* Additional card number */
		TYPEROW (d,   8, O,  1, "effective"),	/* Effective date */
		TYPEROW (d,   8, O,  1, "expiry"),	/* Expiry date */
		TYPEROW (n,   2, O,  1, "cyclen"),	/* Cycle length */
		TYPEROW (n,   3, O,  1, "currcode"),	/* Card currency code */
		TYPEROW (f,  12, O,  1, "cyclim"),	/* Cycle limit (online) */
		TYPEROW (f,  12, O,  1, "offlim"),	/* Daily limit (offline) */
		TYPEROW (an,  2, O,  1, "statcode"),	/* Card status */
		TYPEROW (an, 32, O,  1, "emboss"),	/* Name to emboss */
		TYPEROW (an, 30, O,  1, "usrdata"),	/* User data */
		TYPEROW (an, 10, O,  1, "kinship"),	/* Relationship to primary */
		TYPEROW (an, 28, O,  1, "accno"),	/* Account number */
		TYPEROW (an,  12, FK, 1, "custcode"),	/* Customer code */
		TYPEROW (n,  19, O,  1, "oldpan"),	/* PAN of card being replaced */
		TYPEROW (n,   1, O,  1, "oldseqno"),	/* Seqno of card being replaced */
		TYPEROW (n,   1, O,  1, "urgent"),	/* Urgent issue */
		TYPEROW (an, 20, O,  2, "firstname"),	/* First name */
		TYPEROW (an, 20, O,  2, "lastname"),	/* Last name */
		TYPEROW (an,  4, O,  2, "title"),	/* Title */
		TYPEROW (d,   8, O,  2, "cycbegin"),	/* cycbegin */
		TYPEROW (n,   1, O,  3, "corp"),	/* corporate */
		TYPEROW (n,  19, O,  3, "corppan"),	/* corporate PAN */
		TYPEROW (n,   1, O,  3, "corpseq"),	/* corporate seq */
		TYPEROW (an,  8, O,  3, "corpcust"),	/* corporate cust */
		TYPEROW (an, 28, O,  4, "debaccno"),  	/* Debit-account number for charge cards*/ 
		TYPEROW (an,  2, O,  4, "acctypelim"),	/* Account limit type */
		TYPEROW (n,   3, O,  4, "chgcycle"),	/* Charge cycle number */
		TYPEROW (f,  12, O,  4, "totlim_amt"),	/* Max value of all transations per cycle */ 
		TYPEROW (f,  12, O,  4, "cashlim_amt"),	/* Max amount of cash transations per cycle */ 
		TYPEROW (f,  12, O,  4, "purchlim_amt"),/* Max value of purchase transations per cycle */ 
		TYPEROW (n,   4, O,  4, "totlim_num"),	/* Max number of all transations per cycle */ 
		TYPEROW (n,   4, O,  4, "cashlim_num"),	/* Max number of cash transations per cycle */ 
		TYPEROW (n,   4, O,  4, "purchlim_num"),/* Max number of purchase transations per cycle */ 
		TYPEROW (n,   1, O,  5, "delvaddr"),    /* TR 5557 Delivery address Home or Bank */
		TYPEROW (n,   3, O,  6, "svccode"),	/* SK NMR013955 Service Code */
	/* sdods HYPO_DEV-28 04/09/2009, issuer categorisation values */
		TYPEROW (an, 12, O,  7, "cat_issfee"),	/* fee category */
		TYPEROW (an, 12, O,  7, "cat_isscycfee"),/*cyclic-fee category*/
		TYPEROW (an, 12, O,  7, "cat_isscomm"),	/* commission category*/
		TYPEROW (an, 12, O,  7, "cat_issrisk"),	/* risk category */
		/* mvitolins HAAB_09_002_WO-3 27/11/2009 */
		TYPEROW (an, 12, O,  8, "design_ref"),	/* card design reference */
		{0}
	};

/*
 * pinreiss card record
 * Used in:
 * same as key card record except with urgent mandatory
 */
ctxprivate field_t M_pinreiss_rec[] =
	{
		TYPEROW (n,   8, M,  1, "rechead"),	/* Record header */
		TYPEROW (an,  4, FK, 1, "instcode"),	/* Institution code */
		TYPEROW (an,  8, O,  1, "branch"),	/* Branch code */
		TYPEROW (an,  4, O,  1, "crdproduct"),	/* Card product */
		TYPEROW (n,  19, CK, 1, "pan" ),	/* Card serial number */
		TYPEROW (n,   1, CK, 1, "seqno"),	/* Card sequence number */
		TYPEROW (n,   1, O,  1, "additional"),	/* Additional card number */
		TYPEROW (d,   8, O,  1, "effective"),	/* Effective date */
		TYPEROW (d,   8, O,  1, "expiry"),	/* Expiry date */
		TYPEROW (n,   2, O,  1, "cyclen"),	/* Cycle length */
		TYPEROW (n,   3, O,  1, "currcode"),	/* Card currency code */
		TYPEROW (f,  12, O,  1, "cyclim"),	/* Cycle limit (online) */
		TYPEROW (f,  12, O,  1, "offlim"),	/* Daily limit (offline) */
		TYPEROW (an,  2, O,  1, "statcode"),	/* Card status */
		TYPEROW (an, 32, O,  1, "emboss"),	/* Name to emboss */
		TYPEROW (an, 30, O,  1, "usrdata"),	/* User data */
		TYPEROW (an, 10, O,  1, "kinship"),	/* Relationship to primary */
		TYPEROW (an, 28, O,  1, "accno"),	/* Account number */
		TYPEROW (an,  12, FK, 1, "custcode"),	/* Customer code */
		TYPEROW (n,  19, O,  1, "oldpan"),	/* PAN of card being replaced */
		TYPEROW (n,   1, O,  1, "oldseqno"),	/* Seqno of card being replaced */
		TYPEROW (n,   1, M,  1, "urgent"),	/* Urgent issue */
		TYPEROW (an, 20, O,  2, "firstname"),	/* First name */
		TYPEROW (an, 20, O,  2, "lastname"),	/* Last name */
		TYPEROW (an,  4, O,  2, "title"),	/* Title */
		TYPEROW (d,   8, O,  2, "cycbegin"),	/* cycbegin */
		TYPEROW (n,   1, O,  3, "corp"),	/* corporate */
		TYPEROW (n,  19, O,  3, "corppan"),	/* corporate PAN */
		TYPEROW (n,   1, O,  3, "corpseq"),	/* corporate seq */
		TYPEROW (an,  8, O,  3, "corpcust"),	/* corporate cust */
		TYPEROW (an, 28, O,  4, "debaccno"),  	/* Debit-account number for charge cards*/ 
		TYPEROW (an,  2, O,  4, "acctypelim"),	/* Account limit type */
		TYPEROW (n,   3, O,  4, "chgcycle"),	/* Charge cycle number */
		TYPEROW (f,  12, O,  4, "totlim_amt"),	/* Max value of all transations per cycle */ 
		TYPEROW (f,  12, O,  4, "cashlim_amt"),	/* Max amount of cash transations per cycle */ 
		TYPEROW (f,  12, O,  4, "purchlim_amt"),/* Max value of purchase transations per cycle */ 
		TYPEROW (n,   4, O,  4, "totlim_num"),	/* Max number of all transations per cycle */ 
		TYPEROW (n,   4, O,  4, "cashlim_num"),	/* Max number of cash transations per cycle */ 
		TYPEROW (n,   4, O,  4, "purchlim_num"),/* Max number of purchase transations per cycle */ 
		TYPEROW (n,   1, O,  5, "delvaddr"),	/* TR 5557 Delivery address Home or Bank */
		TYPEROW (n,   3, O,  6, "svccode"),	/* SK NMR013955 Service Code */
	/* sdods HYPO_DEV-28 04/09/2009, issuer categorisation values */
		TYPEROW (an, 12, O,  7, "cat_issfee"),	/* fee category */
		TYPEROW (an, 12, O,  7, "cat_isscycfee"),/*cyclic-fee category*/
		TYPEROW (an, 12, O,  7, "cat_isscomm"),	/* commission category*/
		TYPEROW (an, 12, O,  7, "cat_issrisk"),	/* risk category */
		/* mvitolins HAAB_09_002_WO-3 27/11/2009 */
		TYPEROW (an, 12, O,  8, "design_ref"),	/* card design reference */
		{0}
	};
/*
 * crdacc card record
 * Used in: pr_add_crdacc, pr_del_crdacc
 * Only the crddet and accdet key fields are mandatory
 */
ctxprivate field_t M_crdacccard_rec[] =
	{
		TYPEROW (n,   8, M,  1, "rechead"),	/* Record header */
		TYPEROW (an,  4, FK, 1, "instcode"),	/* Institution code */
		TYPEROW (an,  8, O,  1, "branch"),	/* Branch code */
		TYPEROW (an,  4, O,  1, "crdproduct"),	/* Card product */
		TYPEROW (n,  19, CK, 1, "pan" ),	/* Card serial number */
		TYPEROW (n,   1, CK, 1, "seqno"),	/* Card sequence number */
		TYPEROW (n,   1, O,  1, "additional"),	/* Additional card number */
		TYPEROW (d,   8, O,  1, "effective"),	/* Effective date */
		TYPEROW (d,   8, O,  1, "expiry"),	/* Expiry date */
		TYPEROW (n,   2, O,  1, "cyclen"),	/* Cycle length */
		TYPEROW (n,   3, FK, 1, "currcode"),	/* Card currency code */
		TYPEROW (f,  12, O,  1, "cyclim"),	/* Cycle limit (online) */
		TYPEROW (f,  12, O,  1, "offlim"),	/* Daily limit (offline) */
		TYPEROW (an,  2, O,  1, "statcode"),	/* Card status */
		TYPEROW (an, 32, O,  1, "emboss"),	/* Name to emboss */
		TYPEROW (an, 30, O,  1, "usrdata"),	/* User data */
		TYPEROW (an, 10, O,  1, "kinship"),	/* Relationship to primary */
		TYPEROW (an, 28, O, 1, "accno"),	/* Account number */
		TYPEROW (an,  12, FK, 1, "custcode"),	/* Customer code */
		TYPEROW (n,  19, O,  1, "oldpan"),	/* PAN of card being replaced */
		TYPEROW (n,   1, O,  1, "oldseqno"),	/* Seqno of card being replaced */
		TYPEROW (n,   1, O,  1, "urgent"),	/* Urgent issue */
		TYPEROW (an, 20, O,  2, "firstname"),	/* First name */
		TYPEROW (an, 20, O,  2, "lastname"),	/* Last name */
		TYPEROW (an,  4, O,  2, "title"),	/* Title */
		TYPEROW (d,   8, O,  2, "cycbegin"),	/* cycbegin */
		TYPEROW (n,   1, O,  3, "corp"),	/* corporate */
		TYPEROW (n,  19, O,  3, "corppan"),	/* corporate PAN */
		TYPEROW (n,   1, O,  3, "corpseq"),	/* corporate seq */
		TYPEROW (an,  8, O,  3, "corpcust"),	/* corporate cust */
		TYPEROW (an, 28, O,  4, "debaccno"),  	/* Debit-account number for charge cards*/ 
		TYPEROW (an,  2, O,  4, "acctypelim"),	/* Account limit type */
		TYPEROW (n,   3, O,  4, "chgcycle"),	/* Charge cycle number */
		TYPEROW (f,  12, O,  4, "totlim_amt"),	/* Max value of all transations per cycle */ 
		TYPEROW (f,  12, O,  4, "cashlim_amt"),	/* Max amount of cash transations per cycle */ 
		TYPEROW (f,  12, O,  4, "purchlim_amt"),/* Max value of purchase transations per cycle */ 
		TYPEROW (n,   4, O,  4, "totlim_num"),	/* Max number of all transations per cycle */ 
		TYPEROW (n,   4, O,  4, "cashlim_num"),	/* Max number of cash transations per cycle */ 
		TYPEROW (n,   4, O,  4, "purchlim_num"),/* Max number of purchase transations per cycle */ 
		TYPEROW (n,   1, O,  5, "delvaddr"),	/* TR 5557 Delivery address Home or Bank */
		{0}
	};

	/*
	 * Card Application record
	 * Used in:
	 *	Card application
	 */
	ctxprivate field_t M_card_appl_rec[] =
		{
			TYPEROW (n,   8, M,  1, "rechead"),	/* Record header */
			TYPEROW (an, 16, O,  1, "appldata1"),	/* Application data 1 */
			TYPEROW (an, 16, O,  1, "appldata2"),	/* Application data 2 */
			TYPEROW (an, 16, O,  1, "appldata3"),	/* Application data 3 */
			TYPEROW (an, 16, O,  1, "appldata4"),	/* Application data 4 */
			TYPEROW (an, 16, O,  1, "appldata5"),	/* Application data 5 */
			TYPEROW (an, 16, O,  1, "appldata6"),	/* Application data 6 */
			TYPEROW (an, 16, O,  1, "appldata7"),	/* Application data 7 */
			TYPEROW (an, 16, O,  1, "appldata8"),	/* Application data 8 */
			TYPEROW (n,  16, O,  1, "scoredata"),	/* Credit scores */
			{0}
		};

	ctxprivate field_t M_card_export_rec[] =
		{
			TYPEROW (n,   8, M,  1, "rechead"),	/* Record header */
			TYPEROW (an,  4, FK, 1, "crdproduct"),	/* Card product */
			TYPEROW (n,  19, CK, 1, "pan" ),	/* Card serial number */
			TYPEROW (an, 28, FK, 1, "accno"),	/* Default account number */
			TYPEROW (n,   1, CK, 1, "seqno"),	/* Card sequence number */
			TYPEROW (an,  8, FK, 1, "brncode"),	/* Branch code */
			TYPEROW (d,   8, M,  1, "expdate"),	/* Expiry date */
			TYPEROW (d,   8, M,  1, "effdate"),	/* Effective date */
			TYPEROW (an,  3, M,  1, "cvv"),	/* Card verification value */
			TYPEROW (an,  1, M,  1, "pvki"),	/* PIN verification key index */
			TYPEROW (an,  4, M,  1, "pvv" ),	/* PIN verification value */
			TYPEROW (an,  4, O,  1, "title"),	/* Cardholder's title */
			TYPEROW (an, 20, O,  1, "firstname"),	/* Cardholder's first name */
			TYPEROW (an, 20, O,  1, "lastname"),	/* Cardholder's last name */
			TYPEROW (an, 35, M,  1, "addrl1"),	/* Cardholder's address 1 */
			TYPEROW (an, 35, M,  1, "addrl2"),	/* Cardholder's address 2 */
			TYPEROW (an, 35, M,  1, "addrl3"),	/* Cardholder's address 2 */
			TYPEROW (an, 20, M,  1, "homecity"),	/* Cardholder's home city */
			TYPEROW (an, 10, M,  1, "postcode"),	/* Cardholder's postcode */
			TYPEROW (an, 25, M,  1, "discret"),	/* Discretionary data */
			TYPEROW (an,  3, M,  1, "svvcode"),	/* Card service code */
			TYPEROW (an,  1, M,  1, "aci" ),	/* Authorization control indicator */
			TYPEROW (an,  3, M,  1, "cvc" ),	/* Card verification code */
			TYPEROW (an, 32, O,  1, "embossname"),	/* Embossed name */
			TYPEROW (an, 35, O,  1, "companyname"),	/* Company embossed name */
			TYPEROW (an, 79, O,  1, "track1"),	/* Track 1 data */
			TYPEROW (an, 40, O,  1, "track2"),	/* Track 2 data */
			TYPEROW (an, 30, O,  1, "embossl1"),	/* Embossed data 1 */
			TYPEROW (an, 30, O,  1, "embossl2"),	/* Embossed data 2 */
			TYPEROW (an, 30, O,  1, "embossl3"),	/* Embossed data 3 */
			TYPEROW (an, 30, O,  1, "embossl4"),	/* Embossed data 4 */
			TYPEROW (an, 30, O,  1, "rear"),	/* Rear data */
			TYPEROW (an,  4, O,  2, "title_t1"),	/* Title T1 */
			TYPEROW (an, 20, O,  2, "firstname_t1"),	/* First name T1 */
			TYPEROW (an, 20, O,  2, "lastname_t1"),	/* Last name T1 */
			TYPEROW (an, 26, O,  2, "encodename"),	/* Encoded name */
			{0}
		};

	/* TR 4786 -  Extra records for merchant import */
	/*
	 * Merchant record
	 * Used in:
	 *	Amend merchant 		( * NOTE: Add merchant in table below )
	 *	Delete merchant
	 */
	ctxprivate field_t M_merchant_rec_del[] =
		{
		TYPEROW (n,   8,M,  1, "rechead"),	/* Record header */
		TYPEROW (an,  4,CK, 1, "instcode"),
		TYPEROW (an,  8,O,  1, "brncode"),
		TYPEROW (an, 15,CK, 1, "mrchno"),
		TYPEROW (n,   1,O,  1, "posflag"),
		TYPEROW (n,   1,O,  1, "vipflag"),
		TYPEROW (n,   1,M,  1, "mrchstat"),
		TYPEROW (an, 25,M,  1, "name"),
		TYPEROW (an, 25,M,  1, "trading_as"),
		TYPEROW (an, 25,O,  1, "phy_address1"),
		TYPEROW (an, 25,O,  1, "phy_address2"),
		TYPEROW (an, 20,O,  1, "phy_city"),
		TYPEROW (an,  3,O,  1, "phy_state"),
		TYPEROW (an, 15,O,  1, "phy_postcode"),
		TYPEROW (an,  3,O,  1, "phy_countrycode"),
		TYPEROW (an, 25,M,  1, "address1"),
		TYPEROW (an, 25,M,  1, "address2"),
		TYPEROW (an, 20,O,  1, "city"),
		TYPEROW (an,  3,O,  1, "state"),
		TYPEROW (an, 15,O,  1, "postcode"),
		TYPEROW (an,  3,O,  1, "countrycode"),
		TYPEROW (an, 25,O,  1, "reg_address1"),
		TYPEROW (an, 25,O,  1, "reg_address2"),
		TYPEROW (an, 20,O,  1, "reg_city"),
		TYPEROW (an,  3,O,  1, "reg_state"),
		TYPEROW (an, 15,O,  1, "reg_postcode"),
		TYPEROW (an,  3,O,  1, "reg_countrycode"),
		TYPEROW (an, 15,M,  1, "head_office"),
		TYPEROW (an, 20,O,  1, "rnc"),
		TYPEROW (an, 25,O,  1, "taxreg"),
		TYPEROW (an, 20,O,  1, "contact1"),
		TYPEROW (an, 20,O,  1, "contact2"),
		TYPEROW (an, 20,O,  1, "contact3"),
		TYPEROW (an, 20,O,  1, "telno1"),
		TYPEROW (an, 20,O,  1, "telno2"),
		TYPEROW (an, 20,O,  1, "telno3"),
		TYPEROW (an, 20,O,  1, "faxno"),
		TYPEROW (an, 20,O,  1, "telex"),
		TYPEROW (an, 30,O,  1, "email"),
		TYPEROW (f,  12,O,  1, "msc"),
		TYPEROW (n,   1,O,  1, "msc_charge"),
		TYPEROW (n,   1,O,  1, "msc_calc"),
		TYPEROW (n,   4,O,  1, "msc_table"),
		TYPEROW (f,  12,O,  1, "retenamt"),
		TYPEROW (f,  12,O,  1, "retenpc"),
		TYPEROW (n,   1,M,  1, "stmtto"),
		TYPEROW (n,   1,M,  1, "stmtto_ho"),
		TYPEROW (n,   1,O,  1, "stmtfreq"),
		TYPEROW (n,   1,O,  1, "paymtype"),
		TYPEROW (n,   1,O,  1, "paymto"),
		TYPEROW (an,  9,O,  1, "sortcode"),
		TYPEROW (an, 28,O,  1, "accno"),
		TYPEROW (an, 30,O,  1, "accnm"),
		TYPEROW (an,  8,O,  1, "contrno"),
		TYPEROW (d,   8,O,  1, "contrdate"),
		TYPEROW (an,  3,O,  1, "contrsign"),
		TYPEROW (d,   8,O,  1, "contrcnx"),
		TYPEROW (n,   4,M,  1, "cyclen"),
		TYPEROW (d,   8,M,  1, "cycbegin"),
		TYPEROW (n,   4,M,  1, "no_imprntrs"),
		TYPEROW (an,  3,O,  1, "zonegeog"),
		TYPEROW (an,  3,O,  1, "zonecomer"),
		TYPEROW (an,  3,O,  1, "zonepostal"),
		TYPEROW (an,  3,FK, 1, "currcode"),
		TYPEROW (n,   4,M,  1, "acptbus"),
		TYPEROW (an,  1,O,  1, "taxcode"),
		TYPEROW (an,  3,FK, 1, "official"),
		TYPEROW (an, 12,O,  1, "usrdata1"),
		TYPEROW (an, 12,O,  1, "usrdata2"),
		TYPEROW (an, 12,O,  1, "usrdata3"),
		{0}
	};


	/* TR 4786 -  Extra records for merchant import */
	/*
	 * Merchant record
	 * Used in:
	 *	Add merchant only (others above)
	 */
	ctxprivate field_t M_merchant_rec_add[] =
		{
		TYPEROW (n,   8,M,  1, "rechead"),	/* Record header */
		TYPEROW (an,  4,CK, 1, "instcode"),
		TYPEROW (an,  8,O,  1, "brncode"),
		TYPEROW (an, 15,CK, 1, "mrchno"),
		TYPEROW (n,   1,M,  1, "posflag"),
		TYPEROW (n,   1,O,  1, "vipflag"),
		TYPEROW (n,   1,M,  1, "mrchstat"),
		TYPEROW (an, 25,M,  1, "name"),
		TYPEROW (an, 25,M,  1, "trading_as"),
		TYPEROW (an, 25,O,  1, "phy_address1"),
		TYPEROW (an, 25,O,  1, "phy_address2"),
		TYPEROW (an, 20,O,  1, "phy_city"),
		TYPEROW (an,  3,O,  1, "phy_state"),
		TYPEROW (an, 15,O,  1, "phy_postcode"),
		TYPEROW (an,  3,O,  1, "phy_countrycode"),
		TYPEROW (an, 25,M,  1, "address1"),
		TYPEROW (an, 25,M,  1, "address2"),
		TYPEROW (an, 20,O,  1, "city"),
		TYPEROW (an,  3,O,  1, "state"),
		TYPEROW (an, 15,O,  1, "postcode"),
		TYPEROW (an,  3,O,  1, "countrycode"),
		TYPEROW (an, 25,O,  1, "reg_address1"),
		TYPEROW (an, 25,O,  1, "reg_address2"),
		TYPEROW (an, 20,O,  1, "reg_city"),
		TYPEROW (an,  3,O,  1, "reg_state"),
		TYPEROW (an, 15,O,  1, "reg_postcode"),
		TYPEROW (an,  3,O,  1, "reg_countrycode"),
		TYPEROW (an, 15,M,  1, "head_office"),
		TYPEROW (an, 20,M,  1, "rnc"),
		TYPEROW (an, 25,O,  1, "taxreg"),
		TYPEROW (an, 20,O,  1, "contact1"),
		TYPEROW (an, 20,O,  1, "contact2"),
		TYPEROW (an, 20,O,  1, "contact3"),
		TYPEROW (an, 20,O,  1, "telno1"),
		TYPEROW (an, 20,O,  1, "telno2"),
		TYPEROW (an, 20,O,  1, "telno3"),
		TYPEROW (an, 20,O,  1, "faxno"),
		TYPEROW (an, 20,O,  1, "telex"),
		TYPEROW (an, 30,O,  1, "email"),
		TYPEROW (f,  12,O,  1, "msc"),
		TYPEROW (n,   1,O,  1, "msc_charge"),
		TYPEROW (n,   1,O,  1, "msc_calc"),
		TYPEROW (n,   4,O,  1, "msc_table"),
		TYPEROW (f,  12,O,  1, "retenamt"),
		TYPEROW (f,  12,O,  1, "retenpc"),
		TYPEROW (n,   1,M,  1, "stmtto"),
		TYPEROW (n,   1,M,  1, "stmtto_ho"),
		TYPEROW (n,   1,M,  1, "stmtfreq"),
		TYPEROW (n,   1,M,  1, "paymtype"),
		TYPEROW (n,   1,M,  1, "paymto"),
		TYPEROW (an,  9,O,  1, "sortcode"),
		TYPEROW (an, 28,O,  1, "accno"),
		TYPEROW (an, 30,O,  1, "accnm"),
		TYPEROW (an,  8,M,  1, "contrno"),
		TYPEROW (d,   8,M,  1, "contrdate"),
		TYPEROW (an,  3,M,  1, "contrsign"),
		TYPEROW (d,   8,O,  1, "contrcnx"),
		TYPEROW (n,   4,M,  1, "cyclen"),
		TYPEROW (d,   8,M,  1, "cycbegin"),
		TYPEROW (n,   4,M,  1, "no_imprntrs"),
		TYPEROW (an,  3,O,  1, "zonegeog"),
		TYPEROW (an,  3,O,  1, "zonecomer"),
		TYPEROW (an,  3,O,  1, "zonepostal"),
		TYPEROW (an,  3,FK, 1, "currcode"),
		TYPEROW (n,   4,M,  1, "acptbus"),
		TYPEROW (an,  1,FK, 1, "taxcode"),
		TYPEROW (an,  3,FK, 1, "official"),
		TYPEROW (an, 12,O,  1, "usrdata1"),
		TYPEROW (an, 12,O,  1, "usrdata2"),
		TYPEROW (an, 12,O,  1, "usrdata3"),
		{0}
	};

/*
 * Mrchscheme record
 * Used in:
 *	Add mrchscheme
 *	Amend mrchscheme
 *	Delete mrchscheme
 */
ctxprivate field_t M_mrchscheme_rec[] =
	{
		TYPEROW (n,  8, M,  1, "rechead"),	/* Record header */
		TYPEROW (an, 4,CK,  1, "instcode"),	/* Institution code */
		TYPEROW (an,15,CK,  1, "mrchno"),	/* Merchant number */
		TYPEROW (an,12,CK,  1, "scheme"),	/* Scheme */
		TYPEROW (f, 12, O,  1, "floorlim"),	/* Floor limit */
		TYPEROW (f, 12, O,  1, "msc"),	/* Merchant service charge % */
		TYPEROW (f, 12, O,  1, "msc_intl"),	/* International msc */
		TYPEROW (n,  4, O,  1, "crdacptbus"),	/* mcc */
		TYPEROW (an,15, O,  1, "schmrchno"),	/* mrchno for scheme */
		{0}
	};

/*
 * Termpos record
 * Used in:
 *	Add termpos
 *	Amend termpos
 *	Delete termpos
 */
ctxprivate field_t M_termpos_rec[] =
	{
		TYPEROW (n,  8, M,  1, "rechead"),	/* Record Header */
		TYPEROW (n,  4,FK,  1, "typeid"),	/* Terminal type id */
		TYPEROW (an,16, M,  1, "termcode"),	/* Terminal code */
		TYPEROW (n,  1, M,  1, "testflag"),	/* Test flag */
		TYPEROW (an,15,FK,  1, "mrchno"),	/* Merchant number */
		TYPEROW (an, 4,FK,  1, "instcode"),	/* Institution code */
		TYPEROW (n,  4, M,  1, "termno"),	/* Terminal number */
		TYPEROW (an,30, O,  1, "location"),	/* Location */
		{0}
	};

ctxprivate field_t M_limit_rec[] =
	{
		TYPEROW (n,  8, M,  1,	"rechead"),	/* Record Header */
		TYPEROW (an, 4,FK,  1,	"instcode"),	/* Institution code */
		TYPEROW (n,  2, M,  1,	"limtype"),	/* Limit type (card or account) */
		TYPEROW (an,28,FK,  1,  "ref1"),	/* Card Num or acc */
		TYPEROW (an,10,FK,  1,  "ref2"),	/* Card seq or curr */
		TYPEROW (n,  3, M,  1, 	"cycle_len"),	/* Cycle Length */
		TYPEROW (f, 12, M,  1, 	"totlim_amt"),	/* Total Limit */
		TYPEROW (f, 12, M,  1,	"cashlim_amt"),	/* Cash Limit */
		TYPEROW (f, 12, M,  1,	"purchlim_amt"),/* Purchase Limit */
		TYPEROW (n,  4, M,  1,	"totlim_num"),	/* Total Lim Number */
		TYPEROW (n,  4, M,  1,	"cashlim_num"),	/* Cash Lim Number */
		TYPEROW (n,  4, M,  1,	"totlim_num"),	/* Purchase Lim Number*/
		TYPEROW (d,  8, O,  2,	"cycle_begin"),	/* cycle begin date*/
		{0}
	};

/*
 * Postal Address record.  Used in:
 *	Add Postal Address
 *	Amend Postal Address
 */
ctxprivate field_t M_postaladdress_rec[] =
	{
		TYPEROW (n,   8, M,  1, "rechead"),	/* Record header */
		TYPEROW (an,  4, CK, 1, "instcode"),	/* Institution code */
		TYPEROW (an,  12, CK, 1, "custcode"),	/* Customer code (CIF) */
		TYPEROW (n,   4, M,  1, "contact_purpose"),	/* Contact Mechanism Purpose */
		TYPEROW (n,   4, M,  1, "contact_type"),	/* Contact Mechanism Type */
		TYPEROW (an, 40, M,  1, "address_1"),	/* Address line 1 */
		TYPEROW (an, 40, O,  1, "address_2"),	/* Address line 2 */
		TYPEROW (an, 40, O,  1, "address_3"),	/* Address line 3 */
		TYPEROW (an, 40, O,  1, "address_4"),	/* Address line 4 */
		TYPEROW (an, 40, O,  1, "address_5"),	/* Address line 5 */
		TYPEROW (an, 255, O,  1, "directions"),	/* Directions (free text) */
		TYPEROW (an, 40, O,  1, "city"),	/* City */
		TYPEROW (an, 10, O,  1, "postal_code"),	/* Post code */
		TYPEROW (n,  3, O,  1, "country_id"),	/* character ISO Alpha Country Code */
		TYPEROW (an, 40, O,  1, "province"),	/* Province if available */
		TYPEROW (an, 40, O,  1, "territory"),	/* Territory if available */
		TYPEROW (an, 40, O,  1, "state"),	/* State if available */
		TYPEROW (an, 40, O,  1, "county"),	/* County if available */
		TYPEROW (an, 40, O,  1, "region"),	/* Region if available */
		{0}
	};

/*
 * Telco record.  Used in:
 *	Add Telco
 *	Amend Telco	
 */
ctxprivate field_t M_telco_rec[] =
	{
		TYPEROW (n,   8, M,  1, "rechead"),	/* Record header */
		TYPEROW (an,  4, CK, 1, "instcode"),	/* Institution code */
		TYPEROW (an,  12, CK, 1, "custcode"),	/* Customer code (CIF) */
		TYPEROW (n,   4, M,  1, "contact_purpose"),	/* Contact Mechanism Purpose */
		TYPEROW (n,   4, M,  1, "contact_type"),	/* Contact Mechanism Type */
		TYPEROW (n, 10, O,  1, "area_code"),	/* Area code */
		TYPEROW (n, 13, M,  1, "contact_no"),	/* Contact number */
		TYPEROW (n, 10, O,  1, "extension_no"),	/* Extension */
		TYPEROW (n,  3, O,  1, "country_code"),	/* character ISO Alpha Country Code */
		{0}
	};

/*
 * Electronic Address  record.  Used in:
 *	Add Electronic Address 
 *	Amend Electronic Address 	
 */
ctxprivate field_t M_electroaddress_rec[] =
	{
		TYPEROW (n,   8, M,  1, "rechead"),	/* Record header */
		TYPEROW (an,  4, CK, 1, "instcode"),	/* Institution code */
		TYPEROW (an,  12, CK, 1, "custcode"),	/* Customer code (CIF) */
		TYPEROW (n,   4, M,  1, "contact_purpose"),	/* Contact Mechanism Purpose */
		TYPEROW (n,   4, M,  1, "contact_type"),	/* Contact Mechanism Type */
		TYPEROW (an, 100, M,  1, "electronic_address"),	/* Electronic address */
		{0}
	};

ctxprivate field_t M_file_trailer[] =
	{
		TYPEROW (n,  8, M,  1, "rechead"),	/* Record header */
		TYPEROW (a, 20, O,  1, "filename"),	/* File name */
		TYPEROW (n,  8, M,  1, "nrecs"),	/* Number of records */
		{0}
	};

ctxprivate record_t M_record_descriptions[] =
	{
		{ ACT_HDR,       TYPE_HDR,      1, M_file_hdr,          0},
		{ ACT_ADD,       TYPE_CUST,     4, M_cust_rec,          0},
		{ ACT_ADD,       TYPE_ACC,      3, M_account_rec,       0},
		{ ACT_ACCADD,    TYPE_ACC,      2, M_assoc_account_rec, 0},
		/* New for Bug 4647 - MC 05/04/01 */
		{ ACT_ASSOC_ADD, TYPE_CRD,	8, M_newcard_rec,	0 },	
		{ ACT_ADD,       TYPE_CRD,      8, M_newcard_rec,       0},
		{ ACT_ADD,       TYPE_CRDACC,   5, M_crdacccard_rec,    0},
		{ ACT_AMEND,     TYPE_CUST,     4, M_cust_rec,          0},
		{ ACT_AMEND,     TYPE_ACC,      3, M_account_rec,       0},
		{ ACT_AMEND,     TYPE_CRD,      8, M_card_rec,          0},
		{ ACT_REISS_CRD, TYPE_CRD,      8, M_card_rec,          0},
		{ ACT_REP_LOST,  TYPE_CRD,      8, M_repcard_rec,       0},
		{ ACT_REP_FRAUD, TYPE_CRD,      8, M_repcard_rec,       0},
		{ ACT_REN_CRD,   TYPE_CRD,      8, M_card_rec,          0},
		/* NMR004481 WLi 14/03/2001 */
		{ ACT_REISS_PIN, TYPE_CRD,      8, M_pinreiss_rec,      0},
		{ ACT_DEL,       TYPE_CUST,     4, M_cust_rec,          0},
		{ ACT_DEL,       TYPE_ACC,      3, M_account_rec,       0},
		{ ACT_DEL,       TYPE_CRD,      8, M_keycard_rec,       0},
		{ ACT_DEL,       TYPE_CRDACC,   5, M_crdacccard_rec,    0},
		{ ACT_CRDAPPL,   TYPE_CUST,     4, M_cust_rec,          0},
		{ ACT_CRDAPPL,   TYPE_ACC,      3, M_account_rec,       0},
		{ ACT_CRDAPPL,   TYPE_CRD,      8, M_card_rec,          0},
		{ ACT_CRDAPPL,   TYPE_CRDAPPL,  1, M_card_appl_rec,     0},
		{ ACT_NEW_CRD,   TYPE_CUST,     4, M_cust_rec,          0},
		{ ACT_NEW_CRD,   TYPE_ACC,      3, M_account_rec,       0},
		{ ACT_NEW_CRD,   TYPE_CRD,      8, M_newcard_rec,       0},
		{ ACT_NEW_CRD,   TYPE_POSTALADDR,1, M_postaladdress_rec,0},
		{ ACT_NEW_CRD,	 TYPE_ELECTROADDR,1, M_electroaddress_rec,0},
		{ ACT_NEW_CRD,	 TYPE_TELCO, 	1, M_telco_rec,		0},
		{ ACT_TRL,       TYPE_TRL,      1, M_file_trailer,      0},

		/* TR 4786 - New fields for merchant import */
		{ ACT_ADD,	 TYPE_MERCHANT,	1, M_merchant_rec_add,	0},
		{ ACT_ADD,	TYPE_MRCHSCHEME,1, M_mrchscheme_rec,	0},
		{ ACT_ADD,	 TYPE_TERMPOS,	1, M_termpos_rec,	0},
		{ ACT_AMEND,	 TYPE_MERCHANT,	1, M_merchant_rec_add,	0},
		{ ACT_AMEND,	TYPE_MRCHSCHEME,1, M_mrchscheme_rec,	0},
		{ ACT_AMEND,	 TYPE_TERMPOS,	1, M_termpos_rec,	0},
		{ ACT_DEL,	 TYPE_MERCHANT,	1, M_merchant_rec_del,	0},
		{ ACT_DEL,	TYPE_MRCHSCHEME,1, M_mrchscheme_rec,	0},
		{ ACT_DEL,	 TYPE_TERMPOS,	1, M_termpos_rec,	0},
		/* LMM - New recs for Account Lims records	*/
		{ ACT_ADD,	TYPE_LIMITS, 	2, M_limit_rec,		0},
		{ ACT_AMEND,	TYPE_LIMITS,	2, M_limit_rec,		0},
		{ ACT_DEL,	TYPE_LIMITS,	2, M_limit_rec,		0},
		/* New recs for Postal Address records	*/
		{ ACT_ADD,	TYPE_POSTALADDR, 	1, M_postaladdress_rec,		0},
		{ ACT_DEL,	TYPE_POSTALADDR,	1, M_postaladdress_rec,		0},
		/* New recs for Electronic Address records	*/
		{ ACT_ADD,	TYPE_ELECTROADDR, 	1, M_electroaddress_rec,		0},
		{ ACT_DEL,	TYPE_ELECTROADDR,	1, M_electroaddress_rec,		0},
		/* New recs for Telco records	*/
		{ ACT_ADD,	TYPE_TELCO, 	1, M_telco_rec,		0},
		{ ACT_DEL,	TYPE_TELCO,	1, M_telco_rec,		0},
		-1
	};
/*---------------------------Prototypes---------------------------------*/
ctxprivate record_t *find_recdesc (int action_code, int record_type);
ctxprivate int verify_fields (char *buf, int *reason, Hdr *hp, record_t *rp, int *parse_flag, long rcp);
ctxprivate int verify_float (char *buf, int len);

/*------------------------------------------------------------------------
 *
 * Function	:  recdesc_init
 *
 * Purpose	:  Initialize the dynamically-calculated fields of
 *		   the record descriptions.
 *
 * Parameters	:  None
 *
 * Returns	:  SUCCEED/FAIL.  The only way to fail is for
 *		   memory allocation errors.
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int recdesc_init (void)
{
	int       ret = SUCCEED;
	int       length;
	int       version;
	record_t *rp = M_record_descriptions;
	field_t  *fp;

	for (; rp->action_code >= 0; rp++)
	{
		rp->lengths = (int *)calloc (rp->max_version, sizeof (int));
		if (rp->lengths == NULL)
		{
			ret = FAIL;
			/* break; */continue;
		}

		version = 1;
		length = 0;
		for (fp = rp->fields; fp->length > 0; fp++)
		{
			/*
			 * If the version number increases, save the old
			 * length, and track versions.
			 */
			if (fp->version != version)
			{
				rp->lengths[version - 1] = length;
				version = fp->version;
			}

			/*
			 * Store the length-so-far as the offset, and
			 * keep counting.
			 */
			fp->offset = length;
			length += fp->length;
		}
		
		if (rp->max_version < version)
		{
			DBG_PRINTF((dbg_syserr, "!!!! SYSTEM CONFIG ERROR !!! "
				"rp->max_version(%d)<version(%d). "
				"Row: action: %d rec type %d",
				rp->max_version, version, rp->action_code, 
				rp->record_type));	
			ret=FAIL;
			break; /* <<<< BREAK!!! */
		}
		
		rp->lengths[version - 1] = length;
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  find_recdesc
 *
 * Purpose	:  find the record description for a given command
 *		   and type.
 *
 * Parameters	:  action_code
 *		   record_type
 *
 * Returns	:  A pointer to the record description, or NULL
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate record_t *find_recdesc (int action_code, int record_type)
{
	record_t *rp = M_record_descriptions;

	for (; rp->action_code >= 0; rp++)
	{
		if (rp->action_code == action_code &&
					rp->record_type == record_type)
			break;
	}

	return (rp->action_code >= 0) ? rp : NULL;
}
/*------------------------------------------------------------------------
 *
 * Function	:  verify_record
 *
 * Purpose	:  Check that the passed buffer matches the description.
 *
 * Parameters	:  buf - The input record
 *		   reason - The reason for the failure
 *
 * Returns	:  SUCCEED/FAIL
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
 ctxpublic int verify_record (char *buf, int *reason, int *parse_flag, long rcp)
 {
	int       ret = SUCCEED;
	int       len = strlen (buf);
	int       minlen = HDR_LEN;
	Hdr      *hp =  NULL;
	record_t *rp =  NULL;
	field_t  *fp =  NULL;
	
	if ((len >= minlen) &&
	    ((hp = parse_hdr (buf)) != NULL) &&
	    ((rp = find_recdesc (hp->act, hp->type)) != NULL) &&
	    (hp->ver > 0 && hp->ver <= rp->max_version) &&
	    (len == rp->lengths[hp->ver - 1])
	    )
	{
		/*
		 * If we get here the record looks plausible, in that
		 * it has a valid header and the record is of the correct
		 * length.  Now all that remains is to check the fields
		 * for correctness.
		 */
		ret = verify_fields (buf, reason, hp, rp, parse_flag, rcp);
	}
	else
	{
		ret = FAIL;
		if (len < minlen)
		{
                 *reason = RDE_INVALID_LENGTH;

                 if (*parse_flag == SUCCEED)
                  {
                    sprintf(ERROR_VAR, " ---------- FILE NOT PROCESSED ---------");
                    sprintf(ERROR_VAR, " FILE PARSING FAILED\n%s", ERROR_TAG);
                    *parse_flag = FAIL;
                  }

                 sprintf(ERROR_VAR, " Record (%ld): Invalid Record Length: ", rcp);
		}
                else if (hp == NULL)
		{
                 *reason = RDE_INVALID_HEADER;

                 if (*parse_flag == SUCCEED)
                  {
                    sprintf(ERROR_VAR, " ---------- FILE NOT PROCESSED ---------");
                    sprintf(ERROR_VAR, " FILE PARSING FAILED\n%s", ERROR_TAG);
                    *parse_flag = FAIL;
                  }

                 sprintf(ERROR_VAR, " Record (%ld): Invalid Record Header: ", rcp);
		}
                else if (rp == NULL)
		{
                 *reason = RDE_INVALID_ACTION;

		 if (*parse_flag == SUCCEED)
                  {
                    sprintf(ERROR_VAR, " ---------- FILE NOT PROCESSED ---------");
                    sprintf(ERROR_VAR, " FILE PARSING FAILED\n%s", ERROR_TAG);
                    *parse_flag = FAIL;
                  }

                 sprintf(ERROR_VAR, " Record (%ld): Invalid Record Action: ", rcp);
                }
                else if (hp->ver <= 0 || hp->ver > rp->max_version)
		{
                 *reason = RDE_INVALID_VERSION;

                 if (*parse_flag == SUCCEED)
                  {
                    sprintf(ERROR_VAR, " ---------- FILE NOT PROCESSED ---------");
                    sprintf(ERROR_VAR, " FILE PARSING FAILED\n%s", ERROR_TAG);
                    *parse_flag = FAIL;
                  }

                 sprintf(ERROR_VAR, " Record (%ld): Invalid Record Version: ", rcp);
		}
                else
		{
                 *reason = RDE_INVALID_LENGTH;

                 if (*parse_flag == SUCCEED)
                  {
                    sprintf(ERROR_VAR, " ---------- FILE NOT PROCESSED ---------");
                    sprintf(ERROR_VAR, " FILE PARSING FAILED\n%s", ERROR_TAG);
                    *parse_flag = FAIL;
                  }

                 sprintf(ERROR_VAR, " Record (%ld): Invalid Record Length: ", rcp);
                }
	}
DBG_PRINTF((dbg_proginfo, "Value of ret = %d", ret));

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  verify_fields
 *
 * Purpose	:  Check the fields of a record for validity
 *
 * Parameters	:  buf -> the record
 *		   reason -> the reason for failure
 *		   hp -> the header fields
 *		   rp -> the record description
 *                 parse_flag -> used in ther error file
 *
 * Returns	:  SUCCEED/FAIL
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int verify_fields (char *buf, int *reason, Hdr *hp, record_t *rp, int *parse_flag, long rcp)
{
	int      ret = SUCCEED;
	int      i, o;
	field_t *fp;

DBG_PRINTF((dbg_proginfo, "In verify fields"));
	for (fp = rp->fields;
	     fp->length > 0 && ret == SUCCEED && fp->version <= hp->ver;
	     fp++)
	{
		/*
		 * Check for invalid characters in the field
		 */
		switch (fp->type)
		{
			/*
			 * For the moment, anything will do
			 */
			case RD_an:
				break;
			
			/*
			 * Numeric fields must be numbers or spaces
			 */
			case RD_n:
				for (o = fp->offset, i = 0;
				     i < fp->length && ret == SUCCEED;
				     i++, o++)
				{
/*	AV 04.02.2002 Integration of NMR006592 into v25			*/
/*					if (!isdigit (buf[o]) &&	*/
/*					    !isspace (buf[o])		*/
					if (!isdigit ((unsigned char)buf[o]) &&
					    !isspace ((unsigned char)buf[o])
					   )
					{
						ret = FAIL;
						*reason = RDE_INVALID_CHAR;

                                                if (*parse_flag == SUCCEED) 
                                                 {
                                                   sprintf(ERROR_VAR, " ---------- FILE NOT PROCESSED ---------");
                                                   sprintf(ERROR_VAR, " FILE PARSING FAILED\n%s", ERROR_TAG);
                                                   *parse_flag = FAIL;
                                                 }
 
						sprintf(ERROR_VAR, " Record (%ld): Invalid character should be ", rcp);
                                                sprintf(ERROR_VAR, " numbers or spaces in Numeric field [%s]", fp->name);
                                                sprintf(ERROR_VAR, " at offset [%d]:", i);

						DBG_PRINTF((dbg_syserr,
							"Invalid character in field \"%s\" at offset %d",
							fp->name, i));
					}
				}
				break;

			/*
			 * Date fields must be fully numeric, or empty
			 */
			case RD_d:
				for (o = fp->offset, i = 0;
				     i < fp->length && ret == SUCCEED;
				     i++, o++)
				{
/*	AV 04.02.2002 Integration of NMR006592 into v25			*/
/*					if (!isdigit (buf[o])  &&	*/
/*					    !isspace (buf[o])		*/
					if (!isdigit ((unsigned char)buf[o]) &&
					    !isspace ((unsigned char)buf[o])
					   )
					{
						ret = FAIL;
						*reason = RDE_INVALID_CHAR;

                                                if (*parse_flag == SUCCEED)
                                                 {
                                                   sprintf(ERROR_VAR, " ---------- FILE NOT PROCESSED ---------");
                                                   sprintf(ERROR_VAR, " FILE PARSING FAILED\n%s", ERROR_TAG);
                                                   *parse_flag = FAIL;
                                                 }

                                                sprintf(ERROR_VAR, " Record (%ld): Invalid character should", rcp);
                                                sprintf(ERROR_VAR, " be fully numeric or empty in Date field [%s]", fp->name);
                                                sprintf(ERROR_VAR, " at offset [%d]:", i);

						DBG_PRINTF((dbg_syserr,
							"Invalid character in field \"%s\" at offset %d",
							fp->name, i));
					}
				}
				break;
			
			/*
			 * Alpha fields are alphabetic or spaces
			 */
			case RD_a:
				for (o = fp->offset, i = 0;
				     i < fp->length && ret == SUCCEED;
				     i++, o++)
				{
/*	AV 04.02.2002 Integration of NMR006592 into v25			*/
/*					if (!isalpha (buf[o]) &&	*/
/*					    !isspace (buf[o])		*/
					if (!isalpha ((unsigned char)buf[o]) &&
					    !isspace ((unsigned char)buf[o])
					   )
					{
						ret = FAIL;
						*reason = RDE_INVALID_CHAR;

                                                if (*parse_flag == SUCCEED)
                                                 {
                                                   sprintf(ERROR_VAR, " ---------- FILE NOT PROCESSED ---------");
                                                   sprintf(ERROR_VAR, " FILE PARSING FAILED\n%s", ERROR_TAG);
                                                   *parse_flag = FAIL;
                                                 }

                                                sprintf(ERROR_VAR, " Record (%ld): Invalid character should", rcp);
                                                sprintf(ERROR_VAR, " be alphabetic or spaces in Alpha field [%s]", fp->name);
                                                sprintf(ERROR_VAR, " at offset [%d]:", i);
                 
						DBG_PRINTF((dbg_syserr,
							"Invalid character in field \"%s\" at offset %d",
							fp->name, i));
					}
				}
				break;
			
			/*
			 * Floating fields are sufficiently complex that the
			 * only realistic approach is to throw the field at
			 * strtod.
			 */
			case RD_f:
				if (verify_float (buf+fp->offset, fp->length) == FAIL)
				{
				   ret = FAIL;
				   *reason = RDE_INVALID_CHAR;

                                   if (*parse_flag == SUCCEED)
                                    {
                                      sprintf(ERROR_VAR, " ---------- FILE NOT PROCESSED ---------");
                                      sprintf(ERROR_VAR, " FILE PARSING FAILED\n%s", ERROR_TAG);
                                      *parse_flag = FAIL;
                                    }

                                   sprintf(ERROR_VAR, " Record (%ld): Invalid character should", rcp);
                                   sprintf(ERROR_VAR, " be numeric float in field [%s]", fp->name);
                                   sprintf(ERROR_VAR, " at offset [%d]:", i);

				   DBG_PRINTF((dbg_syserr,
						"Invalid character in field \"%s\" at offset %d",
						fp->name, i));
				}
				break;

			/*
			 * The default case shouldn't happen
			 */
			default:
				break;
		}

		switch (fp->usage)
		{
			case RD_M:
			case RD_CK:
			case RD_FK:
				for (o = fp->offset, i = 0;
				     i < fp->length;
				     i++, o++)
				{
/*	AV 04.02.2002 Integration of NMR006592 into v25			*/
/*					if (!isspace (buf[o]))		*/
					if (!isspace ((unsigned char)buf[o]))
					{
						break;
					}
				}

				if (i == fp->length && ret == SUCCEED)
				{
				   ret = FAIL;
				   *reason = RDE_EMPTY_FIELD;

                                   if (*parse_flag == SUCCEED)
                                    {
                                      sprintf(ERROR_VAR, " ---------- FILE NOT PROCESSED ---------");
                                      sprintf(ERROR_VAR, " FILE PARSING FAILED\n%s", ERROR_TAG);
                                      *parse_flag = FAIL;
                                    }

                                   sprintf(ERROR_VAR, " Record (%ld): Empty mandatory field [%s]: ", rcp, fp->name);

				   DBG_PRINTF((dbg_syserr,
						"Empty mandatory field \"%s\"",
						fp->name));
				}
				break;
			
			case RD_O:
				break;
			
			/*
			 * The default case shouldn't happen
			 */
			default:
				break;
		}

/*	AV 04.02.2002 Integration of NMR006592 into v25			*/
/*		if ((ret == SUCCEED) && isspace (buf[fp->offset]))		*/
		if ((ret == SUCCEED) && isspace ((unsigned char)buf[fp->offset]))
		{
			/*
			 * The field has a leading blank.  The only time
			 * this should be allowed is if the entire field
			 * is blank, and it is optional.
			 */
			for (o = fp->offset, i = 0;
			     i < fp->length;
			     i++, o++)
			{
/*	AV 04.02.2002 Integration of NMR006592 into v25			*/
/*				if (!isspace (buf[o]))		*/
				if (!isspace ((unsigned char)buf[o]))
				{
					break;
				}
			}

			if (i != fp->length)
			{
			 ret = FAIL;
			 *reason = RDE_LEADING_BLANK;

                         if (*parse_flag == SUCCEED)
                          {
                           sprintf(ERROR_VAR, " ---------- FILE NOT PROCESSED ---------");
                           sprintf(ERROR_VAR, " FILE PARSING FAILED\n%s", ERROR_TAG);
                           *parse_flag = FAIL;
                          }

                          sprintf(ERROR_VAR, " Record (%ld): Leading Blank(s) in field [%s]: ", rcp, fp->name);

                          DBG_PRINTF((dbg_syserr,
					"Leading blank in field \"%s\"",
					fp->name));
			}
		}
	}
DBG_PRINTF((dbg_proginfo, "Value of ret = %d", ret));
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  verify_float
 *
 * Purpose	:  Check a float field for accuracy
 *
 * Parameters	:  buf -> field (note: not NUL terminated)
 *		   len -> length of field
 *
 * Returns	:  SUCCEED/FAIL
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int verify_float (char *buf, int len)
{
	int    ret = FAIL;
	char  *cp  = (char *)malloc (len + 1);
	char  *ep;
	double d;

	if (cp)
	{
		/*
		 * Copy the buffer
		 */
		strncpy (cp, buf, len);
		cp[len] = 0;

		/*
		 * Lose trailing blanks
		 */
		stp_right (cp);

		/*
		 * Convert the number.  The end pointer should
		 * now point to the trailing NUL.  If it doesn't,
		 * the number is malformed.
		 */
		d = strtod (cp, &ep);
		if (*ep == '\0')
		{
			ret = SUCCEED;
		}

		free (cp);
	}

	return ret;
}
