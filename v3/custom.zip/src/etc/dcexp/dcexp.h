/*---------------------------Macros-------------------------------------*/
#define TAGNM		"DCEXP"
#define	DCORDER_TAG	"DCEXPOrdercode"
#define	SEP_MAX_LEN	8
#define	SIZTK1		79
#define	SIZTK2		40
#define	SIZEMB		30
#define	SIZCOMP		30
#define TITLE_MAX_LEN	4
#define FIRSTNAME_MAX_LEN	20
#define LASTNAME_MAX_LEN	20
#define	EXTENDED_NAME_LEN	256
#define	NAME_MAX_LEN	26
#define	AC_COMPANY_MAX_LEN	21
#define	AC_EMBNAME_MAX_LEN	21
#define	AC_INDENT_MAX_LEN	23
#define	MAX_CRDPROD_COUNT	100
#define MAX_BUFFER_SIZE 1024
#define	SPACE_STR		" "
#define	ONE			1

#define	EVMODULE	"ia"
#define	EVPROGRAM	"dcexp"
#define	EVENT_XTRACT_FAIL	"crdextrfail"
#define	MAPDIR		"/map"
#define	CUSTCODE_DUMMY	"99999999"
#define STATIC_IMPORT	"STATIC_IMPORT"
#define PAYROLL		"PAYROLL"

/*---------------------------Typedefs-----------------------------------*/
typedef struct convs
{
	char	fldnm[40];	/* Field name */
	short	fldlen;		/* Field len  */
	short	fldtyp;		/* Field type */
	char	*data;		/* Ptr to data*/
	int	(*p_convfn)(struct convs *);
				/* Conv func  */
} dcexp_conv_t;

typedef struct
{
	char	home_phone[36];
	char	work_phone[36];
	char	addrl1[40];
	char	addrl2[40];
	char	addrl3[40];
} addit_info_t;

enum
{
	FLD_SHT = 0,
	FLD_LNG,
	FLD_CHR,
	FLD_FLT,
	FLD_DBL,
	FLD_STR,
	FLD_ARR,
	FLD_INT
};

/*---------------------------Prototypes---------------------------------*/
ctxprivate int	main_loop(void);
ctxprivate int	unlink_files(void);
ctxprivate int	open_files(void);
ctxpublic int	init(int argc, char **argv);
ctxpublic int	uninit(int so_far);
ctxprivate void	sigdisp( int sig);
ctxprivate int 	output_record(CRDDET_t *p_cd, crdmorejo_spec_t *p_crdinfo,
						CRDFORMAT_t *p_crdfmt);
ctxprivate int	get_crdformat( CRDPRODUCT_t *p_cp, CRDFORMAT_t *p_crdfmt);
ctxprivate int 	get_company_name(char *output, CRDDET_t *p_cd);
ctxprivate int	write_header(void);
ctxprivate int	write_map_header(void);
ctxprivate int	write_map_trailer(void);
ctxprivate int 	parse_batchid(char * p_batch, char * p_parsed);
ctxprivate int 	process_rec(dcexp_conv_t *conv_table);
ctxprivate int	cnv_emistyp(dcexp_conv_t *);
ctxprivate int	cnv_addit(dcexp_conv_t *);
ctxprivate int	cnv_expdate(dcexp_conv_t *);
ctxprivate int	cnv_expdatMMYY(dcexp_conv_t *);
ctxprivate int	cnv_custname(dcexp_conv_t *);
ctxprivate int	cnv_addname(dcexp_conv_t *);
ctxprivate int	cnv_ddmmyy(dcexp_conv_t *);
ctxprivate int	cnv_mmddyyyy(dcexp_conv_t *);
ctxprivate int	cnv_cardcount(dcexp_conv_t *);
ctxprivate int	cnv_acctyp(dcexp_conv_t *);
ctxprivate int	cnv_dbl0(dcexp_conv_t *);
ctxprivate int	cnv_dbl2(dcexp_conv_t *);
ctxprivate int	cnv_cardtyp(dcexp_conv_t *);
ctxprivate int 	cnv_brncode(dcexp_conv_t *);
ctxprivate int	cnv_isstyp(dcexp_conv_t *);
ctxprivate int cnv_chkdelivtype(dcexp_conv_t *p_conv);
ctxprivate void setup_signal_handlers(void);
ctxprivate long	mmddyyyy(long yyyymmdd);
#ifdef OLDCODE
ctxprivate void	parse_eor(char *eor);
ctxprivate int 	get_pinblk (CRDDET_t *p_crddet, char *buf);
#endif
