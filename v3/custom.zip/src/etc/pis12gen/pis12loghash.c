/*-----------------------------------------------------------------------
 * 
 * File		: pis12loghash.c
 * 
 * Author	: Ruslans Vasiljevs
 * 
 * Created	: 29/06/2022
 *
 * Purpose	: Functions of hashed tables for pis12gen
 * 
 * Comments	: 
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
 *-----------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <memory.h>

#include <pis12loghash.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define HASH_FIND_LONG(head,findlong,out)                                          \
    HASH_FIND(hh,head,findlong,sizeof(long),out)
#define HASH_ADD_LONG(head,intfield,add)                                          \
    HASH_ADD(hh,head,intfield,sizeof(long),add)

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
ctxprivate pis12log_hash_t *M_pis12log_hash = NULL;
/* M_pis12log_hash hashed memory size (bytes) */
ctxprivate size_t M_pis12loghash_memsize = 0L;

/* CRDDET.id(s) hash map head */
ctxprivate hashmap_t *M_crddetid_hashmap = NULL;

/* TOKEN.id(s) hash map head */
ctxprivate hashmap_t *M_tokenid_hashmap = NULL;

/* M_crddetid_hashmap and M_tokenid_hashmap total hashed memory size (bytes) */
ctxprivate size_t M_hashmap_memsize = 0L;

/*---------------------------Prototypes---------------------------------*/

/*------------------------------------------------------------------------
 *
 * Function     :  pis12loghash_add
 *
 * Purpose      :  Add PIS12 log item to hash table
 *
 * Parameters   :  pis12log_hash - PIS12 log item to add
 *
 * Returns      :  Pointer to PIS12 log item in hash table
 *
 *----------------------------------------------------------------------*/
ctxpublic pis12log_hash_t *pis12loghash_add(pis12log_hash_t pis12log_hash)
{
	pis12log_hash_t *p_pis12log_hash;

	p_pis12log_hash = (pis12log_hash_t*)uthash_malloc(sizeof(pis12log_hash_t));
	
	if (NULL != p_pis12log_hash)
	{
		memcpy(p_pis12log_hash, &pis12log_hash, sizeof(pis12log_hash));
		
		HASH_ADD(hh, M_pis12log_hash, tablename,
			 sizeof(pis12log_hash.tablename)+sizeof(pis12log_hash.keydata), p_pis12log_hash);
		M_pis12loghash_memsize += sizeof(pis12log_hash_t);
	}
	
	return p_pis12log_hash;
}

/*------------------------------------------------------------------------
 *
 * Function     :  pis12loghash_find
 *
 * Purpose      :  Find PIS12 log item by hash of tablename and keydata
 *
 * Parameters   :  p_pis12log_hash - PIS12 log item to find
 *
 * Returns      :  Pointer to PIS12 log item in hash table
 *
 *----------------------------------------------------------------------*/
ctxpublic pis12log_hash_t *pis12loghash_find(pis12log_hash_t *p_pis12log_hash)
{
	pis12log_hash_t *res;
	
	HASH_FIND(hh, M_pis12log_hash, p_pis12log_hash->tablename, 
		  sizeof(res->tablename)+sizeof(res->keydata), res);
	return res;
}

/*------------------------------------------------------------------------
 *
 * Function     :  pis12loghash_delete
 *
 * Purpose      :  Delete PIS12 log item from hash table
 *
 * Parameters   :  p_pis12log_hash - PIS12 log item to delete
 *
 * Returns      :  void
 *
 *----------------------------------------------------------------------*/
ctxpublic void pis12loghash_delete(pis12log_hash_t *p_pis12log_hash)
{
	size_t size = sizeof(pis12log_hash_t);
	
	HASH_DEL(M_pis12log_hash, p_pis12log_hash);
	uthash_free(p_pis12log_hash, size);
	
	if (size <= M_pis12loghash_memsize)
	{
		M_pis12loghash_memsize -= size;		
	}
}

/*------------------------------------------------------------------------
 *
 * Function     :  pis12loghash_delete_all
 *
 * Purpose      :  Delete all PIS12 log items from hash table
 *
 * Parameters   :  
 *
 * Returns      :  void
 *
 *----------------------------------------------------------------------*/
ctxpublic int32_t pis12loghash_delete_all()
{
	pis12log_hash_t *p_pis12log_hash, *tmp;
	int32_t counter = 0;

	HASH_ITER(hh, M_pis12log_hash, p_pis12log_hash, tmp)
	{
		pis12loghash_delete(p_pis12log_hash);
		++counter;
	}

	return counter;
}

/*------------------------------------------------------------------------
 *
 * Function     :  pis12loghash_get
 *
 * Purpose      :  Return pis12log hash items
 *
 * Parameters   :  
 *
 * Returns      :  Pointer to first item in the hash table
 *
 *----------------------------------------------------------------------*/
ctxpublic pis12log_hash_t *pis12loghash_get()
{
	return M_pis12log_hash;
}

/*------------------------------------------------------------------------
 *
 * Function     :  pis12loghash_memory_size
 *
 * Purpose      :  Return pis12log hash size
 *
 * Parameters   :  
 *
 * Returns      :  M_pis12log_hash hashed memory size
 *
 *----------------------------------------------------------------------*/
ctxpublic size_t pis12loghash_memory_size()
{
	return M_pis12loghash_memsize;
}

/*------------------------------------------------------------------------
 *
 * Function     :  crddetid_hashmap_add
 *
 * Purpose      :  Add CRDDET.id hashmap item to hash table
 *
 * Parameters   :  crddetid_hashmap - CRDDET.id hashmap item to add
 *
 * Returns      :  Pointer to CRDDET.id hashmap item in hash table
 *
 *----------------------------------------------------------------------*/
ctxpublic hashmap_t *crddetid_hashmap_add(hashmap_t crddetid_hashmap)
{
	hashmap_t *p_crddetid_hashmap;

	p_crddetid_hashmap = (hashmap_t*)uthash_malloc(sizeof(hashmap_t));
	if (NULL != p_crddetid_hashmap)
	{
		memcpy(p_crddetid_hashmap, &crddetid_hashmap, sizeof(crddetid_hashmap));
		
		HASH_ADD_LONG( M_crddetid_hashmap, id, p_crddetid_hashmap );
		M_hashmap_memsize += sizeof(hashmap_t);
	}
	
	return p_crddetid_hashmap;
}

/*------------------------------------------------------------------------
 *
 * Function     :  crddetid_hashmap_find
 *
 * Purpose      :  Find CRDDET.id hashmap item
 *
 * Parameters   :  id - CRDDET.id to find
 *
 * Returns      :  Pointer to CRDDET.id hashmap item in hash table
 *
 *----------------------------------------------------------------------*/
ctxpublic hashmap_t *crddetid_hashmap_find(long id)
{
	hashmap_t *res;

	HASH_FIND_LONG( M_crddetid_hashmap, &id, res );
	return res;
}

/*------------------------------------------------------------------------
 *
 * Function     :  crddetid_hashmap_delete
 *
 * Purpose      :  Delete CRDDET.id hashmap item from hash table
 *
 * Parameters   :  p_crddetid_hashmap - CRDDET.id hashmap item to delete
 *
 * Returns      :  void
 *
 *----------------------------------------------------------------------*/
ctxpublic void crddetid_hashmap_delete(hashmap_t *p_crddetid_hashmap)
{
	size_t size = sizeof(hashmap_t);
	
	HASH_DEL(M_crddetid_hashmap, p_crddetid_hashmap);
	uthash_free(p_crddetid_hashmap, size);

	if (size <= M_hashmap_memsize)
	{
		M_hashmap_memsize -= size;
	}
}

/*------------------------------------------------------------------------
 *
 * Function     :  crddetid_hashmap_delete_all
 *
 * Purpose      :  Delete all CRDDET.id hashmap items from hash table
 *
 * Parameters   :  
 *
 * Returns      :  void
 *
 *----------------------------------------------------------------------*/
ctxpublic int32_t crddetid_hashmap_delete_all()
{
	hashmap_t *p_crddetid_hashmap, *tmp;
	int32_t counter = 0;

	HASH_ITER(hh, M_crddetid_hashmap, p_crddetid_hashmap, tmp)
	{
		crddetid_hashmap_delete(p_crddetid_hashmap);
		++counter;
	}

	return counter;
}

/*------------------------------------------------------------------------
 *
 * Function     :  crddetid_hashmap_get
 *
 * Purpose      :  Return CRDDET.id hashmap items
 *
 * Parameters   :  
 *
 * Returns      :  Pointer to first item in the hash table
 *
 *----------------------------------------------------------------------*/
ctxpublic hashmap_t *crddetid_hashmap_get()
{
	return M_crddetid_hashmap;
}

/*------------------------------------------------------------------------
 *
 * Function     :  tokenid_hashmap_add
 *
 * Purpose      :  Add TOKEN.id hashmap item to hash table
 *
 * Parameters   :  tokenid_hashmap - TOKEN.id hashmap item to add
 *
 * Returns      :  Pointer to TOKEN.id hashmap item in hash table
 *
 *----------------------------------------------------------------------*/
ctxpublic hashmap_t *tokenid_hashmap_add(hashmap_t tokenid_hashmap)
{
	hashmap_t *p_tokenid_hashmap;

	p_tokenid_hashmap = (hashmap_t*)uthash_malloc(sizeof(hashmap_t));
	if (NULL != p_tokenid_hashmap)
	{
		memcpy(p_tokenid_hashmap, &tokenid_hashmap, sizeof(tokenid_hashmap));

		HASH_ADD_LONG( M_tokenid_hashmap, id, p_tokenid_hashmap );
		M_hashmap_memsize += sizeof(hashmap_t);
	}

	return p_tokenid_hashmap;
}

/*------------------------------------------------------------------------
 *
 * Function     :  tokenid_hashmap_find
 *
 * Purpose      :  Find TOKEN.id hashmap item
 *
 * Parameters   :  id - TOKEN.id to find
 *
 * Returns      :  Pointer to TOKEN.id hashmap item in hash table
 *
 *----------------------------------------------------------------------*/
ctxpublic hashmap_t *tokenid_hashmap_find(long id)
{
	hashmap_t *res;

	HASH_FIND_LONG( M_tokenid_hashmap, &id, res );
	return res;
}

/*------------------------------------------------------------------------
 *
 * Function     :  tokenid_hashmap_delete
 *
 * Purpose      :  Delete TOKEN.id hashmap item from hash table
 *
 * Parameters   :  p_tokenid_hashmap - TOKEN.id hashmap item to delete
 *
 * Returns      :  void
 *
 *----------------------------------------------------------------------*/
ctxpublic void tokenid_hashmap_delete(hashmap_t *p_tokenid_hashmap)
{
	size_t size = sizeof(hashmap_t);

	HASH_DEL(M_tokenid_hashmap, p_tokenid_hashmap);
	uthash_free(p_tokenid_hashmap, size);

	if (size <= M_hashmap_memsize)
	{
		M_hashmap_memsize -= size;
	}
}

/*------------------------------------------------------------------------
 *
 * Function     :  tokenid_hashmap_delete_all
 *
 * Purpose      :  Delete all TOKEN.id hashmap items from hash table
 *
 * Parameters   :  
 *
 * Returns      :  void
 *
 *----------------------------------------------------------------------*/
ctxpublic int32_t tokenid_hashmap_delete_all()
{
	hashmap_t *p_tokenid_hashmap, *tmp;
	int32_t counter = 0;

	HASH_ITER(hh, M_tokenid_hashmap, p_tokenid_hashmap, tmp)
	{
		tokenid_hashmap_delete(p_tokenid_hashmap);
		++counter;
	}

	return counter;
}

/*------------------------------------------------------------------------
 *
 * Function     :  tokenid_hashmap_get
 *
 * Purpose      :  Return TOKEN.id hashmap items
 *
 * Parameters   :  
 *
 * Returns      :  Pointer to first item in the hash table
 *
 *----------------------------------------------------------------------*/
ctxpublic hashmap_t *tokenid_hashmap_get()
{
	return M_tokenid_hashmap;
}

/*------------------------------------------------------------------------
 *
 * Function     :  hashmap_memory_size
 *
 * Purpose      :  Return total hashmap size
 *
 * Parameters   :  
 *
 * Returns      :  M_tokenid_hashmap+M_tokenid_hashmap hashed memory size
 *
 *----------------------------------------------------------------------*/
ctxpublic size_t hashmap_memory_size()
{
	return M_hashmap_memsize;
}
