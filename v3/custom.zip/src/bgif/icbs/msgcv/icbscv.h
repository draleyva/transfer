/*-----------------------------------------------------------------------
 * 
 * File		: icbscv.h 
 * 
 * Author	: Alex Butikov
 * 
 * Created	: Jan 2011
 *
 * Purpose	: ICBS conversion routines 
 * 
 * Comments	: 
 * 	
 * Ident	: @(#) $Id: //depot/cortex/v2/main/src/bgif/iso93H/msgcv/iso93Hcv.h#1$
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.					 
 *-----------------------------------------------------------------------*/
#ifndef __ICBSCV_H
#define __ICBSCV_H
/*---------------------------Includes-----------------------------------*/
#include <iso.fd.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define ICBS_HEADER_ERR			-1
#define ICBS_HEADER_LENGTH		12
#define ICBS_PRID_OFF			3
#define ICBS_PRID_LEN			2
#define ICBS_RLNO_OFF			5
#define ICBS_RLNO_LEN			2
#define ICBS_STAT_OFF			7
#define ICBS_STAT_LEN			3
#define ICBS_ORCO_OFF			10
#define ICBS_ORCO_LEN			1
#define ICBS_RECO_OFF			11
#define ICBS_RECO_LEN			1
#define AIID_LEN			11
	/* hlg BPD_MAINT-131 VISA OCT changes  APR/2018 */
#define	MTILEN					4
#define	PCODELEN				2
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
typedef struct SUBF_T
{
        char    *descr;
        int     field_no;
        int     length;
        int     type;
        struct SUBF_T
                *substruct;
} subf_t;

typedef struct TLV_T
{
        char    *tag;
        int     field_no;
        char    *name;
        int     length;
        int     type;
        ctxbool    pad;
} tlv_t;
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
						/* in iso93Hcv		*/
extern int icbscvin(FBFR *p_fb);
extern int icbscvout(FBFR *p_fb);
						/* in mxuiso93H		*/
extern	int jiso_init(void);
extern	int jiso_i2f(char *p_iso, FBFR *p_fb, int *nfield);
extern	int jiso_f2i(FBFR *p_fb, char *p_iso, int *p_len);
extern	void fill_M_headerorg(FBFR *p_fb);
extern	void jiso_set_use_conacc(ctxbool use_conacc_f);
extern	ctxbool jiso_use_conacc(void);
extern	void jiso_set_basefe(char *basefe);
extern	ctxbool jiso_use_basefe(void);
extern  void set_ath_aiid_code(char *ath_aiid_code);
extern  void set_vpan_over_pan(ctxbool vpanover_enabled);
/* hlg BPD_MAINT-131 VISA OCT changes  APR/2018 */
extern	void set_ovr_octpcode(char *pcode);
extern	void set_ovr_cltoctpcode(char *pcode);
extern	void set_ovr_octmti(char *mti);

#endif

