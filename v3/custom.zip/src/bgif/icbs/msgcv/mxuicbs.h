#define _UNUSED_(x) (void)x;
ctxpublic int check_message_body (char *p_iso, FBFR *p_fb, int *nfield);
