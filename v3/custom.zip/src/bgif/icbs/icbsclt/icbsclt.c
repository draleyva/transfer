/*-----------------------------------------------------------------------
 * 
 * File		: icbsclt.c 
 * 
 * Author	: Alex Butikov 
 * 
 * Created	: Jan 2011
 *
 * Purpose	: ICBS client
 * 
 * Comments	: 
 * 	
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.					 
 *-----------------------------------------------------------------------*/
/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>


#include <slfdbg.h>
#include <sldbg.h>
#include <slcfp.h>
#include <slclp.h>
#include <slntp.h>
#include <sldtm.h>
#include <slnfb.h>
#include <slgsm.h>
#include <slmsgcat.h>
#include <slmsgque.h>
#include <slenv.h>
#include <slgtp.h>


#include <cortex.h>
#include <cocbfdef.h>
#include <cocbf.h>
#include <coevent.h>
#include <coclinit.h>
#include <comsgtyp.h>

#include <coint.fd.h>
#include <cocrd.fd.h>
#include <mxuiso2.h>

#include <icbscv.h>
#include <ifevent.h>
#include <gdiev.h>
#include <vicat.h>
#include <gdiinet.h>

#include <gendbcmd.h>

#include <hoststat.h>
#include <hostcmd.h>
#include <genif.h>
#include <ovrld.h>

#include <cotxnmon.h>
/*---------------------------Externs------------------------------------*/
extern int	errno;
/*---------------------------Macros-------------------------------------*/
#define MODNM 	"if"
#define PROGNM 	"ICBSCLT"

#define	SRVNM_LEN	64
#define	PIPE_WAIT	1		/* pipe should already be there	*/
#define	WAIT_MSG	60
#define	EXIT_CTX_DEAD	1

#define ICBSNMGSVC	"ICBSNMGT"	/* net management requests      */
#define CRDSTATUPDSVC	"CRDSTATUPD"

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
enum states						/* states	*/
{
	st_read_msg,
	st_msgcnv,
	st_chk_msg,
	st_snd_rsp,
	st_snd_nmg,
	st_snd_filem,
	st_snd_rply,
	st_snd_ferply,
	st_snd_late,
	st_snd_rev_conv,
	st_snd_rev_snd,
	st_error,
	st_snd_req,
	st_return
};

enum events
{
	ev_ok = 0,
	ev_err,
	ev_rsp,
	ev_nmgrq,
	ev_reqtxn,
	ev_filem,
	ev_poll,
	ev_comok,
	ev_conv
};

/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
static char rcsid[] = "$Id: //depot/cortex/v2/main/src/bgif/iso93H/iso93Hcl/iso93Hclt.c#9$";

ctxprivate int	M_err;

ctxprivate void	*M_p_mc = NULL;			/* state machine handle	*/
ctxprivate char 	M_tagnm[128];
ctxprivate long	M_msgkey;			/* message queue number	*/
ctxprivate char	M_dbgfile[CTX_FILENAME_MAX];	/* debug file		*/
ctxprivate char	M_hostname[SRVNM_LEN]; 		/* host name		*/
ctxprivate char	M_lansvc[SRVNM_LEN];  		/* service for driver	*/
ctxprivate char	M_reqfwdsvc[SRVNM_LEN];	  	/* MV BZWBK_DEV-25 20090407 */

ctxprivate msgque_t	M_msgqueue = FAIL;

ctxprivate FBFR	*M_p_fb = NULL;		/* working fielded buffer	*/
ctxprivate char	M_buf[1024];		/* message buffer for queue	*/
ctxprivate int	M_buflen;		/* message length		*/
ctxprivate ctxbool	M_ovrld_check = FALSE;	/* CN 9709 5/6/03 	*/
ctxprivate ctxbool	M_vpan_over_pan = FALSE;/* MV NMR023597         */

int	M_DO_DUMP=0;			/* Message Dumps 	*/

/* Is message an ACCOUNT balance update */
ctxprivate fld_cond_t Bisaccbal =
{ COND_FBOOL, NULL, "(C_FILENAME == 'ACCOUNT')" };

/* Is message an ACCOUNT balance refresh */
ctxprivate fld_cond_t Bisbalref =
{ COND_FBOOL, NULL, "(C_FILENAME == 'ACCOUNT2')" };

/* Is message an exchange rate update */
ctxprivate fld_cond_t Bisxrate = 
{ COND_FBOOL, NULL, "(C_FILENAME == 'EXCHRATE')" };

/* B.Aspland - 01/11/99 - Support for Card Status Updates from Host */
/* Is message a CRDSTUPD (Card Status update) */
ctxprivate fld_cond_t Biscrdstupd =
{ COND_FBOOL, NULL, "(C_FILENAME == 'CRDSTATUS')" };

/* hlg BPD_MAINT-131 VISA OCT changes  MAY/2018 */
static char M_octpcode[PCODELEN + 1] = ""; /* PCODE used for VISA OCT 
								transaction default 26 = MTC_CHFUNDSXFER*/
/*---------------------------Prototypes---------------------------------*/
ctxprivate int	vc_init(int argc, char **argv);
ctxprivate void	vc_uninit( void );
ctxprivate void	vc_main( void );
ctxprivate void	vc_sigdisp( int sig );
ctxprivate short	vc_tpcall(char *svcnm);
ctxprivate short	vc_snd_rev( short rej, short reason );

ctxprivate short	vc_read_msg( void );
ctxprivate short	vc_msgcnv( void );
ctxprivate short	vc_chk_msg( void );
ctxprivate short	vc_snd_rsp( void );
ctxprivate short	vc_snd_nmg( void );
ctxprivate short	vc_snd_filem(void);
ctxprivate short	vc_snd_late( void );
ctxprivate short	vc_snd_rply(void);
ctxprivate short	vc_snd_ferply(void);
ctxprivate short	vc_error( void );
ctxprivate short	vc_snd_rev_conv( void );
ctxprivate short	vc_snd_rev_snd( void );

ctxprivate int	vc_event( int ev );

ctxpublic int	main( int argc, char **argv );
ctxprivate short 	vc_snd_req(void);

/*------------------------------------------------------------------------
 *
 * Function	:  main
 *
 * Purpose	:  Usual
 *
 * Parameters	:  Usual
 *
 * Returns	:  Usual
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int	main( int argc, char **argv )
{
	int ret;

        ret = vc_init( argc, argv );

	if (FAIL == ret)
                fprintf(stderr,"Error: Initialisation failed\n");

        if (FAIL != ret)
                vc_main();

        vc_uninit();

	return (SUCCEED == ret ? 0 : 1);
}

/*--------------------------------------------------------------------------
 *
 * Function	: vc_main
 
 * Purpose	: Main processing loop for client
 *
 * Parameters	: void
 *
 * Returns	: void
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate void	vc_main( void )
{
	gsm_enter( M_p_mc, st_read_msg );

	return;
}

/*------------------------------------------------------------------------
 *
 * Function	:  vc_init
 *
 * Purpose	:  Initialisation
 *
 * Parameters	:  argc, argv
 *
 * Returns	:  SUCCEED - initialized
 *		   FAIL - error
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	vc_init( int argc, char **argv )
{
ctxprivate char 	subsect[128];
ctxprivate	char 	dbgfile[CTX_FILENAME_MAX];
ctxprivate int 	dbglev = 0,
		dbgbuf = FAIL;
ctxprivate char 	netaddr[32];
ctxprivate short 	comstate, reqstate, curstate, accok, stmtok;
	int 	ret = SUCCEED;
	FILE 	*envfile;
	FILE	*fp=NULL;

ctxprivate int M_printdump = 0;

ctxprivate gsm_states st[] =
	{
					/* Main state machine		*/
{GST(st_read_msg),	vc_read_msg,		st_return,	NULL},
{GST(st_msgcnv),	vc_msgcnv,		st_error,	NULL},
{GST(st_chk_msg),	vc_chk_msg,		st_error,	NULL},
{GST(st_snd_rsp),	vc_snd_rsp,		st_error,	NULL},
{GST(st_snd_nmg),	vc_snd_nmg,		st_error,	NULL},
{GST(st_snd_filem),	vc_snd_filem,		st_error,	NULL},
{GST(st_snd_rply),	vc_snd_rply,		st_error,	NULL},
{GST(st_snd_ferply),	vc_snd_ferply,		st_error,	NULL},
{GST(st_snd_late),	vc_snd_late,		st_error,	NULL},
{GST(st_snd_rev_conv),	vc_snd_rev_conv,	st_error,	NULL},
{GST(st_snd_rev_snd),	vc_snd_rev_snd,		st_error,	NULL},
{GST(st_error),		vc_error,		st_read_msg,	NULL},
{GST(st_snd_req),       vc_snd_req,             st_error,       NULL},
{GST(st_return),	vc_error,		0,		GSM_RETURN},
	};

ctxprivate gsm_trans tr[] =
	{
					/* main SM transitions		*/
{	st_read_msg,	GEV(ev_ok),	NULL,		st_msgcnv	},
{	st_read_msg,	GEV(ev_poll),	NULL,		st_read_msg	},
{	st_read_msg,	GEV(ev_comok),	NULL,		st_read_msg	},
{	st_msgcnv,	GEV(ev_ok),	NULL,		st_chk_msg	},
{	st_msgcnv,	GEV(ev_err),	NULL,		st_snd_ferply	},
{	st_chk_msg,	GEV(ev_rsp),	NULL,		st_snd_rsp	},
{	st_chk_msg,	GEV(ev_nmgrq),	NULL,		st_snd_nmg	},
{	st_chk_msg,	GEV(ev_reqtxn),	NULL,		st_snd_req	},
{	st_chk_msg,	GEV(ev_filem),	NULL,		st_snd_filem	},
{	st_snd_rsp,	GEV(ev_ok),	NULL,		st_read_msg	},
{	st_snd_rsp,	GEV(ev_err),	NULL,		st_snd_late	},
{	st_snd_nmg,	GEV(ev_ok),	NULL,		st_snd_rply	},
{	st_snd_req,	GEV(ev_ok),	NULL,		st_snd_rply	},
{	st_snd_filem,	GEV(ev_ok),	NULL,		st_snd_rply	},
{	st_snd_late,	GEV(ev_ok),	NULL,		st_read_msg	},
{	st_snd_rply,	GEV(ev_ok),	NULL,		st_read_msg	},
{	st_snd_rply,	GEV(ev_conv),	NULL,		st_snd_rev_conv	},
{	st_snd_rply,	GEV(ev_err),	NULL,		st_snd_rev_snd	},
{	st_snd_rev_conv,GEV(ev_ok),	NULL,		st_read_msg	},
{	st_snd_rev_snd,	GEV(ev_ok),	NULL,		st_read_msg	},
{	st_snd_ferply,	GEV(ev_ok),	NULL,		st_read_msg	},
{FAIL}
	};

	ctxprivate cfp_parm cfp[] =
	{
		{"MSGQUEUE",  	parm_hexlong,	0, TRUE, (void *)&M_msgkey, 0},
		{"HOSTNAME",  	parm_string, 	sizeof(M_hostname), TRUE, (void *)&M_hostname, 0},
		{"DEBUG",  	parm_int,    	0, FALSE, (void *)&dbglev, 0},
		{"DBGBUF", 	parm_int,    	0, FALSE, (void *)&dbgbuf, 0},
		{"DBGNAME",	parm_string, 	sizeof(dbgfile),FALSE, (void *)&dbgfile, 0},
		{"DUMP",   	parm_int,    	0, FALSE, (void *)&M_DO_DUMP, 0},
		{"OVRLD_CHECK", parm_truebool,	0, FALSE, (void *)&M_ovrld_check,	0},
		{"VPANOVRPAN",  parm_truebool, 	0, FALSE, (void *)&M_vpan_over_pan, 0},
		{"REQFWDSVC", 	parm_string, 	sizeof(M_reqfwdsvc), FALSE, (void *)&M_reqfwdsvc, 0},
		{"OVR_OCTPCODE",   parm_string, sizeof(M_octpcode), FALSE, (void *)&M_octpcode, 0},
		{"PRINTDUMP",   parm_int, 0, FALSE, (void *)&M_printdump, 0},
		{0}
	};
	
	if (M_printdump)
	{
		set_printdump(M_printdump);
	}	
	
        /* Create a structure to hold the command line parameters */
        clp_parm clp[]=
        {
	        {'t', parm_string, sizeof(M_tagnm), TRUE, M_tagnm},
	        {'s', parm_string, sizeof(subsect), FALSE, subsect},
	        {0}
        };	
	
        char	buf[CTX_FILENAME_MAX], *p;

	/* Parse the command line parameters. */
	if( SUCCEED == ( ret = clp_parse(argc, argv, clp) ) )
        {
		fp = cfp_open();

		if (NULL == fp)
		{
			ret = FAIL;
		}

		if (SUCCEED == ret)
		{
			ret = cfp_parse(fp, cfp, M_tagnm, subsect);
		}

		if (SUCCEED == ret)
		{
			ret = dbg_cfp_parse(fp, M_tagnm, subsect);
		}
	
		if (fp != NULL) fclose(fp);
		
		if (EOS!=M_reqfwdsvc[0])
			DBG_PRINTF(( dbg_progdetail, "M_reqfwdsvc: %s",M_reqfwdsvc));
	} 
	else
	{
		fprintf( stderr, 
			"Usage:\t%s -t <tag> -s <Subsection name>\n", argv[0] );
	}

	if( SUCCEED != (ret = hst_get_hostdet( M_hostname, &reqstate,
		&curstate, &comstate, &accok, &stmtok, netaddr )) )
	{
		DBG_PRINTF((dbg_fatal, "The hostname <%s> could not be"
			" found in hostdet table"));
	}

	if(SUCCEED == ret)
		strcpy(M_lansvc, netaddr);

	if (SUCCEED == ret)
	{
		DBG_SETNAME(M_tagnm);
	}

	if (FAIL != ret)
	{
		if (M_vpan_over_pan)
		{
			set_vpan_over_pan(M_vpan_over_pan);
		}
	}

	if( FAIL != ret )
		if (FAIL == (ret = gsm_new(st, DIM(st)-1, tr, &M_p_mc)))
			DBG_PRINTF(( dbg_fatal, "gsm_new failed" ));

	if( FAIL != ret )
		if (DBG_GETLEV() >= dbg_progdetail)
			gsm_debug(M_p_mc, TRUE, PROGNM);

	if( FAIL != ret && FAIL == (ret = msgque_new((key_t)M_msgkey, &M_msgqueue) ) )
	{
		DBG_PRINTF((dbg_fatal, "Create/Open message queue %ld failed",
			    M_msgkey ));

		sprintf( buf, "%ld", M_msgkey );
	   
		if (SUCCEED != ev_call(EVTAG_MSGQUE, buf))
	     		ret = ev_err;
	}

	if( FAIL != ret && !(p = getenv("CTXUSR")))
	{
	        DBG_PRINTF((dbg_syserr, "CTXUSR not set up"));
	        ret = FAIL;
      	}
	if( FAIL != ret )
	{
		/* CN 9709 5/6/03 overload checking */
		DBG_PRINTF((dbg_proginfo,"Overload checking %s",
			(M_ovrld_check) ? "ENABLED" : "DISABLED"));
	}
	
	/* hlg BPD_MAINT-131 14-may-2018 */
	if (M_octpcode)
	{
		set_ovr_cltoctpcode(M_octpcode);
	}

	if( FAIL != ret )
	{
		ev_init( "if", M_tagnm, "");
	}

	if( FAIL != ret )
	{
		signal(SIGINT,  vc_sigdisp);
		signal(SIGTERM, vc_sigdisp);
		signal(SIGQUIT, vc_sigdisp);
		signal(SIGSEGV, vc_sigdisp);
		signal(SIGALRM,vc_sigdisp);
	}

	/* This function required so that large messages are 
	 * handled properly */
	gtp_usebig();

	return( ret );
}

/*--------------------------------------------------------------------------
 *
 * Function	: vc_uninit
 *
 * Purpose	: Uninitialize the machinery
 *
 * Parameters	: 
 *
 * Returns	: void
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate void	vc_uninit( void )
{
	gsm_delete( M_p_mc );

	if( 1 == ntp_getlev() )
		ntp_abort(0);

	ntp_free( (char *)M_p_fb );

	ntp_term();

	return;
}
/*--------------------------------------------------------------------------
 *
 * function	: vc_read_msg
 *
 * purpose	: read message from the message queue (with blocking)
 *
 * parameters	: void
 *
 * returns	: ev_ok / ev_comok / ev_poll / ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	vc_read_msg( void )
{
	short	ret = ev_ok;
	int	cnt;
	short	ret_code = SUCCEED;
	char	buf[12];


	DBG_PRINTF((dbg_progdetail,
		    "===========================>  Waiting for a message"));

	memset( M_buf, 0, sizeof(M_buf) );
	M_buflen = sizeof(M_buf);
	M_err = err_allok;

again:
	if( 1 == getppid() )
	{
		DBG_PRINTF((dbg_syswarn, "Parent dead - exiting"));
		exit( EXIT_CTX_DEAD );
	}

	alarm(WAIT_MSG);		/* But why ? */
	DBG_PRINTF((dbg_progdetail, "READ QUEUE %ld", (long)M_msgqueue));
	if (FAIL == ( cnt = msgque_rcv( M_msgqueue, M_buf, M_buflen ) ) )
    	{
	      if( EINTR == errno )
			goto again;
      
	      ret = ev_err;
	      DBG_PRINTF((dbg_syserr,"receive failed %s", strerror(errno) ));
	}

	alarm(0);
	M_buflen = cnt;
	DBG_PRINTF((dbg_progdetail,"received %d bytes", M_buflen ));
	      
	/* Very primitive event maint	*/
	if( M_buflen == 2 )
	{
		sscanf( M_buf, "%2hd", &ret_code );
		DBG_PRINTF((dbg_progdetail, "ret_code %d", ret_code));
		switch( ret_code )
		{
		case gdi_com_ev_com_ok:
			ret = ev_comok;
		      
			if( SUCCEED !=
				hst_upd_comstat( M_hostname, 1, 
					   HCOMS_ON_LINE ) )
			{
				ret = ev_err;
			}
			else
			{
				sprintf(buf, "%ld", M_msgkey);
				if(SUCCEED !=
					ev_call(EVTAG_COMOK, buf))
			    /* ret = ev_err*/;
			}
			break;
		      
		case gdi_com_ev_poll_err:
			ret = ev_poll;
		      
			DBG_PRINTF(( dbg_progdetail, "M_hostname: %s",
								M_hostname ));
			if( SUCCEED !=
				hst_upd_comstat( M_hostname, 1,
					   HCOMS_OFF_LINE ) )
			{
				ret = ev_err;
			}
			else
			{
				sprintf( buf, "%ld", M_msgkey);
				if(SUCCEED !=
					ev_call(EVTAG_POLL,buf))
			    /* ret = ev_err*/;
			}
			break;
		      
		default:
			DBG_PRINTF((dbg_syserr,
					"Unknow event: %hd", ret_code));
			ret = ev_err;
			break;
		}
	}
	
	return( ret );
}

/*--------------------------------------------------------------------------
 *
 * function	: vc_msgcnv
 *
 * purpose	: message conversion from: native -> FML
 *
 * parameters	: void
 *
 * returns	: ev_ok / ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	vc_msgcnv( void )
{
	short	ret = ev_ok;


	ntp_free((char *)M_p_fb);

	/* A message has come in from the host (in M_buf), so start 
	 * up a fresh FB to put it in */
	if ( !(M_p_fb = (FBFR *)ntp_alloc("FML", NULL, 4096)) )
	{
		DBG_PRINTF((dbg_syserr, "FML alloc failed"));
		ev_tpallocfail(ntp_tperrno());
		ret = ev_err;
	}

	/* Stick the raw message into the FB for starters */
	if( ev_ok == ret && SUCCEED != F_chg( M_p_fb, I_NATMSG, 0, M_buf,
					      M_buflen ) )
	{
		ret = ev_err;
	}

	/* Do the actual conversion from ISO to Fielded buffer */
	ret = icbscvin(M_p_fb);

	/* Dump the ISO message to disk */
	if( M_DO_DUMP && SUCCEED == ret )
	{
		char	cmsgcls;
		char	cmsgfn;
		char	ctxnsrc;
		char	fname[80];
		FILE	*fp;

		/* Make filename out of C_MSGCLS, C_MSGFN,
		 * C_TXNSRC and time
		*/
		if(	FAIL != CF_get(M_p_fb,C_MSGCLS,0,(char*) &cmsgcls,
				(FLDLEN) 0, FLD_CHAR) &&
			FAIL != CF_get(M_p_fb,C_MSGFN,0,(char*) &cmsgfn,
				(FLDLEN) 0, FLD_CHAR) &&
			FAIL != CF_get(M_p_fb,C_TXNSRC,0,(char*) &ctxnsrc,
				(FLDLEN) 0, FLD_CHAR) )
		{
			sprintf( fname, "%s/1%c%c%c%ld.dmp",
				getenv( "CTXTMP" ),
				cmsgcls,
				cmsgfn,
				ctxnsrc,
				local_time());
			DBG_PRINTF(( dbg_progdetail, "Dumping to %s", fname ));
			/* Open the file for writing */
			if( NULL != (fp=fopen( fname, "w+" )) )
			{
				DBG_PRINTF(( dbg_progdetail, "Dumping!"));
				/* Dump! */
				fwrite( M_buf, M_buflen, 1, fp );
				fclose( fp );
			}
		}
	}

	if (ret == SUCCEED)
	{
		ret = ev_ok;
	}

	return( ret );
}

/*--------------------------------------------------------------------------
 *
 * function	: vc_chk_msg
 *
 * purpose	: check message type
 *
 * parameters	: void
 *
 * returns	: ev_rsp / ev_nmg / ev_err / ev_filem
 *
 * comments	: This is where we have alook at the message and decide
 *		  what the hell we going to do with the thing.
 *
 *------------------------------------------------------------------------*/
ctxprivate short	vc_chk_msg( void )
{
	char	*p;
	short	ret = ev_err;
	int		mc, mf;
	long	rej_code;

	mc = cbf_get_msg_class(M_p_fb);
	mf = cbf_get_msg_function(M_p_fb);

	if (SUCCEED != CF_get(M_p_fb, I_REJECTCODE, 0, 
				(char *)&rej_code, 0, FLD_LONG))
	{
		DBG_PRINTF(( dbg_syswarn, "NO REJECT CODE" ));
		return ev_err;
	}

	if (MFN_REQRSP == mf || MFN_ADVRSP == mf)
	{
		/* If its a response, then we'll bail out here	*/
		return ev_rsp;
	}

	if (MCL_AUTH == mf)
		DBG_MONSTART(M_p_fb,PROGNM);
	/* it's a request, suss out type	*/
	switch(mc)
	{
		case MCL_NETMGT:
			ret = ev_nmgrq;
			break;

		case MCL_FILE:	
			ret = ev_filem;
			break;
		default:
			if (EOS==M_reqfwdsvc[0])
			{
				DBG_PRINTF((dbg_syserr,
					"Unsupported req msg class 0x%X", mc));
				ret = ev_err;
			} 
			else 
			{
				DBG_PRINTF((dbg_syserr,
					"Test service request %s", M_reqfwdsvc));
				ret = ev_reqtxn;
			}
			break;
	}

	return ret;
}

/*--------------------------------------------------------------------------
 *
 * function	: vc_snd_rsp
 *
 * purpose	: Try to send response on pipe
 *
 * parameters	: void
 *
 * returns	: ev_ok / ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	vc_snd_rsp( void )
{
	TPQCTL	qctl;
	char	stan[7];
	char	msgcls[2];
	char	pipenm[CTX_FILENAME_MAX];	/* name of the FIFO pipe */
	int	fd;
	int	nb;
	FILE	*fp;
	int	ret = ev_ok;

	if (FAIL == CF_get(M_p_fb, C_STAN, 0, stan, 0, FLD_STRING))
		return ev_err;

	if (FAIL == CF_get(M_p_fb, C_MSGCLS, 0, msgcls, 0, FLD_CHAR))
		return ev_err;
		
	msgcls[1]=EOS;
	strcpy(pipenm, getenv("CTXTMP"));
	strcat(pipenm, "/");
	strcat(pipenm, msgcls);
	strcat(pipenm, stan);

	alarm(PIPE_WAIT);
	if(FAIL == (fd = open(pipenm, O_WRONLY)))
	{
		DBG_PRINTF((dbg_syserr, "Can't open %s %s",
			pipenm,strerror(errno) ));
		return ev_err;
	}
	F_unindex(M_p_fb);
	if (FAIL == write(fd, (char *)M_p_fb, (nb = (int)F_used(M_p_fb))))
	{
		DBG_PRINTF((dbg_syserr, "Can't write %s", pipenm));
		ret = ev_err;
	}
	else
	{
		DBG_PRINTF((dbg_progdetail, "Wrote %d bytes", nb));
		ret = ev_ok;
	}
	
	alarm(0);
	close(fd);

	return ret;
}


/*--------------------------------------------------------------------------
 *
 * function	: vc_snd_nmg
 *
 * purpose	: send network mgt message 
 *
 * parameters	: void
 *
 * returns	: ev_ok /ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	vc_snd_nmg(void)
{
	if (SUCCEED != CF_chg(M_p_fb, I_IFNETADR, 0, M_hostname, 0, FLD_STRING))
		return ev_err;

	return vc_tpcall(ICBSNMGSVC);

}

/*--------------------------------------------------------------------------
 *
 * function	: vc_snd_filem
 *
 * purpose	: send file maintainance message 
 *
 * parameters	: void
 *
 * returns	: ev_ok /ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	vc_snd_filem(void)
{
        char    svcnm[100];
	int	filetype;
 
	DBG_PRINTF(( dbg_progdetail, "vc_snd_filem" ));

	if( TRUE == fev_evbool(M_p_fb, &Bisxrate) )
	{
		/* Its an exchange rate update */
		strcpy( svcnm, XRATEUPDSVC );
	}
	else if( TRUE == fev_evbool(M_p_fb, &Bisaccbal) )
	{
		/* Its an Account balance update */
		strcpy( svcnm, ACBALUPDSVC );
	}
	else if( TRUE == fev_evbool(M_p_fb, &Bisbalref) )
	{
		DBG_PRINTF(( dbg_progdetail, "Forwarding to ACBALREF" ));
		/* Its an Account balance refresh */
		strcpy( svcnm, ACBALREFSVC );
	}
	/* B.Aspland - 01/11/99 - Support for Card Status Updates */
	else if( TRUE == fev_evbool(M_p_fb, &Biscrdstupd) )
	{
		DBG_PRINTF(( dbg_progdetail, "Forwarding to CRDSTATUPD" ));
		/* Its a Card Status Update message*/
		strcpy( svcnm, CRDSTATUPDSVC );
	}
	else
	{
		/* Dont know what it is, so send back ACTIONCODE= 306! */
		/* B.Aspland - 11/11/99 - Send back a 1310 rather than a 1300
		 *                        or else we may confuse the host sys.
		 */
		DBG_PRINTF(( dbg_syserr, "Unknown File Maintainance type" ));

		if( FAIL == CF_chg(M_p_fb, C_ACTIONCODE, 0,
				(char *)"3",0,FLD_STRING) 
		 || FAIL == CF_chg(M_p_fb, C_RSPCODE, 0,
				(char *)"06",0,FLD_STRING)
		 || FAIL == CF_chg(M_p_fb, C_MSGFN, 0,
				(char *)"1",0,FLD_STRING) )
			return( ev_err );
	       	else
			return( ev_ok ); 
	}
 
	DBG_PRINTF(( dbg_progdetail, "svcnm: %s", svcnm ));
	return vc_tpcall(svcnm);
}

/*--------------------------------------------------------------------------
 *
 * function	: vc_snd_ferply
 *
 * purpose	: Send format error reply to request message
 *
 * parameters	: void
 *
 * returns	: ev_ok /ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	vc_snd_ferply(void)
{
	short	ret = ev_ok;
	FLDLEN	len;

	M_buflen = 0;
	memset(M_buf, NULL, sizeof(M_buf));

	if( ev_ok == ret && FAIL == F_get( M_p_fb, I_NATMSG, 0, M_buf, &len ) )
	{
		M_err = err_missfld;
		ret = ev_err;
	}

	if( ev_ok == ret )
	{
		M_buflen = len;
		
		DBG_PRINTF(( dbg_progdetail, "M_lansvc: %s",M_lansvc));
	        if (FAIL == gdinet_snd(M_buf, M_buflen, "", M_lansvc, &M_err))
	        {
		        M_err = err_putev;
		        ret = ev_err;
	        }
	}
	return( ret );
}

/*--------------------------------------------------------------------------
 *
 * function	: vc_snd_rply
 *
 * purpose	: Send reply to request message
 *
 * parameters	: void
 *
 * returns	: ev_ok /ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	vc_snd_rply(void)
{
	short	ret = ev_ok;
	FLDLEN	len;
	char	msgcls;
	
	M_buflen = 0;

	if (FAIL == F_get(M_p_fb, C_MSGCLS, 0, &msgcls, 0))
		ret = ev_err;

	if( SUCCEED != icbscvout( M_p_fb ) )
	{
		M_err = err_msgcnv;
		ret = ev_conv;
	}

	if( ev_ok == ret )
	{
		memset( M_buf, 0, sizeof(M_buf) );
		len = 0;
	}

	if( ev_ok == ret && FAIL == F_get( M_p_fb, I_NATMSG, 0, M_buf, &len ) )
	{
		M_err = err_missfld;
		ret = ev_err;
	}

	if( MCL_AUTH == msgcls || MCL_FIN == msgcls || MCL_FEE == msgcls
	|| MCL_REVCB == msgcls )
		DBG_MONPRINT(M_p_fb,PROGNM); /* catches ev_finreq */

	if( ev_ok == ret )
	{
		M_buflen = len;

		DBG_PRINTF(( dbg_progdetail, "Sending to service : %s", M_lansvc ));
	        if (FAIL == gdinet_snd(M_buf, M_buflen, "", M_lansvc, &M_err))
	        {
		        M_err = err_putev;
		        ret = ev_err;
	        }
	}
	return( ret );
}

/*--------------------------------------------------------------------------
 *
 * function	: vc_snd_rev_snd
 *
 * purpose	: Send reversal to the issuer if financial comms error
 *
 * parameters	: void
 *
 * returns	: ev_ok /ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	vc_snd_rev_snd(void)
{
	return( vc_snd_rev( RJR_IF_SENDDRV, MRC_REV_SUS_MAL ) );
}

/*--------------------------------------------------------------------------
 *
 * function	: vc_snd_rev_conv
 *
 * purpose	: Send reversal to the issuer if financiala conversion error
 *
 * parameters	: void
 *
 * returns	: ev_ok /ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	vc_snd_rev_conv(void)
{
	return( vc_snd_rev( RJR_IF_MSGCVOUT, MRC_REV_FMT_ERR ) );
}

/*--------------------------------------------------------------------------
 *
 * function	: vc_snd_rev
 *
 * purpose	: Send reversal to the issuer if financial
 *
 * parameters	: void
 *
 * returns	: ev_ok /ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	vc_snd_rev( short rej, short reason )
{
	short	ret = ev_ok;


	if(  cbf_reversible( M_p_fb ) )
	{
		if( SUCCEED != cbf_gen_rev( M_p_fb ) )
			ret = ev_err;
		else
		{
			DBG_PRINTF((dbg_syserr, "Sending reversal"));

			if( SUCCEED != cbf_set_stan( &M_p_fb ) )
				ret = ev_err;
			else
				if( FAIL == CF_chg(M_p_fb, I_REJREASON, 0,
						(char *)&rej,0,FLD_SHORT) 
				 || FAIL == CF_chg(M_p_fb, C_REASONCODE, 0,
						(char *)&reason,0,FLD_SHORT) )
					ret = ev_err;
	       			else
					ret = vc_tpcall(CTHREQSVC);
		}
	}

	return( ret );
}

/*--------------------------------------------------------------------------
 *
 * function	: vc_snd_late
 *
 * purpose	: Send late response
 *
 * parameters	: void
 *
 * returns	: ev_ok /ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	vc_snd_late(void)
{
	short	outbtchtype = OB_ONLHOSTBTCH;

	if ( FBISRSP(M_p_fb) )
		if( !F_pres(M_p_fb, I_OUTBTCHTYP, 0 ) &&
		   FAIL == CF_chg(M_p_fb, I_OUTBTCHTYP, 0, 
				  (char *)&outbtchtype, 0, FLD_SHORT ) )
			return( ev_err );

	return( FBISFIN(M_p_fb) || FBISAUTH(M_p_fb) || FBISREVCB(M_p_fb) ?
	       vc_tpcall(SWLATESVC) : ev_ok );
}

/*--------------------------------------------------------------------------
 *
 * function	: vc_tpcall
 *
 * purpose	: Generic tpcall
 *
 * parameters	: void
 *
 * returns	: ev_ok /ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	vc_tpcall(char *svcnm)
{
	short	ret = ev_ok;
	long	rsplen = 0L;
	int	mc = 0;


	DBG_STAR(("ntp_call: %s", svcnm));
	if (FAIL == ntp_call(svcnm,
			     (char *)M_p_fb,
			     0L, 
			     (char **)&M_p_fb, 
			     &rsplen,
			     0))
	{
		DBG_PRINTF((dbg_syserr, 
				"tpcall %s failed %d [%s]",
				svcnm,
				ntp_errno(), ntp_strerror(ntp_errno())));
		ev_svcfail(svcnm,ntp_errno());
		mc = cbf_get_msg_class(M_p_fb);
		if( MCL_AUTH == mc || MCL_FIN == mc || MCL_FEE == mc
			|| MCL_REVCB == mc )
			DBG_MONPRINT(M_p_fb, PROGNM);
		ret = ev_err;
	}

	DBG_STAR(("Back to icbs client"));

	return( ret );
}

/*--------------------------------------------------------------------------
 *
 * function	: vc_error
 *
 * purpose	: an error occurred - tell someone !
 *
 * parameters	: void
 *
 * returns	: ev_ok
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	vc_error( void )
{
	vc_event(M_err);

	return(ev_ok);
}

/*------------------------------------------------------------------------
 *
 * Function	:  vc_event
 *
 * Purpose	:  Log an error
 *
 * Parameters	:  ev - event type
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	vc_event( int ev )
{
	int	ret = SUCCEED;

	switch( ev )
	{
		case err_connect:
			ret = ev_call( EVTAG_LANERR, M_lansvc );
			break;

		case err_missfld:
		case err_msgcnv:
			ret = ev_call( EVTAG_MSGCONV, M_lansvc );
			break;

		case err_getev:
		case err_putev:
		case err_sndmsg:
			ret = ev_call( EVTAG_LOWCOM, M_lansvc );
			break;

		default:
			DBG_PRINTF(( dbg_syserr,"Invalid event: %d", ev ));
			ret = FAIL;
			break;
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * function	: vc_sigdisp
 *
 * purpose	: react on signal
 *
 * parameters	: sig - signal which caused interrupt
 *
 * returns	: 
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate void	vc_sigdisp( int sig )
{

	if( SIGALRM == sig )
	{
		signal( SIGALRM, vc_sigdisp );
	}
	else if( SIGQUIT == sig || SIGINT == sig || SIGTERM == sig )
	{
		DBG_PRINTF((dbg_syserr,
			    "Exiting due to receiving signal: %d", sig ));
		ntp_abort(0);
		exit(1);
	}
	else if( SIGSEGV == sig )
	{
		DBG_PRINTF((dbg_fatal,
			    "Exiting due to receiving signal: %d", sig ));
		ntp_abort(0);
		exit( 1 );
	}
	else
		DBG_PRINTF((dbg_syserr, "Unexpected signal %d", sig));

	return;
}
/*--------------------------------------------------------------------------
 *
 * function     : vc_snd_req
 *
 * purpose      : send network req message 
 *
 * parameters   : void
 *
 * returns      : ev_ok /ev_err
 *
 * comments     : MV BZWBK_DEV-25 20090407 Added for testing purposes
 *
 *------------------------------------------------------------------------*/
ctxprivate short vc_snd_req(void)
{
	if (SUCCEED != CF_chg(M_p_fb, I_IFNETADR, 0, M_hostname, 0, FLD_STRING))
		return ev_err;
	if (EOS==M_reqfwdsvc[0])
	{
		return vc_tpcall(CTHREQSVC);
	} else
	{
		return vc_tpcall(M_reqfwdsvc);
	}
}
