/*-----------------------------------------------------------------------
 * 
 * File		: falcon2.h
 * 
 * Author	: Ruslans Vasiljevs
 * 
 * Created	: 09/05/2022
 * 
 * Purpose	: Falcon2 constants
 * 
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
 *-----------------------------------------------------------------------*/
#ifndef __FALCON2_H
#define __FALCON2_H
/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/* Request from Falcon: */
#define TRAN_CODE_STOP_SENDING_REQ	"100000050"	/* Handshaking: Stop sending transactions */
#define TRAN_CODE_START_SENDING_REQ	"100000051"	/* Handshaking: Start sending transactions */
/* Reply from Falcon: */
#define TRAN_CODE_FALCON_SHUTDOWN	"000000052"	/* Handshaking: Falcon is shutting down */
#define TRAN_CODE_FALCON_UNAVAILABLE	"000000053"	/* Handshaking: Falcon is unavailable */
#define TRAN_CODE_PING			"200000060"	/* Handshaking: PING response message */
#define TRAN_CODE_PRIORITY_SCORING_RSP	"200000101"	/* Scoring: Priority scoring for online messages */
#define TRAN_CODE_SCORING_STANDARD_RSP	"200000102"	/* Scoring: Standard scoring for batch & rejected */

/* Request from Cortex: */
#define TRAN_CODE_ISREADY		"100000060"	/* Handshaking: Is Falcon ready for transactions? */
#define TRAN_CODE_PRIORITY_SCORING_REQ	"100000101"	/* Scoring: Priority scoring for online messages */
#define TRAN_CODE_SCORING_STANDARD_REQ	"100000102"	/* Scoring: Standard scoring for batch & rejected */
/* Reply from Cortex: */
#define TRAN_CODE_STOP_SENDING_RSP	"200000050"	/* Reply to 100000050 (on Stop sending transactions) */
#define TRAN_CODE_START_SENDING_RSP	"200000051"	/* Reply to 100000051 (on Start sending transactions) */

#define FA_MODE_SCORING		0
#define FA_MODE_REJECTED	1
#define FA_MODE_BATCH		2

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/

#endif /* __FALCON2_H */
