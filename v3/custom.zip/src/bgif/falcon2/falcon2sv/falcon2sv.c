/*-----------------------------------------------------------------------
 * 
 * File		: falcon2sv.c 
 * 
 * Author	: Ruslans Vasiljevs
 *
 * Created	: 06/05/2022
 * 
 * Purpose	: Falcon2 server
 * 
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
 *-----------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>

#include <condbsvi.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
ctxpublic char	*srv_module(void) { return "src"; }
ctxpublic char	*srv_name(void) { return "FALCON2SV"; }
ctxpublic int	falconmg_init(FILE *fp, char *subsect);
ctxpublic void	falconmg_uninit();

/*------------------------------------------------------------------------
 *
 * Function	:  
 *
 * Purpose	:  
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int  srv_init( FILE *fp, char *subsect )
{
	int ret = SUCCEED;

	srv_ndb_dummy();

	ret = falconmg_init(fp, subsect);

	return (ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  
 *
 * Purpose	:  
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic void  srv_uninit(void)
{
	falconmg_uninit();
}
