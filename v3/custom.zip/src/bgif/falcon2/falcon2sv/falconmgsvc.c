/*-----------------------------------------------------------------------
 * 
 * File		: falconmgsvc.c
 *
 * Author	: Ruslans Vasiljevs
 * 
 * Created	: 06/05/2022
 * 
 * Purpose	: The Falcon2 Network Management Service
 * 
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
 *-----------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <sys/stat.h>

#include <sldbg.h>
#include <slfdbg.h>
#include <slnfb.h>
#include <slntp.h>
#include <slcfp.h>
#include <slstm.h>

#include <cocbf.h>
#include <cocbfdef.h>
#include <comsgtyp.h>
#include <userlog.h>

#include <cust_prod.fd.h>

#include <hoststat.h>
#include <genif.h>

#include <dbhostrh.h>	/* HOSTDET_HOSTNAME_BUFFSIZE */

#include <falcon2.h>

/*---------------------------Externs------------------------------------*/

/*---------------------------Macros-------------------------------------*/
#define TAGNAME 		"FALCON2SV"	/* tag name of program	*/

#define POLLERROR(x)    ( POLL_ANYERR & (x) )

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
ctxprivate char	M_fifonm[CTX_FILENAME_MAX] = {EOS}; /* Full path to named pipe where the binary waits for responses */
ctxprivate int	M_rsptime; /* timeout for Falcon response (in milliseconds) */
ctxprivate char M_hostname[HOSTDET_HOSTNAME_BUFFSIZE] = {EOS}; /* FDSHOST/HOSTDET hostname */
ctxprivate char	M_svcnm[16+1] = "FALCON2NET"; /* Service name to advertise */
ctxprivate char	M_falconsvcnm[16+1] = "FALCON2IF"; /* Falcon2 interface name (for requests from CORTEX) */

/*---------------------------Prototypes---------------------------------*/
ctxprivate int	falconreq_process( FBFR **pp_fb );
ctxprivate int	cortexreq_process( FBFR **pp_fb );

/*------------------------------------------------------------------------
 *
 * Function	:  FALCON2NET
 *
 * Purpose	:  Falcon2 network management processing
 *
 * Parameters	:  Usual tpcall
 *
 * Returns	:  tpreturns
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic void FALCON2NET(TPSVCINFO *p_svc)
{
	FBFR	*p_fb = NULL;
	int	ret = SUCCEED;

	DBG_SETNAME(TAGNAME);

	p_fb = MAKE_BIGGER(p_svc->data);

	if (F_pres(p_fb, CS_FA_TRAN_CODE, 0)) /* if request from FALCON */
	{
		ret = falconreq_process(&p_fb);
	}
	else /* if request from CORTEX */
	{
		ret = cortexreq_process(&p_fb);
	}

	ntp_return( (FAIL == ret)
			? TPFAIL
			: TPSUCCESS,
			0L,
			(char *)p_fb,
			0L,
			0L);
}

/*--------------------------------------------------------------------------
 *
 * Function	: falconreq_process
 *
 * Purpose	: Falcon requests process
 *
 * Parameters	: 
 *
 * Returns	: SUCCEED/FAIL
 *
 *------------------------------------------------------------------------*/
ctxprivate int	falconreq_process( FBFR **pp_fb )
{
	int ret = SUCCEED;
	char *thisfn = "falconreq_process";
	int mfc = 0;
	char trancode[16] = {EOS};

	DBG_ENTRY(thisfn);
	
	if (SUCCEED != F_get(*pp_fb, CS_FA_TRAN_CODE, 0, trancode, 0L))
	{
		DBG_PRINTF((dbg_syserr, "Failed to get CS_FA_TRAN_CODE from FB"));
		ret = FAIL;
	}

	switch (mfc = cbf_get_fncode(*pp_fb))
	{
		case MFC_NETMGT_SIGN_ON:
			if (0 == strcmp(TRAN_CODE_START_SENDING_REQ, trancode))
			{
				if (SUCCEED == hst_upd_reqcurstat(M_hostname, 1, HRS_ON_LINE) )
				{
					cbf_gen_rsp(*pp_fb, MAC_NETMGT, MRS_NETMGT_OK);
					strcpy(trancode, TRAN_CODE_START_SENDING_RSP);
				}
				else
				{
					cbf_gen_rsp(*pp_fb, MAC_ERROR, MRS_RRSP_MALSYS);
					ret = FAIL;
				}
			}
			break;
		case MFC_NETMGT_SIGN_OFF:
			if (0 == strcmp(TRAN_CODE_STOP_SENDING_REQ, trancode))
			{
				if (SUCCEED == hst_upd_reqcurstat(M_hostname, 1, HRS_OFF_LINE) )
				{
					cbf_gen_rsp(*pp_fb, MAC_NETMGT, MRS_NETMGT_OK);
					strcpy(trancode, TRAN_CODE_STOP_SENDING_RSP);
				}
				else
				{
					cbf_gen_rsp(*pp_fb, MAC_ERROR, MRS_RRSP_MALSYS);
					ret = FAIL;
				}
			}
			break;
		default:
			DBG_PRINTF((dbg_syserr, "Unknown NetMgt fn %d", mfc));
			ret = FAIL;
			break;
	}

	if (SUCCEED != F_chg(*pp_fb, CS_FA_TRAN_CODE, 0, trancode, 0L))
	{
		DBG_PRINTF((dbg_syserr, "Failed to change CS_FA_TRAN_CODE in FB"));
		ret = FAIL;
	}

	DBG_EXIT(thisfn);
	
	return ret;
}

/*--------------------------------------------------------------------------
 *
 * Function	: cortexreq_process
 *
 * Purpose	: Cortex Network management messages process
 *
 * Parameters	: 
 *
 * Returns	: SUCCEED/FAIL
 *
 *------------------------------------------------------------------------*/
ctxprivate int	cortexreq_process( FBFR **pp_fb )
{
	int ret = SUCCEED;
	char *thisfn = "cortexreq_process";
	int mfc = 0;
	FBFR *p_rsp_fb = NULL;
	long rsplen = 0L;
	char trancode[16] = {EOS};
	ctxbool timeout = FALSE;
	ctxbool discarded;
	int sz;
struct	pollfd	poll_st[1];

	DBG_ENTRY(thisfn);

	strcpy(trancode, TRAN_CODE_ISREADY);
	if (SUCCEED != F_chg(*pp_fb, CS_FA_TRAN_CODE, 0, trancode, 0L))
	{
		DBG_PRINTF((dbg_syserr, "Failed to set CS_FA_TRAN_CODE in FB"));
		ret = FAIL;
	}

	if (SUCCEED == ret)
	{
		ret = ntp_call(M_falconsvcnm,
			       (char *)*pp_fb,
			       0L,
			       (char **)pp_fb,
			       &rsplen,
			       0);
	}

	if (SUCCEED == ret)
	{
		poll_st[0].events = POLLIN|POLLRDNORM;
		
		do
		{
			if (FBISREJ(*pp_fb))
			{
				DBG_PRINTF((dbg_syserr, "Request is rejected by %s", M_falconsvcnm));
				break;
			}

			DBG_PRINTF((dbg_proginfo, "Waiting on reply from Falcon on pipe..."));
			
			discarded = FALSE;
			poll_st[0].revents = 0;
			/* NOTE: open on a pipe with RDONLY and NDELAY */
			poll_st[0].fd = open(M_fifonm, O_RDONLY|O_NDELAY);
			/* Poll with waits until there is a writer on the other end - how convenient ! */
			switch( poll( poll_st, 1, M_rsptime))
			{
				case 1:
					DBG_STAR_PUTS(("Response from Falcon received via pipe"));
					if(POLLERROR(poll_st[0].revents))
					{
						if ( POLLHUP & poll_st[0].revents )
						{
							TRACE_PRINTF((trace_ev_down,
								"received POLLHUP"));
							DBG_PRINTF((dbg_progdetail,
								"received EOF"));
						}
						else
						{
							DBG_PRINTF(( dbg_syserr,
								"Error: 0x%x %s", poll_st[0].revents,
								strerror(errno)));
						}
					}
					else if( (POLLIN|POLLRDNORM) & poll_st[0].revents )
					{
						DBG_PRINTF((dbg_progdetail, "Got message"));
						sz = (int)F_sizeof(*pp_fb);
						if (!(p_rsp_fb = (FBFR *)ntp_alloc("FML", NULL, sz+64)))
						{
							DBG_PRINTF((dbg_syserr, "tp_alloc fail %d %s",
								ntp_errno(), ntp_strerror(ntp_errno())));
							ret = FAIL;
						}
						else if (FAIL == (int)read(poll_st[0].fd, (char *)p_rsp_fb, 
									   (size_t)sz+64))
						{
							DBG_PRINTF((dbg_syserr, "read fail %d", errno));
							ret = FAIL;
						}
						else if (FAIL == F_index(p_rsp_fb, 0))
						{
							DBG_PRINTF((dbg_syserr, "F_index fail %d %s",
								F_errno(), F_strerror(F_errno())));
							ret = FAIL;
						}
						else
						{
							DBG_DUMPFB(dbg_progdetail, "Response FB:", p_rsp_fb);
							if (!F_pres(p_rsp_fb, CS_FA_TRAN_CODE, 0))
							{
								DBG_PRINTF((dbg_proginfo,
									"Received message is not expected "
										"for the given request - discarded"));
								discarded = TRUE;
								(void)close(poll_st[0].fd);
								continue;
							}
							else if (SUCCEED != F_get(p_rsp_fb, CS_FA_TRAN_CODE, 0, 
										  trancode, 0L))
							{
								DBG_PRINTF((dbg_syserr, "Failed to get CS_FA_TRAN_CODE "
									"from FB"));
								ret = FAIL;
							}
						}
					}
					else
					{
						DBG_PRINTF(( dbg_proginfo,
							"Unexpected revent: 0x%x %s",
							poll_st[0].revents, strerror(errno)));
					}

					break;
				case 0:
					DBG_PRINTF((dbg_syserr, "Open fifo timeout: %s",
						strerror(errno)));
					timeout = TRUE;
					break;
				default:
					DBG_PRINTF(( dbg_syserr, "poll error: %s",
						strerror(errno) ));
					ret = FAIL;
			}

			if (SUCCEED != ret)
			{
				(void)close(poll_st[0].fd);
				break;
			}
			switch (mfc = cbf_get_fncode(*pp_fb))
			{
				case MFC_NETMGT_ECHO:
				case MFC_NETMGT_SIGN_ON:
					if (timeout)
					{
						cbf_gen_rsp(*pp_fb, MAC_ERROR, MRS_RRSP_ISSTIM);
					}
					else if (0 == strcmp(TRAN_CODE_PING, trancode))
					{
						F_chg(*pp_fb, CS_FA_TRAN_CODE, 0, trancode, 0L);
						cbf_gen_rsp(*pp_fb, MAC_AUTH_APP, MRS_NETMGT_OK);
					}
					else
					{
						DBG_PRINTF((dbg_proginfo,
							"Falcon transaction code [%s] is not expected "
								"for the given request - discarded", trancode));
						discarded = TRUE;
						(void)close(poll_st[0].fd);
						continue;
					}
					break;
				case MFC_NETMGT_SIGN_OFF:
					cbf_gen_rsp(*pp_fb, MAC_AUTH_APP, MRS_NETMGT_OK);
					break;
				default:
					DBG_PRINTF((dbg_syserr, "Unknown NetMgt fn %d", mfc));
					ret = FAIL;
					break;
			}

			(void)close(poll_st[0].fd);
		}
		while (discarded);
	}
	else
	{
		DBG_PRINTF((dbg_syserr,
			"tpcall %s failed %d [%s]",
			M_falconsvcnm,
			ntp_errno(), ntp_strerror(ntp_errno())));
	}

	if (NULL != p_rsp_fb)
	{
		ntp_free((char *)p_rsp_fb);
	}

	DBG_EXIT(thisfn);

	return ret;
}

/*--------------------------------------------------------------------------
 *
 * Function	: falconmg_init
 *
 * Purpose	: Server initialisation
 *
 * Parameters	: argc, argv - from command line
 *
 * Returns	: SUCCEED - initialised OK
 *		  FAIL - failed to initialise
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxpublic int falconmg_init(FILE *fp, char *subsect)
{
	int ret = SUCCEED;

	ctxprivate cfp_parm cfp[] =
	{
		{"SVCNM",	parm_string,	sizeof(M_svcnm),	FALSE,	M_svcnm,		0},
		{"HOSTNAME",	parm_string,	sizeof(M_hostname),	TRUE,	M_hostname,		0},
		{"PIPENAMENMG",	parm_string,	sizeof(M_fifonm),	TRUE,	M_fifonm,		0},
		{"TIMEOUT",	parm_int,	0,			TRUE,	(void *)&M_rsptime,	0},
		{"FALCON2IF",	parm_string,	sizeof(M_falconsvcnm),	FALSE,	M_falconsvcnm,		0},
		{0}
	};

	ctxprivate char *tagnm = TAGNAME;

	fprintf(stderr, "falconmg_init start with %s %s (%s)\n",
			tagnm, subsect, cfp_errparm());

	ret = cfp_parse(fp, cfp, tagnm, subsect);
	if (SUCCEED != ret)
	{
		userlog("falconmg_init failed (cfp_parse)");
		fprintf(stderr, "falconmg_init failed %s %s (%s)\n",
			tagnm, subsect, cfp_errparm());
	}

	if (0 == access(M_fifonm, F_OK))
	{
		DBG_PRINTF((dbg_syswarn, "WARNING! "
			"fifo <%s> already exists then unlink it before create new", M_fifonm));
		unlink(M_fifonm);
	}

	DBG_PRINTF((dbg_progdetail,"creating fifo: <%s>",M_fifonm));

	if (FAIL == mkfifo(M_fifonm, 0660))
	{
		DBG_PRINTF((dbg_syserr,
			"Mkfifo %s [%d]", M_fifonm, errno));
		M_fifonm[0] = EOS;
		ret = FAIL;
	}

	if (SUCCEED == ret)
	{
		if (FAIL == ntp_advertise(M_svcnm, FALCON2NET))
		{
			DBG_PRINTF((dbg_syserr, "tpadvertise %s failed %d %s",
				M_svcnm,
				ntp_errno(), ntp_strerror(ntp_errno())));
			ret = FAIL;
		}
	}

	if (SUCCEED == ret)
	{
		DBG_PRINTF((dbg_progdetail, "FALCON2SV started as %s service with:\n"
			" HOSTNAME:[%s]\n"
			" PIPENAME:[%s]\n"
			" TIMEOUT:[%d]\n"
			" FALCON2IF:[%s]"
			,
			M_svcnm,
			M_hostname,
			M_fifonm,
			M_rsptime,
			M_falconsvcnm));
	}
	else
	{
		DBG_PRINTF((dbg_syserr, "FALCON2SV init failed. Server not started!"));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  falconmg_uninit
 *
 * Purpose	:  Unlink pipe
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic void	falconmg_uninit()
{
	unlink(M_fifonm);
	M_fifonm[0] = EOS;
}
