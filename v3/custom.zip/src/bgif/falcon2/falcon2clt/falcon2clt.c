/*-----------------------------------------------------------------------
 * 
 * File		: falcon2clt.c
 * 
 * Author	: Ruslans Vasiljevs
 * 
 * Created	: 11/05/2022
 *
 * Purpose	: FALCON2 client
 * 
 * Comments	: 
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
 *-----------------------------------------------------------------------*/
/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>


#include <slfdbg.h>
#include <sldbg.h>
#include <slcfp.h>
#include <slclp.h>
#include <slntp.h>
#include <slnfb.h>
#include <slgsm.h>
#include <slmsgque.h>
#include <slgtp.h>
#include <slstring.h>

#include <enc.h>

#include <cortex.h>
#include <cocbfdef.h>
#include <cocbf.h>
#include <coevent.h>
#include <cocltmsg.h>
#include <comsgtyp.h>
#include <cotxnmon.h>

#include <coint.fd.h>
#include <cocrd.fd.h>
#include <cust_prod.fd.h>

#include <falcon2cv.h>
#include <ifevent.h>
#include <gdiev.h>
#include <gdiinet.h>

#include <hoststat.h>
#include <genif.h>

#include <bpd_prod.fd.h>
#include <token.fd.h>

/*---------------------------Externs------------------------------------*/
extern int	errno;
/*---------------------------Macros-------------------------------------*/
#define MODNM "if"
#define PROGNM "FALCON2CLT"

#define	SRVNM_LEN	64
#define	BUF_SIZE	2048
#define	PIPE_WAIT	1		/* pipe should already be there	*/

#define	WAIT_MSG	60
#define	EXIT_CTX_DEAD	1

#define DEFAULT_HANDSHAKESVC	"FALCON2NET"

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
enum states						/* states	*/
{
	st_read_msg,
	st_msgcnv,
	st_chk_msg,
	st_snd_rsp,
	st_snd_nmgrsp,
	st_snd_nmg,
	st_snd_rply,
	st_snd_ferply,
	st_error,
	st_return
};

enum events
{
	ev_ok = 0,
	ev_err,
	ev_rsp,		/* response (approve/deny)		*/
	ev_nmgrsp,	/* network mgt response 8xx		*/
	ev_nmgrq,	/* network mgt request 8xx		*/
	ev_poll,
	ev_comok
};

/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
ctxprivate int	M_err;

ctxprivate void	*M_p_mc = NULL;			/* state machine handle	*/
ctxprivate char M_tagnm[128];
ctxprivate long	M_msgkey;			/* message queue number	*/
ctxprivate char	M_hostname[SRVNM_LEN]; 		/* host name		*/
ctxprivate char	M_nmgpipe[CTX_FILENAME_MAX];	/* Full path to named pipe where FALCON2SV waits for responses */
ctxprivate char	M_handshakesvc[16+1] = DEFAULT_HANDSHAKESVC;/* Service name to sending handshaking requests */
ctxprivate char	M_lansvc[SRVNM_LEN];  		/* service for driver	*/

ctxprivate msgque_t	M_msgqueue = FAIL;
#ifdef TESTMODE
ctxprivate char	M_fifonm[CTX_FILENAME_MAX];
#endif

ctxprivate FBFR	*M_p_fb = NULL;		/* working fielded buffer	*/
ctxprivate char	M_buf[BUF_SIZE];	/* message buffer for queue	*/
ctxprivate int	M_buflen;		/* message length		*/

/*---------------------------Prototypes---------------------------------*/
ctxprivate int	fc_init(int argc, char **argv);
ctxprivate void	fc_uninit( void );
ctxprivate void	fc_main( void );
ctxprivate void	fc_sigdisp( int sig );
ctxprivate short fc_tpcall(char *svcnm);

ctxprivate short fc_read_msg( void );
#ifdef TESTMODE
ctxprivate short fc_read_msg_testmode( void );
#endif
ctxprivate short fc_msgcnv( void );
ctxprivate short fc_chk_msg( void );
ctxprivate short fc_snd_rsp( void );
ctxprivate short fc_snd_nmgrsp( void );
ctxprivate short fc_snd_nmg( void );
ctxprivate short fc_snd_rply(void);
ctxprivate short fc_snd_ferply(void);
ctxprivate short fc_error( void );

ctxprivate int fc_event( int ev );

ctxpublic int main( int argc, char **argv );

/*------------------------------------------------------------------------
 *
 * Function	:  main
 *
 * Purpose	:  Usual
 *
 * Parameters	:  Usual
 *
 * Returns	:  Usual
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int	main( int argc, char **argv )
{
	int ret;

        ret = fc_init( argc, argv );

	if (FAIL == ret)
                fprintf(stderr,"failed during init\n");

        if (FAIL != ret)
                fc_main();

        fc_uninit();

	return (SUCCEED == ret ? 0 : 1);
}

/*--------------------------------------------------------------------------
 *
 * Function	: fc_main
 *
 * Purpose	: Main processing loop for client
 *
 * Parameters	: void
 *
 * Returns	: void
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate void	fc_main( void )
{
	gsm_enter( M_p_mc, st_read_msg );

	return;
}

/*------------------------------------------------------------------------
 *
 * Function	:  fc_init
 *
 * Purpose	:  Initialisation
 *
 * Parameters	:  argc, argv
 *
 * Returns	:  SUCCEED - initialized
 *		   FAIL - error
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	fc_init( int argc, char **argv )
{
static	char subsect[128];
	int ret = SUCCEED;

ctxprivate gsm_states st[] =
	{
					/* Main state machine		*/
#ifdef TESTMODE
{GST(st_read_msg),	fc_read_msg_testmode,		st_return,	NULL},
#else
{GST(st_read_msg),	fc_read_msg,		st_return,	NULL},
#endif
{GST(st_msgcnv),	fc_msgcnv,		st_error,	NULL},
{GST(st_chk_msg),	fc_chk_msg,		st_error,	NULL},
{GST(st_snd_rsp),	fc_snd_rsp,		st_error,	NULL},
{GST(st_snd_nmgrsp),	fc_snd_nmgrsp,		st_error,	NULL},
{GST(st_snd_nmg),	fc_snd_nmg,		st_error,	NULL},
{GST(st_snd_rply),	fc_snd_rply,		st_error,	NULL},
{GST(st_snd_ferply),	fc_snd_ferply,		st_error,	NULL},
{GST(st_error),		fc_error,		st_read_msg,	NULL},
{GST(st_return),	fc_error,		0,		GSM_RETURN},
	};

ctxprivate gsm_trans tr[] =
	{
					/* main SM transitions		*/
{	st_read_msg,	GEV(ev_ok),	NULL,		st_msgcnv	},
{	st_read_msg,	GEV(ev_poll),	NULL,		st_read_msg	},
{	st_read_msg,	GEV(ev_comok),	NULL,		st_read_msg	},
{	st_msgcnv,	GEV(ev_ok),	NULL,		st_chk_msg	},
{	st_msgcnv,	GEV(ev_err),	NULL,		st_snd_ferply	},
{	st_chk_msg,	GEV(ev_rsp),	NULL,		st_snd_rsp	},
{	st_chk_msg,	GEV(ev_nmgrsp),	NULL,		st_snd_nmgrsp	},
{	st_chk_msg,	GEV(ev_nmgrq),	NULL,		st_snd_nmg	},
{	st_snd_rsp,	GEV(ev_ok),	NULL,		st_read_msg	},
{	st_snd_nmgrsp,	GEV(ev_ok),	NULL,		st_read_msg	},
{	st_snd_nmg,	GEV(ev_ok),	NULL,		st_snd_rply	},
{	st_snd_rply,	GEV(ev_ok),	NULL,		st_read_msg	},
{	st_snd_ferply,	GEV(ev_ok),	NULL,		st_read_msg	},
{FAIL}
	};

	ctxprivate cfp_parm cfp[] =
	{
		{"MSGQUEUE",		parm_hexlong,	0,			TRUE,	(void *)&M_msgkey,	0},
		{"LANSVCPFX",		parm_string,	sizeof(M_lansvc),	TRUE,	(void *)&M_lansvc,	0},
		{"HOSTNAME",		parm_string,	sizeof(M_hostname),	TRUE,	(void *)&M_hostname,	0},
		{"PIPENAMENMG",		parm_string,	sizeof(M_nmgpipe),	TRUE,	M_nmgpipe,		0},
		{"HANDSHAKESVC",	parm_string,	sizeof(M_handshakesvc),	FALSE,	M_handshakesvc,		0},
		{0}
	};
	
        /* Create a structure to hold the command line parameters */
        clp_parm clp[]=
        {
	        {'t', parm_string, sizeof(M_tagnm), TRUE, M_tagnm},
	        {'s', parm_string, sizeof(subsect), FALSE, subsect},
	        {0}
        };	
	
        char	buf[CTX_FILENAME_MAX];

	/* Parse the command line parameters. */
	if( SUCCEED == ( ret = clp_parse(argc, argv, clp) ) )
        {
	        ret = cfp_lite(cfp, M_tagnm, subsect );
          
		if(FAIL == ret)
		{
			fprintf(stderr, 
			"Unable to parse cfg file settings\n\n"
			"Required parameters are:\n\t"
			"MSGQUEUE\t- Message queue number to create\n\t"
                	"LANSVCPFX\t- TCPIP service to connect to\n\t"
			"HOSTNAME\t- Must exist in HOSTDET table\n\t"
                	"PIPENAMENMG\t- Network management fifo name\n\t"
                	"HANDSHAKESVC\t- Handshake service name (default: %s)\n", DEFAULT_HANDSHAKESVC );
		}
	} 
	else
	{
		fprintf( stderr, "Usage:\t%s -t <tag> -s <Subsection name>\n", argv[0] );
	}

	if (SUCCEED == ret)
	{
		ret = falcon2_init("");
		
       		/* set debug		*/
		DBG_SETNAME(M_tagnm);
	}
	if( FAIL != ret )
		if (FAIL == (ret = gsm_new(st, DIM(st)-1, tr, &M_p_mc)))
			DBG_PRINTF(( dbg_fatal, "gsm_new failed" ));

	if( FAIL != ret )
		if (DBG_GETLEV() >= dbg_progdetail)
			gsm_debug(M_p_mc, TRUE, PROGNM);

	if( FAIL != ret && FAIL == (ret = msgque_new((key_t)M_msgkey, &M_msgqueue) ) )
	{
		DBG_PRINTF((dbg_fatal, "Create/Open message queue %ld failed",
			    M_msgkey ));

		slsprintf_se( buf, slsafe_sizeof(buf), "%ld", M_msgkey );
		if (SUCCEED != ev_call(EVTAG_MSGQUE, buf))
			ret = ev_err;
	}

	if( FAIL != ret && NULL == getenv("CTXUSR"))
	{
	        DBG_PRINTF((dbg_syserr, "CTXUSR not set up"));
	        ret = FAIL;
      	}

	if( FAIL != ret )
	{
		if (SUCCEED != (ret = enc_init(NULL)))
			DBG_PRINTF((dbg_syserr, "Encryptor did not init"));
	}

	if( FAIL != ret )
	{
		signal(SIGINT,  fc_sigdisp);
		signal(SIGTERM, fc_sigdisp);
		signal(SIGQUIT, fc_sigdisp);
		signal(SIGSEGV, fc_sigdisp);
		signal(SIGALRM,fc_sigdisp);
	}

	/* This function required so that large messages are 
	 * handled properly */
	gtp_usebig();

	return( ret );
}

/*--------------------------------------------------------------------------
 *
 * Function	: fc_uninit
 *
 * Purpose	: Uninitialize the machinery
 *
 * Parameters	: 
 *
 * Returns	: void
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate void	fc_uninit( void )
{
	falcon2_uninit();
	
	gsm_delete( M_p_mc );

	if( 1 == ntp_getlev() )
		ntp_abort(0);

	DBG_FBDIFFENDL(dbg_progdetail, M_p_fb, DIFF_CLOSE);
	DBG_MINIDUMPFB(M_p_fb);
	DBG_STAR_PUTS(("Closing file created by FALCON2CLT! "));
	DBG_CLOSEFILE();

	ntp_free( (char *)M_p_fb );

	ntp_term();

	return;
}
/*--------------------------------------------------------------------------
 *
 * function	: fc_read_msg
 *
 * purpose	: read message from the message queue (with blocking)
 *
 * parameters	: void
 *
 * returns	: ev_ok / ev_comok / ev_poll / ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	fc_read_msg( void )
{
	short	ret = ev_ok;
	short	ret_code = SUCCEED;
	char	buf[12];

	DBG_MINIDUMPFB(M_p_fb);
	DBG_CLOSEFILE();
	M_err = err_allok;

	/* required as input to clt_read_msg, and set correctly on output */
	M_buflen = sizeof(M_buf);

	if( SUCCEED != (ret = clt_read_msg(M_buf, &M_buflen, M_msgqueue,
					   WAIT_MSG,clt_read_msg_action_check_parent)) )
	{
		ret = ev_err;
	}
	else if( GDI_NETMSGLEN == M_buflen )  /* Very primitive event maint */
	{
		sscanf( M_buf, "%2hd", &ret_code );
		DBG_PRINTF((dbg_progdetail, "ret_code %d", ret_code));
		switch( ret_code )
		{
		case gdi_com_ev_com_ok:
			ret = ev_comok;
		      
			if( SUCCEED !=
				hst_upd_comstat( M_hostname, 1, 
					   HCOMS_ON_LINE ) )
			{
				ret = ev_err;
			}
			else
			{
				slsprintf_se( buf, slsafe_sizeof(buf), "%ld", M_msgkey );
				if(SUCCEED !=
					ev_call(EVTAG_COMOK, buf))
				{
/*					ret = ev_err;*/
				}
			}
			break;
		      
		case gdi_com_ev_poll_err:
			ret = ev_poll;

			if( SUCCEED !=
				hst_upd_comstat( M_hostname, 1,
					   HCOMS_OFF_LINE ) )
			{
				ret = ev_err;
			}
			else
			{
				slsprintf_se( buf, slsafe_sizeof(buf),
						"%ld", M_msgkey );
				if(SUCCEED !=
					ev_call(EVTAG_POLL,buf))
					{
/*						ret = ev_err;*/
					}
			}
			break;
		      
		default:
			DBG_PRINTF((dbg_syserr,
					"Unknown event: %hd", ret_code));
			ret = ev_err;
			break;
		}
	}
	
	return( ret );
}

#ifdef TESTMODE
ctxprivate short fc_read_msg_testmode( void )
{
	short	ret = ev_ok;
	short	ret_code = SUCCEED;
	char	buf[12];
	int fd;
	int cnt = FAIL;

	DBG_MINIDUMPFB(M_p_fb);
	DBG_CLOSEFILE();
	M_err = err_allok;

	/* required as input to clt_read_msg, and set correctly on output */
	M_buflen = sizeof(M_buf);

	slstrcpy_sen(M_fifonm, getenv("CTXTMP"));
	slstrcat_sen(M_fifonm, "/falcon2.cltinput");

	DBG_PRINTF((dbg_progdetail,"creating fifo: <%s>",M_fifonm));

	if (FAIL == mkfifo(M_fifonm, 0660))
	{
		DBG_PRINTF((dbg_syserr,
			"Mkfifo %s [%d]", M_fifonm, errno));
		M_fifonm[0] = EOS;
		ret = ev_err;
	}
	else
	{
		DBG_PRINTF((dbg_progdetail, "===========================>  "
			"Waiting for a message"));
	}
					
	while( ev_ok == ret && FAIL == cnt )
	{
		alarm(WAIT_MSG);
		fd = open(M_fifonm, O_RDONLY);
		alarm(0);

		if (FAIL == fd)
		{
			DBG_PRINTF((dbg_progdetail, "Fifo timeout - waiting..."));
		}
		else
		{
			DBG_PRINTF((dbg_progdetail, "Got message"));
			if (FAIL == (cnt = (int)read(fd, M_buf, M_buflen)))
			{
				DBG_PRINTF((dbg_syserr, "read fail %d", errno));
				ret = ev_err;
			}
			else
			{
				M_buflen = cnt;
			}
		}
	}
	DBG_PRINTF((dbg_progdetail,"received %d bytes", M_buflen));

	(void)close(fd);

	unlink(M_fifonm);
	M_fifonm[0] = EOS;

	if( ev_ok == ret && GDI_NETMSGLEN == M_buflen )  /* Very primitive event maint */
	{
		sscanf( M_buf, "%2hd", &ret_code );
		DBG_PRINTF((dbg_progdetail, "ret_code %d", ret_code));
		switch( ret_code )
		{
			case gdi_com_ev_com_ok:
				ret = ev_comok;

				if( SUCCEED !=
				    hst_upd_comstat( M_hostname, 1,
						     HCOMS_ON_LINE ) )
				{
					ret = ev_err;
				}
				else
				{
					slsprintf_se( buf, slsafe_sizeof(buf), "%ld", M_msgkey );
					if(SUCCEED !=
					   ev_call(EVTAG_COMOK, buf))
					{
/*					ret = ev_err;*/
					}
				}
				break;

			case gdi_com_ev_poll_err:
				ret = ev_poll;

				if( SUCCEED !=
				    hst_upd_comstat( M_hostname, 1,
						     HCOMS_OFF_LINE ) )
				{
					ret = ev_err;
				}
				else
				{
					slsprintf_se( buf, slsafe_sizeof(buf),
						      "%ld", M_msgkey );
					if(SUCCEED !=
					   ev_call(EVTAG_POLL,buf))
					{
/*						ret = ev_err;*/
					}
				}
				break;

			default:
				DBG_PRINTF((dbg_syserr,
					"Unknown event: %hd", ret_code));
				ret = ev_err;
				break;
		}
	}

	return( ret );
}
#endif

/*--------------------------------------------------------------------------
 *
 * function	: fc_msgcnv
 *
 * purpose	: message conversion from: Falcon -> FML
 *
 * parameters	: void
 *
 * returns	: ev_ok / ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	fc_msgcnv( void )
{
	short	ret = ev_ok;


	ntp_free((char *)M_p_fb);

	/* A message has come in from the host (in M_buf), so start 
	 * up a fresh FB to put it in */
	if ( !(M_p_fb = (FBFR *)ntp_alloc("FML", NULL, 4096)) )
	{
		DBG_PRINTF((dbg_syserr, "FML alloc failed"));
		ev_tpallocfail(ntp_tperrno());
		ret = ev_err;
	}
	else
	{
		DBG_MONSTART(M_p_fb, PROGNM);
	}

	/* Stick the raw message into the FB for starters */
	if (ev_ok == ret && SUCCEED != F_chg( M_p_fb, I_NATMSG, 0, M_buf, M_buflen))
	{
		ret = ev_err;
	}
	
	if (ev_ok == ret && ret != falcon2cvin(M_p_fb)) /* Do the actual conversion from Falcon to Fielded buffer */
	{
		ret = ev_err;
	}

	return( ret );
}

/*--------------------------------------------------------------------------
 *
 * function	: fc_chk_msg
 *
 * purpose	: check message type
 *
 * parameters	: void
 *
 * returns	: ev_rsp / ev_rejrsp / ev_fin / ev_rec / ev_nmg /
 *		  ev_txt / ev_stiprev / ev_err
 *
 * comments	: This is where we have alook at the message and decide
 *		  what the hell we going to do with the thing.
 *
 *------------------------------------------------------------------------*/
ctxprivate short	fc_chk_msg( void )
{
	short	ret = ev_err;
	int	mc;
	char	trancode[9+1] = {EOS};

	mc = cbf_get_msg_class(M_p_fb);

	F_get(M_p_fb, CS_FA_TRAN_CODE, 0, trancode, 0L);

	/* It's a response message? */
	if ('1' != trancode[0])
	{
		DBG_PRINTF(( dbg_progdetail, "Reply from Falcon received" ));
		if (MCL_NETMGT == mc)
		{
			return ev_nmgrsp;
		}
		return ev_rsp;
	}

	DBG_SETDUMPMODE(M_p_fb, DUMP_ALWAYS);
	DBG_SETNAMEBYPAN(M_p_fb);
	DBG_STAR_PUTS(("FALCON2CLT (fc_chk_msg) - Starting NEW Debug file"));
	DBG_FBDIFFSTARTL(dbg_progdetail, M_p_fb);

	/* it's a request (only network mgt is available) */
	if (MCL_NETMGT == mc)
	{
		ret = ev_nmgrq;
	}
	else
	{
		DBG_PRINTF((dbg_syserr,
			"Unsupported req msg class 0x%X", mc));
		ret = ev_err;
	}

	return ret;
}

/*--------------------------------------------------------------------------
 *
 * function	: fc_snd_rsp
 *
 * purpose	: Send response to FALCON2IF via pipe
 *
 * parameters	: void
 *
 * returns	: ev_ok / ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	fc_snd_rsp( void )
{
	short	ret = ev_ok;
	char	pipenm[CTX_FILENAME_MAX];	/* name of the FIFO pipe */
	int	fd;
	int	nb;
	long	txmit = 0;
	long	stan;
	
	long tknlogreqid = 0;

	if (FAIL == CF_get(M_p_fb, C_STAN, 0, (char *)&stan, 0, FLD_LONG)
	 || FAIL== CF_get(M_p_fb, C_TIMEXMIT, 0, (char *)&txmit, 0, FLD_LONG) )
	{
		DBG_PRINTF((dbg_syserr, "Error: failed to get C_STAN or C_TIMEXMIT"));
		DBG_PRINTF((dbg_syserr, "Trying to get N_TKN_LOG_REQ_ID and BPDTKN_TIMELOCAL ..."));
		
		if (FAIL == CF_get(M_p_fb, N_TKN_LOG_REQ_ID, 0, (char *)&tknlogreqid, (FLDLEN)0, FLD_LONG)
		 || FAIL== CF_get(M_p_fb, BPDTKN_TIMELOCAL, 0, (char *)&txmit, 0, FLD_LONG) )
		{
			DBG_PRINTF((dbg_syserr, "Error: failed to get N_TKN_LOG_REQ_ID or BPDTKN_TIMELOCAL"));
			return ev_err;
		}
		else 
		{
			DBG_PRINTF((dbg_progdetail, "N_TKN_LOG_REQ_ID[%ld] BPDTKN_TIMELOCAL[%ld]", tknlogreqid, txmit));
			
			snprintf(pipenm, sizeof(pipenm), "%s/falcon2.%06ld%06ld", getenv("CTXTMP"), tknlogreqid, txmit);
		}
	}
	else
	{
		DBG_PRINTF((dbg_progdetail, "C_STAN[%ld] C_TIMEXMIT[%ld]", stan, txmit));
		
		snprintf(pipenm, sizeof(pipenm), "%s/falcon2.%06ld%06ld", getenv("CTXTMP"), stan, txmit);
	}

	alarm(PIPE_WAIT);
	if(FAIL == (fd = open(pipenm, O_WRONLY)))
	{
		DBG_PRINTF((dbg_syserr, "Can't open %s %s",
			pipenm,strerror(errno) ));
		return ev_err;
	}
	F_unindex(M_p_fb);
	if (FAIL == write(fd, (char *)M_p_fb, (nb = F_used(M_p_fb))))
	{
		DBG_PRINTF((dbg_syserr, "Can't write %s", pipenm));
		ret = ev_err;
	}
	else
	{
		DBG_PRINTF((dbg_progdetail, "Wrote %d bytes", nb));
		ret = ev_ok;
	}

	DBG_MONPRINT(M_p_fb, PROGNM);

	alarm(0);
	close(fd);

	return ret;
}

/*--------------------------------------------------------------------------
 *
 * function	: fc_snd_nmgrsp
 *
 * purpose	: Send Network management response to FALCON2SV via single pipe
 *
 * parameters	: void
 *
 * returns	: ev_ok / ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	fc_snd_nmgrsp( void )
{
	short	ret = ev_ok;
	int	fd;
	int	nb;

	alarm(PIPE_WAIT);
	if(FAIL == (fd = open(M_nmgpipe, O_WRONLY)))
	{
		DBG_PRINTF((dbg_syserr, "Can't open %s %s",
			M_nmgpipe,strerror(errno) ));
		return ev_err;
	}
	F_unindex(M_p_fb);
	if (FAIL == write(fd, (char *)M_p_fb, (nb = F_used(M_p_fb))))
	{
		DBG_PRINTF((dbg_syserr, "Can't write %s", M_nmgpipe));
		ret = ev_err;
	}
	else
	{
		DBG_PRINTF((dbg_progdetail, "Wrote %d bytes", nb));
		ret = ev_ok;
	}

	DBG_MONPRINT(M_p_fb, PROGNM);

	alarm(0);
	close(fd);

	return ret;
}

/*--------------------------------------------------------------------------
 *
 * function	: fc_snd_nmg
 *
 * purpose	: send network mgt (handshake) message 
 *
 * parameters	: void
 *
 * returns	: ev_ok /ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	fc_snd_nmg(void)
{
	return fc_tpcall(M_handshakesvc);
}

/*--------------------------------------------------------------------------
 *
 * function	: fc_snd_ferply
 *
 * purpose	: Send format error reply to request message
 *
 * parameters	: void
 *
 * returns	: ev_ok /ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	fc_snd_ferply(void)
{
	short	ret = ev_ok;
	FLDLEN	len;

	M_buflen = 0;
	memset(M_buf, NULL, sizeof(M_buf));

	if( ev_ok == ret && FAIL == F_get( M_p_fb, I_NATMSG, 0, M_buf, &len ) )
	{
		M_err = err_missfld;
		ret = ev_err;
	}

	if( ev_ok == ret )
	{
		M_buflen = len;
		
		DBG_PRINTF(( dbg_progdetail, "M_lansvc: %s",M_lansvc));
	        if (FAIL == gdinet_snd(M_buf, M_buflen, "", M_lansvc, &M_err))
	        {
		        M_err = err_putev;
		        ret = ev_err;
	        }
	}
	return( ret );
}

/*--------------------------------------------------------------------------
 *
 * function	: fc_snd_rply
 *
 * purpose	: Send reply to request message
 *
 * parameters	: void
 *
 * returns	: ev_ok /ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	fc_snd_rply(void)
{
	short	ret = ev_ok;
	FLDLEN	len;

	M_buflen = 0;

	if( SUCCEED != falcon2cvout( M_p_fb ) )
	{
		M_err = err_msgcnv;
		ret = ev_err;
	}

	if( ev_ok == ret )
	{
		memset( M_buf, 0, sizeof(M_buf) );
		len = 0;
	}

	if( ev_ok == ret && FAIL == F_get( M_p_fb, I_NATMSG, 0, M_buf, &len ) )
	{
		M_err = err_missfld;
		ret = ev_err;
	}

	if (!FBISNETMGT(M_p_fb) )
	{
		DBG_MONPRINT(M_p_fb, PROGNM);
	}

	if( ev_ok == ret )
	{
		M_buflen = len;
		
		DBG_PRINTF(( dbg_progdetail,"Sending to service:%s",M_lansvc));
	        if (FAIL == gdinet_snd(M_buf, M_buflen, "", M_lansvc, &M_err))
	        {
		        M_err = err_putev;
		        ret = ev_err;
	        }
	}
	
	return( ret );
}

/*--------------------------------------------------------------------------
 *
 * function	: fc_tpcall
 *
 * purpose	: Generic tpcall
 *
 * parameters	: void
 *
 * returns	: ev_ok /ev_err
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	fc_tpcall(char *svcnm)
{
	short	ret = ev_ok;
	long	rsplen = 0L;

	DBG_FBDIFFENDL(dbg_progdetail, M_p_fb, DIFF_OPEN);
	DBG_STAR(("ntp_call : %s",svcnm));
	DBG_FLUSH();

	if (FAIL == ntp_call(svcnm,
			     (char *)M_p_fb,
			     0L, 
			     (char **)&M_p_fb, 
			     &rsplen,
			     0))
	{
		DBG_STAR_PUTS(("Back to FALCON2CLT : (fc_tpcall)"));
		DBG_PRINTF((dbg_syserr, 
				"tpcall %s failed %d [%s]",
				svcnm,
				ntp_errno(), ntp_strerror(ntp_errno())));
		ev_svcfail(svcnm,ntp_errno());
		ret = ev_err;
	}

	if (ev_ok == ret)
	{
		DBG_STAR_PUTS(("Back to FALCON2CLT : (fc_tpcall)"));
	}

	return( ret );
}

/*--------------------------------------------------------------------------
 *
 * function	: fc_error
 *
 * purpose	: an error occurred - tell someone !
 *
 * parameters	: void
 *
 * returns	: ev_ok
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	fc_error( void )
{
	fc_event(M_err);

	return(ev_ok);
}

/*------------------------------------------------------------------------
 *
 * Function	:  fc_event
 *
 * Purpose	:  Log an error
 *
 * Parameters	:  ev - event type
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	fc_event( int ev )
{
	int	ret = SUCCEED;

	switch( ev )
	{
		case err_connect:
			ret = ev_call( EVTAG_LANERR, M_lansvc );
			break;

		case err_missfld:
		case err_msgcnv:
			ret = ev_call( EVTAG_MSGCONV, M_lansvc );
			break;

		case err_getev:
		case err_putev:
		case err_sndmsg:
			ret = ev_call( EVTAG_LOWCOM, M_lansvc );
			break;

		default:
			DBG_PRINTF(( dbg_syserr,"Invalid event: %d", ev ));
			ret = FAIL;
			break;
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * function	: fc_sigdisp
 *
 * purpose	: react on signal
 *
 * parameters	: sig - signal which caused interrupt
 *
 * returns	: 
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate void	fc_sigdisp( int sig )
{

	if( SIGALRM == sig )
	{
		signal( SIGALRM, fc_sigdisp );
	}
	else if( SIGQUIT == sig || SIGINT == sig || SIGTERM == sig )
	{
		DBG_PRINTF((dbg_syserr,
			    "Exiting due to receiving signal: %d", sig ));
#ifdef TESTMODE
		if (EOS != M_fifonm)
		{
			unlink(M_fifonm);
			M_fifonm[0] = EOS;
		}
#endif
		ntp_abort(0);
		exit(1);
	}
	else if( SIGSEGV == sig )
	{
		DBG_PRINTF((dbg_fatal,
			    "Exiting due to receiving signal: %d", sig ));
		ntp_abort(0);
		exit( 1 );
	}
	else
		DBG_PRINTF((dbg_syserr, "Unexpected signal %d", sig));

	return;
}
