/*-----------------------------------------------------------------------
 * 
 * File		: falcon2ifsv.c
 * 
 * Author	: Ruslans Vasiljevs
 * 
 * Created	: 09/05/2022
 *
 * Purpose	: FALCON2 server
 * 
 * Comments	: 
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
 *-----------------------------------------------------------------------*/
/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>

#include <cortex.h>
#include <condbsvi.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
static char rcsid[] = "$Id: //ps/cortex/latam/bpd/c/bpd-4.0/src/bgif/falcon2/falcon2if/falcon2ifsv.c#1 $";

/*---------------------------Prototypes---------------------------------*/
ctxpublic char	*srv_module(void) { return "src"; }
ctxpublic char	*srv_name(void) { return "FALCON2IF"; }
ctxpublic int	falcon2if_init( FILE *fp, char *subsect );
ctxpublic void	falcon2if_uninit();

/*------------------------------------------------------------------------
 *
 * Function	:  
 *
 * Purpose	:  
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int  srv_init( FILE *fp, char *subsect )
{
	int ret = SUCCEED;

	srv_ndb_dummy();	/* mention this to pull in condbsvi	*/

	ret = falcon2if_init(fp, subsect);

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	:  
 *
 * Purpose	:  
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic void  srv_uninit(void)
{
	falcon2if_uninit();
}
