/*-----------------------------------------------------------------------
 *
 * File		: fpadsvc.c
 *
 * Author	: Ruslans Vasiljevs
 * 
 * Created	: 02/05/2022
 *
 * Purpose	: PAD data collection services
 *
 * Comments	: 
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS.
 *-----------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <regex.h>

#include <sldbg.h>
#include <slfdbg.h>
#include <slcfp.h>
#include <slnfb.h>
#include <slntp.h>
#include <slstring.h>
#include <slstrip.h>
#include <sldtm.h>
#include <slregex.h>

#include <cocrd.fd.h>
#include <coint.fd.h>
#include <cust_prod.fd.h>

#include <cortex.h>
#include <cotux.h>
#include <coevent.h>
#include <cotxnmon.h>
#include <cocbfdef.h>
#include <cocbf.h>
#include <comsgtyp.h>
#include <crdstatupd.h>

#include <fds.h>

#include <dbcdetrh.h>
#include <dbcustrh.h>
#include <dbadetrh.h>
#include <dbfpadrecrh.h>
#include <dbfdshostrh.h>
#include <dberr.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define TAGNAME 	"FPADSV"	/* tag name of program             */

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
ctxprivate int 	M_validity = 30;	/* Number of days record is valid from the last score response to be used */
ctxprivate char	M_codestat_map[CTX_FILENAME_MAX+1] = {EOS};	/* Falcon decision code to card status mapping */

ctxprivate char	*M_re_code2crdstat = NULL;	/* "^(.+):(.+)$" */

ctxprivate FPADREC_t M_fpadrec;
ctxprivate char **M_decision_code_array;

ctxprivate FBFR *M_adddata_fb = NULL;

ctxprivate cotux_flds_t	M_fpadrec_flds[] =
{
	{ C_ACTIONCODE,      		M_fpadrec.actioncode,		sizeof(M_fpadrec.actioncode), 0,
		FLD_STRING,	FLD_OPT, NULL},
	{ C_RSPCODE,			M_fpadrec.rspcode,		sizeof(M_fpadrec.rspcode), 0,
		FLD_STRING,	FLD_OPT, NULL},
	{ C_CRDACPTBUS,			&M_fpadrec.crdacptbus,		0, 0,
		FLD_SHORT,	FLD_OPT, NULL},
	{ C_CRDACPTLOC_POSTCODE,	M_fpadrec.crdacptloc_postcode,	sizeof(M_fpadrec.crdacptloc_postcode), 0,
		FLD_STRING,	FLD_OPT, NULL},
	{ CS_FA_DECISION_CODE,		M_fpadrec.decision_code_1,	sizeof(M_fpadrec.decision_code_1), 0,
		FLD_STRING,	FLD_OPT, NULL},
	{ CS_FA_DECISION_CODE,		M_fpadrec.decision_code_2,	sizeof(M_fpadrec.decision_code_2), 1,
		FLD_STRING,	FLD_OPT, NULL},
	{ CS_FA_DECISION_CODE,		M_fpadrec.decision_code_3,	sizeof(M_fpadrec.decision_code_3), 2,
		FLD_STRING,	FLD_OPT, NULL},
	{ CS_FA_DECISION_CODE,		M_fpadrec.decision_code_4,	sizeof(M_fpadrec.decision_code_4), 3,
		FLD_STRING,	FLD_OPT, NULL},
	{ CS_FA_DECISION_CODE,		M_fpadrec.decision_code_5,	sizeof(M_fpadrec.decision_code_5), 4,
		FLD_STRING,	FLD_OPT, NULL},
	{ CS_FA_DECISION_CODE,		M_fpadrec.decision_code_6,	sizeof(M_fpadrec.decision_code_6), 5,
		FLD_STRING,	FLD_OPT, NULL},
	{ CS_FA_DECISION_CODE,		M_fpadrec.decision_code_7,	sizeof(M_fpadrec.decision_code_7), 6,
		FLD_STRING,	FLD_OPT, NULL},
	{ CS_FA_DECISION_CODE,		M_fpadrec.decision_code_8,	sizeof(M_fpadrec.decision_code_8), 7,
		FLD_STRING,	FLD_OPT, NULL},
	{ CS_FA_DECISION_CODE,		M_fpadrec.decision_code_9,	sizeof(M_fpadrec.decision_code_9), 8,
		FLD_STRING,	FLD_OPT, NULL},
	{ CS_FA_DECISION_CODE,		M_fpadrec.decision_code_10,	sizeof(M_fpadrec.decision_code_10), 9,
		FLD_STRING,	FLD_OPT, NULL},
	{ BADFLDID }
};

/*---------------------------Prototypes---------------------------------*/
ctxpublic void	FPADAUTH(TPSVCINFO *p_svc);
ctxpublic void	FPADUPD(TPSVCINFO *p_svc);
ctxpublic void	FALCON2INFO(TPSVCINFO *p_svc);
ctxpublic int	fpadsv_init( FILE *fp, char *subsect );
ctxprivate int	fpadauth_process( FBFR *p_fb );
ctxprivate int	fpadupd_process( FBFR *p_fb );
ctxprivate int	falcon2info_process( FBFR *p_fb );

ctxprivate ctxbool reqd_crdpres(FBFR *p_fb);
ctxprivate ctxbool reqd_crdsvccode(FBFR *p_fb);
ctxprivate ctxbool reqd_custcode(FBFR *p_fb);
ctxprivate char* code2crdstat(char* code, char* crdstat);
ctxprivate int rex_group(char *rx, char *str, regmatch_t *garray, int max_groups);
ctxprivate char* regmatch_group_get(char *str, regmatch_t *regmatch, int group);

ctxprivate int	Get_f(FBFR *p_fb, FLDID fid, int occ, char *val, FLDLEN *p_l);
ctxprivate int	Get_cf(FBFR *p_fb, FLDID fid, int occ, char *val, FLDLEN *p_l, int ty);

ctxprivate int	adddata_fb_init(FBFR *p_fb);
ctxprivate void	adddata_fb_uninit(void);

/*------------------------------------------------------------------------
 *
 * Function	:  fpadsv_init
 *
 * Purpose	:  
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int	fpadsv_init( FILE *fp, char *subsect )
{
	int	ret = SUCCEED;
static	cfp_parm cfp[] =
	{
		{"VALIDITY", parm_int, 0, FALSE, (void *)&M_validity, 0},
		{"CODE2CRDSTAT", parm_string, sizeof(M_codestat_map), TRUE, M_codestat_map, 0},
		{0}
	};


	ret = cfp_parse(fp, cfp, TAGNAME, subsect);

	if( SUCCEED != ret )
	{
		fprintf(stderr, "fpadsv init failed %s %s (%s)\n", TAGNAME, subsect, cfp_errparm());
	}
	else
	{
		DBG_SETNAME("FPADSV");		
	}

	if (SUCCEED != rex_comp(&M_re_code2crdstat, "^(.+):(.+)$", 0))
	{
		DBG_PRINTF((dbg_syserr, "compile REGEX failed"));
		return( FAIL );
	}

	M_decision_code_array = calloc(10+1, sizeof(char*));
	if (NULL == M_decision_code_array)
	{
		DBG_PRINTF((dbg_syserr, "calloc failed"));
		return( FAIL );
	}
	M_decision_code_array[0] = M_fpadrec.decision_code_1;
	M_decision_code_array[1] = M_fpadrec.decision_code_2;
	M_decision_code_array[2] = M_fpadrec.decision_code_3;
	M_decision_code_array[3] = M_fpadrec.decision_code_4;
	M_decision_code_array[4] = M_fpadrec.decision_code_5;
	M_decision_code_array[5] = M_fpadrec.decision_code_6;
	M_decision_code_array[6] = M_fpadrec.decision_code_7;
	M_decision_code_array[7] = M_fpadrec.decision_code_8;
	M_decision_code_array[8] = M_fpadrec.decision_code_9;
	M_decision_code_array[9] = M_fpadrec.decision_code_10;
	M_decision_code_array[10] = NULL;

	if (SUCCEED == ret)
	{
		if (FAIL == ntp_advertise("FPADAUTH", FPADAUTH))
		{
			DBG_PRINTF((dbg_syserr, "tpadvertise %s failed %d %s",
				"FPADAUTH", ntp_errno(), ntp_strerror(ntp_errno())));
			ret = FAIL;
		}
	}

	if (SUCCEED == ret)
	{
		if (FAIL == ntp_advertise("FPADUPD", FPADUPD))
		{
			DBG_PRINTF((dbg_syserr, "tpadvertise %s failed %d %s",
				"FPADUPD", ntp_errno(), ntp_strerror(ntp_errno())));
			ret = FAIL;
		}
	}

	if (SUCCEED == ret)
	{
		if (FAIL == ntp_advertise("FALCON2INFO", FALCON2INFO))
		{
			DBG_PRINTF((dbg_syserr, "tpadvertise %s failed %d %s",
				"FALCON2INFO", ntp_errno(), ntp_strerror(ntp_errno())));
			ret = FAIL;
		}
	}

	if (SUCCEED == ret)
	{
		DBG_PRINTF((dbg_progdetail, "FPADSV started with:\n"
			" CODE2CRDSTAT:[%s]\n"
			" VALIDITY:[%d]"
			,
			M_codestat_map,
			M_validity));
	}
	else
	{
		DBG_PRINTF((dbg_progdetail, "FPADSV init failed. Server not started!"));
	}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	:  fpadsv_uninit
 *
 * Purpose	:  Free the allocated memory
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic void	fpadsv_uninit()
{
	if (NULL != M_decision_code_array)
	{
		free(M_decision_code_array);
	}

	if (NULL != M_re_code2crdstat)
	{
		rex_free(M_re_code2crdstat);
	}
}

/*--------------------------------------------------------------------------
 *
 * Function	: FPADAUTH
 *
 * Purpose	: Service entry point for FPADAUTH
 *
 * Parameters	: Usual for service
 *
 * Returns	: tpreturn
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxpublic void	FPADAUTH( TPSVCINFO *p_svc )
{
	int	ret = SUCCEED;
	FBFR	*p_fb;

	DBG_SETNAME("FPADAUTH");

	/* try to reallocate FB to accommodate more data */
	p_fb = MAKE_BIGGER(p_svc->data);

	DBG_MONSTART(p_fb,"FPADAUTH");
	DBG_SETDUMPMODE(p_fb, DUMP_ATSTART);
	DBG_SETNAMEBYPAN(p_fb);
	DBG_STAR(("FPADAUTH service"));
	DBG_FBDIFFSTARTL(dbg_progdetail, p_fb);

	ret = adddata_fb_init(p_fb);

	if (SUCCEED == ret)
	{
		ret = fpadauth_process(p_fb);
	}

	adddata_fb_uninit();

	DBG_FBDIFFENDL(dbg_progdetail,p_fb,DIFF_CLOSE);
	DBG_PRINTF((dbg_progdetail, "FPADAUTH returns: %s", SUCCEED == ret ?
							   "TPSUCCESS" : "TPFAIL" ));

	DBG_STAR(("ntp_return from FPADAUTH"));

	DBG_FLUSH();
	DBG_CLOSEFILE();

	ntp_return( (FAIL == ret)
		    ? TPFAIL
		    : TPSUCCESS,
		    0L,
		    (char *)p_fb,
		    0L,
		    0L);
}

/*--------------------------------------------------------------------------
 *
 * Function	: FPADUPD
 *
 * Purpose	: Service entry point for FPADUPD
 *
 * Parameters	: Usual for service
 *
 * Returns	: tpreturn
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxpublic void	FPADUPD( TPSVCINFO *p_svc )
{
	int	ret = SUCCEED;
	FBFR	*p_fb;

	DBG_SETNAME("FPADUPD");

	/* try to reallocate FB to accommodate more data */
	p_fb = MAKE_BIGGER(p_svc->data);

	DBG_MONSTART(p_fb,"FPADUPD");
	DBG_SETDUMPMODE(p_fb, DUMP_ATSTART);
	DBG_SETNAMEBYPAN(p_fb);
	DBG_STAR(("FPADUPD service"));
	DBG_FBDIFFSTARTL(dbg_progdetail, p_fb);

	ret = adddata_fb_init(p_fb);

	if (0 == ntp_getlev())		/* not in transaction mode	*/
	{
		if ( SUCCEED != sql_begin())
		{
			ret = FAIL;
			DBG_PRINTF((dbg_syserr, "Could not sql_begin"));
			ev_beginfail(0L);
		}
	}

	if (SUCCEED == ret)
	{
		ret = fpadupd_process(p_fb);		
	}

	if (0 == ntp_getlev())		/* not in transaction mode	*/
	{
		if (SUCCEED == ret)
		{
			if (FAIL == sql_commit())
			{
				DBG_PRINTF((dbg_syserr, "Commit failed"));
				ev_commitfail(0L);
				sql_abort();
			}
		}
		else
		{
			DBG_PRINTF((dbg_syserr, "Aborting..."));
			sql_abort();
		}
	}

	adddata_fb_uninit();

	DBG_FBDIFFENDL(dbg_progdetail,p_fb,DIFF_CLOSE);
	DBG_PRINTF((dbg_progdetail, "FPADUPD returns: %s", SUCCEED == ret ?
							   "TPSUCCESS" : "TPFAIL" ));

	DBG_STAR(("ntp_return from FPADUPD"));

	DBG_FLUSH();
	DBG_CLOSEFILE();

	ntp_return( (FAIL == ret)
		    ? TPFAIL
		    : TPSUCCESS,
		    0L,
		    (char *)p_fb,
		    0L,
		    0L);
}

/*--------------------------------------------------------------------------
 *
 * Function	: FALCON2INFO
 *
 * Purpose	: Service entry point for FALCON2INFO
 *
 * Parameters	: Usual for service
 *
 * Returns	: tpreturn
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxpublic void	FALCON2INFO(TPSVCINFO *p_svc)
{
	int	ret = SUCCEED;
	FBFR	*p_fb;

	DBG_SETNAME("FALCON2INFO");

	/* try to reallocate FB to accommodate more data */
	p_fb = MAKE_BIGGER(p_svc->data);

	DBG_MONSTART(p_fb,"FALCON2INFO");
	DBG_SETDUMPMODE(p_fb, DUMP_ATSTART);
	DBG_SETNAMEBYPAN(p_fb);
	DBG_STAR(("FALCON2INFO service"));
	DBG_FBDIFFSTARTL(dbg_progdetail, p_fb);

	if (SUCCEED == ret)
	{
		ret = falcon2info_process(p_fb);
	}

	DBG_FBDIFFENDL(dbg_progdetail,p_fb,DIFF_CLOSE);
	DBG_PRINTF((dbg_progdetail, "FALCON2INFO returns: %s", SUCCEED == ret ?
							    "TPSUCCESS" : "TPFAIL" ));

	DBG_STAR(("ntp_return from FALCON2INFO"));

	DBG_FLUSH();
	DBG_CLOSEFILE();

	ntp_return( (FAIL == ret)
		    ? TPFAIL
		    : TPSUCCESS,
		    0L,
		    (char *)p_fb,
		    0L,
		    0L);
}

/*--------------------------------------------------------------------------
 *
 * Function	: fpadauth_process
 *
 * Purpose	: Falcon PAD authorization process
 *
 * Parameters	: 
 *
 * Returns	: SUCCEED/FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int	fpadauth_process(FBFR *p_fb)
{
	int	ret = SUCCEED;
	char *thisfn = "fpadauth_process";
	short action;
	char response[3] = {EOS};

	CRDDET_t crddet;
	CRDDET_HASH_t crddet_hash;
	FPADREC_HASH_t fpadrec_hash;

	DBG_ENTRY(thisfn);

	memset(&M_fpadrec, 0, sizeof(M_fpadrec));
	memset(&crddet, 0, sizeof(crddet));
	memset(&crddet_hash, 0, sizeof(crddet_hash));
	memset(&fpadrec_hash, 0, sizeof(fpadrec_hash));

	if ( SUCCEED!=Get_f(p_fb, C_PAN, 0, crddet_hash.pan, 0)
	     || SUCCEED!=Get_f(p_fb, C_CRDSEQNO, 0, (char *)&crddet_hash.seqno, 0) )
	{
		DBG_PRINTF((dbg_syserr, "Failed to get C_PAN/C_CRDSEQNO from FB"));
		ret = FAIL;
	}

	Get_f(p_fb, I_CRDDET_ID, 0, (char *)&fpadrec_hash.crddet_id, 0); /* Optional */

	if (SUCCEED == ret && 0 == fpadrec_hash.crddet_id)
	{
		if ( SUCCEED != (ret=CRDDETgetbyCRDDET_HASH(&crddet, &crddet_hash)) )
		{
			DBG_PRINTF((dbg_syserr, "Failed to get CRDDET from DB by pan=[%s], seqno=%hd",
				dbg_panMask(crddet_hash.pan), crddet_hash.seqno));
		}
		fpadrec_hash.crddet_id = crddet.id;
	}

	if (SUCCEED == ret)
	{
		ret = FPADRECgetbyFPADREC_HASH(&M_fpadrec, &fpadrec_hash);
		if (SQE_EOFERR == ret)
		{
			DBG_PRINTF((dbg_proginfo, "No FPADREC cached records found for the card [crddet_id=%ld]", 
				fpadrec_hash.crddet_id));
			ret = SUCCEED;
		}
		if (SUCCEED != ret)
		{
			DBG_PRINTF((dbg_syserr, "Failed to get FPADREC from DB by crddet_id=%ld",
				fpadrec_hash.crddet_id));
		}
	}

	/* If FPADREC successfully fetched */
	if (SUCCEED == ret && 0 < M_fpadrec.id)
	{
		if (date_diff(local_date(), M_fpadrec.dateupdated) > M_validity)
		{
			DBG_PRINTF((dbg_proginfo, "FPADREC record (id=%ld) age exceeds number of validity days [%d]. "
				"Transaction is assumed as not a fraud",
				M_fpadrec.id, M_validity));
		}
		else
		{
			if (MAC_AUTH_APP != M_fpadrec.actioncode[0])
			{
				if (SUCCEED != cotux_setfields(p_fb, M_fpadrec_flds, NULL))
				{
					DBG_PRINTF((dbg_syserr, "Failed to set FPADREC data in FB"));
					ret = FAIL;
				}
			}
			else
			{
				ret = F_chg(p_fb, CS_FA_DECISION_CODE, 0, M_fpadrec.decision_code_1, 0L);
			}
		}

	}

	if (FBISREJ(p_fb))
	{
		if (SUCCEED == CF_get(p_fb, C_ACTIONCODE, 0, (char *)&action, 0, FLD_SHORT)
		    && SUCCEED == CF_get(p_fb, C_RSPCODE, 0, response, 0, FLD_STRING))
		{
			cbf_gen_rsp2(p_fb, action, response,
				     RSPSRC_INTERFACE, NULL, RJR_IF_REJECT, NULL,
				     "Rejected by Falcon PAD authorization");
		}
		else
		{
			DBG_PRINTF((dbg_syserr, "Failed to get C_ACTIONCODE/C_RSPCODE from FB"));
		}
	}
	
	DBG_EXIT(thisfn);

	return ret;
}

/*--------------------------------------------------------------------------
 *
 * Function	: fpadupd_process
 *
 * Purpose	: Check the FDS host parameters and if thresholds are met, 
 * 		  data is updated
 *
 * Parameters	: 
 *
 * Returns	: SUCCEED/FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int	fpadupd_process(FBFR *p_fb)
{
	int	ret = SUCCEED;
	char *thisfn = "fpadupd_process";
	
	CRDDET_t crddet;
	CRDDET_HASH_t crddet_hash;
	FPADREC_HASH_t fpadrec_hash;
	FPADREC_t tmp_fpadrec;
	char **decision_code;
	short fdsaction;
	char statcode[CRDDET_STATCODE_BUFFSIZE] = {EOS};
	char new_statcode[CRDDET_STATCODE_BUFFSIZE] = {EOS};
	char expdate[5] = {EOS};
	char whymsg[CDSTHST_WHY_SET_BUFFSIZE] = {EOS};
	crdstatupd_t statupd;
	ctxbool update = FALSE;

	DBG_ENTRY(thisfn);

	memset(&M_fpadrec, 0, sizeof(M_fpadrec));
	memset(&crddet, 0, sizeof(crddet));
	memset(&crddet_hash, 0, sizeof(crddet_hash));
	memset(&fpadrec_hash, 0, sizeof(fpadrec_hash));

	if ( SUCCEED!=Get_f(p_fb, C_PAN, 0, crddet_hash.pan, 0)
	     || SUCCEED!=Get_f(p_fb, C_CRDSEQNO, 0, (char *)&crddet_hash.seqno, 0)
	     || SUCCEED!=Get_f(p_fb, I_CRDSTAT, 0, statcode, 0)
	     || (F_pres(p_fb, C_DATEEXP, 0) && SUCCEED!=Get_f(p_fb, C_DATEEXP, 0, (char *)expdate, 0)) )
	{
		DBG_PRINTF((dbg_syserr, "Failed to get C_PAN/C_CRDSEQNO/C_DATEEXP/I_CRDSTAT from FB"));
		ret = FAIL;
	}

	Get_f(p_fb, I_CRDDET_ID, 0, (char *)&fpadrec_hash.crddet_id, 0); /* Optional */
	
	if (SUCCEED == ret && 0 == fpadrec_hash.crddet_id)
	{
		if ( SUCCEED != (ret=CRDDETgetbyCRDDET_HASH(&crddet, &crddet_hash)) )
		{
			DBG_PRINTF((dbg_syserr, "Failed to get CRDDET from DB by pan=[%s], seqno=%hd", 
				dbg_panMask(crddet_hash.pan), crddet_hash.seqno));
		}
		fpadrec_hash.crddet_id = crddet.id;
	}

	if (SUCCEED == ret)
	{
		M_fpadrec.crddet_id = fpadrec_hash.crddet_id;
		ret = FPADRECgetbyFPADREC_HASH4upd(&tmp_fpadrec, &fpadrec_hash);
		if (SQE_EOFERR == ret)
		{
			M_fpadrec.dateupdated = M_fpadrec.datecreated = local_date();
			M_fpadrec.timeupdated = M_fpadrec.timecreated = local_time();
			ret = SUCCEED;
		}
		else if (SUCCEED == ret)
		{
			M_fpadrec.dateupdated = local_date();
			M_fpadrec.timeupdated = local_time();
			M_fpadrec.id = tmp_fpadrec.id;
			update = TRUE;
		}
		else
		{
			DBG_PRINTF((dbg_syserr, "Failed to get FPADREC from DB by crddet_id=%ld",
				fpadrec_hash.crddet_id));
		}
	}

	if (!FBISRSP(p_fb))
	{
		/* By default - probably approved decision code has received from Falcon. */
		M_fpadrec.actioncode[0] = MAC_AUTH_APP;
		M_fpadrec.actioncode[1] = EOS;
		strcpy(M_fpadrec.rspcode, MRS_AAPP_APP);
	}

	if (SUCCEED == ret && SUCCEED != cotux_getfields(p_fb, M_fpadrec_flds, NULL))
	{
		DBG_PRINTF((dbg_syserr, "Failed to get FPADREC data from FB"));
		ret = FAIL;
	}

	if (SUCCEED == ret)
	{
		if ( EOS!=expdate[0] && (0==strcmp(expdate, "0000") || EOS==stp_right(expdate)) )
		{
			/* We do not have expdate! */
			expdate[0]=EOS;
		}
		
		decision_code = M_decision_code_array;
		while (*decision_code)
		{
			/* if decision code is found and current card status is other than I_CRDSTAT */
			if (NULL != code2crdstat(*decision_code++, new_statcode) 
			    && 0 != strcmp(statcode, new_statcode))
			{
				if (SUCCEED != F_get(p_fb, I_FDSACTION, 0, (char *)&fdsaction, 0L))
				{
					DBG_PRINTF((dbg_syserr, "Failed to get I_FDSACTION from FB"));
					ret = FAIL;
				}
				else if (FDSSEND_REQUEST == fdsaction)
				{
					DBG_PRINTF((dbg_progdetail, "Scheduled card status change to [%s]", 
						new_statcode));
					if (SUCCEED != F_chg(p_fb, CS_FA_CRDSTATCODEUPD, 0, new_statcode, 0))
					{
						DBG_PRINTF((dbg_syserr, "Failed to change CS_FA_CRDSTATCODEUPD in FB"));
						ret = FAIL;
					}
				}
				else
				{
					slstrcpy_sen(whymsg, "Mapped by Falcon decision code");
					/* Initialize structures */
					if (SUCCEED != crdstatupd_init(&statupd,
								       crddet_hash.pan, crddet_hash.seqno, expdate,
								       new_statcode,
								       TAGNAME, whymsg))
					{
						DBG_PRINTF((dbg_progdetail, "Failed to initialise crdstatupd struct"));
						ret = FAIL;
					}
					else
					{
						ret = crdstatupd_updcrd(&statupd);
					}
				}
				
				break;
			}
		}
	}

	if (SUCCEED == ret)
	{
		if (update)
		{
			if ( SUCCEED != (ret=FPADRECupdate(&M_fpadrec)) )
			{
				DBG_PRINTF((dbg_syserr, "Failed to update FPADREC in DB (crddet_id=%ld)", 
					M_fpadrec.crddet_id));
			}
		}
		else
		{
			if ( SUCCEED != (ret=FPADRECadd(&M_fpadrec)) )
			{
				DBG_PRINTF((dbg_syserr, "Failed to create FPADREC in DB (crddet_id=%ld)", 
					M_fpadrec.crddet_id));
			}
		}

	}

	DBG_EXIT(thisfn);

	return ret;
}

/*--------------------------------------------------------------------------
 *
 * Function	: falcon2info_process
 *
 * Purpose	: Get FDSHOST.waittime and set it in FB field CS_FA_WAITTIME
 *
 * Parameters	: 
 *
 * Returns	: SUCCEED/FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int	falcon2info_process( FBFR *p_fb )
{
	int	ret = SUCCEED;
	char *thisfn = "falcon2info_process";

	FDSHOST_t fdshost;
	FDSHOST_HASH_t fdshost_hash;
	CRDDET_t crddet;
	CRDDET_PK_t crddet_pk;
	CRDDET_HASH_t crddet_hash;
	CUSTDET_t custdet;
	CUSTDET_PK_t custdet_pk;
	ACCDET_t accdet;
	ACCDET_PK_t accdet_pk;

	cotux_flds_t input_flds[] =
	{
		{ I_FDSHOSTNAME, fdshost_hash.hostname, sizeof(fdshost_hash.hostname), 0, FLD_STRING, FLD_MAND, NULL },
		{ I_CRDDET_ID, &crddet_pk.id, 0, 0, FLD_LONG, FLD_OPT, NULL },
		{ C_PAN, crddet_hash.pan, sizeof(crddet_hash.pan), 0, FLD_STRING, FLD_OPT, NULL },
		{ C_CRDSEQNO, &crddet_hash.seqno, 0, 0, FLD_SHORT, FLD_OPT, NULL },
		{ BADFLDID }
	};

	cotux_flds_t output_flds[] =
	{
		{ CS_FA_WAITTIME, &fdshost.waittime, 0, 0, FLD_LONG, FLD_MAND, NULL },
		{ I_CRDSVCCODE, crddet.svccode, sizeof(crddet.svccode), 0, FLD_STRING, FLD_COND, &reqd_crdpres },
		{ I_CUSTCODE, custdet.custcode, sizeof(custdet.custcode), 0, FLD_STRING, FLD_COND, &reqd_crdpres },
		{ C_ACCNO, accdet.accno, sizeof(accdet.accno), 0, FLD_STRING, FLD_COND, &reqd_crdpres },
		{ I_CRDSTAT, crddet.statcode, sizeof(crddet.statcode), 0, FLD_STRING, FLD_COND, &reqd_crdpres },
		{ BADFLDID }
	};

	DBG_ENTRY(thisfn);
	
	memset(&fdshost, 0, sizeof(fdshost));
	memset(&fdshost_hash, 0, sizeof(fdshost_hash));
	memset(&crddet, 0, sizeof(crddet));
	memset(&crddet_pk, 0, sizeof(crddet_pk));
	memset(&crddet_hash, 0, sizeof(crddet_hash));
	memset(&custdet, 0, sizeof(custdet));
	memset(&accdet, 0, sizeof(accdet));

	if (SUCCEED != cotux_getfields(p_fb, input_flds, NULL))
	{
		DBG_PRINTF((dbg_syserr, "Failed to get input data from FB"));
		ret = FAIL;
	}
	else if (SUCCEED != FDSHOSTgetbyFDSHOST_HASH(&fdshost, &fdshost_hash))
	{
		DBG_PRINTF((dbg_syserr, "Failed to get FDSHOST from DB by hostname=[%s]", fdshost_hash.hostname));
		ret = FAIL;
	}
	else if (0 < crddet_pk.id)
	{
		if (SUCCEED != CRDDETgetbyCRDDET_PK(&crddet, &crddet_pk))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get CRDDET from DB by id=[%ld]", 
				crddet_pk.id));
			ret = FAIL;
		}
	}
	else if (EOS != crddet_hash.pan[0])
	{
		if (SUCCEED != CRDDETgetbyCRDDET_HASH(&crddet, &crddet_hash))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get CRDDET from DB by pan=[%s]:%hd", 
				crddet_hash.pan, crddet_hash.seqno));
			ret = FAIL;
		}
	}
	
	if (SUCCEED == ret && 0 < crddet.custdet_id)
	{
		custdet_pk.id = crddet.custdet_id;
		if (SUCCEED != CUSTDETgetbyCUSTDET_PK(&custdet, &custdet_pk))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get CUSTDET from DB by id=[%ld]",
				custdet_pk.id));
			ret = FAIL;
		}
	}

	if (SUCCEED == ret && 0 < crddet.accdet_id)
	{
		accdet_pk.id = crddet.accdet_id;
		if (SUCCEED != ACCDETgetbyACCDET_PK(&accdet, &accdet_pk))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get ACCDET from DB by id=[%ld]",
				accdet_pk.id));
			ret = FAIL;
		}
	}
	
	if (SUCCEED == ret && SUCCEED != cotux_setfields(p_fb, output_flds, NULL))
	{
		DBG_PRINTF((dbg_syserr, "Failed to set output data in FB"));
		ret = FAIL;
	}

	DBG_EXIT(thisfn);

	return ret;
}

/*------------------------------------------------------------------------------
 *
 * Function	:  reqd_crdpres
 *
 * Purpose	:  Conditional function to check if card is present
 *
 * Parameters	:  p_fb - fielded buffer
 *
 * Returns	:  TRUE/FALSE
 *
 *----------------------------------------------------------------------------*/
ctxprivate ctxbool reqd_crdpres(FBFR *p_fb)
{
	return F_pres(p_fb, I_CRDDET_ID, 0) || F_pres(p_fb, C_PAN, 0);
}

/*------------------------------------------------------------------------------
 *
 * Function	:  reqd_crdsvccode
 *
 * Purpose	:  Conditional function to check if card service code is required
 *
 * Parameters	:  p_fb - fielded buffer
 *
 * Returns	:  TRUE/FALSE
 *
 *----------------------------------------------------------------------------*/
ctxprivate ctxbool reqd_crdsvccode(FBFR *p_fb)
{
	return !F_pres(p_fb, I_CRDSVCCODE, 0) && reqd_crdpres(p_fb);
}

/*------------------------------------------------------------------------------
 *
 * Function	:  reqd_custcode
 *
 * Purpose	:  Conditional function to check if customer code is required
 *
 * Parameters	:  p_fb - fielded buffer
 *
 * Returns	:  TRUE/FALSE
 *
 *----------------------------------------------------------------------------*/
ctxprivate ctxbool reqd_custcode(FBFR *p_fb)
{
	return !F_pres(p_fb, I_CUSTCODE, 0) && reqd_crdpres(p_fb);
}

/*------------------------------------------------------------------------------
 *
 * Function	:  code2crdstat
 *
 * Purpose	:  Evaluate decision code against the list of CODE2CRDSTAT map
 *
 * Parameters	:  code (in) Falcon decision code
 * 		   crdstat (out) card status
 *
 * Returns	:  card status
 *
 *----------------------------------------------------------------------------*/
ctxprivate char* code2crdstat(char* code, char* crdstat)
{
	char *item;
	char *group;
	char *result = NULL;
	regmatch_t regmatch[2+1];	/* regex match + 2 group */
	char tmp_codestat_map[CTX_FILENAME_MAX+1] = {EOS};

	if (NULL == code || EOS == code[0])
	{
		return NULL;
	}

	strscpy(tmp_codestat_map, M_codestat_map);
	item = strtok(tmp_codestat_map,",");
	while(NULL != item)
	{
		if (SUCCEED == rex_group(M_re_code2crdstat, item, regmatch, 2+1))
		{
			group = regmatch_group_get(item, regmatch, 1);
			if (0 == strcmp(stp_both(group), code))
			{
				result = regmatch_group_get(item, regmatch, 2);
			}
			if (NULL != result)
			{
				stp_both(result);
				if (NULL != crdstat)
				{
					slstrcpy(crdstat, result);
				}
				break;
			}
		}
		
		item = strtok(NULL, ",");
	}
	
	return result;
}

/*------------------------------------------------------------------------------
 *
 * Function	:  regmatch_group_get
 *
 * Purpose	:  Get matching string from regex match groups
 *
 * Parameters	:  str (in) source string
 * 		   regmatch (in) regex match groups
 * 		   group (in) regex match group number
 *
 * Returns	:  regex matched group
 *
 *----------------------------------------------------------------------------*/
ctxprivate char* regmatch_group_get(char *str, regmatch_t *regmatch, int group)
{
static	char buf[64];
	int len;

	if (regmatch[group].rm_so == (size_t)-1)
	{
		return NULL;  /* No more groups */
	}

	len = (int)(regmatch[group].rm_eo - regmatch[group].rm_so);
	strnscpy(buf, str+regmatch[group].rm_so, (size_t)len);
	buf[len] = EOS;

	return buf;
}

/*------------------------------------------------------------------------------
 *
 * Function	:  rex_group
 *
 * Purpose	:  Execute regular expression match on compiled regex
 * 		   and find results by groups
 *
 * Parameters	:  rx (in) compiled regex
 * 		   str (in) source string
 * 		   garray (out) regex match groups
 * 		   max_groups (in) maximum number of matches by group
 *
 * Returns	:  SUCCEED/FAIL
 *
 *----------------------------------------------------------------------------*/
ctxprivate int rex_group(char *rx, char *str, regmatch_t *garray, int max_groups)
{
	int ret = SUCCEED;
	int  status;

	status = regexec((regex_t*)rx , str, (size_t) max_groups, garray, 0);

	if (status != 0)
	{
		ret = FAIL;
	}
	return ret;
}

/*------------------------------------------------------------------------------
 *
 * Function	:  Get_f
 *
 * Purpose	:  Retrieve field value from fielded buffer, 
 * 		   with using fallback fielded buffer from CS_FA_ADDDATA
 *
 * Parameters	:  p_fb	Fielded buffer
 * 		   fid	Field ID
 * 		   occ	Field occurence
 * 		   val	Buffer to retrieved field value
 * 		   p_l	Optional field length to retrieve
 * 		   
 *
 * Returns	:  SUCCEED/FAIL
 * 
 * Notes	:  To use fallback fielded buffer from CS_FA_ADDDATA
 * 		   it is should to be initialise first by adddata_fb_init
 *
 *----------------------------------------------------------------------------*/
ctxprivate int Get_f(FBFR *p_fb, FLDID fid, int occ, char *val, FLDLEN *p_l)
{
	int ret = SUCCEED;
	FBFR *fb = NULL;

	fb = F_pres(p_fb, fid, 0) ? p_fb : M_adddata_fb;
	
	if (NULL == fb || SUCCEED != F_get(fb, fid, occ, val, p_l))
	{
		DBG_PRINTF(( dbg_syserr, "Get_f failed: %s[%d]", F_name(fid), occ ));
		ret = FAIL;
	}
	
	return ret;
}

/*------------------------------------------------------------------------------
 *
 * Function	:  Get_cf
 *
 * Purpose	:  Retrieve field value from fielded buffer and do conversion, 
 * 		   with using fallback fielded buffer from CS_FA_ADDDATA
 *
 * Parameters	:  p_fb	Fielded buffer
 * 		   fid	Field ID
 * 		   occ	Field occurence
 * 		   val	Buffer to retrieved field value
 * 		   p_l	Optional field length to retrieve
 * 		   ty	Buffer type
 * 		   
 *
 * Returns	:  SUCCEED/FAIL
 * 
 * Notes	:  To use fallback fielded buffer from CS_FA_ADDDATA
 * 		   it is should to be initialise first by adddata_fb_init
 *
 *----------------------------------------------------------------------------*/
ctxprivate int Get_cf(FBFR *p_fb, FLDID fid, int occ, char *val, FLDLEN *p_l, int ty)
{
	int ret = SUCCEED;
	FBFR *fb = NULL;

	fb = F_pres(p_fb, fid, 0) ? p_fb : M_adddata_fb;

	if (NULL == fb || SUCCEED != CF_get(fb, fid, occ, val, p_l, ty))
	{
		DBG_PRINTF(( dbg_syserr, "Get_cf failed: %s[%d]", F_name(fid), occ ));
		ret = FAIL;
	}

	return ret;
}

/*------------------------------------------------------------------------------
 *
 * Function	:  adddata_fb_init
 *
 * Purpose	:  Initialise fallback fielded buffer from CS_FA_ADDDATA
 *
 * Parameters	:  p_fb	Fielded buffer
 * 		   
 *
 * Returns	:  SUCCEED/FAIL
 * 
 * Notes	:  Is used by functions Get_f and Get_cf
 * 
 *----------------------------------------------------------------------------*/
ctxprivate int adddata_fb_init(FBFR *p_fb)
{
	int ret = SUCCEED;
	unsigned size = BLOB_BUFSIZE;
	
	if (F_pres(p_fb, CS_FA_ADDDATA, 0))
	{
		if (!(M_adddata_fb = (FBFR *)ntp_alloc("FML", NULL, size)))
		{
			DBG_PRINTF((dbg_syserr, "tp_alloc fail %d %s",
				ntp_errno(), ntp_strerror(ntp_errno())));
			ret = FAIL;
		}
		else if (SUCCEED != CF_get(p_fb, CS_FA_ADDDATA, 0,
					   (char *)M_adddata_fb, &size, FLD_FML32))
		{
			DBG_PRINTF((dbg_syserr, "Failed to restore sub-FB from CS_FA_ADDDATA"));

			ntp_free((char *)M_adddata_fb);
			M_adddata_fb = NULL;
			ret = FAIL;
		}
	}
	
	return ret;
}

/*------------------------------------------------------------------------------
 *
 * Function	:  adddata_fb_uninit
 *
 * Purpose	:  Un-initialise fallback fielded buffer
 *
 * Parameters	:  void
 * 		   
 *
 * Returns	:  void
 * 
 *----------------------------------------------------------------------------*/
ctxprivate void adddata_fb_uninit(void)
{
	if (NULL != M_adddata_fb)
	{
		ntp_free((char *)M_adddata_fb);
		M_adddata_fb = NULL;
	}
}
