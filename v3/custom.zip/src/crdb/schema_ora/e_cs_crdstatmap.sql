-- primary key for crdstatmap table
create unique index pk_crdstatmap
	on crdstatmap (ext_statcode);

alter table crdstatmap
	add constraint pk_crdstatmap primary key (ext_statcode);
