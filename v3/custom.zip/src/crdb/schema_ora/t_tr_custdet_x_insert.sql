
create or replace trigger custdet_x_insert before insert on custdet_x
referencing new as new_custdet_x
for each row
begin
        if (:new_custdet_x.id is null or :new_custdet_x.id = 0) then
                select custdet_x_sequence.nextval into :new_custdet_x.id from dual;
        end if;
end;
/

