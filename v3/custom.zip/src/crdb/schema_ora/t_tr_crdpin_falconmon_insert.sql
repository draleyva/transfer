--
-- CRDPIN_FALCONMON_INSERT  (Trigger) 
--
CREATE OR REPLACE TRIGGER CRDPIN_FALCONMON_INSERT AFTER INSERT ON CRDPIN 
REFERENCING NEW AS new_crdpin
FOR EACH ROW
BEGIN
    nmon_addlog('CRDPIN', :new_crdpin.crddet_id, 'I', '3020', 
    		newvalue1=>TO_CHAR(SYSDATE, 'YYYYMMDD'),
    		newvalue2=>:new_crdpin.pintype
    );
END;
/

