--
-- PIS12_LOG_INSERT  (Trigger) 
--
CREATE OR REPLACE TRIGGER PIS12_LOG_INSERT before insert ON PIS12_LOG 
referencing new as new_pis12_log
for each row
begin
    if (:new_pis12_log.id is null or :new_pis12_log.id = 0) then
        select pis12_log_sequence.nextval into :new_pis12_log.id from dual;
    end if;
end;
/

