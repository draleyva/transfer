
CREATE OR REPLACE FUNCTION get_adds_email_tel_cm_id (i_crddet_id	crddet.id%TYPE DEFAULT NULL,
						i_cmpt_id		prt_cmpt.id%TYPE,
						i_tab_nm		VARCHAR2,
						i_custdet_id	custdet.id%TYPE DEFAULT NULL)
RETURN NUMBER
IS
	r_cm_id	prt_cm.id%TYPE :=0 ;
	quary_str	VARCHAR2(5000);
	v_cmpt_dft_id	prt_cmpt.id%TYPE;
BEGIN
	IF	LENGTH(TO_CHAR(i_cmpt_id)) >= 4 THEN
		v_cmpt_dft_id := TO_NUMBER(SUBSTR(TO_CHAR(i_cmpt_id), 1, 2) || '00');
	ELSE
		v_cmpt_dft_id := 0;
	END IF;
	
	IF i_crddet_id IS NOT NULL AND i_crddet_id != 0 THEN
		BEGIN
			quary_str := ' select '|| i_tab_nm ||'.prt_cm_id 
				from '|| i_tab_nm || ', 
				prt_pcm, 
				prt_pcmp,  
				prt_pcmp_media, 
				prt_person,
				prt_cmpt,
				prt_prt,
				prt_cmt,
				custdet c,
				inst i,
				crddet crd
			where	c.inst_id = i.id
			and	prt_person.custdet_id = c.id
			and prt_pcm.prt_prt_id = prt_prt.id
			and prt_pcm.prt_party_id = prt_person.prt_party_id
			and prt_pcmp.prt_cm_id = prt_pcm.prt_cm_id
			and prt_pcmp.prt_cmt_id = prt_pcm.prt_cmt_id
			and prt_pcmp.prt_prt_id = prt_pcm.prt_prt_id
			and prt_pcmp.prt_party_id = prt_pcm.prt_party_id
			and prt_pcmp.prt_pcm_from_date = prt_pcm.from_date
			and prt_pcmp_media.prt_cmpt_id = prt_cmpt.id
			and prt_cmt.id = '|| i_tab_nm ||'.prt_cmt_id
			and prt_pcm.prt_cm_id = '|| i_tab_nm ||'.prt_cm_id
			and prt_pcmp_media.mediatype_id = 0
			and prt_pcmp_media.prt_cmpt_id = prt_pcmp.prt_cmpt_id
			and prt_pcmp_media.prt_party_id = prt_pcmp.prt_party_id
			and prt_pcmp_media.prt_cm_id = prt_pcmp.prt_cm_id
			and prt_pcmp_media.prt_cmt_id = prt_pcmp.prt_cmt_id
			and prt_pcmp_media.media_id = crd.id
			and prt_pcmp_media.prt_prt_id = prt_pcmp.prt_prt_id
			and prt_pcmp_media.prt_pcm_from_date = prt_pcmp.prt_pcm_from_date
			and prt_pcmp_media.prt_pcmp_from_date = prt_pcmp.from_date
			and prt_pcmp.from_date <= (select trunc(sysdate) from dual) 
			and prt_pcmp.until_date >= (select trunc(sysdate) from dual) 
			and prt_pcm.from_date <= (select trunc(sysdate) from dual) 
			and prt_pcm.until_date >= (select trunc(sysdate) from dual)
			and prt_pcmp.from_date = (select max(prt_pcmp_from_date) from prt_pcmp_media t
						where prt_pcmp_media.mediatype_id = t.mediatype_id
						and prt_pcmp_media.prt_cmpt_id = t.prt_cmpt_id
						and prt_pcmp_media.prt_party_id = t.prt_party_id
						and prt_pcmp_media.prt_cm_id = t.prt_cm_id
						and prt_pcmp_media.prt_cmt_id = t.prt_cmt_id
						and prt_pcmp_media.media_id = t.media_id
						and prt_pcmp_media.prt_prt_id = t.prt_prt_id
										group by t.media_id, t.prt_cmpt_id)
			and prt_pcmp.usage_type_id = 0
			and	prt_pcmp.prt_cmpt_id = '|| i_cmpt_id ||'
			and	crd.id = '|| i_crddet_id;
			
			EXECUTE IMMEDIATE quary_str INTO r_cm_id;
		  RETURN r_cm_id;
		EXCEPTION WHEN NO_DATA_FOUND THEN
			BEGIN
				quary_str := ' select '|| i_tab_nm ||'.prt_cm_id 
					from '|| i_tab_nm || ', 
					prt_pcm, 
					prt_pcmp,  
					prt_pcmp_media, 
					prt_person,
					prt_cmpt,
					prt_prt,
					prt_cmt,
					custdet c,
					inst i,
					crddet crd
				where	c.inst_id = i.id
				and	prt_person.custdet_id = c.id
				and prt_pcm.prt_prt_id = prt_prt.id
				and prt_pcm.prt_party_id = prt_person.prt_party_id
				and prt_pcmp.prt_cm_id = prt_pcm.prt_cm_id
				and prt_pcmp.prt_cmt_id = prt_pcm.prt_cmt_id
				and prt_pcmp.prt_prt_id = prt_pcm.prt_prt_id
				and prt_pcmp.prt_party_id = prt_pcm.prt_party_id
				and prt_pcmp.prt_pcm_from_date = prt_pcm.from_date
				and prt_pcmp_media.prt_cmpt_id = prt_cmpt.id
				and prt_cmt.id = '|| i_tab_nm ||'.prt_cmt_id
				and prt_pcm.prt_cm_id = '|| i_tab_nm ||'.prt_cm_id
				and prt_pcmp_media.mediatype_id = 0
				and prt_pcmp_media.prt_cmpt_id = prt_pcmp.prt_cmpt_id
				and prt_pcmp_media.prt_party_id = prt_pcmp.prt_party_id
				and prt_pcmp_media.prt_cm_id = prt_pcmp.prt_cm_id
				and prt_pcmp_media.prt_cmt_id = prt_pcmp.prt_cmt_id
				and prt_pcmp_media.media_id = crd.id
				and prt_pcmp_media.prt_prt_id = prt_pcmp.prt_prt_id
				and prt_pcmp_media.prt_pcm_from_date = prt_pcmp.prt_pcm_from_date
				and prt_pcmp_media.prt_pcmp_from_date = prt_pcmp.from_date
				and prt_pcmp.from_date <= (select trunc(sysdate) from dual) 
				and prt_pcmp.until_date >= (select trunc(sysdate) from dual) 
				and prt_pcm.from_date <= (select trunc(sysdate) from dual) 
				and prt_pcm.until_date >= (select trunc(sysdate) from dual)
				and prt_pcmp.usage_type_id = 0
				and	prt_pcmp.prt_cmpt_id = '|| v_cmpt_dft_id ||'
				and	crd.id = '|| i_crddet_id;
				
				EXECUTE IMMEDIATE quary_str INTO r_cm_id;
				RETURN r_cm_id;
			EXCEPTION WHEN NO_DATA_FOUND THEN
				BEGIN
					quary_str := ' select '|| i_tab_nm ||'.prt_cm_id 
						from '|| i_tab_nm || ', 
						prt_pcm, 
						prt_pcmp,   
						prt_person,
						prt_cmpt,
						prt_prt,
						prt_cmt,
						custdet c,
						inst i,
						crddet crd
					where	c.inst_id = i.id
					and	crd.custdet_id = c.id
					and	prt_person.custdet_id = c.id
					and prt_pcm.prt_prt_id = prt_prt.id
					and prt_pcm.prt_party_id = prt_person.prt_party_id
					and prt_pcmp.prt_cm_id = prt_pcm.prt_cm_id
					and prt_pcmp.prt_cmt_id = prt_pcm.prt_cmt_id
					and prt_pcmp.prt_prt_id = prt_pcm.prt_prt_id
					and prt_pcmp.prt_party_id = prt_pcm.prt_party_id
					and prt_pcmp.prt_pcm_from_date = prt_pcm.from_date
					and prt_pcmp.prt_cmpt_id = prt_cmpt.id
					and prt_cmt.id = '|| i_tab_nm ||'.prt_cmt_id
					and prt_pcm.prt_cm_id = '|| i_tab_nm ||'.prt_cm_id
					and prt_pcmp.from_date <= (select trunc(sysdate) from dual) 
					and prt_pcmp.until_date >= (select trunc(sysdate) from dual) 
					and prt_pcm.from_date <= (select trunc(sysdate) from dual) 
					and prt_pcm.until_date >= (select trunc(sysdate) from dual)
					and prt_pcmp.from_date = (select max(from_date) from prt_pcmp t
											where prt_pcmp.prt_cmpt_id = t.prt_cmpt_id
											and prt_pcmp.prt_party_id = t.prt_party_id
											and prt_pcmp.prt_cmt_id = t.prt_cmt_id
											and prt_pcmp.prt_prt_id = t.prt_prt_id)
					and prt_pcmp.until_date = to_date(''31082263'',''DDMMYYYY'')
					and prt_pcmp.usage_type_id <> 0
					and	prt_pcmp.prt_cmpt_id = '|| i_cmpt_id ||'
					and	crd.id = '|| i_crddet_id;
					
					EXECUTE IMMEDIATE quary_str INTO r_cm_id;
					RETURN r_cm_id;
				EXCEPTION WHEN NO_DATA_FOUND THEN
					BEGIN
						quary_str := ' select '|| i_tab_nm ||'.prt_cm_id 
							from '|| i_tab_nm || ', 
							prt_pcm, 
							prt_pcmp,   
							prt_person,
							prt_cmpt,
							prt_prt,
							prt_cmt,
							custdet c,
							inst i,
							crddet crd
						where	c.inst_id = i.id
						and	crd.custdet_id = c.id
						and	prt_person.custdet_id = c.id
						and prt_pcm.prt_prt_id = prt_prt.id
						and prt_pcm.prt_party_id = prt_person.prt_party_id
						and prt_pcmp.prt_cm_id = prt_pcm.prt_cm_id
						and prt_pcmp.prt_cmt_id = prt_pcm.prt_cmt_id
						and prt_pcmp.prt_prt_id = prt_pcm.prt_prt_id
						and prt_pcmp.prt_party_id = prt_pcm.prt_party_id
						and prt_pcmp.prt_pcm_from_date = prt_pcm.from_date
						and prt_pcmp.prt_cmpt_id = prt_cmpt.id
						and prt_cmt.id = '|| i_tab_nm ||'.prt_cmt_id
						and prt_pcm.prt_cm_id = '|| i_tab_nm ||'.prt_cm_id
						and prt_pcmp.from_date <= (select trunc(sysdate) from dual) 
						and prt_pcmp.until_date >= (select trunc(sysdate) from dual) 
						and prt_pcm.from_date <= (select trunc(sysdate) from dual) 
						and prt_pcm.until_date >= (select trunc(sysdate) from dual)
						and prt_pcmp.usage_type_id <> 0
						and	prt_pcmp.prt_cmpt_id = '|| v_cmpt_dft_id ||'
						and	crd.id = '|| i_crddet_id;
						
						EXECUTE IMMEDIATE quary_str INTO r_cm_id;
						RETURN r_cm_id;
					EXCEPTION WHEN OTHERS THEN
						RETURN 0;
					END;
				WHEN OTHERS THEN
					RETURN 0;
				END;
			WHEN OTHERS THEN
				RETURN 0;
			END;
		WHEN OTHERS THEN
			RETURN 0;
		END;
	ELSE 
		IF i_custdet_id IS NOT NULL AND i_custdet_id != 0 THEN
			BEGIN
				quary_str := ' select '|| i_tab_nm ||'.prt_cm_id 
					from '|| i_tab_nm || ', 
					prt_pcm, 
					prt_pcmp,   
					prt_person,
					prt_cmpt,
					prt_prt,
					prt_cmt,
					custdet c,
					inst i
				where	c.inst_id = i.id
				and	prt_person.custdet_id = c.id
				and prt_pcm.prt_prt_id = prt_prt.id
				and prt_pcm.prt_party_id = prt_person.prt_party_id
				and prt_pcmp.prt_cm_id = prt_pcm.prt_cm_id
				and prt_pcmp.prt_cmt_id = prt_pcm.prt_cmt_id
				and prt_pcmp.prt_prt_id = prt_pcm.prt_prt_id
				and prt_pcmp.prt_party_id = prt_pcm.prt_party_id
				and prt_pcmp.prt_pcm_from_date = prt_pcm.from_date
				and prt_pcmp.prt_cmpt_id = prt_cmpt.id
				and prt_cmt.id = '|| i_tab_nm ||'.prt_cmt_id
				and prt_pcm.prt_cm_id = '|| i_tab_nm ||'.prt_cm_id
				and prt_pcmp.from_date <= (select trunc(sysdate) from dual) 
				and prt_pcmp.until_date >= (select trunc(sysdate) from dual) 
				and prt_pcm.from_date <= (select trunc(sysdate) from dual) 
				and prt_pcm.until_date >= (select trunc(sysdate) from dual)
				and prt_pcmp.from_date = (select max(from_date) from prt_pcmp t
										where prt_pcmp.prt_cmpt_id = t.prt_cmpt_id
										and prt_pcmp.prt_party_id = t.prt_party_id
										and prt_pcmp.prt_cm_id = t.prt_cm_id
										and prt_pcmp.prt_cmt_id = t.prt_cmt_id
										and prt_pcmp.prt_prt_id = t.prt_prt_id
										group by t.prt_party_id, t.prt_cmpt_id)
				and prt_pcmp.usage_type_id <> 0
				and	prt_pcmp.prt_cmpt_id = '|| i_cmpt_id ||'
				and	c.id = '|| i_custdet_id;
				
				EXECUTE IMMEDIATE quary_str INTO r_cm_id;
				RETURN r_cm_id;
			EXCEPTION WHEN NO_DATA_FOUND THEN
				BEGIN
					quary_str := ' select '|| i_tab_nm ||'.prt_cm_id 
						from '|| i_tab_nm || ', 
						prt_pcm, 
						prt_pcmp,   
						prt_person,
						prt_cmpt,
						prt_prt,
						prt_cmt,
						custdet c,
						inst i
					where	c.inst_id = i.id
					and	prt_person.custdet_id = c.id
					and prt_pcm.prt_prt_id = prt_prt.id
					and prt_pcm.prt_party_id = prt_person.prt_party_id
					and prt_pcmp.prt_cm_id = prt_pcm.prt_cm_id
					and prt_pcmp.prt_cmt_id = prt_pcm.prt_cmt_id
					and prt_pcmp.prt_prt_id = prt_pcm.prt_prt_id
					and prt_pcmp.prt_party_id = prt_pcm.prt_party_id
					and prt_pcmp.prt_pcm_from_date = prt_pcm.from_date
					and prt_pcmp.prt_cmpt_id = prt_cmpt.id
					and prt_cmt.id = '|| i_tab_nm ||'.prt_cmt_id
					and prt_pcm.prt_cm_id = '|| i_tab_nm ||'.prt_cm_id
					and prt_pcmp.from_date <= (select trunc(sysdate) from dual) 
					and prt_pcmp.until_date >= (select trunc(sysdate) from dual) 
					and prt_pcm.from_date <= (select trunc(sysdate) from dual) 
					and prt_pcm.until_date >= (select trunc(sysdate) from dual)
					and prt_pcmp.usage_type_id <> 0
					and	prt_pcmp.prt_cmpt_id = '|| v_cmpt_dft_id ||'
					and	c.id = '|| i_custdet_id;
					
					EXECUTE IMMEDIATE quary_str INTO r_cm_id;
					RETURN r_cm_id;
				EXCEPTION WHEN OTHERS THEN
					RETURN 0;
				END;
			WHEN OTHERS THEN
				RETURN 0;
			END;
		END IF;
	END IF;
EXCEPTION WHEN OTHERS THEN
  RETURN 0;
END;
/
