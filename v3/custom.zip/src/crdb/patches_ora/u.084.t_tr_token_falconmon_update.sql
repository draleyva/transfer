--
-- TOKEN_FALCONMON_UPDATE  (Trigger) 
--
CREATE OR REPLACE TRIGGER TOKEN_FALCONMON_UPDATE AFTER UPDATE ON TOKEN
REFERENCING OLD old_token NEW new_token
FOR EACH ROW
BEGIN
	IF (:old_token.crddet_id <> :new_token.crddet_id
		or :old_token.vpan <> :new_token.vpan) THEN
			pis12_addlog('TOKEN', :new_token.id, 'U', ind3=>'1');
	END IF;
	
	IF (:old_token.tknstatustimestamp <> :new_token.tknstatustimestamp
		or :old_token.tknexpirydate <> :new_token.tknexpirydate
		or :old_token.tknstatus <> :new_token.tknstatus
		or :old_token.tknasslevel <> :new_token.tknasslevel) THEN
			nmon_addlog('TOKEN', :new_token.id, 'U', '3401', 
					newvalue1=>TO_CHAR(:new_token.tknstatustimestamp, 'YYYYMMDDHH24MISSFF3'),
					oldvalue1=>TO_CHAR(:old_token.tknstatustimestamp, 'YYYYMMDDHH24MISSFF3'),
					newvalue2=>TO_CHAR(:new_token.tknexpirydate, 'YYYYMMDD'),
					oldvalue2=>TO_CHAR(:old_token.tknexpirydate, 'YYYYMMDD'),
					newvalue3=>:new_token.tknstatus,
					oldvalue3=>:old_token.tknstatus,
					newvalue4=>:new_token.tknasslevel,
					oldvalue4=>:old_token.tknasslevel
			);
	END IF;
END;
/

