CREATE OR REPLACE TRIGGER crddelivinfo_change BEFORE UPDATE
ON
	crddelivinfo
REFERENCING OLD old_crddelivinfo NEW new_crddelivinfo
FOR EACH ROW
BEGIN
	:new_crddelivinfo.verno_ctx := :old_crddelivinfo.verno_ctx + 1;
END;
/
