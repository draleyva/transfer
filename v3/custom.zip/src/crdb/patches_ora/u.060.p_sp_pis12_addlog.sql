-- Procedure create PIS12_LOG record
-- Used by <FALCONMON> insert/update triggers

CREATE OR REPLACE procedure pis12_addlog(
        table_name    PIS12_LOG.tablename%type,
        key    PIS12_LOG.keydata%type,
        hint    PIS12_LOG.hint%type,
        ind    PIS12_LOG.indicator1%type default ' ',
        ind2    PIS12_LOG.indicator2%type default '0',
        ind3    PIS12_LOG.indicator3%type default '0'
) is xpis12_log    PIS12_LOG%rowtype;
begin
	xpis12_log.id := 0;
	xpis12_log.tablename := table_name;
	xpis12_log.keydata := key;
	xpis12_log.hint := hint;
	xpis12_log.indicator1 := ind;
	xpis12_log.indicator2 := ind2;
	xpis12_log.indicator3 := ind3;
	xpis12_log.tstamp := SUBSTR(TO_CHAR(systimestamp, 'YYYYMMDDHHMISSFF'), 1, 20);

	INSERT INTO PIS12_LOG VALUES xpis12_log;
end;
/
