--
-- FPADREC_CHANGE  (Trigger) 
--
CREATE OR REPLACE TRIGGER "FPADREC_CHANGE" BEFORE UPDATE
ON
	FPADREC
REFERENCING OLD old_fpadrec NEW new_fpadrec
FOR EACH ROW
BEGIN
	:new_fpadrec.verno_ctx := :old_fpadrec.verno_ctx + 1;
END;
/

