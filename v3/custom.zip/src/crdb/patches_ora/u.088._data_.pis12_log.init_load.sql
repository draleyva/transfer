DECLARE
   ind PIS12_LOG.indicator1%type;
BEGIN
   FOR card IN (SELECT CD.id, CD.statcode 
                FROM CRDDET CD LEFT JOIN PIS12_LOG PL on CD.id=PL.keydata
                -- add to log only non expired cards
                WHERE CD.statcode not in ('02') and CD.expdate >= sysdate and PL.id is null) LOOP
       IF (card.statcode = '00') THEN
        ind := 'pan_act';
       ELSE
        ind := ' ';
       END IF;
       pis12_addlog('CRDDET', card.id, 'I', ind, '1', '1');
   END LOOP;
   COMMIT;
END;
/
