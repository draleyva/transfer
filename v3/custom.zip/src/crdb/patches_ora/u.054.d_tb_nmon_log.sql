-- Schema for table: NMON_LOG

CREATE TABLE NMON_LOG
(
	id		number(20,0)	not null,
	tstamp		varchar2(20)	not null,
	tablename	varchar2(32)	not null,
	keydata		varchar2(64)	not null,
	hint		char(1)		not null,
	nmoncode	varchar2(4)	not null,
	newvalue1	varchar2(64)	not null,
	oldvalue1	varchar2(64)	not null,
	newvalue2	varchar2(64)	not null,
	oldvalue2	varchar2(64)	not null,
	newvalue3	varchar2(64)	not null,
	oldvalue3	varchar2(64)	not null,
	newvalue4	varchar2(64)	not null,
	oldvalue4	varchar2(64)	not null,
	newvalue5	varchar2(64)	not null,
	oldvalue5	varchar2(64)	not null,
	newvalue6	varchar2(64)	not null,
	oldvalue6	varchar2(64)	not null,
	newvalue7	varchar2(64)	not null,
	oldvalue7	varchar2(64)	not null
);

CREATE SEQUENCE NMON_LOG_SEQUENCE start with 1;

