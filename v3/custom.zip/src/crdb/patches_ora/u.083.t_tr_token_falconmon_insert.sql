--
-- TOKEN_FALCONMON_INSERT  (Trigger) 
--
CREATE OR REPLACE TRIGGER TOKEN_FALCONMON_INSERT AFTER INSERT ON TOKEN 
REFERENCING NEW AS new_token
FOR EACH ROW
BEGIN
    pis12_addlog('TOKEN', :new_token.id, 'I', ind3=>'1');
    nmon_addlog('TOKEN', :new_token.id, 'I', '3400', 
    		newvalue1=>TO_CHAR(:new_token.whencreated, 'YYYYMMDDHH24MISSFF3'),
    		newvalue2=>TO_CHAR(:new_token.tknexpirydate, 'YYYYMMDD'),
    		newvalue3=>:new_token.tknrequestorid,
    		newvalue4=>:new_token.tknstatus,
    		newvalue5=>:new_token.schemeid,
    		newvalue6=>:new_token.tknasslevel,
    		newvalue7=>:new_token.tkntype
    );
END;
/

