--
-- CRDFORMAT_FALCONMON_UPDATE  (Trigger) 
--
CREATE OR REPLACE TRIGGER CRDFORMAT_FALCONMON_UPDATE AFTER UPDATE ON CRDFORMAT
REFERENCING OLD old_CRDFORMAT NEW new_CRDFORMAT
FOR EACH ROW
DECLARE
    ind2       PIS12_LOG.indicator2%type := '0';
    ind3       PIS12_LOG.indicator3%type := '0';
BEGIN
	IF (:old_crdformat.scheme <> :new_crdformat.scheme) THEN
		ind2 := '1';
	END IF;
	
	IF (:old_crdformat.localcountry <> :new_crdformat.localcountry) THEN
		ind2 := '1';
		ind3 := '1';
	END IF;
	
	IF (ind2 = '1' or ind3 = '1') THEN
		pis12_addlog('CRDFORMAT', :new_crdformat.id, 'U', ind2=>ind2, ind3=>ind3);
	END IF;
END;
/

