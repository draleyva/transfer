-- Procedure create NMON_LOG record
-- Used by <FALCONMON> insert/update triggers

CREATE OR REPLACE procedure nmon_addlog(
        table_name	NMON_LOG.tablename%type,
        key		NMON_LOG.keydata%type,
        hint		NMON_LOG.hint%type,
        code		NMON_LOG.nmoncode%type,
        
        newvalue1    NMON_LOG.newvalue1%type default ' ',
        oldvalue1    NMON_LOG.oldvalue1%type default ' ',
        newvalue2    NMON_LOG.newvalue1%type default ' ',
        oldvalue2    NMON_LOG.oldvalue1%type default ' ',
        newvalue3    NMON_LOG.newvalue1%type default ' ',
        oldvalue3    NMON_LOG.oldvalue1%type default ' ',
        newvalue4    NMON_LOG.newvalue1%type default ' ',
        oldvalue4    NMON_LOG.oldvalue1%type default ' ',
        newvalue5    NMON_LOG.newvalue1%type default ' ',
        oldvalue5    NMON_LOG.oldvalue1%type default ' ',
        newvalue6    NMON_LOG.newvalue1%type default ' ',
        oldvalue6    NMON_LOG.oldvalue1%type default ' ',
        newvalue7    NMON_LOG.newvalue1%type default ' ',
        oldvalue7    NMON_LOG.oldvalue1%type default ' '
) is xnmon_log    NMON_LOG%rowtype;
begin
	xnmon_log.id := 0;
	xnmon_log.tablename := table_name;
	xnmon_log.keydata := key;
	xnmon_log.hint := hint;
	xnmon_log.nmoncode := code;
	
	xnmon_log.newvalue1 := newvalue1;
	xnmon_log.oldvalue1 := oldvalue1;
	xnmon_log.newvalue2 := newvalue2;
	xnmon_log.oldvalue2 := oldvalue2;
	xnmon_log.newvalue3 := newvalue3;
	xnmon_log.oldvalue3 := oldvalue3;
	xnmon_log.newvalue4 := newvalue4;
	xnmon_log.oldvalue4 := oldvalue4;
	xnmon_log.newvalue5 := newvalue5;
	xnmon_log.oldvalue5 := oldvalue5;
	xnmon_log.newvalue6 := newvalue6;
	xnmon_log.oldvalue6 := oldvalue6;
	xnmon_log.newvalue7 := newvalue7;
	xnmon_log.oldvalue7 := oldvalue7;
	
	xnmon_log.tstamp := SUBSTR(TO_CHAR(systimestamp, 'YYYYMMDDHHMISSFF'), 1, 20);

	INSERT INTO NMON_LOG VALUES xnmon_log;
end;
/
