--
-- CUSTDET_FALCONMON_UPDATE  (Trigger) 
--
CREATE OR REPLACE TRIGGER CUSTDET_FALCONMON_UPDATE AFTER UPDATE ON CUSTDET
REFERENCING OLD old_custdet NEW new_custdet
FOR EACH ROW
BEGIN
	IF (:old_custdet.home_city <> :new_custdet.home_city
		or :old_custdet.postcode <> :new_custdet.postcode
		or :old_custdet.home_county <> :new_custdet.home_county
		or :old_custdet.custcode <> :new_custdet.custcode) THEN
			pis12_addlog('CUSTDET', :new_custdet.id, 'U', ind2=>'1', ind3=>'1');
	END IF;
	
	IF (:old_custdet.home_city <> :new_custdet.home_city
		or :old_custdet.postcode <> :new_custdet.postcode
		or :old_custdet.home_county <> :new_custdet.home_county) THEN
			nmon_addlog('CUSTDET', :new_custdet.id, 'U', '3100', 
					newvalue1=>:new_custdet.home_city,
					oldvalue1=>:old_custdet.home_city,
					newvalue2=>:new_custdet.postcode,
					oldvalue2=>:old_custdet.postcode,
					newvalue3=>:new_custdet.home_county,
					oldvalue3=>:old_custdet.home_county
			);
	END IF;
END;
/

