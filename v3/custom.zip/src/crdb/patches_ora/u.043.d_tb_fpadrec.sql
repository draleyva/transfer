-- Schema for table: FPADREC

CREATE TABLE FPADREC
(
	verno_ctx		number(10,0)	default 1	not null,
	id			number(20,0)	not null,
	crddet_id		number(10,0)	not null,
	datecreated		date			not null,
	timecreated		number(10,0)    not null,
	dateupdated		date			not null,
	timeupdated		number(10,0)    not null,
	actioncode		char(1)			not null,
	rspcode			char(2)			not null,
	crdacptbus		number(5,0)		not null,
	crdacptloc_postcode		varchar2(10)	not null,
	decision_code_1		varchar2(32)	not null,
	decision_code_2		varchar2(32)	not null,
	decision_code_3		varchar2(32)	not null,
	decision_code_4		varchar2(32)	not null,
	decision_code_5		varchar2(32)	not null,
	decision_code_6		varchar2(32)	not null,
	decision_code_7		varchar2(32)	not null,
	decision_code_8		varchar2(32)	not null,
	decision_code_9		varchar2(32)	not null,
	decision_code_10	varchar2(32)	not null
);

CREATE SEQUENCE FPADREC_SEQUENCE start with 1;

