--
-- FPADREC_INSERT  (Trigger) 
--
CREATE OR REPLACE TRIGGER FPADREC_INSERT before insert ON FPADREC 
referencing new as new_fpadrec
for each row
begin
    if (:new_fpadrec.id is null or :new_fpadrec.id = 0) then
        select fpadrec_sequence.nextval into :new_fpadrec.id from dual;
    end if;
end;
/

