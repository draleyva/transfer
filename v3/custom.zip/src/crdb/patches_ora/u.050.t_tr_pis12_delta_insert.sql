--
-- PIS12_DELTA_INSERT  (Trigger) 
--
CREATE OR REPLACE TRIGGER PIS12_DELTA_INSERT before insert ON PIS12_DELTA 
referencing new as new_pis12_delta
for each row
begin
    if (:new_pis12_delta.id is null or :new_pis12_delta.id = 0) then
        select pis12_delta_sequence.nextval into :new_pis12_delta.id from dual;
    end if;
end;
/

