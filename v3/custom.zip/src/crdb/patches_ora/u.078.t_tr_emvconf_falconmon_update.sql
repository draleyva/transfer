--
-- EMVCONF_FALCONMON_UPDATE  (Trigger) 
--
CREATE OR REPLACE TRIGGER EMVCONF_FALCONMON_UPDATE AFTER UPDATE ON EMVCONF
REFERENCING OLD old_emvconf NEW new_emvconf
FOR EACH ROW
BEGIN
	IF (:old_emvconf.emvoda <> :new_emvconf.emvoda) THEN
		pis12_addlog('EMVCONF', :new_emvconf.id, 'U', ind2=>'1');
	END IF;
END;
/

