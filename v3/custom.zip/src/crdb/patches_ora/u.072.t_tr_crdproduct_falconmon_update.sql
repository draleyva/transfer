--
-- CRDPRODUCT_FALCONMON_UPDATE  (Trigger) 
--
CREATE OR REPLACE TRIGGER CRDPRODUCT_FALCONMON_UPDATE AFTER UPDATE ON CRDPRODUCT
REFERENCING OLD old_crdproduct NEW new_crdproduct
FOR EACH ROW
DECLARE
    ind2       PIS12_LOG.indicator2%type := '0';
    ind3       PIS12_LOG.indicator3%type := '0';
BEGIN
	IF (:old_crdproduct.features <> :new_crdproduct.features) THEN
		ind2 := '1';
	END IF;
	
	IF (:old_crdproduct.affinity <> :new_crdproduct.affinity) THEN
		ind2 := '1';
		ind3 := '1';
	END IF;
	
	IF (ind2 = '1' or ind3 = '1') THEN
		pis12_addlog('CRDPRODUCT', :new_crdproduct.id, 'U', ind2=>ind2, ind3=>ind3);
	END IF;
END;
/

