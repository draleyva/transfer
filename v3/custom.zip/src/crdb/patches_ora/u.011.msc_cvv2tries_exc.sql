INSERT INTO DESCR (verno_ctx, descrtag, descr, lang)
	VALUES (1, (select max(descrtag)+1 from descr), 'CVV2 validation tries exceeded', 'EN');

INSERT INTO DESCR (verno_ctx, descrtag, descr, lang)
	VALUES (1, (select max(descrtag) from descr), 'CVV2 validation tries exceeded', 'GB');

INSERT INTO MSC (verno_ctx, tag, idx, mscmodule, descr, mask, string_t, long_t, short_t, double_t, date_t)  
	VALUES (1, 'cvv2tries_exc', 1, 'ia', (select max(descrtag) from descr), 1, '02', 0, 0, 0.00, to_date('2263-08-31','YYYY-MM-DD'));
