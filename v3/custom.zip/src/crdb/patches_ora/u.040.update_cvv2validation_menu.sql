UPDATE acsitem SET command = 'iacvv2validationon.do' WHERE acsitem = 'ia_cvv2val';
