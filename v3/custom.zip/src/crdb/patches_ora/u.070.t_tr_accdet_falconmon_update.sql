--
-- ACCDET_FALCONMON_UPDATE  (Trigger) 
--
CREATE OR REPLACE TRIGGER ACCDET_FALCONMON_UPDATE AFTER UPDATE ON ACCDET
REFERENCING OLD old_accdet NEW new_accdet
FOR EACH ROW
BEGIN
	IF (:old_accdet.accno <> :new_accdet.accno
		or :old_accdet.currcode <> :new_accdet.currcode
		or :old_accdet.credit_limit <> :new_accdet.credit_limit) THEN
			pis12_addlog('ACCDET', :new_accdet.id, 'U', ind2=>'1', ind3=>'1');
	END IF;
END;
/

