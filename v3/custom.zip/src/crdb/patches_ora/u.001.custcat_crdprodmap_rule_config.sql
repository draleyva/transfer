DECLARE 
	inst_bpd_id inst.id%TYPE;
	context_custcat_id rule_context.id%TYPE;
	context_crdprodmap_id rule_context.id%TYPE;
	dim_custcat_id rule_dimension.id%TYPE;
	dim_crdprodmap_id rule_dimension.id%TYPE;
	dimval_custcat_id rule_dimvalue.id%TYPE;
	dimval_crdprodmap_id rule_dimvalue.id%TYPE;
	eval_id rule_evalset.id%TYPE;
	rule_id rule_rule.id%TYPE;
	ifExists number(5,0);

BEGIN
	inst_bpd_id := 0;
	context_custcat_id := 0;
	context_crdprodmap_id := 0;
	dim_custcat_id := 0;
	dim_crdprodmap_id := 0;
	dimval_custcat_id := 0;
	dimval_crdprodmap_id := 0;
	eval_id := 0;
	rule_id := 0;
	ifExists := 0;
	
	-- Add CUSTCAT and CRDPRODMAP to rule_context
	SELECT count(id) INTO ifExists FROM rule_context WHERE contextcode = 'CUSTCAT';
	if ifExists = 0 then
		INSERT INTO rule_context(contextcode, tuxedo_event, event_pending, descr, conf_ind)
		VALUES ('CUSTCAT','CTX.CUSTCAT',1,'Customer Categorisation Context', 1);
	end if;
	
	SELECT count(id) INTO ifExists FROM rule_context WHERE contextcode = 'CRDPRODMAP';
	if ifExists = 0 then
		INSERT INTO rule_context(contextcode, tuxedo_event, event_pending, descr, conf_ind)
		VALUES ('CRDPRODMAP','CTX.CRDPRODMAP',1,'Card Product Mappint Context', 1);
	end if;

	COMMIT;
	
	-- Get the ids from rule_context for CUSTCAT and CRDPRODMAP
	SELECT id INTO context_custcat_id FROM rule_context WHERE contextcode = 'CUSTCAT';
	SELECT id INTO context_crdprodmap_id FROM rule_context WHERE contextcode = 'CRDPRODMAP';
	
	-- Add new dimensions to rule_dimension for CUSTCAT and CRDPRODMAP
	SELECT count(id) INTO ifExists FROM rule_dimension WHERE context_id = context_custcat_id AND dimlvl = 1;
	if ifExists = 0 then
		INSERT INTO rule_dimension (dimlvl, context_id, scopedet_id, descr, dimvalue_linktype)
		VALUES (1, context_custcat_id, 1,'Dimension values (Customer Income Category)', 0);
	end if;
	
	SELECT count(id) INTO ifExists FROM rule_dimension WHERE context_id = context_crdprodmap_id AND dimlvl = 1;
	if ifExists = 0 then
	INSERT INTO rule_dimension (dimlvl, context_id, scopedet_id, descr, dimvalue_linktype)
	VALUES (1, context_crdprodmap_id, 1,'Dimension values (Card Product Mapping)', 0);
	end if;
	
	COMMIT;
	
	-- Get the ids from rule_dimension for CUSTCAT and CRDPRODMAP
	SELECT id INTO dim_custcat_id FROM rule_dimension WHERE context_id = context_custcat_id AND dimlvl = 1;
	SELECT id INTO dim_crdprodmap_id FROM rule_dimension WHERE context_id = context_crdprodmap_id AND dimlvl = 1;

	-- Add new atoms to rule_atom for CUSTCAT
	SELECT count(id) INTO ifExists FROM rule_atom WHERE atomcode = 'custCatClassic';
	if ifExists = 0 then
		INSERT INTO rule_atom (atomcode, atom, descr)
		VALUES ('custCatClassic', 'I_DOUBLE_VALUE >= 0 ' || '&' || '&' || ' I_DOUBLE_VALUE <= 30000', 'Classic Customer Category');
	end if;
	SELECT count(id) INTO ifExists FROM rule_atom WHERE atomcode = 'custCatGold';
	if ifExists = 0 then
		INSERT INTO rule_atom (atomcode, atom, descr)
		VALUES ('custCatGold', 'I_DOUBLE_VALUE > 30000 ' || '&' || '&' || ' I_DOUBLE_VALUE <= 500000', 'Gold Customer Category');
	end if;
	SELECT count(id) INTO ifExists FROM rule_atom WHERE atomcode = 'custCatPlatinum';
	if ifExists = 0 then
		INSERT INTO rule_atom (atomcode, atom, descr)
		VALUES ('custCatPlatinum', 'I_DOUBLE_VALUE > 500000 ' || '&' || '&' || ' I_DOUBLE_VALUE <= 1000000', 'Platinum Customer Category');
	end if;

	COMMIT;
	
	-- Add new atoms to rule_atom for CRDPRODMAP
	SELECT count(id) INTO ifExists FROM rule_atom WHERE atomcode = 'custCpdMClassic';
	if ifExists = 0 then
		INSERT INTO rule_atom (atomcode, atom, descr)
		VALUES ('custCpdMClassic', 'I_CUSTCATPARAMS == ''S0''', 'Classic Customer Card Product Mapping');
	end if;
	SELECT count(id) INTO ifExists FROM rule_atom WHERE atomcode = 'custCpdMGold';
	if ifExists = 0 then
		INSERT INTO rule_atom (atomcode, atom, descr)
		VALUES ('custCpdMGold', 'I_CUSTCATPARAMS == ''S1''', 'Gold Customer Card Product Mapping');
	end if;
	SELECT count(id) INTO ifExists FROM rule_atom WHERE atomcode = 'custCpdMPlatinum';
	if ifExists = 0 then
		INSERT INTO rule_atom (atomcode, atom, descr)
		VALUES ('custCpdMPlatinum', 'I_CUSTCATPARAMS == ''S2''', 'Platinum Customer Card Product Mapping');
	end if;

	COMMIT;
	
	-- Get the id from inst for instcode 'BPD'
	SELECT inst.id INTO inst_bpd_id FROM inst WHERE UPPER(instcode) = 'BPD';

	-- Add new dimension VALUES to rule_dimvalue for CUSTCAT and CRDPRODMAP
	SELECT count(id) INTO ifExists FROM rule_dimvalue WHERE dimension_id = dim_custcat_id AND inst_id = inst_bpd_id AND dimvalue = 1;
	if ifExists = 0 then
		INSERT INTO rule_dimvalue (dimension_id, inst_id, dimvalue, descr)
		VALUES (dim_custcat_id, inst_bpd_id, 1, 'Customer Income Category');
	end if;
	SELECT count(id) INTO ifExists FROM rule_dimvalue WHERE dimension_id = dim_crdprodmap_id AND inst_id = inst_bpd_id AND dimvalue = 1;
	if ifExists = 0 then
		INSERT INTO rule_dimvalue (dimension_id, inst_id, dimvalue, descr)
		VALUES (dim_crdprodmap_id, inst_bpd_id, 1, 'Card Product Mapping');
	end if;

	COMMIT;
	
	-- Get the ids from rule_dimvalue for CUSTCAT and CRDPRODMAP
	SELECT id INTO dimval_custcat_id FROM rule_dimvalue WHERE dimension_id = dim_custcat_id AND inst_id = inst_bpd_id AND dimvalue = 1;
	SELECT id INTO dimval_crdprodmap_id FROM rule_dimvalue WHERE dimension_id = dim_crdprodmap_id AND inst_id = inst_bpd_id AND dimvalue = 1;

	-- Add new evaluation sets to rule_evalset for CUSTCAT
	SELECT count(id) INTO ifExists FROM rule_evalset WHERE inst_id = inst_bpd_id AND evalcode = 'CAT_CLASSIC';
	if ifExists = 0 then
		INSERT INTO rule_evalset (inst_id, evalcode, descr, ret_data0, ret_data1, ret_data2, ret_data3, ret_data4, ret_data5, ret_data6, ret_data7)
		VALUES (inst_bpd_id, 'CAT_CLASSIC', 'Customer Category', 'S0', ' ', ' ', ' ', ' ', ' ', ' ', ' ');
	end if;
	SELECT count(id) INTO ifExists FROM rule_evalset WHERE inst_id = inst_bpd_id AND evalcode = 'CAT_GOLD';
	if ifExists = 0 then
		INSERT INTO rule_evalset (inst_id, evalcode, descr, ret_data0, ret_data1, ret_data2, ret_data3, ret_data4, ret_data5, ret_data6, ret_data7)
		VALUES (inst_bpd_id, 'CAT_GOLD', 'Customer Category', 'S1', ' ', ' ', ' ', ' ', ' ', ' ', ' ');
	end if;
	SELECT count(id) INTO ifExists FROM rule_evalset WHERE inst_id = inst_bpd_id AND evalcode = 'CAT_PLATIMUN';
	if ifExists = 0 then
		INSERT INTO rule_evalset (inst_id, evalcode, descr, ret_data0, ret_data1, ret_data2, ret_data3, ret_data4, ret_data5, ret_data6, ret_data7)
		VALUES (inst_bpd_id, 'CAT_PLATIMUN', 'Customer Category', 'S2', ' ', ' ', ' ', ' ', ' ', ' ', ' ');
	end if;

	COMMIT;
	
	-- Add new evaluation sets to rule_evalset for CRDPRODMAP
	SELECT count(id) INTO ifExists FROM rule_evalset WHERE inst_id = inst_bpd_id AND evalcode = 'CRDP_CLASSIC';
	if ifExists = 0 then
		INSERT INTO rule_evalset (inst_id, evalcode, descr, ret_data0, ret_data1, ret_data2, ret_data3, ret_data4, ret_data5, ret_data6, ret_data7)
		VALUES (inst_bpd_id, 'CRDP_CLASSIC', 'Card Product Mapping', 'VICI', ' ', ' ', ' ', ' ', ' ', ' ', ' ');
	end if;
	SELECT count(id) INTO ifExists FROM rule_evalset WHERE inst_id = inst_bpd_id AND evalcode = 'CRDP_GOLD';
	if ifExists = 0 then
		INSERT INTO rule_evalset (inst_id, evalcode, descr, ret_data0, ret_data1, ret_data2, ret_data3, ret_data4, ret_data5, ret_data6, ret_data7)
		VALUES (inst_bpd_id, 'CRDP_GOLD', 'Card Product Mapping', 'VIGI', ' ', ' ', ' ', ' ', ' ', ' ', ' ');
	end if;
	SELECT count(id) INTO ifExists FROM rule_evalset WHERE inst_id = inst_bpd_id AND evalcode = 'CRDP_PLATIMUN';
	if ifExists = 0 then
		INSERT INTO rule_evalset (inst_id, evalcode, descr, ret_data0, ret_data1, ret_data2, ret_data3, ret_data4, ret_data5, ret_data6, ret_data7)
		VALUES (inst_bpd_id, 'CRDP_PLATIMUN', 'Card Product Mapping', 'VIPI', ' ', ' ', ' ', ' ', ' ', ' ', ' ');
	end if;

	COMMIT;
	
	-- Add new rules to rule_rule for CUSTCAT
	SELECT count(id) INTO ifExists FROM rule_rule WHERE context_id = context_custcat_id AND inst_id = inst_bpd_id AND rulename = 'custCatClassic';
	if ifExists = 0 then
		INSERT INTO rule_rule (context_id, inst_id, rulename, ruleexpr, descr)
		VALUES (context_custcat_id, inst_bpd_id, 'custCatClassic', 'custCatClassic', 'Classic customer Category');
	end if;
	SELECT count(id) INTO ifExists FROM rule_rule WHERE context_id = context_custcat_id AND inst_id = inst_bpd_id AND rulename = 'custCatGold';
	if ifExists = 0 then
		INSERT INTO rule_rule (context_id, inst_id, rulename, ruleexpr, descr)
		VALUES (context_custcat_id, inst_bpd_id, 'custCatGold', 'custCatGold', 'Gold customer Category');
	end if;
	SELECT count(id) INTO ifExists FROM rule_rule WHERE context_id = context_custcat_id AND inst_id = inst_bpd_id AND rulename = 'custCatPlatinum';
	if ifExists = 0 then
		INSERT INTO rule_rule (context_id, inst_id, rulename, ruleexpr, descr)
		VALUES (context_custcat_id, inst_bpd_id, 'custCatPlatinum', 'custCatPlatinum', 'Platinum customer Category');
	end if;

	COMMIT;
	
	-- Add new rules to rule_rule for CRDPRODMAP
	SELECT count(id) INTO ifExists FROM rule_rule WHERE context_id = context_crdprodmap_id AND inst_id = inst_bpd_id AND rulename = 'custCpdMClassic';
	if ifExists = 0 then
		INSERT INTO rule_rule (context_id, inst_id, rulename, ruleexpr, descr)
		VALUES (context_crdprodmap_id, inst_bpd_id, 'custCpdMClassic', 'custCpdMClassic', 'Classic customer Card Product Mapping');
	end if;
	SELECT count(id) INTO ifExists FROM rule_rule WHERE context_id = context_crdprodmap_id AND inst_id = inst_bpd_id AND rulename = 'custCpdMGold';
	if ifExists = 0 then
		INSERT INTO rule_rule (context_id, inst_id, rulename, ruleexpr, descr)
		VALUES (context_crdprodmap_id, inst_bpd_id, 'custCpdMGold', 'custCpdMGold', 'Gold customer Card Product Mapping');
	end if;
	SELECT count(id) INTO ifExists FROM rule_rule WHERE context_id = context_crdprodmap_id AND inst_id = inst_bpd_id AND rulename = 'custCpdMPlatinum';
	if ifExists = 0 then
		INSERT INTO rule_rule (context_id, inst_id, rulename, ruleexpr, descr)
		VALUES (context_crdprodmap_id, inst_bpd_id, 'custCpdMPlatinum', 'custCpdMPlatinum', 'Platinum customer Card Product Mapping');
	end if;

	COMMIT;
	
	-- Add new evaluation sets and rules/dimension value link to rule_evalrulelink for CUSTCAT
	SELECT id INTO eval_id FROM rule_evalset WHERE inst_id = inst_bpd_id AND evalcode = 'CAT_CLASSIC';
	SELECT id INTO rule_id FROM rule_rule WHERE context_id = context_custcat_id AND inst_id = inst_bpd_id AND rulename = 'custCatClassic';
	SELECT count(id) INTO ifExists FROM rule_evalrulelink WHERE rule_id = rule_id AND evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_evalrulelink (rule_id, evalset_id)
		VALUES (rule_id, eval_id);
	end if;
	SELECT count(id) INTO ifExists FROM rule_evaldimlink WHERE dimvalue_id = dimval_custcat_id AND evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_evaldimlink (evalset_id, dimvalue_id)
		VALUES (eval_id, dimval_custcat_id);
	end if;
	SELECT count(id) INTO ifExists FROM rule_dimlvllink WHERE evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_dimlvllink (evalset_id, dimvalue_id)
		VALUES (eval_id, dimval_custcat_id);
	end if;
	
	COMMIT;
	
	SELECT id INTO eval_id FROM rule_evalset WHERE inst_id = inst_bpd_id AND evalcode = 'CAT_GOLD';
	SELECT id INTO rule_id FROM rule_rule WHERE context_id = context_custcat_id AND inst_id = inst_bpd_id AND rulename = 'custCatGold';
	SELECT count(id) INTO ifExists FROM rule_evalrulelink WHERE rule_id = rule_id AND evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_evalrulelink (rule_id, evalset_id)
		VALUES (rule_id, eval_id);
	end if;
	SELECT count(id) INTO ifExists FROM rule_evaldimlink WHERE dimvalue_id = dimval_custcat_id AND evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_evaldimlink (evalset_id, dimvalue_id)
		VALUES (eval_id, dimval_custcat_id);
	end if;
	SELECT count(id) INTO ifExists FROM rule_dimlvllink WHERE evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_dimlvllink (evalset_id, dimvalue_id)
		VALUES (eval_id, dimval_custcat_id);
	end if;
	
	COMMIT;
	
	SELECT id INTO eval_id FROM rule_evalset WHERE inst_id = inst_bpd_id AND evalcode = 'CAT_PLATIMUN';
	SELECT id INTO rule_id FROM rule_rule WHERE context_id = context_custcat_id AND inst_id = inst_bpd_id AND rulename = 'custCatPlatinum';
	SELECT count(id) INTO ifExists FROM rule_evalrulelink WHERE rule_id = rule_id AND evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_evalrulelink (rule_id, evalset_id)
		VALUES (rule_id, eval_id);
	end if;
	SELECT count(id) INTO ifExists FROM rule_evaldimlink WHERE dimvalue_id = dimval_custcat_id AND evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_evaldimlink (evalset_id, dimvalue_id)
		VALUES (eval_id, dimval_custcat_id);
	end if;
	SELECT count(id) INTO ifExists FROM rule_dimlvllink WHERE evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_dimlvllink (evalset_id, dimvalue_id)
		VALUES (eval_id, dimval_custcat_id);
	end if;

	COMMIT;
	
	-- Add new evaluation sets and rules/dimension value link to rule_evalrulelink for CRDPRODMAP
	SELECT id INTO eval_id FROM rule_evalset WHERE inst_id = inst_bpd_id AND evalcode = 'CRDP_CLASSIC';
	SELECT id INTO rule_id FROM rule_rule WHERE context_id = context_crdprodmap_id AND inst_id = inst_bpd_id AND rulename = 'custCpdMClassic';
	SELECT count(id) INTO ifExists FROM rule_evalrulelink WHERE rule_id = rule_id AND evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_evalrulelink (rule_id, evalset_id)
		VALUES (rule_id, eval_id);
	end if;
	SELECT count(id) INTO ifExists FROM rule_evaldimlink WHERE dimvalue_id = dimval_crdprodmap_id AND evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_evaldimlink (evalset_id, dimvalue_id)
		VALUES (eval_id, dimval_crdprodmap_id);
	end if;
	SELECT count(id) INTO ifExists FROM rule_dimlvllink WHERE evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_dimlvllink (evalset_id, dimvalue_id)
		VALUES (eval_id, dimval_crdprodmap_id);
	end if;
	
	COMMIT;
	
	SELECT id INTO eval_id FROM rule_evalset WHERE inst_id = inst_bpd_id AND evalcode = 'CRDP_GOLD';
	SELECT id INTO rule_id FROM rule_rule WHERE context_id = context_crdprodmap_id AND inst_id = inst_bpd_id AND rulename = 'custCpdMGold';
	SELECT count(id) INTO ifExists FROM rule_evalrulelink WHERE rule_id = rule_id AND evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_evalrulelink (rule_id, evalset_id)
		VALUES (rule_id, eval_id);
	end if;
	SELECT count(id) INTO ifExists FROM rule_evaldimlink WHERE dimvalue_id = dimval_crdprodmap_id AND evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_evaldimlink (evalset_id, dimvalue_id)
		VALUES (eval_id, dimval_crdprodmap_id);
	end if;
	SELECT count(id) INTO ifExists FROM rule_dimlvllink WHERE evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_dimlvllink (evalset_id, dimvalue_id)
		VALUES (eval_id, dimval_crdprodmap_id);
	end if;
	
	COMMIT;
	
	SELECT id INTO eval_id FROM rule_evalset WHERE inst_id = inst_bpd_id AND evalcode = 'CRDP_PLATIMUN';
	SELECT id INTO rule_id FROM rule_rule WHERE context_id = context_crdprodmap_id AND inst_id = inst_bpd_id AND rulename = 'custCpdMPlatinum';
	SELECT count(id) INTO ifExists FROM rule_evalrulelink WHERE rule_id = rule_id AND evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_evalrulelink (rule_id, evalset_id)
		VALUES (rule_id, eval_id);
	end if;
	SELECT count(id) INTO ifExists FROM rule_evaldimlink WHERE dimvalue_id = dimval_crdprodmap_id AND evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_evaldimlink (evalset_id, dimvalue_id)
		VALUES (eval_id, dimval_crdprodmap_id);
	end if;
	SELECT count(id) INTO ifExists FROM rule_dimlvllink WHERE evalset_id = eval_id;
	if ifExists = 0 then
		INSERT INTO rule_dimlvllink (evalset_id, dimvalue_id)
		VALUES (eval_id, dimval_crdprodmap_id);
	end if;

	COMMIT;
	
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE NO_DATA_FOUND;
  WHEN DUP_VAL_ON_INDEX THEN
    RAISE DUP_VAL_ON_INDEX;
  WHEN OTHERS THEN
	ROLLBACK;
	RAISE_APPLICATION_ERROR(-20001, 'Unexpected error occured : ORA-' || (CASE WHEN LENGTH(SUBSTR(SQLCODE,2,LENGTH(SQLCODE))) < 5 THEN
																			LPAD(SUBSTR(SQLCODE,2,LENGTH(SQLCODE)), 5, '0')  
																			ELSE SUBSTR(SQLCODE,2,LENGTH(SQLCODE)) 
																			END));

END;
/
