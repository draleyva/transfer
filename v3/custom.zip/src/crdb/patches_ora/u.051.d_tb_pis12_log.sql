-- Schema for table: PIS12_LOG

CREATE TABLE PIS12_LOG
(
	id		number(20,0)	not null,
	tstamp		varchar2(20)	not null,
	tablename	varchar2(32)	not null,
	keydata		varchar2(64)	not null,
	hint		char(1)		not null,
	indicator1	varchar2(32)	not null,
	indicator2	char(1)		not null,
	indicator3	char(1)		not null
);

CREATE SEQUENCE PIS12_LOG_SEQUENCE start with 1;

