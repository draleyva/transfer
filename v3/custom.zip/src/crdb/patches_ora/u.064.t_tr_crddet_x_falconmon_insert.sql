--
-- CRDDET_X_FALCONMON_INSERT  (Trigger) 
--
CREATE OR REPLACE TRIGGER CRDDET_X_FALCONMON_INSERT AFTER INSERT ON CRDDET_X 
REFERENCING NEW AS new_crddet_x
FOR EACH ROW
BEGIN
    pis12_addlog('CRDDET_X', :new_crddet_x.crddet_id, 'I', ind2=>'1', ind3=>'1');
END;
/

