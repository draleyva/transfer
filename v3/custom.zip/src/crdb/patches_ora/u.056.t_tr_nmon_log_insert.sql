--
-- NMON_LOG_INSERT  (Trigger) 
--
CREATE OR REPLACE TRIGGER NMON_LOG_INSERT before insert ON NMON_LOG 
referencing new as new_nmon_log
for each row
begin
    if (:new_nmon_log.id is null or :new_nmon_log.id = 0) then
        select nmon_log_sequence.nextval into :new_nmon_log.id from dual;
    end if;
end;
/

