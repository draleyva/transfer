create or replace procedure cvv2validation_menu(p_usrgrp usrgrp.usrgrp%type) is

t_maxtag	number(10,0);
t_menuorder	number(10,0);

begin

    select max(descrtag) into t_maxtag from descr;

    -- Issuer > CVV2 Validation
    t_menuorder := 0;
    select nvl(max(morder),0) into t_menuorder from menu where mitem = 'ia_' and usrgrp = p_usrgrp;
    t_menuorder := t_menuorder + 1;
    t_maxtag := t_maxtag + 1;
    insert into descr(descrtag,descr,lang) values(t_maxtag,'CVV2 Validation','EN');
    insert into acsitem(acsitem,acstype,shortname,command,helpform,descrtag) values('ia_cvv2val','J2EF',' ','CortexOnline-WEB-BPD/iacvv2validationon.do',' ',t_maxtag);
    insert into grpperm(acsitem,usrgrp,mask,extpswd,optag) values('ia_cvv2val',p_usrgrp,'Y','N',15);
    insert into menu(mitem,acsitem,descrtag,morder,usrgrp,acstype) values('ia_','ia_cvv2val',t_maxtag,t_menuorder,p_usrgrp,'J2EF');

end;
.
/

call cvv2validation_menu('cortex');

drop procedure cvv2validation_menu;
