--
-- CRDDET_FALCONMON_INSERT  (Trigger) 
--
CREATE OR REPLACE TRIGGER CRDDET_FALCONMON_INSERT AFTER INSERT ON CRDDET 
REFERENCING NEW AS new_crddet
FOR EACH ROW
DECLARE
    ind        PIS12_LOG.indicator1%type := ' ';
BEGIN
	IF (:new_crddet.statcode = '00') THEN
		ind := 'pan_act';
	END IF;
    pis12_addlog('CRDDET', :new_crddet.id, 'I', ind, '1', '1');
END;
/

