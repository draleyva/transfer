--
-- CRDDET_FALCONMON_UPDATE  (Trigger) 
--
CREATE OR REPLACE TRIGGER CRDDET_FALCONMON_UPDATE AFTER UPDATE ON CRDDET
REFERENCING OLD old_crddet NEW new_crddet
FOR EACH ROW
DECLARE
    ind        PIS12_LOG.indicator1%type := ' ';
    ind2       PIS12_LOG.indicator2%type := '0';
    ind3       PIS12_LOG.indicator3%type := '0';
BEGIN
	IF (:new_crddet.statcode <> :old_crddet.statcode and :new_crddet.statcode = '00') THEN
		ind := 'pan_act';
	END IF;
	
	IF (:new_crddet.classid <> :old_crddet.classid
		or :new_crddet.statcode <> :old_crddet.statcode) THEN
			ind2 := '1';
	END IF;
	
	IF (:new_crddet.date_created <> :old_crddet.date_created
		or :new_crddet.date_statchg <> :old_crddet.date_statchg
		or :new_crddet.firstname <> :old_crddet.firstname
		or :new_crddet.lastname <> :old_crddet.lastname    
		or :new_crddet.expdate <> :old_crddet.expdate
		or :new_crddet.effdate <> :old_crddet.effdate) THEN
			ind2 := '1';
			ind3 := '1';
	END IF;
	
	IF (ind2 = '1' or ind3 = '1') THEN
		pis12_addlog('CRDDET', :new_crddet.id, 'U', ind, ind2, ind3);
	END IF;
	
	IF (:old_crddet.statcode = '02' and (:new_crddet.statcode = '00' or :new_crddet.statcode = '26')) THEN
		nmon_addlog('CRDDET', :new_crddet.id, 'U', '3000', 
				newvalue1=>:new_crddet.custdet_id, 
				newvalue2=>:new_crddet.accdet_id,
				newvalue3=>:new_crddet.embossname,
				newvalue4=>TO_CHAR(:new_crddet.date_statchg, 'YYYYMMDD'),
				newvalue5=>TO_CHAR(:new_crddet.expdate, 'YYYYMMDD'),
				newvalue6=>:new_crddet.statcode,
				oldvalue6=>:old_crddet.statcode
		);
	END IF;
END;
/

