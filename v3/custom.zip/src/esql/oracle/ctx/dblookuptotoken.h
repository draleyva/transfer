/*------------------------------------------------------------------------*/
/**
 * @file	dblookuptotoken.h
 *
 * @brief	Lookup to TOKEN.id routines (header)
 *
 * @author	Ruslans Vasiljevs
 *
 * @date	19/07/2022
 *
 * $Id:
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

#ifndef __DBLOOKUPTOTOKEN_H
#define __DBLOOKUPTOTOKEN_H
/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
extern int dbcrddet_lookuptotoken_begin_scan(char *keydata, long start_from);
extern int dbcustdet_lookuptotoken_begin_scan(char *keydata, long start_from);
extern int dbaccdet_lookuptotoken_begin_scan(char *keydata, long start_from);
extern int dbcrdproduct_lookuptotoken_begin_scan(char *keydata, long start_from);
extern int dbcrdformat_lookuptotoken_begin_scan(char *keydata, long start_from);
extern int dbcrdbtch_lookuptotoken_begin_scan(char *keydata, long start_from);
extern int dbemvprofile_lookuptotoken_begin_scan(char *keydata, long start_from);
extern int dbemvconf_lookuptotoken_begin_scan(char *keydata, long start_from);
extern int dblookuptotoken_get_next(int cursor, long *p_token_id);
extern int dblookuptotoken_close_scan(int cursor);

#endif /* __DBLOOKUPTOTOKEN_H */
