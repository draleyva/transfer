/*------------------------------------------------------------------------*/
/**
 * @file	dbcdsthstrx.h
 *
 * @brief	CDSTHST access routines (header)
 *
 * @author	Ruslans Vasiljevs
 *
 * @date	12/08/2022
 *
 * $Id:
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

#ifndef __DBCDSTHSTRX_H
#define __DBCDSTHSTRX_H
/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
extern int dbcdsthst_whoset_getby_statcodes(long crddet_id, char* old_statcode, char* new_statcode, char* whoset);
extern int dbcdsthst_dateset_getby_before(long crddet_id, const long *p_before_dateset, long *p_dateset);

#endif /* __DBCDSTHSTRX_H */
