/*------------------------------------------------------------------------*/
/**
 * @file	dblookuptobpdtkndeviceprov.h
 *
 * @brief	Lookup to BPDTKNDEVICEPROV.id routines (header)
 *
 * @author	Raul Torres
 *
 * @date	19/09/2024
 *
 * $Id:
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

#ifndef __DBLOOKUPTOBPDTKNDEVICEPROV_H
#define __DBLOOKUPTOBPDTKNDEVICEPROV_H
/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
extern int dbcrddet_lookuptobpdtkndeviceprov_begin_scan(char *keydata, long start_from);
extern int dbcustdet_lookuptobpdtkndeviceprov_begin_scan(char *keydata, long start_from);
extern int dbaccdet_lookuptobpdtkndeviceprov_begin_scan(char *keydata, long start_from);
extern int dbcrdproduct_lookuptobpdtkndeviceprov_begin_scan(char *keydata, long start_from);
extern int dbcrdformat_lookuptobpdtkndeviceprov_begin_scan(char *keydata, long start_from);
extern int dbcrdbtch_lookuptobpdtkndeviceprov_begin_scan(char *keydata, long start_from);
extern int dbemvprofile_lookuptobpdtkndeviceprov_begin_scan(char *keydata, long start_from);
extern int dbemvconf_lookuptobpdtkndeviceprov_begin_scan(char *keydata, long start_from);
extern int dblookuptobpdtkndeviceprov_get_next(int cursor, long *p_bpdtkndeviceprov_id);
extern int dblookuptobpdtkndeviceprov_close_scan(int cursor);

#endif /* __DBLOOKUPTOBPDTKNDEVICEPROV_H */
