/*------------------------------------------------------------------------*/
/**
 * @file	dblookuptocrddet.h
 *
 * @brief	Lookup to CRDDET.id routines (header)
 *
 * @author	Ruslans Vasiljevs
 *
 * @date	29/06/2022
 *
 * $Id:
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

#ifndef __DBLOOKUPTOCRDDET_H
#define __DBLOOKUPTOCRDDET_H
/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
extern int dbcustdet_lookuptocrddet_begin_scan(char *keydata, long start_from);
extern int dbaccdet_lookuptocrddet_begin_scan(char *keydata, long start_from);
extern int dbcrdproduct_lookuptocrddet_begin_scan(char *keydata, long start_from);
extern int dbcrdformat_lookuptocrddet_begin_scan(char *keydata, long start_from);
extern int dbcrdbtch_lookuptocrddet_begin_scan(char *keydata, long start_from);
extern int dbemvprofile_lookuptocrddet_begin_scan(char *keydata, long start_from);
extern int dbemvconf_lookuptocrddet_begin_scan(char *keydata, long start_from);
extern int dblookuptocrddet_get_next(int cursor, long *p_crddet_id);
extern int dblookuptocrddet_close_scan(int cursor);

#endif /* __DBLOOKUPTOCRDDET_H */
