/*-----------------------------------------------------------
 *
 * File		: common.c
 *
 * Purpose	: To generate the library libesql_common.a
 * 		  in the src/lib directory so that v25
 * 		  builds still work.
 *
 * 		  With Config management changes, and building
 * 		  with main's base directory, the a library called
 * 		  libesql_common.a is required to allow building.
 *
 * 		  Nothing is needed in this, it merely needs to
 * 		  exist
 *
 * Author	: Mark Davey 5 July 2002 - NMR 7844
 *
 *-----------------------------------------------------------*/



/*---------------------------------------------------------------
 *
 * Function	:  build_system_id
 *
 * Purpose	:  To return an id for the system build
 *
 * Parameters	:  void
 *
 * Returns	:  decimal number
 *
 * Author	:  Mark Davey 5 July 2002 NMR 7844
 *
 * Comments	:  Couldn't think of another useful function
 * 	           which requires no libraries.
 *
 * idea is:	major_version   0 to 99
 * 		minor_version   0 to 99
 * 		cust_id         0 to 99
 * 		cust_version	0 to 99
 *-------------------------------------------------------------*/
unsigned long build_system_id(void)
{
	unsigned long 	id,
			major_version = 2,
			minor_version = 5,
			cust_id = 0,
			cust_version = 0;
	
	id = 	major_version*100UL*100UL*100UL*100UL 
	      + minor_version*100UL*100UL*100UL
	      + cust_id*100UL*100UL
	      + cust_version;

	return id;
}
