/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDTKNREQ Service definition functions
 *
 * @author	Raul Torres
 *
 * @date	20 Jul 2020
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-4.0/src/des/src/bpdtknreqsv/bpdtknreqsvc.h#1 $
 * 
 * @copyright	FIS Global
 */
/*----------------------------------------------------------------------*/
#ifndef __BPDTKNREQSVC_H
#define __BPDTKNREQSVC_H

/* _________________________ End of P4 stamps ____________________ */

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <cotux.h>
#include <bpd_prod.fd.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
extern int bpdtknreq_init(FILE *p_fp, char *subsect);
extern void bpdtknreq_uninit(void);

#endif

