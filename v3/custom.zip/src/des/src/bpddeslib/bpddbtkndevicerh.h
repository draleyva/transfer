/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDTKNDEVICE type defininitions (ORACLE)
 *
 * @author	Raul Torres
 *
 * @date	06 Apr 2021
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-4.0/src/des/src/bpddeslib/bpddbtkndevicerh.h#1 $
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __BPDDBTKNDEVICERH_H
#define __BPDDBTKNDEVICERH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table BPDTKNDEVICE
 */
typedef struct
{
	char	virtualcardid[64+1];
	char	devicebindingreference[64+1];
	char	tokenstorageid[128+1];
	char	tokenstoratype[32+1];
	char	manufacturer[32+1];
	long	token_id;
	char	devstatus[1+1];
	char	brand[16+1];
	char	model[16+1];
	char	tac[8+1];
	char	osversion[16+1];
	char	firmwareversion[16+1];
	char	phonenumber[20+1];
	char	fourlastdigitphonenumber[4+1];
	char	devicename[128+1];
	char	deviceid[64+1];
	char	androidlasttwo[2+1];
	char	deviceparentid[64+1];
	char	language[3+1];
	char	devicestateflags[2+1];
	char	serialnumber[64+1];
	char	timezone[10+1];
	char	timezonesettings[32+1];
	char	simserialnumber[24+1];
	char	imei[24+1];
	char	phonelosttime[4+1];
	char	networkoperator[16+1];
	char	networktype[32+1];
	char	walletproviderid[128+1];
	char	bindingdate[24];
} BPDTKNDEVICE_t;

/**
 * Structure of indicators for table  BPDTKNDEVICE 
 */
typedef struct
{
	short	virtualcardid;
	short	devicebindingreference;
	short	tokenstorageid;
	short	tokenstoratype;
	short	manufacturer;
	short	token_id;
	short	devstatus;
	short	brand;
	short	model;
	short	tac;
	short	osversion;
	short	firmwareversion;
	short	phonenumber;
	short	fourlastdigitphonenumber;
	short	devicename;
	short	deviceid;
	short	androidlasttwo;
	short	deviceparentid;
	short	language;
	short	devicestateflags;
	short	serialnumber;
	short	timezone;
	short	timezonesettings;
	short	simserialnumber;
	short	imei;
	short	phonelosttime;
	short	networkoperator;
	short	networktype;
	short	walletproviderid;
	short	bindingdate;
} BPDTKNDEVICE_IND_t;

/**
 * Structure to retrieve BPDTKNDEVICE by Primary Key PK_BPDTKNDEVICE
 */
typedef struct
{
	char	virtualcardid[64+1];
	char	devicebindingreference[64+1];
} BPDTKNDEVICE_PK_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
#define BPDTKNDEVICEadd(pdata)					BPDTKNDEVICEadd_IND(pdata, NULL)

#define BPDTKNDEVICEdump(p_BPDTKNDEVICE)				BPDTKNDEVICEdump_IND(p_BPDTKNDEVICE, NULL)
#define BPDTKNDEVICEdumplev(p_BPDTKNDEVICE, dbglev)			BPDTKNDEVICEdumplev_IND(p_BPDTKNDEVICE, NULL, dbglev)

extern	int	BPDTKNDEVICEadd_IND(BPDTKNDEVICE_t *p_BPDTKNDEVICE, BPDTKNDEVICE_IND_t *p_BPDTKNDEVICE_IND);

extern	void	BPDTKNDEVICEdump_IND(BPDTKNDEVICE_t *p_BPDTKNDEVICE, BPDTKNDEVICE_IND_t *p_BPDTKNDEVICE_IND);
extern	void	BPDTKNDEVICEdumplev_IND(BPDTKNDEVICE_t *p_BPDTKNDEVICE, BPDTKNDEVICE_IND_t *p_BPDTKNDEVICE_IND, int dbglev);

extern  int     BPDTKNDEVICEupdbyBPDTKNDEVICE_PK_IND(BPDTKNDEVICE_t *p_BPDTKNDEVICE, BPDTKNDEVICE_IND_t *p_BPDTKNDEVICE_IND, BPDTKNDEVICE_PK_t *p_BPDTKNDEVICE_PK);

#endif
