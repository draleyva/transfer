/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDTKNDEVICE access routines for managing database access (ORACLE)
 *
 * @author	Raul Torres
 *
 * @date	06 Apr 2021
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-4.0/src/des/src/bpddeslib/bpddbtkndevicees.h#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __BPDDBTKNDEVICEES_H
#define __BPDDBTKNDEVICEES_H

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	extern	char	BPDTKNDEVICEvirtualcardid[64+1];
	extern	char	BPDTKNDEVICEdevicebindingreference[64+1];

	extern	char	BPDTKNDEVICE_PKvirtualcardid[64+1];
	extern	char	BPDTKNDEVICE_PKdevicebindingreference[64+1];
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Macros-------------------------------------*/

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_BPDTKNDEVICE_t
	{
		char	virtualcardid[64+1];
		char	devicebindingreference[64+1];
		char	tokenstorageid[128+1];
		char	tokenstoratype[32+1];
		char	manufacturer[32+1];
		long	token_id;
		char	devstatus[1+1];
		char	brand[16+1];
		char	model[16+1];
		char	tac[8+1];
		char	osversion[16+1];
		char	firmwareversion[16+1];
		char	phonenumber[20+1];
		char	fourlastdigitphonenumber[4+1];
		char	devicename[128+1];
		char	deviceid[64+1];
		char	androidlasttwo[2+1];
		char	deviceparentid[64+1];
		char	language[3+1];
		char	devicestateflags[2+1];
		char	serialnumber[64+1];
		char	timezone[10+1];
		char	timezonesettings[32+1];
		char	simserialnumber[24+1];
		char	imei[24+1];
		char	phonelosttime[4+1];
		char	networkoperator[16+1];
		char	networktype[32+1];
		char	walletproviderid[128+1];
		char	bindingdate[24];
	} HOST_BPDTKNDEVICE_t;

	typedef struct HOST_BPDTKNDEVICE_IND_t
	{
		short	virtualcardid_ind;
		short	devicebindingreference_ind;
		short	tokenstorageid_ind;
		short	tokenstoratype_ind;
		short	manufacturer_ind;
		short	token_id_ind;
		short	devstatus_ind;
		short	brand_ind;
		short	model_ind;
		short	tac_ind;
		short	osversion_ind;
		short	firmwareversion_ind;
		short	phonenumber_ind;
		short	fourlastdigitphonenumber_ind;
		short	devicename_ind;
		short	deviceid_ind;
		short	androidlasttwo_ind;
		short	deviceparentid_ind;
		short	language_ind;
		short	devicestateflags_ind;
		short	serialnumber_ind;
		short	timezone_ind;
		short	timezonesettings_ind;
		short	simserialnumber_ind;
		short	imei_ind;
		short	phonelosttime_ind;
		short	networkoperator_ind;
		short	networktype_ind;
		short	walletproviderid_ind;
		short	bindingdate_ind;
	} HOST_BPDTKNDEVICE_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/

/*
#define BPDTKNDEVICEdump(p_BPDTKNDEVICE)				BPDTKNDEVICEdump_IND(p_BPDTKNDEVICE, NULL)
#define BPDTKNDEVICEdumplev(p_BPDTKNDEVICE, dbglev)			BPDTKNDEVICEdumplev_IND(p_BPDTKNDEVICE, NULL, dbglev)
*/
extern	int		BPDTKNDEVICEadd_IND(BPDTKNDEVICE_t *p_BPDTKNDEVICE, BPDTKNDEVICE_IND_t *p_BPDTKNDEVICE_IND);
extern	void	BPDTKNDEVICEcs2hsINS(BPDTKNDEVICE_t *p_BPDTKNDEVICE, BPDTKNDEVICE_IND_t *p_IND, HOST_BPDTKNDEVICE_t *hsData, HOST_BPDTKNDEVICE_IND_t *hsInd);
extern	void	BPDTKNDEVICEdump_IND(BPDTKNDEVICE_t *p_BPDTKNDEVICE, BPDTKNDEVICE_IND_t *p_BPDTKNDEVICE_IND);
extern	void	BPDTKNDEVICEdumplev_IND(BPDTKNDEVICE_t *p_BPDTKNDEVICE, BPDTKNDEVICE_IND_t *p_BPDTKNDEVICE_IND, int dbglev);

extern  int     BPDTKNDEVICEupdbyBPDTKNDEVICE_PK_IND(BPDTKNDEVICE_t *p_BPDTKNDEVICE, BPDTKNDEVICE_IND_t *p_BPDTKNDEVICE_IND, BPDTKNDEVICE_PK_t *p_BPDTKNDEVICE_PK);
extern  void    BPDTKNDEVICEcs2hs(BPDTKNDEVICE_t *p_BPDTKNDEVICE, BPDTKNDEVICE_IND_t *p_IND, HOST_BPDTKNDEVICE_t *hsData, HOST_BPDTKNDEVICE_IND_t *hsInd);
extern  int     BPDTKNDEVICEhs2cs(BPDTKNDEVICE_t *p_BPDTKNDEVICE, BPDTKNDEVICE_IND_t *p_IND, HOST_BPDTKNDEVICE_t *hsData, HOST_BPDTKNDEVICE_IND_t *hsInd);

#endif
