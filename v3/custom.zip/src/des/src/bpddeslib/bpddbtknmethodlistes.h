/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDTKNMETHODLIST access routines for managing database access (ORACLE)
 *
 * @author	Raul Torres
 *
 * @date	06 Apr 2021
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-4.0/src/des/src/bpddeslib/bpddbtknmethodlistes.h#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __BPDDBTKNMETHODLISTES_H
#define __BPDDBTKNMETHODLISTES_H

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	extern	long	BPDTKNMETHODLISTtoken_id;

	extern	long	BPDTKNMETHODLIST_PKtoken_id;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Macros-------------------------------------*/

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_BPDTKNMETHODLIST_t
	{
		long	id;
		long	token_id;
		char	cvm[100+1];
		char	cusamtype[100+1];
		char	custatmvalue[1000+1];
	} HOST_BPDTKNMETHODLIST_t;

	typedef struct HOST_BPDTKNMETHODLIST_IND_t
	{
		short	id_ind;
		short	token_id_ind;
		short	cvm_ind;
		short	cusamtype_ind;
		short	custatmvalue_ind;
	} HOST_BPDTKNMETHODLIST_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/

/*
#define BPDTKNMETHODLISTdump(p_BPDTKNMETHODLIST)				BPDTKNMETHODLISTdump_IND(p_BPDTKNMETHODLIST, NULL)
#define BPDTKNMETHODLISTdumplev(p_BPDTKNMETHODLIST, dbglev)			BPDTKNMETHODLISTdumplev_IND(p_BPDTKNMETHODLIST, NULL, dbglev)
*/
extern	int		BPDTKNMETHODLISTadd_IND(BPDTKNMETHODLIST_t *p_BPDTKNMETHODLIST, BPDTKNMETHODLIST_IND_t *p_BPDTKNMETHODLIST_IND);
extern	void	BPDTKNMETHODLISTcs2hsINS(BPDTKNMETHODLIST_t *p_BPDTKMETHODLIST, BPDTKNMETHODLIST_IND_t *p_IND, HOST_BPDTKNMETHODLIST_t *hsData, HOST_BPDTKNMETHODLIST_IND_t *hsInd);
extern	void	BPDTKNMETHODLISTdump_IND(BPDTKNMETHODLIST_t *p_BPDTKNMETHODLIST, BPDTKNMETHODLIST_IND_t *p_BPDTKNMETHODLIST_IND);
extern	void	BPDTKNMETHODLISTdumplev_IND(BPDTKNMETHODLIST_t *p_BPDTKNMETHODLIST, BPDTKNMETHODLIST_IND_t *p_BPDTKNMETHODLIST_IND, int dbglev);

extern  int     BPDTKNMETHODLISTupdbyBPDTKNMETHODLIST_PK_IND(BPDTKNMETHODLIST_t *p_BPDTKNMETHODLIST, BPDTKNMETHODLIST_IND_t *p_BPDTKNMETHODLIST_IND, BPDTKNMETHODLIST_PK_t *p_BPDTKNMETHODLIST_PK);
extern  void    BPDTKNMETHODLISTcs2hs(BPDTKNMETHODLIST_t *p_BPDTKNMETHODLIST, BPDTKNMETHODLIST_IND_t *p_IND, HOST_BPDTKNMETHODLIST_t *hsData, HOST_BPDTKNMETHODLIST_IND_t *hsInd);
extern  int     BPDTKNMETHODLISThs2cs(BPDTKNMETHODLIST_t *p_BPDTKNMETHODLIST, BPDTKNMETHODLIST_IND_t *p_IND, HOST_BPDTKNMETHODLIST_t *hsData, HOST_BPDTKNMETHODLIST_IND_t *hsInd);

#endif
