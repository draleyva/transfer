/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDTKNUPD Service definition functions
 *
 * @author	Raul Torres
 *
 * @date	20 Jul 2020
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-4.0/src/des/src/bpdtknupd/bpdtknupdsvc.h#1 $
 * 
 * @copyright	FIS Global
 */
/*----------------------------------------------------------------------*/
#ifndef __BPDTKNUPDSVC_H
#define __BPDTKNUPDSVC_H

/* _________________________ End of P4 stamps ____________________ */

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <cotux.h>
#include <bpd_prod.fd.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
extern int bpdtknupd_init(FILE *p_fp, char *subsect);
extern void bpdtknupd_uninit(void);

#endif

