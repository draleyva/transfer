/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDDESLIB Additional DES BPD variables 
 *
 * @author	Raul Torres
 *
 * @date	06 Mar 2020
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-4.0/src/des/src/include/bpddesdef.h#2 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/


#define BPD_RSPCOD_ERRORINITDATA         "02"
#define BPD_RSPCOD_REJECTBYFALCON        "03"
#define BPD_RSPCOD_REJECTBYRULE          "04"
#define BPD_RSPCOD_DEVPROVNOTFOUND       "05"
#define BPD_RSPCOD_UNKNOWNCARD           "06"
#define BPD_RSPCOD_CRDPRODNOK            "07"
#define BPD_RSPCOD_CRDSTATNOK            "08"
#define BPD_RSPCOD_CRDSTATNOK_SUSP       "09"
#define BPD_RSPCOD_DEVICELIMITEX         "62"
/*
#define BPD_RSPCOD_FIELDNOTFOUND         "12"
*/
#define BPD_RSPCOD_INVALIDMETHODID         "01"
#define BPD_RSPCOD_YELLOWFLOWREJECT         "11"

