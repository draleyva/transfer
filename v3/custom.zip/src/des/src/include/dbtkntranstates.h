/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDTKNTRANSTAT access routines for managing database access (ORACLE)
 *
 * @author	Raul Torres
 *
 * @date	06 Mar 2020
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-4.0/src/des/src/include/dbtkntranstates.h#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __DBTKNTRANSTATES_H
#define __DBTKNTRANSTATES_H

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	extern long	BPDTKNTRANSTATid;
	extern char	BPDTKNTRANSTATstatcodefrom[3];
	extern char	BPDTKNTRANSTATstatcodeto[3];
	extern char	BPDTKNTRANSTATaction[21];
	extern char	BPDTKNTRANSTATenabled[2];
EXEC SQL END DECLARE SECTION;
/** @endcond */

/*---------------------------Macros-------------------------------------*/
#define BPDTKNTRANSTAT_HV \
:BPDTKNTRANSTATid,\
:BPDTKNTRANSTATstatcodefrom,\
:BPDTKNTRANSTATstatcodeto,\
:BPDTKNTRANSTATaction,\
:BPDTKNTRANSTATenabled

#define BPDTKNTRANSTAT_COL \
bpdtknstattrans.id,\
bpdtknstattrans.statcodefrom,\
bpdtknstattrans.statcodeto,\
bpdtknstattrans.action,\
bpdtknstattrans.enabled

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_BPDTKNTRANSTAT_t
	{
		long	id;
		char	statcodefrom[3];
		char	statcodeto[3];
		char	action[21];
		char	enabled[2];
	} HOST_BPDTKNTRANSTAT_t;

	typedef struct HOST_BPDTKNTRANSTAT_IND_t
	{
		short	id_ind;
		short	statcodefrom_ind;
		short	statcodeto_ind;
		short	action_ind;
		short	enabled_ind;
	} HOST_BPDTKNTRANSTAT_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/

extern int	BPDTKNTRANSTAThs2cs(BPDTKNTRANSTAT_t *p_BPDTKNTRANSTAT, BPDTKNTRANSTAT_IND_t *p_IND, HOST_BPDTKNTRANSTAT_t *hsData, HOST_BPDTKNTRANSTAT_IND_t *hsInd);

#endif
