/*-----------------------------------------------------------------------
 * 
 * File		: chararray.c
 * 
 * Author	: Graeme Thomas
 * 
 * Created	: 1998-11-03
 * 
 * Purpose	: Support routines for standard import
 * 
 * Comments	: 
 * 	
 * Ident	: $Id$
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.					 
 *-----------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "chararray.h"
#include "constant.h"
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define	MIN_CA_ALLOC_SIZE	8

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
static char rcsid[] = "$Id$";

/*---------------------------Prototypes---------------------------------*/
ctxprivate int char_array_compar (const void *p1, const void *p2);

/*---------------------------Functions----------------------------------*/
/*------------------------------------------------------------------------
 *
 * Function	:  char_array_compar
 *
 * Purpose	:  Compares two elements of a char array
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  Called by qsort
 *
 *----------------------------------------------------------------------*/
ctxprivate int char_array_compar (const void *p1, const void *p2)
{
	char_row_t *pr1 = (char_row_t *)p1;
	char_row_t *pr2 = (char_row_t *)p2;

	return (pr1->data - pr2->data);
}

/*------------------------------------------------------------------------
 *
 * Function	:  char_array_init
 *
 * Purpose	:  
 *
 * Parameters	:  guess - guess at initial size
 *
 * Returns	:  pointer to char_array structure
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic char_array_t *char_array_init (int guess)
{
	char_array_t *pca;

	pca = (char_array_t *)malloc (sizeof (char_array_t));
	if (pca != NULL)
	{
		if (guess > 0)
		{
			pca->sdirows = 0;
			pca->used  = 0;
			pca->csr   = 0;
			pca->array = (char_row_t *)malloc
					(guess*sizeof (char_row_t));
			if (pca->array != NULL)
			{
				pca->size = guess;
			}
			else
			{
				/*
				 * The initial allocation failed.  We don't
				 * treat this as an error, as perhaps it will
				 * work next time
				 */
				pca->size = 0;
			}
		}
		else
		{
			pca->sdirows = 0;
			pca->array = NULL;
			pca->used  = 0;
			pca->csr   = 0;
			pca->size  = 0;
		}
	}

	return pca;
}

/*------------------------------------------------------------------------
 *
 * Function	:  char_array_clear
 *
 * Purpose	:  
 *
 * Parameters	:  pca - pointer to char_array structure
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/

 ctxpublic int char_array_clear (char_array_t *pca)
 {
	int i;

	for (i = 0; i < pca->used; i++)
	{
		free (pca->array[i].row);
		pca->array[i].row  = NULL;
		pca->array[i].data = 0;
	}

	pca->used = 0;
	pca->csr  = 0;

	return SUCCEED;
}

/*------------------------------------------------------------------------
 *
 * Function	:  char_array_free
 *
 * Purpose	:  
 *
 * Parameters	:  pca - pointer to char_array structure
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/

ctxpublic int char_array_free (char_array_t *pca)
{
	if (pca)
	{
		char_array_clear (pca);
		free (pca->array);
	}

	free (pca);

	return SUCCEED;
}

/*------------------------------------------------------------------------
 *
 * Function	:  char_array_add
 *
 * Purpose	:  add a row to the array
 *
 * Parameters	:  pca - pointer to char_array structure
 *		   data - data associated with the row
 *		   row - row to add
 *
 * Returns	:  SUCCEED/FAIL
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int char_array_add (char_array_t *pca, long data, char *row)
{
	int ret = SUCCEED;

	/*
	 * Check to see if more space is needed.  If so, double the
	 * previous allocation size, and get more memory.  If that succeeds,
	 * alter the description accordingly.  Otherwise leave everything
	 * alone, and report failure.
	 */
	if (pca->used >= pca->size)
	{
		int         newsize = 2*pca->size;
		char_row_t *newarray;

		if (newsize < MIN_CA_ALLOC_SIZE)
			newsize = MIN_CA_ALLOC_SIZE;
		
		newarray = (char_row_t *)realloc (pca->array,
					newsize*sizeof (char_row_t));
		if (newarray == NULL)
		{
			/*
			 * We cannot allocate the extra size.  No damage
			 * has been done, so just report failure.
			 */
			ret = FAIL;
		}
		else
		{
			pca->array = newarray;
			pca->size = newsize;
		}
	}

	/*
	 * We now have enough space in the array.  Allocate space for the
	 * new line, and assign it to the array.  If we fail to get the
	 * memory, report failure.
	 */
	if (ret == SUCCEED)
	{
		size_t len    = (size_t)strlen (row) + 1;
		char  *newrow = (char *)malloc (len);

		if (newrow == NULL)
		{
			ret = FAIL;
		}
		else
		{
			memcpy (newrow, row, len);
			pca->array[pca->used  ].data = data;
			pca->array[pca->used++].row  = newrow;
			if(strncmp(ERROR_TAG, row, strlen(ERROR_TAG)))
			{
				pca->sdirows++;
			}
			pca->csr  = 0;
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  char_array_sort
 *
 * Purpose	:  sort the data in the array
 *
 * Parameters	:  pca - pointer to char_array structure
 *
 * Returns	:  SUCCEED/FAIL
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic void char_array_sort (char_array_t *pca)
{
	if (pca->used > 0)
	{
		qsort ((void *)pca->array,
			pca->used, sizeof (char_row_t), char_array_compar);
	}
	pca->csr  = 0;
}

/*------------------------------------------------------------------------
 *
 * Function	:  char_array_first
 *
 * Purpose	:  Start a scan of the lines in the array
 *
 * Parameters	:  pca -> pointer to character array
 *		   pdata -> pointer to returned data
 *		   prow -> pointer to returned row
 *
 * Returns	:  SUCCEED/FAIL
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int char_array_first (char_array_t *pca, long *pdata, char **prow)
{
	int ret = FAIL;

	if (pca->used != 0)
	{
		*pdata = pca->array[0].data;
		*prow  = pca->array[0].row;
		pca->csr = 1;
		ret = SUCCEED;
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  char_array_next
 *
 * Purpose	:  Continue a scan of the lines in the array
 *
 * Parameters	:  pca -> pointer to character array
 *		   pdata -> pointer to returned data
 *		   prow -> pointer to returned row
 *
 * Returns	:  SUCCEED/FAIL
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int char_array_next (char_array_t *pca, long *pdata, char **prow)
{
	int ret = FAIL;

	if (pca->used > pca->csr)
	{
		*pdata = pca->array[pca->csr].data;
		*prow  = pca->array[pca->csr].row;
		pca->csr++;
		ret = SUCCEED;
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  char_array_used
 *
 * Purpose	:  Report how many records are in the array
 *
 * Parameters	:  pca -> pointer to character array
 *
 * Returns	:  Number of rows
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int char_array_used (char_array_t *pca)
{
	int ret = 0;

	if (pca)
	{
		ret = pca->used;
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  char_array_sdirows
 *
 * Purpose	:  Report how many sdi records are in the array
 *
 * Parameters	:  pca -> pointer to character array
 *
 * Returns	:  Number of sdi rows
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int char_array_sdirows (char_array_t *pca)
{
	int ret = 0;

	if (pca)
	{
		ret = pca->sdirows;
	}

	return ret;
}
