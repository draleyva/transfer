/*-----------------------------------------------------------------------
 * Author       : Rumana Malik
 *
 * Created      : Aug 97
 *
 * Purpose      : Function.h 
 *
 * Comments     :  
 *
 * Ident        : @(#) $Id: //depot/cortex/v2/main/src/etc/
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __FUNCTION_H
#define __FUNCTION_H
/*---------------------------Includes-----------------------------------*/
#include <constant.h>

/*---------------------------Statics-------------------------------------*/
#define NEXTCRDBTCH_TAG         "nextcrdbtch"
/*---------------------------Prototypes---------------------------------*/
extern int endscan(void);
extern int endscan_cdhst(void);
extern int endscan_crd(void);
extern int endscan_crdacc(void);
extern int endscan_crdaccbyan(void);
extern int nxtscan(void);
extern int nxtscan_cdsthst(void);
extern int nxtscan_crd(void);
extern int nxtscan_crdacc(void);
extern int nxtscan_crdaccbyan(void);
extern int bgnscan(CRDDET_t *p_crddet, int btchtyp);
extern int bgnscan_crd(char* custcode,char* instcode);
extern int bgnscan_crdacc(CRDACC_HASH_t *p_crdacc_k);
extern int bgnscan_crdaccbyan(CRDACC_HASH_t *p_crdacc_k);
extern int avail_batch( int btchtyp, CRDBTCH_t *p_crdbtch, CRDDET_t *p_crddet);
extern int process_crdbtch(ctxbool p_btch_open,int btchtype, CRDDET_t *p_crddet, CRDBTCH_t *p_crdbtch);
extern int upd_crdbtch( CRDBTCH_t *crdbtch, int btchtype, CRDDET_t *crddet);
extern int add_crdbtch( CRDBTCH_t *p_crdbtch,int btchtype, CRDDET_t *p_crddet );

extern int add_cust (char* buf);
extern int add_acc(char* buf);
extern int account_add(char* buf);
extern int del_cust(char* buf);
extern int del_card(char* buf);
extern int del_acc (char* buf);
extern int amend_cust (char* buf);
extern int amend_acc (char* buf);
extern int amend_card(char* buf);
extern int reiss_card (char* buf);
extern int reiss_PIN (char* buf);
extern int rep_card (char* buf);
extern int ren_card (char* buf);
extern int new_card (char* buf);
extern int card_appl(char* buf);
extern int del_crdaccbyan(CRDACC_HASH_t *p_crdacc_k); 
extern add_card(int *p_card_count, char* buf, CUSTDET_t  *p_custdet);
extern add_crdacc(CRDDET_t  *p_crddet);
extern void set_ccs_installed (ctxbool ccs_installed);
/* mvitolin HAAB_10_004_WO-1 16/07/2010 */
extern void set_noupdstatus( char * noupstatcode );
extern void set_override_noupdstatus( char * ovrnoupstatcode );

ctxprivate ctxbool    need_crdpin( char *crdproduct );
ctxprivate ctxbool    need_crdstmt( char *crdproduct );
int add_crdstmt(char* buf);
int add_crdpin(char* buf);

ctxprivate long calc_next_stmtdate( int cycle );
/*---------------------------Typedefs-----------------------------------*/
typedef struct
{
        int act_code;
        int rec_type;
        int (*f) (char* buf);
 
}Func;
extern Func proc_func[]; 
 
/*---------------------------Globals------------------------------------*/
/*extern int M_crdbtch_size;*/
extern ctxbool G_exists;
extern char G_bak[BUFSIZ];
extern char G_priority[2];
extern int G_rec_cnt;
/* extern int G_err_cnt; */
extern char G_old_pan[20];
extern short G_old_seq;
static int M_scan_first = TRUE;
static int M_crdacc_first = TRUE;
static int M_cdsthst_first = TRUE;
static int M_crd_first = TRUE;

/*---------------------------Statics------------------------------------*/
 
#endif
/*]i
extern amend_cardappl(void);
extern del_cardappl (void);
*/
