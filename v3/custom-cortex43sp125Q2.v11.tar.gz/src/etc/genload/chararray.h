/*-----------------------------------------------------------------------
 * 
 * File		: chararray.h 
 * 
 * Author	: Graeme Thomas
 * 
 * Created	: 1998-11-06
 * 
 * Purpose	: Character array manipulation
 * 
 * Comments	: 
 * 	
 * Ident	: @(#) $Id$
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.					 
 *-----------------------------------------------------------------------*/
#ifndef __ROUTINES_H
#define __ROUTINES_H
/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
typedef struct {
	long data;
	char *row;
} char_row_t;

typedef struct {
	int size;
	int used;
	/* NMR013959 - To keep track of actual sdi records in the buffer */
	int sdirows;
	int csr;
	char_row_t *array;
} char_array_t;

/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
ctxpublic char_array_t *char_array_init (int guess);
ctxpublic int           char_array_free (char_array_t *pca);
ctxpublic int           char_array_add (char_array_t *pca, long data, char *row);
ctxpublic void          char_array_sort (char_array_t *pca);
ctxpublic int char_array_first (char_array_t *pca, long *pdata, char **prow);
ctxpublic int char_array_next (char_array_t *pca, long *pdata, char **prow);
ctxpublic int char_array_used (char_array_t *pca);
ctxpublic int char_array_sdirows (char_array_t *pca);

#endif

