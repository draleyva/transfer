/*-----------------------------------------------------------------------
 * 
 * File		: nmonpiscv.c
 * 
 * Author	: Ruslans Vasiljevs
 * 
 * Created	: 12/08/2022
 *
 * Purpose	: NMON_PIS data conversion mapping
 * 
 * Comments	: 
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
 *-----------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>

#include <cortex.h>
#include <cocbfdef.h>
#include <coencpan.h>
#include <encgen.h>
#include <diges.h>

#include <sldbg.h>
#include <slstring.h>
#include <slstrip.h>
#include <sldtm.h>
#include <slmap.h>

#include <dbnmonpisrh.h>
#include <dbcshsrh.h>
#include <dbcdetrh.h>
#include <dbcstarh.h>
#include <dbcdsthstrx.h>
#include <dberr.h>

#include <nmonpiscv.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define NMON_RECORDTYPE	"NMON20"
#define NMON_VERSION	"2.0"

#define LOG_HINT_INSERT	'I'
#define LOG_HINT_UPDATE	'U'

#define FO(x) OFFSET(NMON_PIS_t,x)
#define FS(x) ELEM_SIZE(NMON_PIS_t,x)

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/* Name of the workflow to be executed by Falcon Fraud Manager */
ctxprivate char	M_workflow[16+1] = {EOS};
/* Unique identifier for the client or subclient */
ctxprivate char	M_clientid[16+1] = {EOS};

/* Card status */
ctxprivate map_tbl_t map_nmon20status[] =
{
	/* ctx, 		Falcon */
	{"99",			"40",	STR},	/* Statused, other (blocked)		*/
	{CRDSTAT_EXPIRED,	"40",	STR},	/* Statused, other (blocked)		*/
	{CRDSTAT_LOST,		"27",	STR},	/* Closed, lost				*/
	{CRDSTAT_STOLEN,	"26",	STR},	/* Closed, stolen			*/
	{CRDSTAT_CLOSED,	"21",	STR},	/* Closed, cardholder request		*/
	{CRDSTAT_CANCEL,	"23",	STR},	/* Closed, bank action (revoked)	*/
	{CRDSTAT_FRAUD,		"25",	STR},	/* Closed, fraud			*/
	{"09",			"11",	STR},	/* Open, inactive			*/
	{"26",			"00",	STR},	/* Open, non-statused, active		*/
	{CRDSTAT_NORMAL,	"00",	STR},	/* Open, non-statused, active		*/
	{CRDSTAT_PINTRIES,	"40",	STR},	/* Statused, other (blocked)		*/
	{"52",			"40",	STR},	/* Statused, other (blocked)		*/
	{"10",			"40",	STR},	/* Statused, other (blocked)		*/
	{"21",			"40",	STR},	/* Statused, other (blocked)		*/
	{"96",			"27",	STR},	/* Closed, lost				*/
	{NULL}
};

/* Token status */
ctxprivate map_tbl_t map_nmon20tknstatus[] =
{
	/* ctx, Falcon */
	{"I",	"001",	STR},	/* In Progress	*/
	{"A",	"001",	STR},	/* Active	*/
	{"S",	"003",	STR},	/* Suspended	*/
	{"D",	"004",	STR},	/* Deactivated	*/
	{"E",	"004",	STR},	/* Expired	*/
	{NULL}
};

/* Token type */
ctxprivate map_tbl_t map_tkntype[] =
{
	/* ctx, falcon */
	{TKN_TYPE_CRD_ON_FILE,	"1",	STR},	/* Card on File			*/
	{TKN_TYPE_SECURE_ELEM,	"2",	STR},	/* Secure Element		*/
	{TKN_TYPE_CLOUD_BASED,	"3",	STR},	/* Host Card Emulation		*/
	{"05",			"5",	STR},	/* E-commerce enabler		*/
	{"06",			"6",	STR},	/* Pseudo account 		*/
	{NULL}
};

/*---------------------------Prototypes---------------------------------*/
ctxprivate int NMONctxdate(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONworkflow(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONrecordtype(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONdataspecificationversion(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONclientidfromheader(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONrecordcreationdate(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONrecordcreationtime(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONrecordcreationmilliseconds(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONcustomeridfromheader(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONcustomeracctnumber(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONtransactiondate(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONtransactiontime(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnonmoncode(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnonmoncodeinitiator(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONservicerepresentativeid(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONpan(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONpaymentinstrumentid(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnewpan(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnewpaymentinstrumentid(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONactioncode(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnewentityname(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONoldentityname(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnewcity(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONoldcity(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnewpostalcode(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONoldpostalcode(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnewcountrycode(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONoldcountrycode(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnewdate1(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONolddate1(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnewdate2(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONolddate2(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnewid1(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONoldid1(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnewcode1(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONoldcode1(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnewcode2(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONoldcode2(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnewcode3(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONoldcode3(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnewindicator1(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONoldindicator1(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnewindicator2(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONoldindicator2(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONnewnumericvalue1(NMON_Data_t *data, char *out, size_t size);
ctxprivate int NMONoldnumericvalue1(NMON_Data_t *data, char *out, size_t size);

ctxprivate char* NMON3102status_default(char *statcode);

ctxprivate int nmonpis_decrypt_pan(char *enc, char *clr, size_t sizeclr);

ctxprivate nmon_pis_cnv_t M_convtab_NMON20[] =
{
/* offset				len				p_convfn */
{ FO(ctxdate), 				FS(ctxdate),			NMONctxdate },
{ FO(workflow),				FS(workflow), 			NMONworkflow },
{ FO(recordtype),			FS(recordtype),			NMONrecordtype },
{ FO(dataspecificationversion),		FS(dataspecificationversion),	NMONdataspecificationversion },
{ FO(clientidfromheader),		FS(clientidfromheader),		NMONclientidfromheader },
{ FO(recordcreationdate),		FS(recordcreationdate),		NMONrecordcreationdate },
{ FO(recordcreationtime),		FS(recordcreationtime),		NMONrecordcreationtime },
{ FO(recordcreationmilliseconds),	FS(recordcreationmilliseconds),	NMONrecordcreationmilliseconds },
{ FO(gmtoffset),			FS(gmtoffset), 			NULL },
{ FO(customeridfromheader),		FS(customeridfromheader),	NMONcustomeridfromheader },
{ FO(customeracctnumber),		FS(customeracctnumber),		NMONcustomeracctnumber },
{ FO(externaltransactionid),		FS(externaltransactionid),	NULL },
{ FO(transactiondate),			FS(transactiondate),		NMONtransactiondate },
{ FO(transactiontime),			FS(transactiontime),		NMONtransactiontime },
{ FO(nonmoncode),			FS(nonmoncode),			NMONnonmoncode },
{ FO(nonmoncodeinitiator),		FS(nonmoncodeinitiator),	NMONnonmoncodeinitiator },
{ FO(decisioncode),			FS(decisioncode),		NULL },
{ FO(contactmethod),			FS(contactmethod),		NULL },
{ FO(contactmethodid),			FS(contactmethodid),		NULL },
{ FO(servicerepresentativeid),		FS(servicerepresentativeid),	NMONservicerepresentativeid },
{ FO(pan), 				FS(pan),			NMONpan },
{ FO(paymentinstrumentid),		FS(paymentinstrumentid),	NMONpaymentinstrumentid },
{ FO(newcustomerid),			FS(newcustomerid),		NULL },
{ FO(newcustomeracctnumber),		FS(newcustomeracctnumber),	NULL },
{ FO(newpan),				FS(newpan),			NMONnewpan },
{ FO(newpaymentinstrumentid),		FS(newpaymentinstrumentid),	NMONnewpaymentinstrumentid },
{ FO(actioncode),			FS(actioncode),			NMONactioncode },
{ FO(newgivenname),			FS(newgivenname),		NULL },
{ FO(oldgivenname),			FS(oldgivenname),		NULL },
{ FO(newmiddlename),			FS(newmiddlename),		NULL },
{ FO(oldmiddlename),			FS(oldmiddlename),		NULL },
{ FO(newsurname),			FS(newsurname),			NULL },
{ FO(oldsurname),			FS(oldsurname),			NULL },
{ FO(newsuffix),			FS(newsuffix),			NULL },
{ FO(oldsuffix),			FS(oldsuffix),			NULL },
{ FO(newentityname),			FS(newentityname),		NMONnewentityname },
{ FO(oldentityname),			FS(oldentityname),		NMONoldentityname },
{ FO(newstreetline1),			FS(newstreetline1),		NULL },
{ FO(oldstreetline1),			FS(oldstreetline1),		NULL },
{ FO(newstreetline2),			FS(newstreetline2),		NULL },
{ FO(oldstreetline2),			FS(oldstreetline2),		NULL },
{ FO(newstreetline3),			FS(newstreetline3),		NULL },
{ FO(oldstreetline3),			FS(oldstreetline3),		NULL },
{ FO(newstreetline4),			FS(newstreetline4),		NULL },
{ FO(oldstreetline4),			FS(oldstreetline4),		NULL },
{ FO(newcity),				FS(newcity),			NMONnewcity },
{ FO(oldcity),				FS(oldcity),			NMONoldcity },
{ FO(newstateprovince),			FS(newstateprovince),		NULL },
{ FO(oldstateprovince),			FS(oldstateprovince),		NULL },
{ FO(newpostalcode),			FS(newpostalcode),		NMONnewpostalcode },
{ FO(oldpostalcode),			FS(oldpostalcode),		NMONoldpostalcode },
{ FO(newcountrycode),			FS(newcountrycode),		NMONnewcountrycode },
{ FO(oldcountrycode),			FS(oldcountrycode),		NMONoldcountrycode },
{ FO(newphone1),			FS(newphone1),			NULL },
{ FO(oldphone1),			FS(oldphone1),			NULL },
{ FO(newphone2),			FS(newphone2),			NULL },
{ FO(oldphone2),			FS(oldphone2),			NULL },
{ FO(newemailaddress),			FS(newemailaddress),		NULL },
{ FO(oldemailaddress),			FS(oldemailaddress),		NULL },
{ FO(newdate1),				FS(newdate1),			NMONnewdate1 },
{ FO(olddate1),				FS(olddate1),			NMONolddate1 },
{ FO(newdate2),				FS(newdate2),			NMONnewdate2 },
{ FO(olddate2),				FS(olddate2),			NMONolddate2 },
{ FO(newid1),				FS(newid1),			NMONnewid1 },
{ FO(oldid1),				FS(oldid1),			NMONoldid1 },
{ FO(newid2),				FS(newid2),			NULL },
{ FO(oldid2),				FS(oldid2),			NULL },
{ FO(newcode1),				FS(newcode1),			NMONnewcode1 },
{ FO(oldcode1),				FS(oldcode1),			NMONoldcode1 },
{ FO(newcode2),				FS(newcode2),			NMONnewcode2 },
{ FO(oldcode2),				FS(oldcode2),			NMONoldcode2 },
{ FO(newcode3),				FS(newcode3),			NMONnewcode3 },
{ FO(oldcode3),				FS(oldcode3),			NMONoldcode3 },
{ FO(newindicator1),			FS(newindicator1),		NMONnewindicator1 },
{ FO(oldindicator1),			FS(oldindicator1),		NMONoldindicator1 },
{ FO(newindicator2),			FS(newindicator2),		NMONnewindicator2 },
{ FO(oldindicator2),			FS(oldindicator2),		NMONoldindicator2 },
{ FO(newindicator3),			FS(newindicator3),		NULL },
{ FO(oldindicator3),			FS(oldindicator3),		NULL },
{ FO(newindicator4),			FS(newindicator4),		NULL },
{ FO(oldindicator4),			FS(oldindicator4),		NULL },
{ FO(newmonetaryvalue),			FS(newmonetaryvalue),		NULL },
{ FO(oldmonetaryvalue),			FS(oldmonetaryvalue),		NULL },
{ FO(currencycode),			FS(currencycode),		NULL },
{ FO(currencyconversionrate),		FS(currencyconversionrate),	NULL },
{ FO(newnumericvalue1),			FS(newnumericvalue1),		NMONnewnumericvalue1 },
{ FO(oldnumericvalue1),			FS(oldnumericvalue1),		NMONoldnumericvalue1 },
{ FO(newnumericvalue2),			FS(newnumericvalue2),		NULL },
{ FO(oldnumericvalue2),			FS(oldnumericvalue2),		NULL },
{ FO(newcharactervalue),		FS(newcharactervalue),		NULL },
{ FO(oldcharactervalue),		FS(oldcharactervalue),		NULL },
{ FO(newtext),				FS(newtext),			NULL },
{ FO(oldtext),				FS(oldtext),			NULL },
{ FO(ctxcomment),			FS(ctxcomment),			NULL },
{ FO(userindicator01),			FS(userindicator01),		NULL },
{ FO(userindicator02),			FS(userindicator02),		NULL },
{ FO(userindicator03),			FS(userindicator03),		NULL },
{ FO(userindicator04),			FS(userindicator04),		NULL },
{ FO(userindicator05),			FS(userindicator05),		NULL },
{ FO(usercode1),			FS(usercode1),			NULL },
{ FO(usercode2),			FS(usercode2),			NULL },
{ FO(usercode3),			FS(usercode3),			NULL },
{ FO(usercode4),			FS(usercode4),			NULL },
{ FO(usercode5),			FS(usercode5),			NULL },
{ FO(userdata01),			FS(userdata01),			NULL },
{ FO(userdata02),			FS(userdata02),			NULL },
{ FO(userdata03),			FS(userdata03),			NULL },
{ FO(userdata04),			FS(userdata04),			NULL },
{ FO(userdata05),			FS(userdata05),			NULL },
{ FO(userdata06),			FS(userdata06),			NULL },
{ FO(userdata07),			FS(userdata07),			NULL },
{ FO(userdata08),			FS(userdata08),			NULL },
{ FO(userdata09),			FS(userdata09),			NULL },
{ FO(userdata10),			FS(userdata10),			NULL },
{ FO(userdata11),			FS(userdata11),			NULL },
{ FO(userdata12),			FS(userdata12),			NULL },
{ FO(userdata13),			FS(userdata13),			NULL },
{ FO(userdata14),			FS(userdata14),			NULL },
{ FO(userdata15),			FS(userdata15),			NULL },
{ FO(reserved_01),			FS(reserved_01),		NULL }
};

/*------------------------------------------------------------------------
 *
 * Function     :  NMONctxdate
 *
 * Purpose      :  Set date when record added
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONctxdate(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	*((long *)out) = local_date();

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONworkflow
 *
 * Purpose      :  Set name of the workflow to be executed by Falcon Fraud Manager
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONworkflow(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, M_workflow);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONrecordtype
 *
 * Purpose      :  Set NMON record type
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONrecordtype(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	
	slstrcpy_se(out, size, NMON_RECORDTYPE);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONdataspecificationversion
 *
 * Purpose      :  Set NMON data specification version
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONdataspecificationversion(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, NMON_VERSION);

	return ret;	
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONclientidfromheader
 *
 * Purpose      :  Set unique identifier for the client or subclient
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONclientidfromheader(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, M_clientid);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONrecordcreationdate
 *
 * Purpose      :  Set date that NMON record was created
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONrecordcreationdate(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	/* local_timestamp(): yyyymmdd part */
	sscanf(data->timestamp, "%08ld", (long *)out);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONrecordcreationtime
 *
 * Purpose      :  Set time that NMON record was created
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONrecordcreationtime(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	/* local_timestamp(): HHMMSS part */
	sscanf(data->timestamp+8, "%06ld", (long *)out);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONrecordcreationmilliseconds
 *
 * Purpose      :  Set milliseconds portion of the time that NMON record was created
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONrecordcreationmilliseconds(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	/* local_timestamp(): uuu part */
	sscanf(data->timestamp+14, "%03ld", (long *)out);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONcustomeridfromheader
 *
 * Purpose      :  Set Primary Customer Identifier. Financial institution's 
 * 		   unique identifier for the primary customer for the PAN
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONcustomeridfromheader(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, data->custdet.custcode);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONcustomeracctnumber
 *
 * Purpose      :  Set financial institution's unique identifier for the account
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONcustomeracctnumber(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, data->accdet.accno);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONtransactiondate
 *
 * Purpose      :  Set date on which the nonmonetary event took place
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONtransactiondate(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	/* NMON_LOG.tstamp: yyyymmdd part */
	sscanf(data->nmonlog.tstamp, "%08ld", (long *)out);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONtransactiontime
 *
 * Purpose      :  Set time when the nonmonetary event took place
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONtransactiontime(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	/* NMON_LOG.tstamp: HHMMSS part */
	sscanf(data->nmonlog.tstamp+8, "%06ld", (long *)out);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONtransactiontime
 *
 * Purpose      :  Set the code defining the nonmonetary event
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnonmoncode(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	sprintf(out, "%04d", data->nmoncode);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONnonmoncodeinitiator
 *
 * Purpose      :  Set entity initiating the nonmonetary event
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnonmoncodeinitiator(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	
	switch (data->nmoncode)
	{
		case NMON_CODE_0003:
		case NMON_CODE_3000:
			slstrcpy_se(out, size, "B"); /* Bank */
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: nonmonCodeInitiator set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONservicerepresentativeid
 *
 * Purpose      :  Set the identification of the service representative 
 * 		   that worked with the customer for this transaction
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONservicerepresentativeid(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	CDSTHST_t cdsthst;
	CDSTHST_HASH_t cdsthst_hash;
	
	memset(&cdsthst, 0, sizeof(cdsthst));
	memset(&cdsthst_hash, 0, sizeof(cdsthst_hash));

	switch (data->nmoncode)
	{
		case NMON_CODE_0003:
		case NMON_CODE_3000:
			ret = dbcdsthst_whoset_getby_statcodes(data->crddet.id, 
							       data->nmonlog.oldvalue6, data->nmonlog.newvalue6,
							       out);
			if (SQE_EOFERR == ret)
			{
				DBG_PRINTF((dbg_progdetail, "CDSTHST not found"));
				ret = SUCCEED;
			}
			break;
		case NMON_CODE_3102:
			sscanf(data->nmonlog.keydata, "%ld", &cdsthst_hash.crddet_id);
			sscanf(data->nmonlog.newvalue1, "%08ld", &cdsthst_hash.date_set);
			sscanf(data->nmonlog.newvalue3, "%ld", &cdsthst_hash.time_set);
			ret = CDSTHSTgetbyCDSTHST_HASH(&cdsthst, &cdsthst_hash);
			if (SUCCEED == ret)
			{
				slstrcpy_se(out, size, cdsthst.who_set);	
			}
			else if (SQE_EOFERR == ret)
			{
				DBG_PRINTF((dbg_progdetail, "CDSTHST not found"));
				ret = SUCCEED;
			}
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: serviceRepresentativeId set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONpan
 *
 * Purpose      :  Primary Account Number (PAN) of the payment instrument
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONpan(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	CRDDET_t *p_crddet = NULL;

	switch (data->nmoncode)
	{
		case NMON_CODE_0003:
		case NMON_CODE_3000:
			p_crddet = data->p_old_crddet;
			break;
		case NMON_CODE_3020:
		case NMON_CODE_3100:
		case NMON_CODE_3102:
		case NMON_CODE_3400:
		case NMON_CODE_3401:
			p_crddet = &data->crddet;
			break;
		default:
			break;
	}

	if (NULL != p_crddet)
	{
		ret = nmonpis_decrypt_pan(p_crddet->pan, out, size);
		if (SUCCEED != ret)
		{
			DBG_PRINTF((dbg_syserr, "ERROR: Decrypt PAN failed for card id=%ld", p_crddet->id));
		}
	}
	else
	{
		DBG_PRINTF((dbg_progdetail, "NMON %04d: pan set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONpaymentinstrumentid
 *
 * Purpose      :  Unique identifier for the payment instrument
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONpaymentinstrumentid(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3401:
			slstrcpy_se(out, size, data->token.vpan);
			break;
		case NMON_CODE_3400:
			if (NULL != data->p_old_token)
			{
				slstrcpy_se(out, size, data->p_old_token->vpan);
				break;
			}
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: paymentInstrumentId set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONnewpan
 *
 * Purpose      :  Primary Account Number (PAN) of the new payment instrument
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnewpan(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_0003:
		case NMON_CODE_3000:
			ret = nmonpis_decrypt_pan(data->crddet.pan, out, size);
			if (SUCCEED != ret)
			{
				DBG_PRINTF((dbg_syserr, "ERROR: Decrypt PAN failed for card id=%ld", data->crddet.id));
			}
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: newPan set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONpaymentinstrumentid
 *
 * Purpose      :  Unique identifier for the new payment instrument
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnewpaymentinstrumentid(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3400:
			slstrcpy_se(out, size, data->token.vpan);
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: newPaymentInstrumentId set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONactioncode
 *
 * Purpose      :  Code that indicates some specific actions related to the nonmonetary event
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONactioncode(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_0003:
			slstrcpy_se(out, size, "C"); /* Copy the profile from old to new and retain the old */
			break;
		case NMON_CODE_3020:
			slstrcpy_se(out, size, "P0"); /* Indicates that a payee account has been removed */
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: actionCode set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONnewentityname
 *
 * Purpose      :  Entity name
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnewentityname(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3000:
			slstrncpy_se(out, size, data->crddet.embossname,
				     strlen(data->crddet.embossname));
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: newEntityName set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONoldentityname
 *
 * Purpose      :  Previous entity name
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONoldentityname(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3000:
			if (NULL != data->p_old_crddet)
			{
				slstrncpy_se(out, size, data->p_old_crddet->embossname, 
					     strlen(data->p_old_crddet->embossname));
				break;
			}
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: oldEntityName set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONnewcity
 *
 * Purpose      :  newCity
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnewcity(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	
	switch (data->nmoncode)
	{
		case NMON_CODE_3100:
			slstrncpy_se(out, size, data->nmonlog.newvalue1, 
				     strlen(data->nmonlog.newvalue1));
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: newCity set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONoldcity
 *
 * Purpose      :  oldCity
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONoldcity(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3100:
			slstrncpy_se(out, size, data->nmonlog.oldvalue1,
				     strlen(data->nmonlog.oldvalue1));
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: oldCity set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONnewpostalcode
 *
 * Purpose      :  newPostalCode
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnewpostalcode(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3100:
			slstrncpy_se(out, size, data->nmonlog.newvalue2,
				     strlen(data->nmonlog.newvalue2));
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: newPostalCode set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONoldpostalcode
 *
 * Purpose      :  oldPostalCode
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONoldpostalcode(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3100:
			slstrncpy_se(out, size, data->nmonlog.oldvalue2,
				     strlen(data->nmonlog.oldvalue2));
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: oldPostalCode set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONnewcountrycode
 *
 * Purpose      :  ISO 3166-1 three-digit numeric value of country
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnewcountrycode(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3100:
			slstrncpy_se(out, size, data->nmonlog.newvalue3,
				     strlen(data->nmonlog.newvalue3));
			break;
		case NMON_CODE_3000:
			slstrcpy_se(out, size, "214"); /* Dominican Republic */
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: newCountryCode set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONoldcountrycode
 *
 * Purpose      :  Previous customer's country code, use ISO 3166-1 three-digit 
 * 		   numeric value
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONoldcountrycode(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3100:
			slstrncpy_se(out, size, data->nmonlog.oldvalue3,
				     strlen(data->nmonlog.oldvalue3));
			break;
		case NMON_CODE_3000:
			if (NULL != data->p_old_crddet)
			{
				slstrcpy_se(out, size, "214"); /* Dominican Republic */
				break;
			}
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: oldCountryCode set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONnewdate1
 *
 * Purpose      :  newDate1
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnewdate1(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3000:
			*((long *)out) = data->crddet.date_statchg;
			break;
		case NMON_CODE_3020:
		case NMON_CODE_3102:
		case NMON_CODE_3400:
		case NMON_CODE_3401:
			sscanf(data->nmonlog.newvalue1, "%08ld", (long *)out);
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: newDate1 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONolddate1
 *
 * Purpose      :  oldDate1
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONolddate1(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	long dateset;

	switch (data->nmoncode)
	{
		case NMON_CODE_3000:
			if (NULL != data->p_old_crddet)
			{
				*((long *)out) = data->p_old_crddet->date_statchg;
			}
			break;
		case NMON_CODE_3020:
			if (LOG_HINT_UPDATE == data->nmonlog.hint[0])
			{
				sscanf(data->nmonlog.oldvalue1, "%08ld", (long *)out);	
			}
			break;
		case NMON_CODE_3102:
			sscanf(data->nmonlog.newvalue1, "%08ld", &dateset);
			ret = dbcdsthst_dateset_getby_before(data->crddet.id, &dateset, (long *)out);
			if (SQE_EOFERR == ret)
			{
				*((long *)out) = dateset;
				ret = SUCCEED;
			}
			break;
		case NMON_CODE_3400:
			if (NULL != data->p_old_token)
			{
				sscanf(data->p_old_token->tknstatustimestamp, "%08ld", (long *)out);
			}
			break;
		case NMON_CODE_3401:
			sscanf(data->nmonlog.oldvalue1, "%08ld", (long *)out);
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: oldDate1 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONnewdate2
 *
 * Purpose      :  newDate2
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnewdate2(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3000:
			*((long *)out) = data->crddet.expdate;
			break;
		case NMON_CODE_3400:
		case NMON_CODE_3401:
			sscanf(data->nmonlog.newvalue2, "%08ld", (long *)out);
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: newDate2 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONolddate2
 *
 * Purpose      :  oldDate2
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONolddate2(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3000:
			if (NULL != data->p_old_crddet)
			{
				*((long *)out) = data->p_old_crddet->expdate;
			}
			break;
		case NMON_CODE_3400:
			if (NULL != data->p_old_token)
			{
				*((long *)out) = data->p_old_token->tknexpirydate;
			}
			break;
		case NMON_CODE_3401:
			sscanf(data->nmonlog.oldvalue2, "%08ld", (long *)out);
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: oldDate2 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONnewid1
 *
 * Purpose      :  newId1
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnewid1(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3400:
			slstrncpy_se(out, size, data->nmonlog.newvalue3,
				     strlen(data->nmonlog.newvalue3));
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: newId1 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONoldid1
 *
 * Purpose      :  oldId1 (Previous identification number)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONoldid1(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3400:
			if (NULL != data->p_old_token)
			{
				slstrncpy_se(out, size, data->p_old_token->tknrequestorid,
					     strlen(data->p_old_token->tknrequestorid));
				break;
			}
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: oldId1 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONnewcode1
 *
 * Purpose      :  newCode1
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnewcode1(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	map_tbl_t *map = NULL;
	char *value = NULL;
	char *status;
	char* (*get_default)(char *) = NULL;

	switch (data->nmoncode)
	{
		case NMON_CODE_3102:
			value = data->nmonlog.newvalue2;
			map = map_nmon20status;
			get_default = NMON3102status_default;
			break;
		case NMON_CODE_3400:
			value = data->nmonlog.newvalue4;
			map = map_nmon20tknstatus;
			break;
		case NMON_CODE_3401:
			value = data->nmonlog.newvalue3;
			map = map_nmon20tknstatus;
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: newCode1 set empty", data->nmoncode));
	}
	
	if (NULL != value && NULL != map)
	{
		stp_both(value);
		status = map_table(value, map);
		if (NULL != status)
		{
			slstrcpy_se(out, size, status);
		}
		else if (NULL != get_default)
		{
			status = get_default(value);
			slstrcpy_se(out, size, status);
			DBG_PRINTF((dbg_syswarn, "NMON %04d: newCode1 set default [%s]", data->nmoncode, status));
		}
		else
		{
			DBG_PRINTF((dbg_syserr, "Failed to map status [%s]", value));
			ret = FAIL;
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONoldcode1
 *
 * Purpose      :  oldCode1
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONoldcode1(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	map_tbl_t *map = NULL;
	char *value = NULL;
	char *status;
	char* (*get_default)(char *) = NULL;

	switch (data->nmoncode)
	{
		case NMON_CODE_3102:
			value = data->nmonlog.oldvalue2;
			map = map_nmon20status;
			get_default = NMON3102status_default;
			break;
		case NMON_CODE_3400:
			if (NULL != data->p_old_token)
			{
				value = data->p_old_token->tknstatus;				
			}
			map = map_nmon20tknstatus;
			break;
		case NMON_CODE_3401:
			value = data->nmonlog.oldvalue3;
			map = map_nmon20tknstatus;
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: oldCode1 set empty", data->nmoncode));
	}

	if (NULL != value && NULL != map)
	{
		stp_both(value);
		status = map_table(value, map);
		if (NULL != status)
		{
			slstrcpy_se(out, size, status);
		}
		else if (NULL != get_default)
		{
			status = get_default(value);
			slstrcpy_se(out, size, status);
			DBG_PRINTF((dbg_syswarn, "NMON %04d: oldCode1 set default [%s]", data->nmoncode, status));
		}
		else
		{
			DBG_PRINTF((dbg_syserr, "Failed to map status [%s]", value));
			ret = FAIL;
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONnewcode2
 *
 * Purpose      :  newCode2
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnewcode2(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3400:
			slstrncpy_se(out, size, data->nmonlog.newvalue5,
				     strlen(data->nmonlog.newvalue5));
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: newCode2 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONoldcode2
 *
 * Purpose      :  oldCode2
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONoldcode2(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3400:
			if (NULL != data->p_old_token)
			{
				slstrcpy_se(out, size, data->p_old_token->schemeid);
				break;
			}
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: oldCode2 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONnewcode3
 *
 * Purpose      :  newCode3
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnewcode3(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3400:
			slstrncpy_se(out, size, data->nmonlog.newvalue6,
				     strlen(data->nmonlog.newvalue6));
			break;
		case NMON_CODE_3401:
			slstrncpy_se(out, size, data->nmonlog.newvalue4,
				     strlen(data->nmonlog.newvalue4));
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: newCode3 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONoldcode3
 *
 * Purpose      :  oldCode3
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONoldcode3(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3400:
			if (NULL != data->p_old_token)
			{
				sprintf(out, "%hd",  data->p_old_token->tknasslevel);
			}
			break;
		case NMON_CODE_3401:
			slstrncpy_se(out, size, data->nmonlog.oldvalue4,
				     strlen(data->nmonlog.oldvalue4));
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: oldCode3 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONnewindicator1
 *
 * Purpose      :  newIndicator1
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnewindicator1(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	char *indicator;

	switch (data->nmoncode)
	{
		case NMON_CODE_3000:
			slstrcpy_se(out, size, "I");	/* for Cards */
			break;
		case NMON_CODE_3020:
			slstrcpy_se(out, size, "C");
			break;
		case NMON_CODE_3400:
			stp_both(data->nmonlog.newvalue7);
			indicator = map_table(data->nmonlog.newvalue7, map_tkntype);
			if (NULL != indicator)
			{
				slstrcpy_se(out, size, indicator);
			}
			else
			{
				DBG_PRINTF((dbg_syserr, "Failed to map tkntype [%s]",
					data->nmonlog.newvalue7));
				ret = FAIL;
			}
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: newIndicator1 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONoldindicator1
 *
 * Purpose      :  oldIndicator1
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONoldindicator1(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	char *indicator;

	switch (data->nmoncode)
	{
		case NMON_CODE_3000:
			slstrcpy_se(out, size, "I");	/* for Cards */
			break;
		case NMON_CODE_3020:
			slstrcpy_se(out, size, "C");
			break;
		case NMON_CODE_3400:
			if (NULL != data->p_old_token)
			{
				indicator = map_table(data->p_old_token->tkntype, map_tkntype);
				if (NULL != indicator)
				{
					slstrcpy_se(out, size, indicator);
				}
				else
				{
					DBG_PRINTF((dbg_syserr, "Failed to map tkntype [%s]", 
						data->p_old_token->tkntype));
					ret = FAIL;
				}
				break;
			}
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: oldIndicator1 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONnewindicator2
 *
 * Purpose      :  newIndicator2
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnewindicator2(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	char *indicator;

	switch (data->nmoncode)
	{
		case NMON_CODE_3000:
			slstrcpy_se(out, size, "D");	/* for both Cards and Tokens */
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: newIndicator2 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONoldindicator2
 *
 * Purpose      :  oldIndicator2
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONoldindicator2(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	char *indicator;

	switch (data->nmoncode)
	{
		case NMON_CODE_3000:
			slstrcpy_se(out, size, "D");	/* for both Cards and Tokens */
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: oldIndicator2 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONnewnumericvalue1
 *
 * Purpose      :  newNumericValue1
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONnewnumericvalue1(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3020:
			*((long *)out) = 4; /* PIN length */
			break;
		case NMON_CODE_3400:
			*((long *)out) = data->tokencount + 1;
			break;
		case NMON_CODE_3401:
			*((long *)out) = data->tokencount;
			break;
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: newNumericValue1 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMONoldnumericvalue1
 *
 * Purpose      :  oldNumericValue1
 *
 * Parameters   :  data (in) - Pointer to structure of source data for NMON
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int NMONoldnumericvalue1(NMON_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	switch (data->nmoncode)
	{
		case NMON_CODE_3400:
		case NMON_CODE_3401:
			*((long *)out) = data->tokencount;
			break;
		case NMON_CODE_3020:
			if (LOG_HINT_UPDATE == data->nmonlog.hint[0])
			{
				*((long *)out) = 4; /* PIN length */
				break;
			}
		default:
			DBG_PRINTF((dbg_progdetail, "NMON %04d: oldNumericValue1 set empty", data->nmoncode));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  NMON3102status_default
 *
 * Purpose      :  Get default Falcon Status Code for given CRDSTATUS.statcode 
 *
 * Parameters   :  statcode (in) - Cortex card status (CRDSTATUS.statcode)
 *
 * Returns      :  Falcon Status Code
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate char* NMON3102status_default(char *statcode)
{
static	char status[NMON_PIS_NEWCODE1_BUFFSIZE] = {EOS};
	CRDSTATUS_t crdstatus;
	CRDSTATUS_HASH_t crdstatus_hash;
	
	memset(&crdstatus, 0, sizeof(crdstatus));
	memset(&crdstatus_hash, 0, sizeof(crdstatus_hash));
	
	strcpy(crdstatus_hash.statcode, statcode);
	if (SUCCEED == CRDSTATUSgetbyCRDSTATUS_HASH(&crdstatus, &crdstatus_hash)
	    && MAC_AUTH_APP == crdstatus.actioncode[0])
	{
		strcpy(status, "00"); /* Default 1: Open, non-statused, active */
	}
	else
	{
		strcpy(status, "40"); /* Default 2: Statused, other (blocked) */
	}

	return status;
}

/*------------------------------------------------------------------------
 *
 * Function     :  nmonpis_decrypt_pan
 *
 * Purpose      :  Decrypt an encrypted PAN
 *
 * Parameters   :  enc (in) - Encrypted PAN
 * 		   clr (out) - Clear PAN
 * 		   sizeclr (in) - Size of clear PAN buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int nmonpis_decrypt_pan(char *enc, char *clr, size_t sizeclr)
{
	int ret = SUCCEED;
	char pan_clr[PAN_LEN_MAX] = {EOS};

	memset(pan_clr, 0, sizeof(pan_clr));
#ifndef TESTNOENC
	if (NULL != decryptPanSize(pan_clr, sizeof(pan_clr), enc))
	{
		slstrcpy_se(clr, sizeclr, pan_clr);
	}
	else
#endif
	{
#if defined(TESTTEST) || defined(TESTNOENC)
		slstrcpy_se(clr, sizeclr, enc);
#else
		ret = FAIL;
#endif
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  set_workflow
 *
 * Purpose      :  Set configured value for workflow
 *
 * Parameters   :  workflow (in) - Name of the workflow to be executed by Falcon Fraud Manager
 *
 * Returns      :  void
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxpublic void set_workflow(char *workflow)
{
	slstrcpy_sen(M_workflow, workflow);
}

/*------------------------------------------------------------------------
 *
 * Function     :  set_clientid
 *
 * Purpose      :  Set configured value for clientIdFromHeader
 *
 * Parameters   :  clientid (in) - Unique identifier for the client or subclient
 *
 * Returns      :  void
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxpublic void set_clientid(char *clientid)
{
	slstrcpy_sen(M_clientid, clientid);
}

/*------------------------------------------------------------------------
 *
 * Function     :  nmon_pis_map
 *
 * Purpose      :  Generate NMON_PIS by corresponded data convert table
 *
 * Parameters   :  p_nmonpis (out) - Pointer to NMON_PIS record
 * 		   p_nmondata (in/out) - Pointer to structure of source data for NMON
 * 		   p_convtab (in) - Pointer to convert table
 * 		   dim (in) - Number of elements in convert table
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxpublic int nmon_pis_map(NMON_PIS_t *p_nmonpis, NMON_Data_t *p_nmondata,
			       nmon_pis_cnv_t *p_convtab, size_t dim)
{
	int ret = SUCCEED;
	nmon_pis_cnv_t *p_ct;
	int f;
	char *p;

	for (f = 0, p_ct = p_convtab; SUCCEED == ret && f < (int)dim; ++f, ++p_ct)
	{
		p = ((char *)p_nmonpis) + p_ct->offset;
		if (NULL != p_ct->p_convfn)
		{
			ret = p_ct->p_convfn(p_nmondata, p, p_ct->len);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  nmon_pis_map_nmon20
 *
 * Purpose      :  Generate NMON_PIS using Nonmonetary 2.0 data convert table
 *
 * Parameters   :  p_nmonpis (out) - Pointer to NMON_PIS record
 * 		   p_nmondata (in) - Pointer to structure of source data for NMON
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxpublic int nmon_pis_map_nmon20(NMON_PIS_t *p_nmonpis, NMON_Data_t *p_nmondata)
{
	return nmon_pis_map(p_nmonpis, p_nmondata, M_convtab_NMON20, DIM(M_convtab_NMON20));
}
