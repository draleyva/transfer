/*-----------------------------------------------------------------------
 *
 * File		: mapdelexp.c
 *
 * Author	: Alex Butikov
 *
 * Created	: 07-Dec-2010
 *
 * Purpose	: MAP delivery extract
 *
 * Comments	: 
 *
 * Ident	: @(#) $Id: //ps/cortex/latam/bpd/c/bpd-2.0/src/etc/mapdelexp/mapdelexp.c#6 $
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <assert.h>
#include <ctype.h>
#include <errno.h>

#include <sldbg.h>
#include <sldtm.h>
#include <slclp.h>
#include <slcfp.h>
#include <slntp.h>
#include <slnfb.h>
#include <slstrtok.h>

#include <cortex.h>
#include <cocbf.h>
#include <cocbfdef.h>
#include <cotstates.h>
#include <cocurr.h>
#include <gendbcmd.h>
#include <coclinit.h>
#include <coint.fd.h>
#include <dberr.h>
#include <dbcvtdt.h>
#include <cocat.h>
#include <coevent.h>
#include <coencpan.h>
#include <coencpanfb.h>


#include <dbcdetrh.h>		/* CRDDET	*/
#include <dbadetrh.h>		/* ACCDET 	*/
#include <dbcustrh.h>		/* CUSTDET	*/
#include <dbbrnrh.h>		/* BRANCH	*/
#include <dbcust_xrh.h>		/* CUSTDET_X	*/
#include <dbcrddelivinforh.h>	/* CRDDELIVINFO	*/

#include "dbmapdelexp.h"
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define PROGTAG		"MAPDELEXP"      /* tag name of program          */
#define BASE2EXPEND	"processend"
#define EVMODULE	"if"
#define EVPROGRAM	"mapdelexp"
#define PROCESS_OK	2
#define PROCESS_NOK	3
#define NCPY(d,s)	strncpy(d,s,(sizeof(s)<=sizeof(d)-1)?sizeof(s):sizeof(d)-1)
#define FILL(d,p)	memset(&d, p, sizeof(d))
#define DELIM_CHAR	'|'
#define RECTYPE_HEADER	"00"
#define RECTYPE_DATA	"02"
#define RECTYPE_TRAILER	"99"
#define FILE_TITLE	"MAP_EXTRACT_ENCODING"

#define	CRDTYPE_PRIMARY	"P"
#define	CRDTYPE_ADDIT	"A"
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
typedef struct					  		/* Ln T Desc		*/
{						  		/* -- - --------------- */
	char	entacc[CRDDET_PAN_BUFFSIZE];	  		/* 19 A Card Number	*/
	char	entcli[CUSTDET_CUSTCODE_BUFFSIZE];		/* 16 A CIF ID	        */
	char	entcta[ACCDET_ACCNO_BUFFSIZE];	  		/* 19 A Account Number  */
	char	entdoc[64];			  		/* 20 A Document Number */
	short	entdtip;			  		/*  1 N Document Type	*/
	short	enttip;				  		/*  1 N Card Type	*/
	char	eb0004[ACCDET_TYPECODE_BUFFSIZE]; 		/*  2 N Account Type	*/
	short	enttds;				  		/*  1 N Received Ind.	*/
	char	entnbr[CRDDELIVINFO_PERSON_NAME_BUFFSIZE];	/* 30 A Received Name	*/
	char	entdor[CRDDELIVINFO_DOC_NO_BUFFSIZE];	  	/* 20 A Received DocNo	*/
	short	entinr;				  		/*  1 N Received DocTyp	*/
	char	entusr[CRDDELIVINFO_USR_NAME_BUFFSIZE];		/* 10 A Officer Code	*/
	long	entfde;				  		/*  8 N Date		*/
	long	enthde;				  		/*  6 N Time		*/
	char	enttde[CRDDELIVINFO_USR_TERM_BUFFSIZE];		/* 10 A Terminal Id	*/
	short	additional;			  		/*  1 N CRDDET.additionalno */
	char	brncode[BRANCH_BRNCODE_BUFFSIZE]; 		/*  3 N Branch code	*/
} output_rec_t;
	
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
ctxprivate long	M_ctxdate = 0;
ctxprivate long	M_sysdate = 0;			/* Current sysdate for header */
ctxprivate char 	M_outfile[CTX_FILENAME_MAX] = "";
ctxprivate	char	M_dbgfile[CTX_FILENAME_MAX] = "";
ctxprivate	int	M_dbglev = dbg_syswarn;
ctxprivate int	M_dbgbuf = 0;
ctxprivate char 	M_subsect[32] = "";
ctxprivate FILE	*M_fp = NULL;
ctxprivate long	M_rec_cnt = 0;
ctxprivate long	M_rec_cnt_fail = 0;
ctxprivate ctxbool	M_ignoreerr = FALSE;
ctxprivate ctxbool	M_delempty = FALSE;
ctxprivate ctxbool	M_mapheadfoot = FALSE;
/*---------------------------Prototypes---------------------------------*/
ctxprivate int	process_record(void);
ctxprivate int	process(void);
ctxprivate int	raise_event( int code );
ctxprivate int	write_header(void);
ctxprivate int	write_trailer(void);
ctxprivate char	*format_comma_list(char *input_str);
ctxprivate long	custdate2mmddyyyy(long yyyymmdd);


/*--------------------------------------------------------------------------
 *
 * Function		: write_header
 *
 * Purpose		: Print file header into output file
 *
 * Parameters		: 
 *
 * Returns		: SUCCEED/FAIL
 *
 * Comments		:
 *
 *------------------------------------------------------------------------*/
ctxprivate int write_header(void)
{
	char	*thisfn = "write_header";
	int	ret = SUCCEED;
	long	localdate = local_date();
	long	localtime = local_time();

	DBG_ENTRY(thisfn);

	fprintf(M_fp, "%2.2s%20.20s%08ld%08ld%08ld\n",
			RECTYPE_HEADER, FILE_TITLE, custdate2mmddyyyy(M_sysdate),
			custdate2mmddyyyy(localdate), localtime);
	
	DBG_EXIT(thisfn);

	return ret;
}

/*--------------------------------------------------------------------------
 *
 * Function		: write_trailer
 *
 * Purpose		: Print file trailer into output file
 *
 * Parameters		: 
 *
 * Returns		: SUCCEED/FAIL
 *
 * Comments		:
 *
 *------------------------------------------------------------------------*/
ctxprivate int write_trailer(void)
{
	char	*thisfn = "write_trailer";
	int	ret = SUCCEED;

	DBG_ENTRY(thisfn);

	fprintf(M_fp, "%2.2s%20.20s%08ld\n",
			RECTYPE_TRAILER, FILE_TITLE, M_rec_cnt);
	
	DBG_EXIT(thisfn);

	return ret;
}

/*--------------------------------------------------------------------------
 *
 * Function		: process_record
 *
 * Purpose		: Main one record parsing function
 *
 * Parameters		: 
 *
 * Returns		: 
 *
 * Comments		:
 *
 *------------------------------------------------------------------------*/
ctxprivate int process_record(void)
{
	char			*thisfn = "process_record";
	int			ret = SUCCEED;
	char			buf[4096] = "";
	CRDDELIVINFO_t		crddelivinfo;
	CRDDET_t		crddet;
	CRDDET_PK_t		crddet_pk;
	ACCDET_t		accdet;
	ACCDET_PK_t		accdet_pk;
	CUSTDET_t		custdet;
	CUSTDET_PK_t		custdet_pk;
	BRANCH_t		branch;
	BRANCH_PK_t		branch_pk;
	FK_CUSTDET_X_ID_CUSTDET_t custdet_x_k;
	CUSTDET_X_t		custdet_x;
	output_rec_t		rec;
	char			clr_pan[CRDDET_PAN_BUFFSIZE];
	short			tmp;


	DBG_ENTRY(thisfn);
	
	FILL(crddelivinfo, 0); FILL(crddet, 0); FILL(accdet, 0);
	FILL(custdet, 0); FILL(rec, 0); FILL(custdet_x, 0);
	
	ret = dbmapdelexp_nxtscan(&crddelivinfo);

	/* Get all data */
	if ( SUCCEED == ret )
	{
		crddet_pk.id = crddelivinfo.crddet_id;
		DBG_PRINTF((dbg_progdetail, "Looking for crddet with id [%ld]", crddet_pk.id));
		
		if ( SUCCEED != (ret = CRDDETgetbyCRDDET_PK(&crddet, &crddet_pk)) )
		{	
			DBG_PRINTF((dbg_fatal, "Error: Cannot fetch crddet record with id [%ld]", crddet_pk.id));
			ret = FAIL;
		}	
	}

	if ( SUCCEED == ret )
	{
		accdet_pk.id = crddet.accdet_id;
		DBG_PRINTF((dbg_progdetail, "Looking for accdet with id [%ld]", accdet_pk.id));
		
		if ( SUCCEED != (ret = ACCDETgetbyACCDET_PK(&accdet, &accdet_pk)) )
		{	
			DBG_PRINTF((dbg_fatal, "Error: Cannot fetch accdet record with id [%ld]", accdet_pk.id));
			ret = FAIL;
		}	
	}
	
	if ( SUCCEED == ret )
	{
		custdet_pk.id = crddet.custdet_id;
		DBG_PRINTF((dbg_progdetail, "Looking for custdet with id [%ld]", custdet_pk.id));
		
		if ( SUCCEED != (ret = CUSTDETgetbyCUSTDET_PK(&custdet, &custdet_pk)) )
		{	
			DBG_PRINTF((dbg_fatal, "Error: Cannot fetch custdet record with id [%ld]", custdet_pk.id));
			ret = FAIL;
		}	
	}

	if ( SUCCEED == ret )
	{
		branch_pk.id = crddet.branch_id;
		DBG_PRINTF((dbg_progdetail, "Looking for branch with id [%ld]", branch_pk.id));
		
		if ( SUCCEED != (ret = BRANCHgetbyBRANCH_PK_cache(&branch, &branch_pk)) )
		{	
			DBG_PRINTF((dbg_fatal, "Error: Cannot fetch branch record with id [%ld]", branch_pk.id));
			ret = FAIL;
		}	
	}

	if ( SUCCEED == ret )
        {
		custdet_x_k.custdet_id = custdet.id;
		DBG_PRINTF((dbg_progdetail, "Looking for custdet_x with custdet_id [%ld]", custdet_x_k.custdet_id));

		if ( SUCCEED != (ret = CUSTDET_XgetbyFK_CUSTDET_X_ID_CUSTDET(&custdet_x, &custdet_x_k)) )
		{
			DBG_PRINTF((dbg_fatal, "Error: Cannot fetch custdet_x record with custdet_id [%ld]", custdet_x_k.custdet_id));
			/* Ignore error we set custdet_x to zeroes above */
                        ret = SUCCEED;
		}
	}

	if (SUCCEED == ret && NULL == enc_decryptPan(clr_pan, sizeof(clr_pan), crddet.pan))
	{
		ret = FAIL;
		DBG_PRINTF((dbg_syserr, "Decrypting pan failed"));
	}

	/*
	 * We have to put document type (1=natID, 2=taxID(RNC), 3=passport) and Doc
	 * number to a file. Field in our DB used to store data:
	 *	DOCTYPE		CUSTDET_X.usrdata1
	 *	NAT_ID		CUSTDET.national_id
	 *	TAX_ID		CUSTDET_X.usrdata4
	 *	PASSPORT_NR	CUSTDET_X.usrdata3
	 *
	 * Map ICBS doc types to MAP doc types.
	 * ICBS:
	 * Value    Description
	 * 0        Cedula or National ID
	 * 1        Passport ID
	 * 2        Tax ID
	 * 3        Tax ID
	 *
	 * MAP:
	 * Value    Description
	 * 1        Cedula or National ID
	 * 2        Tax ID
	 * 3        Passport ID
	 */

	/* Parse and prepare data */
	if ( SUCCEED == ret )
	{
		NCPY(rec.entacc, clr_pan);
		NCPY(rec.entcli, custdet.custcode);
		NCPY(rec.entcta, accdet.accno);
		
		tmp = atoi(custdet_x.usrdata1);
		if (0 == tmp)
		{
			rec.entdtip = 1;
			NCPY(rec.entdoc, custdet.national_id);
		}	
		else if (2 == tmp || 3 == tmp)
		{
			rec.entdtip = 2;
			NCPY(rec.entdoc, custdet_x.usrdata4);
		}
		else if (1 == tmp)
		{
			rec.entdtip = 3;
			NCPY(rec.entdoc, custdet_x.usrdata3);
		}
		
		rec.enttip = 4;
		NCPY(rec.eb0004, accdet.typecode);
		rec.enttds = crddelivinfo.person_type;
		NCPY(rec.entnbr, crddelivinfo.person_name);
		NCPY(rec.entdor, crddelivinfo.doc_no);
		rec.entinr = crddelivinfo.doc_type;
		NCPY(rec.entusr, crddelivinfo.usr_name);
		rec.entfde = crddelivinfo.deliv_date;
		rec.enthde = crddelivinfo.deliv_time;
		NCPY(rec.enttde, crddelivinfo.usr_term);
		rec.additional = crddet.additionalno;
		NCPY(rec.brncode, branch.brncode);


		DBG_PRINTF((dbg_progdetail, "Preparing record..."));
		DBG_PRINTF((dbg_progdetail, "    entacc  : [%s]",  rec.entacc));
		DBG_PRINTF((dbg_progdetail, "    entcli  : [%s]",  rec.entcli));
		DBG_PRINTF((dbg_progdetail, "    entcta  : [%s]",  rec.entcta));
		DBG_PRINTF((dbg_progdetail, "    entdoc  : [%s]",  rec.entdoc));
		DBG_PRINTF((dbg_progdetail, "    additional: [%hd]", rec.additional));
		DBG_PRINTF((dbg_progdetail, "    branch  : [%s]",  rec.brncode));
		DBG_PRINTF((dbg_progdetail, "    entdtip : [%hd]", rec.entdtip));
		DBG_PRINTF((dbg_progdetail, "    enttip  : [%hd]", rec.enttip));
		DBG_PRINTF((dbg_progdetail, "    eb0004  : [%s]",  rec.eb0004));
		DBG_PRINTF((dbg_progdetail, "    enttds  : [%hd]", rec.enttds));
		DBG_PRINTF((dbg_progdetail, "    entnbr  : [%s]",  rec.entnbr));
		DBG_PRINTF((dbg_progdetail, "    entdor  : [%s]",  rec.entdor));
		DBG_PRINTF((dbg_progdetail, "    entinr  : [%hd]", rec.entinr));
		DBG_PRINTF((dbg_progdetail, "    entusr  : [%s]",  rec.entusr));
		DBG_PRINTF((dbg_progdetail, "    entfde  : [%ld]", rec.entfde));
		DBG_PRINTF((dbg_progdetail, "    enthde  : [%ld]", rec.enthde));
		DBG_PRINTF((dbg_progdetail, "    enttde  : [%s]",  rec.enttde));
	}

	/* Print data to file */
	if ( SUCCEED == ret )
	{
		sprintf( buf, 
			"%-2.2s"     /* IG 03Mar2011 Record Type */
			"%-19.19s"   /* entacc  */
			"%-16.16s"   /* entcli  */
			"%-19.19s"   /* entcta  */
			"%-20.20s"   /* entdoc  */
			"%-1.1hd"    /* entdtip */
			"%-1.1s"     /* IG 03Mar2011 P-primary, A-additional */
			"%-3.3s"     /* IG 03Mar2011 Branch code */
			"%-1.1hd"    /* enttip  */
			"%-2.2s"     /* eb0004  */
			"%-1.1hd"    /* enttds  */
			"%-30.30s"   /* entnbr  */
			"%-20.20s"   /* entdor  */
			"%-1.1hd"    /* entinr  */
			"%-10.10s"   /* entusr  */
			"%-8.8ld"    /* entfde  */
			"%-6.6ld"    /* enthde  */
			"%-10.10s\n",  /* enttde  */
			RECTYPE_DATA,
			rec.entacc,
			rec.entcli,
			rec.entcta,
			rec.entdoc,
			rec.entdtip,
			0 == rec.additional ? CRDTYPE_PRIMARY : CRDTYPE_ADDIT,
			rec.brncode,
			rec.enttip,
			rec.eb0004,
			rec.enttds,
			rec.entnbr,
			rec.entdor,
			rec.entinr,
			rec.entusr,
			rec.entfde,
			rec.enthde,
			rec.enttde
		);

		DBG_PRINTF((dbg_progdetail, "Output buffer : \n[%s]", buf));

		fprintf(M_fp, buf);
	}


	DBG_EXIT(thisfn);
	
	return ret;
}

/*--------------------------------------------------------------------------
 *
 * Function		: process
 *
 * Purpose		: 
 *
 * Parameters		: 
 *
 * Returns		: SUCCEED/FAIL
 *
 * Comments		:
 *
 *------------------------------------------------------------------------*/
ctxprivate int	process(void)
{
	char	*thisfn = "process";
	int 	ret = SUCCEED;

	DBG_ENTRY(thisfn);

	ret = dbmapdelexp_bgnscan(M_ctxdate);

	while( SUCCEED == ret )
	{
		ret = process_record();

		if ( SUCCEED != ret && SQE_EOFERR != ret )
		{
			M_rec_cnt_fail++;
			DBG_PRINTF((dbg_fatal, "Error: Export of record failed"));

			if ( M_ignoreerr )
			{
				ret = SUCCEED;
				DBG_PRINTF((dbg_fatal, "IGNOREERR is set, so continue..."));
			}
		}
		else if ( SUCCEED == ret )
		{
			M_rec_cnt++;
			DBG_PRINTF((dbg_fatal, "Record exported"));
		}
	}
	
	if (ret == SQE_EOFERR )
	{
		ret = SUCCEED;
	}

	(void)dbmapdelexp_endscan();
	
	DBG_EXIT(thisfn);

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function		:  main
 *
 * Purpose		:	  
 *
 * Parameters		:
 *
 * Returns		:
 *
 * Comments		:
 *
 *----------------------------------------------------------------------*/
int	main( int argc, char ** argv )
{
	int	ret = SUCCEED;
	ctxprivate FILE *fp;
	ctxprivate char tmpf[CTX_FILENAME_MAX];
	
	ctxprivate clp_parm clp[] =
	{
		{'d', parm_long,	1,  			TRUE,  	&M_ctxdate},
		{'o', parm_string,	sizeof(tmpf),		TRUE,	tmpf      },
		{'s', parm_string,	sizeof(M_subsect),	FALSE,	M_subsect },
		{0}
	};
		
	ctxprivate cfp_parm cfp[] =
	{
                {"DEBUG",      parm_int,      0,		 FALSE, (void *)&M_dbglev,     0},
                {"DBGBUF",     parm_int,      0,		 FALSE, (void *)&M_dbgbuf,     0},
                {"DBGNAME",    parm_string, sizeof(M_dbgfile),	 FALSE, (void *)&M_dbgfile,    0},
		{"IGNOREERR",  parm_truebool, 1,		 FALSE,	        &M_ignoreerr,  0},
		{"DELEMPTY",   parm_truebool, 1,		 FALSE,	        &M_delempty,   0},
		{"MAPHEADFOOT",parm_truebool, 1,		 FALSE,	        &M_mapheadfoot,0},
		{0}
    };

	if( SUCCEED != ( ret = clp_parse(argc, argv, clp) ) )
	{
	    fprintf( stderr,
			"\n Card delivery extract program. Extracts to MAP host information about all "
			"\n activated cards during specified calendar or system date based on specified filter."
			"\n\n Usage:\t%s \n\n"
			"\t\t-o outfile      Name of outgoing file\n"
			"\t\t-d date         Date to process\n"
			"\t\t[-s subsection] Ctxcfg subsection\n\n",
			argv[0] );
		
		return( FAIL );
	}

	DBG_SETLEV( M_dbglev );
	DBG_SETBUF( M_dbgbuf );
	DBG_SETNAME( PROGTAG );
	if ( EOS == M_dbgfile[0] )
	{
		sprintf( M_dbgfile, "%s/%s", getenv("CTXTMP"), PROGTAG );
	}
	DBG_SETFILE( M_dbgfile );

	if ( '/' == tmpf[0] )
		sprintf(M_outfile, "%s", tmpf);
	else
		sprintf(M_outfile, "%s/%s", getenv("CTXOUT"), tmpf);

	if (SUCCEED == ret)
	{
		fp = cfp_open();
		if (!fp)
		{
			DBG_PRINTF((dbg_syswarn, "Error: Could not open config file"));
			ret = FAIL;
		}
		else if (SUCCEED != cfp_parse(fp, cfp, PROGTAG, M_subsect))
		{
			DBG_PRINTF((dbg_syswarn, 
				"Error: Could not find config file section [%s/%s]",	PROGTAG));
			ret = FAIL;
		}
		if( SUCCEED != ret )
		{
			return( ret );
		}
	}
	

	DBG_PRINTF((dbg_fatal,
		"\n\nProgram starting with following options:\n"
		"\tDate : [%ld]\n"
		"\tOutput file : [%s]\n"
		"\tWill%s continue on fail\n"
		"\tWill%s delete file, if empty\n",
		M_ctxdate,
		M_outfile,
		M_ignoreerr?"":" not",
		M_delempty?"":" not"));


	if (SUCCEED == ret)
	{
		ev_init(EVMODULE,EVPROGRAM,NULL);

		ret = clt_basic_init("if", "MAPDELEXP");

		if (SUCCEED != ret)
		{
			DBG_PRINTF((dbg_fatal, "Error: Cannot init Tuxedo"));
			return(ret);
		}
	}

	if( SUCCEED == ret )
	{
		if( SUCCEED != sql_open(getenv("DBNAME") ) )
		{
			DBG_PRINTF((dbg_fatal, "Error: Cannot open database connection to [%s]", getenv("DBNAME")));
			ret = FAIL;
		}
		else
		{
			DBG_PRINTF((dbg_progdetail, "Opened database connection to [%s]", getenv("DBNAME")));
		}
	}

	if( SUCCEED == ret )
	{
		if( NULL == ( M_fp = fopen( M_outfile, "w" ) ) )
		{
			ret = FAIL;
			DBG_PRINTF((dbg_fatal,"Error: Cannot open file [%s] (errno: %s)", M_outfile, errno));
		}
	}

	if( SUCCEED == ret )
	{
		M_sysdate = cbf_get_sysdatefb();
	}

	if( SUCCEED == ret && M_mapheadfoot )
	{
		ret = write_header();
	}

	if( SUCCEED == ret )
	{
		ret = process();
	}

	if( SUCCEED == ret && M_mapheadfoot )
	{
		ret = write_trailer();
	}

	fclose( M_fp );

	if ( 0 == M_rec_cnt && M_delempty )
	{
		DBG_PRINTF((dbg_syswarn, "No records exported, deleting output file "));
		unlink(M_outfile);
	}

	if ( SUCCEED == ret )
	{
		raise_event(PROCESS_OK);
		DBG_PRINTF((dbg_syswarn,"Program Completed - "
				"[%ld] records exported, [%ld] records failed\n\n\n",
				M_rec_cnt, M_rec_cnt_fail));
	}
	else
	{
		raise_event(PROCESS_NOK);
		DBG_PRINTF((dbg_fatal,"Program Failed\n\n\n"));
	}

	return( ret );
}


/*----------------------------------------------------------------------
*
* Function     :  raise_event
*
* Purpose      :  Raise a process end event to announce problems
*
* Parameters   :  code - Error code
*
* Returns      :  SUCCEED - event raised
*                 FAIL    - could not raise event
*
* Notes        :  @1,2
*                 means grab message from message catalogue,
*                 msgset=1 and msgno=2.
*
*                 Message catalogue is:-
*                 base/common/src/msg/C/cocat.md  (set 4)
*
*------------------------------------------------------------------*/
ctxprivate int raise_event( int code )
{
	char    data[1024];
	int     msgset = 4;
	int     msgno  = PROCESS_END_EVENTS + code;

	sprintf(data,"%s~@%d,%d", "mapdelexp", msgset, msgno );

	DBG_PRINTF((dbg_progdetail,"Raising event [%s], data [%s]",
						BASE2EXPEND, data));
	return ev_call(BASE2EXPEND, data);
}

/*------------------------------------------------------------------------
 *
 * Function     :  format_comma_list
 *
 * Purpose      :
 *
 * Parameters   :
 *
 * Returns      :
 *
 * Comments     :  IG. 15Apr09. Defining string here and returning to caller
 *                 is not correct. Defined as static for now.
 *
 *----------------------------------------------------------------------*/
ctxprivate char *format_comma_list(char *input_str)
{
static  char fmtd_list[100] = "";
	char *token;

	fmtd_list[0] = 0;

	token = strtok(input_str, ",");
	do
	{
		strcat(fmtd_list, "'");
		strcat(fmtd_list, token);
		strcat(fmtd_list, "'");

		if (NULL != (token = strtok(NULL, ",")))
		{
			strcat(fmtd_list, ",");
		}
	} while (token != NULL);

	return (fmtd_list);
}

/*-----------------------------------------------------------------------
 *
 * Function     :  custdate2mmddyyyy
 *
 * Purpose      :  Convert date in format YYYYMMDD (long) to
 *                 mmddyyyy (long)
 *
 * Parameters   :  yyyymmdd - (long - input date)
 *
 * Returns      :  date in MMDDYYYY format (as long)
 *
 *---------------------------------------------------------------------*/
ctxprivate long custdate2mmddyyyy(long yyyymmdd)
{
        long dd,mm,yyyy;

        dd = yyyymmdd%100;
        mm = (yyyymmdd/100)%100;
        yyyy = yyyymmdd/10000;

        return mm*1000000 + dd*10000 + yyyy;
}

