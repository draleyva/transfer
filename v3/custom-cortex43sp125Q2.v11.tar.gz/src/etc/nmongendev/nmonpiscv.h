/*-----------------------------------------------------------------------
 * 
 * File		: nmonpiscv.h
 * 
 * Author	: Ruslans Vasiljevs
 * 
 * Created	: 12/08/2022
 *
 * Purpose	: NMON_PIS data conversion mapping
 * 
 * Comments	: 
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
 *-----------------------------------------------------------------------*/

#ifndef __NMONPISCV_H
#define __NMONPISCV_H
/*---------------------------Includes-----------------------------------*/
#include <portable.h>

#include <dbnmonlogrh.h>
#include <dbcdetrh.h>
#include <dbadetrh.h>
#include <dbcustrh.h>
#include <dbtokenrh.h>
#include <dbnmonpisrh.h>

#include <bpddbtkndeviceprovrh.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define NMON_CODE_0003	3	/* Change PAN profile		*/
#define NMON_CODE_3000	3000	/* Issue card			*/
#define NMON_CODE_3020	3020	/* Change PIN info		*/
#define NMON_CODE_3100	3100	/* Change cardholder location	*/
#define NMON_CODE_3102	3102	/* Change PAN status		*/
#define NMON_CODE_3400	3400	/* Token provisioning		*/
#define NMON_CODE_3401	3401	/* Token Maintenance		*/

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
typedef struct NMON_Data
{
    int			nmoncode;
    char		*timestamp;
    NMON_LOG_t		nmonlog;
	BPDTKNDEVICEPROV_t	bpdtkndeviceprov;
    CRDDET_t		crddet;
    ACCDET_t		accdet;
    CUSTDET_t		custdet;
    CRDDET_t		*p_old_crddet;
    TOKEN_t		token;
    TOKEN_t		*p_old_token;
    long		tokencount;
} NMON_Data_t;

typedef struct
{
    long	offset;		/* Offset in NMON_PIS		*/
    size_t	len;		/* Length of field in NMON_PIS	*/
    int		(*p_convfn)(NMON_Data_t *, char *, size_t);
} nmon_pis_cnv_t;

/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
ctxpublic void set_workflow(char *workflow);
ctxpublic void set_clientid(char *clientid);

ctxpublic int nmon_pis_map(NMON_PIS_t *p_nmonpis, NMON_Data_t *p_nmondata, nmon_pis_cnv_t *p_convtab, size_t dim);
ctxpublic int nmon_pis_map_nmon20(NMON_PIS_t *p_nmonpis, NMON_Data_t *p_nmondata);

#endif /* __NMONPISCV_H */
