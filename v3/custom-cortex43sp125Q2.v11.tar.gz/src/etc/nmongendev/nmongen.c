/*-----------------------------------------------------------------------
 * 
 * File		: nmongen.c 
 * 
 * Author	: Ruslans Vasiljevs - Raul Torres
 * 
 * Created	: 12/08/2022
 *
 * Purpose	: Process NMON_LOG records and generate NMON_PIS data
 * 
 * Comments	: 
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
 *-----------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>

#include <cortex.h>
#include <tknfdef.h>

#include <sldbg.h>
#include <slcfp.h>
#include <slclp.h>
#include <slstring.h>
#include <sldtm.h>
#include <slstrip.h>

#include <dbnmonpisrh.h>
#include <dbcdetrh.h>
#include <dbadetrh.h>
#include <dbcustrh.h>
#include <dbtokenrh.h>
#include <dbnmonlogrh.h>
#include <dbnmonlogrx.h>
#include <dbcdetcrx.h>
#include <dbtokenrx.h>
#include <crdcustjo.h>
#include <dberr.h>

#include <nmonpiscv.h>
#include "nmonpiscv.h"

#include <bpddbtkndeviceprovrh.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define TAGNAME	"NMONGEN"
#define EXCLUDE_STATUS_SIZE	65

#define FALCON_DEFAULT_WORKFLOW	"DEBIT"
#define FALCON_DEFAULT_CLIENTID	"BPDDB"

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/* Comma separated list of card statuses for which card expand is not needed */
ctxprivate char	M_exclcrdstat[EXCLUDE_STATUS_SIZE] = CRDSTAT_UNISSUED;
/* Comma separated list of excluded TOKEN.tknstatus */
ctxprivate char	M_excltknstat[EXCLUDE_STATUS_SIZE] = {TKNSTATUS_INPROG, EOS};
/* Name of the workflow to be executed by Falcon Fraud Manager */
ctxprivate char	M_workflow[16+1] = FALCON_DEFAULT_WORKFLOW;
/* Unique identifier for the client or subclient */
ctxprivate char	M_clientid[16+1] = FALCON_DEFAULT_CLIENTID;

/*---------------------------Prototypes---------------------------------*/
ctxprivate int	init(int argc, char **argv);
ctxprivate int	uninit(void);
ctxprivate int	nmongen_process(void);
ctxprivate int	process_nmon3000(NMON_Data_t *p_nmondata);
ctxprivate int	process_nmon3020(NMON_Data_t *p_nmondata);
ctxprivate int	process_nmon3100(NMON_Data_t *p_nmondata);
ctxprivate int	process_nmon3102(NMON_Data_t *p_nmondata);
ctxprivate int	process_nmon3400(NMON_Data_t *p_nmondata);
ctxprivate int	process_nmon3401(NMON_Data_t *p_nmondata);
ctxprivate int	geninsert_nmonpis(NMON_Data_t *p_nmondata);
ctxprivate int	get_cardinfo(long crddet_id, CRDDET_t *p_crddet, CUSTDET_t *p_custdet, ACCDET_t *p_accdet);
ctxprivate ctxbool exclstatus_check(const char *status, const char *exclstats);
ctxprivate void sigdisp(int sig);

ctxprivate int	geninsert_nmonpis_3400(NMON_Data_t *p_nmondata);

/*------------------------------------------------------------------------
 *
 * Function     :  main
 *
 * Purpose      :  Start point of program execution
 *
 * Parameters   :  argc -> number of arguments passed on the command line
 *		   argv -> command line arguments in string form.
 *
 * Returns      :  program exit state (0 = normal termination)
 *
 * Comments     :
 *
 *----------------------------------------------------------------------*/
ctxpublic int	main( int argc, char **argv )
{
	int ret;

	ret = init( argc, argv );

	if (SUCCEED != ret)
	{
		fprintf(stderr,"failed during init\n");
	}

	if( SUCCEED != (ret = sql_open(NULL)) )
	{
		DBG_PRINTF((dbg_syserr, "Failed to open database"));
	}
	else if(SUCCEED != (ret = sql_begin()) )
	{
		DBG_PRINTF((dbg_syserr, "Failed to begin SQL"));
	}

	if (SUCCEED == ret)
	{
		ret = nmongen_process();
	}

	if( SUCCEED == ret )
	{
		DBG_PRINTF((dbg_progdetail, "Commit..."));
		ret = sql_commit();
	}
	else
	{
		DBG_PRINTF((dbg_progdetail, "Abort..."));
		sql_abort();
	}

	uninit();

	DBG_PRINTF((dbg_progdetail, "Finished - %s",
		(SUCCEED==ret) ? "OK" : "ERROR"));

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  init
 *
 * Purpose	:  Initialisation
 *
 * Parameters	:  argc, argv
 *
 * Returns	:  SUCCEED - initialized
 *		   FAIL - error
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	init( int argc, char **argv )
{
	int ret = SUCCEED;
static	ctxbool help = FALSE;
	FILE *fp = NULL;

static	clp_parm clp[]=
	{
		{'h', parm_truebool, sizeof(help), FALSE, &help},
		{0}
	};
static	cfp_parm cfp[]=
	{
		{"CLIENTID",          parm_string, sizeof(M_clientid),	  FALSE, M_clientid,   0},
		{"EXCLUDE_CRDSTATUS", parm_string, sizeof(M_exclcrdstat), FALSE, M_exclcrdstat,0},
		{"EXCLUDE_TKNSTATUS", parm_string, sizeof(M_excltknstat), FALSE, M_excltknstat,0},
		{0}
	};

	static	cfp_parm cfp_falcon2[] =
	{
		{"WORKFLOW",	parm_string, sizeof(M_workflow),	FALSE,	M_workflow,	0},
		{0}
	};

	ret = clp_parse(argc, argv, clp);

	if (SUCCEED != ret || help)
	{
		fprintf( stderr,
			 "Usage:\t%s (does not require any command line options)\n",
			 argv[0] );
		exit(1);
	}

	/* handle signals */
	signal( SIGTERM, sigdisp );
	signal( SIGQUIT, sigdisp );
	signal( SIGINT,  sigdisp );
	signal( SIGALRM, sigdisp );
	signal( SIGSEGV, sigdisp );

	fp = cfp_open();
	if (fp)
	{
		if( SUCCEED != (ret=cfp_parse(fp, cfp, TAGNAME, NULL)) )
		{
			fprintf(stderr, "Failed to parse configuration file\n");
		}
		else if ( SUCCEED != (ret=cfp_parse_nodebug(fp, cfp_falcon2, "FALCON2", NULL)) )
		{
			DBG_PRINTF((dbg_syserr, "cfp_parse_nodebug failed [%s] (%s)",
				"FALCON2", cfp_errparm()));
		}
		fclose(fp);
	}
	else
	{
		fprintf(stderr, "cfp_open failed\n");
		ret = FAIL;
	}

	if (SUCCEED == ret)
	{
		DBG_SETNAME(TAGNAME);

		DBG_PRINTF((dbg_progdetail, "Configuration :"));
		DBG_PRINTF((dbg_progdetail, "WORKFLOW: [%s]", M_workflow));
		DBG_PRINTF((dbg_progdetail, "CLIENTID: [%s]", M_clientid));
		DBG_PRINTF((dbg_progdetail, "EXCLUDE_CRDSTATUS: [%s]", M_exclcrdstat));
		DBG_PRINTF((dbg_progdetail, "EXCLUDE_TKNSTATUS: [%s]", M_excltknstat));
	}

	set_workflow(M_workflow);
	set_clientid(M_clientid);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  nmongen_process
 *
 * Purpose      :  Read all records from NMON_LOG table and for each of
 * 		   the tables+keydata perform reverse lookup to CRDDET.id 
 * 		   then generate NMON20 data and perform insert into NMON_PIS
 *
 * Parameters   :  
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	nmongen_process()
{
	int ret = SUCCEED;
	char *thisfn = "nmongen_process";

	NMON_Data_t nmondata;

	DBG_ENTRY(thisfn);

	ret = dbnmonlog_begin_scan();
	while (SUCCEED == ret)
	{
		memset(&nmondata, 0, sizeof(nmondata));
		ret = dbnmonlog_get_next(&nmondata.nmonlog);
		if (SUCCEED == ret)
		{
			sscanf(nmondata.nmonlog.nmoncode, "%d", &nmondata.nmoncode);
			
			switch (nmondata.nmoncode)
			{
				case NMON_CODE_0003:
				case NMON_CODE_3000:
					ret = process_nmon3000(&nmondata);
					if (SUCCEED == ret && NMON_CODE_3000 == nmondata.nmoncode 
					    && !exclstatus_check(nmondata.crddet.statcode, M_exclcrdstat))
					{
						/* Produce NMON 0003 record */
						nmondata.nmoncode = NMON_CODE_0003;
						ret = geninsert_nmonpis(&nmondata);
					}
					break;
				case NMON_CODE_3020:
					ret = process_nmon3020(&nmondata);
					break;
				case NMON_CODE_3100:
					ret = process_nmon3100(&nmondata);
					break;
				case NMON_CODE_3102:
					ret = process_nmon3102(&nmondata);
					break;
				case NMON_CODE_3400:
					if (strcmp(nmondata.nmonlog.tablename, "TOKEN")==0)
						DBG_PRINTF((dbg_progdetail, "nmoncode 3400 and tablename TOKEN -> ignore"));
					else
					{
						DBG_PRINTF((dbg_progdetail, "nmoncode 3400 and tablename <> TOKEN -> will process"));
						ret = process_nmon3400(&nmondata);
					}
					break;
				case NMON_CODE_3401:
					if (strcmp(nmondata.nmonlog.tablename, "TOKEN")==0)
						DBG_PRINTF((dbg_progdetail, "nmoncode 3401 and tablename TOKEN -> ignore"));
					else
					{
						DBG_PRINTF((dbg_progdetail, "nmoncode 3401 and tablename <> TOKEN -> will process"));
						ret = process_nmon3401(&nmondata);
					}
					break;
				default:
					DBG_PRINTF((dbg_syswarn, "Unknown NMON code: %04d", nmondata.nmoncode));
			}

			if (SUCCEED == ret)
			{
				NMON_LOGdelete(&nmondata.nmonlog);
			}
		}
		else if (SQE_EOFERR != ret)
		{
			DBG_PRINTF((dbg_syserr, "Failed to fetch from PIS12_LOG"));
		}
	}
	if (SQE_EOFERR == ret)
	{
		DBG_PRINTF((dbg_proginfo, "No more records"));
		ret = SUCCEED;
	}
	dbnmonlog_close_scan();

	DBG_EXIT(thisfn);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  process_nmon3000
 *
 * Purpose      :  Processing of NMON 3000
 *
 * Parameters   :  p_nmondata - Pointer to structure of source data for NMON
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	process_nmon3000(NMON_Data_t *p_nmondata)
{
	int ret = SUCCEED;
	char *thisfn = "process_nmon3000";

	long crddet_id;
static	CRDDET_t crddet_old;

	DBG_ENTRY(thisfn);

	memset(&crddet_old, 0, sizeof(crddet_old));

	sscanf(p_nmondata->nmonlog.keydata, "%ld", &crddet_id);
	ret = get_cardinfo(crddet_id,
			   &p_nmondata->crddet,
			   &p_nmondata->custdet,
			   &p_nmondata->accdet);

	if (SUCCEED == ret && exclstatus_check(p_nmondata->crddet.statcode, M_exclcrdstat))
	{
		goto out;	
	}
	
	if (SUCCEED == ret)
	{
		ret = dbcrddet_getold(&crddet_old, p_nmondata->crddet.accdet_id, p_nmondata->crddet.expdate);
		if (SUCCEED == ret)
		{
			p_nmondata->p_old_crddet = &crddet_old;
		}
		else if (SQE_EOFERR == ret)
		{
			ret = SUCCEED;
		}
		else
		{
			DBG_PRINTF((dbg_syserr, "Failed to get old CRDDET by "
				"accdet_id=%ld, expdate=%ld from DB",
				p_nmondata->crddet.accdet_id, p_nmondata->crddet.expdate));
		}
	}

	if (SUCCEED == ret)
	{
		ret = geninsert_nmonpis(p_nmondata);		
	}
	
out:

	DBG_EXIT(thisfn);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  process_nmon3020
 *
 * Purpose      :  Processing of NMON 3020
 *
 * Parameters   :  p_nmondata - Pointer to structure of source data for NMON
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	process_nmon3020(NMON_Data_t *p_nmondata)
{
	int ret = SUCCEED;
	char *thisfn = "process_nmon3020";

	long	crddet_id;
	
	DBG_ENTRY(thisfn);

	sscanf(p_nmondata->nmonlog.keydata, "%ld", &crddet_id);
	ret = get_cardinfo(crddet_id,
			   &p_nmondata->crddet,
			   &p_nmondata->custdet,
			   &p_nmondata->accdet);

	if (SUCCEED == ret && !exclstatus_check(p_nmondata->crddet.statcode, M_exclcrdstat))
	{
		ret = geninsert_nmonpis(p_nmondata);
	}

	DBG_EXIT(thisfn);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  process_nmon3100
 *
 * Purpose      :  Processing of NMON 3100
 *
 * Parameters   :  p_nmondata - Pointer to structure of source data for NMON
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	process_nmon3100(NMON_Data_t *p_nmondata)
{
	int ret = SUCCEED;
	char *thisfn = "process_nmon3100";

	long	custdet_id;
	long	crddet_id;

	DBG_ENTRY(thisfn);

	sscanf(p_nmondata->nmonlog.keydata, "%ld", &custdet_id);
	ret = crddetbycu_init(custdet_id);
	while (SUCCEED == ret)
	{
		ret = crddetbycu_next(&crddet_id);
		if (SUCCEED == ret)
		{
			ret = get_cardinfo(crddet_id,
					   &p_nmondata->crddet,
					   &p_nmondata->custdet,
					   &p_nmondata->accdet);

			if (SUCCEED == ret && !exclstatus_check(p_nmondata->crddet.statcode, M_exclcrdstat))
			{
				ret = geninsert_nmonpis(p_nmondata);
			}
		}
		else if (SQE_EOFERR != ret)
		{
			DBG_PRINTF((dbg_syserr, "Failed to fetch from CRDDET"));
		}
	}
	if (SQE_EOFERR == ret)
	{
		ret = SUCCEED;
	}
	crddetbycu_end();

	DBG_EXIT(thisfn);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  process_nmon3102
 *
 * Purpose      :  Processing of NMON 3102
 *
 * Parameters   :  p_nmondata - Pointer to structure of source data for NMON
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	process_nmon3102(NMON_Data_t *p_nmondata)
{
	int ret = SUCCEED;
	char *thisfn = "process_nmon3102";

	long	crddet_id;

	DBG_ENTRY(thisfn);

	sscanf(p_nmondata->nmonlog.keydata, "%ld", &crddet_id);
	ret = get_cardinfo(crddet_id,
			   &p_nmondata->crddet,
			   &p_nmondata->custdet,
			   &p_nmondata->accdet);

	if (SUCCEED == ret && !exclstatus_check(p_nmondata->crddet.statcode, M_exclcrdstat))
	{
		ret = geninsert_nmonpis(p_nmondata);
	}

	DBG_EXIT(thisfn);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  process_nmon3400
 *
 * Purpose      :  Processing of NMON 3400
 *
 * Parameters   :  p_nmondata - Pointer to structure of source data for NMON
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	process_nmon3400(NMON_Data_t *p_nmondata)
{
	int ret = SUCCEED;
	char *thisfn = "process_nmon3400";
	
	long bpdtkndeviceprov_id = 0;
	BPDTKNDEVICEPROV_IND_t p_bpdtkndeviceprov_ind;	
	
	TOKEN_PK_t token_pk;
static	TOKEN_t old_token;

	DBG_ENTRY(thisfn);

	memset(&old_token, 0, sizeof(old_token));
	
	memset(&p_bpdtkndeviceprov_ind, 0, sizeof(p_bpdtkndeviceprov_ind));
	
	sscanf(p_nmondata->nmonlog.keydata, "%ld", &bpdtkndeviceprov_id);
	
	ret = dbbpdtkndeviceprov_get_by_id_deletedincluded_nolock(bpdtkndeviceprov_id, &p_nmondata->bpdtkndeviceprov, &p_bpdtkndeviceprov_ind);
	
	if (SUCCEED == ret)
	{
		DBG_PRINTF((dbg_progdetail, "BPDTKNDEVICEPROV id[%ld] found", bpdtkndeviceprov_id));
	}
	else if (SQE_EOFERR == ret)
	{
		DBG_PRINTF((dbg_proginfo, "BPDTKNDEVICEPROV id[%ld] not found --> ignore and continue", bpdtkndeviceprov_id));
		
		ret = SUCCEED;
		goto out;
	}
	else
	{
		DBG_PRINTF((dbg_syserr, "Failed to get BPDTKNDEVICEPROV (id: %ld) from DB", bpdtkndeviceprov_id));
		ret = FAIL;
	}
	
	if (SUCCEED == ret)
	{
		token_pk.id = p_nmondata->bpdtkndeviceprov.token_id;
		if (SUCCEED != TOKENgetbyTOKEN_PK(&p_nmondata->token, &token_pk))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get TOKEN (id: %ld) from DB", token_pk.id));
			ret = FAIL;
		}
		else
		{
			DBG_PRINTF((dbg_progdetail, "TOKEN found id[%ld]", token_pk.id));
		}
	}

	if (SUCCEED == ret && exclstatus_check(p_nmondata->bpdtkndeviceprov.devstatus, M_excltknstat))
	{
		DBG_PRINTF((dbg_progdetail, "devstatus[%s] will not be sent to Falcon", p_nmondata->bpdtkndeviceprov.devstatus));
		
		goto out;
	}

	if (SUCCEED == ret)
	{
		ret = get_cardinfo(p_nmondata->token.crddet_id,
				   &p_nmondata->crddet,
				   &p_nmondata->custdet,
				   &p_nmondata->accdet);
	}

	if (SUCCEED == ret)
	{
		ret = dbtoken_getby_crddet_id(p_nmondata->token.crddet_id, p_nmondata->token.whencreated, 
					      &old_token, &p_nmondata->tokencount);
		if (SUCCEED == ret)
		{
			DBG_PRINTF((dbg_progdetail, "Previous token found. Token previous count: [%ld]",
				p_nmondata->tokencount));
			p_nmondata->p_old_token = &old_token;
		}
		else if (SQE_EOFERR == ret)
		{
			DBG_PRINTF((dbg_proginfo, "Previous token not found. Current TOKEN.id=[%ld]", 
				p_nmondata->token.id));
			ret = SUCCEED;
		}
		else
		{
			DBG_PRINTF((dbg_syserr, "Failed to get previous TOKEN by "
				"crddet_id=%ld and whencreated < %s",
				p_nmondata->token.crddet_id, p_nmondata->token.whencreated));
		}
	}

	if (SUCCEED == ret)
	{
		ret = geninsert_nmonpis_3400(p_nmondata);
	}
	
out:

	DBG_EXIT(thisfn);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  process_nmon3401
 *
 * Purpose      :  Processing of NMON 3401
 *
 * Parameters   :  p_nmondata - Pointer to structure of source data for NMON
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	process_nmon3401(NMON_Data_t *p_nmondata)
{
	int ret = SUCCEED;
	char *thisfn = "process_nmon3401";
	
	long bpdtkndeviceprov_id = 0;
	BPDTKNDEVICEPROV_IND_t p_bpdtkndeviceprov_ind;	

	TOKEN_PK_t	token_pk;

	DBG_ENTRY(thisfn);

	memset(&p_bpdtkndeviceprov_ind, 0, sizeof(p_bpdtkndeviceprov_ind));
	
	sscanf(p_nmondata->nmonlog.keydata, "%ld", &bpdtkndeviceprov_id);
	
	ret = dbbpdtkndeviceprov_get_by_id_deletedincluded_nolock(bpdtkndeviceprov_id, &p_nmondata->bpdtkndeviceprov, &p_bpdtkndeviceprov_ind);
	
	if (SUCCEED == ret)
	{
		DBG_PRINTF((dbg_progdetail, "BPDTKNDEVICEPROV id[%ld] found", bpdtkndeviceprov_id));
	}
	else if (SQE_EOFERR == ret)
	{
		DBG_PRINTF((dbg_proginfo, "BPDTKNDEVICEPROV id[%ld] not found --> ignore and continue", bpdtkndeviceprov_id));
		
		ret = SUCCEED;
		goto out;
	}
	else
	{
		DBG_PRINTF((dbg_syserr, "Failed to get BPDTKNDEVICEPROV (id: %ld) from DB", bpdtkndeviceprov_id));
		ret = FAIL;
	}

	if (SUCCEED == ret)
	{
		token_pk.id = p_nmondata->bpdtkndeviceprov.token_id;	
		if (SUCCEED != TOKENgetbyTOKEN_PK(&p_nmondata->token, &token_pk))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get TOKEN (id: %ld) from DB", token_pk.id));
			ret = FAIL;
		}
		else
		{
			DBG_PRINTF((dbg_progdetail, "TOKEN found id[%ld]", token_pk.id));
		}
	}

	if (SUCCEED == ret && exclstatus_check(p_nmondata->bpdtkndeviceprov.devstatus, M_excltknstat))
	{
		DBG_PRINTF((dbg_progdetail, "devstatus[%s] will not be sent to Falcon", p_nmondata->bpdtkndeviceprov.devstatus));
		
		goto out;
	}

	if (SUCCEED == ret)
	{
		ret = get_cardinfo(p_nmondata->token.crddet_id, 
				   &p_nmondata->crddet, 
				   &p_nmondata->custdet, 
				   &p_nmondata->accdet);
	}
	
	if (SUCCEED == ret)
	{
		ret = dbtoken_getby_crddet_id(p_nmondata->token.crddet_id, NULL, NULL, &p_nmondata->tokencount);
		if (SQE_EOFERR == ret)
		{
			ret = SUCCEED;
		}
		else
		{
			DBG_PRINTF((dbg_syserr, "Failed to get TOKEN count by crddet_id=%ld", 
				p_nmondata->token.crddet_id));
		}
	}

	if (SUCCEED == ret)
	{
		ret = geninsert_nmonpis(p_nmondata);
	}
	
out:

	DBG_EXIT(thisfn);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  geninsert_nmonpis
 *
 * Purpose      :  Map NMON_PIS data according to Nonmonetary 2.0
 * 		   and add new record to DB
 *
 * Parameters   :  p_nmondata - Pointer to structure of source data for NMON
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	geninsert_nmonpis(NMON_Data_t *p_nmondata)
{
	int ret = SUCCEED;
	char *thisfn = "geninsert_nmonpis";

	NMON_PIS_t nmonpis;

	DBG_ENTRY(thisfn);

	memset(&nmonpis, 0, sizeof(nmonpis));

	p_nmondata->timestamp = local_timestamp(NULL, 0);
	if (SUCCEED != nmon_pis_map_nmon20(&nmonpis, p_nmondata))
	{
		DBG_PRINTF((dbg_syserr, "Failed to map NMON_PIS data"));
		ret = FAIL;
	}
	else 
	{	
		DBG_PRINTF((dbg_progdetail, "nmonpis.olddate1[%ld] nmonpis.newdate1[%ld] nmonpis.olddate2[%ld] nmonpis.newdate2[%ld]", 
										nmonpis.olddate1, nmonpis.newdate1, nmonpis.olddate2, nmonpis.newdate2));
										
		DBG_PRINTF((dbg_progdetail, "p_nmondata->bpdtkndeviceprov.id[%ld] p_nmondata->bpdtkndeviceprov.tknexpdate[%s]", 
										p_nmondata->bpdtkndeviceprov.id, p_nmondata->bpdtkndeviceprov.tknexpdate));
		

		if (SUCCEED != NMON_PISadd(&nmonpis))
		{
			DBG_PRINTF((dbg_syserr, "Failed to add NMON_PIS record [PAN:%s]",
				dbg_panMask(nmonpis.pan)));
			ret = FAIL;
		}
		else
		{
			/* Client-generated unique transaction ID that is unique across all
			 * data feeds for a specific installation of Falcon Fraud Manager */
			sprintf(nmonpis.externaltransactionid, "%ld", nmonpis.id);
		}
	}

	DBG_EXIT(thisfn);

	return ret;
}



/*------------------------------------------------------------------------
 *
 * Function     :  geninsert_nmonpis_3400
 *
 * Purpose      :  Map NMON_PIS data according to Nonmonetary 2.0
 * 		   and add new record to DB
 *
 * Parameters   :  p_nmondata - Pointer to structure of source data for NMON
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	geninsert_nmonpis_3400(NMON_Data_t *p_nmondata)
{
	int ret = SUCCEED;
	char *thisfn = "geninsert_nmonpis_3400";

	NMON_PIS_t nmonpis;
	NMON_PIS_IND_t nmonpis_ind;

	DBG_ENTRY(thisfn);

	memset(&nmonpis, 0, sizeof(nmonpis_ind));
	
	memset(&nmonpis_ind, IND_DATA_VALUE, sizeof(nmonpis_ind));
	
	nmonpis_ind.olddate1 = IND_DATA_NULL;
	nmonpis_ind.olddate2 = IND_DATA_NULL;
	nmonpis_ind.oldnumericvalue1 = IND_DATA_NULL;
	
	strcpy(nmonpis.externaltransactionid, " ");
	strcpy(nmonpis.decisioncode, " ");
	strcpy(nmonpis.contactmethod, " ");
	strcpy(nmonpis.contactmethodid, " ");
	strcpy(nmonpis.newcustomerid, " ");
	strcpy(nmonpis.newcustomeracctnumber, " ");
	strcpy(nmonpis.newgivenname, " ");
	strcpy(nmonpis.oldgivenname, " ");
	strcpy(nmonpis.newmiddlename, " ");
	strcpy(nmonpis.oldmiddlename, " ");
	strcpy(nmonpis.newsurname, " ");
	strcpy(nmonpis.oldsurname, " ");
	strcpy(nmonpis.newsuffix, " ");
	strcpy(nmonpis.oldsuffix, " ");
	strcpy(nmonpis.newstreetline1, " ");
	strcpy(nmonpis.oldstreetline1, " ");
	strcpy(nmonpis.newstreetline2, " ");
	strcpy(nmonpis.oldstreetline2, " ");
	strcpy(nmonpis.newstreetline3, " ");
	strcpy(nmonpis.oldstreetline3, " ");
	strcpy(nmonpis.newstreetline4, " ");
	strcpy(nmonpis.oldstreetline4, " ");
	strcpy(nmonpis.newstateprovince, " ");
	strcpy(nmonpis.oldstateprovince, " ");
	strcpy(nmonpis.newphone1, " ");
	strcpy(nmonpis.oldphone1, " ");
	strcpy(nmonpis.newphone2, " ");
	strcpy(nmonpis.oldphone2, " ");
	strcpy(nmonpis.newemailaddress, " ");
	strcpy(nmonpis.oldemailaddress, " ");
	strcpy(nmonpis.newid2, " ");
	strcpy(nmonpis.oldid2, " ");
	strcpy(nmonpis.newindicator3, " ");
	strcpy(nmonpis.oldindicator3, " ");
	strcpy(nmonpis.newindicator4, " ");
	strcpy(nmonpis.oldindicator4, " ");
	
	nmonpis.newmonetaryvalue = 0;
	nmonpis.oldmonetaryvalue = 0;
	
	strcpy(nmonpis.currencycode, " ");
	nmonpis.currencyconversionrate = 0;

	nmonpis.newnumericvalue2 = 0;
	nmonpis.oldnumericvalue2 = 0;

	strcpy(nmonpis.newcharactervalue, " ");
	strcpy(nmonpis.oldcharactervalue, " ");	
	
	strcpy(nmonpis.newtext, " ");
	strcpy(nmonpis.oldtext, " ");
	strcpy(nmonpis.ctxcomment, " ");
	strcpy(nmonpis.userindicator01, " ");
	strcpy(nmonpis.userindicator02, " ");
	strcpy(nmonpis.userindicator03, " ");
	strcpy(nmonpis.userindicator04, " ");
	strcpy(nmonpis.userindicator05, " ");
	strcpy(nmonpis.usercode1, " ");
	strcpy(nmonpis.usercode2, " ");
	strcpy(nmonpis.usercode3, " ");
	strcpy(nmonpis.usercode4, " ");
	strcpy(nmonpis.usercode5, " ");
	strcpy(nmonpis.userdata01, " ");
	strcpy(nmonpis.userdata02, " ");
	strcpy(nmonpis.userdata03, " ");
	strcpy(nmonpis.userdata04, " ");
	strcpy(nmonpis.userdata05, " ");
	strcpy(nmonpis.userdata06, " ");
	strcpy(nmonpis.userdata07, " ");
	strcpy(nmonpis.userdata08, " ");
	strcpy(nmonpis.userdata09, " ");
	strcpy(nmonpis.userdata10, " ");
	strcpy(nmonpis.userdata11, " ");
	strcpy(nmonpis.userdata12, " ");
	strcpy(nmonpis.userdata13, " ");
	strcpy(nmonpis.userdata14, " ");
	strcpy(nmonpis.userdata15, " ");
	strcpy(nmonpis.reserved_01, " ");
	
		
	p_nmondata->timestamp = local_timestamp(NULL, 0);
	if (SUCCEED != nmon_pis_map_nmon20(&nmonpis, p_nmondata))
	{
		DBG_PRINTF((dbg_syserr, "Failed to map NMON_PIS data"));
		ret = FAIL;
	}
	else 
	{	
		DBG_PRINTF((dbg_progdetail, "nmonpis.olddate1[%ld] nmonpis.newdate1[%ld] nmonpis.olddate2[%ld] nmonpis.newdate2[%ld]", 
										nmonpis.olddate1, nmonpis.newdate1, nmonpis.olddate2, nmonpis.newdate2));
										
		DBG_PRINTF((dbg_progdetail, "p_nmondata->bpdtkndeviceprov.id[%ld] p_nmondata->bpdtkndeviceprov.tknexpdate[%s]", 
										p_nmondata->bpdtkndeviceprov.id, p_nmondata->bpdtkndeviceprov.tknexpdate));
		

		if (SUCCEED != NMON_PISadd_IND(&nmonpis, &nmonpis_ind))
		{
			DBG_PRINTF((dbg_syserr, "Failed to add NMON_PIS record [PAN:%s]",
				dbg_panMask(nmonpis.pan)));
			ret = FAIL;
		}
		else
		{
			/* Client-generated unique transaction ID that is unique across all
			 * data feeds for a specific installation of Falcon Fraud Manager */
			sprintf(nmonpis.externaltransactionid, "%ld", nmonpis.id);
		}
	}

	DBG_EXIT(thisfn);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  get_cardinfo
 *
 * Purpose      :  Search for card, account, customer details by card Id
 *
 * Parameters   :  crddet_id - Card Id
 * 		   p_crddet - Pointer to CRDDET structure
 * 		   p_custdet - Pointer to CUSTDET structure
 * 		   p_accdet - Pointer to ACCDET structure
 *
 * Returns      :  SUCCEED / SQE_EOFERR / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	get_cardinfo(long crddet_id, CRDDET_t *p_crddet, CUSTDET_t *p_custdet, ACCDET_t *p_accdet)
{
	int ret = SUCCEED;
	char *thisfn = "get_cardinfo";

	CRDDET_PK_t	crddet_pk;

	CRDFORMAT_t	crdformat;
	CRDPRODUCT_t	crdproduct;
	BRANCH_t	branch;
	INST_t		inst;

	DBG_ENTRY(thisfn);

	crddet_pk.id = crddet_id;
	if(SUCCEED != CRDCUST_CRDDET_PK_SELECT(&crddet_pk,
					       p_crddet,
					       p_custdet,
					       &crdformat,
					       &crdproduct,
					       p_accdet,
					       &branch,
					       &inst))
	{
		DBG_PRINTF((dbg_syserr, "Failed to get associated card "
			"(id: %ld) records", crddet_pk.id));
		ret = FAIL;
	}

	DBG_EXIT(thisfn);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  exclstatus_check
 *
 * Purpose      :  Check card/token status to match `exclstats`
 *
 * Parameters   :  status - Card/Token status to check
 * 		   exclstats - Comma separated list of excluded statuses
 *
 * Returns      :  TRUE / FALSE
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate ctxbool exclstatus_check(const char *status, const char *exclstats)
{
	ctxbool ret = FALSE;
	char tmpexclstat[EXCLUDE_STATUS_SIZE] = {EOS}, *tmp;
	char tmpbuf[16];

	strscpy(tmpexclstat, exclstats);
	tmp = strtok(tmpexclstat,",");
	while(NULL != tmp)
	{
		strscpy(tmpbuf, tmp);
		if (0 == strcmp(status, stp_both(tmpbuf)))
		{
			ret = TRUE;
			break;
		}

		tmp = strtok(NULL, ",");
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  uninit
 *
 * Purpose	:  Wrap everything up
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *------------------------------------------------------------------------*/
ctxprivate int uninit(void)
{
	int ret = SUCCEED;
	sql_close();

	return ret;
}

/*------------------------------------------------------------------------
 *
 * function	: sigdisp
 *
 * purpose	: react on signal (no more hanging)
 *
 * parameters	: sig - signal which caused interrupt
 *
 * returns	: 
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate void sigdisp(int sig)
{

	DBG_PRINTF((dbg_progdetail,
		"!!!!!!!!!!  Interrupted: %d  !!!!!!!!!!", sig ));

	if( SIGALRM == sig )
	{
		signal( SIGALRM, sigdisp );
		DBG_PRINTF((dbg_syswarn, "Alarm signal"));
	}
	else if( SIGTERM == sig || SIGQUIT == sig || SIGINT == sig )
	{
		DBG_PRINTF((dbg_syserr, "Exiting due to receiving signal: %d", sig));
		DBG_PRINTF((dbg_progdetail, "Abort..."));
		sql_abort();

		uninit();
		exit( 1 );
	}
	else if( SIGSEGV == sig )
	{
		DBG_PRINTF((dbg_fatal, "Exiting due to receiving signal: %d", sig));
	}
	else
	{
		DBG_PRINTF((dbg_syswarn, "Unexpected signal %d", sig));
	}
}
