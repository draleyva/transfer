/*-----------------------------------------------------------------------
 * 
 * File		: pis12deltacv.c
 * 
 * Author	: Ruslans Vasiljevs - Raul Torres
 * 
 * Created	: 26/07/2022
 *
 * Purpose	: PIS12_DELTA data conversion mapping
 * 
 * Comments	: 
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
 *-----------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>

#include <cortex.h>
#include <cocbfdef.h>
#include <coencpan.h>
#include <encgen.h>
#include <forex.h>
#include <crdbasedef.h>
#include <emvdef.h>
#include <cdbcrdprodetal.h>

#include <sldbg.h>
#include <slstring.h>
#include <slmap.h>

#include <dbpis12deltarh.h>
#include <dbcrbtrh.h>
#include <dbcstarh.h>
#include <dbpinsthstrx.h>
#include <dbcpinrh.h>
#include <dbforex.h>
#include <dberr.h>

#include <pis12deltacv.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define PIS12_RECORDTYPE	"PIS12"
#define PIS12_VERSION	"1.2"

#define FO(x) OFFSET(PIS12_DELTA_t,x)
#define FS(x) ELEM_SIZE(PIS12_DELTA_t,x)

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
typedef struct
{
    long	offset;		/* Offset in PIS12_DELTA		*/
    size_t	len;		/* Length of field in PIS12_DELTA	*/
    int		(*p_convfn)(PIS12_Data_t *, char *, size_t);
} pis12_delta_cnv_t;

/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/* Name of the workflow to be executed by Falcon Fraud Manager */
ctxprivate char	M_workflow[16+1] = {EOS};
/* Unique identifier for the client or subclient */
ctxprivate char	M_clientid[16+1] = {EOS};

/* Type of the card */
ctxprivate map_tbl_t map_pis12type[] =
{
	/* ctx, PIS12 */
	{"2",	"C",	STR},	/* Credit card			*/
	{".",	"D",	REGEX},	/* Debit card (default)		*/
	{NULL}
};

/* Card subtype */
ctxprivate map_tbl_t map_pis12subtype[] =
{
	/* ctx, PIS12 */
	{"0",	"N",	STR},	/* Standard consumer card	*/
	{"1",	"C",	STR},	/* Co-branded			*/
	{".",	"O",	REGEX},	/* Other			*/
	{NULL}
};

/* Credit card association under which the card was issued */
ctxprivate map_tbl_t map_pis12association[] =
{
	/* ctx, 	PIS12 */
	{"VISA",	"V",	STR},	/* Visa		*/
	{"PLUS",	"V",	STR},	/* Visa		*/
	{"ECRD",	"M",	STR},	/* MasterCard	*/
	{"MCRD",	"M",	STR},	/* MasterCard	*/
	{"CIRR",	"M",	STR},	/* MasterCard	*/
	{"MAES",	"M",	STR},	/* MasterCard	*/
	{"CIMA",	"M",	STR},	/* MasterCard	*/
	{"AMEX",	"A",	STR},	/* AMEX		*/
	{".",		" ",	REGEX},	/* Default	*/
	{NULL}
};

/* Card status */
ctxprivate map_tbl_t map_pis12status[] =
{
	/* ctx, 		PIS12 */
	{"99",			"40",	STR},	/* Statused, other (blocked)		*/
	{CRDSTAT_EXPIRED,	"40",	STR},	/* Statused, other (blocked)		*/
	{CRDSTAT_LOST,		"27",	STR},	/* Closed, lost				*/
	{CRDSTAT_STOLEN,	"26",	STR},	/* Closed, stolen			*/
	{CRDSTAT_CLOSED,	"21",	STR},	/* Closed, cardholder request		*/
	{CRDSTAT_CANCEL,	"23",	STR},	/* Closed, bank action (revoked)	*/
	{CRDSTAT_FRAUD,		"25",	STR},	/* Closed, fraud			*/
	{"09",			"11",	STR},	/* Open, inactive			*/
	{"26",			"00",	STR},	/* Open, non-statused, active		*/
	{CRDSTAT_NORMAL,	"00",	STR},	/* Open, non-statused, active		*/
	{CRDSTAT_PINTRIES,	"40",	STR},	/* Statused, other (blocked)		*/
	{"52",			"40",	STR},	/* Statused, other (blocked)		*/
	{"10",			"40",	STR},	/* Statused, other (blocked)		*/
	{"21",			"40",	STR},	/* Statused, other (blocked)		*/
	{"96",			"27",	STR},	/* Closed, lost				*/
	{NULL}
};

/* Token status */
ctxprivate map_tbl_t map_pis12tknstatus[] =
{
	/* ctx, PIS12 */
	{"I",	"11",	STR},	/* In Progress	*/
	{"A",	"00",	STR},	/* Active	*/
	{"S",	"20",	STR},	/* Suspended	*/
	{"D",	"29",	STR},	/* Deactivated	*/
	{"E",	"30",	STR},	/* Expired	*/
	{NULL}
};

/* Card issue type for most recently issued payment instrument */
ctxprivate map_tbl_t map_pis12plasticissuetype[] =
{
	/* ctx, PIS12 */
	{"1",	"I",	STR},	/* Initial issue	*/
	{".",	" ",	REGEX},	/* Unknown/other	*/
	{NULL}
};

/* Chip specification */
ctxprivate map_tbl_t map_pis12emvscheme[] =
{
	/* ctx, PIS12 */
	{"0",	"V",	STR},	/* VIS			*/
	{"1",	"M",	STR},	/* M/Chip		*/
	{"3",	"C",	STR},	/* CCD			*/
	{".",	" ",	REGEX},	/* Unknown/not provided	*/
	{NULL}
};

/* Chip specification version */
ctxprivate map_tbl_t map_pis12emvchipref[] =
{
	/* ctx, PIS12 */
	{"1",	" ",	STR},	/* Visa UKIS 		*/
	{"2",	"131",	STR},	/* VSDC VIS 1.3.1	*/
	{"3",	"132",	STR},	/* VSDC VIS 1.3.2 	*/
	{"4",	"140",	STR},	/* VSDC VIS 1.4		*/
	{"5",	"141",	STR},	/* VSDC VIS 1.4.1 	*/
	{"6",	"150",	STR},	/* VSDC VIS 1.5		*/
	{".",	" ",	REGEX},	/* Unknown/not provided	*/
	{NULL}
};

/*---------------------------Prototypes---------------------------------*/
ctxprivate int PIS12delta_workflow(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_recordtype(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_dataspecificationversion(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_clientidfromheader(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_crddet_id(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_token_crddet_id(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_token_id(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_pis12_type_crddet(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_pis12_type_token(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_recordcreationdate(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_recordcreationtime(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_recordcreationmilliseconds(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_customeridfromheader(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_customeracctnumber(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_pan_crddet(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_pan_token(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_type(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_subtype(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_category(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_association_crddet(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_association_token(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_panopendate(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_membersincedate(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_issuingcountry(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_cardholdercity(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_cardholderpostalcode(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_cardholdercountrycode(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_paymentinstrumentid(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_status_crddet(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_status_token(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_statusdate(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_pinlength(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_pinsetdate(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_pintype(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_activeindicator(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_nameoninstrument(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_expirationdate(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_lastissuedate(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_plasticissuetype_crddet(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_plasticissuetype_token(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_incentive(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_currencycode(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_currencyconversionrate(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_creditlimit(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_dailyposlimit(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_dailycashlimit(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_mediatype_crddet(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_mediatype_token(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_aipstatic(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_aipdynamic(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_chipspecification(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_chipspecversion(PIS12_Data_t *data, char *out, size_t size);


ctxprivate int PIS12delta_userdata04_token(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_userdata05_token(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_userdata07_token(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_userindicator01_token(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_userindicator02_token(PIS12_Data_t *data, char *out, size_t size);
ctxprivate int PIS12delta_numberofpaymentids(PIS12_Data_t *data, char *out, size_t size);

ctxprivate int pis12delta_get_crdprodlim(PIS12_Data_t *data);
ctxprivate int pis12delta_decrypt_pan(char *enc, char *clr, size_t sizeclr);
ctxprivate int pis12_delta_map(PIS12_DELTA_t *p_pis12delta, PIS12_Data_t *p_pis12data, 
			       pis12_delta_cnv_t *p_convtab, size_t dim, ctxbool errorignore);

ctxprivate int cust_strscat(char* dst, size_t dstsize, const char* src);

ctxprivate pis12_delta_cnv_t M_convtab_CRDDET_PIS12[] =
{
/* offset				len				p_convfn */
{ FO(workflow),				FS(workflow), 			PIS12delta_workflow },
{ FO(recordtype),			FS(recordtype),			PIS12delta_recordtype },
{ FO(dataspecificationversion),		FS(dataspecificationversion),	PIS12delta_dataspecificationversion },
{ FO(clientidfromheader),		FS(clientidfromheader),		PIS12delta_clientidfromheader },
{ FO(crddet_id), 			FS(crddet_id),			PIS12delta_crddet_id },
{ FO(token_id),				FS(token_id), 			NULL },
{ FO(pis12_type),			FS(pis12_type),			PIS12delta_pis12_type_crddet },
{ FO(recordcreationdate),		FS(recordcreationdate),		PIS12delta_recordcreationdate },
{ FO(recordcreationtime),		FS(recordcreationtime),		PIS12delta_recordcreationtime },
{ FO(recordcreationmilliseconds),	FS(recordcreationmilliseconds),	PIS12delta_recordcreationmilliseconds },
{ FO(gmtoffset),			FS(gmtoffset), 			NULL },
{ FO(customeridfromheader),		FS(customeridfromheader),	PIS12delta_customeridfromheader },
{ FO(customeracctnumber),		FS(customeracctnumber),		PIS12delta_customeracctnumber },
{ FO(externaltransactionid),		FS(externaltransactionid),	NULL },
{ FO(pan), 				FS(pan),			PIS12delta_pan_crddet },
{ FO(type),				FS(type),			PIS12delta_type },
{ FO(subtype), 				FS(subtype),			PIS12delta_subtype },
{ FO(category),				FS(category),			PIS12delta_category },
{ FO(association),			FS(association),		PIS12delta_association_crddet },
{ FO(panopendate),			FS(panopendate),		PIS12delta_panopendate },
{ FO(membersincedate),			FS(membersincedate),		PIS12delta_membersincedate },
{ FO(issuingcountry),			FS(issuingcountry),		PIS12delta_issuingcountry },
{ FO(cardholdercity),			FS(cardholdercity),		PIS12delta_cardholdercity },
{ FO(cardholderstateprovince),		FS(cardholderstateprovince),	NULL },
{ FO(cardholderpostalcode),		FS(cardholderpostalcode),	PIS12delta_cardholderpostalcode },
{ FO(cardholdercountrycode),		FS(cardholdercountrycode),	PIS12delta_cardholdercountrycode },
{ FO(numberofpaymentids),		FS(numberofpaymentids),		NULL },
{ FO(paymentinstrumentid),		FS(paymentinstrumentid),	NULL },
{ FO(status),				FS(status),			PIS12delta_status_crddet },
{ FO(statusdate),			FS(statusdate),			PIS12delta_statusdate },
{ FO(pinlength),			FS(pinlength),			PIS12delta_pinlength },
{ FO(pinsetdate),			FS(pinsetdate),			PIS12delta_pinsetdate },
{ FO(pintype),				FS(pintype),			PIS12delta_pintype },
{ FO(activeindicator),			FS(activeindicator),		PIS12delta_activeindicator },
{ FO(nameoninstrument),			FS(nameoninstrument),		PIS12delta_nameoninstrument },
{ FO(expirationdate),			FS(expirationdate),		PIS12delta_expirationdate },
{ FO(lastissuedate),			FS(lastissuedate),		PIS12delta_lastissuedate },
{ FO(plasticissuetype),			FS(plasticissuetype),		PIS12delta_plasticissuetype_crddet },
{ FO(incentive),			FS(incentive),			PIS12delta_incentive },
{ FO(currencycode),			FS(currencycode),		PIS12delta_currencycode },
{ FO(currencyconversionrate),		FS(currencyconversionrate),	PIS12delta_currencyconversionrate },
{ FO(creditlimit),			FS(creditlimit),		PIS12delta_creditlimit },
{ FO(overdraftlimit),			FS(overdraftlimit),		NULL },
{ FO(dailyposlimit),			FS(dailyposlimit),		PIS12delta_dailyposlimit },
{ FO(dailycashlimit),			FS(dailycashlimit),		PIS12delta_dailycashlimit },
{ FO(cashbacklimitmode),		FS(cashbacklimitmode),		NULL },
{ FO(mediatype),			FS(mediatype),			PIS12delta_mediatype_crddet },
{ FO(aipstatic),			FS(aipstatic),			PIS12delta_aipstatic },
{ FO(aipdynamic),			FS(aipdynamic),			PIS12delta_aipdynamic },
{ FO(aipverify),			FS(aipverify),			NULL },
{ FO(aiprisk),				FS(aiprisk),			NULL },
{ FO(aipissuerauthentication),		FS(aipissuerauthentication),	NULL },
{ FO(aipcombined),			FS(aipcombined),		NULL },
{ FO(chipspecification),		FS(chipspecification),		PIS12delta_chipspecification },
{ FO(chipspecversion),			FS(chipspecversion),		PIS12delta_chipspecversion },
{ FO(offlinelowerlimit),		FS(offlinelowerlimit),		NULL },
{ FO(offlineupperlimit),		FS(offlineupperlimit),		NULL },
{ FO(userindicator01),			FS(userindicator01),		NULL },
{ FO(userindicator02),			FS(userindicator02),		NULL },
{ FO(usercode1),			FS(usercode1),			NULL },
{ FO(usercode2),			FS(usercode2),			NULL },
{ FO(userdata01),			FS(userdata01),			NULL },
{ FO(userdata02),			FS(userdata02),			NULL },
{ FO(userdata03),			FS(userdata03),			NULL },
{ FO(userdata04),			FS(userdata04),			NULL },
{ FO(userdata05),			FS(userdata05),			NULL },
{ FO(userdata06),			FS(userdata06),			NULL },
{ FO(userdata07),			FS(userdata07),			NULL }
};

ctxprivate pis12_delta_cnv_t M_convtab_TOKEN_PIS12[] =
{
/* offset				len				p_convfn */
{ FO(workflow),				FS(workflow), 			PIS12delta_workflow },
{ FO(recordtype),			FS(recordtype),			PIS12delta_recordtype },
{ FO(dataspecificationversion),		FS(dataspecificationversion),	PIS12delta_dataspecificationversion },
{ FO(clientidfromheader),		FS(clientidfromheader),		PIS12delta_clientidfromheader },
{ FO(crddet_id), 			FS(crddet_id), 			PIS12delta_token_crddet_id },
{ FO(token_id),				FS(token_id), 			PIS12delta_token_id },
{ FO(pis12_type),			FS(pis12_type),			PIS12delta_pis12_type_token },
{ FO(recordcreationdate),		FS(recordcreationdate),		PIS12delta_recordcreationdate },
{ FO(recordcreationtime),		FS(recordcreationtime),		PIS12delta_recordcreationtime },
{ FO(recordcreationmilliseconds),	FS(recordcreationmilliseconds),	PIS12delta_recordcreationmilliseconds },
{ FO(gmtoffset),			FS(gmtoffset), 			NULL },
{ FO(customeridfromheader),		FS(customeridfromheader),	PIS12delta_customeridfromheader },
{ FO(customeracctnumber),		FS(customeracctnumber),		PIS12delta_customeracctnumber },
{ FO(externaltransactionid),		FS(externaltransactionid),	NULL },
{ FO(pan), 				FS(pan),			PIS12delta_pan_crddet },
{ FO(type),				FS(type),			PIS12delta_type },
{ FO(subtype), 				FS(subtype),			PIS12delta_subtype },
{ FO(category),				FS(category),			PIS12delta_category },
{ FO(association),			FS(association),		PIS12delta_association_token },
{ FO(panopendate),			FS(panopendate),		PIS12delta_panopendate },
{ FO(membersincedate),			FS(membersincedate),		PIS12delta_membersincedate },
{ FO(issuingcountry),			FS(issuingcountry),		PIS12delta_issuingcountry },
{ FO(cardholdercity),			FS(cardholdercity),		PIS12delta_cardholdercity },
{ FO(cardholderstateprovince),		FS(cardholderstateprovince),	NULL },
{ FO(cardholderpostalcode),		FS(cardholderpostalcode),	PIS12delta_cardholderpostalcode },
{ FO(cardholdercountrycode),		FS(cardholdercountrycode),	PIS12delta_cardholdercountrycode },
{ FO(numberofpaymentids),		FS(numberofpaymentids),		PIS12delta_numberofpaymentids },
{ FO(paymentinstrumentid),		FS(paymentinstrumentid),	PIS12delta_paymentinstrumentid },
{ FO(status),				FS(status),			PIS12delta_status_token },
{ FO(statusdate),			FS(statusdate),			PIS12delta_statusdate },
{ FO(pinlength),			FS(pinlength),			PIS12delta_pinlength },
{ FO(pinsetdate),			FS(pinsetdate),			PIS12delta_pinsetdate },
{ FO(pintype),				FS(pintype),			PIS12delta_pintype },
{ FO(activeindicator),			FS(activeindicator),		PIS12delta_activeindicator },
{ FO(nameoninstrument),			FS(nameoninstrument),		PIS12delta_nameoninstrument },
{ FO(expirationdate),			FS(expirationdate),		PIS12delta_expirationdate },
{ FO(lastissuedate),			FS(lastissuedate),		PIS12delta_lastissuedate },
{ FO(plasticissuetype),			FS(plasticissuetype),		PIS12delta_plasticissuetype_token },
{ FO(incentive),			FS(incentive),			PIS12delta_incentive },
{ FO(currencycode),			FS(currencycode),		PIS12delta_currencycode },
{ FO(currencyconversionrate),		FS(currencyconversionrate),	PIS12delta_currencyconversionrate },
{ FO(creditlimit),			FS(creditlimit),		PIS12delta_creditlimit },
{ FO(overdraftlimit),			FS(overdraftlimit),		NULL },
{ FO(dailyposlimit),			FS(dailyposlimit),		PIS12delta_dailyposlimit },
{ FO(dailycashlimit),			FS(dailycashlimit),		PIS12delta_dailycashlimit },
{ FO(cashbacklimitmode),		FS(cashbacklimitmode),		NULL },
{ FO(mediatype),			FS(mediatype),			PIS12delta_mediatype_token },
{ FO(aipstatic),			FS(aipstatic),			NULL },
{ FO(aipdynamic),			FS(aipdynamic),			NULL },
{ FO(aipverify),			FS(aipverify),			NULL },
{ FO(aiprisk),				FS(aiprisk),			NULL },
{ FO(aipissuerauthentication),		FS(aipissuerauthentication),	NULL },
{ FO(aipcombined),			FS(aipcombined),		NULL },
{ FO(chipspecification),		FS(chipspecification),		NULL },
{ FO(chipspecversion),			FS(chipspecversion),		NULL },
{ FO(offlinelowerlimit),		FS(offlinelowerlimit),		NULL },
{ FO(offlineupperlimit),		FS(offlineupperlimit),		NULL },
{ FO(userindicator01),			FS(userindicator01),		PIS12delta_userindicator01_token },
{ FO(userindicator02),			FS(userindicator02),		PIS12delta_userindicator02_token },
{ FO(usercode1),			FS(usercode1),			NULL },
{ FO(usercode2),			FS(usercode2),			NULL },
{ FO(userdata01),			FS(userdata01),			NULL },
{ FO(userdata02),			FS(userdata02),			NULL },
{ FO(userdata03),			FS(userdata03),			NULL },
{ FO(userdata04),			FS(userdata04),			PIS12delta_userdata04_token },
{ FO(userdata05),			FS(userdata05),			PIS12delta_userdata05_token },
{ FO(userdata06),			FS(userdata06),			NULL },
{ FO(userdata07),			FS(userdata07),			PIS12delta_userdata07_token }
};

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_workflow
 *
 * Purpose      :  Set name of the workflow to be executed by Falcon Fraud Manager
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_workflow(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, M_workflow);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_recordtype
 *
 * Purpose      :  Set PIS12 record type
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_recordtype(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	
	slstrcpy_se(out, size, PIS12_RECORDTYPE);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_dataspecificationversion
 *
 * Purpose      :  Set PIS12 data specification version
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_dataspecificationversion(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, PIS12_VERSION);

	return ret;	
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_clientidfromheader
 *
 * Purpose      :  Set unique identifier for the client or subclient
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_clientidfromheader(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, M_clientid);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_crddet_id
 *
 * Purpose      :  Set crddet_id field getting from CRDDET
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_crddet_id(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	*((long *)out) = data->crddet.id;

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_token_crddet_id
 *
 * Purpose      :  Set crddet_id field getting from TOKEN
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_token_crddet_id(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	*((long *)out) = data->token.crddet_id;

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_token_id
 *
 * Purpose      :  Set token_id field
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  Used only in case if PIS12 is generated for TOKEN
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_token_id(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	*((long *)out) = data->token.id;

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_pis12_type_crddet
 *
 * Purpose      :  Set pis12_type = 1 (Card)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_pis12_type_crddet(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	
	*((short *)out) = PIS12_TYPE_CARD;

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_pis12_type_token
 *
 * Purpose      :  Set pis12_type = 2 (Token)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_pis12_type_token(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	*((short *)out) = PIS12_TYPE_TOKEN;

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_recordcreationdate
 *
 * Purpose      :  Set date that PIS12 record was created
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_recordcreationdate(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	
	/* local_timestamp(): yyyymmdd part */
	sscanf(data->timestamp, "%08ld", (long *)out);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_recordcreationtime
 *
 * Purpose      :  Set time that PIS12 record was created
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_recordcreationtime(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	/* local_timestamp(): HHMMSS part */
	sscanf(data->timestamp+8, "%06ld", (long *)out);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_recordcreationmilliseconds
 *
 * Purpose      :  Set milliseconds portion of the time that PIS12 record was created
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_recordcreationmilliseconds(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	/* local_timestamp(): uuu part */
	sscanf(data->timestamp+14, "%03ld", (long *)out);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_customeridfromheader
 *
 * Purpose      :  Set Primary Customer Identifier. Financial institution's 
 * 		   unique identifier for the primary customer for the PAN
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_customeridfromheader(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, data->custdet.custcode);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_customeracctnumber
 *
 * Purpose      :  Set unique identifier for the account associated with the transaction/record.
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_customeracctnumber(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, data->accdet.accno);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_pan_crddet
 *
 * Purpose      :  Set primary Account Number (PAN) of the payment instrument
 * 		   getting from CRDDET
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_pan_crddet(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	
	if ( SUCCEED != (ret=pis12delta_decrypt_pan(data->crddet.pan, out, size)) )
	{
		DBG_PRINTF((dbg_syserr, "ERROR: Decrypt PAN failed for card id=%ld", data->crddet.id));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_pan_token
 *
 * Purpose      :  Set primary Account Number (PAN) of the payment instrument
 * 		   getting from TOKEN
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_pan_token(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	if ( SUCCEED != (ret=pis12delta_decrypt_pan(data->token.pan, out, size)) )
	{
		DBG_PRINTF((dbg_syserr, "ERROR: Decrypt PAN failed for token id=%ld", data->token.id));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_type
 *
 * Purpose      :  Set type of the card
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_type(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	char tmpbuf[64], *pis12tmap;

	sprintf(tmpbuf, "%hd", data->crddet.classid);
	pis12tmap = map_table(tmpbuf, map_pis12type);
	if (NULL != pis12tmap)
	{
		slstrcpy_se(out, size, pis12tmap);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_subtype
 *
 * Purpose      :  Set card subtype
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_subtype(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	char *pis12tmap;

	pis12tmap = map_table(data->crdproduct.affinity, map_pis12subtype);
	if (NULL != pis12tmap)
	{
		slstrcpy_se(out, size, pis12tmap);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_category
 *
 * Purpose      :  Set card category
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_category(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	strcpy(out, "S"); /* Standard */

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_association_crddet
 *
 * Purpose      :  Set credit card association under which the card was issued
 * 		   (getting by CRDDET->CRDFORMAT)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_association_crddet(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	char *pis12tmap;

	pis12tmap = map_table(data->crdformat.scheme, map_pis12association);
	if (NULL != pis12tmap)
	{
		slstrcpy_se(out, size, pis12tmap);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_association_token
 *
 * Purpose      :  Set credit card association under which the card was issued
 * 		   (getting by TOKEN)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_association_token(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, data->token.schemeid);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_panopendate
 *
 * Purpose      :  Set date on which a card was first provided on the account
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_panopendate(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	*((long *)out) = data->crddet.date_created;

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_membersincedate
 *
 * Purpose      :  Set card member since date, as printed on the card
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_membersincedate(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	*((long *)out) = data->crddet.effdate;

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_issuingcountry
 *
 * Purpose      :  Set ISO numeric country code for the country from which the card was issued
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_issuingcountry(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, data->crdformat.localcountry);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_cardholdercity
 *
 * Purpose      :  Set PAN primary address: city
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_cardholdercity(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, data->custdet.home_city);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_cardholderpostalcode
 *
 * Purpose      :  Set PAN primary address: postal code
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_cardholderpostalcode(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, data->custdet.postcode);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_cardholdercountrycode
 *
 * Purpose      :  Set PAN primary address: ISO numeric country code
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_cardholdercountrycode(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, data->custdet.home_ctry);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_paymentinstrumentid
 *
 * Purpose      :  Set virtual card number
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  For token provisioning
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_paymentinstrumentid(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	/* slstrcpy_se(out, size, data->token.vpan); */
	
	slstrcpy_se(out, size, data->bpdtkndeviceprov.token);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_status_crddet
 *
 * Purpose      :  Set current card status (getting by CRDDET)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_status_crddet(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	char *pis12tmap;

	CRDSTATUS_t crdstatus;
	CRDSTATUS_HASH_t crdstatus_hash;

	memset(&crdstatus, 0, sizeof(crdstatus));
	memset(&crdstatus_hash, 0, sizeof(crdstatus_hash));

	pis12tmap = map_table(data->crddet.statcode, map_pis12status);
	if (NULL != pis12tmap)
	{
		slstrcpy_se(out, size, pis12tmap);
	}
	else
	{
		strcpy(crdstatus_hash.statcode, data->crddet.statcode);
		if (SUCCEED == CRDSTATUSgetbyCRDSTATUS_HASH(&crdstatus, &crdstatus_hash)
		    && MAC_AUTH_APP == crdstatus.actioncode[0])
		{
			slstrcpy_se(out, size, "00"); /* Default 1: Open, non-statused, active */
		}
		else
		{
			slstrcpy_se(out, size, "40"); /* Default 2: Statused, other (blocked) */
		}
		DBG_PRINTF((dbg_syswarn, "Failed to map statcode [%s] for card id=%ld, set default [%s]",
			data->crddet.statcode, data->crddet.id, out));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_status_token
 *
 * Purpose      :  Set current card status (getting by TOKEN)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_status_token(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	char *pis12tmap;

	pis12tmap = map_table(data->token.tknstatus, map_pis12tknstatus);
	if (NULL != pis12tmap)
	{
		slstrcpy_se(out, size, pis12tmap);
	}
	else
	{
		DBG_PRINTF((dbg_syserr, "Failed to map tknstatus [%s] for token id=%ld",
			data->token.tknstatus, data->token.id));
		ret = FAIL;
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_status_token
 *
 * Purpose      :  Set effective date of current status
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_statusdate(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	*((long *)out) = data->crddet.date_statchg;

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_pinlength
 *
 * Purpose      :  Set length of PIN
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_pinlength(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	*((short *)out) = 4; /* Cortex Length is 4 - constant */

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_pinsetdate
 *
 * Purpose      :  Set date on which the PIN was last set
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_pinsetdate(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	
	CRDPIN_t crdpin;
	CRDPIN_HASH_t crdpin_hash;
	
	memset(&crdpin, 0, sizeof(crdpin));
	memset(&crdpin_hash, 0, sizeof(crdpin_hash));

	ret = dbpinsetdate_by_crddetid(data->crddet.id, (long *)out);
	if (SQE_EOFERR == ret)
	{
		crdpin_hash.pintype = PINTYPE_DFLT;
		crdpin_hash.crddet_id = data->crddet.id;
		ret = CRDPINgetbyCRDPIN_HASH(&crdpin, &crdpin_hash);

		if (SQE_EOFERR == ret)
		{
			DBG_PRINTF((dbg_progdetail, "CRDPIN not found for crddet_id=%ld and pintype=%hd, "
				"set pinSetDate = NDATE_NEVER", crdpin_hash.crddet_id, crdpin_hash.pintype));
			ret = SUCCEED;
		}
		else if (SUCCEED == ret)
		{
			*((long *)out) = NDATE_NEVER == crdpin.datechanged ? crdpin.datecreated : crdpin.datechanged;		
		}
		else
		{
			DBG_PRINTF((dbg_syserr, "Failed to get CRDPIN by crddet_id=%ld, pintype=%hd from DB", 
				crdpin_hash.crddet_id, crdpin_hash.pintype));	
		}
	}
	else if (SUCCEED != ret)
	{
		DBG_PRINTF((dbg_syserr, "Failed to get pinsetdate by crddet_id=%ld from DB", data->crddet.id));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_pintype
 *
 * Purpose      :  Set type of PIN
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_pintype(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	strcpy(out, "C"); /* Customer selected */

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_activeindicator
 *
 * Purpose      :  Set PAN activation indicator
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_activeindicator(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	if (data->keyword && 0 == strcmp("pan_act", data->keyword))
	{
		strcpy(out, "Y");
	}
	else
	{
		strcpy(out, "N");
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_nameoninstrument
 *
 * Purpose      :  Set name that appears on the payment instrument(s)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_nameoninstrument(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, data->crddet.firstname);
	cust_strscat(out, size, " ");
	cust_strscat(out, size, data->crddet.lastname);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_expirationdate
 *
 * Purpose      :  Set PAN expiration date
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_expirationdate(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	/* *((long *)out) = data->crddet.expdate; */
	
	DBG_PRINTF((dbg_progdetail, "tknexpdate[%s]", data->bpdtkndeviceprov.tknexpdate));
	sscanf(data->bpdtkndeviceprov.tknexpdate, "%08ld", (long *)out);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_lastissuedate
 *
 * Purpose      :  Set PAN issue date
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_lastissuedate(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	/* *((long *)out) = data->crddet.effdate; */
	
	DBG_PRINTF((dbg_progdetail, "bindingdate [%s]", data->bpdtkndeviceprov.bindingdate));
	sscanf(data->bpdtkndeviceprov.bindingdate, "%08ld", (long *)out);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_plasticissuetype_crddet
 *
 * Purpose      :  Set card issue type for most recently issued payment instrument
 * 		   (getting by CRDDET)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_plasticissuetype_crddet(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	CRDBTCH_t	crdbtch;
	CRDBTCH_HASH_t	crdbtch_hash;
	char tmpbuf[64], *pis12tmap;

	memset(&crdbtch, 0, sizeof(crdbtch));

	crdbtch_hash.batch = data->crddet.batch;
	if (SUCCEED != CRDBTCHgetbyCRDBTCH_HASH(&crdbtch, &crdbtch_hash))
	{
		DBG_PRINTF((dbg_syswarn, "Failed to get CRDBTCH [batch:%ld] from DB", crdbtch_hash.batch));
	}
	sprintf(tmpbuf, "%hd", crdbtch.btchtyp);
	pis12tmap = map_table(tmpbuf, map_pis12plasticissuetype);
	if (NULL != pis12tmap)
	{
		slstrcpy_se(out, size, pis12tmap);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_plasticissuetype_token
 *
 * Purpose      :  Set card issue type for most recently issued payment instrument
 * 		   (getting by TOKEN)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_plasticissuetype_token(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, "T");	/* Token or virtual card issue */

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_incentive
 *
 * Purpose      :  Set incentive program associated with the PAN
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_incentive(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, "N");	/* None */

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_currencycode
 *
 * Purpose      :  Set ISO numeric currency code
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_currencycode(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	slstrcpy_se(out, size, data->accdet.currcode);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_currencyconversionrate
 *
 * Purpose      :  Set the multiplicative currency conversion rate that is used 
 * 		   to convert the currency specified in `currencycode` field to USD
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_currencyconversionrate(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	forex_t forex;
	long l_date = 0, l_time = 0;

	/*e5706717*/
	if (SUCCEED != tenant_local_date_time(data->inst.id, &l_date, &l_time))
	{
		DBG_PRINTF((dbg_syserr,"Cannot calculate the local date & time for inst_id: (%ld)",
 			data->inst.id));
		ret = FAIL;
	}
	else if (SUCCEED != dbforex_get_rate(&forex, data->inst.id, DFLT_FOREX_REF, "840", data->accdet.currcode, l_date, l_time))
	{
		DBG_PRINTF((dbg_syserr, "Failed to get FOREX currency conversion rate: %s->%s",
			data->accdet.currcode, "840"));
		ret = FAIL;
	}
	else
	{
		*((double *)out) = forex.sellrate;		
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_creditlimit
 *
 * Purpose      :  Set credit limit for the PAN. 
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  Expressed in full units of the currency specified in `currencycode` field
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_creditlimit(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	*((double *)out) = data->accdet.credit_limit;

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_dailyposlimit
 *
 * Purpose      :  Set daily limit for POS transactions for the PAN.
 *
 * Parameters   :  data (in/out) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  Expressed in full units of the currency specified in `currencycode` field
 * 
 * Note		:  Get the CRDPRODLIM at once if it's still empty
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_dailyposlimit(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	ret = pis12delta_get_crdprodlim(data);
	if (SUCCEED == ret)
	{
		*((double *)out) = data->crdprodlim.purchlim_amt;
	}
	else if (SQE_EOFERR == ret)
	{
		ret = SUCCEED;
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_dailycashlimit
 *
 * Purpose      :  Set daily limit for cash (ATM) transactions for the PAN
 *
 * Parameters   :  data (in/out) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  Expressed in full units of the currency specified in `currencycode` field
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_dailycashlimit(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	ret = pis12delta_get_crdprodlim(data);
	if (SUCCEED == ret)
	{
		*((double *)out) = data->crdprodlim.cashlim_amt;		
	}
	else if (SQE_EOFERR == ret)
	{
		ret = SUCCEED;
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_mediatype_crddet
 *
 * Purpose      :  Set medium carrying the payment information
 * 		   (getting by CRDDET->CRDPRODUCT)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_mediatype_crddet(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	if ('0' == data->crdproduct.features[CRDPRODUCT_FEATURES_OFF_PEMAG])
	{
		slstrcpy_se(out, size, "M");	/* Magnetic-stripe card */
	}
	else if ('0' == data->crdproduct.features[CRDPRODUCT_FEATURES_OFF_PEEMV])
	{
		slstrcpy_se(out, size, "C");	/* Chip card */
	}
	else if ('0' == data->crdproduct.features[CRDPRODUCT_FEATURES_OFF_PEEMVCL])
	{
		slstrcpy_se(out, size, "D");	/* Contactless-capable chip card */
	}
	else if ('0' == data->crdproduct.features[CRDPRODUCT_FEATURES_OFF_PEMAGCL])
	{
		slstrcpy_se(out, size, "N");	/* Contactless-capable magnetic-stripe card */
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_mediatype_token
 *
 * Purpose      :  Set medium carrying the payment information
 * 		   (getting by TOKEN)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_mediatype_token(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	
	slstrcpy_se(out, size, "P");	/* Mobile Phone */

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_aipstatic
 *
 * Purpose      :  Set the value that indicates the ability of a chip card 
 * 		   to support Static Data Authentication (SDA) as part of 
 * 		   the Application Interchange Profile
 *
 * Parameters   :  data (in/out) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 * 
 * Note		:  Fetch the EMVCONF and EMVPROFILE at once if it's still empty
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_aipstatic(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	if (0 == data->emvconf.id
	    && SUCCEED != lookup_crdprodetal_id(data->crddet.crdproduct_id,
						NULL, NULL, &data->emvprofile,
						&data->emvconf, NULL, NULL, NULL, NULL))
	{
		DBG_PRINTF((dbg_syswarn, "Failed to get EMV configuration for card product [id:%ld]",
			data->crddet.crdproduct_id));
	}
	else if (0 < data->emvconf.id)
	{
		slstrcpy_se(out, size, 1 == data->emvconf.emvoda ? "Y" : "N");
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_aipdynamic
 *
 * Purpose      :  Set the value that indicates the ability of a chip card 
 * 		   to support Dynamic Data Authentication (DDA) as part of 
 * 		   the Application Interchange Profile
 *
 * Parameters   :  data (in/out) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 * 
 * Note		:  Fetch the EMVCONF and EMVPROFILE at once if it's still empty
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_aipdynamic(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	if (0 == data->emvconf.id
	    && SUCCEED != lookup_crdprodetal_id(data->crddet.crdproduct_id,
						NULL, NULL, &data->emvprofile,
						&data->emvconf, NULL, NULL, NULL, NULL))
	{
		DBG_PRINTF((dbg_syswarn, "Failed to get EMV configuration for card product [id:%ld]",
			data->crddet.crdproduct_id));
	}
	else if (0 < data->emvconf.id)
	{
		slstrcpy_se(out, size, 2 == data->emvconf.emvoda ? "Y" : "N");
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_chipspecification
 *
 * Purpose      :  Set chip specification
 *
 * Parameters   :  data (in/out) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 * 
 * Note		:  Fetch the EMVPROFILE and EMVCONF at once if it's still empty
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_chipspecification(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	char tmpbuf[64], *pis12tmap;

	if (0 == data->emvprofile.id
	    && SUCCEED != lookup_crdprodetal_id(data->crddet.crdproduct_id,
						NULL, NULL, &data->emvprofile,
						&data->emvconf, NULL, NULL, NULL, NULL))
	{
		DBG_PRINTF((dbg_syswarn, "Failed to get EMV profile for card product [id:%ld]",
			data->crddet.crdproduct_id));
	}
	
	sprintf(tmpbuf, "%hd", data->emvprofile.scheme);
	pis12tmap = map_table(tmpbuf, map_pis12emvscheme);
	if (NULL != pis12tmap)
	{
		slstrcpy_se(out, size, pis12tmap);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_chipspecversion
 *
 * Purpose      :  Set chip specification version
 *
 * Parameters   :  data (in/out) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 * 
 * Note		:  Fetch the EMVPROFILE and EMVCONF at once if it's still empty
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_chipspecversion(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	char tmpbuf[64], *pis12tmap;

	if (0 == data->emvprofile.id
	    && SUCCEED != lookup_crdprodetal_id(data->crddet.crdproduct_id,
						NULL, NULL, &data->emvprofile,
						&data->emvconf, NULL, NULL, NULL, NULL))
	{
		DBG_PRINTF((dbg_syswarn, "Failed to get EMV profile for card product [id:%ld]",
			data->crddet.crdproduct_id));
	}

	if (EMVSCH_VISA == data->emvprofile.scheme)
	{
		sprintf(tmpbuf, "%hd", data->emvprofile.chipref);
		pis12tmap = map_table(tmpbuf, map_pis12emvchipref);
		if (NULL != pis12tmap)
		{
			slstrcpy_se(out, size, pis12tmap);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  pis12delta_get_crdprodlim
 *
 * Purpose      :  Fetch the CRDPRODLIM record from DB
 *
 * Parameters   :  data (in/out) - Pointer to structure of source data for PIS12
 *
 * Returns      :  SUCCEED / FAIL / SQE_EOFERR
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int pis12delta_get_crdprodlim(PIS12_Data_t *data)
{
	int ret = SUCCEED;
	CRDPRODLIM_HASH_t crdprodlim_hash;

	if (data->crddet.crdproduct_id != data->crdprodlim.crdproduct_id)
	{
		crdprodlim_hash.crdproduct_id = data->crddet.crdproduct_id;
		ret = CRDPRODLIMgetbyCRDPRODLIM_HASH(&data->crdprodlim, &crdprodlim_hash);
		if (SUCCEED != ret)
		{
			DBG_PRINTF((dbg_syswarn, "Failed to get CRDPRODLIM [crdproduct_id:%ld] from DB",
				crdprodlim_hash.crdproduct_id));
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  pis12delta_decrypt_pan
 *
 * Purpose      :  Decrypt an encrypted PAN
 *
 * Parameters   :  enc (in) - Encrypted PAN
 * 		   clr (out) - Clear PAN
 * 		   sizeclr (in) - Size of clear PAN buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int pis12delta_decrypt_pan(char *enc, char *clr, size_t sizeclr)
{
	int ret = SUCCEED;
	char pan_clr[PAN_LEN_MAX] = {EOS};

	memset(pan_clr, 0, sizeof(pan_clr));
#ifndef TESTNOENC
	if (NULL != decryptPanSize(pan_clr, sizeof(pan_clr), enc))
	{
		slstrcpy_se(clr, sizeclr, pan_clr);
	}
	else
#endif
	{
#if defined(TESTTEST) || defined(TESTNOENC)
		slstrcpy_se(clr, sizeclr, enc);
#else
		ret = FAIL;
#endif
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  pis12_delta_map
 *
 * Purpose      :  Generate PIS12_DELTA by corresponded data convert table
 *
 * Parameters   :  p_pis12delta (out) - Pointer to PIS12_DELTA record
 * 		   p_pis12data (in/out) - Pointer to structure of source data for PIS12
 * 		   p_convtab (in) - Pointer to convert table
 * 		   dim (in) - Number of elements in convert table
 * 		   errorignore (in) - Ignore errors
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int pis12_delta_map(PIS12_DELTA_t *p_pis12delta, PIS12_Data_t *p_pis12data,
			       pis12_delta_cnv_t *p_convtab, size_t dim, ctxbool errorignore)
{
	int ret = SUCCEED;
	pis12_delta_cnv_t *p_ct;
	int f;
	char *p;

	for (f = 0, p_ct = p_convtab; SUCCEED == ret && f < (int)dim; ++f, ++p_ct)
	{
		p = ((char *)p_pis12delta) + p_ct->offset;
		if (NULL != p_ct->p_convfn)
		{
			ret = p_ct->p_convfn(p_pis12data, p, p_ct->len);
		}
		
		if (errorignore)
		{
			ret = SUCCEED;
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  set_workflow
 *
 * Purpose      :  Set configured value for workflow
 *
 * Parameters   :  workflow (in) - Name of the workflow to be executed by Falcon Fraud Manager
 *
 * Returns      :  void
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxpublic void set_workflow(char *workflow)
{
	slstrcpy_sen(M_workflow, workflow);
}

/*------------------------------------------------------------------------
 *
 * Function     :  set_clientid
 *
 * Purpose      :  Set configured value for clientIdFromHeader
 *
 * Parameters   :  clientid (in) - Unique identifier for the client or subclient
 *
 * Returns      :  void
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxpublic void set_clientid(char *clientid)
{
	slstrcpy_sen(M_clientid, clientid);
}

/*------------------------------------------------------------------------
 *
 * Function     :  pis12_delta_map_crddet
 *
 * Purpose      :  Generate PIS12_DELTA for Card
 *
 * Parameters   :  p_pis12delta (out) - Pointer to PIS12_DELTA record
 * 		   p_pis12data (in) - Pointer to structure of source data for PIS12
 * 		   errorignore (in) - Ignore errors
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxpublic int pis12_delta_map_crddet(PIS12_DELTA_t *p_pis12delta, PIS12_Data_t *p_pis12data, ctxbool errorignore)
{
	return pis12_delta_map(p_pis12delta, p_pis12data, M_convtab_CRDDET_PIS12, DIM(M_convtab_CRDDET_PIS12), 
			       errorignore);
}

/*------------------------------------------------------------------------
 *
 * Function     :  pis12_delta_map_bpdtkndeviceprov
 *
 * Purpose      :  Generate PIS12_DELTA for Token
 *
 * Parameters   :  p_pis12delta (out) - Pointer to PIS12_DELTA record
 * 		   p_pis12data (in) - Pointer to structure of source data for PIS12
 * 		   errorignore (in) - Ignore errors
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxpublic int pis12_delta_map_bpdtkndeviceprov(PIS12_DELTA_t *p_pis12delta, PIS12_Data_t *p_pis12data, ctxbool errorignore)
{
	return pis12_delta_map(p_pis12delta, p_pis12data, M_convtab_TOKEN_PIS12, DIM(M_convtab_TOKEN_PIS12), 
			       errorignore);
}

/*------------------------------------------------------------------------
 *
 * Function     :  cust_strscat
 *
 * Purpose      :  Appends src string to dst, adjusting maximum capacity by the
 * 		   length of dst prior to appending.
 *
 * Parameters   :  dst (out) - destination buffer
 * 		   dstsize (in) - destination buffer capacity including NULL character
 * 		   src (in) - source string
 *
 * Returns      :  look in slstrncat_se definition
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int cust_strscat(char* dst, size_t dstsize, const char* src)
{
	size_t len, tailsize;

	len = strlen(src);
	tailsize = dstsize - strlen(dst);
	return slstrncat_se(dst, dstsize, src, tailsize > len ? len : tailsize-1);
}




/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_userdata04_token
 *
 * Purpose      :  Set userData04 field
 * 		   (getting by TOKEN)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_userdata04_token(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	
	char tokenstorageid[150];
	
	memset(tokenstorageid, 0, sizeof(tokenstorageid));
	strcpy(tokenstorageid, data->bpdtkndeviceprov.tokenstorageid);
	tokenstorageid[9] = 0;

	slstrcpy_se(out, size, tokenstorageid);	

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_userdata05_token
 *
 * Purpose      :  Set userData05 field
 * 		   (getting by TOKEN)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_userdata05_token(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	
	slstrcpy_se(out, size, data->bpdtkndeviceprov.tokenrequestorid);	

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_userdata07_token
 *
 * Purpose      :  Set userData07 field
 * 		   (getting by TOKEN)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_userdata07_token(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;
	
	char tokenstorageid[150];
	char * p_storageid2;
	
	memset(tokenstorageid, 0, sizeof(tokenstorageid));
	strcpy(tokenstorageid, data->bpdtkndeviceprov.tokenstorageid);
	p_storageid2 = tokenstorageid + 9;

	slstrcpy_se(out, size, p_storageid2);	

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_userindicator01_token
 *
 * Purpose      :  Set userindicator01 field
 * 		   (getting by TOKEN)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_userindicator01_token(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	char userIndicator1[10];
	
	memset(userIndicator1, 0, sizeof(userIndicator1));
	
	if (strcmp(data->bpdtkndeviceprov.capturemethod, "BANK_APP")==0)
		strcpy(userIndicator1, "1");
	else if (strcmp(data->bpdtkndeviceprov.capturemethod, "MANUAL")==0)
		strcpy(userIndicator1, "2");
	else
		strcpy(userIndicator1, " ");

	slstrcpy_se(out, size, userIndicator1);	

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_userindicator02_token
 *
 * Purpose      :  Set userindicator02 field
 * 		   (getting by TOKEN)
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_userindicator02_token(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	char userIndicator2[10];
	
	memset(userIndicator2, 0, sizeof(userIndicator2));
	
	if (strcmp(data->bpdtkndeviceprov.capturemethod, "BANK_APP")==0)
		strcpy(userIndicator2, "4");
	else if (strcmp(data->bpdtkndeviceprov.capturemethod, "MANUAL")==0)
		strcpy(userIndicator2, "3");
	else
		strcpy(userIndicator2, " ");

	slstrcpy_se(out, size, userIndicator2);	

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function     :  PIS12delta_numberofpaymentids
 *
 * Purpose      :  Set number of active tokens
 *
 * Parameters   :  data (in) - Pointer to structure of source data for PIS12
 * 		   out (out) - Pointer to destination buffer
 * 		   size (in) - Size of destination buffer
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  For token provisioning
 *
 *----------------------------------------------------------------------*/
ctxprivate int PIS12delta_numberofpaymentids(PIS12_Data_t *data, char *out, size_t size)
{
	int ret = SUCCEED;

	int bpdtkndeviceProvCount = 0;
	short sdevcount = 0;

	DBG_PRINTF((dbg_progdetail, "token_id[%ld]", data->bpdtkndeviceprov.token_id));
	
	ret = BPDTKNDEVICEPROV_count(data->bpdtkndeviceprov.token_id, &bpdtkndeviceProvCount);
	
	if (SUCCEED == ret)
	{
		sdevcount = bpdtkndeviceProvCount;
		DBG_PRINTF((dbg_progdetail, "count result[%d]", sdevcount));
		
		*((short *)out) = sdevcount;
	}
	else
	{
		DBG_PRINTF((dbg_fatal, "Error counting devices"));
	}
	
	return ret;
}


