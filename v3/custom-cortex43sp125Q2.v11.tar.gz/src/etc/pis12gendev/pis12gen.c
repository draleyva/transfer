/*-----------------------------------------------------------------------
 * 
 * File		: pis12gen.c 
 * 
 * Author	: Ruslans Vasiljevs - Raul Torres
 * 
 * Created	: 28/06/2022
 *
 * Purpose	: Process PIS12_LOG records and generate PIS12 data
 * 
 * Comments	: 
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
 *-----------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <stdint.h>

#include <cortex.h>
#include <tknfdef.h>
#include <cdbcrdprodetal.h>

#include <sldbg.h>
#include <slcfp.h>
#include <slclp.h>
#include <slstring.h>
#include <sldtm.h>
#include <slstrip.h>

#include <dbpis12deltarh.h>
#include <dbpis12logrh.h>
#include <dbpis12logrx.h>
#include <dblookuptocrddet.h>
#include <dblookuptobpdtkndeviceprov.h>
#include <crdcustjo.h>
#include <bpddbtkndeviceprovrh.h>
#include <dberr.h>

#include <pis12loghash.h>
#include <pis12deltacv.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define TAGNAME	"PIS12GEN"
#define EXCLUDE_STATUS_SIZE	65

#define FALCON_DEFAULT_WORKFLOW	"DEBIT"
#define FALCON_DEFAULT_CLIENTID	"BPDDB"

#define HASHMAP_ROUTINE_CRDDETID	0
#define HASHMAP_ROUTINE_BPDTKNDEVICEPROVID		1

#define PIS12LOG_LOOKUPTOCRDDET(FN)	FN,dblookuptocrddet_get_next,dblookuptocrddet_close_scan
#define PIS12LOG_LOOKUPTOBPDTKNDEVICEPROV(FN)	FN,dblookuptobpdtkndeviceprov_get_next,dblookuptobpdtkndeviceprov_close_scan

#define PIS12LOG_LOOKUP_STATUS_DONOT	0
#define PIS12LOG_LOOKUP_STATUS_READY	1
#define PIS12LOG_LOOKUP_STATUS_DONE	2

#define HINT_INSERT 'I'
#define CRDDET_STRING "CRDDET"
#define CRDDET_X_STRING "CRDDET_X"
#define CRDDET_INDEX 0
#define CRDDET_X_INDEX 1
#define CRDDET_MAX 2

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
typedef struct
{
    char *tablename;
    int (*beginscanfn)(char *, long);
    int (*getnextfn)(int, long *);
    int (*closescanfn)(int);
    int (*convfn)(char *, long *);
} pis12log_lookup_map_t;

typedef struct
{
    short kind;
    char *name;
    hashmap_t * (*add)(hashmap_t);
    hashmap_t * (*find)(long);
} hashmap_routine_t;

/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/* Name of the workflow to be executed by Falcon Fraud Manager */
ctxprivate char	M_workflow[16+1] = FALCON_DEFAULT_WORKFLOW;
/* Unique identifier for the client or subclient */
ctxprivate char	M_clientid[16+1] = FALCON_DEFAULT_CLIENTID;
/* Comma separated list of excluded CRDDET.statcode */
ctxprivate char	M_exclcrdstat[EXCLUDE_STATUS_SIZE] = CRDSTAT_UNISSUED;
/* Comma separated list of excluded BPDTKNDEVICEPROV.devstatus */
ctxprivate char	M_excltknstat[EXCLUDE_STATUS_SIZE] = {TKNSTATUS_INPROG, EOS};
/* Number of processed records requiring commit */
ctxprivate long	M_commitfreq = 1000;
/* Ignore errors */
ctxprivate ctxbool M_errorignore = FALSE;
/* Delta's counter*/
ctxprivate int32_t M_deltacounter = 0;

ctxprivate size_t M_hashed_memory_size_max = 65536; /* Hashed memory size max (KBytes) */

/*---------------------------Prototypes---------------------------------*/
ctxprivate int	init(int argc, char **argv);
ctxprivate void	hashmap_delete_all(void);
ctxprivate int	uninit(void);
ctxprivate int	pis12gen_process(void);
ctxprivate int	pis12log_process_deferred(void);
ctxprivate int	loop_crddetid_hashmap(void);
ctxprivate int	loop_bpdtkndeviceprovid_hashmap(void);
ctxprivate pis12log_lookup_map_t *pis12log_lookup_map_get(char *tablename, const pis12log_lookup_map_t *lookup_map);
ctxprivate int	pis12log_lookup_process(pis12log_hash_t *p_pis12log_hash,
					      pis12log_lookup_map_t *p_lookup,
					      long *p_breakpoint, 
					      hashmap_routine_t *p_hashmap_routine);
ctxprivate int	convert_to_id(char *keydata, long *p_id);
ctxprivate void sigdisp(int sig);

ctxprivate int	checkStatusDoDeletePi212log(PIS12_LOG_t pis12log);


ctxprivate pis12log_lookup_map_t M_pis12log_lookuptocrddet_map[] =
{
	/* tablename	beginscanfn getnextfn closescanfn					convfn */
	{ "CRDDET",	PIS12LOG_LOOKUPTOCRDDET(NULL),						convert_to_id },
	{ "CRDDET_X",	PIS12LOG_LOOKUPTOCRDDET(NULL),						convert_to_id },
	{ "PINSTHST",	PIS12LOG_LOOKUPTOCRDDET(NULL),						convert_to_id },
	{ "CUSTDET",	PIS12LOG_LOOKUPTOCRDDET(dbcustdet_lookuptocrddet_begin_scan),		NULL },
	{ "ACCDET",	PIS12LOG_LOOKUPTOCRDDET(dbaccdet_lookuptocrddet_begin_scan),		NULL },
	{ "CRDPRODUCT",	PIS12LOG_LOOKUPTOCRDDET(dbcrdproduct_lookuptocrddet_begin_scan),	NULL },
	{ "CRDFORMAT",	PIS12LOG_LOOKUPTOCRDDET(dbcrdformat_lookuptocrddet_begin_scan),		NULL },
	{ "CRDBTCH",	PIS12LOG_LOOKUPTOCRDDET(dbcrdbtch_lookuptocrddet_begin_scan),		NULL },
	{ "EMVPROFILE",	PIS12LOG_LOOKUPTOCRDDET(dbemvprofile_lookuptocrddet_begin_scan),	NULL },
	{ "EMVCONF",	PIS12LOG_LOOKUPTOCRDDET(dbemvconf_lookuptocrddet_begin_scan),		NULL },
	{ "CRDPRODLIM",	PIS12LOG_LOOKUPTOCRDDET(dbcrdproduct_lookuptocrddet_begin_scan),	NULL },
	{ NULL }
};

ctxprivate pis12log_lookup_map_t M_pis12log_lookuptobpdtkndeviceprov_map[] =
{
	/* tablename	beginscanfn getnextfn closescanfn				convfn */
	{ "CRDDET",	PIS12LOG_LOOKUPTOBPDTKNDEVICEPROV(dbcrddet_lookuptobpdtkndeviceprov_begin_scan),	NULL },
	{ "CRDDET_X",	PIS12LOG_LOOKUPTOBPDTKNDEVICEPROV(dbcrddet_lookuptobpdtkndeviceprov_begin_scan),	NULL },
	{ "PINSTHST",	PIS12LOG_LOOKUPTOBPDTKNDEVICEPROV(dbcrddet_lookuptobpdtkndeviceprov_begin_scan),	NULL },
	{ "CUSTDET",	PIS12LOG_LOOKUPTOBPDTKNDEVICEPROV(dbcustdet_lookuptobpdtkndeviceprov_begin_scan),	NULL },
	{ "ACCDET",	PIS12LOG_LOOKUPTOBPDTKNDEVICEPROV(dbaccdet_lookuptobpdtkndeviceprov_begin_scan),	NULL },
	{ "CRDPRODUCT",	PIS12LOG_LOOKUPTOBPDTKNDEVICEPROV(dbcrdproduct_lookuptobpdtkndeviceprov_begin_scan),	NULL },
	{ "CRDFORMAT",	PIS12LOG_LOOKUPTOBPDTKNDEVICEPROV(dbcrdformat_lookuptobpdtkndeviceprov_begin_scan),	NULL },
	{ "CRDBTCH",	PIS12LOG_LOOKUPTOBPDTKNDEVICEPROV(dbcrdbtch_lookuptobpdtkndeviceprov_begin_scan),	NULL },
	{ "EMVPROFILE",	PIS12LOG_LOOKUPTOBPDTKNDEVICEPROV(dbemvprofile_lookuptobpdtkndeviceprov_begin_scan),	NULL },
	{ "EMVCONF",	PIS12LOG_LOOKUPTOBPDTKNDEVICEPROV(dbemvconf_lookuptobpdtkndeviceprov_begin_scan),	NULL },
	{ "CRDPRODLIM",	PIS12LOG_LOOKUPTOBPDTKNDEVICEPROV(dbcrdproduct_lookuptobpdtkndeviceprov_begin_scan),	NULL },
	{ "BPDTKNDEVICEPROV",	PIS12LOG_LOOKUPTOBPDTKNDEVICEPROV(NULL),					convert_to_id },
	{ NULL }
};

ctxprivate hashmap_routine_t M_hashmap_routines[] =
{
	{ HASHMAP_ROUTINE_CRDDETID,	"CRDDET",	crddetid_hashmap_add,	crddetid_hashmap_find },
	{ HASHMAP_ROUTINE_BPDTKNDEVICEPROVID,	"BPDTKNDEVICEPROV",	bpdtkndeviceprovid_hashmap_add,	bpdtkndeviceprovid_hashmap_find },
};

/*------------------------------------------------------------------------
 *
 * Function     :  main
 *
 * Purpose      :  Start point of program execution
 *
 * Parameters   :  argc -> number of arguments passed on the command line
 *		   argv -> command line arguments in string form.
 *
 * Returns      :  program exit state (0 = normal termination)
 *
 * Comments     :
 *
 *----------------------------------------------------------------------*/
ctxpublic int	main( int argc, char **argv )
{
	int ret;

	ret = init( argc, argv );

	if (SUCCEED != ret)
	{
		fprintf(stderr,"failed during init\n");
	}

	if( SUCCEED != (ret = sql_open(NULL)) )
	{
		DBG_PRINTF((dbg_syserr, "Failed to open database"));
	}
	else if(SUCCEED != (ret = sql_begin()) )
	{
		DBG_PRINTF((dbg_syserr, "Failed to begin SQL"));
	}

	if (SUCCEED == ret)
	{
		ret = pis12gen_process();
	}

	if( SUCCEED == ret )
	{
		DBG_PRINTF((dbg_progdetail, "Commit..."));
		ret = sql_commit();
	}
	else
	{
		DBG_PRINTF((dbg_fatal, "Total used memory for hashed data: %ld bytes",
			hashmap_memory_size() + pis12loghash_memory_size()));
		DBG_PRINTF((dbg_progdetail, "Abort..."));
		sql_abort();
	}

	uninit();

	DBG_PRINTF((dbg_progdetail, "Finished - %s",
		(SUCCEED==ret) ? "OK" : "ERROR"));

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  init
 *
 * Purpose	:  Initialisation
 *
 * Parameters	:  argc, argv
 *
 * Returns	:  SUCCEED - initialized
 *		   FAIL - error
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	init( int argc, char **argv )
{
	int ret = SUCCEED;
static	ctxbool help = FALSE;
	FILE *fp = NULL;

static	clp_parm clp[]=
	{
		{'h', parm_truebool, sizeof(help), FALSE, &help},
		{0}
	};
static	cfp_parm cfp[]=
	{
		{"CLIENTID",          parm_string, sizeof(M_clientid),	  FALSE, M_clientid,   0},
		{"EXCLUDE_CRDSTATUS", parm_string, sizeof(M_exclcrdstat), FALSE, M_exclcrdstat,0},
		{"EXCLUDE_TKNSTATUS", parm_string, sizeof(M_excltknstat), FALSE, M_excltknstat,0},
		{"COMMITFREQ", parm_long, 0, FALSE, (void *)&M_commitfreq, 0},
		{"HASHED_MEMORY_MAX", parm_long, 0, FALSE, (void *)&M_hashed_memory_size_max, 0},
		{"ERROR_IGNORE", parm_truebool, 0, FALSE, (void *)&M_errorignore, 0},
		{0}
	};

static	cfp_parm cfp_falcon2[] =
	{
		{"WORKFLOW",	parm_string, sizeof(M_workflow),	FALSE,	M_workflow,	0},
		{0}
	};

	ret = clp_parse(argc, argv, clp);

	if (SUCCEED != ret || help)
	{
		fprintf( stderr,
			 "Usage:\t%s (does not require any command line options)\n",
			 argv[0] );
		exit(1);
	}

	/* handle signals */
	signal( SIGTERM, sigdisp );
	signal( SIGQUIT, sigdisp );
	signal( SIGINT,  sigdisp );
	signal( SIGALRM, sigdisp );
	signal( SIGSEGV, sigdisp );

	fp = cfp_open();
	if (fp)
	{
		if( SUCCEED != (ret=cfp_parse(fp, cfp, TAGNAME, NULL)) )
		{
			fprintf(stderr, "Failed to parse configuration file\n");
		}
		else if ( SUCCEED != (ret=cfp_parse_nodebug(fp, cfp_falcon2, "FALCON2", NULL)) )
		{
			DBG_PRINTF((dbg_syserr, "cfp_parse_nodebug failed [%s] (%s)",
				"FALCON2", cfp_errparm()));
		}
		fclose(fp);
	}
	else
	{
		fprintf(stderr, "cfp_open failed\n");
		ret = FAIL;
	}

	if (SUCCEED == ret)
	{
		DBG_SETNAME(TAGNAME);

		DBG_PRINTF((dbg_progdetail, "Configuration:"));
		DBG_PRINTF((dbg_progdetail, "WORKFLOW: [%s]", M_workflow));
		DBG_PRINTF((dbg_progdetail, "CLIENTID: [%s]", M_clientid));
		DBG_PRINTF((dbg_progdetail, "EXCLUDE_CRDSTATUS: [%s]", M_exclcrdstat));
		DBG_PRINTF((dbg_progdetail, "EXCLUDE_TKNSTATUS: [%s]", M_excltknstat));
		DBG_PRINTF((dbg_progdetail, "HASHED_MEMORY_MAX: [%ld]", M_hashed_memory_size_max));
		DBG_PRINTF((dbg_progdetail, "ERROR_IGNORE: [%s]", M_errorignore == TRUE ? "TRUE" : "FALSE"));
	}

	M_hashed_memory_size_max *= 1024; /* Convert KBytes to Bytes */
	set_workflow(M_workflow);
	set_clientid(M_clientid);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  pis12gen_process
 *
 * Purpose      :  Read all records from PIS12_LOG table and for each of
 * 		   the tables+keydata perform reverse lookup to CRDDET.id 
 * 		   then generate PIS12 data and perform insert into PIS12_DELTA
 *
 * Parameters   :  
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	pis12gen_process()
{
	int ret = SUCCEED;
	char *thisfn = "pis12gen_process";
	long pis12log_total_cnt = 0L;
	long pis12loghash_cnt = 0L;

	PIS12_LOG_t pis12log;
	pis12log_hash_t pis12log_hash, *p_pis12log_hash;
	pis12log_lookup_map_t *p_pis12log_lookup_map;
	short crddetid_lookup_status;
	short bpdtkndeviceprovid_lookup_status;
	ctxbool duplicate;
	int32_t crddetdiscard[CRDDET_MAX] = {0}; 
	ctxbool crddetfound[CRDDET_MAX];
	int32_t deletecount = 0;
	DBG_ENTRY(thisfn);

	hashmap_delete_all();
	
	ret = dbpis12log_begin_scan();
	while (SUCCEED == ret)
	{
		memset(&pis12log, 0, sizeof(pis12log));
		memset(&pis12log_hash, 0, sizeof(pis12log_hash));

		ret = dbpis12log_get_next(&pis12log);
		if (SUCCEED == ret)
		{
			DBG_PRINTF((dbg_progdetail, "pis12log.id[%ld]", pis12log.id));
			
			crddetid_lookup_status = PIS12LOG_LOOKUP_STATUS_DONOT;
			bpdtkndeviceprovid_lookup_status = PIS12LOG_LOOKUP_STATUS_DONOT;
			duplicate = FALSE;

			slstrscpy(pis12log_hash.tablename, pis12log.tablename);
			slstrscpy(pis12log_hash.keydata, pis12log.keydata);
			slstrscpy(pis12log_hash.indicator1, pis12log.indicator1);
			slstrscpy(pis12log_hash.indicator2, pis12log.indicator2);
			slstrscpy(pis12log_hash.indicator3, pis12log.indicator3);

			/**
			 * Discarding CRDDET & CRDDET_X insert records for further processing
			*/
			crddetfound[CRDDET_INDEX] = strcmp(pis12log_hash.tablename, CRDDET_STRING) == 0 && pis12log.hint[0] == HINT_INSERT;
			crddetfound[CRDDET_X_INDEX] = strcmp(pis12log_hash.tablename, CRDDET_X_STRING) == 0 && pis12log.hint[0] == HINT_INSERT;

			if(crddetfound[CRDDET_INDEX] || crddetfound[CRDDET_X_INDEX])
			{
				crddetfound[CRDDET_INDEX] ? ++crddetdiscard[CRDDET_INDEX] : ++crddetdiscard[CRDDET_X_INDEX];
			}
			else
			{
				p_pis12log_hash = pis12loghash_find(&pis12log_hash);
				if (p_pis12log_hash)
				{
					duplicate = TRUE;
					/*DBG_PRINTF((dbg_progdetail, "Table and key %s:%s found to be duplicate...",
						pis12log_hash.tablename, pis12log_hash.keydata));*/

					if (EOS != pis12log_hash.indicator1[0] 
						&& EOS == p_pis12log_hash->indicator1[0])
					{
						slstrscpy(p_pis12log_hash->indicator1, pis12log_hash.indicator1);
						DBG_PRINTF((dbg_progdetail, "indicator1 is set"));
					}
					if ('1' == pis12log_hash.indicator2[0] 
						&& pis12log_hash.indicator2[0] != p_pis12log_hash->indicator2[0])
					{
						slstrscpy(p_pis12log_hash->indicator2, pis12log_hash.indicator2);
						DBG_PRINTF((dbg_progdetail, "indicator2 is set"));
						crddetid_lookup_status = PIS12LOG_LOOKUP_STATUS_READY;
					}
					if ('1' == pis12log_hash.indicator3[0]
						&& pis12log_hash.indicator3[0] != p_pis12log_hash->indicator3[0])
					{
						slstrscpy(p_pis12log_hash->indicator3, pis12log_hash.indicator3);
						DBG_PRINTF((dbg_progdetail, "indicator3 is set"));
						bpdtkndeviceprovid_lookup_status = PIS12LOG_LOOKUP_STATUS_READY;
					}
				}
				else
				{
					if ('1' == pis12log_hash.indicator2[0])
					{
						crddetid_lookup_status = PIS12LOG_LOOKUP_STATUS_READY;
					}
					else if ('0' != pis12log_hash.indicator2[0])
					{
						DBG_PRINTF((dbg_syswarn, "Unknown indicator2: '%c'", 
							pis12log_hash.indicator2[0]));
					}
					if ('1' == pis12log_hash.indicator3[0])
					{
						bpdtkndeviceprovid_lookup_status = PIS12LOG_LOOKUP_STATUS_READY;
					}
					else if ('0' != pis12log_hash.indicator3[0])
					{
						DBG_PRINTF((dbg_syswarn, "Unknown indicator3: '%c'", 
							pis12log_hash.indicator3[0]));
					}
					
					if (PIS12LOG_LOOKUP_STATUS_READY == crddetid_lookup_status
						|| PIS12LOG_LOOKUP_STATUS_READY == bpdtkndeviceprovid_lookup_status)
					{
						p_pis12log_hash = pis12loghash_add(pis12log_hash);
						if (NULL == p_pis12log_hash)
						{
							DBG_PRINTF((dbg_fatal, "Failed to allocate memory "
								"on calling pis12loghash_add() "
								"for tablename: [%s], keydata: [%s]\n"
								"Used memory for PIS12_LOG hashed data: %ld bytes",
								pis12log_hash.tablename,
								pis12log_hash.keydata,
								pis12loghash_memory_size()));
							ret = FAIL;
							break;
						}

						++pis12loghash_cnt;
					}
				}
			}

			if (PIS12LOG_LOOKUP_STATUS_DONOT == crddetid_lookup_status
			    && PIS12LOG_LOOKUP_STATUS_DONOT == bpdtkndeviceprovid_lookup_status)
			{
				//DBG_PRINTF((dbg_progdetail, "%s [Id:%ld]", 
				//	(crddetfound[CRDDET_INDEX] || crddetfound[CRDDET_X_INDEX])?"discarded":"ignored", pis12log.id));

				if (duplicate || crddetfound[CRDDET_INDEX] || crddetfound[CRDDET_X_INDEX])
				{
					if (checkStatusDoDeletePi212log(pis12log)==1)
					{
						DBG_PRINTF((dbg_progdetail, "duplicate - after checking status ... deleting pis12log -> id[%ld]", pis12log.id));
						
						PIS12_LOGdelete(&pis12log);
						++deletecount;
					}
					else
					{
						DBG_PRINTF((dbg_progdetail, "after checking status ... will not be deleted -> pis12log -> id[%ld]", pis12log.id));
					}
					
				}
				continue;
			}
			
			if (PIS12LOG_LOOKUP_STATUS_READY == crddetid_lookup_status)
			{
				p_pis12log_lookup_map = pis12log_lookup_map_get(pis12log_hash.tablename,
										     M_pis12log_lookuptocrddet_map);
				if (NULL != p_pis12log_lookup_map)
				{
					ret = pis12log_lookup_process(p_pis12log_hash,
								      p_pis12log_lookup_map,
								      &p_pis12log_hash->crddet_breakpoint,
								      &M_hashmap_routines[HASHMAP_ROUTINE_CRDDETID]);
					if (SUCCEED == ret)
					{
						crddetid_lookup_status = PIS12LOG_LOOKUP_STATUS_DONE;		
					}
					else
					{
						break;
					}
				}
				else
				{
					DBG_PRINTF((dbg_syserr, "Could not found lookup to CRDDET routine "
						"in pis12log map for the table [%s]", pis12log_hash.tablename));
				}
			}
			else
			{
				p_pis12log_hash->crddet_breakpoint = FAIL;
			}
			
			if (PIS12LOG_LOOKUP_STATUS_READY == bpdtkndeviceprovid_lookup_status)
			{
				p_pis12log_lookup_map = pis12log_lookup_map_get(pis12log_hash.tablename,
										    M_pis12log_lookuptobpdtkndeviceprov_map);
				if (NULL != p_pis12log_lookup_map)
				{
					ret = pis12log_lookup_process(p_pis12log_hash,
								      p_pis12log_lookup_map,
								      &p_pis12log_hash->bpdtkndeviceprov_breakpoint,
								      &M_hashmap_routines[HASHMAP_ROUTINE_BPDTKNDEVICEPROVID]);
					if (SUCCEED == ret)
					{
						bpdtkndeviceprovid_lookup_status = PIS12LOG_LOOKUP_STATUS_DONE;		
					}
					else
					{
						break;
					}
				}
				else
				{
					DBG_PRINTF((dbg_syserr, "Could not found lookup to BPDTKNDEVICEPROV routine "
						"in pis12log map for the table [%s]", pis12log_hash.tablename));
				}
			}
			else
			{
				p_pis12log_hash->bpdtkndeviceprov_breakpoint = FAIL;
			}

			if (PIS12LOG_LOOKUP_STATUS_DONE == crddetid_lookup_status 
			    || PIS12LOG_LOOKUP_STATUS_DONE == bpdtkndeviceprovid_lookup_status)
			{
				if (checkStatusDoDeletePi212log(pis12log)==1)
				{
					DBG_PRINTF((dbg_progdetail, "after checking status ... deleting pis12log -> id[%ld]", pis12log.id));
					
					PIS12_LOGdelete(&pis12log);
					++deletecount;
				}
				else
				{
					DBG_PRINTF((dbg_progdetail, "after checking status ... will not be deleted -> pis12log -> id[%ld]", pis12log.id));
				}
			}
			else
			{
				pis12loghash_delete(p_pis12log_hash);
			}
			
			++pis12log_total_cnt;

			if (SUCCEED == ret && pis12loghash_cnt >= M_commitfreq)
			{
				if (SUCCEED != loop_crddetid_hashmap() 
				    || SUCCEED != loop_bpdtkndeviceprovid_hashmap() 
				    || SUCCEED != pis12log_process_deferred())
				{
					ret = FAIL;
				}
				else
				{
					ret = sql_commit_and_begin(pis12log_total_cnt, M_commitfreq);
					if (SUCCEED != ret)
					{
						DBG_PRINTF((dbg_syserr, "Failed to commit"));
					}
					else
					{
						hashmap_delete_all();
						pis12loghash_cnt = 0;
					}
				}
			}
		}
		else if (SQE_EOFERR != ret)
		{
			DBG_PRINTF((dbg_syserr, "Failed to fetch from PIS12_LOG"));
		}
	}

	if (SQE_EOFERR == ret)
	{
		DBG_PRINTF((dbg_proginfo, "No more records"));
		ret = SUCCEED;
	}

	dbpis12log_close_scan();

	if (SUCCEED == ret)
	{
		ret = loop_crddetid_hashmap();
	}
	
	if (SUCCEED == ret)
	{
		ret = loop_bpdtkndeviceprovid_hashmap();
	}

	if (SUCCEED == ret)
	{
		ret = pis12log_process_deferred();		
	}

	DBG_PRINTF((dbg_proginfo, "COUNTERS DELTA [%d] CRDDET discarded [%d] CRDDET_X discarded [%d] deleted [%d]", 
		M_deltacounter, crddetdiscard[CRDDET_INDEX], crddetdiscard[CRDDET_X_INDEX], deletecount));

	/*
	to ensure missing records
	*/
	ret = sql_commit_and_begin(0, 0);
	if (SUCCEED != ret)
	{
		DBG_PRINTF((dbg_syserr, "Failed to commit"));
	}

	DBG_EXIT(thisfn);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  pis12log_process_deferred
 *
 * Purpose      :  Process deferred PIS12LOG hash data
 *
 * Parameters   :  
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	pis12log_process_deferred(void)
{
	int ret = SUCCEED;
	char *thisfn = "pis12log_process_deferred";

	pis12log_hash_t *p_pis12log_hash;
	pis12log_lookup_map_t *p_pis12log_lookup_map;
	ctxbool breakpoint_found = FALSE;

	DBG_ENTRY(thisfn);

	while (SUCCEED == ret && M_hashed_memory_size_max <= hashmap_memory_size())
	{
		crddetid_hashmap_delete_all();
		bpdtkndeviceprovid_hashmap_delete_all();
		breakpoint_found = FALSE;

		PIS12LOG_HASH_ITER(pis12loghash_get(), p_pis12log_hash)
		{
			if (breakpoint_found
			    || 0 < p_pis12log_hash->crddet_breakpoint
			    || 0 < p_pis12log_hash->bpdtkndeviceprov_breakpoint)
			{
				breakpoint_found = TRUE;
			}
			else
			{
				continue;
			}

			/* Process if crddet_breakpoint if greater or equal to zero but 
			 * do not process if same time has breakpoint on lookup to BPDTKNDEVICEPROV -
			 * so crddet_breakpoint must be zero */
			if (FAIL < p_pis12log_hash->crddet_breakpoint && p_pis12log_hash->bpdtkndeviceprov_breakpoint <= 0)
			{
				p_pis12log_lookup_map = pis12log_lookup_map_get(p_pis12log_hash->tablename,
										M_pis12log_lookuptocrddet_map);
				if (NULL != p_pis12log_lookup_map)
				{
					ret = pis12log_lookup_process(p_pis12log_hash,
								      p_pis12log_lookup_map,
								      &p_pis12log_hash->crddet_breakpoint,
								      &M_hashmap_routines[HASHMAP_ROUTINE_CRDDETID]);
				}

				if (SUCCEED != ret)
				{
					break;
				}
			}

			/* Process if bpdtkndeviceprov_breakpoint if greater or equal to zero but 
			 * do not process if same time has breakpoint on lookup to CRDDET -
			 * so bpdtkndeviceprov_breakpoint must be zero */
			if (FAIL < p_pis12log_hash->bpdtkndeviceprov_breakpoint && p_pis12log_hash->crddet_breakpoint <= 0)
			{
				p_pis12log_lookup_map = pis12log_lookup_map_get(p_pis12log_hash->tablename,
										M_pis12log_lookuptobpdtkndeviceprov_map);
				if (NULL != p_pis12log_lookup_map)
				{
					ret = pis12log_lookup_process(p_pis12log_hash,
								      p_pis12log_lookup_map,
								      &p_pis12log_hash->bpdtkndeviceprov_breakpoint,
								      &M_hashmap_routines[HASHMAP_ROUTINE_BPDTKNDEVICEPROVID]);
				}

				if (SUCCEED != ret)
				{
					break;
				}
			}

		}

		if (SUCCEED == ret)
		{
			ret = loop_crddetid_hashmap();
		}

		if (SUCCEED == ret)
		{
			ret = loop_bpdtkndeviceprovid_hashmap();
		}
	}

	DBG_EXIT(thisfn);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  loop_crddetid_hashmap
 *
 * Purpose      :  Loop over the hashed table to perform reverse lookup to CRDDET.id 
 * 		   then generate PIS12 data and create PIS12_DELTA record
 *
 * Parameters   :  
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	loop_crddetid_hashmap()
{
	int ret = SUCCEED;
	char *thisfn = "loop_crddetid_hashmap";
	
	PIS12_Data_t	pis12data;
	PIS12_DELTA_t	pis12delta;
	hashmap_t	*p_crddetid_hashmap;

	CRDDET_PK_t 	crddet_pk;
	BRANCH_t 	branch;

	char tmpexclstat[EXCLUDE_STATUS_SIZE] = {EOS}, *tmp;
	char tmpbuf[16];
	ctxbool exclude;

	DBG_ENTRY(thisfn);
	
	DBG_PRINTF((dbg_proginfo, "Start loop over the hashmap of crddetid"));
	HASHMAP_ITER(crddetid_hashmap_get(), p_crddetid_hashmap)
	{
		memset(&pis12data, 0, sizeof(pis12data));
		memset(&pis12delta, 0, sizeof(pis12delta));
		
		crddet_pk.id = p_crddetid_hashmap->id;
		if(SUCCEED != CRDCUST_CRDDET_PK_SELECT(&crddet_pk,
						       &pis12data.crddet,
						       &pis12data.custdet,
						       &pis12data.crdformat,
						       &pis12data.crdproduct,
						       &pis12data.accdet,
						       &branch,
						       &pis12data.inst))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get associated card (id: %ld) records", crddet_pk.id));
			ret = FAIL;
			break;
		}

		exclude = FALSE;

		strscpy(tmpexclstat, M_exclcrdstat);
		tmp = strtok(tmpexclstat,",");
		while(NULL != tmp)
		{
			strscpy(tmpbuf, tmp);
			if (0 == strcmp(pis12data.crddet.statcode, stp_both(tmpbuf)))
			{
				exclude = TRUE;
				break;
			}

			tmp = strtok(NULL, ",");
		}
		if (exclude)
		{
			DBG_PRINTF((dbg_syswarn, "Card with status [%s] will not be send to Falcon. "
				"Card [id:%ld] is missed.",
				pis12data.crddet.statcode,
				pis12data.crddet.id));
			continue;
		}

		pis12data.timestamp = utc_timestamp(NULL, 0);
		pis12data.keyword = p_crddetid_hashmap->keyword;

		if (pis12data.crddet.expdate < local_date())
		{
			DBG_PRINTF((dbg_syswarn, "Expired card [crddet_id:%ld] - ignore", pis12data.crddet.id));
		}
		else if (SUCCEED != pis12_delta_map_crddet(&pis12delta, &pis12data, M_errorignore))
		{
			DBG_PRINTF((dbg_syserr, "Failed to map PIS12_DELTA data"));
			ret = FAIL;
			break;
		}
		else if (SUCCEED != PIS12_DELTAadd(&pis12delta))
		{
			DBG_PRINTF((dbg_syserr, "Failed to add PIS12_DELTA record [crddet_id:%ld]",
				pis12delta.crddet_id));
			ret = FAIL;
			break;
		}
		else
		{
			/* Client-generated unique transaction ID that is unique across all
			 * data feeds for a specific installation of Falcon Fraud Manager */
			sprintf(pis12delta.externaltransactionid, "%ld", pis12delta.id);
			++M_deltacounter;
		}
	}
	DBG_PRINTF((dbg_proginfo, "End loop over the hashmap of crddetid"));

	DBG_EXIT(thisfn);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  checkStatusDoDeletePi212log
 *
 * Purpose      :  Check status in bpdtkndeviceprov to delete pis12log record
 *
 * Parameters   :  
 *
 * Returns      :  0 / 1
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	checkStatusDoDeletePi212log(PIS12_LOG_t pis12log)
{
	int	ret = 1;
	int ret2 = 0;
	
	long bpdtkndeviceprov_id = 0;
	
	BPDTKNDEVICEPROV_t		p_bpdtkndeviceprov;
	BPDTKNDEVICEPROV_IND_t p_bpdtkndeviceprov_ind;
	
	memset((void *)&p_bpdtkndeviceprov,  0, sizeof(p_bpdtkndeviceprov));
	memset((void *)&p_bpdtkndeviceprov_ind, 0, sizeof(p_bpdtkndeviceprov_ind));
	
	sscanf(pis12log.keydata, "%ld", &bpdtkndeviceprov_id);
	
	DBG_PRINTF((dbg_progdetail, "checkStatusDoDeletePi212log -> pis12log.keydata[%s], p_bpdtkndeviceprov_ind[%ld]",
										pis12log.keydata, bpdtkndeviceprov_id));
	
	ret2 = dbbpdtkndeviceprov_get_by_id_deletedincluded_nolock(bpdtkndeviceprov_id, &p_bpdtkndeviceprov, &p_bpdtkndeviceprov_ind);
	
	if (SUCCEED == ret2) 
	{
		DBG_PRINTF((dbg_progdetail, "BPDTKNDEVICEPROV found, token_id[%ld] devstatus[%s] token[%s] bindingdate[%s]", 
												p_bpdtkndeviceprov.token_id, p_bpdtkndeviceprov.devstatus,
												p_bpdtkndeviceprov.token, p_bpdtkndeviceprov.bindingdate));
		
		if (strcmp(p_bpdtkndeviceprov.devstatus, "I")==0)
		{
			ret = 0;
		}
	}
	else
	{
		DBG_PRINTF(( dbg_syserr, "BPDTKNDEVICEPROV record not found [%ld]", bpdtkndeviceprov_id));
	}
	
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  loop_bpdtkndeviceprovid_hashmap
 *
 * Purpose      :  Loop over the hashed table to perform reverse lookup to BPDTKNDEVICEPROV.id 
 * 		   then generate PIS12 data and create PIS12_DELTA record
 *
 * Parameters   :  
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	loop_bpdtkndeviceprovid_hashmap(void)
{
	int ret = SUCCEED;
	char *thisfn = "loop_bpdtkndeviceprovid_hashmap";

	PIS12_Data_t	pis12data;
	PIS12_DELTA_t	pis12delta;
	hashmap_t	*p_bpdtkndeviceprovid_hashmap;

	/* BPDTKNDEVICEPROV_PK2_t	bpdtkndeviceprov_pk; */
	BPDTKNDEVICEPROV_IND_t p_bpdtkndeviceprov_ind;	
	
	CRDDET_PK_t 	crddet_pk;
	TOKEN_PK_t	token_pk;
	BRANCH_t 	branch;

	char tmpexclstat[EXCLUDE_STATUS_SIZE] = {EOS}, *tmp;
	char tmpbuf[16];
	ctxbool exclude;

	DBG_ENTRY(thisfn);
	
	DBG_PRINTF((dbg_proginfo, "Start loop over the hashmap of bpdtkndeviceprovid"));
	HASHMAP_ITER(bpdtkndeviceprovid_hashmap_get(), p_bpdtkndeviceprovid_hashmap)
	{
		memset(&pis12data, 0, sizeof(pis12data));
		memset(&pis12delta, 0, sizeof(pis12delta));
				
		ret = dbbpdtkndeviceprov_get_by_id_deletedincluded_nolock(p_bpdtkndeviceprovid_hashmap->id, &pis12data.bpdtkndeviceprov, &p_bpdtkndeviceprov_ind);
		
		if (SUCCEED == ret)
		{
			DBG_PRINTF((dbg_progdetail, "BPDTKNDEVICEPROV id[%ld] found", p_bpdtkndeviceprovid_hashmap->id));
		}
		else if (SQE_EOFERR == ret)
		{
			DBG_PRINTF((dbg_proginfo, "BPDTKNDEVICEPROV id[%ld] not found --> ignore and continue", p_bpdtkndeviceprovid_hashmap->id));
			
			ret = SUCCEED;
			continue;
		}
		else
		{
			DBG_PRINTF((dbg_syserr, "Failed to get BPDTKNDEVICEPROV (id: %ld) from DB", p_bpdtkndeviceprovid_hashmap->id));
			ret = FAIL;
			break;
		}
			
		exclude = FALSE;

		strscpy(tmpexclstat, M_excltknstat);
		tmp = strtok(tmpexclstat,",");
		while(NULL != tmp)
		{
			strscpy(tmpbuf, tmp);
			if (0 == strcmp(pis12data.bpdtkndeviceprov.devstatus, stp_both(tmpbuf)))
			{
				exclude = TRUE;
				break;
			}

			tmp = strtok(NULL, ",");
		}
		if (exclude)
		{
			DBG_PRINTF((dbg_syswarn, "bpdtkndeviceprov with status [%s] will not be send to Falcon. "
				"bpdtkndeviceprov [id:%ld] is missed.",
				pis12data.bpdtkndeviceprov.devstatus,
				pis12data.bpdtkndeviceprov.id));
				
			continue;
		}
		
		token_pk.id = pis12data.bpdtkndeviceprov.token_id;
		if (SUCCEED != TOKENgetbyTOKEN_PK(&pis12data.token, &token_pk))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get TOKEN (id: %ld) from DB", token_pk.id));
			ret = FAIL;
			break;
		}

		crddet_pk.id = pis12data.token.crddet_id;
		if(SUCCEED != CRDCUST_CRDDET_PK_SELECT(&crddet_pk,
						       &pis12data.crddet,
						       &pis12data.custdet,
						       &pis12data.crdformat,
						       &pis12data.crdproduct,
						       &pis12data.accdet,
						       &branch,
						       &pis12data.inst))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get associated card (id: %ld) records", crddet_pk.id));
			ret = FAIL;
			break;
		}

		pis12data.timestamp = utc_timestamp(NULL, 0);
		pis12data.keyword = p_bpdtkndeviceprovid_hashmap->keyword;

		if (SUCCEED != pis12_delta_map_bpdtkndeviceprov(&pis12delta, &pis12data, M_errorignore))
		{
			DBG_PRINTF((dbg_syserr, "Failed to map PIS12_DELTA data"));
			ret = FAIL;
			break;
		}

		if (SUCCEED != PIS12_DELTAadd(&pis12delta))
		{
			DBG_PRINTF((dbg_syserr, "Failed to add PIS12_DELTA record [bpdtkndeviceprov_id:%ld]",
				pis12delta.token_id));
			ret = FAIL;
			break;
		}
		else
		{
			/* Client-generated unique transaction ID that is unique across all
			 * data feeds for a specific installation of Falcon Fraud Manager */
			sprintf(pis12delta.externaltransactionid, "%ld", pis12delta.id);
			++M_deltacounter;
		}
	}
	DBG_PRINTF((dbg_proginfo, "End loop over the hashmap of bpdtkndeviceprovid"));

	DBG_EXIT(thisfn);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  pis12log_lookup_map_get
 *
 * Purpose      :  Find lookup routine in pis12log map for corresponded table
 *
 * Parameters   :  tablename - Table name
 * 		   lookup_map - Pointer to lookup map table
 *
 * Returns      :  Item of M_pis12log_lookuptocrddet_map or NULL if not found
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate pis12log_lookup_map_t *pis12log_lookup_map_get(char *tablename, const pis12log_lookup_map_t *lookup_map)
{
	while (NULL != lookup_map->tablename)
	{
		if (0 == strcmp(lookup_map->tablename, tablename))
		{
			break;
		}
		lookup_map++;
	}
	
	if (NULL == lookup_map->tablename)
	{
		return NULL;
	}

	return (pis12log_lookup_map_t *)lookup_map;
}

/*------------------------------------------------------------------------
 *
 * Function     :  avoid_scan
 *
 * Purpose      :  avoid scan of specific tables
 *
 * Parameters   :  tablename - table name
 *
 * Returns      :  1 / 0 
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/

int8_t avoid_scan(const char *tablename)
{
	return strcmp(tablename, "CRDBTCH") == 0;
}

/*------------------------------------------------------------------------
 *
 * Function     :  pis12log_lookup_process
 *
 * Purpose      :  Process the PIS12 log item and loading all resolved IDs to hashmap
 *
 * Parameters   :  p_pis12log_hash - Pointer to hashed PIS12 log item
 * 		   p_lookup - Pointer to lookup function set for table scan
 * 		   p_breakpoint - Pointer to breakpoint Id for table scan
 * 		   p_hashmap_routine - Pointer to hashmap routine
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	pis12log_lookup_process(pis12log_hash_t *p_pis12log_hash,
					      pis12log_lookup_map_t *p_lookup,
					      long *p_breakpoint,
					      hashmap_routine_t *p_hashmap_routine)
{
	int ret = SUCCEED;
	char *thisfn = "pis12log_lookup_process";
	int cursor;
	hashmap_t hashmap, *p_hashmap;
	char scanname[512];
	int8_t avoidscan = 0;
	memset(&hashmap, 0, sizeof(hashmap));

	DBG_ENTRY(thisfn);

	hashmap.keyword = p_pis12log_hash->indicator1;
	
	sprintf(scanname, "scan %s for keydata [%s]", p_lookup->tablename, p_pis12log_hash->keydata);

	if (M_hashed_memory_size_max < hashmap_memory_size() + sizeof(hashmap))
	{
		DBG_PRINTF((dbg_proginfo, "Hashed memory size limit reached. %s:%s - deferred", 
			p_pis12log_hash->tablename, p_pis12log_hash->keydata));
	}
	else if (NULL != p_lookup->convfn)
	{
		ret = p_lookup->convfn(p_pis12log_hash->keydata, &hashmap.id);
		if (SUCCEED == ret)
		{
			p_hashmap = p_hashmap_routine->find(hashmap.id);
			if (NULL == p_hashmap)
			{
				if (NULL == p_hashmap_routine->add(hashmap))
				{
					DBG_PRINTF((dbg_fatal, "Failed to allocate memory "
						"on calling hashmap_add() "
						"for %s.id: %ld\n"
						"Used memory for hashed data: %ld bytes",
						p_hashmap_routine->name,
						hashmap.id,
						hashmap_memory_size()));
					ret = FAIL;
				}
			}
			else if (NULL == p_hashmap->keyword
				 || EOS == p_hashmap->keyword[0])
			{
				p_hashmap->keyword = p_pis12log_hash->indicator1;
			}
		}
	}
	else if (NULL != p_lookup->beginscanfn && !(avoidscan = avoid_scan(p_lookup->tablename)))
	{
		int32_t counter = 0;

		DBG_PRINTF((dbg_progdetail, "Start %s, starting from %s.id = %ld",
			scanname, p_hashmap_routine->name, *p_breakpoint));

		ret = p_lookup->beginscanfn(p_pis12log_hash->keydata, *p_breakpoint);
		cursor = ret;

		if (FAIL != ret)
		{
			ret = SUCCEED;
		}

		while (SUCCEED == ret)
		{
			memset(&hashmap, 0, sizeof(hashmap));
			
			if (M_hashed_memory_size_max <= hashmap_memory_size())
			{
				break;
			}
			hashmap.keyword = p_pis12log_hash->indicator1;

			ret = p_lookup->getnextfn(cursor, &hashmap.id);
			if (SUCCEED == ret)
			{
				p_hashmap = p_hashmap_routine->find(hashmap.id);
				if (NULL == p_hashmap)
				{
					if (NULL == p_hashmap_routine->add(hashmap))
					{
						DBG_PRINTF((dbg_fatal, "Failed to allocate memory "
							"on calling hashmap_add() "
							"for %s.id: %ld\n"
							"Used memory for hashed data: %ld bytes",
							p_hashmap_routine->name,
							hashmap.id,
							hashmap_memory_size()));
						ret = FAIL;
					}
					else
					{
						//DBG_PRINTF((dbg_progdetail, "Hash : %ld", hashmap.id));
						++counter;
						*p_breakpoint = hashmap.id;
					}
				}
				else if (NULL == p_hashmap->keyword
					 || EOS == p_hashmap->keyword[0])
				{
					p_hashmap->keyword = p_pis12log_hash->indicator1;
				}
			}
			else if (SQE_EOFERR != ret)
			{
				DBG_PRINTF((dbg_syserr, "Failed to fetch on lookup for %s:%s",
					p_lookup->tablename, p_pis12log_hash->keydata));
			}
		}
		if (SQE_EOFERR == ret)
		{
			//DBG_PRINTF((dbg_proginfo, "No more records"));
			*p_breakpoint = 0;
			ret = SUCCEED;
		}
		p_lookup->closescanfn(cursor);

		DBG_PRINTF((dbg_progdetail, "End %s [S:%d]",
			scanname, counter));
	}

	if(avoidscan)
	{
		DBG_PRINTF((dbg_progdetail, "Avoiding %s",
			scanname));
	}

	DBG_EXIT(thisfn);
	
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function     :  convert_to_id
 *
 * Purpose      :  Check and convert keydata to CRDDET.id / BPDTKNDEVICEPROV.id
 *
 * Parameters   :  keydata - key data to lookup by
 * 		   p_id - pointer to value to return
 *
 * Returns      :  SUCCEED / FAIL
 *
 * Comments     :  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	convert_to_id(char *keydata, long *p_id)
{
	int ret = SUCCEED;
	char *ep;
	
	*p_id = strtol(keydata, &ep, 10);

	if (*ep != EOS)
	{
		DBG_PRINTF((dbg_syserr, "Invalid keydata: %s", keydata));
		ret = FAIL;
	}
	
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  hashmap_delete_all
 *
 * Purpose	:  Wrap everything up
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *------------------------------------------------------------------------*/

ctxprivate void hashmap_delete_all(void)
{
	int32_t crddetidcounter = crddetid_hashmap_delete_all();
	int32_t bpdtkndeviceprovidcounter = bpdtkndeviceprovid_hashmap_delete_all();
	int32_t logcounter = pis12loghash_delete_all();

	DBG_PRINTF((dbg_proginfo, "DELETE CRDDET [%d] BPDTKNDEVICEPROVID [%d] LOG [%d]", 
		crddetidcounter, bpdtkndeviceprovidcounter, logcounter));
}

/*------------------------------------------------------------------------
 *
 * Function	:  uninit
 *
 * Purpose	:  Wrap everything up
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *------------------------------------------------------------------------*/
ctxprivate int uninit(void)
{
	int ret = SUCCEED;
	sql_close();

	hashmap_delete_all();

	return ret;
}

/*------------------------------------------------------------------------
 *
 * function	: sigdisp
 *
 * purpose	: react on signal (no more hanging)
 *
 * parameters	: sig - signal which caused interrupt
 *
 * returns	: 
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate void sigdisp(int sig)
{

	DBG_PRINTF((dbg_progdetail,
		"!!!!!!!!!!  Interrupted: %d  !!!!!!!!!!", sig ));

	if( SIGALRM == sig )
	{
		signal( SIGALRM, sigdisp );
		DBG_PRINTF((dbg_syswarn, "Alarm signal"));
	}
	else if( SIGTERM == sig || SIGQUIT == sig || SIGINT == sig )
	{
		DBG_PRINTF((dbg_syserr, "Exiting due to receiving signal: %d", sig));
		DBG_PRINTF((dbg_progdetail, "Abort..."));
		sql_abort();
		
		uninit();
		exit( 1 );
	}
	else if( SIGSEGV == sig )
	{
		DBG_PRINTF((dbg_fatal, "Exiting due to receiving signal: %d", sig));
		DBG_PRINTF((dbg_fatal, "Total used memory for hashed data: %ld bytes",
			hashmap_memory_size() + pis12loghash_memory_size()));
	}
	else
	{
		DBG_PRINTF((dbg_syswarn, "Unexpected signal %d", sig));
	}
}
