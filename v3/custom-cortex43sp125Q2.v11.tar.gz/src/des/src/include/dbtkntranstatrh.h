/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDTKNTRANSTAT type defininitions (ORACLE)
 *
 * @author	Raul Torres
 *
 * @date	06 Oct 2020
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-2.0/src/des/src/include/dbtkntranstatrh.h#1 $
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBTKNTRANSTATRH_H
#define __DBTKNTRANSTATRH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/

/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table BPDTKNTRANSTAT
 */
typedef struct
{
	long	id;
	char	statcodefrom[3];
	char	statcodeto[3];
	char	action[21];
	char	enabled[2];	
} BPDTKNTRANSTAT_t;

/**
 * Structure of indicators for table  BPDTKNTRANSTAT 
 */
typedef struct
{
	short	id;
	short	statcodefrom;
	short	statcodeto;
	short	action;
	short	enabled;
} BPDTKNTRANSTAT_IND_t;

/**
 * Structure to retrieve BPDTKNTRANSTAT by Primary Key PK_BPDTKNTRANSTAT
 */
typedef struct
{
	long	id;
} BPDTKNTRANSTAT_PK_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/

#endif
