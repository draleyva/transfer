/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDTKNREQLOG type defininitions (ORACLE)
 *
 * @author	Raul Torres
 *
 * @date	06 Mar 2020
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-2.0/src/des/src/bpddeslib/bpddbtknrsplogrh.h#2 $
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __BPDDBTKNREQLOGRH_H
#define __BPDDBTKNREQLOGRH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table TKNRSPLOG
 */
typedef struct
{
	long	tknreqlog_id;
	char	walletid[128+1];
	char	cardacceptorid[32+1];
	char	cardacceptorname[256+1];
	char	leveloftrust[32+1];
	char	captmethod[64+1];
	char	crdscore[1+1];
	char	reasoncode[100+1];
	char	accountscore[1+1];
	char	language[3+1];
	char	provattemptondev[2+1];
	char	phonenumberscore[1+1];
	char	suspendcrdsinacc[2+1];
	char	dayslastaccact[4+1];
	char	numtranlastmonths[4+1];
	char	devwithactivetkns[2+1];
	char	activetknsalldev[4+1];
	char	dayslastaccchg[4+1];
	char	acccreationdate[32+1];
	char	acclastupddate[32+1];
	char	origtknreqid[11+1];
	char	cardholdername[256+1];
	char	sourceip[256+1];
	char	tknrqmerchantid[32+1];
	char	tokenstorageid[128+1];
	char	tokenstoragetype[32+1];
	char	crdexpdate[8+1];
	char	crdproduct[4+1];
	char	devicescore[1+1];
	char	walletscore[1+1];
} BPDTKNREQLOG_t;

/**
 * Structure of indicators for table  TKNRSPLOG 
 */
typedef struct
{
	short	tknreqlog_id;
	short	walletid;
	short	cardacceptorid;
	short	cardacceptorname;
	short	leveloftrust;
	short	captmethod;
	short	crdscore;
	short	reasoncode;
	short	accountscore;
	short	language;
	short	provattemptondev;
	short	phonenumberscore;
	short	suspendcrdsinacc;
	short	dayslastaccact;
	short	numtranlastmonths;
	short	devwithactivetkns;
	short	activetknsalldev;
	short	dayslastaccchg;
	short	acccreationdate;
	short	acclastupddate;
	short	origtknreqid;
	short	cardholdername;
	short	sourceip;
	short	tknrqmerchantid;
	short	tokenstorageid;
	short	tokenstoragetype;
	short	crdexpdate;
	short	crdproduct;
	short	devicescore;
	short	walletscore;
} BPDTKNREQLOG_IND_t;

/**
 * Structure to retrieve BPDTKNREQLOG by Primary Key PK_BPDTKNREQLOG
 */
typedef struct
{
	long	tknreqlog_id;
} BPDTKNREQLOG_PK_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
#define BPDTKNREQLOGadd(pdata)					BPDTKNREQLOGadd_IND(pdata, NULL)

#define BPDTKNREQLOGdump(p_BPDTKNREQLOG)				TKNRSPLOGdump_IND(p_BPDTKNREQLOG, NULL)
#define BPDTKNREQLOGdumplev(p_BPDTKNREQLOG, dbglev)			TKNREQLOGdumplev_IND(p_BPDTKNREQLOG, NULL, dbglev)

extern	int	BPDTKNREQLOGadd_IND(BPDTKNREQLOG_t *p_BPDTKNREQLOG, BPDTKNREQLOG_IND_t *p_BPDTKNREQLOG_IND);

extern	void	BPDTKNREQLOGdump_IND(BPDTKNREQLOG_t *p_BPDTKNREQLOG, BPDTKNREQLOG_IND_t *p_BPDTKNREQLOG_IND);
extern	void	BPDTKNREQLOGdumplev_IND(BPDTKNREQLOG_t *p_BPDTKNRSPLOG, BPDTKNREQLOG_IND_t *p_BPDTKNREQLOG_IND, int dbglev);

#endif
