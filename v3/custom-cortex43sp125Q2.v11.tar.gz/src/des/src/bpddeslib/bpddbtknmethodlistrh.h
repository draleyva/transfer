/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDTKNMETHODLIST type defininitions (ORACLE)
 *
 * @author	Raul Torres
 *
 * @date	06 Mar 2022
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-2.0/src/des/src/bpddeslib/bpddbtknmethodlistrh.h#1 $
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __BPDDBTKNMETHODLISTRH_H
#define __BPDDBTKNMETHODLISTRH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table BPDTKNMETHODLIST
 */
typedef struct
{
	long	id;
	long	token_id;
	char	cvm[100+1];
	char	cusamtype[100+1];
	char	custatmvalue[1000+1];
} BPDTKNMETHODLIST_t;

/**
 * Structure of indicators for table  BPDTKNMETHODLIST
 */
typedef struct
{
	short	id;
	short	token_id;
	short	cvm;
	short	cusamtype;
	short	custatmvalue;
} BPDTKNMETHODLIST_IND_t;

/**
 * Structure to retrieve BPDTKNMETHODLIST by Primary Key PK_BPDTKNMETHODLIST
 */
typedef struct
{
	long	token_id;
} BPDTKNMETHODLIST_PK_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
#define BPDTKNMETHODLISTadd(pdata)					BPDTKNMETHODLISTadd_IND(pdata, NULL)

#define BPDTKNMETHODLISTdump(p_BPDTKNMETHODLIST)				BPDTKNMETHODLISTdump_IND(p_BPDTKNMETHODLIST, NULL)
#define BPDTKNMETHODLISTdumplev(p_BPDTKNMETHODLIST, dbglev)			BPDTKNMETHODLISTdumplev_IND(p_BPDTKNMETHODLIST, NULL, dbglev)

extern	int	BPDTKNMETHODLISTadd_IND(BPDTKNMETHODLIST_t *p_BPDTKNMETHODLIST, BPDTKNMETHODLIST_IND_t *p_BPDTKNMETHODLIST_IND);

extern	void	BPDTKNMETHODLISTdump_IND(BPDTKNMETHODLIST_t *p_BPDTKNMETHODLIST, BPDTKNMETHODLIST_IND_t *p_BPDTKNMETHODLIST_IND);
extern	void	BPDTKNMETHODLISTdumplev_IND(BPDTKNMETHODLIST_t *p_BPDTKNMETHODLIST, BPDTKNMETHODLIST_IND_t *p_BPDTKNMETHODLIST_IND, int dbglev);

extern  int     BPDTKNMETHODLISTupdbyBPDTKNMETHODLIST_PK_IND(BPDTKNMETHODLIST_t *p_BPDTKNMETHODLIST, BPDTKNMETHODLIST_IND_t *p_BPDTKNMETHODLIST_IND, BPDTKNMETHODLIST_PK_t *p_BPDTKNMETHODLIST_PK);

#endif
