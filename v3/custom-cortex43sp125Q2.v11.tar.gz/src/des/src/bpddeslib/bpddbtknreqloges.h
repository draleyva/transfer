/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDTKNREQLOG access routines for managing database access (ORACLE)
 *
 * @author	Raul Torres
 *
 * @date	06 Mar 2020
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-2.0/src/des/src/bpddeslib/bpddbtknreqloges.h#2 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __BPDDBTKNREQLOGES_H
#define __BPDDBTKNREQLOGES_H

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	extern	long	BPDTKNREQLOGtknreqlog_id;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Macros-------------------------------------*/

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_BPDTKNREQLOG_t
	{
		long	tknreqlog_id;
		char	walletid[128+1];
		char	cardacceptorid[32+1];
		char	cardacceptorname[256+1];
		char	leveloftrust[32+1];
		char	captmethod[64+1];
		char	crdscore[1+1];
		char	reasoncode[100+1];
		char	accountscore[1+1];
		char	language[3+1];
		char	provattemptondev[2+1];
		char	phonenumberscore[1+1];
		char	suspendcrdsinacc[2+1];
		char	dayslastaccact[4+1];
		char	numtranlastmonths[4+1];
		char	devwithactivetkns[2+1];
		char	activetknsalldev[4+1];
		char	dayslastaccchg[4+1];
		char	acccreationdate[32+1];
		char	acclastupddate[32+1];
		char	origtknreqid[11+1];
		char	cardholdername[256+1];
		char	sourceip[256+1];
		char	tknrqmerchantid[32+1];
		char	tokenstorageid[128+1];
		char	tokenstoragetype[32+1];
		char	crdexpdate[8+1];
		char	crdproduct[4+1];
		char	devicescore[1+1];
		char	walletscore[1+1];
	} HOST_BPDTKNREQLOG_t;

	typedef struct HOST_BPDTKNREQLOG_IND_t
	{
		short	tknreqlog_id_ind;
		short	walletid_ind;
		short	cardacceptorid_ind;
		short	cardacceptorname_ind;
		short	leveloftrust_ind;
		short	captmethod_ind;
		short	crdscore_ind;
		short	reasoncode_ind;
		short	accountscore_ind;
		short	language_ind;
		short	provattemptondev_ind;
		short	phonenumberscore_ind;
		short	suspendcrdsinacc_ind;
		short	dayslastaccact_ind;
		short	numtranlastmonths_ind;
		short	devwithactivetkns_ind;
		short	activetknsalldev_ind;
		short	dayslastaccchg_ind;
		short	acccreationdate_ind;
		short	acclastupddate_ind;
		short	origtknreqid_ind;
		short	cardholdername_ind;
		short	sourceip_ind;
		short	tknrqmerchantid_ind;
		short	tokenstorageid_ind;
		short	tokenstoragetype_ind;
		short	crdexpdate_ind;
		short	crdproduct_ind;
		short	devicescore_ind;
		short	walletscore_ind;
	} HOST_BPDTKNREQLOG_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/

/*
#define BPDTKNREQLOGdump(p_BPDTKNREQLOG)				BPDTKNREQLOGdump_IND(p_BPDTKNREQLOG, NULL)
#define BPDTKNREQLOGdumplev(p_BPDTKNREQLOG, dbglev)			BPDTKNREQLOGdumplev_IND(p_BPDTKNREQLOG, NULL, dbglev)
*/
extern	int		BPDTKNREQLOGadd_IND(BPDTKNREQLOG_t *p_BPDTKNREQLOG, BPDTKNREQLOG_IND_t *p_BPDTKNREQLOG_IND);
extern	void	BPDTKNREQLOGcs2hsINS(BPDTKNREQLOG_t *p_BPDTKNREQLOG, BPDTKNREQLOG_IND_t *p_IND, HOST_BPDTKNREQLOG_t *hsData, HOST_BPDTKNREQLOG_IND_t *hsInd);
extern	void	BPDTKNREQLOGdump_IND(BPDTKNREQLOG_t *p_BPDTKNREQLOG, BPDTKNREQLOG_IND_t *p_BPDTKNREQLOG_IND);
extern	void	BPDTKNREQLOGdumplev_IND(BPDTKNREQLOG_t *p_BPDTKNEQPLOG, BPDTKNREQLOG_IND_t *p_BPDTKNREQLOG_IND, int dbglev);
extern	int		BPDTKNREQLOGhs2cs(BPDTKNREQLOG_t *p_BPDTKNREQLOG, BPDTKNREQLOG_IND_t *p_IND, HOST_BPDTKNREQLOG_t *hsData, HOST_BPDTKNREQLOG_IND_t *hsInd);

#endif
