/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDTKNDEVICEPROV access routines for managing database access (ORACLE)
 *
 * @author	Raul Torres
 *
 * @date	02 May 2024
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-2.0/src/des/src/bpddeslib/bpddbtkndeviceproves.h#2 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __BPDDBTKNDEVICEPROVES_H
#define __BPDDBTKNDEVICEPROVES_H

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	extern	long	BPDTKNDEVICEPROVtoken_id;
	extern	char	BPDTKNDEVICEPROVtokenstorageid[128+1];
	
	extern	char	BPDTKNDEVICEPROVtoken[19+1];
	extern	long	BPDTKNDEVICEPROVid;
	extern	char	BPDTKNDEVICEPROVtokenrequestorid[11+1];

	extern	long	BPDTKNDEVICEPROV_PKtoken_id;
	extern	char	BPDTKNDEVICEPROV_PKtokenstorageid[128+1];
	
	extern	char	TOKENpan[20];
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Macros-------------------------------------*/

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_BPDTKNDEVICEPROV_t
	{
		long	id;
		char	virtualcardid[64+1];
		char	devicebindingreference[64+1];
		char	tokenstorageid[128+1];
		char	tokenstoratype[32+1];
		char	manufacturer[32+1];
		long	token_id;
		char	devstatus[1+1];
		char	brand[16+1];
		char	model[16+1];
		char	tac[8+1];
		char	osversion[16+1];
		char	firmwareversion[16+1];
		char	phonenumber[20+1];
		char	fourlastdigitphonenumber[4+1];
		char	devicename[128+1];
		char	deviceid[64+1];
		char	androidlasttwo[2+1];
		char	deviceparentid[64+1];
		char	language[3+1];
		char	devicestateflags[2+1];
		char	serialnumber[64+1];
		char	timezone[10+1];
		char	timezonesettings[32+1];
		char	simserialnumber[24+1];
		char	imei[24+1];
		char	phonelosttime[4+1];
		char	networkoperator[16+1];
		char	networktype[32+1];
		char	walletproviderid[128+1];
		char	bindingdate[24+1];
		char	token[19+1];
		char	capturemethod[64+1];
		char	tokenrequestorid[11+1];
		char	tknexpdate[8+1];
	} HOST_BPDTKNDEVICEPROV_t;

	typedef struct HOST_BPDTKNDEVICEPROV_IND_t
	{
		short	id_ind;
		short	virtualcardid_ind;
		short	devicebindingreference_ind;
		short	tokenstorageid_ind;
		short	tokenstoratype_ind;
		short	manufacturer_ind;
		short	token_id_ind;
		short	devstatus_ind;
		short	brand_ind;
		short	model_ind;
		short	tac_ind;
		short	osversion_ind;
		short	firmwareversion_ind;
		short	phonenumber_ind;
		short	fourlastdigitphonenumber_ind;
		short	devicename_ind;
		short	deviceid_ind;
		short	androidlasttwo_ind;
		short	deviceparentid_ind;
		short	language_ind;
		short	devicestateflags_ind;
		short	serialnumber_ind;
		short	timezone_ind;
		short	timezonesettings_ind;
		short	simserialnumber_ind;
		short	imei_ind;
		short	phonelosttime_ind;
		short	networkoperator_ind;
		short	networktype_ind;
		short	walletproviderid_ind;
		short	bindingdate_ind;
		short	token_ind;
		short	capturemethod_ind;
		short	tokenrequestorid_ind;
		short	tknexpdate_ind;
	} HOST_BPDTKNDEVICEPROV_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/

/*
#define BPDTKNDEVICEPROVdump(p_BPDTKNDEVICEPROV)				BPDTKNDEVICEPROVdump_IND(p_BPDTKNDEVICEPROV, NULL)
#define BPDTKNDEVICEPROVdumplev(p_BPDTKNDEVICEPROV, dbglev)			BPDTKNDEVICEPROVdumplev_IND(p_BPDTKNDEVICEPROV, NULL, dbglev)
*/
extern	int		BPDTKNDEVICEPROVadd_IND(BPDTKNDEVICEPROV_t *p_BPDTKNDEVICEPROV, BPDTKNDEVICEPROV_IND_t *p_BPDTKNDEVICEPROV_IND);
extern	void	BPDTKNDEVICEPROVcs2hsINS(BPDTKNDEVICEPROV_t *p_BPDTKNDEVICEPROV, BPDTKNDEVICEPROV_IND_t *p_IND, HOST_BPDTKNDEVICEPROV_t *hsData, HOST_BPDTKNDEVICEPROV_IND_t *hsInd);
extern	void	BPDTKNDEVICEPROVdump_IND(BPDTKNDEVICEPROV_t *p_BPDTKNDEVICEPROV, BPDTKNDEVICEPROV_IND_t *p_BPDTKNDEVICEPROV_IND);
extern	void	BPDTKNDEVICEPROVdumplev_IND(BPDTKNDEVICEPROV_t *p_BPDTKNDEVICEPROV, BPDTKNDEVICEPROV_IND_t *p_BPDTKNDEVICEPROV_IND, int dbglev);

extern  int     BPDTKNDEVICEPROVupdbyBPDTKNDEVICEPROV_PK_IND(BPDTKNDEVICEPROV_t *p_BPDTKNDEVICEPROV, BPDTKNDEVICEPROV_IND_t *p_BPDTKNDEVICEPROV_IND, BPDTKNDEVICEPROV_PK_t *p_BPDTKNDEVICEPROV_PK);
extern  void    BPDTKNDEVICEPROVcs2hs(BPDTKNDEVICEPROV_t *p_BPDTKNDEVICEPROV, BPDTKNDEVICEPROV_IND_t *p_IND, HOST_BPDTKNDEVICEPROV_t *hsData, HOST_BPDTKNDEVICEPROV_IND_t *hsInd);
extern  int     BPDTKNDEVICEPROVhs2cs(BPDTKNDEVICEPROV_t *p_BPDTKNDEVICEPROV, BPDTKNDEVICEPROV_IND_t *p_IND, HOST_BPDTKNDEVICEPROV_t *hsData, HOST_BPDTKNDEVICEPROV_IND_t *hsInd);

#endif
