/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	BPDTKNDEVICEPROV type defininitions (ORACLE)
 *
 * @author	Raul Torres
 *
 * @date	02 May 2024
 *
 * $Id: //ps/cortex/latam/bpd/c/bpd-2.0/src/des/src/bpddeslib/bpddbtkndeviceprovrh.h#2 $
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __BPDDBTKNDEVICEPROVRH_H
#define __BPDDBTKNDEVICEPROVRH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table BPDTKNDEVICEPROV
 */
typedef struct
{
	long	id;
	char	virtualcardid[64+1];
	char	devicebindingreference[64+1];
	char	tokenstorageid[128+1];
	char	tokenstoratype[32+1];
	char	manufacturer[32+1];
	long	token_id;
	char	devstatus[1+1];
	char	brand[16+1];
	char	model[16+1];
	char	tac[8+1];
	char	osversion[16+1];
	char	firmwareversion[16+1];
	char	phonenumber[20+1];
	char	fourlastdigitphonenumber[4+1];
	char	devicename[128+1];
	char	deviceid[64+1];
	char	androidlasttwo[2+1];
	char	deviceparentid[64+1];
	char	language[3+1];
	char	devicestateflags[2+1];
	char	serialnumber[64+1];
	char	timezone[10+1];
	char	timezonesettings[32+1];
	char	simserialnumber[24+1];
	char	imei[24+1];
	char	phonelosttime[4+1];
	char	networkoperator[16+1];
	char	networktype[32+1];
	char	walletproviderid[128+1];
	char	bindingdate[24+1];
	char	token[19+1];
	char	capturemethod[64+1];
	char	tokenrequestorid[11+1];
	char	tknexpdate[8+1];
} BPDTKNDEVICEPROV_t;

/**
 * Structure of indicators for table  BPDTKNDEVICEPROV 
 */
typedef struct
{
	short	id;
	short	virtualcardid;
	short	devicebindingreference;
	short	tokenstorageid;
	short	tokenstoratype;
	short	manufacturer;
	short	token_id;
	short	devstatus;
	short	brand;
	short	model;
	short	tac;
	short	osversion;
	short	firmwareversion;
	short	phonenumber;
	short	fourlastdigitphonenumber;
	short	devicename;
	short	deviceid;
	short	androidlasttwo;
	short	deviceparentid;
	short	language;
	short	devicestateflags;
	short	serialnumber;
	short	timezone;
	short	timezonesettings;
	short	simserialnumber;
	short	imei;
	short	phonelosttime;
	short	networkoperator;
	short	networktype;
	short	walletproviderid;
	short	bindingdate;
	short	token;
	short	capturemethod;
	short	tokenrequestorid;
	short	tknexpdate;
} BPDTKNDEVICEPROV_IND_t;

/**
 * Structure to retrieve BPDTKNDEVICEPROV by Primary Key PK_BPDTKNDEVICEPROV
 */
typedef struct
{
	long	token_id;
	char	tokenstorageid[128+1];
} BPDTKNDEVICEPROV_PK_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
#define BPDTKNDEVICEPROVadd(pdata)					BPDTKNDEVICEPROVadd_IND(pdata, NULL)

#define BPDTKNDEVICEPROVdump(p_BPDTKNDEVICEPROV)				BPDTKNDEVICEPROVdump_IND(p_BPDTKNDEVICEPROV, NULL)
#define BPDTKNDEVICEPROVdumplev(p_BPDTKNDEVICEPROV, dbglev)			BPDTKNDEVICEPROVdumplev_IND(p_BPDTKNDEVICEPROV, NULL, dbglev)

extern	int	BPDTKNDEVICEPROVadd_IND(BPDTKNDEVICEPROV_t *p_BPDTKNDEVICEPROV, BPDTKNDEVICEPROV_IND_t *p_BPDTKNDEVICEPROV_IND);

extern	void	BPDTKNDEVICEPROVdump_IND(BPDTKNDEVICEPROV_t *p_BPDTKNDEVICEPROV, BPDTKNDEVICEPROV_IND_t *p_BPDTKNDEVICEPROV_IND);
extern	void	BPDTKNDEVICEPROVdumplev_IND(BPDTKNDEVICEPROV_t *p_BPDTKNDEVICEPROV, BPDTKNDEVICEPROV_IND_t *p_BPDTKNDEVICEPROV_IND, int dbglev);

extern  int     BPDTKNDEVICEPROVupdbyBPDTKNDEVICEPROV_PK_IND(BPDTKNDEVICEPROV_t *p_BPDTKNDEVICEPROV, BPDTKNDEVICEPROV_IND_t *p_BPDTKNDEVICEPROV_IND, BPDTKNDEVICEPROV_PK_t *p_BPDTKNDEVICEPROV_PK);

#endif
