-- primary key for custdet_x table
create unique index pk_custdet_x
	on custdet_x (id);

alter table custdet_x
	add constraint pk_custdet_x primary key (id);

