--
-- CRDPIN_FALCONMON_UPDATE  (Trigger) 
--
CREATE OR REPLACE TRIGGER CRDPIN_FALCONMON_UPDATE AFTER UPDATE ON CRDPIN
REFERENCING OLD old_crdpin NEW new_crdpin
FOR EACH ROW
DECLARE
    oldvalue1    NMON_LOG.oldvalue1%type;
BEGIN
	IF (:old_crdpin.pinblk <> :new_crdpin.pinblk) THEN
		IF (:old_crdpin.datechanged = to_date('22630831', 'YYYYMMDD')) THEN
			oldvalue1 := TO_CHAR(:old_crdpin.datecreated, 'YYYYMMDD');
		ELSE
			oldvalue1 := TO_CHAR(:old_crdpin.datechanged, 'YYYYMMDD');
		END IF;
	
		nmon_addlog('CRDPIN', :new_crdpin.crddet_id, 'U', '3020', 
			newvalue1=>TO_CHAR(SYSDATE, 'YYYYMMDD'),
			oldvalue1=>oldvalue1,
			newvalue2=>:new_crdpin.pintype,
			oldvalue2=>:old_crdpin.pintype
		);
	END IF;

END;
/

