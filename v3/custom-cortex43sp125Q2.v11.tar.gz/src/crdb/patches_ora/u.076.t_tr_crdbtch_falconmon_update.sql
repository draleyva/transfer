--
-- CRDBTCH_FALCONMON_UPDATE  (Trigger) 
--
CREATE OR REPLACE TRIGGER CRDBTCH_FALCONMON_UPDATE AFTER UPDATE ON CRDBTCH
REFERENCING OLD old_crdbtch NEW new_crdbtch
FOR EACH ROW
BEGIN
	IF (:old_crdbtch.btchtyp <> :new_crdbtch.btchtyp) THEN
		pis12_addlog('CRDBTCH', :new_crdbtch.batch, 'U', ind2=>'1');
	END IF;
END;
/

