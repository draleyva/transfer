--
-- CRDPRODLIM_FALCONMON_UPDATE  (Trigger) 
--
CREATE OR REPLACE TRIGGER CRDPRODLIM_FALCONMON_UPDATE AFTER UPDATE ON CRDPRODLIM
REFERENCING OLD old_crdprodlim NEW new_crdprodlim
FOR EACH ROW
BEGIN
	IF (:old_crdprodlim.cashlim_amt <> :new_crdprodlim.cashlim_amt
		or :old_crdprodlim.purchlim_amt <> :new_crdprodlim.purchlim_amt) THEN
			pis12_addlog('CRDPRODLIM', :new_crdprodlim.crdproduct_id, 'U', ind2=>'1', ind3=>'1');
	END IF;
END;
/

