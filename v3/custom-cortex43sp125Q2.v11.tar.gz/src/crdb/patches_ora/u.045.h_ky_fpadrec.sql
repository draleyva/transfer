-- foreign key for FPADREC table

ALTER TABLE FPADREC ADD CONSTRAINT fk_fpadrec_id_crddet
	FOREIGN KEY  (crddet_id) 
	REFERENCES CRDDET (id); 
