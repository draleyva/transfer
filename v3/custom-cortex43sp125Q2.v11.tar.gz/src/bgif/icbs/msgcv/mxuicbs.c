/*-----------------------------------------------------------------------
 *
 * File		: mxuicbs.c
 *
 * Author	: Alex Butikov
 *
 * Created	: Jan 2011
 *
 * Purpose	: Tables and special functions to drive Cortex ICBS interface
 *
 * Comments	: 
 *
 * Ident	: @(#) $Id: //depot/cortex/v2/main/src/bgif/iso93H/msgcv/mxuiso93H.c#14$
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
/*---------------------------Includes-----------------------------------*/

#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <sldbg.h>
#include <slfdbg.h>
#include <slnfb.h>
#include <sldtm.h>
#include <slmap.h>
#include <slfev.h>
#include <slntp.h>
#include <slnfb.h>
#include <slstrip.h>
#include <slnum.h>

#include <mxuiso2.h>
#include <cortex.h>
#include <cocbf.h>
#include <cocbfdef.h>
#include <cocurr.h>
#include <comsgtyp.h>
#include <encgen.h>
#include <vicntry.h>
#include <coctry.h>
#include <cocrd.fd.h>
#include <coint.fd.h>
#include <coencpanfb.h>
#include <coamtadd.h> /* BZWBK_DEV-25 */
#include <visa.fd.h>
#include <iso.fd.h>
#include <enc.fd.h>
#include <gendbcmd.h>
#include <cprdefs.h>
#include <vpantp.h>
#include <bpd_prod.fd.h>

#include "mxuicbs.h"
#include "icbscv.h"

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/

#define	SECREL_DFLT	"20010001"		/* 20: zone encryption	*/
						/* 01: ANSI DES PIN	*/
						/* 00: PIN Block=PIN+Fs	*/
						/* 01: Use working key 1*/
#define ORGMESS		"1200"			/* original message	*/
#define ENDOFARRAY	"EOA"
#define CUSTOMER	'0'
#define CUSTACC		'1'
#define CRDACC		'2'
#define ACCOUNT		'3'
#define EXCHRATE	'4'
#define CRDSTATUS	'5'
#define ACCOUNT2	'6'

#define	FLD_RATE	999

#define MTC_PREPAYPHONE	38	/* transaction code to be sent to ICBS	*/
				/* when a prepaid phone card		*/
				/* transaction is detected.		*/

/* hlg BPD_MAINT-131 VISA OCT changes  APR/2018 */				
#define FBNEEDMTICHANGE(x) (1 == fev_evbool(x, &cfb_needmtichg))
#define BPD_VISAOCT	"OCT"
				
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
static char rcsid[] = "$Id: //depot/cortex/v2/main/src/bgif/iso93H/msgcv/mxuiso93H.c#14$";

static char	*M_rawdata=NULL;	/* generic conversion buffer	*/
static int	*M_p_datalen;		/* length of converted data	*/
static f2i_t	*M_f2ibase;		/* base message F2I table	*/
static ctxbool	M_message_simulator = FALSE;
static ctxbool	M_use_conacc = FALSE;
static ctxbool	M_ignore_nou_accno = FALSE;
/* MV NMR023597 */
static ctxbool	M_vpan_over_pan = FALSE;
static ctxbool	M_conv_failed = FALSE;
static char	M_ath_aiid_code[AIID_LEN+1] = "";

/* hlg BPD_MAINT-131 VISA OCT changes  APR/2018 */
ctxprivate fld_cond_t cfb_needmtichg = { COND_FBOOL, NULL, "(C_MSGCLS == '1') && (C_TXNCODE==26)" };
static char M_octpcode[PCODELEN + 1] = ""; /* PCODE to be used for VISA OCT transaction default 26 = MTC_CHFUNDSXFER*/
static char M_octmti[MTILEN + 1] = ""; /* MTI to be used to VISA OCT transaction default 0100 */
static char M_cltoctpcode[PCODELEN + 1] = ""; /* PCODE to be used for identify VISA OCT transaction when host response*/

static int iprintdump = 0;

static map_tbl_t i2vrspc[] =
{
 { "000",	"00",	 STR },  /* approved				*/
 { "400",	"00",	 STR },  /* approved				*/
 { "800",	"00",	 STR },  /* approved				*/
 { "107",	"01",	 STR },  /* ref to crd issuer			*/
 { "108",	"02",	 STR },  /* ref to issuer special		*/
 { "109",	"03",	 STR },  /* invalid merchant			*/
 { "200",	"04",	 STR },  /* pick up				*/
 { "202",	"04",	 STR },  /* suspected fraud			*/
 { "100",	"05",	 STR },  /* do not honour			*/
 { "100",	"06",	 STR },  /* do not honour - FILE MAINT ONLY	*/
 { "207",	"07",	 STR },  /* pick up special			*/
 { "002",	"10",	 STR },  /* approved for partial amount		*/
 { "003",	"11",	 STR },  /* approved VIP - NEVER IN MSG, FM ONLY*/
 { "902",	"12",	 STR },  /* invalid txn				*/
 { "110",	"13",	 STR },  /* invalid amount			*/
 { "118",	"14",	 STR },  /* no card record			*/
 { "111",	"14",	 STR },	 /* invalid card number			*/
 { "100",	"15",	 STR },  /* no such issuer - SWITCH->Acq only	*/
 { "909",	"17",	 STR },  /* processing timed out at host	*/
 { "903",	"19",	 STR },  /* retry txn				*/
 { "110",	"23",	 STR },  /* unacceptable fee			*/
 { "904",	"30",	 STR },  /* format error    			*/
 { "902",	"31",	 STR },  /* invalid txn				*/
 { "101",	"33",	 STR },  /* expired card, pickup		*/
 { "202",	"34",	 STR },  /* suspected fraud			*/
 { "203",	"35",	 STR },  /* pick up, contact acq		*/
 { "204",	"36",	 STR },  /* restricted card			*/
 { "205",	"37",	 STR },  /* call security			*/
 { "106",	"38",	 STR },  /* pin tries exceeded			*/
 { "114",	"38",	 STR },  /* no credit account			*/
 { "902",	"40",	 STR },  /* function not supported		*/
 { "208",	"41",	 STR },  /* lost card				*/
 { "114",	"42",	 STR },  /* no universal account		*/
 { "209",	"43",	 STR },  /* stolen card				*/
 { "111",	"44",	 STR },  /* no invest account			*/
 { "116",	"51",	 STR },  /* insufficient funds			*/
 { "183",	"52",	 STR },  /* no account checking			*/
 { "114",	"53",	 STR },  /* no account savings			*/
 { "101",	"54",	 STR },  /* expired card			*/
 { "117",	"55",	 STR },  /* incorrect PIN			*/
 { "118",	"56",	 STR },  /* no card record			*/
 { "119",	"57",	 STR },  /* txn not permitted (C/H)		*/
 { "120",	"58",	 STR },  /* txn not permitted (TERM)		*/
 { "102",	"59",	 STR },	 /* suspected fraud (revmap)		*/
 { "103",	"60",	 STR },  /* contact acq				*/
 { "121",	"61",	 STR },  /* exceeds wd amt limit		*/
 { "104",	"62",	 STR },  /* restricted card			*/
 { "122",	"63",	 STR },  /* security violation			*/
 { "110",	"64",	 STR },  /* invalid amount			*/ 
 { "123",	"65",	 STR },  /* activity cnt exceeded		*/
 { "105",	"66",	 STR },  /* contact dec dept			*/
 { "200",	"67",	 STR },  /* pick up				*/
 { "907",	"68",	 STR },  /* issuer or switch down		*/ 
 { "106",	"75",	 STR },  /* PIN tries exceeded			*/
 { "206",	"75",	 STR },  /* PIN tries exceeded			*/
 { "120",	"77",	 STR },  /* txn not permitted (TERM)		*/
 { "903",	"88",	 STR },  /* retry transaction			*/
 { "906",	"96",	 STR },  /* cutoff in prgress			*/
 { "907",	"91",	 STR },  /* issuer or switch down		*/
 { "124",	"93",	 STR },  /* violation of law			*/
 { "913",	"94",	 STR },  /* duplicate transmission		*/
 { "915",	"95",	 STR },  /* pickup suspect counterfeit		*/
 { "909",	"96",	 STR },  /* system malfunction			*/
 { "1..",	"05",	 REGEX },  /* default deny			*/
 { "2..",	"04",	 REGEX },  /* default pick up			*/
 { "9..",	"96",	 REGEX },  /* default error			*/
 { "904",	"..",	 REGEX },  /* default format error    		*/
 { NULL }
};

/*---------------------------Prototypes---------------------------------*/
					/* ctxpublic functions		*/
ctxpublic	int jiso_init(void);
ctxpublic	void jiso_set_use_conacc(ctxbool use_conacc_f);
ctxpublic	void jiso_set_basefe(char *basefe);
ctxpublic	void jiso_set_ignore_nou_accno(void);
ctxpublic	ctxbool jiso_use_conacc(void);
ctxpublic	ctxbool jiso_use_basefe(void);
ctxpublic	ctxbool jiso_use_ignore_nou_accno(void);
ctxpublic	void set_vpan_over_pan(ctxbool vpanover_enabled);
ctxpublic	int jiso_i2f(char *p_iso, FBFR *p_fb, int *nfield);
ctxpublic	int jiso_f2i(FBFR *p_fb, char *p_iso, int *p_len);
					/* driver functions		*/
ctxprivate int I2Fterm(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Iterm(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fpan(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Ipan(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fcaid(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Icaid(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Frate(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Irate(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fmsgtyp(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Imsgtyp(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fprcode(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Iprcode(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Iamtset(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Istan(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fdtlocal(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Idtlocal(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Ftmlocal(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Itmlocal(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fdtxmit(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Idtxmit(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fposdc(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Iposdc(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fflt(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Iflt(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fcdbcd(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Icdbcd(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fcaloc(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Icaloc(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Isecrel(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fsecrel(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Iaddam(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Faddam(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Ienqn(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fact(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Iact(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fdrec(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Idrec(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Forgdat(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Iorgdat(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Iexpy(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fexpy(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Iacqctry(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Facqctry(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Iaprvlcode(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Ft2data(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2It2data(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Iaccid(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Faccid(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int I2Faddrspdata(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Iamtbill(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Famtbill(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Iaiid(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fotham(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Iotham(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Ifld44(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Ifld48(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Ifld60(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Ifld61(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Ifld70(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Ifld90(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Ifld95(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Ifld120(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Ifld123(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Ifld124(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Ffld44(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int I2Ffld48(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int I2Ffld60(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int I2Ffld61(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int I2Ffld70(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int I2Ffld90(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int I2Ffld95(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int I2Ffld120(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int I2Ffld123(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int I2Ffld124(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int I2Fpostdt(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Ipostdt(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Ffld126(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Ifld126(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Ffld62(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Ifld62(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Fcomm(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Icomm(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int I2Frrn(char *iso, FBFR *p_fb, i2f_t *p_i2f);
ctxprivate int F2Irrn(FBFR *p_fb, char *iso, i2f_t *p_i2f);
ctxprivate int F2Iascmmddicbs(FBFR *p_fb, char *iso, i2f_t *p_i2f);

ctxprivate int I2Ffld54(char *iso, FBFR *p_fb, i2f_t *p_i2f); /* Autorizaciones parciales */

				/* miscellaneous support functions	*/
ctxprivate int	setrule(FBFR *p_fb);
ctxprivate int	adjust_dp(FBFR *p_fb);
ctxprivate int	custmdhms2fb(char *buf, FBFR *p_fb, FLDID datefld, FLDID timefld);
ctxprivate int	visa_dp(FBFR *p_fb, FLDID fldno, int occ);
ctxprivate char	*nstrtok( char *src, char c );
ctxprivate int	get_sysdate(long* lpsysdate);
ctxprivate int	post_i2f(FBFR *p_fb);
ctxprivate int	amttxn(FBFR *p_fb, char *iso, i2f_t *p_i2f, ctxbool bfield3);
ctxprivate int	isosub2fb( FBFR *p_fb, int field_no, char *start, int field_type, int length, int occurrence );
ctxprivate int 	fb2isosub( FBFR *p_fb, int field_no, char *out, int field_type, int length, int occurrence );
ctxprivate	int	F2Irateconvert( double rate, char *out );
ctxprivate double	I2Frates( char * );
ctxprivate int	setaiidcode(FBFR *p_fb);
ctxprivate int	adjust_addamt(FBFR *p_fb);

ctxpublic void set_printdump(int print_dump);

/************************************************************************
 * Boolean conditions
 ************************************************************************/
ctxprivate fld_cond_t Bnomag =
/*      { COND_FBOOL, NULL, "!(C_T1DATA || C_T2DATA)" }; This doesnt work! PE */
	/* Expiry date not required on Advices */
        { COND_FBOOL, NULL, "!C_T1DATA && !C_T2DATA && (C_MSGFN != 2)" };
ctxprivate fld_cond_t Brepre =
	{ COND_FBOOL, NULL, "(C_FNCODE>=205) && (C_FNCODE<=207)" };
ctxprivate fld_cond_t Bpartrev =
	{ COND_FBOOL, NULL, "(C_FNCODE==401)" };
ctxprivate fld_cond_t Batmpartial =
	{ COND_FBOOL, NULL, "(C_FNCODE==401) && (C_CRDACPTBUS==6011)" };
ctxprivate fld_cond_t Binqbal =
	{ COND_FBOOL, NULL, "(C_TXNCODE==31) || (C_TXNCODE == 30)" };
ctxprivate fld_cond_t B5xx =
	{ COND_FBOOL, NULL, "(C_MSGCLS == '5')" };
ctxprivate fld_cond_t B8xx =
	{ COND_FBOOL, NULL, "(C_MSGCLS == '8')" };
ctxprivate fld_cond_t Bstxn =
	{ COND_FBOOL, NULL, "(C_ACTIONCODE == '0') && (C_RSPCODE == '00')" };
ctxprivate fld_cond_t B112x =
	{ COND_FBOOL, NULL, "(C_MSGCLS == '1') && (C_MSGFN == '2')" };
ctxprivate fld_cond_t Bkeyc =
	{ COND_FBOOL, NULL, "(C_FNCODE == 811)" };
					/* forex when different */
ctxprivate fld_cond_t Bfrx =
	{ COND_FBOOL, NULL, "(C_CURBILL != C_CURTXN)" };
/* This is a file maintainance response, but was it a successfull */
ctxprivate fld_cond_t Brspok =
	{ COND_FBOOL, NULL, "(C_ACTIONCODE == '3') &&(C_RSPCODE == '00')" };
/* Is this message a CUTOVER notification */
ctxprivate fld_cond_t Biscutover =
	{ COND_FBOOL, NULL, "(C_FNCODE == 821)" };
/* Is this message a CUSTOMER enquiry */
ctxprivate fld_cond_t Biscust =
	{ COND_FBOOL, NULL, "(C_FILENAME == 'CUSTOMER')" };
/* Is this message a CUSTOMER ACCOUNT enquiry */
ctxprivate fld_cond_t Biscustacc =
	{ COND_FBOOL, NULL, "(C_FILENAME == 'CUSTACC')" };
/* Is this message a CARD-ACCOUNT linkage */
ctxprivate fld_cond_t Biscrdacc =
	{ COND_FBOOL, NULL, "(C_FILENAME == 'CRDACC')" };
/* Is this message a ACCOUNT balance update */
ctxprivate fld_cond_t Bisaccbal =
	{ COND_FBOOL, NULL, "(C_FILENAME == 'ACCOUNT')" };
/* Is this message an exchange rate update */
ctxprivate fld_cond_t Bisxrate =
	{ COND_FBOOL, NULL, "(C_FILENAME == 'EXCHRATE')" };
/* Is this message a card status update */
ctxprivate fld_cond_t Biscrdstat =
	{ COND_FBOOL, NULL, "(C_FILENAME == 'CRDSTATUS')" };
/* Is this message a ACCOUNT balance refresh */
ctxprivate fld_cond_t Bisbalref =
	{ COND_FBOOL, NULL, "(C_FILENAME == 'ACCOUNT2')" };
ctxprivate fld_cond_t Bcrdread =
	{ COND_FBOOL, NULL, "(((C_POSCDIM == '2') || (C_POSCDIM == '9')) && C_T2DATA)" };
ctxprivate fld_cond_t Bcashback =
	{ COND_FBOOL, NULL, "(C_TXNCODE == 9)" };
ctxprivate fld_cond_t Bemvoff =
	{ COND_FBOOL, NULL, "(I_CRDPROD_OPT %% '1.*')" };
ctxprivate fld_cond_t Baurev =
	{ COND_FBOOL, NULL, "(C_MSGCLS == '4') && (C_MSGCLSORG == '2')" };

/************************************************************************
 * MAIN CONVERSION TABLES - CONTAINS ALL POSSIBLE ICBS FIELDS FOR ISO->FB
 ************************************************************************/
static i2f_t i2fbase[] =
/*	bmno, fldno, min_len, max_len, p_iso2fbfn, p_fb2isofn	*/
{
{ISO_MSGTYP,		BADFLDID,	 4,  4, I2Fmsgtyp, F2Imsgtyp, NULL},	/*0*/
{ISO_BITMAP,		C_BITMAP,	 8, 16, I2Fascbit, F2Iascbit, NULL},	/*1*/
{ISO_PAN,		BADFLDID,	 1, 19, I2Fpan, F2Ipan, NULL},	/*2*/
{ISO_PROCCODE,		BADFLDID,	 6,  6, I2Fprcode, F2Iprcode, NULL},	/*3*/
{ISO_AMTTXN,		BADFLDID,	12, 12, I2Famtbill, F2Iamtbill, NULL},/*4*/
{ISO_DTXMIT,		BADFLDID,	10, 10, I2Fdtxmit, F2Idtxmit, NULL},	/*7*/
{ISO_STAN,		C_STAN,		 6,  6, I2Fasc, F2Istan, NULL},	/*11*/
{ISO_TIMELOCAL,		BADFLDID,	 6,  6, I2Ftmlocal, F2Itmlocal, NULL},/*12*/
{ISO_DATELOCAL,		C_DATELOCAL,	 4,  4, I2Fascmmdd, F2Iascmmddicbs, NULL},/*13*/
{ISO_DATESET,		C_DATESET,	 4,  4, I2Fascmmdd, F2Iascmmdd, NULL},/*15*/
{ISO_DATECPT,		BADFLDID,	 4,  4, I2Fpostdt, F2Ipostdt, NULL},	/*17*/
{ISO_AMTTXNFEE,		BADFLDID,	 8,  8, I2Fcomm, F2Icomm, NULL},	/*28*/
{ISO_AIID,		C_AIID,		 1, 13, I2Fva2asc, F2Iva2asc, NULL},	/*32*/
{ISO_FIID,		C_FIID,		 1, 11, I2Fva2asc, F2Iva2asc, NULL},	/*33*/
{ISO_T2DATA,		BADFLDID,	 1, 37, I2Ft2data, F2It2data, NULL},	/*35*/
{ISO_RRN,		BADFLDID,	12, 12, I2Frrn, F2Irrn, NULL},	/*37*/
{ISO_APRVLCODE,		C_APRVLCODE,	 6,  6, I2Fasc, F2Iaprvlcode, NULL},	/*38*/
{ISO_RSPCODE,		BADFLDID,	 2,  2, I2Fact, F2Iact, NULL},	/*39*/
{ISO_TERMID,		BADFLDID,	16, 16, I2Fterm, F2Iterm, NULL},	/*41*/
{ISO_CRDACPTID,		C_CRDACPTID,	15, 15, I2Fcaid, F2Icaid, NULL},	/*42*/
{ISO_CRDACPTLOC,	BADFLDID,	40, 40, I2Fcaloc, F2Icaloc, NULL}, 	/*43*/
{ISO_ADDRSPDATA,	BADFLDID,	27, 27, I2Ffld44, F2Ifld44, NULL},	/*44*/
{ISO_ADDDATAPRI,	BADFLDID,	44, 44, I2Ffld48, F2Ifld48, NULL},	/*48*/
{ISO_CURTXN,		C_CURBILL,	 3,  3, I2Fasc, F2Iasc, NULL},	/*49*/
{ISO_PIN,		C_PIN,		16, 16, I2Fhex, F2Ihex, NULL},	/*52*/
{ISO_SECRELATED,	BADFLDID,	 1, 48, I2Fsecrel, F2Isecrel, NULL},	/*53*/
{ISO_ADDAMTS,		BADFLDID,	 1, 20, I2Ffld54, F2Iasc, NULL},	/*54*/  /* Autorizaciones parciales */
{ISO_ADDPOSINFO,	BADFLDID,	12, 12, I2Ffld60, F2Ifld60, NULL},	/*60*/
{ISO_OTHERAMTS,		BADFLDID,	13, 13, I2Ffld61, F2Ifld61, NULL},	/*61*/
{ISO_CPSFIELDS,		BADFLDID,	 1,  4, I2Ffld62, F2Ifld62, NULL},	/*62*/
{ISO_NETMGTINFO,	BADFLDID,	 3,  3,	I2Ffld70, F2Ifld70, NULL},	/*70*/
{ISO_ORGDATA,		BADFLDID,	42, 42, I2Ffld90, F2Ifld90, NULL},	/*90*/
{ISO_AMTRPLC,		BADFLDID,	42, 42, I2Ffld95, F2Ifld95, NULL},	/*95*/
{ISO_RIID,		C_RIID,		 1, 11, I2Fva2asc, F2Iva2asc, NULL},	/*100*/
{ISO_FILENAME,		C_FILENAME,	 1, 17, I2Fva2asc, F2Iva2asc, NULL},	/*101*/
{ISO_ACCID1,		BADFLDID,	 1, 28, I2Faccid, F2Iaccid, NULL},	/*102*/
{ISO_ACCID2,		BADFLDID,	 1, 28, I2Faccid, F2Iaccid, NULL},	/*103*/
{ISO_ORGMTID,		BADFLDID,	25, 33, I2Ffld120, F2Ifld120, NULL},	/*120*/
{ISO_ADDRVER,		BADFLDID,	 0,553, I2Ffld123, F2Ifld123, NULL},	/*123*/
{ISO_FREETXTJAP,	BADFLDID,	30, 30, I2Ffld124, F2Ifld124, NULL},	/*124*/
{ISO_RSVPRV126,		BADFLDID,	 1,600, I2Ffld126, F2Ifld126, NULL},	/*126*/
{LAST_BITMAPENT,	BADFLDID, 0, 0, NULL, NULL, NULL}
};

/**************************************************************************
 * SPECIFIC CONVERSION TABLES - CONTAIN SUBSETS OF ISO93 FIELDS FOR
 * SPECIFIC MESSAGE TYPES WHEN CONVERTING FB->ISO93
 **************************************************************************/

/**************************************************************************/
/* External Authorisation Request Messages:	100/110  	          */
/**************************************************************************/
ctxprivate f2i_t f2ijarq[] =
/*	bmno, req_f, req_cond, rsp_f, rsp_cond				*/
{
{ISO_PAN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 2 */
{ISO_PROCCODE,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 3 */
{ISO_AMTTXN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 4 */
{ISO_DTXMIT,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 7 */
{ISO_STAN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 11 */
{ISO_TIMELOCAL,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 12 */
{ISO_DATELOCAL,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 13 */
{ISO_DATECPT,		0,	NULL,	F_RET, 	NULL, 0, NULL, 0, NULL},	/* 17 */
{ISO_AMTTXNFEE,		F_OMIT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 28 */
{ISO_AIID,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 32 */
{ISO_T2DATA,		F_OMIT,	NULL,	F_RET,  NULL, 0, NULL, 0, NULL},	/* 35 */
{ISO_RRN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 37 */
{ISO_APRVLCODE,		F_OMIT,	NULL,	0,	NULL, 0, NULL, 0, NULL},	/* 38 */
{ISO_RSPCODE,		F_OMIT, NULL,	0,	NULL, 0, NULL, 0, NULL},	/* 39 */
{ISO_TERMID,		F_OPT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 41 */
{ISO_CRDACPTLOC,	0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 43 */
{ISO_ADDRSPDATA,	F_OMIT,	NULL,	0, 	NULL, 0, NULL, 0, NULL},	/* 44 */
{ISO_ADDDATAPRI,	0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 48 */
{ISO_CURTXN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 49 */
{ISO_PIN,		F_OMIT,	NULL,	F_OMIT,	NULL, 0, NULL, 0, NULL},	/* 52 */
{ISO_ADDAMTS,	F_OMIT,	NULL,	F_OPT,	NULL, 0, NULL, 0, NULL},	/* 54 */ /* Autorizaciones parciales */
{ISO_ADDPOSINFO,	0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 60 */
{ISO_CPSFIELDS,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 62 */
{ISO_RIID,		F_OPT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 100 */
{ISO_ACCID1,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 102 */
{ISO_ACCID2,		F_OPT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 103 */
{ISO_ORGMTID,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 120 */
{ISO_ADDRVER,		F_OPT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 123 */
{ISO_FREETXTJAP,	F_OPT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 124 */
{ISO_RSVPRV126,		F_OPT,	NULL,	F_OPT,	NULL, 0, NULL, 0, NULL},	/* 126 */
{LAST_BITMAPENT,	0,	NULL,	0,	NULL, 0, NULL, 0, NULL}
};
 
/**************************************************************************/
/* External Financial Request Messages:	200/210	    	  	          */
/**************************************************************************/
ctxprivate	f2i_t f2ijfrq[] =
/*	bmno, req_f, req_cond, rsp_f, rsp_cond				*/
{
{ISO_PAN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 2 */
{ISO_PROCCODE,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 3 */
{ISO_AMTTXN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 4 */
{ISO_DTXMIT,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 7 */
{ISO_STAN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 11 */
{ISO_TIMELOCAL,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 12 */
{ISO_DATELOCAL,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 13 */
{ISO_DATECPT,		0,	NULL,	F_RET, 	NULL, 0, NULL, 0, NULL},	/* 17 */
{ISO_AMTTXNFEE,		F_OPT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 28 */
{ISO_AIID,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 32 */
{ISO_T2DATA,		F_OMIT,	NULL,	F_RET,  NULL, 0, NULL, 0, NULL},	/* 35 */
{ISO_RRN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 37 */
{ISO_APRVLCODE,		F_OMIT,	NULL,	0,	NULL, 0, NULL, 0, NULL},	/* 38 */
{ISO_RSPCODE,		F_OMIT, NULL,	0,	NULL, 0, NULL, 0, NULL},	/* 39 */
{ISO_TERMID,		F_OPT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 41 */
{ISO_CRDACPTLOC,	0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 43 */
{ISO_ADDRSPDATA,	F_OMIT,	NULL,	0, 	NULL, 0, NULL, 0, NULL},	/* 44 */
{ISO_ADDDATAPRI,	0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 48 */
{ISO_CURTXN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 49 */
{ISO_PIN,		F_OMIT,	NULL,	F_OMIT,	NULL, 0, NULL, 0, NULL},	/* 52 */
{ISO_ADDPOSINFO,	0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 60 */
{ISO_CPSFIELDS,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 62 */
{ISO_RIID,		F_OMIT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 100 */
{ISO_ACCID1,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 102 */
{ISO_ACCID2,		F_OPT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 103 */
{ISO_ORGMTID,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 120 */
{ISO_FREETXTJAP,	F_OPT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 124 */
{ISO_RSVPRV126,		F_OPT,	NULL,	F_OPT,	NULL, 0, NULL, 0, NULL},	/* 126 */
{LAST_BITMAPENT,	0,	NULL,	0,	NULL, 0, NULL, 0, NULL}
};

/**************************************************************************/
/* File Maintainance Messages:	300/310			      	          */
/**************************************************************************/
ctxprivate	f2i_t f2ijfmm[] =
/*	bmno, req_f, req_cond, rsp_f, rsp_cond				*/
{
{ISO_DTXMIT,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 7 */
{ISO_STAN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 11 */
{ISO_AMTTXNFEE,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 28 */
{ISO_FIID,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 33 */
{ISO_RSPCODE,		F_OMIT, NULL,	0,	NULL, 0, NULL, 0, NULL},	/* 39 */
{ISO_RIID,		F_OPT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 100 */
{ISO_FILENAME,		0,	NULL,	F_OMIT,	NULL, 0, NULL, 0, NULL},	/* 101 */
{LAST_BITMAPENT,	0,	NULL,	0,	NULL, 0, NULL, 0, NULL}
};
	
/**************************************************************************/
/* External Reversal Messages:	420/430		       		          */
/**************************************************************************/
ctxprivate	f2i_t f2ijrm[] =
/*	bmno, req_f, req_cond, rsp_f, rsp_cond				*/
{
{ISO_PAN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 2 */
{ISO_PROCCODE,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 3 */
{ISO_AMTTXN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 4 */
{ISO_DTXMIT,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 7 */
{ISO_STAN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 11 */
{ISO_TIMELOCAL,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 12 */
{ISO_DATELOCAL,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 13 */
{ISO_DATECPT,		0,	NULL,	F_RET, 	NULL, 0, NULL, 0, NULL},	/* 17 */
{ISO_AMTTXNFEE,		F_OPT,	&Baurev,F_RET,	NULL, 0, NULL, 0, NULL},	/* 28 */
{ISO_AIID,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 32 */
{ISO_T2DATA,		F_OMIT,	NULL,	F_RET,  NULL, 0, NULL, 0, NULL},	/* 35 */
{ISO_RRN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 37 */
{ISO_APRVLCODE,		F_OMIT,	NULL,	0,	NULL, 0, NULL, 0, NULL},	/* 38 */
{ISO_RSPCODE,		0,	NULL,	0,	NULL, 0, NULL, 0, NULL},	/* 39 */
{ISO_TERMID,		F_OPT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 41 */
{ISO_CRDACPTLOC,	0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 43 */
{ISO_ADDRSPDATA,	F_OMIT,	NULL,	0, 	NULL, 0, NULL, 0, NULL},	/* 44 */
{ISO_ADDDATAPRI,	0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 48 */
{ISO_CURTXN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 49 */
{ISO_PIN,		F_OMIT,	NULL,	F_OMIT,	NULL, 0, NULL, 0, NULL},	/* 52 */
{ISO_ADDPOSINFO,	0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 60 */
{ISO_AMTRPLC,		0,	NULL,	F_OMIT,	NULL, 0, NULL, 0, NULL},	/* 95 */
{ISO_RIID,		F_OMIT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 100 */
{ISO_ACCID1,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 102 */
{ISO_ACCID2,		F_OPT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 103 */
{ISO_ORGMTID,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 120 */
{ISO_FREETXTJAP,	F_OPT,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 124 */
{ISO_RSVPRV126,		F_OPT,	NULL,	F_OPT,	NULL, 0, NULL, 0, NULL},	/* 126 */
{LAST_BITMAPENT,	0,	NULL,	0,	NULL, 0, NULL, 0, NULL}
};

/**************************************************************************/
/* External Network Management Messages:	804/814      	          */
/**************************************************************************/
ctxprivate	f2i_t f2ijnmm[] =
/*	bmno, req_f, req_cond, rsp_f, rsp_cond				*/
{
{ISO_DTXMIT,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 7  */
{ISO_STAN,		0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 11 */
{ISO_RSPCODE,		F_OMIT,	NULL,	0, 	NULL, 0, NULL, 0, NULL},	/* 39 */
{ISO_NETMGTINFO,	0,	NULL,	F_RET,	NULL, 0, NULL, 0, NULL},	/* 70 */
{LAST_BITMAPENT,	0,	NULL,	0,	NULL, 0, NULL, 0, NULL}
};



/*-----------------------------------------------------------------------
 * Mappings for individual fields
 * We have a problem with asymmetric mappings - we cannot recover
 * the original data 100% accurately !
 *-----------------------------------------------------------------------*/

static map_tbl_t e2iacctyp[] =
{
	{"00",	"00",	STR},	/* Default			*/
	{"10",	"10",	STR},	/* Savings			*/
	{"20",	"20",	STR},	/* Cheque			*/
	{"30",	"30",	STR},	/* Credit			*/
/*	{"40",	"40",	STR},	  Universal			*/
				/* Mi 15/04/97 */
	{"00",	"40",	STR},	/* Universal (for revmap)	*/
	{"00",	"50",	STR},	/* Investment (for revmap)	*/
	{"..",	"00",	REGEX},	/* Unknown			*/
};

/****************************************************************/
/* Sub field layouts for Field 72 Record Data 			*/
/****************************************************************/
ctxprivate	subf_t	sf_adddata_rsp[]=
{
{"ADDDATA1",	I_ADDDATA1,	20,	FLD_STRING,	NULL	},
{"ADDDATA2",	I_ADDDATA2,	20,	FLD_STRING,	NULL	},
{"ADDDATA3",	I_ADDDATA3,	20,	FLD_STRING,	NULL	},
{"ADDDATA4",	I_ADDDATA4,	20,	FLD_STRING,	NULL	},
{"ADDDATA5",	I_ADDDATA5,	20,	FLD_STRING,	NULL	},
{"ADDDATA6",	I_ADDDATA6,	20,	FLD_STRING,	NULL	},
{"ADDDATA7",	I_ADDDATA7,	20,	FLD_STRING,	NULL	},
{"ADDDATA8",	I_ADDDATA8,	20,	FLD_STRING,	NULL	},
{ NULL }
};

ctxprivate	subf_t	sf_cust_rsp[]=
{
{"CUSTCODE",	I_CUSTCODE,	12,	FLD_STRING,	NULL	},
{"CUSTTYPE",	I_CUSTTYPE,	1,	FLD_STRING,	NULL	},
{"LASTNAME",	I_LASTNAME,	20,	FLD_STRING,	NULL	},
{"FIRSTNAME",	I_FIRSTNAME,	20,	FLD_STRING,	NULL	},
{"CUSTTITLE",	I_CUSTTITLE,	4,      FLD_STRING,	NULL	},
{"CUSTSEX",	I_CUSTSEX,	1,      FLD_STRING,	NULL	},
{"CUSTMARRIED",I_CUSTMARRIED,	1,      FLD_STRING,	NULL	},
{"CUSTPROF",	I_CUSTPROF,	2,      FLD_STRING,	NULL	},
{"HOMEADDR1",	I_HOMEADDR1,	35,	FLD_STRING,	NULL	},
{"HOMEADDR2",	I_HOMEADDR2,	35,	FLD_STRING,	NULL	},
{"HOMEADDR3",	I_HOMEADDR3,	35,	FLD_STRING,	NULL	},
{"HOMECITY",	I_HOMECITY,	20,	FLD_STRING,	NULL	},
{"HOMETEL",	I_HOMETEL,	20,	FLD_STRING,	NULL	},
{"HOMEPCODE",	I_HOMEPCODE,	10,	FLD_STRING,	NULL	},
{"POBOX",	I_POBOX,	8,      FLD_STRING,	NULL	},
{"WORKADDR1",	I_WORKADDR1,	35,	FLD_STRING,	NULL	},
{"WORKADDR2",	I_WORKADDR2,	35,	FLD_STRING,	NULL	},
{"WORKADDR3",	I_WORKADDR3,	35,	FLD_STRING,	NULL	},
{"WORKCITY",	I_WORKCITY,	20,	FLD_STRING,	NULL	},
{"WORKTEL",	I_WORKTEL,	20,	FLD_STRING,	NULL	},
{"WORKPCODE",	I_WORKPCODE,	10,	FLD_STRING,	NULL	},
{"BIRTHDATE",	I_BIRTHDATE,	8,      FLD_LONG,	NULL	},
{"IDNUMBER",	I_IDNUMBER,	12,	FLD_STRING,	NULL	},
{"MAILSHOTS",	I_MAILSHOTS,	1,      FLD_STRING,	NULL	},
{"USERDATA1",	I_USERDATA1,	12,	FLD_STRING,	NULL	},
{"USERDATA2",	I_USERDATA2,	12,	FLD_STRING,	NULL	},
{"USERDATA3",	I_USERDATA3,	12,	FLD_STRING,	NULL	},
{"ADDITIONAL DATA",BADFLDID,	160,	0,	sf_adddata_rsp},
{ NULL }
};

ctxprivate	subf_t	sf_accdet_rsp[]=
{
{"ACCNO",	C_ACCNO,	28,	FLD_STRING,	NULL	},
{"ACCTYPE",	C_ACCNOTYPE,	2,      FLD_STRING,	NULL	},
{"ACCNOCUR",	C_ACCNOCUR,	3,      FLD_STRING,	NULL	},
{ NULL }
};

ctxprivate	subf_t	sf_custacc_rsp[]=
{
{"CUSTCODE",	I_CUSTCODE,	12,	FLD_STRING,	NULL	},
{"ACCOUNT DETAILS",BADFLDID,	33,	0,	sf_accdet_rsp},
{ NULL }
};

ctxprivate	subf_t	sf_crdacc_rsp[]=
{
{ NULL }
};

ctxprivate	subf_t	sf_crdstat_rsp[]=
{
{ NULL }
};

ctxprivate	subf_t	sf_accbal_req[]=
{
{"ACCNO",	C_ACCNO,	28,	FLD_STRING,	NULL	},
{"ACCNOSTAT",	C_ACCNOSTAT,	2,      FLD_STRING,	NULL	},
{"DEBITCREDIT",	C_DEBITCREDIT,	1,      FLD_STRING,	NULL	},
{"AMTTXN",	C_AMTTXN,	12,	FLD_DOUBLE,	NULL	},
{"INST",	I_INSTCODE,	4,      FLD_STRING,	NULL	},
{"CURTXN",	C_CURTXN,	3,      FLD_STRING,	NULL	},
{ NULL }
};

ctxprivate	subf_t	sf_xratedets_req[]=
{
{"I_BASECURCODE",I_BASECURCODE,	3,      FLD_STRING,	NULL	},
{"I_TGTCURCODE",I_TGTCURCODE,	3,      FLD_STRING,	NULL	},
{"I_BUYRATE",	I_BUYRATE,	8,      FLD_RATE,	NULL	},
{"I_SELLRATE",	I_SELLRATE,	8,      FLD_RATE,	NULL	},
{"I_EFFDATE",	I_EFFDATE,	8,      FLD_LONG,	NULL	},
{"I_EFFTIME",	I_EFFTIME,	6,      FLD_LONG,	NULL	},
{"I_EXPDATE",	I_EXPDATE,	8,      FLD_LONG,	NULL	},
{"I_EXPTIME",	I_EXPTIME,	6,      FLD_LONG,	NULL	},
{"I_CRDPROD",	I_CRDPROD,	4,      FLD_STRING,	NULL	},
{ NULL }
};

ctxprivate	subf_t	sf_xrate_req[]=
{
{"X RATE DETAILS",BADFLDID,	54,	0,	sf_xratedets_req	},
{ NULL }
};

ctxprivate	subf_t	sf_cust_req[]=
{
{"CUSTCODE",	I_CUSTCODE,	12,	FLD_STRING, 	NULL	},
{ NULL }
};

ctxprivate	subf_t	sf_custacc_req[]=
{
{"CUSTCODE",	I_CUSTCODE,	12,	FLD_STRING, 	NULL	},
{ NULL }
};


ctxprivate	subf_t	sf_accs_req[]=
{
{"ACCNO",	C_ACCNO,	28,	FLD_STRING,	NULL	},
{ NULL }
};

ctxprivate	subf_t	sf_crdacc_req[]=
{
{"CUSTCODE",	I_CUSTCODE,	12,	FLD_STRING, 	NULL	},
{"PAN",		C_PAN,		19,	FLD_STRING, 	NULL	},
{"CRDSEQNO",	C_CRDSEQNO,	3,	FLD_SHORT, 	NULL	},
{"ACCOUNTS",	BADFLDID,	28,	FLD_SHORT, 	sf_accs_req},
{ NULL }
};

ctxprivate	subf_t	sf_crdstat_req[]=
{
{"PAN",		C_PAN,		19,	FLD_STRING,	NULL	},
{"CRDSEQNO",	C_CRDSEQNO,	3,	FLD_SHORT,	NULL	},
{"OLDCRDSTAT",	I_OLDCRDSTAT,	2,	FLD_STRING,	NULL	},
{"NEWCRDSTAT",	I_NEWCRDSTAT,	2,	FLD_STRING,	NULL	},
{"ACCOUNTS",	BADFLDID,	28,	FLD_SHORT, 	sf_accs_req},
{ NULL }
};

ctxprivate	subf_t	sf_balref_req[]=
{
{"ACCNO",	C_ACCNO,	28,	FLD_STRING,	NULL	},
{"ACCNOSTAT",	C_ACCNOSTAT,	2,      FLD_STRING,	NULL	},
{"INST",	I_INSTCODE,	4,      FLD_STRING,	NULL	},
{"ACCNOCUR",	C_ACCNOCUR,	3,      FLD_STRING,	NULL	},
{"BLKAMT",	I_BLKAMT,	12,	FLD_DOUBLE,	NULL	},
{"AVLBAL",	I_AVLBAL,	12,	FLD_DOUBLE,	NULL	},
{"CLRBAL",	I_CLRBAL,	12,	FLD_DOUBLE,	NULL	},
{"UNCLRBAL",	I_UNCLRBAL,	12,	FLD_DOUBLE,	NULL	},
{"CREDITLIM",	I_CREDITLIM,	12,	FLD_DOUBLE,	NULL	},
{"CYCLELIM",	I_CYCLELIM,	12,	FLD_DOUBLE,	NULL	},
{ NULL }
};
ctxprivate	subf_t	sf_xrate_rsp[]=
{
{ NULL }
};

ctxprivate	subf_t	sf_accbal_rsp[]=
{
{ NULL }
};

ctxprivate	subf_t	sf_balref_rsp[]=
{
{ NULL }
};

ctxprivate subf_t
		*req_sub_fields[] =
		{
			sf_cust_req,
			sf_custacc_req,
			sf_crdacc_req,
			sf_accbal_req,
			sf_xrate_req,
			sf_crdstat_req,
			sf_balref_req
		};

ctxprivate subf_t
		*rsp_sub_fields[] =
		{
			sf_cust_rsp,
			sf_custacc_rsp,
			sf_crdacc_rsp,
			sf_accbal_rsp,
			sf_xrate_rsp,
			sf_crdstat_rsp,
			sf_balref_rsp
		};

/* TR For ICBS Interface we define a table of subfields for field 48 */
ctxprivate tlv_t add_data_tags[] =
{
{"001",	C_ADDDATA,	"C_ADDDATA",	 20,	FLD_STRING,	FALSE},
{"002",	I_TLOGID,	"I_TLOGID",	 10,	FLD_LONG,	TRUE},
{"003",	I_AFE,		"I_AFE",	  8,	FLD_STRING,	FALSE},
{"004",	I_IFE,		"I_IFE",	  8,	FLD_STRING,	FALSE},
{"005",	X_TRANDATA,	"X_TRANDATA",	140,	FLD_STRING,	FALSE},
{"006",	X_ADDTRANDATA,	"X_ADDTRANDATA",140,	FLD_STRING,	FALSE},
{"007",	X_SRCPOSTACCNO,	"X_SRCPOSTACCNO",28,	FLD_STRING,	FALSE},
{"008",	X_SRCPOSTCUR,	"X_SRCPOSTCUR",	  3,	FLD_STRING,	FALSE},
{"009",	X_SRCPOSTAMT,	"X_SRCPOSTAMT",	 12,	FLD_DOUBLE,	FALSE},
{"010",	X_DSTPOSTACCNO,	"X_DSTPOSTACCNO",28,	FLD_STRING,	FALSE},
{"011",	X_DSTPOSTCUR,	"X_DSTPOSTCUR",	  3,	FLD_STRING,	FALSE},
{"012", X_DSTPOSTAMT,	"X_DSTPOSTAMT",	 12,	FLD_DOUBLE,	FALSE},
{"013",	X_CRDPROD,	"X_CRDPROD",	 30,	FLD_STRING,	FALSE},
{"014",	I_TLOGIDORG,	"I_TLOGIDORG",	 10,	FLD_LONG,	TRUE},
{"015",	I_VPAN,		"I_VPAN",	 19,	FLD_STRING,	FALSE},
{"016",	I_AUTHDAYS,	"I_AUTHDAYS",	  5,	FLD_SHORT,	FALSE},
{"017",	C_AUTH_EXPDATE,	"C_AUTH_EXPDATE", 8,	FLD_LONG,	FALSE},
{"",0,"",0,0,FALSE},
{NULL}
};

/*---------------------------Prototypes---------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/

/*------------------------------------------------------------------------
 *
 * Function	:  jiso_set_use_conacc
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxpublic	void jiso_set_use_conacc(ctxbool use_conacc_f)
{
	M_use_conacc = use_conacc_f;

	DBG_PRINTF(( dbg_progdetail, "use_conacc flag set to %s",
		M_use_conacc ? "TRUE" : "FALSE" ));

	return;
}

/*------------------------------------------------------------------------
 *
 * Function	:  jiso_use_conacc
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxpublic	ctxbool jiso_use_conacc(void)
{
	return( M_use_conacc  );
}

/*------------------------------------------------------------------------
 *
 * Function	:  jiso_set_ignore_nou_accno
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxpublic	void jiso_set_ignore_nou_accno(void)
{
	M_ignore_nou_accno = TRUE;

	DBG_PRINTF(( dbg_progdetail, "ignore_nou_accno flag set to %s",
		M_ignore_nou_accno ? "TRUE" : "FALSE" ));

	return;
}

/*------------------------------------------------------------------------
 *
 * Function	:  jiso_use_ignore_nou_accno
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxpublic	ctxbool jiso_ignore_nou_accno(void)
{
	return ( M_ignore_nou_accno );
}



/*------------------------------------------------------------------------
 *
 * Function	:  I2Ffld54
 *
 * Purpose	:  Deblock DE054 field
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  Proyecto Autorizacion parcial
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Ffld54(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len = 0;
	
	char acctype[10]; char amttype[10]; char curcode[10];
	char posbal[10];  char amount[20];  
	
	int ret = SUCCEED;
	
	memset(acctype, 0, sizeof(acctype));
	memset(amttype, 0, sizeof(amttype));
	memset(curcode, 0, sizeof(curcode));
	memset(posbal, 0, sizeof(posbal));
	memset(amount, 0, sizeof(amount));
	
	DBG_PRINTF(( dbg_progdetail, "DE054 - I2Ffld54" )); 
	
	if (FAIL != (len = I2Fva3asc(iso, p_fb, p_i2f)))
	{
		DBG_PRINTF(( dbg_progdetail, "DE054 M_rawdata [%s] len[%d]", M_rawdata, len)); 
		
		if (len==23)
		{
			strncpy(acctype, M_rawdata, 2); acctype[2] = EOS;
			strncpy(amttype, M_rawdata + 2, 2); amttype[2] = EOS;
			strncpy(curcode, M_rawdata + 4, 3); curcode[3] = EOS;
			strncpy(posbal, M_rawdata + 7, 1); posbal[1] = EOS;
			strncpy(amount, M_rawdata + 8, 12); amount[12] = EOS;
			
			DBG_PRINTF(( dbg_progdetail, "acctype[%s] amttype[%s] curcode[%s] posbal[%s] amount[%s]", acctype, amttype, curcode, posbal, amount )); 
		}
		else 
		{
			DBG_PRINTF(( dbg_fatal, "DE054 M_rawdata [%s] -> len[%d] must be = 23 (len + data)",  M_rawdata, len)); 
			len = FAIL;
		}
	}

	if( FAIL == ret )
		len = FAIL;		
	
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Forgdat
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Forgdat(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len = SUCCEED;
	char	szstan[7];
	long	lstan;
	char	szdlocal[9];
	char	sztlocal[7];
	char	szaiid[12];
	short	nlen;
	long	yy;
	long	yymmdd;
	long	yyyymmdd;

	memset(szstan, 0, sizeof(szstan));
	memset(szdlocal, 0, sizeof(szdlocal));
	memset(sztlocal, 0, sizeof(sztlocal));
	memset(szaiid, 0, sizeof(szaiid));

	len = I2Fvbcd(iso, p_fb, p_i2f);

	DBG_PRINTF(( dbg_progdetail, "vbcd len: %d", len ));
	DBG_DUMP( dbg_progdetail, "iso:", iso, 25 );
	DBG_DUMP( dbg_progdetail, "M_rawdata:", M_rawdata, len );

	if ( FAIL != len )
	{
		sscanf(M_rawdata + 4,  "%6ld", &lstan);
		sscanf(M_rawdata + 10, "%6ld", &yymmdd);

		yy = yymmdd / 10000;
		yy = (yy2ccyy((int)yy)/100);
		yyyymmdd = yymmdd + yy * 1000000;

		sprintf(szdlocal, "%08ld", yyyymmdd);

		sscanf(M_rawdata + 16, "%6s", sztlocal);
		sscanf(M_rawdata + 22, "%2hd", &nlen);

		strnscpy(szaiid, M_rawdata + 24, ((size_t)nlen));
	}

	/* MJB 28/5/97 Changed to use direct F_chg for first 3 since this was
	* setting them to 0x01 instead of 0x31
	*/

	if (   FAIL == F_chg(p_fb, C_MSGCLSORG, 0, (char*)(M_rawdata + 1), 0)
	    || FAIL == F_chg(p_fb, C_MSGFNORG, 0, (char*)(M_rawdata + 2), 0)
	    || FAIL == F_chg(p_fb, C_TXNSRCORG, 0, (char*)(M_rawdata + 3), 0)
	    || FAIL == CF_chg(p_fb, C_STANORG, 0, (char*)&lstan, 0, FLD_LONG)
	    || FAIL == CF_chg(p_fb, C_DATELOCALORG, 0, szdlocal, 0, FLD_STRING)
	    || FAIL == CF_chg(p_fb, C_TIMELOCALORG, 0, sztlocal, 0, FLD_STRING)
	    || FAIL == CF_chg(p_fb, C_AIIDORG, 0, szaiid, 0, FLD_STRING))
		len = FAIL;

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Iacqctry
 *
 * Purpose	:  Add acquirer country code
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Iacqctry(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	short	ctry;
	int	len = SUCCEED;

	if (F_pres(p_fb, C_ACQCOUNTRY, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_ACQCOUNTRY, 0, (char *)&ctry,
								0, FLD_SHORT))
			len = FAIL;
		else
			sprintf(M_rawdata, "%03d", ctry);
	}
	else
		strcpy(M_rawdata, "840");	/* TH 29/12/98 default	*/

	if (FAIL != len)
		len = F2Iasc(p_fb, iso, p_i2f);

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Facqctry
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Facqctry(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fasc(iso, p_fb, p_i2f);

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Iexpy
 *
 * Purpose	:  Add expiry date
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Iexpy(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	char	buf[128];
	short	exp;
	char	*p;
	int	len = SUCCEED;
	
	/* MV BZWM-785 
	 * Expiry date not required:
	 * - in VPAN mode for advices
	 * - in NON VPAN mode and &Bnomag is false (has track data)
	 */
	if ((M_vpan_over_pan && FBISADV(p_fb)) || (!M_vpan_over_pan && FALSE==fev_evbool(p_fb, &Bnomag)))
	{
		DBG_PRINTF(( dbg_progdetail, "Expiry date NOT REQUIRED!"));
		return FAIL; /* <<<<<< RETURN */
	}
	
	if (F_pres(p_fb, C_DATEEXP, 0) && 
		/* MV BZWM-785 */
		(!M_vpan_over_pan || /* Use C_DATEEXP if not in VPAN mode */
		/* ...or if we are in VPAN mode and there is no track data! */
		  ( M_vpan_over_pan &&
		    !F_pres(p_fb, C_T2DATA, 0) &&
		    !F_pres(p_fb, C_T1DATA, 0)
		  )
		)
	   )
	{
		DBG_PRINTF(( dbg_progdetail, "Expiry date from C_DATEEXP"));
		if (SUCCEED != CF_get(p_fb, C_DATEEXP, 0, (char *)&exp,
								0, FLD_SHORT))
			len = FAIL;
		else
			sprintf(M_rawdata, "%04d", exp);
	}
	else if (F_pres(p_fb, C_T2DATA, 0))
	{
		DBG_PRINTF(( dbg_progdetail, "Expiry date from C_T2DATA"));
		/* On T2, Expiry is after first FS	*/
		/* MV BZWM-785 FLD_SHORT -> FLD_STRING */
		if (SUCCEED != CF_get(p_fb, C_T2DATA, 0, buf, 0, FLD_STRING)
		 || !(p = strchr(buf, T2_FS)))
			len = FAIL;
		else
		{
			strncpy(M_rawdata, p+1, 4);
			M_rawdata[4] = EOS;
		}
	}
	else if (F_pres(p_fb, C_T1DATA, 0))
	{
		DBG_PRINTF(( dbg_progdetail, "Expiry date from C_T1DATA"));
		/* On T1, Expiry is after second FS	*/
		/* MV BZWM-785 FLD_SHORT -> FLD_STRING */
		if (SUCCEED != CF_get(p_fb, C_T1DATA, 0, buf, 0, FLD_STRING)
		 || !(p = strchr(buf, T1_FS)) || !(p = strchr(p+1, T1_FS)))
			len = FAIL;
		else
		{
			strncpy(M_rawdata, p+1, 4);
			M_rawdata[4] = EOS;
		}
	} 
	else
	{
		len=FAIL; /* MV BZWM-785 */
	}
		
	if (FAIL != len)
		len = F2Iasc(p_fb, iso, p_i2f);
	
	/* MV BZWM-785 Field is mandatory, but failed! */
	if ( len<1 )
	{
		DBG_PRINTF((dbg_syserr, "Expiry date REQUIRED, but failed "
					"to convert!"));
		M_conv_failed = TRUE;
	}	
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Fexpy
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	: MV BZWM-785 06/10/2009
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fexpy(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fasc(iso, p_fb, p_i2f);

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Iorgdat
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Iorgdat(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = SUCCEED;
	char	szstan[7];
	long	lstan,ldlocal,ltlocal;
	char	szdlocal[9];
	char	sztlocal[7];
	char	szaiid[12];
	char	sztemp[36];
	char	szlen[3];
	char	cmsgclsorg;
	char	cmsgfnorg;
	char	ctxnsrcorg;
	char	szmtid[5];

	memset(szstan, 0, sizeof(szstan));
	memset(szdlocal, 0, sizeof(szdlocal));
	memset(sztlocal, 0, sizeof(sztlocal));
	memset(szaiid, 0, sizeof(szaiid));

	if ( FAIL == CF_get(p_fb, C_STANORG, 0, (char*)&lstan,
								0, FLD_LONG))
		len = FAIL;
	else if (FAIL == CF_get(p_fb, C_DATELOCALORG, 0, (char *)&ldlocal,
						0, FLD_LONG)
	            || FAIL == CF_get(p_fb, C_TIMELOCALORG, 0, (char *)&ltlocal,
						0, FLD_LONG))
			len = FAIL;

	if ( FAIL != len )
	{
		sprintf( szdlocal, "%08ld", ldlocal );
		sprintf( sztlocal, "%06ld", ltlocal );
	}

	if ( FAIL != len )
	{
		if( F_pres(p_fb, C_AIIDORG, 0) )
		{
			if( FAIL == CF_get(p_fb, C_AIIDORG, 0, szaiid, 0,
					   FLD_STRING) )
				len = FAIL;
		}
		else if( F_pres(p_fb, C_AIID, 0) )
		{
			DBG_PRINTF(( dbg_progdetail,
				    "Using AIID instead of AIIDORG" ));
			if( FAIL == CF_get(p_fb, C_AIID, 0, szaiid, 0,
					   FLD_STRING) )
				len = FAIL;
		}
		else
			len = FAIL;
	}

	if ( FAIL != len )
	{
		if( FAIL == CF_get(p_fb,C_MSGCLSORG,0,(char*) &cmsgclsorg,
				(FLDLEN) 0, FLD_CHAR) )
			cmsgclsorg = 0;
		else if( FAIL == CF_get(p_fb,C_MSGFNORG,0,(char*) &cmsgfnorg,
				(FLDLEN) 0, FLD_CHAR) )
			cmsgfnorg = 0;
		else if( FAIL == CF_get(p_fb,C_TXNSRCORG,0,(char*) &ctxnsrcorg,
				(FLDLEN) 0, FLD_CHAR) )
			ctxnsrcorg = 0;
		if( 0 == cmsgclsorg || 0 == cmsgfnorg  || 0 == ctxnsrcorg )
		{
			strcpy(szmtid, ORGMESS);
			DBG_PRINTF((dbg_progdetail,
				"MTID org set to %s", ORGMESS));
		}
		else
		{
 			*szmtid = '1';
 			*(szmtid + 1) = cmsgclsorg;
 			*(szmtid + 2) = cmsgfnorg;
 			*(szmtid + 3) = ctxnsrcorg;
 			*(szmtid + 4) = EOS;
		}
	}
	if ( FAIL != len )
	{
		memset(sztemp,  0, sizeof(sztemp));

		strnscpy(sztemp, szmtid, strlen(szmtid));
		sprintf(szstan, "%06ld", lstan);
		strncat(sztemp, szstan, strlen(szstan));
		strncat(sztemp, szdlocal + 2, strlen(szdlocal) - 2);
		strncat(sztemp, sztlocal, strlen(sztlocal));
		/* Length prefix for aiidorg must be decimal, not hex */
		/* Format changed from "%02X" to "%02d" by Ilya */
		/* Job 3660, 04/07/2000 */
		sprintf(szlen, "%02lu", strlen(szaiid));
		strncat(sztemp, szlen, strlen(szlen));
		strncat(sztemp, szaiid, strlen(szaiid));
		strcpy(M_rawdata, sztemp);

		len = F2Ivbcd(p_fb, iso, p_i2f);
	}
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Fterm
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fterm(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fasc(iso, p_fb, p_i2f);

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Iaprvlcode
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Iaprvlcode(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = SUCCEED;
	char	szbuf[32];

	if ( FAIL == CF_get(p_fb, C_APRVLCODE, 0, szbuf, 0, FLD_STRING))
		len = FAIL;

	if ( FAIL != len )
	{
		sprintf(M_rawdata, "%-6.6s", szbuf);
		len = F2Iasc(p_fb, iso, p_i2f);
	}
	else
	{
					/* want reversal to go ahead since
					 * might be a timeout rev in which
					 * case there is no aprvlcode
					 */
		if (FBISCBREV(p_fb))
		{
			sprintf(M_rawdata, "000000");
			len = F2Iasc(p_fb, iso, p_i2f);
		}
	}

	return( len );
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Ft2data
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Ft2data(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fva2asc(iso, p_fb, p_i2f);

	return len;
}
/*------------------------------------------------------------------------
 *
 * Function	:  F2It2data
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2It2data(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = SUCCEED;
	
	/* MV BZWM-785 */
	if (M_vpan_over_pan)
	{
		DBG_PRINTF((dbg_progdetail, "Not sending Track2 in VPAN mode"));
		return FAIL; /* <<< RETURN */
	}
	
	if (TRUE == fev_evbool(p_fb, &Bcrdread))
	{
		if( F_pres( p_fb, C_T2DATA, 0 ) )
		{
			if(FAIL == CF_get(p_fb, C_T2DATA, 0, M_rawdata, 0, FLD_STRING))
				len = FAIL;
		}
		else
		{
			/* If its a 122x message and T2DATA is not present, then frig it
			* using the PAN.
			*/
			if( !FBISFIN( p_fb ) || !FBISADV( p_fb ) ||
				FAIL == CF_get(p_fb, C_PAN_CLR,
							0, M_rawdata, 0, FLD_STRING))
			{
				len = FAIL;
			}
		}
		
		if ( FAIL != len )
		{
			len = F2Iva2asc(p_fb, iso, p_i2f);
		}
		
		/* MV BZWM-785 Field is mandatory, but failed! */
		if ( len<1 )
		{
			DBG_PRINTF((dbg_syserr, "Track2 is REQUIRED, but failed "
					    "to convert!"));
			M_conv_failed = TRUE;
		}
	} 
	else
	{
		DBG_PRINTF((dbg_progdetail, "Track2 NOT REQUIRED!"));
		len=FAIL;
	}
	
	return( len );
}
/*------------------------------------------------------------------------
 *
 * Function	:  F2Iterm
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Iterm(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = SUCCEED;
	char	szbuf[32];
	
	/* mvitolin BPD_10_001_IT-54 11/02/2011 */
	if (F_pres(p_fb, ISO_TAG_F041, 0))
	{
		if (FAIL == CF_get(p_fb, ISO_TAG_F041, 0, szbuf, 0, FLD_STRING))
		{
			szbuf[0] = EOS;
		}
	}
	else if ( FAIL == CF_get(p_fb, C_TERMCODE, 0, szbuf, 0, FLD_STRING))
	{
		szbuf[0] = EOS;
	}
	
	if ( FAIL != len )
	{
		sprintf(M_rawdata, "%-16.16s", szbuf);

		len = F2Iasc(p_fb, iso, p_i2f);
	}

	return( len );
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Fcaid
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *----------------------------------------------------------------------*/
ctxprivate int I2Fcaid(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fasc(iso, p_fb, p_i2f);

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Icaid
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *----------------------------------------------------------------------*/
ctxprivate int F2Icaid(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = SUCCEED;
	char	szbuf[32];

	if ( FAIL == CF_get(p_fb, C_CRDACPTID, 0, szbuf, 0, FLD_STRING))
	{
		szbuf[0] = EOS;
	}
	if ( FAIL != len )
	{
		sprintf(M_rawdata, "%-15.15s", szbuf);
		len = F2Iasc(p_fb, iso, p_i2f);
	}
	return( len );
}


/*------------------------------------------------------------------------
 *
 * Function	:  I2Fdrec
 *
 * Purpose	:  Set the date of reconciliation
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  C_INDATEREC for the acquirer
 *		   C_OUTDATEREC for the issuer
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fdrec(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	/* We ignore the incoming daterec at the moment */
	/* and set the C_INDATEREC and C_OUTDATEREC to I_SYSDATE */
	/* except for 15xx message which we set it to I_SYSDATE */
	short	len;
	long	yy;
	long	yymmdd, yyyymmdd;

	len = I2Fasc(iso, p_fb, p_i2f);
	sscanf(M_rawdata, "%6ld", &yymmdd);
	yy = yymmdd / 10000;
	yy = (yy2ccyy((int)yy)/100);
	yyyymmdd = yymmdd + yy * 1000000;
	sprintf(M_rawdata, "%08ld", yyyymmdd);

	/* Removed irrelevant 15xx code */
	if( FAIL != len )
	{
		if (FAIL == CF_chg(p_fb,C_DATEREC,0,M_rawdata,
				   (FLDLEN) 0,FLD_STRING))
			len = FAIL;
	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Idrec
 *
 * Purpose	:  Set the date of reconciliation
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  I_INDATEREC for the acquirer
 *		   I_OUTDATEREC for the issuer
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Idrec(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	long	yyyymmdd = 0;
	short	len = 0;

	if (FAIL == CF_get(p_fb, I_SYSDATE, 0, (char *)&yyyymmdd,
						0, FLD_LONG))
	{
		len = FAIL;
	}

	if( 0 == len )
	{
		sprintf(M_rawdata, "%06ld", yyyymmdd % 1000000);
		len = F2Iasc(p_fb, iso, p_i2f);
	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Faddam
 *
 * Purpose	:  Deblock additional amounts
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  Tricky: issuer may provide 1 or 2 sets of bals.
 *		   VISA may convert into txn currency as 1 or 2
 *		   additional fields (if acquirer multicurrency) or
 *		   may convert in-place (if acquirer non-multicurrency).
 *		   Also, if issuer provides 1 balance, VISA will zero-fill
 *		   second balance with 0 ONLY if SMS.
 *		   Here we assume:
 *		   - SMS acquirer
 *		   - multicurrency acquirer
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Faddam(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;
	int	set;
	char	*p;
	char	acctypbuf[3],
		amttypbuf[3],
		currbuf[4];
	double	f;
	amtadd_t amtadd;

	len = I2Fl1asc(iso, p_fb, p_i2f);
	DBG_PRINTF((dbg_progdetail, "ADAM isolen %d len %d [%s]",
			(*iso<<8)+*(iso+1), len, M_rawdata));
	for (set = 0, p = M_rawdata;
			FAIL != len && set * 20 < (len - 1 - 2);
				set++, p+= 20)
	{
		strncpy(acctypbuf, p, 2);
		acctypbuf[2] = EOS;
		strncpy(amttypbuf, p+2, 2);
		amttypbuf[2] = EOS;
		/* Convert non-standard balance types to standard Cortex
		 * equivalents.
		 */
		if( !strcmp( amttypbuf, "50" ) )
		{
			DBG_PRINTF((dbg_progdetail,
				"Converting balance type 50=>02" ));
			strcpy( amttypbuf, "02" );
		}
		else if( !strcmp( amttypbuf, "51" ) )
		{
			DBG_PRINTF((dbg_progdetail,
				"Converting balance type 51=>01" ));
			strcpy( amttypbuf, "01" );
		}
		else if( !strcmp( amttypbuf, "52" ) )
		{
			DBG_PRINTF((dbg_progdetail,
				"Converting balance type 52=>20" ));
			strcpy( amttypbuf, "20" );
		}
		strncpy(currbuf, p+4, 3);
		currbuf[3] = EOS;
		sscanf(p+8, "%12lf", &f);
		if ('D' == p[7])
			f = -f;
		/* use the library */
		memset(&amtadd, 0, sizeof(amtadd));
		sscanf(acctypbuf, "%hd", &amtadd.acctyp);
		sscanf(amttypbuf, "%hd", &amtadd.amttyp);
		strcpy(amtadd.curr, currbuf);
		amtadd.amt=f;
		
		if (ATC_ACC_AVLBAL_NEW==amtadd.amttyp
		    || ATC_ACC_BLKAMT_NEW_OL==amtadd.amttyp)
		{
			amtadd.accidx=AMTADDACCIDX_ACC1;
		}
		else
		{
			amtadd.accidx=AMTADDACCIDX_UNKNOWN;
		}
		DBG_PRINTF((dbg_fatal,"amtadd.amttyp=%hd -> set accidx=%hd",
				amtadd.amttyp, amtadd.accidx));
		
		if (FAIL==amtadd_add(p_fb, &amtadd))
		{
			len=FAIL;
		}	
	}
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Iaddam
 *
 * Purpose	:  Build additional amounts response
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  We may provide 1 or 2 sets of bals.
 *		   We have to provide same ACCTYPE as in proc code acc 1
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Iaddam(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = FAIL;
	int	dp;
	int	occ, set, cnt;
	char	*p;
	short	pcacctyp, pcacctyp1;
	amtadd_t amtadd;
	char		dumpbuf[AMTADD_DUMP_BUFFER]={EOS};
	ctxbool	is_response;
	
	is_response = FBISRSP(p_fb);
	
	if (FAIL == CF_get(p_fb, C_ACCTYPE, 0,
			   (char *)&pcacctyp, 0, FLD_SHORT))
		return FAIL;

	/* Reversals do not have second account */
	if (FAIL == CF_get(p_fb, C_ACCTYPE, 1,
			   (char *)&pcacctyp1, 0, FLD_SHORT))
		pcacctyp1=pcacctyp;

	M_rawdata[0] = EOS;
	cnt=amtadd_occur(p_fb);
	for (occ = 0, set = 0, p = M_rawdata;
		/* set < 2 && */ occ<cnt;
				++occ)
	{
DBG_PRINTF((dbg_progdetail, "ADDAM: check %d", occ));
		memset(&amtadd, 0, sizeof(amtadd));
		/* Use the new library to work with amounts */
		if (SUCCEED!=amtadd_getocc(p_fb, &amtadd, occ))
			continue;
		DBG_PRINTF((dbg_progdetail, "got add amount:%s",
			amtadd_dump_amtadd(dumpbuf, &amtadd,  dbg_progdetail)));
		if (amtadd.acctyp != pcacctyp
		    && amtadd.acctyp != pcacctyp1)	/* same type only WHY 2 ?*/
		{
DBG_PRINTF((dbg_progdetail, "ADDAM: %d <> %d", amtadd.acctyp, pcacctyp));
			continue;
		}
		switch (amtadd.amttyp)
		{
/* BZWBK_DEV-25 */
#if 0
			case ATC_ACC_LEDGER:	/* 01 */
				/* VISA: also Credit Card Credit Avail	*/
				break;
			case ATC_ACC_AVAILABLE:	/* 02 */
				/* VISA: also Credit Card Credit Limit	*/
				break;
			case ATC_AMTGOODS:
			case ATC_ACC_AVLCR:
				/* VISA use 01 Credit Card Credit Avail	*/
				amtadd.amttyp = ATC_ACC_LEDGER;
				break;
			/* TR Following 2 types added for ICBS */
			case ATC_REAL_BAL_WBK:	/* 51 */
				break;
			case ATC_AVL_CASH_WBK:	/* 50 */
				break;
#endif
			/* MV 20090429 BZWBK_DEV-25 */
			case ATC_ACC_AVLBAL_OLD:
				break;
			case ATC_ACC_BLOCKED:
				break;
			case ATC_ACC_PREAUTH_BLK:
				break;
			case ATC_ACC_PREAUTH_UNCLR:
				break;
			case ATC_ACC_AVLBAL_UNSENT:
				break;
			case ATC_ACC_BLKAMT_UNSENT:
				break;
			default:
				/* !!!response thing is just to support testing!!! */
				/* Normally interface will never send responses to host! */
				if (is_response && (ATC_ACC_AVLBAL_NEW==amtadd.amttyp
					|| ATC_ACC_BLKAMT_NEW_OL==amtadd.amttyp
						/* for balance response test! */
					|| ATC_ACC_CLEARED==amtadd.amttyp
					|| ATC_AVL_CASH_WBK==amtadd.amttyp
					|| ATC_REAL_BAL_WBK==amtadd.amttyp
					|| ATC_LIMIT_WBK==amtadd.amttyp))
				{
					break;
				}
/*DBG_PRINTF((dbg_progdetail, "ADDAM: Unsupp type %d", amttyp));*/
				continue;
		}
		if (FAIL == (dp = visa_dp(p_fb, C_AMTADD, occ)))
{
/*DBG_PRINTF((dbg_progdetail, "ADDAM: Bad DP for AMTADD"));*/
			continue;
}
		sprintf(p, "%02d", amtadd.acctyp);
		sprintf(p+2, "%02d", amtadd.amttyp);
		strncpy(p+4, amtadd.curr, 3);
		if (amtadd.amt < 0.0)
		{
			p[7] = 'D';
			amtadd.amt = -amtadd.amt;
		}
		else
			p[7] = 'C';
DBG_PRINTF((dbg_progdetail, "ADDAM1 amt %f dp %d", amtadd.amt, dp));
		while (dp--) amtadd.amt *= 10;
DBG_PRINTF((dbg_progdetail, "ADDAM2 amt %f dp %d", amtadd.amt, dp));
		sprintf(p+8, "%012.0f", amtadd.amt);
		p += 20;
		set++;
	}
	if (set > 0)
	{
		len = F2Il1asc(p_fb, iso, p_i2f);
DBG_PRINTF((dbg_progdetail, "ADDAM: set %d, len %d", set, len));
	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Fotham
 *
 * Purpose	:  Deblock other amounts
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  TR Added for ICBS Interface
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fotham(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;
	int	set;
	char	*p;
	int	amttyp;
	char	currbuf[4];
	double	f;

	len = I2Fl1asc(iso, p_fb, p_i2f);
	DBG_PRINTF((dbg_progdetail, "OTHAM isolen %d len %d [%s]",
			(*iso<<8)+*(iso+1), len, M_rawdata));
	/* Only one amount type at present but loop because more maybe added */
	for (set = 0, p = M_rawdata;
			FAIL != len && set * 18 < (len - 1 - 2);
				set++, p+= 18)
	{
		sscanf(p, "%2d", &amttyp);
		strncpy(currbuf, p+2, 3);
		currbuf[3] = EOS;
		sscanf(p+6, "%12lf", &f);
		if ('D' == p[5])
			f = -f;
		switch (amttyp)
		{
			case ATC_AMTCASH:
				/* Set cash back amount */
				if (FAIL == CF_chg(p_fb, C_AMTTXNCB, 0,
					(char *)&f, (FLDLEN) 0, FLD_DOUBLE))
					len = FAIL;
				break;
			default:
				continue;
		}
	}
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Iotham
 *
 * Purpose	:  Build additional amounts response
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  TR Added for ICBS Interface
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Iotham(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = FAIL;
	int	dp;
	int	set = 0;
	char	*p = M_rawdata;
	char	currbuf[4];
	double	f;


	M_rawdata[0] = EOS;

	if ( F_pres( p_fb, C_AMTTXNCB, 0 ))
	{
		len = CF_get( p_fb, C_CURTXN, 0, currbuf, 0, FLD_STRING);

		if ( FAIL != len )
		{
			len = CF_get( p_fb, C_AMTTXNCB, 0, (char *) &f,
					0, FLD_DOUBLE);
		}

		if ( FAIL != len )
		{
			/* Check decimal places */
			dp = visa_dp(p_fb, C_AMTTXNCB, 0);
			if ( FAIL == dp )
				len = FAIL;
		}

		if ( FAIL != len )
		{
			/* Find if Debit or Credit and strip dps */
			sprintf(p, "%02d", ATC_AMTCASH);
			strncpy(p+2, currbuf, 3);
			if (f < 0.0)
			{
				p[5] = 'D';
				f = -f;
			}
			else
				p[5] = 'C';
DBG_PRINTF((dbg_progdetail, "OTHAM1 f %f dp %d", f, dp));
			while (dp--) f *= 10;
DBG_PRINTF((dbg_progdetail, "OTHAM2 f %f dp %d", f, dp));
			sprintf(p+6, "%012.0f", f);
			p += 18;
			set++;
		}
	}
	if (set > 0)
	{
		len = F2Il1asc(p_fb, iso, p_i2f);
DBG_PRINTF((dbg_progdetail, "OTHAM: set %d, len %d", set, len));
	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Fsecrel
 *
 * Purpose	:  Deblock security related info
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  By default, we dump into C_SECRELATED, but we want to
 *		   pull out I_PINFORMAT as well.
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fsecrel(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	char	buf[3];
	char	szkeyseq[3];
	int	len;

	len = I2Fvbcd(iso, p_fb, p_i2f);

	if (FAIL!= len)
	{

/*		strncpy(buf, M_rawdata+4, 2);
		buf[2] = EOS;

		if( '0' != buf[0] || '0' != buf[1] )
		{
			DBG_PRINTF((dbg_syserr,
				"Got incorrect PINFORMAT %s, exp 00", buf ));
			return( FAIL );
		}

*/
		strcpy( buf, "01" );	/* DIRTY HACK by mi */
					/* Forcing PIN_BLOCK_ANSI */
		strncpy(szkeyseq, M_rawdata+6, 2);
		szkeyseq[2] = EOS;

		if (FAIL == CF_chg(p_fb, C_SECRELATED, 0, M_rawdata,
						(FLDLEN) 0, FLD_STRING)
		 || FAIL == CF_chg(p_fb, I_PINFORMAT, 0, buf,
						(FLDLEN) 0, FLD_STRING)
		 || FAIL == CF_chg(p_fb, K_KEYSEQNO, 0, szkeyseq,
						(FLDLEN) 0, FLD_STRING))
			len = FAIL;
	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Isecrel
 *
 * Purpose	:  Build security-related data
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  Use default except PIN block format
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Isecrel(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	short	pinf;
	short	nkeyseq;
	char	buf[20];
	int	len = FAIL;

	strcpy(M_rawdata, SECREL_DFLT);

	if (FAIL != CF_get(p_fb, I_PINFORMAT, 0, (char *)&pinf, 0, FLD_SHORT)
	 && FAIL != CF_get(p_fb, K_KEYSEQNO, 1, (char *)&nkeyseq,
			   0, FLD_SHORT))
	{
		if( PIN_BLOCK_ANSI != pinf )
			DBG_PRINTF((dbg_syswarn,
				"Got incorrect PINFORMAT %hd, exp 1. Ignoring",
				 pinf ));

		pinf = 0;

		sprintf(buf, "%02d", pinf);
		strncpy(M_rawdata + 4, buf, 2);
		sprintf(buf, "%02d", nkeyseq);
		strncpy(M_rawdata + 6, buf, 2);

		len = F2Ivbcd(p_fb, iso, p_i2f);
	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Fmsgtyp
 *
 * Purpose	:  Deblock 4-digit msgtyp BCD to MSGCLS,MSGFN,TXNSRC
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  There are some differences between our concept of
 *		   what messages go in what classes, and VISA's ...
 *		   ... which we sort out afterwards !
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fmsgtyp(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	if (FAIL != (len = I2Fasc(iso, p_fb, p_i2f)))
	{
		if (FAIL == CF_chg(p_fb,C_MSGCLS,0,M_rawdata + 1,
				   (FLDLEN) 0,FLD_CHAR)
		|| FAIL == CF_chg(p_fb,C_MSGFN,0,M_rawdata + 2,
				  (FLDLEN) 0,FLD_CHAR)
		|| FAIL == CF_chg(p_fb,C_TXNSRC,0,M_rawdata + 3,
				  (FLDLEN) 0,FLD_CHAR))
			len = FAIL;
	}
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Imsgtyp
 *
 * Purpose	:  Build 4-digit msgtyp from MSGCLS,MSGFN,TXNSRC
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  Frig differences between our interpretation of ISO93
 *		   and VISA's version of it, specifically:
 *			- Visa use 220 for Acquirer Fee/Funds, we use 720
 *			- Visa use 422 for Issuer Fee/Funds, we use 722
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Imsgtyp(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = SUCCEED;

	strcpy(M_rawdata, "0000");
	if (FAIL == CF_get(p_fb,C_MSGCLS,0,M_rawdata + 1,0,FLD_CHAR)
	|| FAIL == CF_get(p_fb,C_MSGFN,0,M_rawdata + 2,0,FLD_CHAR)
	|| FAIL == CF_get(p_fb,C_TXNSRC,0,M_rawdata + 3,0,FLD_CHAR))
		len = FAIL;

	if (strcmp (M_rawdata, "1304") == 0)
	{
		M_rawdata[3] = '0';
	}
	
	/* hlg BPD_MAINT-131 APR/2018 */
	if (FBNEEDMTICHANGE(p_fb))
	{
		if (FAIL == CF_chg(p_fb,ISO_TAG_F048,0, BPD_VISAOCT,
				   (FLDLEN) 0,FLD_STRING))
		{
			len = FAIL;
		}
		DBG_PRINTF((dbg_progdetail, "ISO_TAG_F048 = [%s]", BPD_VISAOCT));
		
		if (strlen(M_octmti) >= MTILEN)
		{
			strncpy(M_rawdata, M_octmti, MTILEN);
		}
	}

	if (FAIL != len)
		len = F2Iasc(p_fb, iso, p_i2f);
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Fprcode
 *
 * Purpose	:  Deblock processing code
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  Need some post-massaging of TXNCODE !
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fprcode(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len = 0;
	char	txncode[3],
		acctyp1[3],
		acctyp2[3],
		buf1[3],
		buf2[3];
	char	*conbuf;

	if (FAIL != (len = I2Fasc(iso, p_fb, p_i2f)))
	{
		strncpy(txncode, M_rawdata, 2); txncode[2] = EOS;
		strncpy(buf1, M_rawdata + 2, 2); buf1[2] = EOS;
		if (!(conbuf = map_table(buf1, e2iacctyp)))
			len = FAIL;
		else
			strcpy(acctyp1, conbuf);

		strncpy(buf2, M_rawdata + 4, 2); buf2[2] = EOS;
		if (!(conbuf = map_table(buf2, e2iacctyp)))
			len = FAIL;
		else
			strcpy(acctyp2, conbuf);

		if ( FAIL != len && ( FAIL == CF_chg(p_fb,C_ACCTYPE,0,acctyp1,
				  (FLDLEN) 0,FLD_STRING)
/* F54 might not be here and someone might need C_AMTADDACCTYP */
		|| FAIL == CF_chg(p_fb,C_AMTADDACCTYP,0,acctyp1,
				  (FLDLEN) 0,FLD_STRING)
		|| FAIL == CF_chg(p_fb,C_ACCTYPE,1,acctyp2,
				  (FLDLEN) 0,FLD_STRING)) )
			len = FAIL;
	}
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Iprcode
 *
 * Purpose	:  Build processing code from TXNCODE & ACCTYPEs
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  Frig differences between our interpretation of ISO93
 *		   and VISA's version of it.
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Iprcode(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len;
	short	txncode, orgtxncode;
	short	acctyp0, acctyp1;
	char	msgfn;
	char	szaiid[12];
	char buf[64];

	if (FAIL == CF_get(p_fb,C_TXNCODE,0,(char *)&txncode,0,FLD_SHORT))
		len = FAIL;
	else if (FAIL == CF_get(p_fb,C_MSGFN,0,(char *)&msgfn,0,FLD_CHAR))
		len = FAIL;
	else
	{
		orgtxncode = txncode;

		DBG_PRINTF((dbg_progdetail,
			"BPD=>orgtxncode: %d", orgtxncode));
		
		/* e5706717 : avoiding change when txncode == MTC_RETURN and now MTC_CHFUNDSXFER */
		ctxbool update = TRUE;
		
		switch(txncode)
		{
			case MTC_INQAVL:
				txncode = MTC_INQBAL;
			break;
			case MTC_CASHIN:
				txncode = MTC_DEPOS;
			break;
			/* e5706717 - Original implementation */
			case MTC_RETURN:
			/* e5706717 - This case was introduced after BPD issues in production */
			case MTC_CHFUNDSXFER:
			/* e5706717 - AFT*/
			case MTC_NONCSH:
				update = FALSE;
			break;
		}	

		/* set txncode to 23 for all authorisations and
		 * all authorisation reversals */
		/* we don't need to restore txncode in incoming message
		 * as it is not reading into C_TXNCODE */
		if ( update && (FBISAUTH(p_fb) || FBISAUTHREV(p_fb)) )
			txncode = MTC_CHQDGU;
		
		DBG_PRINTF((dbg_progdetail,
			"BPD=>txncode: %d", txncode));
			
		/* set Txncode to 38 for prepaid phone cards.	*/
		if ( F_pres(p_fb, ISO_TAG_F126, 0) && ( MTC_CASH == txncode ))
		{
			if (FAIL != CF_get(p_fb, C_AIID, 0, szaiid, 0, FLD_STRING))
			{
				if (0 == strcmp(szaiid, M_ath_aiid_code))
				{
					txncode = MTC_PREPAYPHONE;
					DBG_PRINTF((dbg_progdetail,
		    			"Prepaid phone txn detected. txn code set to %d", txncode));
				}
			}
		}
			
		if (!F_pres(p_fb, C_ACCTYPE, 0)
			|| FAIL == CF_get(p_fb, C_ACCTYPE, 0, (char *)&acctyp0,
								0, FLD_SHORT))
			acctyp0 = 0;

		/* MJB 1/6/1997 This makes sure
			* we do not pass an unaccceptable
			* code into the network
			*/
		if (msgfn == MFN_REQRSP &&
		    acctyp0 != ACC_TYPE_SAVINGS &&
		    acctyp0 != ACC_TYPE_CHEQUE &&
		    acctyp0 != ACC_TYPE_CREDIT )
			acctyp0 = ACC_TYPE_DEFAULT;

		if (!F_pres(p_fb, C_ACCTYPE, 1)
			|| FAIL == CF_get(p_fb, C_ACCTYPE, 1, (char *)&acctyp1,
								0, FLD_SHORT))
			acctyp1 = 0;
		
		/* hlg BPD_MAINT-131 APR/2018 */		
		if (F_pres(p_fb, ISO_TAG_F048, 0) && SUCCEED == CF_get(p_fb, ISO_TAG_F048, 0, 
 							buf, 0, FLD_STRING))
		{
			DBG_PRINTF((dbg_progdetail, "Response ISO_TAG_F048 = [%s]", buf));
			if (strncmp(buf, BPD_VISAOCT, 3) == 0)
			{
				DBG_PRINTF((dbg_progdetail , "OCT transaction PCODE = [%s/%d]", M_octpcode, PCODELEN));
				if (strlen(M_octpcode) >= PCODELEN)
				{
					DBG_PRINTF((dbg_progdetail , "Updated PCODE from [%02d] to [%s]]", txncode, M_octpcode));
					txncode = atoi(M_octpcode);				
				}
				else
				{
					DBG_PRINTF((dbg_proginfo , "OCT Transaction mapping not defined"));
				}
			}
			else
			{
				DBG_PRINTF((dbg_progdetail , "Not OCT transaction"));
			}
			
		}
		else
		{
			DBG_PRINTF((dbg_progdetail , "Response ISO_TAG_F048 = [NO DATA/NOT PRESENT]"));
		}
		
		if ( MTC_DEPOS != txncode )
			sprintf(M_rawdata, "%02d%02d%02d", txncode, acctyp0, acctyp1);
		else
			sprintf(M_rawdata, "%02d%02d%02d", txncode, acctyp1, acctyp0);

		len = F2Iasc(p_fb, iso, p_i2f);
	}
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Istan
 *
 * Purpose	:  Build STAN
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  Adjust syntactic difference for STAN.
 *			We use a new STAN for reversals, chargebacks etc
 *			and put old one in STANORG. But VISA keep the
 *			same STAN throughout the life of the transaction.
 *			But, beware of ATM partials, which VISA need as
 *			credit adjustment 220 with *NEW* stan.
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Istan(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	long	l;
	int	len;
/*
	if (TRUE == FBISCBREV(p_fb) && FALSE == fev_evbool(p_fb, &Batmpartial))
		len = CF_get(p_fb,C_STANORG,0,(char *)&l,0,FLD_LONG);
	else
*/
	len = CF_get(p_fb,C_STAN,0,(char *)&l,0,FLD_LONG);

	if (FAIL != len)
	{
		sprintf(M_rawdata, "%06ld", l);
		len = F2Iasc(p_fb, iso, p_i2f);
	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Fdtlocal
 *
 * Purpose	:  Deblock YYMMDDhhmmss BCD to DATELOCAL, TIMELOCAL
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fdtlocal(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int len;
	long	yy;
	long	yymmdd, yyyymmdd;
	char buf[9];

	len = I2Fasc(iso, p_fb, p_i2f);
	if (FAIL != len)
	{
		sscanf(M_rawdata, "%6ld", &yymmdd);
		yy = yymmdd / 10000;
		yy = (yy2ccyy((int)yy)/100);
		yyyymmdd = yymmdd + yy * 1000000;
		sprintf(buf, "%08ld", yyyymmdd);
		buf[8] = EOS;
		if (FAIL == CF_chg(p_fb,C_DATELOCAL,0,buf,
				   (FLDLEN) 0,FLD_STRING)
		|| (FAIL == CF_chg(p_fb,C_TIMELOCAL,0,M_rawdata + 6,
				   (FLDLEN) 0,FLD_STRING)))
			len = FAIL;
	}
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Ftmlocal
 *
 * Purpose	:  Deblock hhmmss TIMELOCAL
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Ftmlocal(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int 	len;

	len = I2Fasc(iso, p_fb, p_i2f);
	
	if (FAIL != len)
	{
		if (SUCCEED!=CF_chg(p_fb, C_TIMELOCAL, 0, M_rawdata, (FLDLEN) 0,FLD_STRING))
		{
			/* mvitolin 15/02/2011 BPD_10_001_IT-54 - fixed len issue */
			len=FAIL;
		}
	}
	
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Idtlocal
 *
 * Purpose	:  Build YYMMDDhhmmss BCD from DATELOCAL, TIMELOCAL
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Idtlocal(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int len = SUCCEED;
	long	timelocal, datelocal;

	if (FAIL == CF_get(p_fb, C_DATELOCAL, 0, (char *)&datelocal,0, FLD_LONG)
	    || FAIL == CF_get(p_fb, C_TIMELOCAL, 0, (char *)&timelocal, 0, FLD_LONG))
	{
		DBG_PRINTF((dbg_progdetail,
		    "Datelocal or timelocal is not present. Trying datexmit and timexmit..."));
		if (FAIL == CF_get(p_fb, C_DATEXMIT, 0, (char *)&datelocal,0, FLD_LONG)
	    	    || FAIL == CF_get(p_fb, C_TIMEXMIT, 0, (char *)&timelocal, 0, FLD_LONG))
		{
			len = FAIL;
		}
	}
	if ( SUCCEED == len )
	{
		sprintf(M_rawdata, "%06ld%06ld", datelocal % 1000000, timelocal);
		len = F2Iasc(p_fb, iso, p_i2f);
	}
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Itmlocal
 *
 * Purpose	:  Build hhmmss from DATELOCAL, TIMELOCAL
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Itmlocal(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int 	len = SUCCEED;
	long 	timelocal;

	if ( FAIL == CF_get(p_fb, C_TIMELOCAL, 0, (char *)&timelocal, 0, FLD_LONG) )
	{
		DBG_PRINTF((dbg_progdetail, "Timelocal is not present. Trying timexmit..."));
		if ( FAIL == CF_get(p_fb, C_TIMEXMIT, 0, (char *)&timelocal, 0, FLD_LONG) ) 
		{
			len = FAIL;
		}
	}
	
	if ( SUCCEED == len )
	{
		sprintf(M_rawdata, "%06ld", timelocal);
		len = F2Iasc(p_fb, iso, p_i2f);
	}
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Fdtxmit
 *
 * Purpose	:  Deblock MMDDhhmmss BCD to DATEXMIT, TIMEXMIT
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fdtxmit(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int len;

	len = I2Fasc(iso, p_fb, p_i2f);
	if (FAIL != len)
	{
		if (FAIL == custmdhms2fb(M_rawdata, p_fb, C_DATEXMIT, C_TIMEXMIT))
			len = FAIL;
	}
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Idtxmit
 *
 * Purpose	:  Build MMDDhhmmss BCD from DATEXMIT, TIMEXMIT
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Idtxmit(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int len = SUCCEED;
	long	mm, dd;
	long	timexmit, datexmit;

	if (FAIL == CF_get(p_fb, C_DATEXMIT, 0, (char *)&datexmit,
							0, FLD_LONG)
		|| FAIL == CF_get(p_fb, C_TIMEXMIT, 0, (char *)&timexmit, 0,
								FLD_LONG))
			len = FAIL;
	else
	{
		mm = (datexmit % 10000) / 100;
		dd = datexmit % 100;
		sprintf(M_rawdata, "%02ld%02ld%06ld", mm, dd, timexmit);
		len = F2Iasc(p_fb, iso, p_i2f);
	}
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Fflt
 *
 * Purpose	:  Deblock BCD into float
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  Adjustment for DPs carried out post_i2f
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fflt(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fasc(iso, p_fb, p_i2f);

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Iflt
 *
 * Purpose	:  Build from float
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Iflt(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = SUCCEED;
	int	dp;
	double	f;
	if (FAIL == CF_get(p_fb, p_i2f->fldno, 0, (char *)&f, 0, FLD_DOUBLE))
	{
		len = FAIL;
	}
	else if (FAIL == (dp = visa_dp(p_fb, p_i2f->fldno, 0)))
	{
		len = FAIL;
	}
	else
	{
		while (dp--) f *= 10;
		sprintf(M_rawdata, "%0*.0f", p_i2f->max_len, f);
		len = F2Iasc(p_fb, iso, p_i2f);
	}
	return len;
}


/*------------------------------------------------------------------------
 *
 * Function	:  I2Fcdbcd
 *
 * Purpose	:  Deblock C/D+num into signed float, D = negative
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fcdbcd(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;
	double	f;
	char	cprefix;

	len = I2Fasc(iso, p_fb, p_i2f);
	if (FAIL != len)
	{
		sscanf(M_rawdata, "%c", &cprefix);
		sscanf(M_rawdata + 2, "%lf", &f);
		if ('D' == cprefix)
			f = -f;
/* DBG_PRINTF((dbg_progdetail, "CDBCD: %s -> %f", M_rawdata, f)); */
		/* sprintf(M_rawdata, "%f", f); */
		if (FAIL == CF_chg(p_fb, C_AMTNETSET, 0,
			   (char *)&f, 0, FLD_DOUBLE))
			len = FAIL;
	}
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Icdbcd
 *
 * Purpose	:  Build C/D+ebc from signed float, D = negative
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Icdbcd(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = SUCCEED;
	int	dp;
	double	f;

	if (FAIL == CF_get(p_fb, C_AMTNETSET, 0, (char *)&f, 0, FLD_DOUBLE))
		len = FAIL;
	else if (FAIL == (dp = visa_dp(p_fb, C_AMTNETSET, 0)))
		len = FAIL;
	else
	{
		if (f < 0)
		{
			sprintf(M_rawdata, "%2X", 'D');
			f = -f;
		}
		else
		{
			sprintf(M_rawdata, "%2X", 'C');
		}
		while (dp--) f *= 10;
		sprintf(M_rawdata + 2, "%0*.0f", p_i2f->max_len - 2, f);
		len = F2Iasc(p_fb, iso, p_i2f);
	}
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Fposdc
 *
 * Purpose	:  Deblock POS entry mode to POSCHIC, POSCHAC
 *		   POSCRC, POSOE
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fposdc(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fasc(iso, p_fb, p_i2f);
	if (FAIL == CF_chg(p_fb,C_POSCHIC,0,M_rawdata,
			   (FLDLEN) 0,FLD_STRING)
	 || FAIL == CF_chg(p_fb,C_POSCHAC,0,M_rawdata + 1,
			   (FLDLEN) 0,FLD_CHAR)
	 || FAIL == CF_chg(p_fb,C_POSCRC,0,M_rawdata + 2,
			   (FLDLEN) 0,FLD_CHAR)
	 || FAIL == CF_chg(p_fb,C_POSOE,0,M_rawdata + 3,
			   (FLDLEN) 0,FLD_CHAR)
	 || FAIL == CF_chg(p_fb,C_POSCHP,0,M_rawdata + 4,
			   (FLDLEN) 0,FLD_CHAR)
	 || FAIL == CF_chg(p_fb,C_POSCP,0,M_rawdata + 5,
			   (FLDLEN) 0,FLD_CHAR)
	 || FAIL == CF_chg(p_fb,C_POSCDIM,0,M_rawdata + 6,
			   (FLDLEN) 0,FLD_CHAR)
	 || FAIL == CF_chg(p_fb,C_POSCHAM,0,M_rawdata + 7,
			   (FLDLEN) 0,FLD_CHAR)
	)
		len = FAIL;
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Iposdc
 *
 * Purpose	:  Build POS entry mode from POSCHIC, POSCHAC
 *		   POSCRC, POSOE
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Iposdc(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	char	buf[13];
	int	len;

	memset(buf, ' ', sizeof(buf));
	buf[sizeof(buf)-1] = EOS;
	if (FAIL == CF_get(p_fb,C_POSCHIC,0,buf,0,FLD_STRING)
	 || FAIL == CF_get(p_fb,C_POSOE,0,buf + 3,0,FLD_CHAR)
	 || FAIL == CF_get(p_fb,C_POSCHP,0,buf + 4,0,FLD_CHAR)
	 || FAIL == CF_get(p_fb,C_POSCP,0,buf + 5,0,FLD_CHAR)
	 || FAIL == CF_get(p_fb,C_POSCDIM,0,buf + 6,0,FLD_CHAR)
	 || FAIL == CF_get(p_fb,C_POSCHAM,0,buf + 7,0,FLD_CHAR)
	)
		len = FAIL;

	/* NMR16001 - Set POSCHAC to '9' when not present. Resolves
	 *            error from IPM import where value will be set to ' '
	 */
	if (FAIL == CF_get(p_fb,C_POSCHAC,0,buf + 1,0,FLD_CHAR))
	{
		DBG_PRINTF((dbg_progdetail,"POSCHAC not present, set to '9'"));
		buf[1] = '9';
	}

	/* MP BZWM-677 - assume POSCRC is '9' if not present
	 * error from IPM import */
	if (FAIL == CF_get(p_fb,C_POSCRC,0,buf + 2,0,FLD_CHAR))
	{
		DBG_PRINTF((dbg_progdetail,"POSCRC not present, set to '9'"));
		buf[2] = '9';
	}

	strcpy(M_rawdata, buf);
	len = F2Iasc(p_fb, iso, p_i2f);
	return len;
}
/*------------------------------------------------------------------------
 *
 * Function	:  I2Fcaloc
 *
 * Purpose	:  Converts crdacptloc from ICBS ISO to internal
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fcaloc(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	char	buf[130];
	char	a1[4];
	char	a2[3];
	int	len;

	len = I2Fasc(iso, p_fb, p_i2f);
	if (FAIL != len)
	{
		memset( buf, 0, sizeof(buf) );
		strncpy(buf, M_rawdata, 22);	/* name			*/
		stp_right(buf);
		if (EOS == buf[0]) buf[0] = ' ';
		strcat(buf, LOC_DELIM_STR);
		strcat(buf, LOC_DELIM_STR);	/* add empty street	*/
		strncat(buf, M_rawdata+22, 13);	/* city			*/
		stp_right(buf);
		strcat(buf, LOC_DELIM_STR);
		strcat(buf, "          " );	/* empty postcode 10	*/
		strncpy(a1, M_rawdata + 35, 3); a1[3] = EOS;
		strcat(buf, a1);
		strncpy(a2, M_rawdata + 38, 2); a2[2] = EOS;
		sprintf(buf+strlen(buf), "%s", ctry_a2ton(a2));
		strcpy(M_rawdata, buf);
		if( SUCCEED != CF_chg(p_fb, C_CRDACPTLOC,
					0,M_rawdata, (FLDLEN) 0,FLD_CHAR) )
			len = FAIL;

	}
	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Ffld44
 *
 * Purpose	:  Converts field 44 - Additional Response Data
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Ffld44(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len, ret = SUCCEED;
	char	scbal[13], sabal[13];
	amtadd_t amt;

	len = I2Fva2asc(iso, p_fb, p_i2f);

	memset(scbal, 0, sizeof(scbal));
	memset(sabal, 0, sizeof(sabal));
	
	strncpy(scbal, M_rawdata+1, 12);
	strncpy(sabal, M_rawdata+13, 12);

	DBG_PRINTF((dbg_progdetail, "Current balance:   [%s]", scbal)); 
	DBG_PRINTF((dbg_progdetail, "Available balance: [%s]", sabal));

	if ( SUCCEED == F_get(p_fb, C_AMTADDACCTYP, 0, (char *)&amt.acctyp, (FLDLEN) 0) )
	{
		amt.occ = 0;
		amt.accidx = 1;
		strcpy(amt.curr, "000"); /* C_CURBILL is not yet available, will change it in post_i2f */
		amt.amttyp = ATC_ACC_BLKAMT_NEW_OL;
		amt.amt = atof(scbal) - atof(sabal);
		
		DBG_PRINTF((dbg_progdetail, "Adding Cortex blkamt:   [%lf]", amt.amt)); 
		ret = amtadd_add(p_fb, &amt);
	}
	else
	{
		ret = FAIL;
	}
	
	if ( SUCCEED == ret )
	{
		amt.occ = 1;
		amt.amttyp = ATC_ACC_AVLBAL_NEW;
		amt.amt = atof(scbal);
		
		DBG_PRINTF((dbg_progdetail, "Adding Cortex avlbal:   [%lf]", amt.amt)); 
		ret = amtadd_add(p_fb, &amt);
	}

	if( FAIL == ret )
		len = FAIL;
	
	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Ffld48
 *
 * Purpose	:  Converts field 48 - ATM Additiona Data
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Ffld48(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;
	char	szbuf[64];
	
	/* mvitolin: I2Fasc->F2Iva3asc */
	len = I2Fva3asc(iso, p_fb, p_i2f);

	/* hlg BPD_MAINT-131 MAY/2018 for rsp MTI must be 1 
	 * (authorisation) */
	DBG_PRINTF((dbg_progdetail,
				"Cheking if is VISA OCT TXN [%s]", M_rawdata));
	if (strncmp(M_rawdata, BPD_VISAOCT, 3) == 0)
	{
		DBG_PRINTF((dbg_progdetail,
					"VISA OCT TXNCODE detected, updating MSGCLS "));
		if (SUCCEED == CF_chg(p_fb,C_MSGCLS,0,(char *)"1",
			   (FLDLEN) 0,FLD_CHAR))
		{
			DBG_PRINTF((dbg_progdetail,
					"MSGCLS updated sucessfully "));
			
		}
		else
		{
			DBG_PRINTF(( dbg_syserr, "Unable to update C_MSGCLS in FB "));
		}
		
		M_rawdata[0] = EOS;
	}
	else 
	{
		DBG_PRINTF((dbg_progdetail,
					"Not VISA OCT TXN, continue normal flow"));
	}
	
	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Ffld60
 *
 * Purpose	:  Converts field 60 - ATM Terminal Data
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Ffld60(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fva3asc(iso, p_fb, p_i2f);

	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Ffld61
 *
 * Purpose	:  Converts field 61 - Card Iss and Auth Data
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Ffld61(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fasc(iso, p_fb, p_i2f);

	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Ffld70
 *
 * Purpose	:  Converts field 70
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Ffld70(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;
	long	mfc = FAIL;
	
	len = I2Fasc(iso, p_fb, p_i2f);

	if(!strncmp(M_rawdata, "001", 3))
		mfc = MFC_NETMGT_SIGN_ON;
	else if(!strncmp(M_rawdata, "002", 3))
		mfc = MFC_NETMGT_SIGN_OFF;
	else if(!strncmp(M_rawdata, "301", 3))
		mfc = MFC_NETMGT_ECHO;
	else
	{
		DBG_PRINTF((dbg_fatal, "Error: Unknown net management code [%s]", M_rawdata));
		len = FAIL;
	}

	if (FAIL != len && SUCCEED != CF_chg(p_fb, C_FNCODE, 0, (char *)&mfc, 0, FLD_LONG))
		len = FAIL;
	
	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Ffld90
 *
 * Purpose	:  Converts field 90
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Ffld90(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fasc(iso, p_fb, p_i2f);

	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Ffld95
 *
 * Purpose	:  Converts field 95
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Ffld95(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fasc(iso, p_fb, p_i2f);

	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Ffld120
 *
 * Purpose	:  Converts field 120 - ATM Terminal Address
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Ffld120(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	/* mvitolin:  I2Fasc->I2Fva3asc */
	len = I2Fva3asc(iso, p_fb, p_i2f);

	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Ffld123
 *
 * Purpose	:  Converts field 123
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Ffld123(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fasc(iso, p_fb, p_i2f);

	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Ffld124
 *
 * Purpose	:  Converts field 124
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Ffld124(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fva3asc(iso, p_fb, p_i2f);

	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Icaloc
 *
 * Purpose	:  Converts crdacptloc from internal to ICBS ISO
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Icaloc(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	ret = SUCCEED;
	char	buf[41];
	char	*name,
		*street,
		*city,
		*rest;
	char	*visa_cntrycode;

	M_rawdata[0] = 0;
	_UNUSED_(street)

	if( FAIL == CF_get(p_fb, C_CRDACPTLOC, 0, M_rawdata, 0, FLD_STRING))
	{
		ret = FAIL;
	}
	else
	{
		name   = nstrtok( M_rawdata, LOC_DELIM );
		street = nstrtok( NULL,  LOC_DELIM );
		city   = nstrtok( NULL,  LOC_DELIM );
		rest   = nstrtok( NULL,  LOC_DELIM );

		if( 16 != strlen(rest) )
		{
			ret = FAIL;
			DBG_PRINTF(( dbg_syserr, "Error: Card acceptor location C_CRDACPTLOC "
				    "has incorrect length. Cannot build P43." ));
		}
	}

	if( SUCCEED == ret )
	{
		if( M_message_simulator )	/* Cant call services */
			visa_cntrycode = rest+13;
		else
			visa_cntrycode = ctry_ntoa2( rest+13 );
	}

	if( SUCCEED == ret )
	{
		memset( buf, ' ', sizeof( buf ) );
		buf[sizeof(buf)-1] = 0;

		memcpy( buf,    name, strlen(name) > 22 ? 22 : strlen(name) );
		memcpy( buf+22, city, strlen(city) > 13 ? 13 : strlen(city) );
		memcpy( buf+35, rest+10, 3 );
		memcpy( buf+38, visa_cntrycode, 2 );
		strcpy(M_rawdata, buf);
		ret = F2Iasc(p_fb, iso, p_i2f);
	}

	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Ifld44
 *
 * Purpose	:  Converts field 44 - DUMMY
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Ifld44 (FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	ret = SUCCEED;
	
	sprintf(M_rawdata, "%-27.27s", " ");
	ret = F2Iasc(p_fb, iso, p_i2f);
	
	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Ifld48
 *
 * Purpose	:  Converts field 48 - ATM Additional Data
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Ifld48 (FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	ret = SUCCEED;
	char	szbuf[64];
	
	/* mvitolin BPD_10_001_IT-54 11/02/2011 */
	if (!F_pres(p_fb, ISO_TAG_F048, 0) || SUCCEED != CF_get(p_fb, ISO_TAG_F048, 0, 
							szbuf, 0, FLD_STRING))
	{
		szbuf[0] = EOS;
	}
	
	/* mvitolin BPD_10_001_IT-54 11/02/2011 */
	if( FAIL != ret )
	{
		sprintf(M_rawdata, "%-44.44s", szbuf);
		ret = F2Iva3asc(p_fb, iso, p_i2f);
	}

	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Ifld60
 *
 * Purpose	:  Converts field 60 - ATM Terminal Data
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Ifld60 (FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int len2 = SUCCEED;
	char poscap[200];
	
	int	len = SUCCEED;
	char	szbuf[64] = "";
	char	afe[12] = "";
	map_tbl_t i2vf60[] =
{
 { "VISAFE",	"VISA",	 STR },
 { "BPDFE",	"IST",	 STR },
 { NULL }
};


	if ( F_pres(p_fb, ISO_TAG_F060, 0) )
	{
		len = CF_get(p_fb, ISO_TAG_F060, 0, szbuf, 0, FLD_STRING);
		
	}
	else if ( SUCCEED == ( len = CF_get(p_fb, I_AFE, 0, afe, 0, FLD_STRING) ) )
	{
		sprintf(szbuf, "%-4.4s%-4.4s%-4.4s", "0000", map_table(afe, i2vf60), "+000");

		/* Autorizaciones parciales */
		memset(poscap, 0, sizeof(poscap));
		if ( SUCCEED == ( len2 = CF_get(p_fb, C_POSCAP, 0, poscap, 0, FLD_STRING) ) ) 
		{
			DBG_PRINTF(( dbg_progdetail, "poscap [%s] len [%ld] de060 [%s]", poscap, strlen(poscap), szbuf));
			if (poscap[10]=='1') 
			{
				szbuf[9] = '1';
				DBG_PRINTF(( dbg_progdetail, "partial authorization flag on -> de060[%s]", szbuf));
			}
			else 
			{
				DBG_PRINTF(( dbg_progdetail, "partial authorization flag off"));
			}
		}		
		
	}
	
	if( FAIL != len )
	{
		sprintf(M_rawdata, "%-12.12s", szbuf);
		len = F2Iva3asc(p_fb, iso, p_i2f);
	}

	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Ifld61
 *
 * Purpose	:  Converts field 61 - Card Auth and Iss Data
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Ifld61 (FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	ret = SUCCEED;
	char	buf[48];

	if( SUCCEED == ret )
	{
		memset( buf, ' ', sizeof( buf ) );
		buf[sizeof(buf)-1] = 0;

		sprintf(buf, "%s%s%s%s", "0000", "0000", "0000", "P");
		strcpy(M_rawdata, buf);
		ret = F2Iva3asc(p_fb, iso, p_i2f);
	}

	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Ifld70
 *
 * Purpose	:  Converts field 70
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Ifld70 (FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	ret = SUCCEED;
	short	mfc;
	
	switch (mfc = cbf_get_fncode(p_fb))
	{
		case MFC_NETMGT_SIGN_ON:  strcpy(M_rawdata, "001"); break;
		case MFC_NETMGT_SIGN_OFF: strcpy(M_rawdata, "002"); break;	
		case MFC_NETMGT_ECHO:     strcpy(M_rawdata, "301"); break;	
		default:
			DBG_PRINTF((dbg_fatal, "Error: Unknown net management function code [%hd]", mfc));
			ret = FAIL; 
			break;
	}

	if( SUCCEED == ret )
	{
		ret = F2Iasc(p_fb, iso, p_i2f);
	}

	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Ifld90
 *
 * Purpose	:  Converts field 90 - Original Data Elements
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Ifld90 (FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	ret = SUCCEED;
	long	stan=0;
	long    timeloc, dateloc;
	
	sprintf(M_rawdata, "%042d", 0);
	
	if (FAIL == CF_get(p_fb, C_MSGCLSORG, 0, M_rawdata+1, 0, FLD_CHAR)
	 || FAIL == CF_get(p_fb, C_MSGFNORG,  0, M_rawdata+2, 0, FLD_CHAR)
	 || FAIL == CF_get(p_fb, C_TXNSRCORG, 0, M_rawdata+3, 0, FLD_CHAR))
		ret = FAIL;

	if (FAIL == CF_get(p_fb, C_STANORG, 0, (char *)&stan, 0, FLD_LONG))
		ret = FAIL;
	else
		sprintf(M_rawdata+4, "%012ld", stan);

	if (FAIL == CF_get(p_fb, C_DATELOCALORG, 0, (char *)&dateloc, 0, FLD_LONG)
         || FAIL == CF_get(p_fb, C_TIMELOCALORG, 0, (char *)&timeloc, 0, FLD_LONG))
		ret = FAIL;
        else
		sprintf(M_rawdata, "%02ld%02ld%06ld00%02ld%02ld", (dateloc % 10000) / 100, dateloc % 100, 
			timeloc, (dateloc % 10000) / 100, dateloc % 100);
	
	if( SUCCEED == ret )
	{
		ret = F2Iasc(p_fb, iso, p_i2f);
	}

	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Ifld95
 *
 * Purpose	:  Converts field 95
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Ifld95 (FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int dp, ret = FAIL;
	double  amt, amtorg, amt95, ratebill = 1.0f;    
	char curtxn[4], curbillorg[4];

	sprintf(M_rawdata, "%042d", 0);
	memset(curtxn, 0, sizeof(curtxn));
	memset(curbillorg, 0, sizeof(curbillorg));

	/*comparing currencies*/
	if(FAIL == F_get(p_fb, C_CURTXN, 0, curtxn, 0))
		return ret;

	if(FAIL != F_get(p_fb, C_CURBILLORG, 0, curbillorg, 0))
	{
		if (strncmp(curtxn, curbillorg, sizeof(curtxn)) != 0
		 && FAIL == CF_get(p_fb, C_RATEBILLORG, 0, (char *)&ratebill, 0, FLD_DOUBLE))
			return ret;
	}

	DBG_PRINTF((dbg_proginfo, "ICBS F2Ifld95 [2] - currency [%s][%s]", curtxn, curbillorg));

	/*loading amounts*/
	if (FAIL != CF_get(p_fb, C_AMTTXNORG, 0, (char *)&amtorg, 0, FLD_DOUBLE)
	 && FAIL != CF_get(p_fb, C_AMTTXN, 0, (char *)&amt, 0, FLD_DOUBLE))
	{
		amt95 = amtorg - amt;
		if ( FAIL != (ret = dp = visa_dp(p_fb, C_AMTBILL, 0)) )
		{
			while (dp--) amt95 *= 10;
			sprintf(M_rawdata, "%012.0f%012.0f%09d%09d", amt95*ratebill, 0.0, 0, 0);
			ret = F2Iasc(p_fb, iso, p_i2f);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Ifld120
 *
 * Purpose	:  Converts field 120 - ATM Terminal Data
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Ifld120 (FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	ret = SUCCEED;
	char	buf[256];
	char	*name;

	memset( buf, 0, sizeof( buf ) );
	
	if ( F_pres(p_fb, ISO_TAG_F120, 0) ) 
	{
		ret = CF_get(p_fb, ISO_TAG_F120, 0, (char *)buf, (FLDLEN)0, FLD_STRING);
		name = buf;
	}
	else
	{
		ret = CF_get(p_fb, C_CRDACPTLOC, 0, (char *)buf, (FLDLEN)0, FLD_STRING);
		name = nstrtok( buf, LOC_DELIM );
	}
	
	if ( FAIL != ret )
	{
		sprintf(M_rawdata, "%-25.25s", name);
		ret = F2Iva3asc(p_fb, iso, p_i2f);
	}

	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Ifld123
 *
 * Purpose	:  Converts field 123
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *----------------------------------------------------------------------*/
ctxprivate int F2Ifld123 (FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	ret = SUCCEED;
	char	buf[10];
	
	if ( SUCCEED == (ret = CF_get(p_fb, C_AUTHLIFE, 0, buf, 0, FLD_STRING)) )
	{
		sprintf(M_rawdata, "%-2.2s", buf);
		ret = F2Iva2asc(p_fb, iso, p_i2f);
	}
	
	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Ifld124
 *
 * Purpose	:  Converts field 124 - Fee Description
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *----------------------------------------------------------------------*/
ctxprivate int F2Ifld124 (FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	ret = SUCCEED;
	char	buf[256] = "";


	if( SUCCEED == CF_get(p_fb, C_FEEDESCR, 0, buf, 0, FLD_STRING) )
	{
		sprintf(M_rawdata, "%-30.30s", buf);
		ret = F2Iva3asc(p_fb, iso, p_i2f);
	}
	else
	{
		ret = FAIL;
	}
	
	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Fact
 *
 * Purpose	:  Deblock ICBS action code to C_RSPCODE, C_ACTIONCODE
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fact(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;
	char	szbuf[3];
	char	*res;

	len = I2Fasc(iso, p_fb, p_i2f);

	if (FAIL != len)
	{
		strncpy(szbuf, M_rawdata, 2);
		szbuf[2] = EOS;

		res = map_revtab(szbuf, i2vrspc);
		
		if( NULL == res )
		{
			DBG_PRINTF((dbg_fatal, "Error: Cannot find mapping for [%s] response code", szbuf));
			len = FAIL;
		}
		else if ( FAIL == CF_chg(p_fb, C_ACTIONCODE, 0, res, (FLDLEN) 0, FLD_CHAR)
			|| FAIL == CF_chg(p_fb, C_RSPCODE, 0, res + 1, (FLDLEN) 0, FLD_STRING) )
		{
			len = FAIL;
		}
		else
		{
			DBG_PRINTF((dbg_progdetail, "Response code mapping [%s]->[%s]", szbuf, res));
		}
	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Iact
 *
 * Purpose	:  Build ICBS action code from C_RSPCODE, C_ACTIONCODE
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Iact(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = SUCCEED;
	char	ctx[4] = "", icbs[3] = "";
	short	reason=0;
	char 	*res = NULL;


	if( FBISCBREV(p_fb) && FBISREQ(p_fb) )
	{
		if (!F_pres(p_fb, C_REASONCODE, 0))
		{
			strcpy(icbs, "00");
		}
		else
		{
			CF_get(p_fb, C_REASONCODE, 0, (char *)&reason, 0, FLD_SHORT);
			
			if (MRC_REV_CUST_CNX == reason)
				strcpy(icbs, "17");
			else if (MRC_REV_INV_RSP == reason)
				strcpy(icbs, "20");
			else if (MRC_REV_NOT_CMP == reason || MRC_REV_TOUT_CSH == reason || MRC_REV_TOUT_CRD == reason)
				strcpy(icbs, "21");
			else if (MRC_REV_SUS_MAL == reason)
				strcpy(icbs, "22");
			else if (MRC_REV_PART == reason)
				strcpy(icbs, "32");
			else if (MRC_REV_TOO_LATE == reason || MRC_TOUT_WAIT_RSP == reason)
				strcpy(icbs, "68");
			else
				strcpy(icbs, "00");
		}
	}
	else
	{
		if (FAIL == CF_get(p_fb, C_ACTIONCODE, 0, ctx, 0, FLD_CHAR)
			|| FAIL == CF_get(p_fb, C_RSPCODE, 0, ctx + 1, 0, FLD_STRING))
		{
			return FAIL;
		}
	
		res = map_table(ctx, i2vrspc);
		
		if( NULL == res )
		{
			DBG_PRINTF((dbg_fatal, "Error: Cannot find mapping for [%s] action/response code", ctx));
			len = FAIL;
		}
		else
		{
			strcpy(icbs, res);
			DBG_PRINTF((dbg_progdetail, "Response code mapping [%s]->[%s]", ctx, icbs));
		}
	}
	
	strcpy(M_rawdata, icbs);
	
	len = F2Iasc(p_fb, iso, p_i2f);
	
	return len;
}


/*------------------------------------------------------------------------
 *
 * Function	:  I2Frate
 *
 * Purpose	:  Deblock rate as 1-byte DP offset + rate to float
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Frate(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len = 0;
	int	move;
	double	f;

	if (FAIL != (len = I2Fasc(iso, p_fb, p_i2f)))
	{
		move = M_rawdata[0] - '0';

		sscanf(M_rawdata + 1, "%lf", &f);
		DBG_PRINTF(( dbg_progdetail, "M_rawdata: %s, f: %10.10f",
					M_rawdata, f ));

		while(move--)
			f /= 10;

		sprintf(M_rawdata, "%lf", f);
		DBG_PRINTF(( dbg_progdetail, "M_rawdata: %s, f: %10.10f",
					M_rawdata, f ));
	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Faddrspdata
 *
 * Purpose	:  Deblock ADRSPDATA which contains statement data
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Faddrspdata(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int len = 0;
	short txncode;

	/* Convert to ASCII string */
	len = I2Fl2asc(iso, p_fb, p_i2f);

	/* Remove the 2 byte statement type prefix from the beginning
         * of the string.
         */
	memmove(M_rawdata, M_rawdata+2, strlen(M_rawdata)-1);

	/* CN 6446 only include ADDRSPDATA if transaction has financial impact
	*/
	if (FAIL != len)
	{
		/* get the txncode ...
		*/
		if (FAIL==CF_get(p_fb,C_TXNCODE,0,(char *)&txncode,0,FLD_SHORT))
		{
			DBG_PRINTF((dbg_syswarn, "I2Faddrspdata: "
				"failed to get TXNCODE"));
			len = FAIL;
		}
		/* and if financial impact, update C_ADDRSPDATA
		*/
		else if (MTC_MIN_ENQUIRY > txncode || MTC_MAX_ENQUIRY < txncode)
		{
			DBG_PRINTF((dbg_syswarn, "I2Faddrspdata: txncode [%d], "
				"financial impact txn - include ADDRSPDATA",
				txncode));

			if (FAIL == CF_chg(p_fb,C_ADDRSPDATA,0,M_rawdata,
					   (FLDLEN) 0,FLD_STRING))
			{
				len = FAIL;
			}
		}
		else
		{
			DBG_PRINTF((dbg_syswarn, "I2Faddrspdata: txncode [%d], "
				"non-financial impact txn - ignore ADDRSPDATA",
				txncode));
		}
	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Irate
 *
 * Purpose	:  Deblock rate as 1-byte DP offset + rate to float
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Irate(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len;
	double	val;

	/* Get the rate out of the FB in to a double. */
	if( FAIL == CF_get(p_fb, p_i2f->fldno, 0, (char *)&val,
							0, FLD_DOUBLE) )
	{
		len = FAIL;
	}
	else
	{
		/* Convert it to an 8 byte string and stick it in M_rawdata */
		F2Irateconvert( val, M_rawdata );

		/* Then convert it to BCD */
		len = F2Iasc(p_fb, iso, p_i2f);
	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  adjust_dp
 *
 * Purpose	:  Adjust all amount fields for decimal places
 *
 * Parameters	:  p_fb - fielded buffer
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int adjust_dp(FBFR *p_fb)
{
static	FLDID	flds[] = {
		C_AMTTXN, C_AMTBILL, C_AMTSET, C_AMTTXNCB, C_AMTBILLCB,
		C_AMTTXNFEE, C_AMTADD, C_AMTRPLC,
		C_CREDAMT, C_CREDREVAMT, C_DEBAMT, C_DEBREVAMT,
		C_AMTNETSET, C_AMTTXNORG, I_BLKAMT, I_AVLBAL, I_CLRBAL,
		I_UNCLRBAL, I_CREDITLIM, I_CYCLELIM,
		X_SRCPOSTAMT, X_DSTPOSTAMT, C_AMTBILLORG,
		BADFLDID };
	double	f;
	FLDID	fldno;
	int	i, dp, occ;
	int	ret = SUCCEED;

	if (F_pres(p_fb, C_AMTTXN, 0) && !F_pres(p_fb, C_CURTXN, 0)
		&& TRUE == FBISRSP(p_fb))
	{
		DBG_PRINTF((dbg_progdetail,
			"Rsp: CURTXN missing, so zapping AMTTXN"));
		F_del(p_fb, C_AMTTXN, 0);
	}
	for (i = 0; SUCCEED == ret && BADFLDID != (fldno = flds[i]); ++i)
	{
		occ = F_occur(p_fb, fldno);
		while(SUCCEED == ret && --occ >= 0)
		{
			if (FAIL == CF_get(p_fb, fldno, occ, (char *)&f,
							0, FLD_DOUBLE)
				|| (FAIL == (dp = visa_dp(p_fb, fldno, occ))))
			{
				ret = FAIL;
			}
			else
			{
				while (dp--) f /= 10;
				if (FAIL == (CF_chg(p_fb, fldno, occ,
					(char *)&f, (FLDLEN) 0, FLD_DOUBLE)))
					ret = FAIL;
			}
		}
	}
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Ienqn
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Ienqn(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int len = SUCCEED;
	long lvalue;
	char buf[10];

	sscanf(M_rawdata, "%ld", &lvalue);
	sprintf(buf, "%ld", lvalue);
	strcpy(M_rawdata, buf);
	len = F2Iasc(p_fb, iso, p_i2f);
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  custmdhms2fb
 *
 * Purpose	:  Deblock ASCII buffer MMDDHHMMSS to date & time
 *		   in specified FB fields in internal format
 *
 * Parameters	:  buf - ASCII buffer
 *		   p_fb - fielded buffer
 *		   datefld - field number for date YYYYMMDD
 *		   timefld - field number for time HHMMSS
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int custmdhms2fb(char *buf, FBFR *p_fb, FLDID datefld, FLDID timefld)
{
	long	today = local_date();
	long	mm, dd, yy_today, mm_today;
	long	timexmit, datexmit;
	int	ret = SUCCEED;

	sscanf(buf, "%2ld%2ld%6ld", &mm, &dd, &timexmit);
	mm_today = (today % 10000) / 100;
	yy_today = today / 10000;
	if (1 == mm && 12 == mm_today)
		yy_today++;
	else if (12 == mm && 1 == mm_today)
	{
/*
 * We must also take account of current date being jan and txndate being dec
*/
		yy_today--;
	}

	datexmit = dd +(mm * 100) + (yy_today * 10000);
/*DBG_PRINTF((dbg_progdetail, "date %08ld time %06ld", datexmit, timexmit));*/
	if (FAIL == CF_chg(p_fb, datefld, 0, (char *)&datexmit,
						(FLDLEN) 0, FLD_LONG)
		|| FAIL == CF_chg(p_fb, timefld, 0, (char *)&timexmit,
				  (FLDLEN) 0, FLD_LONG))
		ret = FAIL;
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  post_i2f
 *
 * Purpose	:  Carry out any adjustments in message that are relational,
 *		   i.e. depend on more than one field.
 *
 * Parameters	:  p_fb - fielded buffer
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:  Processing carried out:
 *
 *			- Adjust all amounts to appropriate number of DPs
 *			- Adjust syntactic difference for partial reversals
 *				we put original amount in AMTTXNORG, actual
 *				amount in AMTTXN, VISA put original amount
 *				in AMTTXN, actual amount in AMTRPLC
 *			  (In fact, Amount, Replacement is hardly ever used !)
 *			  (Should we have AMTxxxORG set up here ?)
 *			- Adjust syntactic difference for STAN
 *				we use a new stan for reversals (chgbks),
 *				VISA use the same as the original. We can't
 *				generate a new STAN for incomings, but we
 *				can set up STANORG.
 *			- Set up FNCODE, if not already set.
 *
 *----------------------------------------------------------------------*/
ctxprivate int post_i2f(FBFR *p_fb)
{
	static	char	rspsrc[] = { RSPSRC_HOST, EOS, EOS };
	int	ret = SUCCEED;
	long	lsysdate;
	/*short	norgcls = MCL_FIN;*/
	/*short	norgfn  = MFN_REQ;*/
	/*short	norgts  = MOR_ACQ;*/
	char	szt2data[40];
	char	szexpdate[5];
	/*short	nposcdim = MCDIM_MAGCVV;*/
	short	npospcc = MPCC_12;
	long	lrecdate;
	
	
	DBG_PRINTF((dbg_syswarn, "Starting post-conversion tasks... "));

	if (SUCCEED == ret && F_pres(p_fb, C_CURBILL, 0))
	{
		ret = adjust_addamt(p_fb);
	}
	
	if (SUCCEED == ret)
		ret = adjust_dp(p_fb);

	if (SUCCEED == ret && FBISRSP(p_fb) && !F_pres(p_fb, I_RSPSRC, 0))
	{
		DBG_PRINTF((dbg_progdetail, "Setting response source I_RSPSRC to [%s]", rspsrc));
		if (SUCCEED != CF_chg(p_fb, I_RSPSRC, 0, rspsrc, (FLDLEN) 0, FLD_STRING))
			ret = FAIL;
	}

					/* 23/5/97 Deleted code which
					 * was setting up org vals to
					 * fixed vals since was overiding
					 * values set upfrom
					 */

	if(FALSE == fev_evbool(p_fb, &B5xx) && FALSE == fev_evbool(p_fb, &B8xx))
	{
		ret = get_sysdate(&lsysdate);

		if (F_pres(p_fb,C_DATEREC,0) )
			ret = CF_get(p_fb, C_DATEREC, 0, (char*)&lrecdate, (FLDLEN) 0, FLD_LONG);

		if ((SUCCEED == ret) && FBISREQ(p_fb))
		{
			if (!F_pres(p_fb,C_DATEREC,0) )
				ret = CF_chg(p_fb, I_INDATEREC, 0, (char*)&lsysdate, (FLDLEN) 0, FLD_LONG);
			else
				ret = CF_chg(p_fb, I_INDATEREC, 0, (char*)&lrecdate, (FLDLEN) 0, FLD_LONG);
			
			if (SUCCEED == ret)
				ret = CF_chg(p_fb, I_SYSDATE, 0, (char*)&lsysdate, (FLDLEN) 0, FLD_LONG);
		}
		else if ((SUCCEED == ret) && FBISRSP(p_fb))
		{
			if (!F_pres(p_fb,C_DATEREC,0) )
				ret = CF_chg(p_fb, I_OUTDATEREC, 0, (char*)&lsysdate, (FLDLEN) 0, FLD_LONG);
			else
				ret = CF_chg(p_fb, I_OUTDATEREC, 0, (char*)&lrecdate, (FLDLEN) 0, FLD_LONG);
			
			if (SUCCEED == ret)
				ret = CF_chg(p_fb, I_SYSDATE, 0, (char*)&lsysdate, (FLDLEN) 0, FLD_LONG);
		}
	}

	/* Fill in C_DATEEXP from the data in T2DATA */
	if( FAIL != ret  && FBISFIN(p_fb) && FBISREQ(p_fb) && F_pres(p_fb, C_T2DATA, 0) )
	{
		if( FAIL == CF_get(p_fb, C_T2DATA, 0, szt2data, (FLDLEN) 0, FLD_STRING) )
			ret = FAIL;
			
		if( FAIL != ret )
		{
			memset( szexpdate, 0, sizeof(szexpdate) );
			strncpy( szexpdate, strchr( szt2data, '=' ) + 1, sizeof(szexpdate) - 1);
			
			if( FAIL != ret )
			{
				ret = CF_chg(p_fb, C_DATEEXP, 0, szexpdate, (FLDLEN) 0,FLD_STRING);
			}
		}
	}

	if( FAIL == ret || (FAIL == CF_chg(p_fb, C_POSPCC, 0, (char*) &npospcc, (FLDLEN) 0, FLD_SHORT)))
		ret = FAIL;

	return	ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  adjust_addamt
 *
 * Purpose	:  Adjust currency for additional amounts
 *
 * Parameters	:  
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:
 *
 *----------------------------------------------------------------------*/
ctxprivate int	adjust_addamt(FBFR *p_fb)
{
	int 	i = 0;
	int 	ret = SUCCEED;
	char	curr[4];
	
	ret = CF_get(p_fb, C_CURBILL, 0, curr, 0, FLD_STRING);
	
	while ( SUCCEED == ret && amtadd_pres(p_fb, i) )
	{
		ret = F_chg(p_fb, C_AMTADDCUR, i, curr, 0);
		i++;
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  get_sysdate
 *
 * Purpose	:  Get the system date by calling SYSDATE service
 *
 * Parameters	:  lpsysdate (long) system date
 *
 * Returns	:  SUCCEED or FAIL
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int	get_sysdate(long* lpsysdate)
{
	int	ret = SUCCEED;
	short	ig = GENDBCMD_GET;
	long	rsplen = 0L;
	FBFR	*p_lfb = NULL;


	if( NULL == ( p_lfb = (FBFR*) ntp_alloc("FML", NULL, 0)))
		DBG_PRINTF((dbg_progdetail, "ntp_alloc failed!!!"));

	if (SUCCEED == ret)
	{
		ret = F_add(p_lfb, I_GENDBCMD, (char *)&ig, 0);
	}

	if (SUCCEED == ret && FAIL == (ret = ntp_call(SYSDATESVC,
						      (char *)p_lfb,
						      0L,
						      (char **)&p_lfb,
						      &rsplen,
						      0)))
		DBG_PRINTF((dbg_syserr, "tpcall %s failed %d [%s]",
			    SYSDATESVC,ntp_errno(),ntp_strerror(ntp_errno())));

	if( FAIL != ret )
	{
		ret = CF_get(p_lfb, I_SYSDATE, 0, (char *)lpsysdate, 0,
			     FLD_LONG);
	}

	ntp_free((char *)p_lfb);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  visa_dp
 *
 * Purpose	:  Get number of decimal places for specified FB field
 *
 * Parameters	:  p_fb - fielded buffer
 *		   fldno - field number of amount
 *		   occ - field occurrence
 *
 * Returns	:  Decimal places of field, or FAIL if missing field
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int visa_dp(FBFR *p_fb, FLDID fldno, int occ)
{
	FLDID	curr_fldno = BADFLDID;
	char	curr[4];
	int	ret = FAIL;

	/* The message simulator has to run without TUXEDO being around, so
	 * dont bother calling any services */
	if( M_message_simulator == TRUE ) return 2;

	switch (fldno)
	{
		case C_AMTRPLC:
			switch (occ)
			{
				case 0:	/* Actual amt, txn	*/
				case 2:	/* Acual amt, sett	*/
					curr_fldno = C_CURTXN;
					break;
				case 1:	/* Actual amt, Txn Fee	*/
				case 3:	/* Actual amt, Sett Fee	*/
					curr_fldno = C_CURSET;
					break;
			}
			break;
		case C_AMTTXNORG:
		case C_AMTTXN:
		case C_AMTTXNCB:
			curr_fldno = C_CURTXN;
			break;
		case C_AMTBILL:
		case C_AMTBILLCB:
		case C_AMTBILLORG:
			curr_fldno = C_CURBILL;
			break;
		case C_CREDAMT:
		case C_CREDREVAMT:
		case C_DEBAMT:
		case C_DEBREVAMT:
		case C_AMTNETSET:
		case C_AMTSET:
			curr_fldno = C_CURSET;
			break;
		case C_AMTTXNFEE:
			curr_fldno = C_CURTXN;
			break;
		case C_AMTADD:
			curr_fldno = C_AMTADDCUR;
			break;
		case I_BLKAMT:
		case I_AVLBAL:
		case I_CLRBAL:
		case I_UNCLRBAL:
		case I_CREDITLIM:
		case I_CYCLELIM:
			curr_fldno = C_ACCNOCUR;
			break;
		case X_SRCPOSTAMT:
			curr_fldno = X_SRCPOSTCUR;
			break;
		case X_DSTPOSTAMT:
			curr_fldno = X_DSTPOSTCUR;
			break;
	}
	if (BADFLDID == curr_fldno)
		DBG_PRINTF((dbg_syserr, "No currency for %s", F_name(fldno)));
	else if (FAIL != CF_get(p_fb, curr_fldno, occ, curr,
							0, FLD_STRING))
	{
		if (FAIL == (ret = curs_dp(curr)))
			DBG_PRINTF((dbg_syserr, "DP fail for %s", curr));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Iamtbill
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	: 
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Iamtbill(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = SUCCEED;
	double	d = 0.0;
	int	dp;
	
	if ( FBISCBREV(p_fb) )
	{
		if (!F_pres(p_fb, C_AMTBILLORG, 0))
		{
			CF_add(p_fb, C_AMTBILLORG, (char *)&d, 0, FLD_DOUBLE);
		}
		else
		{
			len = CF_get(p_fb, C_AMTBILLORG, 0,
				     (char *)&d, 0, FLD_DOUBLE);
			if ( !d && ( FAIL != len ) )
			{
				len = CF_get(p_fb, C_AMTBILL, 0, 
					     (char *)&d, 0, FLD_DOUBLE);
			}
		}
	}
	else 
		len = CF_get(p_fb, C_AMTBILL, 0, (char *)&d, 0, FLD_DOUBLE);

	if ( FAIL != len )
		if ( FAIL == (dp = visa_dp(p_fb, C_AMTBILL, 0)) )
			len = FAIL;

	if ( FAIL != len )
	{
		while (dp--) d *= 10;
		sprintf(M_rawdata, "%0*.0f", p_i2f->max_len, d);
		len = F2Iasc(p_fb, iso, p_i2f);
	}
				
	return len;
}
/*------------------------------------------------------------------------
 *
 * Function	:  F2Iamtset
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Iamtset(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	double	d;
	int	dp;
	int	len;

	len = CF_get(p_fb, C_AMTSET, 0, (char *)&d, 0, FLD_DOUBLE);

	if (FAIL != len)
		if (FAIL == (dp = visa_dp(p_fb, C_AMTSET, 0)))
			len = FAIL;

	if (FAIL != len)
	{
		while (dp--) d *= 10;
		sprintf(M_rawdata, "%012.0f", d);
		len = F2Iasc(p_fb, iso, p_i2f);
	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  amttxn
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *----------------------------------------------------------------------*/
ctxprivate int amttxn(FBFR *p_fb, char *iso, i2f_t *p_i2f, ctxbool bfield3)
{
	double	d;
	int	dp;
	int	len;

/*	DBG_PRINTF((dbg_progdetail,"M_rawdata : 0x%X",M_rawdata));*/

	if (TRUE == bfield3)
	{
		if( F_pres(p_fb, C_AMTTXN, 0 ) )
		{
			len = CF_get(p_fb,C_AMTTXN,0,(char *)&d,0,FLD_DOUBLE);
		}
		else
		{
			/* If AMTTXN not present, assume non-financial and
			 * default to zero, since we still need Field 4.
			 * This is the aib26 version of the fix for bug no.
			 * NMR009272.
			 */
			d=0.0;
		}
	}
	else
	{
		len = CF_get(p_fb,C_AMTTXNORG,0,(char *)&d,0,FLD_DOUBLE);
	}

	if (FAIL != len)
	{
		if (FAIL == (dp = visa_dp(p_fb, C_AMTTXN, 0)))
		{
			len = FAIL;
		}
	}

	if (FAIL != len)
	{
		while (dp--) d *= 10;
		sprintf(M_rawdata, "%012.0f", d);
		len = F2Iasc(p_fb, iso, p_i2f);
	}
	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Iaccid
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Iaccid(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = FAIL;
	char	*p = M_rawdata;
	int	occ;
	short	txncode;
	ctxbool	use_contracc = FALSE;

	/* Are we doing 102 or 103? */
	occ = ( p_i2f->bmno == ISO_ACCID1 )? 0 : 1;

	if( jiso_use_conacc() )
	{
        	if( F_pres(p_fb, C_TXNCODE, 0 ) && F_pres(p_fb, I_BASEFE, 0) )
		{
			if( FAIL == F_get(p_fb, C_TXNCODE, 0, (char *)&txncode, 0) )
				return( FAIL );
			else if( occ > 0 && MTC_MAX_CREDIT > txncode )
				use_contracc = TRUE;
		}
	}

	/* Get this field from C_ACCNO 102=(0) 103=(1) */
	if( use_contracc )
	{
		if( SUCCEED == CF_get(p_fb, I_DSTACC, 0, p, 0, FLD_STRING) )
		{
			len = F2Iva2asc(p_fb, iso, p_i2f);
		}
	}
	else
	{
		if (F_pres(p_fb, C_ACCNO, 0))
		{
			/* On-us transaction, customer account is present */
			if (SUCCEED == CF_get(p_fb, C_ACCNO, occ, p, 0, FLD_STRING) )
				len = F2Iva2asc(p_fb, iso, p_i2f);
		}
		else
		{
			/* Not-on-us transaction, customer account is not present */
			if (FALSE == jiso_ignore_nou_accno() )
			{
				/* Let's use not-on-us network suspense account */
				if (SUCCEED == CF_get(p_fb, I_SRCACC, occ, p, 0, FLD_STRING) )
					len = F2Iva2asc(p_fb, iso, p_i2f);
			}
			else
			{
				DBG_PRINTF((dbg_progdetail, "Ignoring the ACCNO field, "
					"as this is a not-on-us txn and the "
					"IGNORE_NOU_ACCNO flag is set"));
			}
		}

	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  setaiidcode
 *
 * Purpose	:  Set AIID code for F32
 *
 * Parameters	:  p_fb - fielded buffer
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int setaiidcode(FBFR *p_fb)
{
	int	i;
	int	ret = FAIL;

static	fld_cond_t B_bpd=	/* Banco Popular 	*/
	{ COND_FBOOL, NULL, "(I_AFE=='BPDFE')" };
static	fld_cond_t B_ath=	/* ATH Network 		*/
	{ COND_FBOOL, NULL, "(I_AFE=='ATHFE')" };
static	fld_cond_t B_dom=	/* Domestic		*/
	{ COND_FBOOL, NULL, "(C_ACQCOUNTRY=='214')" };
static	fld_cond_t B_intl=	/* Other		*/
	{ COND_FBOOL, NULL, "('1'=='1')" };

static struct
{
	fld_cond_t	*p_fc;
	int		p_code;
	char		*p_descr;
} fcs[] =
{
{ &B_bpd,	1,	"Banco Popular"},
{ &B_ath,	2,	"ATH Network"},
{ &B_dom,	0,	"Domestic"},
{ &B_intl,	3,	"International"},
{ NULL }
};

	for (i = 0; FAIL == ret && fcs[i].p_fc; ++i)
	{
		if (TRUE == fev_evbool(p_fb, fcs[i].p_fc))
		{
			ret = fcs[i].p_code;
			DBG_PRINTF((dbg_progdetail, "Network: [%s]", fcs[i].p_descr));
		}
		
	}
	
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Iaiid
 *
 * Purpose	:  Convert ICBS F32 - Acquirer ID
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *----------------------------------------------------------------------*/
ctxprivate int F2Iaiid(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = FAIL;
	int	ac = 0;
	char	szaiid[13];

	if( FAIL != ( ac = setaiidcode(p_fb) ) && 
		FAIL != CF_get(p_fb, C_AIID, 0, szaiid, 0, FLD_STRING))
	{
		sprintf(M_rawdata, "%1.1d%10.10s", ac, szaiid);
		len = F2Iva2asc(p_fb, iso, p_i2f);
	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Ifld62
 *
 * Purpose	:  Convert ICBS F62
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *----------------------------------------------------------------------*/
ctxprivate int F2Ifld62(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = FAIL;
	int	ac = 0;

	if( FAIL != ( ac = setaiidcode(p_fb) ) )
	{
		sprintf(M_rawdata, "%1.1d", ac);
		len = F2Iva3asc(p_fb, iso, p_i2f);
	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Ffld62
 *
 * Purpose	:  Convert ICBS F62
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *----------------------------------------------------------------------*/
ctxprivate int I2Ffld62(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fva3asc(iso, p_fb, p_i2f);

	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Faccid
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Faccid(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len,
		occ;

	DBG_PRINTF((dbg_syserr,"I2Faccid" ));

	/* stick stuff into M_rawdata */
	len = I2Fva2asc(iso, p_fb, p_i2f);

	/* Are we doing 102 or 103? */
	occ = ( p_i2f->bmno == ISO_ACCID1 )? 0 : 1;

	/* Insert it into C_ACCNO where the occurrence depends
	 * on whether its field 102 or 103 */
	if( FAIL == CF_chg( p_fb, C_ACCNO, occ,	stp_right(M_rawdata), 0, FLD_STRING) )
	{
		len = FAIL;
	}

	return ( len );
}

/*------------------------------------------------------------------------
 *
 * Function	:  setrule
 *
 * Purpose	:  Set conversion rule for this FB message
 *
 * Parameters	:  p_fb - fielded buffer
 *
 * Returns	:  SUCCEED/FAIL
 *
 * Comments	:  Sets M_f2ibase, M_f2icps, M_f2ispu
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int setrule(FBFR *p_fb)
{
static	fld_cond_t Bjarq=	/* Authorisation Request 200/210 */
	{ COND_FBOOL, NULL, "(C_MSGCLS=='1')" };
static	fld_cond_t Bjfrq=	/* Financial Request 200/210 */
	{ COND_FBOOL, NULL, "(C_MSGCLS=='2')" };
static	fld_cond_t Bjfmm=	/* External File maintainence 300/310*/
	{ COND_FBOOL, NULL, "(C_MSGCLS=='3')" };
static	fld_cond_t Bjrm=	/* Reversal 420/430 */
	{ COND_FBOOL, NULL, "(C_MSGCLS=='4')" };
static	fld_cond_t Bjnmm=	/* Network Management 804 */
	{ COND_FBOOL, NULL, "(C_MSGCLS=='8')" };

	int	i;
	int	ret = FAIL;
static struct
{
	fld_cond_t	*p_fc;
	f2i_t		*p_f2ibase;
	char		*p_descr;
} fcs[] =
{
{ &Bjarq,	f2ijarq,	"1xx Authorisation Message"},
{ &Bjfrq,	f2ijfrq,	"2xx Financial Message"},
{ &Bjfmm,	f2ijfmm,	"3xx File Maintainance"},
{ &Bjrm,	f2ijrm,		"4xx Reversal Message"},
{ &Bjnmm,	f2ijnmm,	"8xx Network Management"},
{ NULL }
};

	M_f2ibase = NULL;
	for (i = 0; FAIL == ret && fcs[i].p_fc; ++i)
	{
		if (TRUE == fev_evbool(p_fb, fcs[i].p_fc))
		{
			M_f2ibase = fcs[i].p_f2ibase;
			DBG_PRINTF((dbg_progdetail, "Using Conversion Rule: [%s]",
						fcs[i].p_descr));
			ret = SUCCEED;
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  nstrtok
 *
 * Purpose	:  better strtok call
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate char	*nstrtok( char *src, char c )
{
	static char	*s   = NULL;
	char		*e   = NULL;
	char		*ret = NULL;


	if( NULL == s && NULL == src )
		return( NULL );

	if( NULL != src )
		s = src;

	ret = s;

	if( c == *s )
		*s++ = 0;
	else
		if( NULL != ( e = strchr( s, c ) ) )
		{
			*e = 0;
			s  = e+1;
		}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	:  jiso_init
 *
 * Purpose	:  Message conversion initialization
 *
 * Parameters	:  None
 *
 * Returns	:  SUCCEED
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxpublic int jiso_init(void)
{
	mxu_init(&M_rawdata, &M_p_datalen);
	return SUCCEED;
}

/*------------------------------------------------------------------------
 *
 * Function	:  jiso_i2f
 *
 * Purpose	:  Message conversion - ICBS -> FB
 *
 * Parameters	:  p_iso - pointer to ICBS message
 *		   p_fb - resulting FB
 *		   nfield - problem field
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxpublic	int jiso_i2f(char *p_iso, FBFR *p_fb, int *nfield)
{
	int ret;
	
	int p_len = 0;
	
	p_len = strlen(p_iso);
	DBG_PRINTF((dbg_progdetail, "Len message from ICBS [%d] flag printump[%d]", p_len, iprintdump));
	
	if (iprintdump==1)
	{
		DBG_DUMP( dbg_fatal, "Dump:", p_iso, p_len );	
	}
	
	if (FAIL == (ret = mxu_iso2fb(p_iso, p_fb, i2fbase, 0, nfield, NULL)))
	{
		DBG_PRINTF((dbg_fatal, "Error: Conversion ICBS->FB failed!"));
	}
	else if (FAIL == (ret = post_i2f(p_fb)))
	{
		DBG_PRINTF((dbg_fatal, "Error: POST_I2F post-conversion failed!"));
	}
	else
	{
		DBG_PRINTF((dbg_syswarn, "Message converted successfully!"));
	}
	
	/* JJ 5780	*/
	/* Response messages MUST have actioncode/response code or there
	*  is a format error
	*/
	if (FBISRSP(p_fb) &&
		(!F_pres(p_fb, C_ACTIONCODE,0) ||
		 !F_pres(p_fb,C_RSPCODE,0)))
	{
		ret = FAIL;
		DBG_PRINTF((dbg_syserr,	"Error: No action/response code in response message" ));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  jiso_f2i
 *
 * Purpose	:  Message conversion - FB -> ICBS
 *
 * Parameters	:  p_fb - FB to convert
 *		   p_iso - buffer for result
 *		   p_len - ICBS length (result)
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxpublic	int jiso_f2i(FBFR *p_fb, char *p_iso, int *p_len)
{
	int ret;

	if ( FAIL == (ret = setrule(p_fb)) )
		DBG_PRINTF((dbg_fatal, "Error: Conversion rule not found. Unknown message type."));
	else if ( FAIL == mxu_fb2iso(p_fb, p_iso, i2fbase, M_f2ibase, 0, p_len) || M_conv_failed )
	{
		ret = FAIL;
		DBG_PRINTF((dbg_fatal, "Error: Conversion FB->ICBS failed!"));
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  isosub2fb
 *
 * Purpose	:  extracts a sub-field from an iso message and updates
 *		   the relevant Fielded buffer field.
 *
 * Parameters	:  p_fb - FB
 *		   field_no - fielded buffer field
 *		   start - offset in iso message of sub-field
 *		   field_type - what sort of field
 *		   length - field length in iso buffer
 *		   occurrence - which occurrence in the FB to update.
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int isosub2fb( FBFR *p_fb, int field_no, char *start, int field_type,
					int length, int occurrence )
{
	int	ret = SUCCEED;
	double	tmpdouble;
	long	tmplong;
	char	buf[100];
	char	 *p;			/* NMR006000 */

	strnscpy( buf, start, ((size_t)length));
	*( buf + length ) = EOS;

	DBG_PRINTF(( dbg_progdetail, "VALUE    : [%s]", buf ));

	switch( field_type )
	{
		case FLD_RATE:
			tmpdouble = I2Frates( buf );
			return( CF_chg( p_fb, field_no, occurrence,
				(char *)&tmpdouble,  0, FLD_DOUBLE) );

		case FLD_STRING:
			/* SD PCI DSS: put C_PAN and C_PAN_CLR both onto buffer */
			if( C_PAN == field_no || C_PAN_CLR == field_no )
				return( CF_chg_pan( p_fb, field_no, occurrence,
						stp_right(buf), 0, FLD_STRING) );	
			else		/* SD (end) */
				return( CF_chg( p_fb, field_no, occurrence,
						stp_right(buf), 0, FLD_STRING) );

		case FLD_DOUBLE:
			/* NMR006000 PE 17/7/2001.  Handle v. large amounts
			 * correctly.  Previously handled in same way as
			 * LONGs, but this failed if number was > (max value
			 * of a long)
			 */
			tmpdouble=0;
			p=buf;
			while( p && *p )
        		{
				tmpdouble*=10;
				tmpdouble+=(*p - 48);
				++p;
        		}
			return( CF_chg( p_fb, field_no, occurrence,
				(char *)&tmpdouble, 0, FLD_DOUBLE) );
		case FLD_SHORT:
		case FLD_LONG:
			/* turn buf into a number */
			sscanf( buf, "%ld", &tmplong );
			return( CF_chg( p_fb, field_no, occurrence,
				(char *)&tmplong, 0, FLD_LONG) );
		default:
			DBG_PRINTF(( dbg_syserr, "Invalid Field type" ));
			ret = FAIL;
	}
	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	:  fb2isosub
 *
 * Purpose	:  extracts a sub-field from relevant Fielded buffer field
 *		   and creates the relevant sub-field in an iso message.
 *
 * Parameters	:  p_fb - FB
 *		   field_no - fielded buffer field
 *		   out - pointer to iso buffer
 *		   field_type - what sort of field
 *		   length - field length in iso buffer
 *		   occurrence - which occurrence in the FB to get stuff from.
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int fb2isosub( FBFR *p_fb, int field_no, char *out, int field_type,
                                        int length, int occurrence )
{
        int     ret = SUCCEED,
		dps;
        char    buf[100];
	short	tmp1;
	long	tmp2;
	double	dubul;

        DBG_PRINTF(( dbg_progdetail, "fb2isosub [%d]-[%d]-[%d]-[%d]",
				field_no, field_type, length, occurrence));
	switch( field_type )
	{
		case FLD_STRING:
			/* SD PCI DSS: use clear pan for outgoing message */
			if( C_PAN == field_no || C_PAN_CLR == field_no )
			{
				if( FAIL == CF_get(p_fb, C_PAN_CLR, occurrence,
							buf, 0, FLD_STRING))
				{
					ret = FAIL;
					*buf = EOS;
				}
			}	/* SD (end) */
			else if( FAIL == CF_get(p_fb, field_no, occurrence,
							buf, 0, FLD_STRING))
			{
				ret = FAIL;
				*buf = EOS;
			}
			sprintf( out, "%-*.*s", length, length, buf );
			break;
		case FLD_LONG:
			if( FAIL == CF_get(p_fb, field_no, occurrence,
						(char*)&tmp2, 0, FLD_LONG))
			{
				ret = FAIL;
				tmp2 = 0;
			}
			sprintf( out, "%-*.*ld", length, length, tmp2 );
			break;
		case FLD_SHORT:
			if( FAIL == CF_get(p_fb, field_no, occurrence,
						(char*)&tmp1, 0, FLD_SHORT))
			{
				ret = FAIL;
				tmp1 = 0;
			}
			sprintf( out, "%-*.*d", length, length, tmp1 );
			break;
		case FLD_RATE:
			/* This is a double in the FB, but we have got to
			 * pack it into 8 bytes with the 1st byte signifying
			 * how many places to the right the decimal point goes
			*/
			if( FAIL == CF_get(p_fb, field_no, occurrence,
						(char*)&dubul, 0, FLD_DOUBLE))
			{
				ret = FAIL;
				dubul = 0;
			}
			F2Irateconvert( dubul, out);
			break;
		case FLD_DOUBLE:
			if( FAIL == CF_get(p_fb, field_no, occurrence,
						(char*)&dubul, 0, FLD_DOUBLE))
			{
				ret = FAIL;
				dubul = 0;
			}
			else if (FAIL == (dps = visa_dp(p_fb, field_no, 0)))
			{
				ret = FAIL;
			}
			else
			{
				while (dps--) dubul *= 10;
				sprintf(out, "%012.0f", dubul);
			}
			break;
		default:
			DBG_PRINTF(( dbg_syserr,
					"Unknown Field Type: %d", field_type ));
			ret = FAIL;
	}
	if( SUCCEED == ret )
		DBG_PRINTF(( dbg_progdetail, "out: %s", out ));

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Irateconvert
 *
 * Purpose	:  packs an exchange rate into 8 bytes, where the 1st
 *		   byte signifies how many places from the right the decimal
 *		   point lies.
 *
 * Parameters	:  rate - decimal rate to be packed
 *		   out - pointer to iso buffer
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Irateconvert( double rate, char *out )
{
#define MAX_DIGITS      7
	int     dps;
	char    buf[20],
		*p, *q, *r;

	q = p = buf;
	p += sprintf( p, "%.9f", rate ) - 1;

	/* move q to decimal point */
	while( *q != '.' )++q;
	/* remove trailing zeros after the decimal point */
	while( p > q && (*p == '0' || *p == '.') ) *p-- = EOS;

	/* How many Decimal places */
	dps = (int)(p - q);

	/* get rid of decimal point  */
	strncpy( q, q+1, p-q+1 );

	/* Get rid of leading zeros ( will only happen of rate < 1 ) */
	r = buf;
	while( *r && *r == '0' )*r++ = EOS;

	while ( p-r > MAX_DIGITS )
	{
		*--p = EOS;
		--dps;
	}
	sprintf( out, "%-1.1d%*.*s", dps, MAX_DIGITS, MAX_DIGITS, r );

	/* replace any spaces with zeros */
	p = out+1;
	while( *p && *p == ' ' ) *p++ = '0';

	return(0);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Frates
 *
 * Purpose	:  unpacks an exchange rate from 8 bytes, where the 1st
 *		   byte signifies how many places from the right the decimal
 *		   point lies, into a fielded decimal.
 *
 * Parameters	:  rate - decimal rate to be packed
 *		   out - pointer to iso buffer
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate double I2Frates( char *buf )
{
	char	dps;
	long	y;
	double	z;

	/* Ist byte contains Number of decimal places in this
	 * number */
	dps = *buf - 48;

	/* Get the number out of the buffer */
	sscanf( buf+1, "%ld", &y );

	/* Apply the relevant number of dps to the number */
	z = y;
	while(dps--)
		( z /= 10 );

	return( z );
}

/*------------------------------------------------------------------------
 *
 * Function	: I2Fpan
 *
 * Purpose	: Convert pan from ISO message to FB field
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	: MV NMR023597 
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fpan(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int len, ret;

	len = I2Fva2asc(iso, p_fb, p_i2f);

	if (M_vpan_over_pan) 
		ret = CF_chg_vpan(p_fb, I_VPAN, 0, M_rawdata, 0, FLD_STRING);
	else 
		ret = CF_chg_pan(p_fb, C_PAN, 0, M_rawdata, 0, FLD_STRING);
		
	if ( FAIL == ret )
		len = FAIL;

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	: F2Ipan
 *
 * Purpose	: Convert FB pan into ISO by using configuration flags
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	: MV NMR023597. This function supports following modes:
 *		  1. BCD clear pan
 *		  2. ASCII clear pan
 *		  3. ASCII virtual pan
 *----------------------------------------------------------------------*/
ctxprivate int F2Ipan(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = SUCCEED;
	FLDID	panfld;

	if (M_vpan_over_pan) 
		panfld = I_VPAN;
	else 
		panfld = C_PAN_CLR;

	if (FAIL != (len = CF_get(p_fb, panfld, 0, M_rawdata, 0, FLD_STRING)))
	{
		len = F2Iva2asc(p_fb, iso, p_i2f);
	}

	return( len );
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Fpostdt
 *
 * Purpose	:  Converts field 17 - just deblock it, we do not need it in rsp
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fpostdt(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fasc(iso, p_fb, p_i2f);

	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	: F2Ipostdt
 *
 * Purpose	: Post date from IST/Switch, if missing the date local
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	: BPD_10_001_IT-54
 * 
 *----------------------------------------------------------------------*/
ctxprivate int F2Ipostdt(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = FAIL;
	
	if (F_pres(p_fb, ISO_TAG_F017, 0))
	{
		/* mvitolin BPD_10_001_IT-54 11/02/2011
		 * Use this directly 
		 */
		if (FAIL != (len = CF_get(p_fb, ISO_TAG_F017, 0, M_rawdata, 0, FLD_STRING)))
		{
			len=F2Iasc(p_fb, iso, p_i2f);
		}
	}
        else
        {
		long    mm, dd;
		long    yyyymmdd;
		FLDID	fldno;
		
		if (F_pres(p_fb, I_INDATEREC, 0))
			fldno = I_INDATEREC;
		else
			fldno = C_DATELOCAL;
		
		if (FAIL == CF_get(p_fb, fldno, 0, (char *)&yyyymmdd,
                                                        0, FLD_LONG))
		{
			len = FAIL;
		}
		else
		{
			mm = (yyyymmdd % 10000) / 100;
			dd = yyyymmdd % 100;
			sprintf(M_rawdata, "%02ld%02ld", mm, dd);
			len = F2Iasc(p_fb, iso, p_i2f);
		}
	}
	
	return( len );
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Ifld126
 *
 * Purpose	:  Converts field 126 - Prepaid card data
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Ifld126 (FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	ret = SUCCEED;
	
	/* mvitolin BPD_10_001_IT-54 11/02/2011 */
	if (!F_pres(p_fb, ISO_TAG_F126, 0) || SUCCEED != CF_get(p_fb, ISO_TAG_F126, 0, 
							M_rawdata, 0, FLD_STRING))
	{
		M_rawdata[0] = 0;
	}
	
	/* mvitolin BPD_10_001_IT-54 11/02/2011 */
	if( FAIL != ret )
	{
		ret = F2Iva3asc(p_fb, iso, p_i2f);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Ffld126
 *
 * Purpose	:  Converts field 126 - Prepaid card data
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Ffld126(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fva3asc(iso, p_fb, p_i2f);

	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Famtbill
 *
 * Purpose	:  
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Famtbill(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fflt(iso, p_fb, p_i2f);
	
	if (FAIL != len) 
	{
		double amttxn = 0.0;
		
		amttxn = atof(M_rawdata);
		amttxn = amttxn/100;
		
		DBG_PRINTF((dbg_progdetail,"I2Famtbill - amttxn[%.2lf] M_rawdata[%s]", amttxn, M_rawdata));

		if ( SUCCEED != CF_chg(p_fb, BPD_ISO_FB4, 0, (char *) &amttxn, 0, FLD_DOUBLE) )
		{
			DBG_PRINTF((dbg_fatal,"Failed to add bpd_iso_fb4 to FB"));
			len = FAIL;
		}
		else 
		{
			DBG_PRINTF((dbg_progdetail,"BPD_ISO_FB4 added to FB  [%.2lf]", amttxn));
		}
	}
	
	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Icomm
 *
 * Purpose	:  Commission calculated in Cortex
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Icomm (FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	ret = SUCCEED;
	double	commission = 0.0;
	double	amtbill = 0.0;
	double	amtblk = 0.0;
	int	dp;
	
	if ( FAIL == (dp = visa_dp(p_fb, C_AMTBILL, 0)) )
		ret = FAIL;
	
	if (F_pres(p_fb, C_AMTBILLCOM, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_AMTBILLCOM, 0, 
					(char *)&commission, 0, FLD_DOUBLE))
		{
			ret = FAIL;
			DBG_PRINTF(( dbg_syserr, "Cannot get C_AMTBILLCOM "
					"from FB"));
		}
	}
	else if ((FBISAUTH(p_fb) || FBISAUTHREV(p_fb)) &&
			F_pres(p_fb, C_AMTBILL, 0) && F_pres(p_fb, I_AMTBLK, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_AMTBILL, 0, 
					(char *)&amtbill, 0, FLD_DOUBLE) ||
		    SUCCEED != CF_get(p_fb, I_AMTBLK, 0,
					(char *)&amtblk, 0, FLD_DOUBLE))
		{
			ret = FAIL;
			DBG_PRINTF(( dbg_syserr, "Cannot get C_AMTBILL/"
					"I_AMTBLK from FB"));
		}
		else
		{
			commission = amtbill - amtblk;
		}
		
	}

	if( FAIL != ret )	
	{
/*		if ((commission > 0.0) || num_equal(commission, 0.0))
		{
			M_rawdata[0] = 'D';
		}
		else
		{
			M_rawdata[0] = 'C';
			commission = -commission;
		}
		
		sprintf(M_rawdata+1, "%07.2lf", commission);
*/		
		while (dp--) commission *= 10;
		sprintf(M_rawdata, "%08.0lf", commission);
	}
	
	if( FAIL != ret )
	{
		
		ret = F2Iasc(p_fb, iso, p_i2f);
	}

	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Fcomm
 *
 * Purpose	:  Converts field DE28 - Commission
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  Ignore data received from host
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Fcomm(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len;

	len = I2Fasc(iso, p_fb, p_i2f);

	return(len);
}

/*------------------------------------------------------------------------
 *
 * Function	:  I2Frrn
 *
 * Purpose	:  Parse the Retrival Request Number
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int I2Frrn(char *iso, FBFR *p_fb, i2f_t *p_i2f)
{
	int	len = SUCCEED;

	len = I2Fasc(iso, p_fb, p_i2f);

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Irrn
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Irrn(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int	len = SUCCEED;
	char	tmp[64] = "";

	if (F_pres(p_fb, ISO_FB37, 0) && SUCCEED == F_get(p_fb, ISO_FB37, 0, M_rawdata, 0))
	{
		DBG_PRINTF((dbg_progdetail, "Using ISO_FB37 [%s]", M_rawdata));
		len = F2Iasc(p_fb, iso, p_i2f);
		return len;  /* <<<<<<<< RETURN */
	}

	if (FAIL == CF_get(p_fb, C_RRN, 0, tmp, (FLDLEN) 0, FLD_STRING))
	{
		DBG_PRINTF((dbg_syserr,"Failed to get C_RRN"));
		len = FAIL;
	}

	if (FAIL != len)
	{	
		DBG_PRINTF((dbg_progdetail, "Using C_RRN [%s]", tmp));
		sprintf(M_rawdata, "%-12.12s", tmp);
		len = F2Iasc(p_fb, iso, p_i2f);
	}

	return len;
}

/*------------------------------------------------------------------------
 *
 * Function	: set_ath_txn_code 
 *
 * Purpose	: Configures the library to use specified code
 *		  as the code for transactions from ATH - local network.
 *
 * Parameters	: ath_txn_code - string containing the ATH code.
 *		 
 * Returns	:  
 *
 * Comments	: 
 *----------------------------------------------------------------------*/
ctxpublic void set_ath_aiid_code(char * ath_aiid_code)
{
	strncpy(M_ath_aiid_code, ath_aiid_code, AIID_LEN);
	M_ath_aiid_code[AIID_LEN] = EOS;

	DBG_PRINTF(( dbg_progdetail, "setting ATH code to %s", 
		     ath_aiid_code));
	
}

/*------------------------------------------------------------------------
 *
 * Function	: set_vpan_over_pan 
 *
 * Purpose	: Configures the library to use virtual pan over
 *		  pan field (iso field 2)
 *
 * Parameters	: vpanover_enabled - if true vpan over pan will be activated	
 *		 
 * Returns	:  
 *
 * Comments	: 
 *----------------------------------------------------------------------*/
ctxpublic void set_vpan_over_pan(ctxbool vpanover_enabled)
{
	M_vpan_over_pan=vpanover_enabled;

	DBG_PRINTF(( dbg_progdetail, "Virtual PAN over PAN: %s", 
		     M_vpan_over_pan?"ENABLED":"DISABLED"));
	
}
	
/* This function is used by the Interface testing tools */
ctxpublic int check_message_body (char *p_iso, FBFR *p_fb, int *nfield)
{
	return ( mxu_iso2fb(p_iso , p_fb, i2fbase, 0, nfield, NULL));
}

/* This function is used by the Interface testing tools */
ctxpublic void set_M_message_simulator()
{
	DBG_PRINTF(( dbg_progdetail, "Setting M_message_simulator" ));
	M_message_simulator = TRUE;
}
/* This function is used by the Interface testing tools */
ctxpublic int get_conversion_tables( FBFR *p_fb,
				i2f_t **all_fields, f2i_t **message )
{
	int	ret = SUCCEED;
	if( SUCCEED != setrule( p_fb ) )
	{
		DBG_PRINTF((dbg_progdetail, "conversion rule setup failed"));
		ret = FAIL;
	}
	else
	{
		*all_fields = i2fbase;
		*message =  M_f2ibase;
	}
	return( ret );
}
/* This function is used by the Interface testing tools */
subf_t *get_sub_field_table( ctxbool isrequest, char type )
{
	return(  isrequest ? req_sub_fields[type-48]: rsp_sub_fields[type-48] );
}

/*------------------------------------------------------------------------
 *
 * Function	:  F2Iascmmdd
 *
 * Purpose	:  Build MMDD ASC
 *		  
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *
 *----------------------------------------------------------------------*/
ctxprivate int F2Iascmmddicbs(FBFR *p_fb, char *iso, i2f_t *p_i2f)
{
	int len = SUCCEED;
	long	mm, dd;
	long	yyyymmdd;
	long	localyear = 0;
	

	if (FAIL == CF_get(p_fb, p_i2f->fldno, 0, (char *)&yyyymmdd,
							0, FLD_LONG))
			len = FAIL;
	else
	{
		mm = (yyyymmdd % 10000) / 100;
		dd = yyyymmdd % 100;
		sprintf(M_rawdata, "%02ld%02ld", mm, dd);
		len = F2Iasc(p_fb, iso, p_i2f);
		if (FBISREQ(p_fb))
		{
			localyear = yyyymmdd / 10000;
			DBG_PRINTF(( dbg_syswarn, "test"));//debug
			if (SUCCEED != CF_add(p_fb, ISO_LCLYR, (char*)&localyear, 0,FLD_LONG))
				DBG_PRINTF(( dbg_syswarn, "Failed to add original year value for local date"));
		}
	}
		DBG_PRINTF(( dbg_progdetail, "localyear = %ld", localyear));//debug
	return len;
}

/*------------------------------------------------------------------------
 * 
 * Function	: set_ovr_octpcode 
 *
 * Purpose	: PCODE to be used for VISA OCT txns.
 *		  
 *
 * Parameters: pode - PCODE to be used	
 *		 			 
 * Returns	:  
 *
 * Comments	: hlg BPD_MAINT-131 VISA OCT changes - APR/2018
 *----------------------------------------------------------------------*/
ctxpublic void set_ovr_octpcode(char *pcode)
{
	strncpy(M_octpcode, pcode, 2);
	M_octpcode[PCODELEN] = EOS;

	DBG_PRINTF(( dbg_progdetail, "VISA OCT PCODE will be: [%s]", 
		     M_octpcode));
	
}

/*------------------------------------------------------------------------
 * 
 * Function	: set_ovr_cltoctpcode 
 *
 * Purpose	: PCODE to be used for VISA OCT txns. when host response
 *		  
 *
 * Parameters: pode - PCODE to be used	
 *		 			 
 * Returns	:  
 *
 * Comments	: hlg BPD_MAINT-131 VISA OCT changes - MAY/2018
 *----------------------------------------------------------------------*/
ctxpublic void set_ovr_cltoctpcode(char *pcode)
{
	strncpy(M_cltoctpcode, pcode, 2);
	M_cltoctpcode[PCODELEN] = EOS;

	DBG_PRINTF(( dbg_progdetail, "VISA OCT PCODE will be: [%s]", 
		     M_cltoctpcode));
	
}


/*------------------------------------------------------------------------
 * 
 * Function	: set_ovr_octmti 
 *
 * Purpose	: PCODE to be used for VISA OCT txns.
 *		  
 *
 * Parameters: pode - PCODE to be used	
 *		 			 
 * Returns	:  
 *
 * Comments	: hlg BPD_MAINT-131 VISA OCT changes - APR/2018
 *----------------------------------------------------------------------*/
ctxpublic void set_ovr_octmti(char *mti)
{
	strncpy(M_octmti, mti, 4);
	M_octmti[MTILEN] = EOS;

	DBG_PRINTF(( dbg_progdetail, "VISA OCT MTI will be: [%s]", 
		     M_octmti));
	
}

ctxpublic void set_printdump(int print_dump)
{
	iprintdump = print_dump;
	DBG_PRINTF(( dbg_progdetail, "printdump ON [%d]", iprintdump));
}

