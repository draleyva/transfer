/*-----------------------------------------------------------------------
 * 
 * File		: icbsifsv.c 
 * 
 * Author	: Alex Butikov
 * 
 * Created	: Jan 2011
 *
 * Purpose	: ICBS server 
 * 
 * Comments	: Just the init & uninit stuff - main is in /Tuxedo somewhere
 * 	
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.					 
 *-----------------------------------------------------------------------*/
/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>

#include <cortex.h>
#include <condbsvi.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
static char rcsid[] = "$Id$";

/*---------------------------Prototypes---------------------------------*/
ctxpublic char	*srv_module(void) { return "if"; }
ctxpublic char	*srv_name(void) { return "ICBSIF"; }
ctxpublic int	icbsif_init( FILE *fp, char *subsect );

/*------------------------------------------------------------------------
 *
 * Function	:  
 *
 * Purpose	:  
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int  srv_init( FILE *fp, char *subsect )
{
	int ret = SUCCEED;

	srv_ndb_dummy();	/* mention this to pull in condbsvi	*/

	ret = icbsif_init(fp, subsect);

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	:  
 *
 * Purpose	:  
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic void  srv_uninit(void)
{
}

