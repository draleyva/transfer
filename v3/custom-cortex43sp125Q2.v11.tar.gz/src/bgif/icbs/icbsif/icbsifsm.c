/*-----------------------------------------------------------------------
 * 
 * File		: icbsifsm.c 
 * 
 * Author	: Alex Butikov
 * 
 * Created	: Jan 2011
 *
 * Purpose	: State machine used by ICBS server
 * 
 * Comments	: BEWARE THE TEST FLAG !!! which will make it LOOK as if
 *		  it's working, but it ain't !!!
 * 	
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.					 
 *-----------------------------------------------------------------------*/
/*---------------------------Includes-----------------------------------*/
/***************************#define TESTMODE**************************/
#include <portable.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>

#include <slntp.h>
#include <slnfb.h>
#include <sldbg.h>
#include <sldtm.h>
#include <slfdbg.h>
#include <slgsm.h>
#include <slmsgcat.h>

#include <cortex.h>
#include <cocrd.fd.h>
#include <coint.fd.h>
#include <cocbf.h>
#include <cocbfdef.h>
#include <comsgtyp.h>
#include <coevent.h>
#include <cocurr.h>
#include <coamtadd.h> /* BZWBK_DEV-25 */
#include <msgdefs.h>
#include <icbscv.h>
#include <ifevent.h>
#include <icbscv.h>
#include <genif.h>

#include <gdiinet.h>
#include <gdiev.h>

#include <hoststat.h>
#include <hostcmd.h>

#include <forex.h>
#include <bpd_prod.fd.h>

#include <cotux.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define	PROGNAME	"ICBSIF"
#define	MODNAME		"if"

#define	BUF_SIZE	1024

#define SHORT_TYPE	"short"
#define	DOUBLE_TYPE	"double"

#define	ALARM_ONLINE_DFLT	5
#define	ALARM_OFFLINE_DFLT	35
#define	ALARM_NETMGT		35

#define GSM_DEBUG_LEVEL	dbg_proginfo

#define HOSTNAME_BUFLEN	28

#define FOREX_REFCODE_BUFFSIZE_FALCON 33
#define GENSUBST_PTRN_BUFFSIZE_FALCON 128
/*---------------------------Enums--------------------------------------*/
enum host_states
{
	st_chk_host,
	st_mkrspq,
	st_msgcnv,
	st_snd_drv,
	st_wait_rsp,
	st_return,
	st_error,
	st_tout
};

enum
{
	ev_ok = 0,
	ev_err,
	ev_tout,
	ev_signoff
};

FLDID M_event[] =
{
	C_ENQNUM,
	C_CREDNUM,
	C_CREDREVNUM,
	C_DEBNUM,
	C_DEBREVNUM,
	C_CREDAMT,
	C_CREDREVAMT,
	C_DEBAMT,
	C_DEBREVAMT,
	C_AMTNETSET,
	BADFLDID
};

/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/

ctxprivate void	*M_p_mc;		/* State machine descriptor	*/
ctxprivate char	M_buf[BUF_SIZE];	/* send/receive buffer		*/
ctxprivate int	M_buflen;		/* length of the msg in M_buf	*/
ctxprivate int	M_err;			/* error conditions		*/
ctxprivate char	M_tcp_svc[32];		/* the driver service name	*/
ctxprivate char	M_tcp_host[32];		/* the driver host name	*/
ctxprivate FBFR	*M_p_fb;		/* working fielded buffer	*/
ctxprivate char	M_fifonm[CTX_FILENAME_MAX]; /* name for response FIFO	*/
/* NMR006689 PE - Make timeout values more configurable 		*/
ctxprivate int	M_rsptime_on=0;		/* timeout for on-line response */
ctxprivate int	M_rsptime_off=0;	/* timeout for off-line response*/
ctxprivate ctxbool	M_updhostst = FALSE;
/* MV 2009.04.20 BZWBK_DEV-26 */
ctxprivate char	M_hostsyncreq = OPTION_DISABLED; /* Host state sync required? */
ctxprivate short	M_channel = 1;		/* channel the IF is associated */
ctxprivate int     M_maxtimeouts = 0;
ctxprivate int     M_timeoutcount = 0;

/*---------------------------Prototypes---------------------------------*/

				/* ctxpublic functions		*/
ctxpublic int	vs_process( FBFR **pp_fb );
/* NMR006689 PE - Make timeout values more configurable 		*/
ctxpublic int	vs_init(char *hostnm, char *srvnm, int timeout_on,
			int timeout_off);

				/* State machine functions 	*/
ctxprivate short	vs_error( void );
ctxprivate short	vs_tout( void );
ctxprivate short	vs_return( void );
ctxprivate short	vs_wait_rsp( void );
ctxprivate short	vs_snd_drv( void );
ctxprivate short	vs_msgcnv( void );
ctxprivate short	vs_mkrspq( void );
ctxprivate short	vs_chk_host( void );

				/* Support functions 		*/
ctxprivate void	vs_atexit( void );
ctxprivate void	vs_sigdisp( int sig);
ctxprivate int	vs_event( int ev );
ctxpublic int	vs_gen_rsp(FBFR *p_fb, short action, char *response,
			   short rejreas);
ctxprivate short	vs_chk_recon( FBFR *p_tmp_fb );

				/* MJB amtset */
ctxprivate void	vc_set_amtset_lf(FBFR *p_fb );
ctxprivate void	vc_unset_amtset_lf(FBFR *p_fb );
/* NMR006689 PE - Make timeout values more configurable 		*/
ctxprivate int	rtc_get_timer_val_bzwbk( FBFR *p_fb, int on, int off );
				/* MJB amtset */
/* MV 2009.04.20 BZWBK_DEV-26 */
ctxprivate ctxbool is_sync_required( char *hostnm );

ctxprivate int checkPartialAuthorization(FBFR * p_fb, FBFR * p_tmp_fb, int * flagPartialAuthorization);

/*------------------------------------------------------------------------
 *
 * function	:  vs_process
 *
 * purpose	:  entry to the state machine processing the message
 *
 * parameters	:  pp_fb - fielded buffer with all nice goods
 *
 * returns	:  SUCCEED / FAIL
 *
 * comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int	vs_process( FBFR **pp_fb )
{
	ctxprivate ctxbool	first = TRUE;
	ctxprivate		gsm_states st[] =
	{
					/* main state machine		*/
{GST(st_chk_host),	vs_chk_host,	st_error,	NULL},
{GST(st_mkrspq),	vs_mkrspq,	st_error,	NULL},
{GST(st_msgcnv),	vs_msgcnv,	st_error,	NULL},
{GST(st_snd_drv),	vs_snd_drv,	st_error,	NULL},
{GST(st_wait_rsp),	vs_wait_rsp,	st_error,	NULL},
{GST(st_return),	vs_return,	0,		GSM_RETURN},
{GST(st_error),		vs_error,	st_return,	NULL},
{GST(st_tout),		vs_tout,	0,		GSM_RETURN},
	};

	ctxprivate gsm_trans tr[] =
	{
					/* main sm transitions		*/
{st_chk_host,	GEV(ev_ok),	NULL,		st_mkrspq},
{st_chk_host,	GEV(ev_signoff),NULL,		st_return},
{st_mkrspq,	GEV(ev_ok),	NULL,		st_msgcnv},
{st_msgcnv,	GEV(ev_ok),	NULL,		st_snd_drv},
{st_snd_drv,	GEV(ev_ok),	NULL,		st_wait_rsp},
{st_wait_rsp,	GEV(ev_ok),	NULL,		st_return},
{st_wait_rsp,	GEV(ev_tout),	NULL,		st_tout},
{FAIL}
	};
	int	ret = SUCCEED;

	M_err = err_allok;
	M_p_fb = *pp_fb;

	if( first && FAIL != ret )
	{
					/* create state machine		*/
		if( FAIL == ( ret = gsm_new( st, DIM(st)-1, tr, &M_p_mc ) ) )
			fprintf( stderr, "gsm_new failed\n" );
	}

	if( FAIL != ret && first )
		if(DBG_GETLEV() >= GSM_DEBUG_LEVEL )
			gsm_debug( M_p_mc, TRUE, "VSM" );

	if( FAIL != ret && first )
		first = FALSE;

	if( FAIL != ret )
		gsm_enter( M_p_mc, st_chk_host );

	*pp_fb = M_p_fb;	/* in case it changed !	*/

	return( M_err == err_allok ? SUCCEED : FAIL );
}

/*------------------------------------------------------------------------
 *
 * Function	:  vs_chk_host
 *
 * Purpose	:  
 *
 * Parameters	:  
 *
 * Returns	:  ev_ok / ev_err
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	vs_chk_host( void )
{
	short	ret = ev_err;
	short	nxt_chan;
	int	fn = 0;
	char	hostnm[HOSTNAME_BUFLEN];
	char	fwd_svc[SVCNAMEMAX + 1];
	hostdet_params_t hst;

	memset(&hst, 0, sizeof(hst));
	if (NULL==( hst.p_paramfb = (FBFR*)ntp_alloc("FML", NULL, 4096) ))
	{
		DBG_PRINTF((dbg_syserr, "F_alloc failed"));
		return FAIL;
	}
	
	/* AV 12/11/00 use only I_HOSTNAME to get host name */
	if (F_pres (M_p_fb, I_HOSTNAME, 0))
	{
		if (FAIL == CF_get( M_p_fb, I_HOSTNAME, 0, hostnm,
							0, FLD_STRING ))
			return( ev_err );
	}
	else
	{
		DBG_PRINTF((dbg_syserr, "No HOSTNAME !"));
		return( ev_err );
	}

	if( F_pres( M_p_fb, C_FNCODE, 0 ) &&
	   FAIL == ( fn = cbf_get_fncode( M_p_fb ) ) )
		return( ev_err );

	if( SUCCEED == hst_get_hostdet_struct(hostnm, &hst) )
	{
		/* MV 2009.04.20 BZWBK_DEV-26 */
		M_hostsyncreq=hst.options[HOSTDET_OPTIONS_OFF_SYNCONL];
		M_timeoutcount = hst.hosttoutcount;
		
		
		strcpy(M_tcp_svc, hst.netaddr);
		
		DBG_PRINTF((dbg_syswarn, "Current consecutive = %d",
						M_timeoutcount));
		
		/* we should do this on entry, cause of concurent interfaces */
		if ( MFC_NETMGT_SIGN_ON != fn && HRS_ON_LINE == hst.curstate
			&& MFC_NETMGT_ECHO != fn
			&& M_timeoutcount >= M_maxtimeouts )
		{
			DBG_PRINTF((dbg_fatal, "Max timeouts already reached - "
						"Setting interface OFF LINE [%d][%d]",
						M_timeoutcount, M_maxtimeouts ));

			hst_upd_current_stat( hostnm, HCS_OFF_LINE );
			
			/* override the curstate to keep the logic of 9/10 next */
			hst.curstate = HRS_OFF_LINE;
		}
		
		if( MFC_NETMGT_SIGN_ON != fn && HRS_OFF_LINE == hst.curstate
		&&  MFC_NETMGT_ECHO != fn )	
		{
			ret = ev_signoff;
			vs_gen_rsp(M_p_fb, MAC_ERROR,MRS_RRSP_ISSOFF,
				   RJR_IF_REJECT);
		}
		else if( MFC_NETMGT_SIGN_ON != fn && MFC_NETMGT_ECHO != fn
			&& HCS_OFF_LINE + '0' ==
					hst.chanstate[M_channel - 1])
		{
			if(HCS_OFF_LINE == hst.comstate ||
				FAIL == chnl_nextavl_channel(
					hst.chanstate, &nxt_chan))
			{
				ret = ev_signoff;
				vs_gen_rsp(M_p_fb, MAC_ERROR, MRS_RRSP_ISINOP,
					RJR_IF_REJECT);
			}
			else if(HCS_ON_LINE == hst.comstate)
			{
				snprintf(fwd_svc, SVCNAMEMAX,
					"%s%s%hd", PROGNAME, CHAN_POSTFIX,
					nxt_chan);

				DBG_PRINTF((dbg_progdetail, "Current channel "
					"inoperative; forwarding to service "
					"<%s>", fwd_svc));
				DBG_STAR(("ntp_forward to: %s", fwd_svc));
				DBG_FBDIFFEND(M_p_fb, DIFF_CLOSE);
				DBG_CLOSEFILE();

				ntp_forward(fwd_svc,
					(char *)M_p_fb,
					0L,
					0L);
			}
		}
		else
		{
			M_updhostst = TRUE;
			ret = ev_ok;
		}
	}
	else
	{
		ret = ev_err;
		vs_gen_rsp(M_p_fb, MAC_ERROR,MRS_RRSP_MALSYS, RJR_IF_HOSTDET);
	}
	ntp_free((char*)hst.p_paramfb);
	
	DBG_PRINTF((dbg_progdetail, "M_hostsyncreq=%c", M_hostsyncreq));
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  vs_mkrspq
 *
 * Purpose	:  Makes response queue, if it's a request/advice
 *
 * Parameters	:  
 *
 * Returns	:  ev_ok / ev_err
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	vs_mkrspq( void )
{
	char	stan[7];
	char	msgcls[2];
	char	*p;
	short	ret = ev_ok;

	M_fifonm[0] = EOS;

#ifdef TESTMODE
DBG_PRINTF((dbg_fatal,"TESTMODE! No RSP Q created"));
return ret;
#endif

	if(!FBISREQ(M_p_fb))
	{
		return ret;
	}
	/*
	 * MV 2009.04.20 BZWBK_DEV-26
	 * Included message class in fifo identifier
	 * So the in multithreaded environment originals and reversals
	 * would not conflict
	 */
	if (FAIL != CF_get(M_p_fb, C_STAN, 0, stan, (FLDLEN)0, FLD_STRING)
		&&  FAIL != CF_get(M_p_fb, C_MSGCLS, 0, msgcls, 0, FLD_CHAR)
				&& (p = getenv("CTXTMP")))
	{
		msgcls[1]=EOS;
		strcpy(M_fifonm, p);
		strcat(M_fifonm, "/");
		strcat(M_fifonm, msgcls);
		strcat(M_fifonm, stan);
		if (FAIL == mkfifo(M_fifonm, 0660))
		{
			DBG_PRINTF((dbg_syserr,
				"Mkfifo %s [%d]", M_fifonm, errno));
			M_fifonm[0] = EOS;
			ret = ev_err;
		}
	}
	else
	{
		DBG_PRINTF((dbg_syserr, "CTXTMP or STAN missing"));
		ret = ev_err;
	}
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  vs_msgcnv
 *
 * Purpose	:  convets message FML->native
 *
 * Parameters	:  
 *
 * Returns	:  ev_ok / ev_err
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	vs_msgcnv( void )
{
	short	ret = ev_ok;
	FLDLEN	len;
extern	int	M_DO_DUMP;			/* Message Dumps 	*/


	M_buflen = 0;

	if( SUCCEED != icbscvout( M_p_fb ) )
	{
		M_err = err_msgcnv;
		vs_gen_rsp(M_p_fb, MAC_ERROR, MRS_RRSP_FORMAT,
			   RJR_VIF_MSGCVOUT);
		ret = ev_err;
	}

	if( ev_ok == ret )
	{
		memset( M_buf, 0, sizeof(M_buf) );
		len = 0;
	}

	if( ev_ok == ret && FAIL == F_get( M_p_fb, I_NATMSG, 0, M_buf, &len ) )
	{
		M_err = err_missfld;
		vs_gen_rsp(M_p_fb, MAC_ERROR, MRS_RRSP_MALSYS,
			   RJR_VIF_NONATMSG);
		ret = ev_err;
	}

	if( ev_ok == ret )
		M_buflen = len;

	/* Dump the ISO message to disk */
	if( M_DO_DUMP && ev_ok == ret )
	{
		char	cmsgcls;
		char	cmsgfn;
		char	ctxnsrc;
		char	fname[80];
		FILE	*fp;

		/* Make filename out of C_MSGCLS, C_MSGFN,
		 * C_TXNSRC and time
		*/
		if(	FAIL != CF_get(M_p_fb,C_MSGCLS,0,(char*) &cmsgcls,
				(FLDLEN) 0, FLD_CHAR) &&
			FAIL != CF_get(M_p_fb,C_MSGFN,0,(char*) &cmsgfn,
				(FLDLEN) 0, FLD_CHAR) &&
			FAIL != CF_get(M_p_fb,C_TXNSRC,0,(char*) &ctxnsrc,
				(FLDLEN) 0, FLD_CHAR) )
		{
			sprintf( fname, "%s/1%c%c%c%ld.dmp",
				getenv( "CTXTMP" ),
				cmsgcls,
				cmsgfn,
				ctxnsrc,
				local_time());
			DBG_PRINTF(( dbg_progdetail, "Dumping to %s", fname ));
			/* Open the file for writing */
			if( NULL != (fp=fopen( fname, "w+" )) )
			{
				DBG_PRINTF(( dbg_progdetail, "Dumping!"));
				/* Dump! */
				fwrite( M_buf, M_buflen, 1, fp );
				fclose( fp );
			}
		}
	}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	:  vs_snd_drv
 *
 * Purpose	:  send converted message to driver
 *
 * Parameters	:  
 *
 * Returns	:  ev_ok / ev_err
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	vs_snd_drv( void )
{
	/*TPQCTL	qctl;*/
	short	ret = ev_ok;

#ifdef TESTMODE
DBG_PRINTF((dbg_fatal,"TESTMODE! Not really sent outside"));
return ret;
#endif
	if(FAIL == gdinet_snd(M_buf, M_buflen, M_tcp_host, M_tcp_svc, &M_err))
	{
		vs_gen_rsp(M_p_fb,MAC_ERROR, MRS_RRSP_MALSYS, RJR_VIF_SENDDRV);
		M_err = err_putev;
		ret = ev_err;
	}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	:  vs_tout
 *
 * Purpose	:  return.
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	vs_tout( void )
{
	int	ret = ev_ok;
	char	*rt = "1";

#if GSM_DEBUG_LEVEL > dbg_proginfo
	DBG_PRINTF(( dbg_proginfo,"Timeout st_tout (%d)",M_err));
#endif

	/* NMR006689 PE 04/12/2001.  Dont set the REVTOUT flag for reversals
	 * OR advices since you cant reverse a reversal or an advice (REVTOUT 
	 * tells TXNRSP to generate an Issuer-timout reversal for this txn), 
	 * and because we want TXNRSP to return TPFAIL to TMQFORWARD, so that
	 * the reversal/advice is re-sent.
	 */
	if (!FBISADV(M_p_fb) )
	{
		DBG_PRINTF((dbg_progdetail,
		  	"Timed out-core will generate reversal if required"));
		if( SUCCEED != CF_chg(M_p_fb, I_REVTOUT, 0, rt, 0, FLD_STRING))
		{
			ret = ev_err;
		}
	}
	else
	{
		DBG_PRINTF((dbg_progdetail,
		  	"NOT adding I_REVTOUT for Advice/Reversal"));
	}

	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  vs_chk_recon
 *
 * Purpose	:  check reconcilaition message
 *
 * Parameters	:  
 *
 * Returns	:  ev_ok  - Response OK
 *		   ev_err - Error
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	vs_chk_recon( FBFR *p_tmp_fb )
{
	short	ret = ev_ok;
	char	szrspcode[3];
	short	nonum;
	short	nnnum;
	double	donum;
	double	dnnum;
	char	szbuf[128];
	FLDID	nevent;
	short	i;
	char	curr[4];
	int	dp;


	if (FAIL != CF_get(M_p_fb, C_CURSET, 0, curr, 0, FLD_STRING))
	{
		if (FAIL == (dp = curs_dp(curr)))
		{
			DBG_PRINTF((dbg_syserr, "DP fail for %s", curr));
			ret = ev_err;
		}
	}
	else
	{
		DBG_PRINTF((dbg_syserr, "Fail to get C_CURSET"));
		ret = ev_err;
	}

	if(  ev_err != ret && FAIL != CF_get(p_tmp_fb, C_RSPCODE, 0, szrspcode,
					     (FLDLEN) 0, FLD_STRING))
	{
		if(!strncmp(szrspcode,MRS_RECON_OUTBAL,
			    strlen(MRS_RECON_OUTBAL))
		   ||  !strncmp(szrspcode, MRS_RECON_ANRCTP,
				strlen(MRS_RECON_OUTBAL)))
		{
			for( nevent = M_event[i = 0]; BADFLDID != M_event[i];
			    i++ )
			{
				if(F_ldtype(M_event[i]) == FLD_SHORT)
				/* !strncmp(F_type(M_event[i]),SHORT_TYPE,
				 *	    strlen(SHORT_TYPE)))
				 */
				{
					if(FAIL == CF_get(p_tmp_fb, M_event[i],
							  0, (char*)&nnnum,
							  (FLDLEN) 0,FLD_SHORT)
					   || FAIL == CF_get(M_p_fb,M_event[i],
							     0, (char*)&nonum,
							     (FLDLEN) 0,
							     FLD_SHORT))
					{
						DBG_PRINTF(( dbg_syserr,
							  "Fail to get %s",
							  F_name(M_event[i])));
						ret = ev_err;
					}
					if( ev_err != ret && nonum!=nnnum )
					{
						sprintf(szbuf, "%s~%hd~%hd",
							F_name(M_event[i]),
							nonum, nnnum);
						ev_call(EVTAG_RECON, szbuf);
					}
				}
				else if( F_ldtype(M_event[i])==FLD_DOUBLE)
				/* else if( !strncmp(F_type(M_event[i]),
				 *		  DOUBLE_TYPE,
				 *		  strlen(DOUBLE_TYPE)))
				 */
				{
					if( FAIL == CF_get(p_tmp_fb,M_event[i],
							   0, (char*) &dnnum,
							   (FLDLEN) 0,
							   FLD_DOUBLE)
					   ||  FAIL == CF_get(M_p_fb,
							      M_event[i],
							      0,(char*) &donum,
							      (FLDLEN) 0,
							      FLD_DOUBLE))
					{
						DBG_PRINTF((dbg_syserr,
							  "Fail to get %s",
							  F_name(M_event[i])));
						ret = ev_err;
					}
					if( ev_err != ret && donum != dnnum )
					{
						sprintf(szbuf,"%s~%.*lf~%.*lf",
							F_name(M_event[i]),
							dp, donum,
							dp, dnnum);
						ev_call(EVTAG_RECON, szbuf);
					}
				}
			}
		}
	}
	else
	{
		DBG_PRINTF((dbg_syserr,  "Cannot get the response code"));
		ret = ev_err;
	}

	return( ret );
}	

/*------------------------------------------------------------------------
 *
 * Function	:  vs_wait_rsp
 *
 * Purpose	:  Wait for response on FIFO, if appropriate
 *
 * Parameters	:  
 *
 * Returns	:  ev_ok  - Response received
 *		   ev_err - Error
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	vs_wait_rsp( void )
{
	FBFR	*p_tmp_fb = NULL;
	int	fd;
	int	nb;
	long	rsplen = 0L;
	int	sz;
	short	ret = ev_ok;
	long	lold_sysdate,
		lnew_sysdate;
	short	outbtchtype = OB_ONLHOSTBTCH;
	FBFR	*p_amtadd_fb = NULL;
	char	hostnm[HOSTNAME_BUFLEN];
	/*variables to restore local date year*/
	long	mm, dd, date, yy_stored;
	long	yyyymmdd;
	
	int ret2 = SUCCEED;
	
	int flagPartialAuthorization = 0;
	

#ifdef TESTMODE
DBG_PRINTF((dbg_fatal,"TESTMODE! Not really waiting response"));
return ret;
#endif
	if (!M_fifonm[0])
		return ret;

	DBG_PRINTF(( dbg_progdetail, "vs_wait_rsp" ));
			
	/* NMR006689 PE 04/12/2001.  Handle timeout values correctly */
	alarm(rtc_get_timer_val_bzwbk(M_p_fb, M_rsptime_on, M_rsptime_off));
	/* NOTE: open on a pipe with RDONLY waits until there	*/
	/* is a writer on the other end - how convenient !	*/
	fd = open(M_fifonm, O_RDONLY);
	alarm(0);
	if (FAIL == fd)
	{
		DBG_PRINTF((dbg_syserr, "Open fifo timeout %s",
				strerror(errno)));
		ret = ev_tout;
	}
	else
	{
		sz = (int)F_sizeof(M_p_fb);
		if (!(p_tmp_fb = (FBFR *)ntp_alloc("FML", NULL, sz+64)))
		{
			DBG_PRINTF((dbg_syserr, "tp_alloc fail %d %s",
				ntp_errno(), ntp_strerror(ntp_errno())));
			ret = ev_err;
		}
		else if (FAIL == (nb = (int)read(fd, (char *)p_tmp_fb, sz+64)))
		{
			DBG_PRINTF((dbg_syserr, "read fail %d", errno));
			ret = ev_err;
		}
		else if (FAIL == F_index(p_tmp_fb, 1))
		{
			DBG_PRINTF((dbg_syserr, "F_index fail %d %s",
				    F_errno(), F_strerror(F_errno())));
			ret = ev_err;
		}
/******* Do *NOT* use extread, it gives truncation problems !!!
		else if (FAIL == F_extread(p_tmp_fb, fp))
		{
			DBG_PRINTF((dbg_syserr, "F_extread fail %d %s",
				F_errno(), F_strerror(F_errno())));
			ret = ev_err;
		}
***/
		else
		{
/* The I_SYSDATE we send to the issuer should be the same as the I_OUTDATEREC*/
/* we set in the response. If they are different, the date we send to the */
/* issuer should be used. */

/* TR - NMR007057. Now that we are correctly setting I_OUTDATEREC from the */
/* value sent in Field 28 in the response from the host we should only     */
/* change I_SYSDATE here.						   */
			if( !FBISNETMGT(M_p_fb) )
			{
				DBG_PRINTF((dbg_progdetail,
					    "!!!Checking I_SYSDATE!!!"));
				if( (FAIL == CF_get(M_p_fb, I_SYSDATE, 0,
					(char*) &lold_sysdate, 0, FLD_LONG)) ||
				   (FAIL == CF_get(p_tmp_fb, I_SYSDATE, 0,
					(char*) &lnew_sysdate, 0, FLD_LONG)))
				{
					DBG_PRINTF((dbg_syserr,
						    "CF_get %d - %s",F_errno(),
						    F_strerror(F_errno()) ));
					ret = ev_err;
				}
				else
				{
					if(lold_sysdate != lnew_sysdate)
					{
						if ((FAIL == CF_chg(p_tmp_fb,
							 I_SYSDATE, 0,
							(char*) &lold_sysdate,
							 0, FLD_LONG))
						    /* TR - NMR007057  ||
						    (FAIL == CF_chg(p_tmp_fb,
							 I_OUTDATEREC, 0,
							(char*) &lold_sysdate,
							 0, FLD_LONG))
						    */
								      )
						{
							DBG_PRINTF((dbg_syserr,
							 "CF_chg %d - %s",
							  F_errno(),
							  F_strerror(F_errno())
								    ));
							ret = ev_err;
						}
					}	
				}
			}
			else
			{
				DBG_PRINTF((dbg_progdetail,
				    "18xx message, I_SYSDATE is not checked"));
			}
			DBG_PRINTF((dbg_progdetail,
				    "read %d bytes into %d+64", nb, sz));
					
					
			ret2 = checkPartialAuthorization(M_p_fb, p_tmp_fb, &flagPartialAuthorization);

			if( ev_err != ret && FBISRECON( M_p_fb ) )
				ret = vs_chk_recon(p_tmp_fb);
			
			/* MV BZWBK_DEV-25 20090429 Merge the additional amounts */
			if (ev_err != ret)
			{
				amtadd_dbgdump(p_tmp_fb, dbg_progdetail, 
						"Additional amounts from host");
				
				if( NULL != (p_amtadd_fb = (FBFR *)ntp_alloc("FML", NULL, sz)) )
				{
					/* Operating with known amounts so that
					 * existing bank's logic would work
					 * ie bank may return credit limit with
					 * account type 20, but Cortex populated with 0
					 * And so by using new function it would be added
					 * to the end of buffer, but ATM driver would
					 * pick up first! Probaly maybe adjusted in future
					 * to merge all amounts with new functions!
					 */
					/* Save KNOWN additional amounts returned
					 * by host into separate tmp buffer */
					amtadd_merge_buffers(p_amtadd_fb,
							p_tmp_fb,
							AMTADDACCIDX_MODE_KNOWN);
					
					amtadd_dbgdump(p_amtadd_fb, dbg_progdetail, 
						"Saved KNOWN additional amounts");
					
					/* remove addamt to protect the target buffer update  */
					amtadd_delall(p_tmp_fb, AMTADDACCIDX_MODE_KNOWN);
				}
				else
				{
					DBG_PRINTF((dbg_syserr,
						"amtadd FB tp_alloc fail %d %s",
						ntp_errno(),
						ntp_strerror(ntp_errno())));
				}
			}	
			if(ev_err != ret && FAIL == F_update(M_p_fb, p_tmp_fb))
			{
				DBG_PRINTF((dbg_syserr,
					    "Fupdate %d - %s", F_errno(),
					    F_strerror(F_errno()) ));
				ret = ev_err;
			} 
			else
			{
				if( NULL != p_amtadd_fb )
				{
					/* Restore saved KNOWN additional amounts
					 * from separate tmp buffer */
					amtadd_merge_buffers(M_p_fb,
							p_amtadd_fb,
							AMTADDACCIDX_MODE_KNOWN);
				}
				amtadd_dbgdump(M_p_fb, dbg_progdetail, "Additional amounts after merge");
			}
			if (SUCCEED == ret &&
				F_pres(M_p_fb, ISO_LCLYR, 0) && F_pres(M_p_fb, C_DATELOCAL, 0))
			{
				if (SUCCEED != CF_get(M_p_fb, ISO_LCLYR, 0, (char *)&yy_stored, 0, FLD_LONG))
				{
					DBG_PRINTF(( dbg_syserr, "Failed to get stored local year." ));
					ret = FAIL;
				}
				if (SUCCEED == ret && SUCCEED != CF_get(M_p_fb, C_DATELOCAL, 0, (char *)&date, 0, FLD_LONG))
				{
					DBG_PRINTF(( dbg_syserr, "Failed to get C_DATELOCAL." ));
					ret = FAIL;
				}
				if (SUCCEED == ret)
				{
					mm = (date % 10000) / 100;
					dd = date % 100;
					yyyymmdd = dd +(mm * 100) + (yy_stored * 10000);
					if (SUCCEED == ret && FAIL == CF_chg(M_p_fb,C_DATELOCAL, 0,(char*) &yyyymmdd,0, FLD_LONG))
					{
						DBG_PRINTF(( dbg_syswarn, "Failed to amend local date"));
						ret = FAIL;
					}
				}
			}

			ntp_free((char *)p_tmp_fb);
			
			if( NULL != p_amtadd_fb ) ntp_free((char *)p_amtadd_fb);
		}
	}

	(void)close(fd);

	unlink(M_fifonm);
	M_fifonm[0] = EOS;

				/* MJB amtset */
	if (ev_ok == ret && !FBISREJ(M_p_fb))	/* good response */
		vc_set_amtset_lf(M_p_fb);
	else
		vc_unset_amtset_lf(M_p_fb);
				/* MJB amtset */

				
	if( FAIL == CF_get( M_p_fb, I_IFNETADR, 0, hostnm, 0, FLD_STRING ) )
		return( ev_err );
				
			
	if (ev_tout == ret)
	{	
		(void) add_rejmsg(M_p_fb, "Response Timed Out !");
		
		vs_gen_rsp(M_p_fb,MAC_ERROR, MRS_RRSP_ISSTIM, RJR_VIF_RSPTOUT);
		vs_event( err_rsptout );

		if ( !FBISNETMGT(M_p_fb) && M_maxtimeouts )
		{
			/* mvitolins, 17/11/2014, BPD_MAINT-83 */
			hst_increment_touts( hostnm );
			
			M_timeoutcount++;
			
			DBG_PRINTF((dbg_syswarn, "Consecutive timeout counter = [%d]", 
				    M_timeoutcount)); 
			
			if ( M_timeoutcount >= M_maxtimeouts )
			{
				DBG_PRINTF((dbg_fatal, "Max timeouts reached - "
							"Setting interface OFF LINE [%d][%d]",
							M_timeoutcount, M_maxtimeouts ));

				hst_upd_current_stat( hostnm, HCS_OFF_LINE );
			}
		}	
	}
        else
        {
		/* Reset consecutive_touts counter if > 0 and msg processed */
		/* mvitolins, 17/11/2014, BPD_MAINT-83 */
		if (0 < M_timeoutcount)
		{
			hst_reset_touts( hostnm );
		}
        }

	if (ev_ok == ret && FBISRSP(M_p_fb) && FBISNETMGT(M_p_fb))
	{
		short	fn;
				
		fn = cbf_get_fncode( M_p_fb );

		if( MFC_NETMGT_SIGN_ON == fn )
		{
			ctxbool	do_sync=FALSE;
			
			if (OPTION_ENABLED==M_hostsyncreq)
			{
				/* MV 2009.04.20 BZWBK_DEV-26 */
				do_sync=is_sync_required(hostnm);
			}
			
			if (!do_sync)
			{
				/* DO the usual way (do not need sync) */
				if( FAIL == hst_upd_reqcurstat(hostnm, 1, HRS_ON_LINE))
					ret = ev_err;
			} else
			{
				if (FAIL == hst_upd_request_stat(hostnm, HRS_ON_LINE) ||
					FAIL == hst_upd_current_stat(hostnm, HCS_SYNC_ONL))
					ret = ev_err;
			}
		}
		else if( MFC_NETMGT_ECHO == fn && TRUE == M_updhostst )
		{
			if( FAIL == hst_upd_comstat( hostnm, 1,
						    HCS_ON_LINE ) )
/*			if( FAIL == hst_upd_curstat( hostnm, 1,
						    HDBCMD_ENABLE ) )
*/				ret = ev_err;
			M_updhostst = FALSE;
		}
		else if( MFC_NETMGT_SIGN_OFF == fn )
			if( FAIL == hst_upd_reqcurstat(hostnm,1,HRS_OFF_LINE))
				ret = ev_err;
	}

	DBG_PRINTF(( dbg_progdetail, "ev_ok==ret: %d  isrsp: %d  !isnetmgt %d",
		    ev_ok == ret, FBISRSP(M_p_fb), !FBISNETMGT(M_p_fb)));

	DBG_PRINTF(( dbg_progdetail, "iscassh: %d  isaprv: %d  isenq: %d",
		    FBISCASH(M_p_fb), FBISAPRV(M_p_fb),	FBISBENQ(M_p_fb)));

	if (ev_ok == ret && FBISRSP(M_p_fb) )
		if( !F_pres(M_p_fb, I_OUTBTCHTYP, 0 ) &&
		   FAIL == CF_chg(M_p_fb, I_OUTBTCHTYP, 0, 
				  (char *)&outbtchtype, 0, FLD_SHORT ) )
			ret = ev_err;

/* ************************************************************************
	*	1500 reconcilliation messages not supported	*
	*********************************************************
	if (ev_ok == ret && FBISRSP(M_p_fb) &&
	    ((FBISCASH(M_p_fb) || FBISBENQ(M_p_fb)) && FBISAPRV(M_p_fb)))
	{
		DBG_PRINTF(( dbg_progdetail,"Calling: %s",SWADRECSVC));

		if (FAIL == ntp_call(SWADRECSVC,
				     (char *)M_p_fb,
				     0L, 
				     (char **)&M_p_fb, 
				     &rsplen,
				     0))
		{
			DBG_PRINTF((dbg_syserr, 
				    "tpcall %s failed %d [%s]",
				    SWADRECSVC,
				    ntp_errno(),
				    ntp_strerror(ntp_errno())));
			ev_svcfail(SWADRECSVC,ntp_errno());
			ret = ev_err;
		}
		
	}
************************************************************************ */

	if (flagPartialAuthorization==1)
	{
		DBG_PRINTF(( dbg_progdetail, "Checking partial authorization result -> ret2[%d]",  ret2));	
		
		if (ret2 != SUCCEED)
		{
			DBG_PRINTF(( dbg_fatal, "Checking partial authorization result is fail"));	
			ret = ev_err;
		}
	}
	else 
	{
		DBG_PRINTF(( dbg_progdetail, "Checking partial authorization result don't needed"));
	}

	return( ret );
}


/*------------------------------------------------------------------------
 *
 * Function	:  checkPartialAuthorization
 *
 * Purpose	:  check partial authorization in response
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int checkPartialAuthorization(FBFR * p_fb, FBFR * p_tmp_fb, int * flagPartialAuthorization)
{
	int ret = 0;
	
	char poscap[200];	
	char actrspcode[10];
	
	char stramtbill[20];
	char stramttxn[20];
	
	char curbillnet[10];
	char curbill[10];
	char curtxn[10];
	
	char curfrom[10];
	char curto[10];
	
	char amttxnorg[20];
	
	long inst_id;
	short txncode;
	
	double amtfrom_icbs_dop = 0.0;
	double amtbill = 0.0;
	double amttxn = 0.0;
	
	double rate = 0.0;	
	
	char forex_ref_dflt[FOREX_REFCODE_BUFFSIZE_FALCON] = {EOS};
	char forex_ref_fmt[GENSUBST_PTRN_BUFFSIZE_FALCON]  = {EOS};
	
	char dfltForexRef[20];
	
	strcpy(dfltForexRef, "DFLT");
	
	/* Autorizaciones parciales */
	memset(poscap, 0, sizeof(poscap));
	memset(actrspcode, 0, sizeof(actrspcode));
	
	memset(curbill, 0, sizeof(curbill));
	memset(curtxn, 0, sizeof(curtxn));
	
	memset(curfrom, 0, sizeof(curfrom));
	memset(curto, 0, sizeof(curto));
	
	memset(stramtbill, 0, sizeof(stramtbill));	
	memset(stramttxn, 0, sizeof(stramttxn));	
	
	memset(amttxnorg, 0, sizeof(amttxnorg));	
	
	if ( SUCCEED == ( ret = CF_get(p_fb, C_POSCAP, 0, poscap, 0, FLD_STRING) ) ) 
	{
		DBG_PRINTF(( dbg_progdetail, "poscap [%s] len[%d]", poscap, strlen(poscap))); 
		
		if (poscap[10]=='1') 
		{
			* flagPartialAuthorization = 1;
			
			DBG_PRINTF(( dbg_progdetail, "partial authorization response On [%d]", *flagPartialAuthorization));
			
			if (FAIL == CF_get(p_tmp_fb, C_ACTIONCODE, 0, actrspcode, 0, FLD_CHAR)
				|| FAIL == CF_get(p_tmp_fb, C_RSPCODE, 0, actrspcode + 1, 0, FLD_STRING))
			{
				ret = FAIL;
			}
			else 
			{
				ret = SUCCEED;
				actrspcode[3] = 0;
				
				DBG_PRINTF(( dbg_progdetail, "actrspcode[%s]", actrspcode));
				
				if (0==strcmp(actrspcode, "002"))
				{
					DBG_PRINTF(( dbg_progdetail, "response is partial authorization"));
					
					if (SUCCEED != F_get(p_tmp_fb, BPD_ISO_FB4, 0, (char *)&amtfrom_icbs_dop, 0L))
					{
						DBG_PRINTF((dbg_syswarn,"Failed to get BPD_ISO_FB4 from FB p_tmp_fb"));
						ret = FAIL;
					}	
				
					if (SUCCEED==ret)
					{
						DBG_PRINTF(( dbg_progdetail, "amtfrom_icbs_dop[%f]", amtfrom_icbs_dop )); 
						
						cotux_flds_t req_flds[] = 
						{	/* FLDID				Source memory address	FLDLEN							OCC	Type   Presence  Req cond */
							{C_AMTTXN,			amttxnorg,			sizeof(amttxnorg),			0, FLD_STRING, FLD_MAND, NULL},
							{C_CURBILLNET,		curbillnet,			sizeof(curbillnet),			0, FLD_STRING, FLD_MAND, NULL},
							{C_CURTXN,			curtxn,				sizeof(curtxn),				0, FLD_STRING, FLD_MAND, NULL},
							{C_TXNCODE,			&txncode,			sizeof(txncode),			0, FLD_SHORT,  FLD_OPT,  NULL},
							{I_INST_ID,			&inst_id,			sizeof(inst_id),			0, FLD_LONG, 	FLD_OPT, NULL},
							{BADFLDID,			NULL,				0,							0, 0,          0,        NULL}
						};	

						/* Going to fill in structure with fields from incoming request */
						ret = cotux_getfields(p_fb, req_flds, NULL);
					}

					if (SUCCEED==ret)
					{			
						DBG_PRINTF(( dbg_progdetail, "validating forex... C_AMTTXN[%s] C_CURBILLNET[%s] C_CURTXN[%s] amtfrom_icbs_dop[%f]", amttxnorg, curbillnet, curtxn, amtfrom_icbs_dop ));
						DBG_PRINTF(( dbg_progdetail, "txncode[%ld] inst_id[%d]", txncode, inst_id ));

						amtbill = amtfrom_icbs_dop;
						
						if (0 == strcmp(curtxn, "214"))
						{
							amttxn = amtfrom_icbs_dop;
						}
						else 
						{
							if (SUCCEED==ret)
							{
								strcpy(curfrom, "214");
								strcpy(curto, curtxn);
								
								DBG_PRINTF((dbg_progdetail,"curfrom[%s] curto[%s]", curfrom, curto));
								
								if (SUCCEED != forex_do_forex(
									inst_id, dfltForexRef,
									amtfrom_icbs_dop, &amttxn, &rate,
									curfrom, curto,
									txncode,
									NULL, p_fb, forex_ref_dflt, forex_ref_fmt,
									FOREXREF_ROLE_ISS,
									FALSE, FALSE))
								{
									DBG_PRINTF((dbg_syserr,"Failed to convert %lf "
										"in [%s] to [%s] for Institution "
										"[id=%ld]", amtfrom_icbs_dop, curfrom,
										curto, inst_id));
									ret = FAIL;
								}
								
								/* sprintf(tmpbuf, "%013.6lf", rate);*/	/* format to nnnnnn.nnnnnn */
								/* memstrscpy(out, tmpbuf, len);*/
							}
						}

						if (SUCCEED==ret)
						{	
							sprintf(stramtbill, "%.2lf", amtbill);
							sprintf(stramttxn, "%.2lf", amttxn);
							
							DBG_PRINTF(( dbg_progdetail, "amtfrom_icbs_dop[%f] amttxn[%f] stramtbill[%s] stramttxn[%s] curbillnet[%s] amttxnorg[%s]", 
										amtfrom_icbs_dop, amttxn, stramtbill, stramttxn, curbillnet, amttxnorg ));
										
							cotux_flds_t rsp_flds[] = 
							{	/* FLDID		Source memory address	FLDLEN							OCC	Type   Presence  Req cond */
								{C_AMTTXN,			stramttxn,		sizeof(stramttxn),		0, FLD_STRING, FLD_MAND, NULL},
								{C_AMTBILL,			stramtbill,		sizeof(stramtbill),		0, FLD_STRING, FLD_MAND, NULL},
								{C_AMTTXNORG,		amttxnorg,		sizeof(amttxnorg),		0, FLD_STRING, FLD_MAND, NULL},	
								{BADFLDID,		NULL,			0,						0, 0,			0,        NULL}
							};
		
							ret = cotux_setfields(p_fb, rsp_flds, NULL);
							
							if (SUCCEED==ret)
							{
								DBG_PRINTF(( dbg_progdetail, "C_AMTTXN/C_AMTBILL/C_AMTTXNORG changed successfully" )); 
							}
							else 
							{
								DBG_PRINTF(( dbg_syserr, "Error updating C_AMTTXN/C_AMTBILL/C_AMTTXNORG" )); 
							}
					
						}	

					}

				}
			}
			
		}
		else 
		{
			DBG_PRINTF(( dbg_progdetail, "partial authorization response Off [%d]", *flagPartialAuthorization));
		}
	}
	
	
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  vs_return
 *
 * Purpose	:  return to the caller
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	vs_return( void )
{

#if GSM_DEBUG_LEVEL > dbg_proginfo
        static char success_msg[]="SUCCESS";
	static char failed_msg[]="FAILED";
	char *p_msg;
	
#ifdef TESTMODE
DBG_PRINTF((dbg_fatal,"TESTMODE! Not really Returning"));
return SUCCEED;
#endif

	p_msg = success_msg;
	
        if (M_err != err_allok) p_msg = failed_msg;

	/* not needed if gsm debug at level */
	DBG_PRINTF(( dbg_proginfo,"st_return: %s (%d)", p_msg, M_err));
#endif
	
	return( M_err == err_allok ? SUCCEED : FAIL );
}

/*------------------------------------------------------------------------
 *
 * Function	:  vs_error
 *
 * Purpose	:  error handling
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	vs_error( void )
{
	short	ret = ev_ok;

	vs_event( M_err );

	if (M_fifonm[0])
	{
		unlink(M_fifonm);
		M_fifonm[0] = EOS;
	}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * function	: vs_sigdisp
 *
 * purpose	: react on signal (no more hanging)
 *
 * parameters	: sig - signal which caused interrupt
 *
 * returns	: 
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate void	vs_sigdisp( int sig)
{

	DBG_PRINTF((dbg_progdetail,
		    "!!!!!!!!!!  Interrupted: %d  !!!!!!!!!!", sig ));

	if( SIGALRM == sig )
	{
		signal( SIGALRM, vs_sigdisp );
		DBG_PRINTF((dbg_progdetail, "Alarm signal"));
	}

	if( SIGTERM == sig || SIGQUIT == sig || SIGINT == sig || SIGILL == sig )
	{
		DBG_PRINTF((dbg_progdetail, "Killed by signal %d - exiting", sig ));
		exit( 1 );
	}
	return;
}

/*--------------------------------------------------------------------------
 *
 * Function	: vs_atexit
 *
 * Purpose	: Disconnect network connections and kill low level driver
 *
 * Parameters	: void
 *
 * Returns	: void
 *
 * Comments	: Is called automaticly by OS on exit and return from the main
 *
 *------------------------------------------------------------------------*/
ctxprivate void	vs_atexit( void )
{
				/* Need to add aborting txn if necessary */
	return;
}

/*--------------------------------------------------------------------------
 *
 * Function	: vs_init
 *
 * purpose	:  create network access point
 *
 * parameters	:  hostnm - network name of the host running driver
 *
 * returns	:  SUCCEED / FAIL
 *
 * comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int	vs_init(char *hostnm, char *srvnm, int timeout_on,
			int timeout_off)
{
	int	ret = SUCCEED;


	if( hostnm != NULL )
		strcpy( M_tcp_host, hostnm );
	else
		M_tcp_host[0] = 0;

	/* strcpy(M_tcp_svc,  srvnm); */
	M_rsptime_on = timeout_on;
	M_rsptime_off = timeout_off;
	
	signal( SIGTERM, vs_sigdisp );
	signal( SIGQUIT, vs_sigdisp );
	signal( SIGINT,  vs_sigdisp );
	signal( SIGALRM, vs_sigdisp );

	{
		int	i;

		for( i = 0; i < 32; i++ )
			signal( i, vs_sigdisp );
	}
	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	:  vs_event
 *
 * Purpose	:  Log an error
 *
 * Parameters	:  ev - event type
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	vs_event( int ev )
{
	int	ret = SUCCEED;
	char	szife[9];

	switch( ev )
	{
		case err_connect:
			ret = ev_call( EVTAG_LANERR, M_tcp_svc );
			break;

		case err_missfld:
		case err_msgcnv:
			ret = ev_call( EVTAG_MSGCONV, M_tcp_svc );
			break;

		case err_getev:
		case err_putev:
		case err_sndmsg:
			ret = ev_call( EVTAG_LOWCOM, M_tcp_svc );
			break;
		case err_rsptout:
			if (SUCCEED == ret) 
			{
				if (SUCCEED != CF_get(M_p_fb, I_IFE,
						 0, szife, 0, FLD_STRING))
				ret = FAIL;
			}

			ret = ev_call( EVTAG_TIMEOUT, szife );
			break;

		default:
			DBG_PRINTF(( dbg_syserr,"Invalid event: %d", ev ));
			ret = FAIL;
			break;
	}

	return ret;
}

/*--------------------------------------------------------------------------
 *
 * Function	: vs_gen_rsp
 *
 * Purpose	: Turn p_fb into a response. Add the reject source and
 *		  reason.
 *
 * Parameters	:
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxpublic int	vs_gen_rsp(FBFR *p_fb, short action, char *response,
			   short rejreas)
{
static	char	rspsrc[] = { RSPSRC_INTERFACE, EOS, EOS };
	int	ret = SUCCEED;

	ret = cbf_gen_rsp(p_fb, action, response);

	if (SUCCEED == ret && !F_pres(p_fb, I_RSPSRC, 0))
	{
		DBG_PRINTF((dbg_syserr, "Update RSP [%d]", rejreas));

		if (SUCCEED != CF_chg(p_fb, I_RSPSRC, 0, rspsrc,
							0, FLD_STRING)
		||  SUCCEED != CF_chg(p_fb, I_REJREASON, 0, (char *)&rejreas,
								0, FLD_SHORT))
			ret = FAIL;
	}

	return ret;
}
					/* MJB amtset */
/*------------------------------------------------------------------------
 *
 * function	: vc_unset_amtset_lf
 *
 * purpose	: Clear amount settlement and currency for reject
 *
 * parameters	: 
 *
 * returns	: 
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate void	vc_unset_amtset_lf(FBFR *p_fb)
{
	double	amtset = 0.0;
        
	if (0 > CF_chg(p_fb, C_AMTSET, 0, (char *)&amtset, 0, FLD_DOUBLE))
		DBG_PRINTF((dbg_progdetail, "Unset amtset"));
	else
		DBG_PRINTF((dbg_syswarn, "Couldnt unset amtset"));

	return;
}

/*------------------------------------------------------------------------
 *
 * function	: vc_set_amtset_lf
 *
 * purpose	: Set up amount settlement and currency
 *
 * parameters	: 
 *
 * returns	: 
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate void	vc_set_amtset_lf(FBFR *p_fb)
{
	char	curbill[3 + 1];
	double	amtbill;
        
	if( !F_pres( p_fb, C_AMTSET, 0 ) &&
		( FBISFIN(p_fb) || FBISFINREV(p_fb) ) )
	{
		if(SUCCEED != CF_get(p_fb, C_AMTBILL, 0, (char *)&amtbill,
							  0, FLD_DOUBLE )
		   || SUCCEED != CF_get(p_fb, C_CURBILL, 0, curbill, 
							  0, FLD_STRING) )
		{
			DBG_PRINTF((dbg_progdetail, "Couldnt get amtbill"));
		}
		else
		{
			if (SUCCEED != CF_chg(p_fb, C_CURSET, 0, curbill,
								0, FLD_STRING)
			    || SUCCEED != CF_chg(p_fb, C_AMTSET, 0, 
					(char *)&amtbill, 0, FLD_DOUBLE))
				DBG_PRINTF((dbg_syswarn,"Couldnt set amtset"));
			else
				DBG_PRINTF((dbg_progdetail, "Set amtset"));
		}
	}
}


/*------------------------------------------------------------------------
 *
 * Function	:  rtc_get_times_val_bzwbk
 *
 * Purpose	:  returns the predefined timer values (depending on txn type)
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  returns dflt if different txn type
 *		   * All on-line txns (Cash/Sale/Balance/Mini-statement etc) 
 *		   	use timeout specified in TIMEOUT_ON (default=5).
 *		   * All signon sign off and echo test txns use fixed timeout
 *			of 15 seconds.
 *		   * All advice txns and ALL reversals use the value of the
 *		   	TIMEOUT_OFF (default=35).
 *		   * All other txns use the value of TIMEOUT_ON parameter
 *		   	in ctxcfg (default=35).
 *
 *----------------------------------------------------------------------*/
ctxprivate int	rtc_get_timer_val_bzwbk( FBFR *p_fb, int on, int off )
{
	int 	ret = 0;

	if( (FBISFIN(p_fb) || FBISAUTH(p_fb)) && !FBISADV(p_fb) )
	{
		/* Use default value if TIMEOUT_ON is zero or less */
		ret = (on>0) ? on :ALARM_ONLINE_DFLT;
		DBG_PRINTF(( dbg_progdetail, "Online txn. TOUT: %d", ret ));
	}
	else if( FBISREVCB(p_fb) || FBISADV(p_fb) )
	{
		/* Use default value if TIMEOUT_OFF is zero or less */
		ret = (off>0) ? off :ALARM_OFFLINE_DFLT;
		DBG_PRINTF(( dbg_progdetail, "Rev/Adv txn. TOUT: %d", ret ));
	}
	else if( FBISNETMGT(p_fb) )
	{
		ret = ALARM_NETMGT;
		DBG_PRINTF(( dbg_progdetail, "Net mgt txn. TOUT: %d", ret ));
	}
	else
	{
		/* Use default value if TIMEOUT_ON is zero or less */
		ret = (on>0) ? on :ALARM_ONLINE_DFLT;
		DBG_PRINTF(( dbg_progdetail, "Dflt txn. TOUT: %d", ret ));
	}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * function	: is_sync_required
 *
 * purpose	: Checks does synchronization mode required for particular
 * 		  host
 *
 * parameters	: hostnm - name of host to be checked
 *
 * returns	: TRUE - host current state should be set to HCS_SYNC_ONL
 * 		  FALSE - host current state should not be set to HCS_SYNC_ONL
 * 		  (i.e. neets to be set HCS_ON_LINE)
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate ctxbool is_sync_required( char *hostnm )
{
	ctxbool 	ret = FALSE;
	short	comstate, reqstate, curstate, accok, stmtok;
	char	*thisfn="is_sync_required";
	DBG_PRINTF(( dbg_progdetail, "%s:Checking Host <%s> for sync on-line state",
		     thisfn, hostnm));
	
	/* Check current status */
	if( SUCCEED == hst_get_hostdet(hostnm, &reqstate, &curstate, &comstate,
				&accok, &stmtok, M_tcp_svc ) )
	{
		DBG_PRINTF(( dbg_syserr, "com=%d, cur=%d, req=%d", 
				comstate, curstate, reqstate));
		if ((HCS_OFF_LINE==curstate || HCS_SYNC_ONL==curstate) 
				&& HCOMS_ON_LINE==comstate)
		{
			ret=TRUE;
		}
	} else
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get HOSTDET"));
	}
	
	DBG_PRINTF(( dbg_progdetail, "%s:return, sync on-line mode %s",
			thisfn, (ret?"required":"not required") ));
	return( ret );
}

/*------------------------------------------------------------------------------
 *
 * Function	: set_channel
 *
 * Purpose	: Sets M_channel variable
 *
 * Parameters	: channel - value to put in M_channel
 *
 * Returns	: 
 *
 * Comments	: 
 *
 *----------------------------------------------------------------------------*/
ctxpublic void set_channel(short channel)
{
	M_channel = channel;
}

/*--------------------------------------------------------------------------
 *
 * Function     : set_maxtimeouts
 *
 * Purpose      : Sets M_maxtimeouts variable.
 *
 * Parameters   : int Max_timeouts
 *
 * Returns      : void
 *
 * Comments     : 
 *
 *------------------------------------------------------------------------*/
ctxpublic void      set_maxtimeouts( int maxtimeouts )
{
        DBG_PRINTF((dbg_proginfo, "Setting Max Timeouts to [%d]", maxtimeouts ));
        M_maxtimeouts = maxtimeouts;
}
