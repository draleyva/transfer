/*-----------------------------------------------------------------------
 *
 * File		: icbsif.c
 *
 * Author	: Alex Butikov
 *
 * Created	: Jan 2011
 *
 * Purpose	: ICBS interface server
 *
 * Comments	:
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <errno.h>
#include <string.h>
#include <memory.h>

#include <sldbg.h>
#include <slfdbg.h>
#include <slcfp.h>
#include <slnfb.h>
#include <slntp.h>
#include <sldtm.h>
#include <slgtp.h>
#include <slta.h>

#include <cortex.h>
#include <coevent.h>
#include <cocbfdef.h>
#include <comsgtyp.h>
#include <copath.h>
#include <cocrd.fd.h>
#include <coint.fd.h>

#include <hoststat.h>
#include <hostcmd.h>
#include <mxunml.h>
#include <mxuiso2.h>
#include <fav.h>
#include <ovrld.h>
#include <icbscv.h>

#include <cosvinit_fun.h>
#include <genif.h>
#include <cotxnmon.h>

#include <slstring.h>
/*---------------------------Externs------------------------------------*/
extern int	errno;

extern int	vs_process( FBFR **pp_fb );

extern int	vs_init(char *lanhost, char *srvnm, int timeout_on,
							int timeout_off);
extern int	vs_gen_rsp(FBFR *p_fb, short action, char *response,
			   short rejreas);
extern void	jiso_set_basefe(char *basefe);
extern void	jiso_set_use_conacc(ctxbool use_conacc_f);
extern void	jiso_set_ignore_nou_accno(void);

extern void	set_channel(short channel);

/*---------------------------Macros-------------------------------------*/
#define	SRVNM_LEN	64
#define	RSPCODE_LEN	6
#define ICBSSVC		"ICBSIF"
/* hlg BPD_MAINT-137 VISA OCT fixes  Aug18 
	Reject OCT trasactions
*/
#define FBOCTREJADV(x) (1 == fev_evbool(x, &cfb_octrejadv))

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/* hlg BPD_MAINT-137 VISA OCT fixes  Jul/2018 */
ctxprivate fld_cond_t cfb_octrejadv = { COND_FBOOL, NULL, "(I_TXNSTATUS == '11') && (C_TXNCODE==26) && (C_MSGCLS == 2)" };
/*---------------------------Statics------------------------------------*/
static char rcsid[] = "$Id$";

ctxprivate char	*M_tagnm = "ICBSIF";

int		M_DO_DUMP=0;			/* Message Dumps 	*/
ctxprivate int	M_dbglev=0;			/* debug level		*/
ctxprivate int	M_dbgbuf=0;			/* debug level		*/
ctxprivate ctxbool	M_use_conacc = FALSE;		/* using CONACC server	*/
ctxprivate ctxbool	M_ignore_nou_accno = FALSE;	/* ignore ACCNO for NOU txns */
ctxprivate char	M_dbgfile[CTX_FILENAME_MAX];	/* debug output name	*/
ctxprivate char	M_basefe[FE_LEN+1];		/* using this BASEFE	*/
ctxprivate char	M_lansvc[SRVNM_LEN+1];  	/* service for driver	*/
ctxprivate int	M_timeout=0;			/* Online Rsp timeout	*/
ctxprivate int	M_timeout_off=0;		/* Offilne Rsp timeout	*/
ctxprivate char	M_service[SRVNM_LEN+1] = "";	/* Service to advertise */
ctxprivate long 	M_ovrld_check = 0L; 		/* CN 9709 10/6/03 	*/
ctxprivate ctxbool	M_vpan_over_pan = FALSE;	/* MV NMR023597		*/
ctxprivate char	M_ath_aiid_code[AIID_LEN+1] = "";	/* code for	*/
						/* transaction from	*/
						/* ath - local network	*/
ctxprivate int	M_maxtimeouts = 0;

ctxprivate char **M_svcs = NULL; /* services advertised by server */

/* hlg BPD_MAINT-131 VISA OCT changes  APR/2018 */
static char 	M_octpcode[PCODELEN + 1] = ""; /* PCODE to be used for VISA OCT transaction default 26 = MTC_CHFUNDSXFER*/
static char 	M_octmti[MTILEN + 1] = ""; /* MTI to be used to VISA OCT transaction default 0100 */
ctxprivate ctxbool	M_octrejadv = FALSE;	/* MV NMR023597		*/

/*---------------------------Externs------------------------------------*/
extern void	set_maxtimeouts(int maxtimeouts);
/*---------------------------Prototypes---------------------------------*/
ctxpublic int	icbsif_init( FILE *fp, char *subsect );
ctxpublic void	ICBSIF(TPSVCINFO *p_svc);
ctxprivate int	proc_req( FBFR **pp_fb, char *service, char *lanhost );
ctxprivate void	vi_printdbg( FBFR *p_fb );

/*------------------------------------------------------------------------
 *
 * Function	:
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *----------------------------------------------------------------------*/
ctxpublic int	icbsif_init( FILE *fp, char *subsect )
{
	char	svcnm[16];
	int	ret = SUCCEED;
	ctxbool	signon_req;
	ctxprivate cfp_parm cfp[] =
	{
		/* NMR006689 PE - Make timeout values more configurable */
		{"TIMEOUT", parm_int, 	0,		    TRUE,
			 (void *)&M_timeout,				0},
		{"TIMEOUTOFF", parm_int, 	0,	    FALSE,
			 (void *)&M_timeout_off,			0},
		{"DEBUG",   parm_int,    0, 		    FALSE,
			 (void *)&M_dbglev, 				0},
		{"DUMP",   parm_int,    0, 		    FALSE,
			 (void *)&M_DO_DUMP, 				0},
		{"DBGBUF",  parm_int,    0,		    FALSE,
			 (void *)&M_dbgbuf,				0},
		{"DBGNAME", parm_string, sizeof(M_dbgfile), FALSE,
			 (void *)&M_dbgfile,				0},
		{"USECONACC",  parm_truebool,    0,	    FALSE,
			 (void *)&M_use_conacc,				0},
		{"BASEFE",  parm_string,  sizeof(M_basefe), FALSE,
			 (char *)&M_basefe,				0},
		{"IGNNOUACCNO",  parm_truebool,	0,  FALSE,
			 (void *)&M_ignore_nou_accno,			0},
		{"SERVICE", parm_string, sizeof(M_service), FALSE,
			 (void *)&M_service,				0},
		{"OVRLD_CHECK", parm_long,0,			FALSE,
			 (void *)&M_ovrld_check,			0},
		{"VPANOVRPAN",  parm_truebool,    0,	    FALSE,
			 (void *)&M_vpan_over_pan,			0},
		{"ATH_AIID", parm_string, sizeof(M_ath_aiid_code), FALSE,
			 (void *)&M_ath_aiid_code,			0},
		{"MAXTIMEOUTS", parm_int, 0, FALSE, &M_maxtimeouts,	0},	
		{"OVR_OCTPCODE",   parm_string, sizeof(M_octpcode), FALSE,
			(void *)&M_octpcode, 0},
		{"OVR_OCTMTI",   parm_string, sizeof(M_octmti), FALSE,
			(void *)&M_octmti, 0},
		{"OCTREJADV",  parm_truebool,    			0 ,	    FALSE,
			 (void *)&M_octrejadv,				0},
		{0}
	};
	char	buf[CTX_FILENAME_MAX];
	char	*p;
	short	channel = 1; /* IF channel, default 1 */
	

	ret = cfp_parse(fp, cfp, M_tagnm, subsect);
	if( SUCCEED != ret )
	{
		fprintf(stderr, "Error : icbsif init failed %s %s (%s)\n",
			M_tagnm, subsect, cfp_errparm());
	}

	if (SUCCEED == ret)
	{
		ret = dbg_cfp_parse(fp, M_tagnm, subsect);
	}
	
	if (SUCCEED == ret)
	{
		DBG_SETNAME("ICBSIF");
	}

	if(M_dbgfile[0])
	{
		DBG_SETFILE(M_dbgfile);
	}

	jiso_set_use_conacc( M_use_conacc );
	jiso_set_basefe( M_basefe );

	/****************************************************/
	/* If flag is set, ignore the account number in the */
	/* message conversion for not on us transactions    */
	/****************************************************/
	if (TRUE == M_ignore_nou_accno)
	{
		DBG_PRINTF((dbg_progdetail, "Setting icbsif to ignore "
			"account number for not-on-us txns"));
		jiso_set_ignore_nou_accno();
	}
	else
	{
		DBG_PRINTF((dbg_progdetail, "Ignore_nou_accno is not set. "
			"Treating account number as normal"));
	}


	/* This function required so that large messages are
	 * handled properly */
	gtp_usebig();

	if( FAIL != ret )
	{
		ret = vs_init("", M_lansvc, M_timeout, M_timeout_off);
	}

	if (SUCCEED == ret)
	{
		/* TR 5455 If SERVICE config parameter set then use that */
		/* as the service name to advertise else use the default */
		if ( M_service[0] )
		{
			strscpy( svcnm, M_service );
		}
		else
		{
			strscpy( svcnm, ICBSSVC );
		}
	}

	if(SUCCEED == ret)
	{
		/* find the chanel of the inteface from the ubbctx alias */
		if(FAIL == (ret = ta_get_svcname(ntp_getSrvID(), &M_svcs))
			|| FAIL == (ret = chnl_get_channel(M_svcs, &channel)))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get service info "
				"for interface channel"));
		}
		else
		{
			DBG_PRINTF((dbg_progdetail, "Inteface uses comms "
				"channel: %hd", channel));
			set_channel(channel);
		}
	}

	if(SUCCEED == ret)
	{

		if (FAIL == ntp_advertise(svcnm, ICBSIF))
		{
			DBG_PRINTF((dbg_syserr, "tpadvertise %s failed %d %s",
				ICBSSVC,
				ntp_errno(), ntp_strerror(ntp_errno())));
			ret = FAIL;
		}
	}

	/* CN 9709 10/6/03 overload checking */
	if( SUCCEED == ret )
	{
		if (0 > M_ovrld_check)
		{
			DBG_PRINTF((dbg_syswarn,
				"Illegal INTERFACE overload delta <%ld>, "
				"changing to <0>",
				M_ovrld_check));
				
			M_ovrld_check = 0L;
		}
		
		if (M_ovrld_check)
		{
			DBG_PRINTF((dbg_proginfo,
				"INTERFACE system overload delta: %ld seconds",
				M_ovrld_check));
		}
		else
		{
			DBG_PRINTF((dbg_proginfo,
				"INTERFACE overload checking DISABLED"));
		}
		/* MV NMR023597 */
		if (M_vpan_over_pan)
		{
			set_vpan_over_pan(M_vpan_over_pan);
		}
		if (M_ath_aiid_code)
		{
			DBG_PRINTF(( dbg_progdetail, "ATH_AIID [%s] found in ctxcfg", M_ath_aiid_code));
			set_ath_aiid_code(M_ath_aiid_code);
		}
		/* mvitolin BZWBK_DEV-32 11/08/2010 */
		
		if( M_maxtimeouts )
		{
			DBG_PRINTF(( dbg_progdetail, "MAXTIMEOUTS [%d] found in ctxcfg", M_maxtimeouts));
			set_maxtimeouts( M_maxtimeouts );
		}
		
		/* hlg BPD_MAINT-131 17-apr-2018 */
		if (M_octpcode)
		{
			set_ovr_octpcode(M_octpcode);
		}
		if (M_octmti)
		{
			set_ovr_octmti(M_octmti);
		}
		if (M_octrejadv)
		{
			DBG_PRINTF(( dbg_progdetail, "Rejecting OCT finantials advice (0220/0230)"));
		}
	}

	return( ret );
}

/*--------------------------------------------------------------------------
 *
 * Function	: ICBSIF
 *
 * Purpose	: Service entry point for ICBS net transaction
 *
 * Parameters	: Usual for service
 *
 * Returns	: tpreturn
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxpublic void	ICBSIF( TPSVCINFO *p_svc )
{
	int	ret = SUCCEED;
	FBFR	*p_fb = (FBFR *)NULL;
	ctxbool	forward = FALSE;
	ctxbool	ovrld = FALSE;		/* CN 7927 10/6/03  ovrld chk	*/
        char    srvcnm[32];
	char	*fwd_to;
	int	cls =-1,
		fn =-1;
	long	rsplen;
	ctxbool	revnotadv = FALSE;	/* NMR006487 */
	ctxbool	del_crdacptid = FALSE;	/* CN 8612 */
	ctxbool	del_crdacptloc = FALSE;	/* CN 8612 */
	int	monstart=FALSE;		/* set to TRUE if MONSTART called */

	p_fb = MAKE_BIGGER (p_svc->data);

	if ((FBISAUTH(p_fb) || FBISFIN(p_fb) || FBISCBREV(p_fb))
		&& FBISREQ(p_fb))
	{
		monstart = TRUE;
		DBG_MONSTART(p_fb,ICBSSVC);
	}

	DBG_SETNAME("ICBSIF");

	DBG_SETDUMPMODE(p_fb, DUMP_ATSTART);
        DBG_SETNAMEBYPAN(p_fb);
        DBG_STAR(("ICBSIF service"));
        DBG_FBDIFFSTARTL(dbg_progdetail, p_fb);
	DBG_DUMPFB(dbg_proginfo, "ICBSIF called with", p_fb);

	forward = FALSE;
	if (F_pres(p_fb, I_RSPSRVCNM, 0))
	{
		if (0 > F_get(p_fb, I_RSPSRVCNM, 0, (char *)srvcnm, 0 ))
			;
		else
		{
			fwd_to = srvcnm;
			forward = TRUE;
		}
	}
	
	/* hlg BPD_MAINT-137 VISA OCT fixes  01Aug18 */
	if (M_octrejadv && FBOCTREJADV(p_fb))
	{
		DBG_PRINTF((dbg_proginfo, "OCT Transaction, rejecting due to configuration"));
		ret = FAIL;
		if ( FAIL == CF_chg(p_fb, C_ACTIONCODE, 0, "902", (FLDLEN) 0, FLD_CHAR)
			|| FAIL == CF_chg(p_fb, C_RSPCODE, 0, "02", (FLDLEN) 0, FLD_STRING) )
		{
			DBG_PRINTF((dbg_fatal, "Error: Unable to update action/response code"));
		}
	}

	/*
	 * CN 9709 10/6/03 check for system overload
	 * If overload detected, txn is rejected by library function.
	 */
	if (M_ovrld_check) 
	{
		ovrld = ovrld_check (p_fb, OVRLD_CHECK_IF, M_ovrld_check);
	}

	/* CN 9727 10/6/03 only process txn if no overload 
	 **************************************************/
	if (!ovrld && (FAIL != ret))
	{
		/* If CRDACPTID is not present, fill it with 15 spaces */
		/* Required for field 42 in ISO93HIF. Ilya. 27/11/99 */
		if (!F_pres(p_fb, C_CRDACPTID, 0))
		{
			ret = CF_chg(p_fb, C_CRDACPTID, 0, "               ",
				0, FLD_STRING);
			if (FAIL != ret)
			{
				DBG_PRINTF((dbg_progdetail, 
					"Added empty CRDACPTID"));
	
				/* CN 8612 
				 * if F42 crdacptid not present in 0100 auth
				 * request, don't include in 0110 response
				 */
				if (FBISAUTH (p_fb))
				{
					del_crdacptid = TRUE;
					DBG_PRINTF((dbg_progdetail,
					    "Empty CRDACPTID [auth req], "
					    "will delete on return from Host"));
				}
			}
		}
		/* If CRDACPTLOC is not present, fill it with 40 spaces */
		/* Required for field 43 in ISO93HIF. Mamta. 03/10/2000 */
		if (!F_pres(p_fb, C_CRDACPTLOC, 0))
		{
			ret = CF_chg(p_fb, C_CRDACPTLOC, 0,
				"                                        ", 
				0, FLD_STRING);
			if (FAIL != ret)
			{
				DBG_PRINTF((dbg_progdetail, 
					"Added empty CRDACPTLOC"));
	
				/* CN 8612 
				 * if F43 crdacptloc not present in 0100 auth
				 * request, don't include in 0110 response
				 */
				if (FBISAUTH (p_fb))
				{
					del_crdacptloc = TRUE;
					DBG_PRINTF((dbg_progdetail,
					    "Empty CRDACPTLOC [auth req], "
					    "will delete on return from Host"));
				}
			}
		}
	
		/* NMR006487 PE 05/11/2001 - ICBS will only accept 1420 
		 * reversals, so convert all 1400s to 1420s and convert 1430 
		 * responses back to 1410. This problem is caused by ICBS's 
		 * slavish adherance to our spec, does not mention the 
		 * possibility of 1400s.
		 */
		if( FBISREVCB(p_fb) && !FBISADV(p_fb) )
		{
			DBG_PRINTF(( dbg_progdetail, "Converting 1400->1420" ));
			revnotadv=TRUE;
			ret = CF_chg(p_fb, C_MSGFN, 0, "2", 0, FLD_STRING);
		}
	
		if (FAIL != ret)
		{
			ret = proc_req(&p_fb,M_lansvc,""/*M_lanhost*/);
		}
	
		/* NMR006487 - Convert a 1430 back to a 1410 if necessary */
		if( revnotadv )
		{
			DBG_PRINTF(( dbg_progdetail, "Converting 1430->1410" ));
			ret = CF_chg(p_fb, C_MSGFN, 0, "1", 0, FLD_STRING);
	
		}
	
		/* CN 8612 delete CRDACPTID if necessary */
		if (del_crdacptid)
		{
			DBG_PRINTF((dbg_progdetail, 
				"Deleting empty F42 CRDACPTID"));
			F_del(p_fb, C_CRDACPTID, 0); /* 'ret' not returned */
		}
	
		/* CN 8612 delete CRDACPTLOC if necessary */
		if (del_crdacptloc)
		{
			DBG_PRINTF((dbg_progdetail, 
				"Deleting empty F43 CRDACPTLOC"));
			F_del(p_fb, C_CRDACPTLOC, 0); /* 'ret' not returned */
		}

	} /* CN 9727 10/6/03 END only process txn if no overload */

	DBG_PRINTF((dbg_progdetail, "ICBSSVC %s: %s",
		forward ? "Forward" : "Return",
		SUCCEED == ret ? "TPSUCCESS" : "TPFAIL" ));
	
	if (monstart) DBG_MONPRINT(p_fb,ICBSSVC);

	/* forward always - GENAUTH doesn't expect any returns */
	if (forward /* && SUCCEED == ret */ )
        {
		DBG_DUMPFB(dbg_proginfo, "ICBSIF ends", p_fb);
 	       	DBG_FBDIFFENDL(dbg_progdetail,p_fb,DIFF_CLOSE);
	        DBG_STAR(("ntp_return from : ICBSIF"));
	        DBG_CLOSEFILE();

        	ntp_forward(fwd_to,
			(char *)p_fb,
			0L,
			0L);
	}
	else /* shouldn't get here */
	{
		DBG_DUMPFB(dbg_proginfo, "ICBSIF ends", p_fb);
 	       	DBG_FBDIFFENDL(dbg_progdetail,p_fb,DIFF_CLOSE);
	        DBG_STAR(("ntp_return from : ICBSIF"));
	        DBG_CLOSEFILE();

		ntp_return((SUCCEED == ret)
			? TPSUCCESS
			: TPFAIL,
			tpu_data,
			(char *)p_fb,
			0L,
			0L);
	}
}

/*--------------------------------------------------------------------------
 *
 * Function	: proc_req
 *
 * Purpose	: Generic procedure to process request
 *
 * Parameters	: Usual for service
 *		  service - name of the network service used by host driver
 *		  lanhost - network name of the box with the low level driver
 *
 * Returns	: SUCCEED/FAIL
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate int	proc_req(FBFR **pp_fb, char *service, char *lanhost )
{
	int		ret = SUCCEED;

	
	ret = vs_process(pp_fb);


	return ret;
}

/*------------------------------------------------------------------------
 *
 * function	: vi_printdbg
 *
 * purpose	: prints debug: pan, datecpt, timecpt, actioncode and rspcode
 *		  to track reject requests
 *
 * parameters	: p_fb - fielded buffer to play with
 *
 * returns	:
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate void	vi_printdbg( FBFR *p_fb )
{
	char	pan[30];
	long	datecpt;
	long	timecpt;
	short	ac;
	short	rsp;
	short	fn;


	if( DBG_GETLEV() < dbg_syserr )
		return;

	pan[0] = EOS;

	(void)CF_get( p_fb, C_MSGFN,      0, (char *)&fn,      0, FLD_SHORT );
	(void)F_get(  p_fb, C_PAN,        0, pan,              0 );
/**
	(void)CF_get( p_fb, C_DATECPT,    0, (char *)&datecpt, 0, FLD_LONG );
	(void)CF_get( p_fb, C_TIMECPT,    0, (char *)&timecpt, 0, FLD_LONG );
**/
	(void)CF_get( p_fb, C_ACTIONCODE, 0, (char *)&ac,      0, FLD_SHORT );
	(void)CF_get( p_fb, C_RSPCODE,    0, (char *)&rsp,     0, FLD_SHORT );


	if( MFN_REQRSP == fn || MFN_ADVRSP == fn )
		DBG_PRINTF((dbg_syserr, "%s   %08ld - %06ld  %c/%02hd",
			dbg_panMask(pan), local_date(), local_time(), ac, rsp ));

	return;
}
