/*-----------------------------------------------------------------------
 * 
 * File		: falcon2cv.c
 *
 * Author	: Ruslans Vasiljevs
 *
 * Created	: 09/05/2022
 *
 * Purpose	: FALCON2 conversion functions etc.
 *
 * Comments	: 
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
*-----------------------------------------------------------------------*/
/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <regex.h>

#include <slfdbg.h>
#include <sldbg.h>
#include <slntp.h>
#include <slnfb.h>
#include <slcfp.h>
#include <slstring.h>
#include <sldtm.h>
#include <slmap.h>
#include <slstrip.h>
#include <slregex.h>

#include <coctry.h>
#include <cocurr.h>

#include <coint.fd.h>
#include <cocrd.fd.h>
#include <token.fd.h>
#include <visa.fd.h>
#include <emv.fd.h>
#include <cointxt.fd.h>
#include <cust_prod.fd.h>

#include <coencpan.h>
#include <cocbfdef.h>
#include <comsgtyp.h>
#include <emv.h>
#include <videfs.h>

#include <enc.h>
#include <forex.h>
#include <diges.h>
#include <fds.h>
#include <falcon2cv.h>
#include <falcon2.h>
#include <visa_common_defs.h>

#include <bpd_prod.fd.h>

#include <dbtokenrh.h>
#include <bpddbtkndeviceprovrh.h>

#include <slstrmsc.h>
#include <comsc.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define BUF_SIZE		2048

#define FALCON2_HEADER_LEN	52
#define FALCON2_HEADER_RESERVED_1_LEN	17

#define DEF_FILLER_SiZE	1

#define ERROR_CODE_POS	25
#define ERROR_CODE_LEN	4

#define DECISION_COUNT_POS	423
#define DECISION_COUNT_LEN	2
#define DECISION_CODE_LEN	32
#define DECISION_TYPE_LEN	32

#define ISCHIPCRD(x) (SVCC1_INTLCHIP == (x) || SVCC1_LOCLCHIP == (x))
#define ISMAGCRD(x)  (SVCC1_INTL == (x) || SVCC1_LOCL == (x))

/* 'safe' memory copy (from string) */
#define memstrscpy(dst, src, max) memcpy(dst, src, strlen(src)>(max)?(max):strlen(src))

#define FOREX_REFCODE_BUFFSIZE_FALCON 33
#define GENSUBST_PTRN_BUFFSIZE_FALCON     128

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
typedef struct DBTRAN25_Context
{
	short   txncode;
	short	fncode;
	char	timestamp[UTCTIMESTAMPLEN+1];
	char	local_timestamp[UTCTIMESTAMPLEN+1];
	
	char	poscdim;
	char	poschic;
	char	poscham;
	char	poschac;
	char	posoe;
	char	poschp;
	char	poscp;
	
	double	transactionAmount;
	char	transactionCurrencyCode[3+1];
	short	mcc;
	char	posEntryMode;
	char	authPostFlag;

	FBFR	*adddata_fb;
} DBTRAN25_Context_t;

typedef struct Falcon_msglayout
{
	char *fieldname;
	int pos;
	size_t len;
	int (*p_fb2rawfn)(FBFR *, char *, size_t, DBTRAN25_Context_t *);
} Falcon_msglayout_t;

typedef struct masked_fields
{
    char *name;
    char *(*p_maskfn)(const char *, size_t len);
} masked_fields_t;

typedef struct 
{
	char    wallet_list[800];
	char    wallet_list_toktmp[800];
	char    * listWallet[50];
	
	char	wallet_list_toktmp_completed[2048];
	char	* listWalletCompleted[50];
	char	tknrequestorid_toktmp[2048];
	char	* listTknRequestorId[50];

	int     sizeListWallet;
	int		sizeListWalletCompleted;
} wallet_list_t;

/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/

ctxprivate char M_forex_ref_dflt[FOREX_REFCODE_BUFFSIZE_FALCON] = {EOS};
ctxprivate char M_forex_ref_fmt[GENSUBST_PTRN_BUFFSIZE_FALCON]  = {EOS};


ctxprivate int 	M_filler_size = DEF_FILLER_SiZE;
ctxprivate char	M_code2rsp[CTX_FILENAME_MAX+1] = {EOS};	/* Falcon to Cortex response code mapping */
ctxprivate short M_gmtoffset = -4;		/* GMT offset value for Falcon field `gmtOffset` */
ctxprivate char	M_ehsource[10+1] = "CORTEX";	/* Source system name */
ctxprivate char	M_ehdest[10+1] = "FALCON";	/* Destination application name */
ctxprivate char	M_workflow[16+1] = {EOS};	/* Name of the workflow to be executed by Falcon Fraud Manager */
ctxprivate char	M_clientid[16+1] = {EOS};	/* Unique identifier for the client or subclient */
ctxprivate char	M_onusafes[CTX_FILENAME_MAX] = {EOS};
ctxprivate char	M_unionafes[CTX_FILENAME_MAX] = {EOS};

ctxprivate char	*M_re_code2rsp = NULL;	/* "^(.+):(.+)$" */

ctxprivate	char M_tmp_wallet_list[800];

ctxprivate map_tbl_t map_tkntype[] =
{
	/* ctx, falcon */
	{TKN_TYPE_CRD_ON_FILE,	"C",	STR},	/* Card on File			*/
	{TKN_TYPE_SECURE_ELEM,	"S",	STR},	/* Secure Element		*/
	{TKN_TYPE_CLOUD_BASED,	"H",	STR},	/* Host Card Emulation		*/
	{NULL}
};

ctxprivate map_tbl_t map_rspcode[] =
{
	/* ctx, falcon */
	{"000",	"A",	STR},	/* Approve			*/
	{"006",	"B",	STR},	/* Partial approval		*/
	{"001",	"I",	STR},	/* Approve with positive ID	*/
	{"108",	"R",	STR},	/* Refer			*/
	{"0..",	"A",	REGEX},	/* Default approve		*/
	{"1..",	"D",	REGEX},	/* Decline			*/
	{"2..",	"P",	REGEX},	/* Pick up card			*/
	{"...",	"D",	REGEX},	/* Default decline		*/
	{NULL}
};

ctxprivate map_tbl_t map_txncode[] =
{
	/* ctx, falcon */
	{"00",	"M",	STR},	/* Purchase			*/
	{"01",	"C",	STR},	/* Cash				*/
	{"09",	"B",	STR},	/* Purchase with cash back	*/
	{"21",	"J",	STR},	/* ATM deposit			*/
	{"30",	"I",	STR},	/* ATM available funds inquiry	*/
	{"31",	"I",	STR},	/* ATM available funds inquiry	*/
	{"96",	"A",	STR},	/* Address verification only	*/
	{"..",	"O",	REGEX},	/* Other		 	*/
	{NULL}
};

ctxprivate map_tbl_t map_cvvres[] =
{
	/* ctx, falcon */
	{"N",	"I",	STR},	/* Invalid (VERCHK_BAD)		*/
	{"n",	"I",	STR},	/* Invalid (VERCHK_NET_BAD)	*/
	{"Y",	"V",	STR},	/* Valid (VERCHK_OK)		*/
	{"y",	"V",	STR},	/* Valid (VERCHK_NET_OK)	*/
	{".",	" ",	REGEX},	/* Not checked		 	*/
	{NULL}
};

ctxprivate map_tbl_t map_poscdim[] =
{
	/* ctx, falcon */
	{"E",	"C",	STR},	/* Contactless magnetic stripe (MCDIM_CLMAG)		*/
	{"G",	"C",	STR},	/* Contactless magnetic stripe (MCDIM_CLMAG_EMV)	*/
	{"S",	"E",	STR},	/* E-commerce (MCDIM_3DSECMRCH)				*/
	{"T",	"E",	STR},	/* E-commerce (MCDIM_3DSEC)				*/
	{"V",	"E",	STR},	/* E-commerce (MCDIM_ESEC)				*/
	{"A",	"E",	STR},	/* E-commerce (MCDIM_3DSECMRCHC)			*/
	{"B",	"E",	STR},	/* E-commerce (MCDIM_3DSECC)				*/
	{"C",	"E",	STR},	/* E-commerce (MCDIM_ESECC)				*/
	{"1",	"K",	STR},	/* Keyed (manual) (MCDIM_MAN)				*/
	{"2",	"S",	STR},	/* Magnetic stripe read (MCDIM_MAG)			*/
	{"8",	"T",	STR},	/* Chip read (MCDIM_ICC9)				*/
	{"9",	"U",	STR},	/* Magnetic stripe read (MCDIM_MAGCVV)			*/
	{"5",	"V",	STR},	/* Chip read (MCDIM_ICC)				*/
	{"6",	"K",	STR},	/* Manually Keyed (MCDIM_KEY)				*/
	{"7",	"D",	STR},	/* Contactless ICC (MCDIM_CLICC)			*/
	{"Y",	"V",	STR},	/* Chip read (MCDIM_ICCSR)				*/
	{"3",	"X",	STR},	/* Entry using bar code reader (MCDIM_BAR)		*/
	{"4",	"Y",	STR},	/* Entry using optical character reader (MCDIM_OCR)	*/
	{".",	" ",	REGEX},	/* Unknown/other (Any other value)	 		*/
	{NULL}
};

/* Response to an AVS (Address Verification Service) request */
ctxprivate map_tbl_t map_avsrsp[] =
{
	/* ctx, falcon */
	{"A",	"A",	STR},	/* AVS address only (AVSRSP_AM_PNM)		*/
	{"N",	"N",	STR},	/* AVS no match (AVSRSP_NOTMATCH)		*/
	{"R",	"R",	STR},	/* AVS system unavailable (AVSRSP_RETRY)	*/
	{"S",	"I",	STR},	/* AVS not supported (AVSRSP_NOTCHK)		*/
	{"W",	"W",	STR},	/* AVS ZIP nine (AVSRSP_PM_ANM)			*/
	{"X",	"Y",	STR},	/* AVS exact (AVSRSP_MATCH)			*/
	{".",	" ",	REGEX},	/* Unknown/not provided			 	*/
	{NULL}
};

/* Terminal entry capability */
ctxprivate map_tbl_t map_poschic[] =
{
	/* ctx, falcon */
	{"5",	"C",	STR},	/* Chip card read capability (MCHIC_ICC)				*/
	{"7",	"D",	STR},	/* Contactless chip card read capability (MCHIC_CLICC_UNK)		*/
	{"A",	"D",	STR},	/* Contactless chip card read capability (MCHIC_CLICC_ICC)		*/
	{"B",	"D",	STR},	/* Contactless chip card read capability (MCHIC_CLICC_NOICC)		*/
	{"6",	"K",	STR},	/* Key entry only (card present) (MCHIC_KEY)				*/
	{"2",	"M",	STR},	/* Magnetic stripe read capability (MCHIC_MAG)				*/
	{"9",	"M",	STR},	/* Magnetic stripe read capability (MCHIC_MAGCVV)			*/
	{"8",	"N",	STR},	/* Contactless magnetic stripe read capability (MCHIC_CLMAG_UNK)	*/
	{"C",	"N",	STR},	/* Contactless magnetic stripe read capability (MCHIC_CLMAG_ICC)	*/
	{"D",	"N",	STR},	/* Contactless magnetic stripe read capability (MCHIC_CLMAG_NOICC)	*/
	{".",	"O",	REGEX},	/* Other				 				*/
	{NULL}
};

/* Auth reversal reason */
ctxprivate map_tbl_t map_reasoncode[] =
{
	/* ctx, falcon */
	{"4021", "3",	STR},	/* System timeout (MRC_TOUT_WAIT_RSP)			*/
	{"4005", "4",	STR},	/* Terminal error/misdispense (MRC_REV_ORG_AMT)		*/
	{"4020", "5",	STR},	/* Terminal communication error (MRC_REV_INV_RSP)	*/
	{"4007", "6",	STR},	/* Terminal error (MRC_REV_NOT_CMP)			*/
	{"4006", "7",	STR},	/* Late or unsolicited response (MRC_REV_TOO_LATE)	*/
	{"4000", "8",	STR},	/* Reversal/Customer cancel (MRC_REV_CUST_CNX)		*/
	{"4362", "9",	STR},	/* Suspected fraud (MRC_REV_SUS_FRAUD)			*/
	{"....", " ",	REGEX},	/* POS transaction or reversal reason unknown		*/
	{NULL}
};

/* Authorization request cryptogram is valid? */
ctxprivate map_tbl_t map_carc[] =
{
	/* ctx, falcon */
	{"2",	"I",	STR},	/* Invalid (CARC_PASSED)	*/
	{"1",	"V",	STR},	/* Valid (CARC_FAILED)		*/
	{".",	" ",	REGEX},	/* Unknown/not provided		*/
	{NULL}
};

ctxprivate fld_cond_t Brejexpdate =	/* Reject reason - Invalid expiry date */
	{ COND_FBOOL, NULL, "I_REJREASON == 700 || I_REJREASON == 708 || I_REJREASON == 705 || I_REJREASON == 723" };

ctxprivate fld_cond_t Brejexpmismatch =	/* Reject reason - Expiration date mismatch */
	{ COND_FBOOL, NULL, "I_REJREASON == 708 || I_REJREASON == 705 || I_REJREASON == 723" };

ctxprivate fld_cond_t Brejcvv =		/* Reject reason - CVV/CVC validation failed */
	{ COND_FBOOL, NULL, "I_REJREASON == 602 || I_REJREASON == 698 || I_REJREASON == 703" };

ctxprivate fld_cond_t Brejbadatc =	/* Reject reason - ATC backwards or duplicate */
	{ COND_FBOOL, NULL, "I_REJREASON == 757" };

ctxprivate fld_cond_t Badencrdexp =	/* Account closed or Expired card */
	{ COND_FBOOL, NULL, "C_ACTIONCODE == '1' && C_RSPCODE == '01'" };

ctxprivate fld_cond_t Badeninsuff =	/* Insufficient funds */
	{ COND_FBOOL, NULL, "C_ACTIONCODE == '1' && C_RSPCODE == '16'" };

ctxprivate fld_cond_t Badenexclim =	/* Exceeds withdrawal amount limit */
	{ COND_FBOOL, NULL, "C_ACTIONCODE == '1' && C_RSPCODE == '21'" };

ctxprivate fld_cond_t Badenexcfrq =	/* Exceeds withdrawal frequency limit */
	{ COND_FBOOL, NULL, "C_ACTIONCODE == '1' && C_RSPCODE == '23'" };

ctxprivate fld_cond_t Badennoacty =	/* No such account (checking, savings, or credit) */
	{ COND_FBOOL, NULL, "C_ACTIONCODE == '1' && C_RSPCODE == '14'" };

ctxprivate fld_cond_t Badenpinreq =	/* Incorrect PIN */
	{ COND_FBOOL, NULL, "C_ACTIONCODE == '1' && C_RSPCODE == '17'" };

ctxprivate fld_cond_t Bisfraud =	/* Suspected fraud or lost/stolen card */
	{ COND_FBOOL, NULL, "C_ACTIONCODE == '2' && (C_RSPCODE == '09' || C_RSPCODE == '08' || C_RSPCODE == '02')" };

ctxprivate fld_cond_t Bcirrus =		/* Cirrus */
	{ COND_FBOOL, NULL, "I_SCHEME=='CIRR'" };

/* PIN verification conditions */
ctxprivate fld_cond_t Bpinveri = 	/* Invalid */
	{ COND_FBOOL, NULL, "(I_PINCHKRES == 'N') || (I_PINCHKRES == 'n')" };
ctxprivate fld_cond_t Bpinverv = 	/* Valid */
	{ COND_FBOOL, NULL, "(I_PINCHKRES == 'Y') || (I_PINCHKRES == 'y')" };
ctxprivate fld_cond_t Bpinverx = 	/* PIN entered but not verified or verification results unknown */
	{ COND_FBOOL, NULL, "(I_PINCHKRES == 'U') || (I_PINCHKRES == 'u') || ((C_POSCHAM == '1') && !(I_PINCHKRES))" };

/* The authorization indicator */
ctxprivate fld_cond_t Becomm = 		/* ecommerce / SecureCode */
	{ COND_FBOOL, NULL, "E_ECOMM_IND %% '21.'" };
ctxprivate fld_cond_t Bmasterpass = 	/* processed through Masterpass */
	{ COND_FBOOL, NULL, "E_ECOMM_IND %% '22.'" };
ctxprivate fld_cond_t Bdsrp =		/* Digital Secure Remote Payment (DSRP) with UCAF data */
	{ COND_FBOOL, NULL, "E_ECOMM_IND %% '24[123]'" };

/* Presence indicator for Card Identification Number */
ctxprivate fld_cond_t Bcvv2pres =	/* CVV2 present */
	{ COND_FBOOL, NULL, "I_CRDCVC" };
ctxprivate fld_cond_t Bcvv2syserr =	/* CVV2 system error (VERCHK_SYSERR or VERCHK_NET_SYSERR) */
	{ COND_FBOOL, NULL, "I_CVV2RES == 'S' || I_CVV2RES == 's'" };

/* Response to a CVV2 request */
ctxprivate fld_cond_t Bcvv2encerr =	/* CVV2 encryption error (VERCHK_ENCERR or VERCHK_NET_ENCERR) */
	{ COND_FBOOL, NULL, "I_CVV2RES == 'E' || I_CVV2RES == 'e'" };
ctxprivate fld_cond_t Bcvv2match =	/* CVV2 match (VERCHK_OK or VERCHK_NET_OK) */
	{ COND_FBOOL, NULL, "I_CVV2RES == 'Y' || I_CVV2RES == 'y'" };
ctxprivate fld_cond_t Bcvv2notmatch =	/* CVV2 no match (VERCHK_BAD or VERCHK_NET_BAD) */
	{ COND_FBOOL, NULL, "I_CVV2RES == 'N' || I_CVV2RES == 'n'" };
ctxprivate fld_cond_t Bcvv2notperf =	/* CVV2 not processed (VERCHK_NOTP or VERCHK_NET_NOTP) */
	{ COND_FBOOL, NULL, "I_CVV2RES == 'P' || I_CVV2RES == 'p'" };

ctxprivate fld_cond_t Bisattend =	/* Attended terminal (MOE_ONP_ATT or MOE_OFP_ATT) */
	{ COND_FBOOL, NULL, "C_POSOE == '1' || C_POSOE == '3'" };

ctxprivate fld_cond_t Bcmpladv =	/* Completion advice */
	{ COND_FBOOL, NULL, "C_MSGCLS == '2' && C_MSGFN == '2' && C_AUTHLIFE > 0" };

ctxprivate fld_cond_t Biscof =         /* BPD Style Card-On-File transaction */
	{ COND_FBOOL, NULL, "C_POSCDIM == 'H' || C_POSCC_89 == 8" };
	
ctxprivate wallet_list_t  M_wallet_list;
ctxprivate int M_gettokenadd = 0;
ctxprivate int M_desfalconmsc = 0;

/*---------------------------Prototypes---------------------------------*/
ctxpublic void FALCON2CVIN(  TPSVCINFO *p_svc );
ctxpublic void FALCON2CVOUT( TPSVCINFO *p_svc );

ctxprivate int rex_group(char *rx, char *str, regmatch_t *garray, int max_groups);
ctxprivate char* regmatch_group_get(char *str, regmatch_t *regmatch, int group);

ctxprivate int	build_hdr( FBFR *p_fb, char *p_buf, long *p_hdrlen );
ctxprivate int	update_hdr_set_datalen( FBFR *p_fb, char *p_buf, long datalen );
ctxprivate int	parse_hdr( char *p_natmsg, FBFR *p_fb, long *p_hdrlen, long *p_datalen );
ctxprivate int	build_data( FBFR *p_fb, char *p_buf, long *p_len );
ctxprivate int	parse_data( char *p_natmsg, long len, FBFR *p_fb );
ctxprivate void falcon_msg_dump(char *p_buf, Falcon_msglayout_t *p_msglayout);
ctxprivate char* dbg_falcon_mask_field(const char *field, char *data, size_t len);
ctxprivate int posEntryModeFallback( FBFR *p_fb, char chic, char cdim, char crdtype, char *res );
ctxprivate ctxbool lookupInList(char *str, char* list);
ctxprivate int cardAipInd(FBFR *p_fb, FLDID fld, char *ind);
ctxprivate int get_datetimexmit_with_gmtoffset(FBFR *p_fb, long *p_date, long *p_time, double gmtoffset);
ctxprivate int timestamp2datetime_with_gmtoffset(char *timestamp, long *p_date, long *p_time, double gmtoffset);

ctxprivate char *maskPAN(const char *, size_t len);
ctxprivate char *maskExpiry(const char *, size_t len);
ctxprivate char *maskBIN(const char *, size_t len);

ctxprivate int FFworkflow(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFrecordType(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFdataSpecificationVersion(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFclientIdFromHeader(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFrecordCreationDate(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFrecordCreationTime(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFrecordCreationMilliseconds(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFgmtOffset(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcustomerIdFromHeader(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcustomerAcctNumber(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFexternalTransactionId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFpan(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFauthPostFlag(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcardSeqNum(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcardExpireDate(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFexpandedBIN(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtokenizationIndicator(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtokenExpirationDate(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcavvResult(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtransactionDate(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtransactionTime(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtransactionAmount(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtransactionCurrencyCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtransactionCurrencyConversionRate(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFauthDecisionCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtransactionType(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFmcc(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFmerchantPostalCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFmerchantCountryCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFpinVerifyCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcvvVerifyCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFposEntryMode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFpostDate(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFidMethod(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFexternalScore1(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcustomerPresent(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFatmOwner(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtokenRequestorId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFmerchantName(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFmerchantCity(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFmerchantState(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFrealtimeRequest(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtokenId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcardAipStatic(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcardAipDynamic(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcardAipVerify(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcardAipRisk(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcardAipIssuerAuthentication(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcardAipCombined(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcardDailyLimitCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFavailableBalance(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFatmProcessingCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcvv2Present(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcvv2Response(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFavsResponse(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtransactionCategory(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFacquirerId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFacquirerCountry(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFterminalId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFterminalType(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFterminalEntryCapability(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFposConditionCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFatmNetworkId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFauthExpireDateVerify(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFauthResponseCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFauthReversalReason(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFauthCardIssuer(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFterminalVerificationResults(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcardVerificationResults(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcryptogramValid(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFatcCard(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtokenAssuranceLevel(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcavvKeyIndicator(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFeciIndicator(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFprocessorAuthReasonCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFstandinAdvice(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFmerchantId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcashbackAmount(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFavsRequest(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcvrOfflinePinVerificationPerformed(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcvrOfflinePinVerificationFailed(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcvrPinTryLimitExceeded(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFposUnattended(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFposOffPremises(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFposCardCapture(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFauthId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);

ctxprivate int FFuserData02(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);

ctxprivate int build_hdr_prov( FBFR *p_fb, char *p_buf, long *p_hdrlen, char subtxncode[]);
ctxprivate int build_data_prov( FBFR *p_fb, char *p_buf, long *p_len, char subtxncode[]);
ctxprivate int FFexternalTransactionId_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtransactionType_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFcardExpireDate_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtokenizationIndicator_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtokenRequestorId_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData03_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData05_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData06_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData07_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserIndicator02_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserIndicator04_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserIndicator05_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserIndicator06_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserIndicator07_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtransactionAmount_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFsegmentId4_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtransactionCurrencyConversionRate_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFmerchantId_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFacquirerCountry_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFacquirerId_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFmcc_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFtransactionCurrencyCode_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFmerchantName_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFposEntryMode_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFposUnattended_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFexternalScore1_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFterminalType_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFmerchantCountryCode_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);

ctxprivate int FFtokenId_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);

ctxprivate int FFrecordType_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFdataSpecificationVersion_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFvalidity_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFentityType_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFextSource_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFnotificationName_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFnotificationStatus_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFscore1_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFscore2_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFscore3_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData01_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData02_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData03_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData04_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData05_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData06_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData07_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData08_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData09_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData10_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData12_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData14_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData15_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData16_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData17_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData18_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData27_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData28_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData29_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFuserData30_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);
ctxprivate int FFexternalTransactionId_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx);

ctxprivate int	getTokenInfo( FBFR *p_fb, char *tokenrequestorid );

ctxprivate int getTknRequestorIdList(void);
ctxprivate int completeListRequestorId(char **p_walletListComp, char **p_tknreqidListComp, char wallet[], char resultmsc[]);
ctxprivate int buildTknrequestoridTag(char walletitem[], char tag[]);
ctxprivate int findListTknRequestorid(char tokenrequestorid[], char wallet[]);

ctxprivate Falcon_msglayout_t DBTRAN25_layout[] =
{
	/* fieldname				pos	len	p_fb2rawfn */
	{ "workflow",				0,	16,	FFworkflow },	/* (position: 1-16) */
	{ "recordType",				16,	8,	FFrecordType },	/* (position: 17-24) */
	{ "dataSpecificationVersion",		24,	5,	FFdataSpecificationVersion },	/* (position: 25-29) */
	{ "clientIdFromHeader",			29,	16,	FFclientIdFromHeader },	/* (position: 30-45) */
	{ "recordCreationDate",			45,	8,	FFrecordCreationDate },	/* (position: 46-53) */
	{ "recordCreationTime",			53,	6,	FFrecordCreationTime },	/* (position: 54-59) */
	{ "recordCreationMilliseconds",		59,	3,	FFrecordCreationMilliseconds },	/* (position: 60-62) */
	{ "gmtOffset",				62,	6,	FFgmtOffset },	/* (position: 63-68) */
	{ "customerIdFromHeader",		68,	20,	FFcustomerIdFromHeader },	/* (position: 69-88) */
	{ "customerAcctNumber",			88,	40,	FFcustomerAcctNumber },	/* (position: 89-128) */
	{ "externalTransactionId",		128,	32,	FFexternalTransactionId },	/* (position: 129-160) */
	{ "pan",				160,	19,	FFpan },	/* (position: 161-179) */
	{ "authPostFlag",			179,	1,	FFauthPostFlag },	/* (position: 180) */
	{ "cardPostalCode",			180,	9,	NULL },	/* (position: 181-189) */
	{ "cardSeqNum",				189,	3,	FFcardSeqNum },	/* (position: 190-192) */
	{ "openDate",				192,	8,	NULL },	/* (position: 193-200) */
	{ "plasticIssueDate",			200,	8,	NULL },	/* (position: 201-208) */
	{ "plasticIssueType",			208,	1,	NULL },	/* (position: 209) */
	{ "acctExpireDate",			209,	8,	NULL },	/* (position: 210-217) */
	{ "cardExpireDate",			217,	8,	FFcardExpireDate },	/* (position: 218-225 */
	{ "expandedBIN",			225,	10,	FFexpandedBIN },	/* (position: 226-235) */
	{ "dailyCashLimit",			235,	10,	NULL },	/* (position: 236-245) */
	{ "tokenizationIndicator",		245,	1,	FFtokenizationIndicator },	/* (position: 246) */
	{ "tokenExpirationDate",		246,	8,	FFtokenExpirationDate },	/* (position: 247-254) */
	{ "consumerAuthenticationScore",	254,	3,	NULL },	/* (position: 255-257) TODO: ??? */
	{ "incomeOrCashBack",			257,	10,	NULL },	/* (position: 258-267) */
	{ "cavvResult",				267,	1,	FFcavvResult },	/* (position: 268) */
	{ "peerGrouping",			268,	1,	NULL },	/* (position: 269) */
	{ "transactionDate",			269,	8,	FFtransactionDate },	/* (position: 270-277) */
	{ "transactionTime",			277,	6,	FFtransactionTime },	/* (position: 278-283) */
	{ "transactionAmount",			283,	13,	FFtransactionAmount },	/* (position: 284-296) */
	{ "transactionCurrencyCode",		296,	3,	FFtransactionCurrencyCode },	/* (position: 297-299) */
	{ "transactionCurrencyConversionRate",	299,	13,	FFtransactionCurrencyConversionRate },	/* (position: 300-312) */
	{ "authDecisionCode",			312,	1,	FFauthDecisionCode },	/* (position: 313) */
	{ "transactionType",			313,	1,	FFtransactionType },	/* (position: 314) */
	{ "mcc",				314,	4,	FFmcc },	/* (position: 315-318)*/
	{ "merchantPostalCode",			318,	9,	FFmerchantPostalCode },	/* (position: 319-327) */
	{ "merchantCountryCode",		327,	3,	FFmerchantCountryCode },	/* (position: 328-330) */
	{ "pinVerifyCode",			330,	1,	FFpinVerifyCode },	/* (position: 331) */
	{ "cvvVerifyCode",			331,	1,	FFcvvVerifyCode },	/* (position: 332) */
	{ "posEntryMode",			332,	1,	FFposEntryMode },	/* (position: 333) */
	{ "postDate",				333,	8,	FFpostDate },	/* (position: 334-341) */
	{ "authPostMiscIndicator",		341,	1,	NULL },	/* (position: 342) */
	{ "mismatchIndicator",			342,	1,	NULL },	/* (position: 343) */
	{ "caseCreationIndicator",		343,	1,	NULL },	/* (position: 344) */
	{ "userIndicator01",			344,	1,	NULL },	/* (position: 345) */
	{ "userIndicator02",			345,	1,	NULL },	/* (position: 346) */
	{ "userData01",				346,	10,	NULL },	/* (position: 347-356) */
	{ "userData02",				356,	10,	FFuserData02 },	/* (position: 357-366) NEW */
	{ "onUsMerchantId",			366,	10,	NULL },	/* (position: 367-376) */
	{ "merchantDataProvided",		376,	1,	NULL },	/* (position: 377) */
	{ "idMethod",				377,	1,	FFidMethod },	/* (position: 378) */
	{ "externalScore1",			378,	4,	FFexternalScore1 },	/* (position: 379-382) */
	{ "externalScore2",			382,	4,	NULL },	/* (position: 383-386) */
	{ "externalScore3",			386,	4,	NULL },	/* (position: 387-390) */
	{ "customerPresent",			390,	1,	FFcustomerPresent },	/* (position: 391) */
	{ "atmOwner",				391,	1,	FFatmOwner },	/* (position: 392) */
	{ "randomDigits",			392,	2,	NULL },	/* (position: 393-394) */
	{ "portfolio",				394,	14,	NULL },	/* (position: 395-408) */
	{ "tokenRequestorId",			408,	14,	FFtokenRequestorId },	/* (position: 409-422) */
	{ "acquirerBin",			422,	6,	NULL },	/* (position: 423-428) */
	{ "merchantName",			428,	40,	FFmerchantName },	/* (position: 429-468) */
	{ "merchantCity",			468,	30,	FFmerchantCity },	/* (position: 469-498) */
	{ "merchantState",			498,	3,	FFmerchantState },	/* (position: 499-501) */
	{ "caseSuppressionIndicator",		501,	1,	NULL },	/* (position: 502) */
	{ "userIndicator03",			502,	5,	NULL },	/* (position: 503-507) */
	{ "userIndicator04",			507,	5,	NULL },	/* (position: 508-512) */
	{ "userData03",				512,	15,	NULL },	/* (position: 513-527) */
	{ "userData04",				527,	20,	NULL },	/* (position: 528-547) */
	{ "userData05",				547,	40,	NULL },	/* (position: 548-587) */
	{ "realtimeRequest",			587,	1,	FFrealtimeRequest },	/* (position: 588) */
	{ "padResponse",			588,	1,	NULL },	/* (position: 589 */
	{ "padActionExpireDate",		589,	8,	NULL },	/* (position: 590-597) */
	{ "tokenId",				597,	19,	FFtokenId },	/* (position: 598-616) */
	{ "cardAipStatic",			616,	1,	FFcardAipStatic },	/* (position: 617) */
	{ "cardAipDynamic",			617,	1,	FFcardAipDynamic },	/* (position: 618) */
	{ "RESERVED_01",			618,	1,	NULL },	/* (position: 619) */
	{ "cardAipVerify",			619,	1,	FFcardAipVerify },	/* (position: 620) */
	{ "cardAipRisk",			620,	1,	FFcardAipRisk },	/* (position: 621) */
	{ "cardAipIssuerAuthentication",	621,	1,	FFcardAipIssuerAuthentication },	/* (position: 622) */
	{ "cardAipCombined",			622,	1,	FFcardAipCombined },	/* (position: 623) */
	{ "cardDailyLimitCode",			623,	1,	FFcardDailyLimitCode },	/* (position: 624) */
	{ "availableBalance",			624,	13,	FFavailableBalance },	/* (position: 625-637) */
	{ "availableDailyCashLimit",		637,	13,	NULL },	/* (position: 638-650) */
	{ "availableDailyMerchandiseLimit",	650,	13,	NULL },	/* (position: 651-663) */
	{ "atmHostMcc",				663,	4,	NULL },	/* (position: 664-667) */
	{ "atmProcessingCode",			667,	6,	FFatmProcessingCode },	/* (position: 668-673) */
	{ "atmCameraPresent",			673,	1,	NULL },	/* (position: 674) */
	{ "cardPinType",			674,	1,	NULL },	/* (position: 675) */
	{ "cardMediaType",			675,	1,	NULL },	/* (position: 676) */
	{ "cvv2Present",			676,	1,	FFcvv2Present },	/* (position: 677) */
	{ "cvv2Response",			677,	1,	FFcvv2Response },	/* (position: 678) */
	{ "avsResponse",			678,	1,	FFavsResponse },	/* (position: 679) */
	{ "transactionCategory",		679,	1,	FFtransactionCategory },	/* (position: 680) */
	{ "acquirerId",				680,	12,	FFacquirerId },	/* (position: 681-692) */
	{ "acquirerCountry",			692,	3,	FFacquirerCountry },	/* (position: 693-695) */
	{ "terminalId",				695,	16,	FFterminalId },	/* (position: 696-711) */
	{ "terminalType",			711,	1,	FFterminalType },	/* (position: 712) */
	{ "terminalEntryCapability",		712,	1,	FFterminalEntryCapability },	/* (position: 713) */
	{ "posConditionCode",			713,	2,	FFposConditionCode },	/* (position: 714-715) */
	{ "atmNetworkId",			715,	1,	FFatmNetworkId },	/* (position: 716) */
	{ "RESERVED_02",			716,	1,	NULL },	/* (position: 717) */
	{ "authExpireDateVerify",		717,	1,	FFauthExpireDateVerify },	/* (position: 718) */
	{ "authSecondaryVerify",		718,	1,	NULL },	/* (position: 719) */
	{ "authBeneficiary",			719,	1,	NULL }, /* (position: 720) */
	{ "authResponseCode",			720,	1,	FFauthResponseCode },	/* (position: 721) */
	{ "authReversalReason",			721,	1,	FFauthReversalReason },	/* (position: 722) */
	{ "authCardIssuer",			722,	1,	FFauthCardIssuer },	/* (position: 723) */
	{ "terminalVerificationResults",	723,	10,	FFterminalVerificationResults },	/* (position: 724-733) */
	{ "cardVerificationResults",		733,	10,	FFcardVerificationResults },	/* (position: 734-743) */
	{ "cryptogramValid",			743,	1,	FFcryptogramValid },	/* (position: 744) */
	{ "atcCard",				744,	5,	FFatcCard },	/* (position: 745-749) */
	{ "atcHost",				749,	5,	NULL },	/* (position: 750-754) */
	{ "RESERVED_03",			754,	2,	NULL },	/* (position: 755-756) */
	{ "tokenAssuranceLevel",		756,	2,	FFtokenAssuranceLevel },	/* (position: 757-758) */
	{ "secondFactorAuthCode",		758,	2,	NULL },	/* (position: 759-760) */
	{ "cavvKeyIndicator",			760,	2,	FFcavvKeyIndicator },	/* (position: 761-762) */
	{ "recurringAuthExpireDate",		762,	8,	NULL },	/* (position: 763-770) */
	{ "linkedAcctType",			770,	1,	NULL },	/* (position: 771) */
	{ "cardIncentive",			771,	1,	NULL },	/* (position: 772) */
	{ "eciIndicator",			772,	2,	FFeciIndicator },	/* (position: 773-774) */
	{ "cardPinSetDate",			774,	8,	NULL },	/* (position: 775-782) */
	{ "processorAuthReasonCode",		782,	5,	FFprocessorAuthReasonCode },	/* (position: 783-787) */
	{ "standinAdvice",			787,	1,	FFstandinAdvice },	/* (position: 788) */
	{ "merchantId",				788,	16,	FFmerchantId },	/* (position: 789-804) */
	{ "cardOrder",				804,	1,	NULL },	/* (position: 805) */
	{ "cashbackAmount",			805,	13,	FFcashbackAmount },	/* (position: 806-818) */
	{ "userData06",				818,	13,	NULL },	/* (position: 819-831) */
	{ "userData07",				831,	40,	NULL },	/* (position: 832-871) */
	{ "paymentInstrumentId",		871,	30,	NULL },	/* (position: 872-901) */
	{ "avsRequest",				901,	1,	FFavsRequest },	/* (position: 902) */
	{ "cvrOfflinePinVerificationPerformed",	902,	1,	FFcvrOfflinePinVerificationPerformed },	/* (position: 903) */
	{ "cvrOfflinePinVerificationFailed",	903,	1,	FFcvrOfflinePinVerificationFailed },	/* (position: 904) */
	{ "cvrPinTryLimitExceeded",		904,	1,	FFcvrPinTryLimitExceeded },	/* (position: 905) */
	{ "posUnattended",			905,	1,	FFposUnattended },	/* (position: 906) */
	{ "posOffPremises",			906,	1,	FFposOffPremises },	/* (position: 907) */
	{ "posCardCapture",			907,	1,	FFposCardCapture },	/* (position: 908) */
	{ "posSecurity",			908,	1,	NULL },	/* (position: 909) */
	{ "authId",				909,	6,	FFauthId },	/* (position: 910-915) */
	{ "userData08",				915,	10,	NULL },	/* (position: 916-925) */
	{ "userData09",				925,	10,	NULL },	/* (position: 926-935) */
	{ "userIndicator05",			935,	1,	NULL },	/* (position: 936) */
	{ "userIndicator06",			936,	1,	NULL },	/* (position: 937) */
	{ "userIndicator07",			937,	5,	NULL },	/* (position: 938-942) */
	{ "userIndicator08",			942,	5,	NULL },	/* (position: 943-947) */
	{ "modelControl1",			947,	1,	NULL },	/* (position: 948) */
	{ "modelControl2",			948,	1,	NULL },	/* (position: 949) */
	{ "modelControl3",			949,	1,	NULL },	/* (position: 950) */
	{ "modelControl4",			950,	1,	NULL },	/* (position: 951) */
	{ "RESERVED_04",			951,	3,	NULL },	/* (position: 952-954) */
	{ "segmentId1",				954,	6,	NULL },	/* (position: 955-960) */
	{ "segmentId2",				960,	6,	NULL },	/* (position: 961-966) */
	{ "segmentId3",				966,	6,	NULL },	/* (position: 967-972) */
	{ "segmentId4",				972,	6,	NULL },	/* (position: 973-978) */
	{NULL}
};

ctxprivate masked_fields_t M_masked_flds[] =
{
	{ "pan",		maskPAN },
	{ "cardExpireDate",	maskExpiry },
	{ "expandedBIN",	maskBIN },
	{NULL}
};

ctxprivate Falcon_msglayout_t DBTRAN25_layout_prov[] =
{
	/* fieldname				pos	len	p_fb2rawfn */
	{ "workflow",				0,	16,	FFworkflow },	/* (position: 1-16) */
	{ "recordType",				16,	8,	FFrecordType },	/* (position: 17-24) */
	{ "dataSpecificationVersion",		24,	5,	FFdataSpecificationVersion },	/* (position: 25-29) */
	{ "clientIdFromHeader",			29,	16,	FFclientIdFromHeader },	/* (position: 30-45) */
	{ "recordCreationDate",			45,	8,	FFrecordCreationDate },	/* (position: 46-53) */
	{ "recordCreationTime",			53,	6,	FFrecordCreationTime },	/* (position: 54-59) */
	{ "recordCreationMilliseconds",		59,	3,	FFrecordCreationMilliseconds },	/* (position: 60-62) */
	{ "gmtOffset",				62,	6,	FFgmtOffset },	/* (position: 63-68) */
	{ "customerIdFromHeader",		68,	20,	FFcustomerIdFromHeader },	/* (position: 69-88) */
	{ "customerAcctNumber",			88,	40,	FFcustomerAcctNumber },	/* (position: 89-128) */
	{ "externalTransactionId",		128,	32,	FFexternalTransactionId_prov },	/* (position: 129-160) PROV */
	{ "pan",				160,	19,	FFpan },	/* (position: 161-179) */
	{ "authPostFlag",			179,	1,	FFauthPostFlag },	/* (position: 180) */
	{ "cardPostalCode",			180,	9,	NULL },	/* (position: 181-189) */
	{ "cardSeqNum",				189,	3,	FFcardSeqNum },	/* (position: 190-192) */
	{ "openDate",				192,	8,	NULL },	/* (position: 193-200) */
	{ "plasticIssueDate",			200,	8,	NULL },	/* (position: 201-208) */
	{ "plasticIssueType",			208,	1,	NULL },	/* (position: 209) */
	{ "acctExpireDate",			209,	8,	NULL },	/* (position: 210-217) */
	{ "cardExpireDate",			217,	8,	FFcardExpireDate_prov },	/* (position: 218-225 PROV */
	{ "expandedBIN",			225,	10,	FFexpandedBIN },	/* (position: 226-235) */
	{ "dailyCashLimit",			235,	10,	NULL },	/* (position: 236-245) */
	{ "tokenizationIndicator",		245,	1,	FFtokenizationIndicator_prov },	/* (position: 246) PROV */
	{ "tokenExpirationDate",		246,	8,	FFtokenExpirationDate },	/* (position: 247-254) */
	{ "consumerAuthenticationScore",	254,	3,	NULL },	/* (position: 255-257) TODO: ??? */
	{ "incomeOrCashBack",			257,	10,	NULL },	/* (position: 258-267) */
	{ "cavvResult",				267,	1,	FFcavvResult },	/* (position: 268) */
	{ "peerGrouping",			268,	1,	NULL },	/* (position: 269) */
	{ "transactionDate",			269,	8,	FFtransactionDate },	/* (position: 270-277) */
	{ "transactionTime",			277,	6,	FFtransactionTime },	/* (position: 278-283) */
	{ "transactionAmount",			283,	13,	FFtransactionAmount_prov },	/* (position: 284-296) PROV */
	{ "transactionCurrencyCode",		296,	3,	FFtransactionCurrencyCode_prov },	/* (position: 297-299) PROV */
	{ "transactionCurrencyConversionRate",	299,	13,	FFtransactionCurrencyConversionRate_prov },	/* (position: 300-312) PROV */
	{ "authDecisionCode",			312,	1,	FFauthDecisionCode },	/* (position: 313) */
	{ "transactionType",			313,	1,	FFtransactionType_prov },	/* (position: 314) PROV */
	{ "mcc",				314,	4,	FFmcc_prov },	/* (position: 315-318) PROV */
	{ "merchantPostalCode",			318,	9,	FFmerchantPostalCode },	/* (position: 319-327) */
	{ "merchantCountryCode",		327,	3,	FFmerchantCountryCode_prov },	/* (position: 328-330) PROV */
	{ "pinVerifyCode",			330,	1,	FFpinVerifyCode },	/* (position: 331) */
	{ "cvvVerifyCode",			331,	1,	FFcvvVerifyCode },	/* (position: 332) */
	{ "posEntryMode",			332,	1,	FFposEntryMode_prov },	/* (position: 333) PROV */
	{ "postDate",				333,	8,	FFpostDate },	/* (position: 334-341) */
	{ "authPostMiscIndicator",		341,	1,	NULL },	/* (position: 342) */
	{ "mismatchIndicator",			342,	1,	NULL },	/* (position: 343) */
	{ "caseCreationIndicator",		343,	1,	NULL },	/* (position: 344) */
	{ "userIndicator01",			344,	1,	NULL },	/* (position: 345) */
	{ "userIndicator02",			345,	1,	FFuserIndicator02_prov },	/* (position: 346) PROV */
	{ "userData01",				346,	10,	NULL },	/* (position: 347-356) */
	{ "userData02",				356,	10,	NULL },	/* (position: 357-366) */
	{ "onUsMerchantId",			366,	10,	NULL },	/* (position: 367-376) */
	{ "merchantDataProvided",		376,	1,	NULL },	/* (position: 377) */
	{ "idMethod",				377,	1,	FFidMethod },	/* (position: 378) */
	{ "externalScore1",			378,	4,	FFexternalScore1_prov },	/* (position: 379-382) PROV */
	{ "externalScore2",			382,	4,	NULL },	/* (position: 383-386) */
	{ "externalScore3",			386,	4,	NULL },	/* (position: 387-390) */
	{ "customerPresent",			390,	1,	FFcustomerPresent },	/* (position: 391) */
	{ "atmOwner",				391,	1,	FFatmOwner },	/* (position: 392) */
	{ "randomDigits",			392,	2,	NULL },	/* (position: 393-394) */
	{ "portfolio",				394,	14,	NULL },	/* (position: 395-408) */
	{ "tokenRequestorId",			408,	14,	FFtokenRequestorId_prov },	/* (position: 409-422) PROV */
	{ "acquirerBin",			422,	6,	NULL },	/* (position: 423-428) */
	{ "merchantName",			428,	40,	FFmerchantName_prov },	/* (position: 429-468) PROV */
	{ "merchantCity",			468,	30,	NULL },	/* (position: 469-498) PROV */
	{ "merchantState",			498,	3,	NULL },	/* (position: 499-501) PROV */
	{ "caseSuppressionIndicator",		501,	1,	NULL },	/* (position: 502) */
	{ "userIndicator03",			502,	5,	NULL },	/* (position: 503-507) */
	{ "userIndicator04",			507,	5,	FFuserIndicator04_prov },	/* (position: 508-512) PROV */
	{ "userData03",				512,	15,	FFuserData03_prov },	/* (position: 513-527) PROV */
	{ "userData04",				527,	20,	NULL },	/* (position: 528-547) */
	{ "userData05",				547,	40,	FFuserData05_prov },	/* (position: 548-587) PROV */
	{ "realtimeRequest",			587,	1,	FFrealtimeRequest },	/* (position: 588) */
	{ "padResponse",			588,	1,	NULL },	/* (position: 589 */
	{ "padActionExpireDate",		589,	8,	NULL },	/* (position: 590-597) */
	{ "tokenId",				597,	19,	FFtokenId_prov },	/* (position: 598-616) PROV */
	{ "cardAipStatic",			616,	1,	FFcardAipStatic },	/* (position: 617) */
	{ "cardAipDynamic",			617,	1,	FFcardAipDynamic },	/* (position: 618) */
	{ "RESERVED_01",			618,	1,	NULL },	/* (position: 619) */
	{ "cardAipVerify",			619,	1,	FFcardAipVerify },	/* (position: 620) */
	{ "cardAipRisk",			620,	1,	FFcardAipRisk },	/* (position: 621) */
	{ "cardAipIssuerAuthentication",	621,	1,	FFcardAipIssuerAuthentication },	/* (position: 622) */
	{ "cardAipCombined",			622,	1,	FFcardAipCombined },	/* (position: 623) */
	{ "cardDailyLimitCode",			623,	1,	FFcardDailyLimitCode },	/* (position: 624) */
	{ "availableBalance",			624,	13,	FFavailableBalance },	/* (position: 625-637) */
	{ "availableDailyCashLimit",		637,	13,	NULL },	/* (position: 638-650) */
	{ "availableDailyMerchandiseLimit",	650,	13,	NULL },	/* (position: 651-663) */
	{ "atmHostMcc",				663,	4,	NULL },	/* (position: 664-667) */
	{ "atmProcessingCode",			667,	6,	FFatmProcessingCode },	/* (position: 668-673) */
	{ "atmCameraPresent",			673,	1,	NULL },	/* (position: 674) */
	{ "cardPinType",			674,	1,	NULL },	/* (position: 675) */
	{ "cardMediaType",			675,	1,	NULL },	/* (position: 676) */
	{ "cvv2Present",			676,	1,	FFcvv2Present },	/* (position: 677) */
	{ "cvv2Response",			677,	1,	FFcvv2Response },	/* (position: 678) */
	{ "avsResponse",			678,	1,	FFavsResponse },	/* (position: 679) */
	{ "transactionCategory",		679,	1,	FFtransactionCategory },	/* (position: 680) */
	{ "acquirerId",				680,	12,	FFacquirerId_prov },	/* (position: 681-692) PROV */
	{ "acquirerCountry",			692,	3,	FFacquirerCountry_prov },	/* (position: 693-695) PROV */
	{ "terminalId",				695,	16,	FFterminalId },	/* (position: 696-711) */
	{ "terminalType",			711,	1,	FFterminalType_prov },	/* (position: 712) PROV */
	{ "terminalEntryCapability",		712,	1,	FFterminalEntryCapability },	/* (position: 713) */
	{ "posConditionCode",			713,	2,	FFposConditionCode },	/* (position: 714-715) */
	{ "atmNetworkId",			715,	1,	FFatmNetworkId },	/* (position: 716) */
	{ "RESERVED_02",			716,	1,	NULL },	/* (position: 717) */
	{ "authExpireDateVerify",		717,	1,	FFauthExpireDateVerify },	/* (position: 718) */
	{ "authSecondaryVerify",		718,	1,	NULL },	/* (position: 719) */
	{ "authBeneficiary",			719,	1,	NULL }, /* (position: 720) */
	{ "authResponseCode",			720,	1,	FFauthResponseCode },	/* (position: 721) */
	{ "authReversalReason",			721,	1,	FFauthReversalReason },	/* (position: 722) */
	{ "authCardIssuer",			722,	1,	FFauthCardIssuer },	/* (position: 723) */
	{ "terminalVerificationResults",	723,	10,	FFterminalVerificationResults },	/* (position: 724-733) */
	{ "cardVerificationResults",		733,	10,	FFcardVerificationResults },	/* (position: 734-743) */
	{ "cryptogramValid",			743,	1,	FFcryptogramValid },	/* (position: 744) */
	{ "atcCard",				744,	5,	FFatcCard },	/* (position: 745-749) */
	{ "atcHost",				749,	5,	NULL },	/* (position: 750-754) */
	{ "RESERVED_03",			754,	2,	NULL },	/* (position: 755-756) */
	{ "tokenAssuranceLevel",		756,	2,	FFtokenAssuranceLevel },	/* (position: 757-758) */
	{ "secondFactorAuthCode",		758,	2,	NULL },	/* (position: 759-760) */
	{ "cavvKeyIndicator",			760,	2,	FFcavvKeyIndicator },	/* (position: 761-762) */
	{ "recurringAuthExpireDate",		762,	8,	NULL },	/* (position: 763-770) */
	{ "linkedAcctType",			770,	1,	NULL },	/* (position: 771) */
	{ "cardIncentive",			771,	1,	NULL },	/* (position: 772) */
	{ "eciIndicator",			772,	2,	FFeciIndicator },	/* (position: 773-774) */
	{ "cardPinSetDate",			774,	8,	NULL },	/* (position: 775-782) */
	{ "processorAuthReasonCode",		782,	5,	FFprocessorAuthReasonCode },	/* (position: 783-787) */
	{ "standinAdvice",			787,	1,	FFstandinAdvice },	/* (position: 788) */
	{ "merchantId",				788,	16,	FFmerchantId_prov },	/* (position: 789-804) PROV */
	{ "cardOrder",				804,	1,	NULL },	/* (position: 805) */
	{ "cashbackAmount",			805,	13,	FFcashbackAmount },	/* (position: 806-818) */
	{ "userData06",				818,	13,	FFuserData06_prov },	/* (position: 819-831) PROV */
	{ "userData07",				831,	40,	FFuserData07_prov },	/* (position: 832-871) PROV */
	{ "paymentInstrumentId",		871,	30,	NULL },	/* (position: 872-901) */
	{ "avsRequest",				901,	1,	FFavsRequest },	/* (position: 902) */
	{ "cvrOfflinePinVerificationPerformed",	902,	1,	FFcvrOfflinePinVerificationPerformed },	/* (position: 903) */
	{ "cvrOfflinePinVerificationFailed",	903,	1,	FFcvrOfflinePinVerificationFailed },	/* (position: 904) */
	{ "cvrPinTryLimitExceeded",		904,	1,	FFcvrPinTryLimitExceeded },	/* (position: 905) */
	{ "posUnattended",			905,	1,	FFposUnattended_prov },	/* (position: 906) PROV */
	{ "posOffPremises",			906,	1,	FFposOffPremises },	/* (position: 907) */
	{ "posCardCapture",			907,	1,	FFposCardCapture },	/* (position: 908) */
	{ "posSecurity",			908,	1,	NULL },	/* (position: 909) */
	{ "authId",				909,	6,	FFauthId },	/* (position: 910-915) */
	{ "userData08",				915,	10,	NULL },	/* (position: 916-925) */
	{ "userData09",				925,	10,	NULL },	/* (position: 926-935) */
	{ "userIndicator05",			935,	1,	FFuserIndicator05_prov },	/* (position: 936) PROV */
	{ "userIndicator06",			936,	1,	FFuserIndicator06_prov },	/* (position: 937) PROV */
	{ "userIndicator07",			937,	5,	FFuserIndicator07_prov },	/* (position: 938-942) PROV */
	{ "userIndicator08",			942,	5,	NULL },	/* (position: 943-947) */
	{ "modelControl1",			947,	1,	NULL },	/* (position: 948) */
	{ "modelControl2",			948,	1,	NULL },	/* (position: 949) */
	{ "modelControl3",			949,	1,	NULL },	/* (position: 950) */
	{ "modelControl4",			950,	1,	NULL },	/* (position: 951) */
	{ "RESERVED_04",			951,	3,	NULL },	/* (position: 952-954) */
	{ "segmentId1",				954,	6,	NULL },	/* (position: 955-960) */
	{ "segmentId2",				960,	6,	NULL },	/* (position: 961-966) */
	{ "segmentId3",				966,	6,	NULL },	/* (position: 967-972) */
	{ "segmentId4",				972,	6,	FFsegmentId4_prov },	/* (position: 973-978) */
	{NULL}
};


ctxprivate Falcon_msglayout_t DBTRAN25_layout_prov_otp[] =
{
	/* fieldname				pos	len	p_fb2rawfn */
	{ "workflow",				0,	16,	FFworkflow },	/* (position: 1-16) */
	{ "recordType",				16,	8,	FFrecordType_prov_otp },	/* (position: 17-24) PROV */
	{ "dataSpecificationVersion",		24,	5,	FFdataSpecificationVersion_prov_otp },	/* (position: 25-29) PROV */
	{ "clientIdFromHeader",			29,	16,	FFclientIdFromHeader },	/* (position: 30-45) */
	{ "recordCreationDate",			45,	8,	FFrecordCreationDate },	/* (position: 46-53) */
	{ "recordCreationTime",			53,	6,	FFrecordCreationTime },	/* (position: 54-59) */
	{ "recordCreationMilliseconds",		59,	3,	FFrecordCreationMilliseconds },	/* (position: 60-62) */
	{ "gmtOffset",				62,	6,	FFgmtOffset },	/* (position: 63-68) */
	{ "customerIdFromHeader",		68,	20,	FFcustomerIdFromHeader },	/* (position: 69-88) */
	{ "customerAcctNumber",			88,	40,	FFcustomerAcctNumber },	/* (position: 89-128) */
	{ "externalTransactionId",		128,	32,	FFexternalTransactionId_prov_otp },	/* (position: 129-160) PROV */
	{ "serviceId",					160,	19,	FFpan },	/* (position: 161-179) PROV */
	{ "transactionDate",			179,	8,	FFtransactionDate },	/* (position: 180-187) */
	{ "transactionTime",			187,	6,	FFtransactionTime },	/* (position: 188-193) */
	{ "validity",					193,	4,	FFvalidity_prov_otp },	/* (position: 194-197) PROV */
	{ "entityType",					197,	4,	FFentityType_prov_otp },	/* (position: 198-201) PROV */
	{ "extSource",					201,	48,	FFextSource_prov_otp },	/* (position: 202-249) PROV */
	{ "notificationName",			249,	48,	FFnotificationName_prov_otp },	/* (position: 250-297) PROV */
	{ "notificationStatus",			297,	10,	FFnotificationStatus_prov_otp },	/* (position: 298-307) PROV */
	{ "score1",						307,	4,	FFscore1_prov_otp },	/* (position: 308-311) PROV */
	{ "score2",						311,	4,	FFscore2_prov_otp },	/* (position: 312-315) PROV */
	{ "score3",						315,	4,	FFscore3_prov_otp },	/* (position: 316-319) PROV */
	{ "userData01",					319,	4,	FFuserData01_prov_otp },	/* (position: 320-323) PROV */
	{ "userData02",					323,	4,	FFuserData02_prov_otp },	/* (position: 324-327) PROV */
	{ "userData03",					327,	4,	FFuserData03_prov_otp },	/* (position: 328-331) PROV */
	{ "userData04",					331,	4,	FFuserData04_prov_otp },	/* (position: 332-335) PROV */
	{ "userData05",					335,	4,	FFuserData05_prov_otp },	/* (position: 336-339) PROV */
	{ "userData06",					339,	8,	FFuserData06_prov_otp },	/* (position: 340-347) PROV */
	{ "userData07",					347,	8,	FFuserData07_prov_otp },	/* (position: 348-355) PROV */
	{ "userData08",					355,	8,	FFuserData08_prov_otp },	/* (position: 356-363) PROV */
	{ "userData09",					363,	8,	FFuserData09_prov_otp },	/* (position: 364-371) PROV */
	{ "userData10",					371,	8,	FFuserData10_prov_otp },	/* (position: 372-379) PROV */
	{ "userData11",					379,	8,	NULL },	/* (position: 380-387) PROV */
	{ "userData12",					387,	16,	FFuserData12_prov_otp },	/* (position: 388-403) PROV */
	{ "userData13",					403,	16,	NULL },	/* (position: 404-419) PROV */
	{ "userData14",					419,	16,	FFuserData14_prov_otp },	/* (position: 420-435) PROV */
	{ "userData15",					435,	16,	FFuserData15_prov_otp },	/* (position: 436-451) PROV */
	{ "userData16",					451,	16,	FFuserData16_prov_otp },	/* (position: 452-467) PROV */
	{ "userData17",					467,	16,	FFuserData17_prov_otp },	/* (position: 468-483) PROV */
	{ "userData18",					483,	32,	FFuserData18_prov_otp },	/* (position: 484-515) PROV */
	{ "userData19",					515,	32,	NULL },	/* (position: 516-547) PROV */
	{ "userData20",					547,	32,	NULL },	/* (position: 548-579) PROV */
	{ "userData21",					579,	32,	NULL },	/* (position: 580-611) PROV */
	{ "userData22",					611,	32,	NULL },	/* (position: 612-643) PROV */
	{ "userData23",					643,	32,	NULL },	/* (position: 644-675) PROV */
	{ "userData24",					675,	32,	NULL },	/* (position: 676-707) PROV */
	{ "userData25",					707,	32,	NULL },	/* (position: 708-739) PROV */
	{ "userData26",					739,	32,	NULL },	/* (position: 740-771) PROV */
	{ "userData27",					771,	32,	FFuserData27_prov_otp },	/* (position: 772-803) PROV */
	{ "userData28",					803,	64,	FFuserData28_prov_otp },	/* (position: 804-867) PROV */
	{ "userData29",					867,	64,	FFuserData29_prov_otp },	/* (position: 868-931) PROV */
	{ "userData30",					931,	64,	FFuserData30_prov_otp },	/* (position: 932-995) PROV */
	{ "userData31",					995,	64,	NULL },	/* (position: 996-1059) */
	{ "userData32",					1059,	64,	NULL },	/* (position: 1060-1123) */
	{ "userData33",					1123,	255,	NULL },	/* (position: 1124-1378) */
	{ "userData34",					1378,	255,	NULL },	/* (position: 1379-1633) */
	{NULL}
};

/*------------------------------------------------------------------------
 *
 * Function	: falcon2_init
 *
 * Purpose	: Init FALCON2
 *
 * Parameters	: 
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxpublic int falcon2_init(char *subsect)
{
	int ret = SUCCEED;
	char *tagnm = "FALCON2";
	FILE *fp = NULL;
	
	ctxprivate cfp_parm cfp[] =
	{
		{"CODE2RSP",		parm_string, sizeof(M_code2rsp),	TRUE,	M_code2rsp,		0},
		{"EH_SOURCE",		parm_string, sizeof(M_ehsource),	FALSE,	M_ehsource,		0},
		{"EH_DEST",		parm_string, sizeof(M_ehdest),		FALSE,	M_ehdest,		0},
		{"WORKFLOW",		parm_string, sizeof(M_workflow),	FALSE,	M_workflow,		0},
		{"CLIENTID",		parm_string, sizeof(M_clientid),	FALSE,	M_clientid,		0},
		{"ONUSAFES",		parm_string, sizeof(M_onusafes),	FALSE,	M_onusafes,		0},
		{"UNIONAFES",		parm_string, sizeof(M_unionafes),	FALSE,	M_unionafes,		0},
		{"GMTOFFSET",		parm_short,  0,				FALSE,	(char *)&M_gmtoffset,	0},
		{"GETTOKENADD", 	parm_int, 	0, 			TRUE,	(void *)&M_gettokenadd, 0},
		{"DESFALCONMSC", 	parm_int, 	0, 			TRUE,	(void *)&M_desfalconmsc, 0},
		{"WALLETLIST", 		parm_string, sizeof(M_tmp_wallet_list), TRUE,(void *)&M_tmp_wallet_list, 0},
		{0}
	};

	fp = cfp_open();
	if (fp)
	{
		ret = cfp_parse_nodebug(fp, cfp, tagnm, subsect);
		if (SUCCEED != ret)
		{
			DBG_PRINTF((dbg_syserr, "falcon2_init failed [%s/%s] (%s)",
				tagnm, subsect, cfp_errparm()));
		}
		else if (SUCCEED != rex_comp(&M_re_code2rsp, "^(.+):(.+)$", 0))
		{
			DBG_PRINTF((dbg_syserr, "compile REGEX failed"));
			ret = FAIL;
		}
		fclose(fp);
	}
	else
	{
		DBG_PRINTF((dbg_syserr, "cfp_open failed"));
		ret = FAIL;
	}
	
	if (SUCCEED == ret) 
	{
		DBG_PRINTF((dbg_progdetail, "getTknRequestorIdList..."));
		
		ret = getTknRequestorIdList();
	}
	
	if (SUCCEED == ret)
	{
		DBG_PRINTF((dbg_progdetail, "sizeListWalletCompleted[%d]", M_wallet_list.sizeListWalletCompleted));
		
		for (int i=0; i<M_wallet_list.sizeListWalletCompleted; i++)
		{
			DBG_PRINTF((dbg_progdetail, "id[%d] wallet[%s] tknrequestorid[%s]", i, M_wallet_list.listWalletCompleted[i], M_wallet_list.listTknRequestorId[i]));
		}
	}
	
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  getTknRequestorId
 *
 * Purpose	:  Get TknRequestorId from MSC
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int getTknRequestorIdList(void)
{
	int ret = SUCCEED;
		
	char mscresult[200];
	char tknrequestorid_tag[30];
		
	char * p_walletListComp;
	char * p_tknreqidListComp;
	
	
	if (SUCCEED == ret) 
	{
		memset(M_wallet_list.wallet_list, 0, sizeof(M_wallet_list.wallet_list));
		memset(M_wallet_list.wallet_list_toktmp, 0, sizeof(M_wallet_list.wallet_list_toktmp));

		memset(M_wallet_list.wallet_list_toktmp_completed, 0, sizeof(M_wallet_list.wallet_list_toktmp_completed));
		memset(M_wallet_list.tknrequestorid_toktmp, 0, sizeof(M_wallet_list.tknrequestorid_toktmp));	
		
		M_wallet_list.sizeListWallet = 0;
		M_wallet_list.sizeListWalletCompleted = 0;
		
		p_walletListComp = M_wallet_list.wallet_list_toktmp_completed;
		p_tknreqidListComp = M_wallet_list.tknrequestorid_toktmp;
		
		strcpy(M_wallet_list.wallet_list, M_tmp_wallet_list);
		strcpy(M_wallet_list.wallet_list_toktmp, M_tmp_wallet_list);
		
		DBG_PRINTF((dbg_progdetail, "M_tmp_wallet_list[%s]", M_tmp_wallet_list));
		
		if (!is_empty_str(M_wallet_list.wallet_list_toktmp)) {
			
			DBG_PRINTF((dbg_progdetail, "Building list of tknrequestorid wallet checks..."));
			
			M_wallet_list.listWallet[0] = strtok(M_wallet_list.wallet_list_toktmp, "|");
			M_wallet_list.sizeListWallet = 1;
			
			DBG_PRINTF((dbg_progdetail, "   [%s] added to list of checks", M_wallet_list.listWallet[0]));

			while ( ( SUCCEED == ret ) && (NULL != (M_wallet_list.listWallet[M_wallet_list.sizeListWallet] = strtok(NULL, "|")) ) )
			{
				DBG_PRINTF((dbg_progdetail, "   [%s] added to list of checks", M_wallet_list.listWallet[M_wallet_list.sizeListWallet]));
				
				M_wallet_list.sizeListWallet++;
			}				
		}		
	}
	
	if (SUCCEED == ret)
	{
		DBG_PRINTF((dbg_progdetail, "sizeListWallet[%d]", M_wallet_list.sizeListWallet));
		
		M_wallet_list.sizeListWalletCompleted = 0;
		
		for (int i=0; i<M_wallet_list.sizeListWallet; i++)
		{
			DBG_PRINTF((dbg_progdetail, "id[%d] wallet[%s]", i, M_wallet_list.listWallet[i]));
			
			ret = buildTknrequestoridTag(M_wallet_list.listWallet[i], tknrequestorid_tag);
					
			DBG_PRINTF((dbg_progdetail, "   [%s] added to list of checks -> tag [%s]", M_wallet_list.listWallet[i], tknrequestorid_tag));
			
			memset(mscresult, 0, sizeof(mscresult));
			ret = get_msc_string(tknrequestorid_tag, 1, mscresult, sizeof(mscresult), FALSE);
			
			if (SUCCEED != ret)
			{
				DBG_PRINTF((dbg_fatal, "Can not get MSC record for tag [%s]", tknrequestorid_tag));
				ret = FAIL;
			}
			else
			{
				DBG_PRINTF((dbg_progdetail, "      --> ind[%d] mscresult for tag [%s]", i, mscresult));
				
				ret = completeListRequestorId(&p_walletListComp, &p_tknreqidListComp, M_wallet_list.listWallet[i], mscresult);
				
			}	
		
		}
	}
	
	return ret;
		
}



/*------------------------------------------------------------------------------*/
/**
 * @brief	completeListRequestorId function
 *
 * @retval	SUCCEED		success
 *
 * @remarks	
 */
/*----------------------------------------------------------------------------*/
ctxprivate int completeListRequestorId(char **p_walletListComp, char **p_tknreqidListComp, char wallet[], char resultmsc[])
{
	int ret = SUCCEED;
	
	char * p;
	
	int lenwallet = 0;
	int lenp = 0;
	
	p = strtok(resultmsc, "|");
	
	DBG_PRINTF((dbg_progdetail, "p[%s] len[%d]", p, strlen(p)));
	
	strcpy(*p_walletListComp, wallet);
	strcpy(*p_tknreqidListComp, p);
	
	M_wallet_list.listWalletCompleted[M_wallet_list.sizeListWalletCompleted] = *p_walletListComp;
	M_wallet_list.listTknRequestorId[M_wallet_list.sizeListWalletCompleted] = *p_tknreqidListComp;
	
	lenwallet = strlen(wallet) + 1;
	lenp = strlen(p) + 1;
		
	*p_walletListComp = *p_walletListComp + lenwallet;
	*p_tknreqidListComp = *p_tknreqidListComp + lenp;
	
	M_wallet_list.sizeListWalletCompleted++;
	
	while ( NULL != (p = strtok(NULL, "|") ))
	{
		DBG_PRINTF((dbg_progdetail, "p[%s] len[%d]", p, strlen(p)));
		
		strcpy(*p_walletListComp, wallet);
		strcpy(*p_tknreqidListComp, p);
		
		M_wallet_list.listWalletCompleted[M_wallet_list.sizeListWalletCompleted] = *p_walletListComp;
		M_wallet_list.listTknRequestorId[M_wallet_list.sizeListWalletCompleted] = *p_tknreqidListComp;
		
		lenwallet = strlen(wallet) + 1;
		lenp = strlen(p) + 1;
		
		*p_walletListComp = *p_walletListComp + lenwallet;
		*p_tknreqidListComp = *p_tknreqidListComp + lenp;
		
		M_wallet_list.sizeListWalletCompleted++;
	}
	
	return ret;
}

/*------------------------------------------------------------------------------*/
/**
 * @brief	buildTknrequestoridTag function
 *
 * @retval	SUCCEED		success
 *
 * @remarks	
 */
/*----------------------------------------------------------------------------*/
ctxprivate int buildTknrequestoridTag(char walletitem[], char tag[])
{
	int ret = SUCCEED;
	
	char wallet3[10];
	
	memset(tag, 0, sizeof(tag));
	strcpy(tag, "TKNREQID_");	

	if (strlen(walletitem) > 3) 
	{
		strncpy(wallet3, walletitem, 3);
		wallet3[3] = 0;
		strcat(tag, wallet3);
	}
	else 
	{
		strcat(tag, walletitem);
	}
	
	return ret;
}


/*------------------------------------------------------------------------*/
/**
 * @brief	  Looking for walletlist for tokenrequestorid list
 *
 * @param[in,out] 
 *
 * @retval	  SUCCEED   ok
 * @retval	  FAIL      error
 */
 /*------------------------------------------------------------------------*/
ctxprivate int findListTknRequestorid(char tokenrequestorid[], char wallet[]) 
{
	int i=0;
	
	int ret = SUCCEED;
	memset(wallet, 0, sizeof(wallet));
	
	DBG_PRINTF((dbg_progdetail, "findListTknRequestorid - looking for wallet for tokenrequestorid list [%s] - lenlist[%d]...", tokenrequestorid, M_wallet_list.sizeListWalletCompleted));
	
	while (i < M_wallet_list.sizeListWalletCompleted) 
	{
		DBG_PRINTF((dbg_progdetail, "    -> [%d] M_wallet_list.listWallet[%s] M_wallet_list.listWalletCompleted[%s]", i, M_wallet_list.listTknRequestorId[i], M_wallet_list.listWalletCompleted[i]));
		
		if (strcmp(M_wallet_list.listTknRequestorId[i], tokenrequestorid)==0) 
		{
			strncpy(wallet, M_wallet_list.listWalletCompleted[i], 3);
			wallet[3] = 0;
			
			DBG_PRINTF((dbg_progdetail, "Record found"));
			
			return SUCCEED;
		}
		i++;
	}
	
	return FAIL;
}

/*------------------------------------------------------------------------
 *
 * Function	:  falcon2_uninit
 *
 * Purpose	:  Free the allocated memory
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic void	falcon2_uninit(void)
{
	if (NULL != M_re_code2rsp)
	{
		rex_free(M_re_code2rsp);
	}
}

/*------------------------------------------------------------------------------
 *
 * Function	:  falconcode2rsp
 *
 * Purpose	:  Map decision code against the list of CODE2RSP map
 *
 * Parameters	:  code (in) Falcon decision code
 * 		   actioncode (out) Action code
 * 		   rspcode (out) Response code
 *
 * Returns	:  action/response code
 *
 *----------------------------------------------------------------------------*/
ctxpublic char* falconcode2rsp(char* code, char* actioncode, char* rspcode)
{
	char *item;
	char *group;
	char *result = NULL;
	regmatch_t regmatch[2+1];	/* regex match + 2 group */
	char tmp_code2rsp[CTX_FILENAME_MAX+1] = {EOS};

	if (NULL == code || EOS == code[0])
	{
		return NULL;
	}

	strscpy(tmp_code2rsp, M_code2rsp);
	item = strtok(tmp_code2rsp,",");
	while(NULL != item)
	{
		if (SUCCEED == rex_group(M_re_code2rsp, item, regmatch, 2+1))
		{
			group = regmatch_group_get(item, regmatch, 1);
			if (0 == strcmp(stp_both(group), code))
			{
				result = regmatch_group_get(item, regmatch, 2);
			}
			if (NULL != result)
			{
				stp_both(result);
				if (NULL != actioncode)
				{
					*actioncode = result[0];
				}
				if (NULL != rspcode)
				{
					slstrncpy(rspcode, ++result, 2);
				}
				break;
			}
		}

		item = strtok(NULL, ",");
	}

	return result;
}

/*------------------------------------------------------------------------
*
* Function	: FALCON2CVIN
*
* Purpose	: FALCON2 converts message from native to FML
*
* Parameters	: p_svc - normal TP call
*
* Returns	: void
*
* Comments	: This is callable as a Tuxedo service
*
*----------------------------------------------------------------------*/
ctxpublic void FALCON2CVIN(TPSVCINFO *p_svc )
{
	int		ret = SUCCEED;
	static FBFR	*p_fb;

	DBG_TIMER(dbg_proginfo, "FALCON2CVIN START");

	p_fb = MAKE_BIGGER(p_svc->data);

	ret = falcon2cvin(p_fb);

	DBG_TIMER(dbg_proginfo, "FALCON2CVIN END");
	DBG_FLUSH();

	ntp_return(SUCCEED == ret
		   ? TPSUCCESS
		   : TPFAIL,
		   0L,
		   (char *)p_fb,
		   0L,
		   0L);
}

/*------------------------------------------------------------------------
*
* Function	: falcon2cvin
*
* Purpose	: Convert FALCON2 input
*
* Parameters	: p_fb - fielded buffer to convert
*
* Returns	: SUCCEED / FAIL
*
* Comments	: This is callable as a linked function
*
*------------------------------------------------------------------------*/
ctxpublic int falcon2cvin(FBFR *p_fb)
{
	int 		ret = SUCCEED;
	char 		*p_natmsg;
	char		*p_tmpbuf = NULL;
	FLDLEN		natmsglen;
	long		hdrlen = FALCON2_HEADER_LEN;
	long 		datalen = 0;

	if (NULL == (p_natmsg = F_find(p_fb, I_NATMSG, 0, &natmsglen ) ) )
		ret = FAIL;
	else if (!(p_tmpbuf = malloc((size_t)natmsglen)))
	{
		DBG_PRINTF((dbg_syserr, "malloc failed"));
		ret = FAIL;
	}
	else
	{
		memcpy(p_tmpbuf, p_natmsg, (size_t)natmsglen);
		if (DBG_GETLEV() > dbg_proginfo)
		{
			DBG_DUMP(dbg_progdetail, "IN MSG", p_tmpbuf, natmsglen);		
		}
	}
	
	if (SUCCEED == ret)
	{
		ret = parse_hdr(p_tmpbuf, p_fb, &hdrlen, &datalen);
	}

	if (SUCCEED == ret)
	{
		ret = parse_data(p_tmpbuf + hdrlen, datalen, p_fb);
	}

	if (FAIL != ret)
 		DBG_DUMPFB(dbg_progdetail,"FALCON2CVIN returns:", p_fb);
	else			
 		DBG_PRINTF((dbg_syserr, "FALCON2CVIN convert failed"));

	free(p_tmpbuf);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FALCON2CVOUT
 *
 * Purpose	: FALCON2 converts message from FML to native
 *
 * Parameters	: p_svc - normal TP call
 *
 * Returns	: void
 *
 * Comments	:
 *
 *----------------------------------------------------------------------*/
ctxpublic void FALCON2CVOUT(TPSVCINFO *p_svc)
{
 	int	 	ret = SUCCEED;
 	static FBFR	*p_fb;

	DBG_TIMER(dbg_proginfo, "FALCON2CVOUT START");
 	p_fb = MAKE_BIGGER(p_svc->data);

	ret = falcon2cvout(p_fb);

	DBG_TIMER(dbg_proginfo, "FALCON2CVOUT END");
 	DBG_FLUSH();
	ntp_return(SUCCEED == ret ? TPSUCCESS : TPFAIL,
		   0L,
		   (char *)p_fb,
		   0L,
		   0L);
}

/*------------------------------------------------------------------------
 *
 * Function	: falcon2cvout
 *
 * Purpose	: Convert FALCON2 output
 *
 * Parameters	: p_fb - fielded buffer to convert
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: This is callable as a linked function
 *
 *------------------------------------------------------------------------*/
ctxpublic int falcon2cvout(FBFR *p_fb)
{
	char	buf[BUF_SIZE];
 	long	datalen = 0;
	long	hdrlen = FALCON2_HEADER_LEN;
	
	char subtxncode[20];
	
 	int	ret = SUCCEED;

	memset(buf, ' ', sizeof(buf));

	DBG_DUMPFB(dbg_progdetail,"FALCON2CVOUT converting:", p_fb);
	
	if  (F_pres(p_fb, D_WALLETPROVIDERID, 0))
	{
		DBG_PRINTF((dbg_progdetail,"converting provisioning..."));
		
		if (SUCCEED != CF_get(p_fb, N_SUB_TXNCODE, 0, (char *)&subtxncode, 0, FLD_STRING))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get N_SUB_TXNCODE"));
			ret = FAIL;
		}
		else
		{
			DBG_PRINTF((dbg_syserr,"N_SUB_TXNCODE[%s]", subtxncode));

			if ( SUCCEED != (ret=build_hdr_prov(p_fb, buf, &hdrlen, subtxncode)) )
			{
				DBG_PRINTF((dbg_syserr,"build_hdr failed"));
			}
			
			/*
			if ( SUCCEED == ret && (FBISAUTH(p_fb) || FBISFIN(p_fb) || FBISREVCB(p_fb)) )
			{
			*/
				DBG_PRINTF((dbg_progdetail,"calling build_data_prov ..."));
				
				if ( SUCCEED != (ret=build_data_prov(p_fb, buf + hdrlen, &datalen, subtxncode)) )
				{
					DBG_PRINTF((dbg_syserr,"build_data_prov failed"));
				}
				else
				{
					ret = update_hdr_set_datalen(p_fb, buf, datalen+FALCON2_HEADER_RESERVED_1_LEN);
				}
			/*
			}
			*/
			
			if (SUCCEED == ret && DBG_GETLEV() > dbg_proginfo)
			{
				DBG_DUMP(dbg_progdetail,"Msg header:", buf, (size_t)hdrlen);
				DBG_DUMP(dbg_progdetail,"Full message:", buf, (size_t)datalen + hdrlen);
			}

			if (SUCCEED == ret && FAIL == F_chg(p_fb, I_NATMSG, 0, buf, (FLDLEN)datalen + hdrlen))
			{
				DBG_PRINTF((dbg_syserr,"Failed add I_NATMSG"));
				ret = FAIL;
			}
		}

	}
	else 
	{
		if ( SUCCEED != (ret=build_hdr(p_fb, buf, &hdrlen)) )
		{
			DBG_PRINTF((dbg_syserr,"build_hdr failed"));
		}

		if ( SUCCEED == ret && (FBISAUTH(p_fb) || FBISFIN(p_fb) || FBISREVCB(p_fb)) )
		{
			DBG_PRINTF((dbg_progdetail,"calling build_data..."));
			
			if ( SUCCEED != (ret=build_data(p_fb, buf + hdrlen, &datalen)) )
			{
				DBG_PRINTF((dbg_syserr,"build_data failed"));
			}
			else
			{
				ret = update_hdr_set_datalen(p_fb, buf, datalen+FALCON2_HEADER_RESERVED_1_LEN);
			}
		}
		
		if (SUCCEED == ret && DBG_GETLEV() > dbg_proginfo)
		{
			DBG_DUMP(dbg_progdetail,"Msg header:", buf, (size_t)hdrlen);
			DBG_DUMP(dbg_progdetail,"Full message:", buf, (size_t)datalen + hdrlen);
		}

		if (SUCCEED == ret && FAIL == F_chg(p_fb, I_NATMSG, 0, buf, (FLDLEN)datalen + hdrlen))
		{
			DBG_PRINTF((dbg_syserr,"Failed add I_NATMSG"));
			ret = FAIL;
		}
	}

	return ret;
}

/*------------------------------------------------------------------------------
 *
 * Function	:  regmatch_group_get
 *
 * Purpose	:  Get matching string from regex match groups
 *
 * Parameters	:  str (in) source string
 * 		   regmatch (in) regex match groups
 * 		   group (in) regex match group number
 *
 * Returns	:  regex matched group
 *
 *----------------------------------------------------------------------------*/
ctxprivate char* regmatch_group_get(char *str, regmatch_t *regmatch, int group)
{
	static	char buf[64];
	int len;

	if (regmatch[group].rm_so == (size_t)-1)
	{
		return NULL;  /* No more groups */
	}

	len = (int)(regmatch[group].rm_eo - regmatch[group].rm_so);
	strnscpy(buf, str+regmatch[group].rm_so, (size_t)len);
	buf[len] = EOS;

	return buf;
}

/*------------------------------------------------------------------------------
 *
 * Function	:  rex_group
 *
 * Purpose	:  Execute regular expression match on compiled regex
 * 		   and find results by groups
 *
 * Parameters	:  rx (in) compiled regex
 * 		   str (in) source string
 * 		   garray (out) regex match groups
 * 		   max_groups (in) maximum number of matches by group
 *
 * Returns	:  SUCCEED/FAIL
 *
 *----------------------------------------------------------------------------*/
ctxprivate int rex_group(char *rx, char *str, regmatch_t *garray, int max_groups)
{
	int ret = SUCCEED;
	int  status;

	status = regexec((regex_t*)rx , str, (size_t) max_groups, garray, 0);

	if (status != 0)
	{
		ret = FAIL;
	}
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: build_hdr
 *
 * Purpose	: Build Header
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  p_buf (out) - location for build header
 * 		  p_hdrlen (out) - header length
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int build_hdr(FBFR *p_fb, char *p_buf, long *p_hdrlen)
{
 	int	ret = SUCCEED;
	char	tmpbuf[16];
	long	hdrlen = 0;
	char 	*ext_hdr;		/* Extended header */
	long	ext_hdr_len = 0;	/* Length of extended-header */
	long	reserved_len = 0;
	
	char	trancode[9+1] = {EOS};
	long	stan;
	long	txmit;
	short	fdsaction;
	
	ext_hdr = p_buf+FALCON2_HEADER_LEN-1+M_filler_size;

	/* EH_APP_DATA_LEN (position: 1-8) */
	memcpy(p_buf, "00000000", 8);
		
	/* EH_EXT_HDR_LEN (position: 9-12) */
	memcpy(p_buf+8, "0000", 4); /* Zero indicates that no extended header is present (default) */
	if (FBISAUTH(p_fb) || FBISFIN(p_fb) || FBISREVCB(p_fb))
	{
		if (SUCCEED != CF_get(p_fb, C_STAN, 0, (char *)&stan, 0L, FLD_LONG)
		    || SUCCEED != CF_get(p_fb, C_TIMEXMIT, 0, (char *)&txmit, 0L, FLD_LONG))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get C_STAN/C_TIMEXMIT from FB"));
			ret |= FAIL;
		}

		if (SUCCEED == ret)
		{
			sprintf(tmpbuf, "%06ld%06ld", stan, txmit);
			ext_hdr_len = strlen(tmpbuf);
			/* EH_EXT_HDR (position: 53-n; n=53+EH_EXT_HDR_LEN) */
			memcpy(ext_hdr, tmpbuf, (size_t)ext_hdr_len);
			
			sprintf(tmpbuf, "%04ld", ext_hdr_len);
			/* EH_EXT_HDR_LEN (position: 9-12) */
			memcpy(p_buf+8, tmpbuf, 4);
		}

		reserved_len = FALCON2_HEADER_RESERVED_1_LEN;
	}

	/* if this is scoring request */
	if (F_pres(p_fb, I_FDSACTION, 0))
	{
		ret |= F_get(p_fb, I_FDSACTION, 0, (char *)&fdsaction, 0L);

		if (FDSSEND_REQUEST == fdsaction)
		{
			strscpy(trancode, TRAN_CODE_PRIORITY_SCORING_REQ);
		}
		else
		{
			strscpy(trancode, TRAN_CODE_SCORING_STANDARD_REQ);
		}
	}
	/* if this is network management request/response */
	else if (SUCCEED != F_get(p_fb, CS_FA_TRAN_CODE, 0, trancode, 0L))
	{
		DBG_PRINTF((dbg_syserr, "Failed to get CS_FA_TRAN_CODE from FB"));
		ret |= FAIL;
	}

	/* EH_TRAN_CODE (position: 13-21) */
	memstrscpy(p_buf+12, trancode, 9);

	/* EH_SOURCE (position: 22-31) */
	memstrscpy(p_buf+21, M_ehsource, 10);
	/* EH_DEST (position: 32-41) */
	memstrscpy(p_buf+31, M_ehdest, 10);

	/* EH_ERROR (position: 42-51) */
	memcpy(p_buf+41, "0000000000", 10);

	/* EH_FILLER (position: by default 52) */
	memset(p_buf+51, ' ', (size_t)M_filler_size);

	hdrlen = FALCON2_HEADER_LEN-1 + M_filler_size + ext_hdr_len + reserved_len;
	if (NULL != p_hdrlen)
	{
		*p_hdrlen = hdrlen;
	}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	: update_hdr_set_datalen
 *
 * Purpose	: Set in the header length of transaction data
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  p_buf (out) - location for build header
 * 		  datalen (out) - length of transaction data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int	update_hdr_set_datalen(FBFR *p_fb, char *p_buf, long datalen)
{
	int ret = SUCCEED;
	char tmpbuf[16];

	sprintf(tmpbuf, "%08ld", datalen);
	/* EH_APP_DATA_LEN (position: 1-8) */
	memcpy(p_buf, tmpbuf, 8);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: parse_hdr
 *
 * Purpose	: Parse incomming header
 *
 * Parameters	: p_natmsg (in) - native message
 *		  p_fb (out) - fielded buffer
 *		  p_hdrlen (out) - actual header length
 *		  p_datalen (out) - data length (in bytes)
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int	parse_hdr( char *p_natmsg, FBFR *p_fb, long *p_hdrlen, long* p_datalen )
{
	int	ret = SUCCEED;
	
	char	tmpbuf[64];
	long	ext_hdr_len;	/* Length of extended-header */
	char 	*ext_hdr;	/* Extended header */
	char	trancode[9+1];	/* Transaction code */
	char	source[10+1];	/* Name of source application */
	char	dest[10+1];	/* Name of destination application */
	char	error[10+1];

	long	stan;
	long	txmit;
	char	msgcls = EOS;
	char	msgfn = EOS;
	short	fncode = FAIL;
	char	txnsrc = MOR_ACQ;
	
	long	tknlogreqid;
	
	/*
	DBG_DUMPFB(dbg_progdetail, "Output temporal FB:", p_fb);
	*/
	
	memcpy(tmpbuf, p_natmsg, 8); tmpbuf[8] = EOS; /* EH_APP_DATA_LEN (position: 1-8) */
	*p_datalen = strtol(tmpbuf, NULL, 10);

	memcpy(tmpbuf, p_natmsg+8, 4); tmpbuf[4] = EOS; /* EH_EXT_HDR_LEN (position: 9-12) */
	ext_hdr_len = strtol(tmpbuf, NULL, 10);

	memcpy(trancode, p_natmsg+12, 9); trancode[9] = EOS; /* EH_TRAN_CODE (position: 13-21) */
	memcpy(source, p_natmsg+21, 10); source[10] = EOS; /* EH_SOURCE (position: 22-31) */
	memcpy(dest, p_natmsg+31, 10); dest[10] = EOS; /* EH_DEST (position: 32-41) */
	memcpy(error, p_natmsg+41, 10); error[10] = EOS; /* EH_ERROR (position: 42-51) */
	/* EH_FILLER (position: by default 52) */
	
	ext_hdr = p_natmsg+FALCON2_HEADER_LEN-1+M_filler_size; /* EH_EXT_HDR (position: 53-n; n=53+EH_EXT_HDR_LEN) */

	*p_hdrlen = FALCON2_HEADER_LEN-1 + M_filler_size + ext_hdr_len;

	if (0 == strcmp(TRAN_CODE_STOP_SENDING_REQ, trancode))
	{
		msgcls = MCL_NETMGT;
		msgfn = MFN_REQ;
		fncode = MFC_NETMGT_SIGN_OFF;
	}
	else if (0 == strcmp(TRAN_CODE_START_SENDING_REQ, trancode))
	{
		msgcls = MCL_NETMGT;
		msgfn = MFN_REQ;
		fncode = MFC_NETMGT_SIGN_ON;
	}
	else if (0 == strcmp(TRAN_CODE_FALCON_SHUTDOWN, trancode) 
	    || 0 == strcmp(TRAN_CODE_FALCON_UNAVAILABLE, trancode))
	{
		msgcls = MCL_NETMGT;
		msgfn = MFN_REQRSP;
		fncode = MFC_NETMGT_SYS_NA;
	}
	else if (0 == strcmp(TRAN_CODE_PING, trancode))
	{
		msgcls = MCL_NETMGT;
		msgfn = MFN_REQRSP;
		fncode = MFC_NETMGT_ECHO;
	}
	/* if this is scoring response */
	else if (0 == strcmp(TRAN_CODE_PRIORITY_SCORING_RSP, trancode)
		 || 0 == strcmp(TRAN_CODE_SCORING_STANDARD_RSP, trancode))
	{
		if (0 < ext_hdr_len)
		{
			memcpy(tmpbuf, ext_hdr, (size_t)ext_hdr_len);
			tmpbuf[ext_hdr_len] = EOS;
			sscanf(tmpbuf, "%06ld%06ld", &stan, &txmit);
			
			if (SUCCEED != CF_chg(p_fb, C_STAN, 0, (char *)&stan, 0L, FLD_LONG)
			    || SUCCEED != CF_chg(p_fb, C_TIMEXMIT, 0, (char *)&txmit, 0L, FLD_LONG))
			{
				DBG_PRINTF((dbg_syserr, "Failed to set C_STAN/C_TIMEXMIT in FB"));
				ret = FAIL;
			}
		}
		else
		{
			DBG_PRINTF((dbg_syserr, "Received empty EH_EXT_HDR header in Falcon scoring response"));
			ret = FAIL;
		}
	}

	if (EOS != msgcls && SUCCEED != F_chg(p_fb, C_MSGCLS, 0, &msgcls, 0L))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to set C_MSGCLS in FB" ));
		ret = FAIL;
	}
	if (EOS != msgfn && SUCCEED != F_chg(p_fb, C_MSGFN, 0, &msgfn, 0L))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to set C_MSGFN in FB" ));
		ret = FAIL;
	}
	if (FAIL != fncode && SUCCEED != F_chg(p_fb, C_FNCODE, 0, (char *)&fncode, 0L))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to set C_FNCODE in FB" ));
		ret = FAIL;
	}
	if (EOS != msgcls && EOS != msgfn && SUCCEED != F_chg(p_fb, C_TXNSRC, 0, &txnsrc, 0L))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to set C_TXNSRC in FB" ));
		ret = FAIL;
	}

	if (SUCCEED != F_chg(p_fb, CS_FA_TRAN_CODE, 0, trancode, 0L))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to set CS_FA_TRAN_CODE in FB" ));
		ret = FAIL;
	}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	: getTokenInfo
 *
 * Purpose	: Get information from Token and Bpdtkndeviceprov
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  tokenrequestorid (in) - token requestor id
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int	getTokenInfo( FBFR *p_fb, char *tokenrequestorid )
{
	int	ret = SUCCEED;
	
	TOKEN_t		p_token;
	TOKEN_IND_t p_token_ind;
	
	BPDTKNDEVICEPROV_t		p_bpdtkndeviceprov;
	BPDTKNDEVICEPROV_IND_t p_bpdtkndeviceprov_ind;
	
	char pan[30];
	char token[30];
	char walletid[10];
	
	memset(pan, 0, sizeof(pan));
	memset(token, 0, sizeof(token));
	memset(walletid, 0, sizeof(walletid));
	
	int bpdtkndeviceprovfound = 0;
	int gettokenadd = 1;
	
	long token_id = 0;
	
	if (SUCCEED != CF_get(p_fb, C_PAN, 0, pan, 0L, FLD_STRING))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get C_PAN from FB" ));
		
		ret = FAIL;
	}
	if (SUCCEED == ret)
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_TOKEN, 0, token, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_TOKEN from FB" ));
			
			ret = FAIL;
		}
	}
	
	if (SUCCEED == ret)
	{
		DBG_PRINTF(( dbg_progdetail, "pan[%s] token[%s]", pan, token ));
		
		memset((void *)&p_bpdtkndeviceprov,  0, sizeof(p_bpdtkndeviceprov));
		memset((void *)&p_bpdtkndeviceprov_ind, 0, sizeof(p_bpdtkndeviceprov_ind));
					
		ret = dbbpdtkndeviceprov_get_by_pan_token_nolock(pan, token, &p_bpdtkndeviceprov, &p_bpdtkndeviceprov_ind);

		if (SUCCEED == ret) 
		{
			DBG_PRINTF((dbg_progdetail, "BPDTKNDEVICEPROV found, token_id[%ld] tokenstorageid[%s] virtualcardid[%s] devstatus[%s] token[%s] bindingdate[%s]", 
													p_bpdtkndeviceprov.token_id, p_bpdtkndeviceprov.tokenstorageid, p_bpdtkndeviceprov.virtualcardid, p_bpdtkndeviceprov.devstatus,
													p_bpdtkndeviceprov.token, p_bpdtkndeviceprov.bindingdate));
													
			bpdtkndeviceprovfound = 1;
		}
		else
		{
			DBG_PRINTF(( dbg_syserr, "BPDTKNDEVICEPROV record not found (with regular attempt)"));
			
			if (M_gettokenadd == 1)
			{
				DBG_PRINTF((dbg_progdetail, "GETTOKENADD ON"));
				
				DBG_PRINTF((dbg_progdetail, "checking deleted bpdtkndeviceprov records ..."));

				memset((void *)&p_bpdtkndeviceprov,  0, sizeof(p_bpdtkndeviceprov));
				memset((void *)&p_bpdtkndeviceprov_ind, 0, sizeof(p_bpdtkndeviceprov_ind));
							
				ret = dbbpdtkndeviceprov_get_by_pan_token_onlydeleted_nolock(pan, token, &p_bpdtkndeviceprov, &p_bpdtkndeviceprov_ind);
				
				if (SUCCEED == ret) 
				{
					DBG_PRINTF((dbg_progdetail, "BPDTKNDEVICEPROV found, token_id[%ld] tokenstorageid[%s] virtualcardid[%s] devstatus[%s] token[%s] bindingdate[%s]", 
															p_bpdtkndeviceprov.token_id, p_bpdtkndeviceprov.tokenstorageid, p_bpdtkndeviceprov.virtualcardid, p_bpdtkndeviceprov.devstatus,
															p_bpdtkndeviceprov.token, p_bpdtkndeviceprov.bindingdate));
															
					bpdtkndeviceprovfound = 1;
				}
				else
				{
					DBG_PRINTF(( dbg_syserr, "BPDTKNDEVICEPROV record not found (second attempt - deleted)"));
					
					if (M_desfalconmsc == 0)
					{
						DBG_PRINTF(( dbg_progdetail, "checking bpdtkndeviceprov records, using tokenrequestorid... pan[%s] tokenrequestorid[%s]", pan, tokenrequestorid ));
						
						memset((void *)&p_bpdtkndeviceprov,  0, sizeof(p_bpdtkndeviceprov));
						memset((void *)&p_bpdtkndeviceprov_ind, 0, sizeof(p_bpdtkndeviceprov_ind));
									
						ret = dbbpdtkndeviceprov_get_by_pan_tokenrequestorid_andtokenempty_nolock(pan, tokenrequestorid, &p_bpdtkndeviceprov, &p_bpdtkndeviceprov_ind);
						
						if (SUCCEED == ret) 
						{
							DBG_PRINTF((dbg_progdetail, "BPDTKNDEVICEPROV found, token_id[%ld] tokenstorageid[%s] virtualcardid[%s] devstatus[%s] token[%s] bindingdate[%s]", 
																	p_bpdtkndeviceprov.token_id, p_bpdtkndeviceprov.tokenstorageid, p_bpdtkndeviceprov.virtualcardid, p_bpdtkndeviceprov.devstatus,
																	p_bpdtkndeviceprov.token, p_bpdtkndeviceprov.bindingdate));
																	
							bpdtkndeviceprovfound = 1;
						}
						else
						{
							DBG_PRINTF(( dbg_syserr, "BPDTKNDEVICEPROV record not found (third attempt - token empty)"));
							ret = FAIL;
						}
					}
					else 
					{
						DBG_PRINTF(( dbg_progdetail, "checking bpdtkndeviceprov records, using MSC tokenrequestorid... " ));
						
						ret = findListTknRequestorid(tokenrequestorid, walletid);
		
						if (ret == SUCCEED)
						{
							DBG_PRINTF(( dbg_progdetail, "pan[%s] walletid[%s] token[%s]", pan, walletid, token ));
							
							memset((void *)&p_token,  0, sizeof(p_token));
							memset((void *)&p_token_ind, 0, sizeof(p_token_ind));
							
							memset((void *)&p_bpdtkndeviceprov,  0, sizeof(p_bpdtkndeviceprov));
							memset((void *)&p_bpdtkndeviceprov_ind, 0, sizeof(p_bpdtkndeviceprov_ind));
							
							ret = dbtoken_get_by_pan_walletid_nolock(pan, walletid, &p_token, &p_token_ind);
							
							if (SUCCEED == ret) 
							{
								DBG_PRINTF((dbg_progdetail, "TOKEN found id [%ld] pan[%s] walletid[%s] tknstatus[%s] crddet_id[%ld]", 
													p_token.id, p_token.pan, p_token.walletid, p_token.tknstatus, p_token.crddet_id));
													
								token_id = p_token.id;
													
								ret = dbbpdtkndeviceprov_get_by_token_id_tokenempty_nolock(token_id, &p_bpdtkndeviceprov, &p_bpdtkndeviceprov_ind);

								if (SUCCEED == ret) 
								{
									DBG_PRINTF((dbg_progdetail, "BPDTKNDEVICEPROV found, token_id[%ld] tokenstorageid[%s] virtualcardid[%s] devstatus[%s] token[%s] bindingdate[%s]", 
																			p_bpdtkndeviceprov.token_id, p_bpdtkndeviceprov.tokenstorageid, p_bpdtkndeviceprov.virtualcardid, p_bpdtkndeviceprov.devstatus,
																			p_bpdtkndeviceprov.token, p_bpdtkndeviceprov.bindingdate));
																			
									bpdtkndeviceprovfound = 1;
								}
								else
								{
									DBG_PRINTF(( dbg_syserr, "BPDTKNDEVICEPROV record not found (third attempt - msc - token empty)"));
									ret = FAIL;
								}
							}
							else 
							{
								DBG_PRINTF(( dbg_syserr, "TOKEN record not found (third attempt - msc - token empty)"));
								ret = FAIL;
							}
						}
						else
						{
							DBG_PRINTF(( dbg_syserr, "tokenrequestorid not found in msc list"));
							ret = FAIL;
						}
					}

				}
			}
			else
			{
				DBG_PRINTF((dbg_progdetail, "GETTOKENADD OFF"));
			}
		
		}

	}
	
	if (bpdtkndeviceprovfound == 1)
	{
		DBG_PRINTF((dbg_progdetail, "bpdtkndeviceprov was found, updating BPDTKN_BINDINGDATE..."));
		
		if (SUCCEED != F_chg(p_fb, BPDTKN_BINDINGDATE, 0, p_bpdtkndeviceprov.bindingdate, 0L))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to set BPDTKN_BINDINGDATE in FB" ));
			ret = FAIL;
		}
	}
	
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: build_data
 *
 * Purpose	: Build outgoing data area
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  p_buf (out) - native data
 * 		  p_len (out) - data length
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int	build_data( FBFR *p_fb, char *p_buf, long *p_len )
{
	int	ret = SUCCEED;
	DBTRAN25_Context_t ctx;
	long	len = 0;
	unsigned size = BLOB_BUFSIZE;
	Falcon_msglayout_t *p_msglayout = DBTRAN25_layout;
	
	int ret2 = 0;
	char tknrequestorid[50];
	memset(tknrequestorid, 0, sizeof(tknrequestorid));
	
	memset(&ctx, 0, sizeof(ctx));

	if (SUCCEED != F_get(p_fb, C_POSCDIM, 0, &ctx.poscdim, 0L)
	    || SUCCEED != F_get(p_fb, C_POSCHP, 0, &ctx.poschp, 0L)
		|| SUCCEED != F_get(p_fb, C_POSCHIC, 0, &ctx.poschic, 0L)
		   || SUCCEED != F_get(p_fb, C_POSCHAM, 0, &ctx.poscham, 0L)
		      || SUCCEED != F_get(p_fb, C_POSCHAC, 0, &ctx.poschac, 0L)
			 || SUCCEED != F_get(p_fb, C_POSOE, 0, &ctx.posoe, 0L)
			    || SUCCEED != F_get(p_fb, C_POSCP, 0, &ctx.poscp, 0L))
	{
		DBG_PRINTF((dbg_syserr, "Failed to get POS code from FB"));
		ret = FAIL;
	}
	
	if (SUCCEED == ret)
	{
		DBG_PRINTF((dbg_progdetail, "Validating if it's token transaction..."));
		
		if ((F_pres(p_fb, N_TKN_REQUESTOR, 0)) && (SUCCEED == CF_get(p_fb, N_TKN_REQUESTOR, 0, tknrequestorid, 0L, FLD_STRING)))
		{
			DBG_PRINTF((dbg_progdetail, "token transaction -> tokenrequestorid[%s]", tknrequestorid));
			
			ret2  = getTokenInfo(p_fb, tknrequestorid);
			
		}
	}

	if (SUCCEED != F_get(p_fb, C_TXNCODE, 0, (char *)&ctx.txncode, 0L)
	    || SUCCEED != F_get(p_fb, C_FNCODE, 0, (char *)&ctx.fncode, 0L))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get C_TXNCODE/C_FNCODE from FB" ));
		ret = FAIL;
	}

	if (F_pres(p_fb, CS_FA_ADDDATA, 0))
	{
		if (!(ctx.adddata_fb = (FBFR *)ntp_alloc("FML", NULL, size)))
		{
			DBG_PRINTF((dbg_syserr, "tp_alloc fail %d %s",
				ntp_errno(), ntp_strerror(ntp_errno())));
			ret = FAIL;
		}
		else if (SUCCEED != CF_get(p_fb, CS_FA_ADDDATA, 0,
					   (char *)ctx.adddata_fb, &size, FLD_FML32))
		{
			DBG_PRINTF((dbg_syserr, "Failed to restore sub-FB from CS_FA_ADDDATA"));

			ntp_free((char *)ctx.adddata_fb);
			ctx.adddata_fb = NULL;
			ret = FAIL;
		}
	}

	while (NULL != p_msglayout->fieldname)
	{
		/* DBG_PRINTF((dbg_progdetail, "fieldname temp[%s]", p_msglayout->fieldname)); */
		
		if (NULL != p_msglayout->p_fb2rawfn)
		{
			ret |= p_msglayout->p_fb2rawfn(p_fb, p_buf+p_msglayout->pos, p_msglayout->len, &ctx);
		}
		len += p_msglayout->len;
		p_msglayout++;
	}

	if (DBG_GETLEV() > dbg_proginfo)
	{
		falcon_msg_dump(p_buf, DBTRAN25_layout);
	}

	if (NULL != p_len)
	{
		*p_len = len;		
	}

	if (NULL != ctx.adddata_fb)
	{
		ntp_free((char *)ctx.adddata_fb);
	}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	: parse_data
 *
 * Purpose	: Parse incomming data
 *
 * Parameters	: p_natmsg (in) - native message
 * 		  len (in) - message length
 *		  p_fb (out) - fielded buffer
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int	parse_data( char *p_natmsg, long len, FBFR *p_fb )
{
	int	ret = SUCCEED;
	char	trancode[9+1];	/* Transaction code */
	char	tmpbuf[64];
	long 	decision_count;
	int	pos, i;

	if (SUCCEED != F_get(p_fb, CS_FA_TRAN_CODE, 0, trancode, 0L))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get CS_FA_TRAN_CODE in FB" ));
		ret = FAIL;
	}

	/* if this is scoring response */
	if ( SUCCEED == ret 
	     && (0 == strcmp(TRAN_CODE_PRIORITY_SCORING_RSP, trancode) 
		 || 0 == strcmp(TRAN_CODE_SCORING_STANDARD_RSP, trancode)  
	/*	 || 0 == strcmp(TRAN_CODE_PRIORITY_SCORING_RSP_PROV, trancode) 
		 || 0 == strcmp(TRAN_CODE_SCORING_STANDARD_RSP_PROV, trancode)*/) )
	{
		if (ERROR_CODE_POS+ERROR_CODE_LEN-1 <= len)
		{
			/* error_code_1 (position: 26-29) */
			memcpy(tmpbuf, p_natmsg+ERROR_CODE_POS, ERROR_CODE_LEN);
			tmpbuf[ERROR_CODE_LEN] = EOS;

			stp_both(tmpbuf);
			if (SUCCEED != F_chg(p_fb, CS_FA_ERROR_CODE, 0, tmpbuf, 0L))
			{
				DBG_PRINTF(( dbg_syserr, "Failed to set CS_FA_ERROR_CODE in FB" ));
				ret = FAIL;
			}
		}

		if (DECISION_COUNT_POS+DECISION_COUNT_LEN-1 <= len)
		{
			/* decision_count (position: 424-425) */
			memcpy(tmpbuf, p_natmsg+DECISION_COUNT_POS, DECISION_COUNT_LEN);
			tmpbuf[DECISION_COUNT_LEN] = EOS;
			decision_count = strtol(tmpbuf, NULL, 10);
			/* decision_code_1 (position: 458-489) */
			pos = DECISION_COUNT_POS+DECISION_COUNT_LEN+DECISION_TYPE_LEN;
			for (i = 0; i < decision_count; i++)
			{
				memcpy(tmpbuf, p_natmsg+pos, DECISION_CODE_LEN);
				tmpbuf[DECISION_CODE_LEN] = EOS;

				stp_both(tmpbuf);
				if (SUCCEED != F_add(p_fb, CS_FA_DECISION_CODE, tmpbuf, 0L))
				{
					DBG_PRINTF(( dbg_syserr, "Failed to add CS_FA_DECISION_CODE in FB" ));
					ret = FAIL;
				}
				
				pos += DECISION_TYPE_LEN+DECISION_CODE_LEN;
			}
		}
	}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	: falcon_msg_dump
 *
 * Purpose	: Print output falcon message sorted by fields
 *
 * Parameters	: p_buf (in) - raw data
 * 		  p_msglayout (in) - Falcon message layout
 *
 * Returns	: void
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate void falcon_msg_dump(char *p_buf, Falcon_msglayout_t *p_msglayout)
{
	char tmpbuf[300];

	DBG_PRINTF((dbg_progdetail, "FALCON MESSAGE:"));
	
	while (NULL != p_msglayout->fieldname)
	{
		memcpy(tmpbuf, p_buf+p_msglayout->pos, p_msglayout->len);
		tmpbuf[p_msglayout->len] = EOS;
		DBG_PRINTF(( dbg_progdetail, "%s: [%s]", 
			p_msglayout->fieldname, 
			dbg_falcon_mask_field(p_msglayout->fieldname, tmpbuf, p_msglayout->len) ));
		p_msglayout++;
	}
}

/*------------------------------------------------------------------------
 *
 * Function	: dbg_falcon_mask_field
 *
 * Purpose	: Return masked value for the specified Falcon field
 *
 * Parameters	: field (in) - Falcon field name
 * 		  data (in) - Data to be masked
 *
 * Returns	: masked field value
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate char* dbg_falcon_mask_field(const char *field, char *data, size_t len)
{
	int i = 0;
	
	for (i = 0; NULL != M_masked_flds[i].name; i++)
	{
		if (0 == strcmp(field, M_masked_flds[i].name))
		{
			return M_masked_flds[i].p_maskfn(data, len);		
		}
	}
	
	return data;
}

/*--------------------------------------------------------------------------
 *
 * Function     : maskPAN
 *
 * Purpose      : mask PAN using bbbbbb*..*dddd format
 *
 * Parameters   : pan (in) - PAN to mask
 * 		  len (in) - received string length
 *
 * Returns      : masked Pan
 *
 * Comments     : Uses an internal static buffer, so cannot be used more
 *		  than once in the invocation
 *
 *------------------------------------------------------------------------*/
ctxprivate char *maskPAN(const char *pan, size_t len)
{
static	char buf[PAN_LEN_MAX];
	char masked[PAN_LEN_MAX];

	slstrncpy_sen(buf, pan, len);
	slstrscpy(masked, dbg_panMask(stp_right(buf)));
	memset(buf, ' ', len);
	memcpy(buf, masked, strlen(masked));
	buf[len] = EOS;
	
	return buf;
}

/*--------------------------------------------------------------------------
 *
 * Function     : maskExpiry
 *
 * Purpose      : Mask long value if not in test mode
 *
 * Parameters   : date (in) - date to mask
 * 		  len (in) - received string length - not used
 *
 * Returns      : masked date
 *
 * Comments     : Uses an internal static buffer, so cannot be used more
 *		  than once in the invocation
 *
 *------------------------------------------------------------------------*/
ctxprivate char *maskExpiry(const char *date, size_t len)
{
	return dbg_longMask(strtol(date, NULL, 10));
}

/*--------------------------------------------------------------------------
 *
 * Function     : maskBIN
 *
 * Purpose      : Mask string value if not in test mode
 *
 * Parameters   : bin (in) - value to mask
 * 		  len (in) - received string length
 *
 * Returns      : masked bin
 *
 * Comments     : Uses an internal static buffer, so cannot be used more
 *		  than once in the invocation
 *
 *------------------------------------------------------------------------*/
ctxprivate char *maskBIN(const char *bin, size_t len)
{
	return (char *)dbg_strnMask(bin, (unsigned short)len);
}

/*------------------------------------------------------------------------
 *
 * Function	: FFworkflow
 *
 * Purpose	: Build Falcon field `workflow`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Contains the name of the workflow to be executed by Falcon
 *		  Fraud Manager
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFworkflow(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	memstrscpy(out, M_workflow, len);
	
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFrecordType
 *
 * Purpose	: Build Falcon field `recordType`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Constant "DBTRAN25"
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFrecordType(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	memcpy(out, "DBTRAN25", len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFdataSpecificationVersion
 *
 * Purpose	: Build Falcon field `dataSpecificationVersion`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Constant "2.5"
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFdataSpecificationVersion(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	memcpy(out, "2.5  ", len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFclientIdFromHeader
 *
 * Purpose	: Build Falcon field `dataSpecificationVersion`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Unique identifier for the client or subclient
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFclientIdFromHeader(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	memstrscpy(out, M_clientid, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFrecordCreationDate
 *
 * Purpose	: Build Falcon fields `recordCreationDate`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Date and time that record was created
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFrecordCreationDate(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	utc_timestamp(p_ctx->timestamp, sizeof(p_ctx->timestamp));
	memcpy(out, p_ctx->timestamp, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFrecordCreationTime
 *
 * Purpose	: Build Falcon fields `recordCreationTime`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Date and time that record was created
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFrecordCreationTime(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	memcpy(out, p_ctx->timestamp+8, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFrecordCreationMilliseconds
 *
 * Purpose	: Build Falcon fields `recordCreationMilliseconds`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Date and time that record was created
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFrecordCreationMilliseconds(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	memcpy(out, p_ctx->timestamp+8+6, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFgmtOffset
 *
 * Purpose	: Build Falcon field `gmtOffset`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Specifies the Greenwich Mean Time (GMT) offset associated
 *		  with all date-time fields in the record body
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFgmtOffset(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	
	char tmpbuf[64];

	if (M_gmtoffset < 0)
	{
		sprintf(tmpbuf, "%06.2f", (float)M_gmtoffset);	/* format to -nn.nn */
	}
	else
	{
		sprintf(tmpbuf, "%05.2f", (float)M_gmtoffset);	/* format to nn.nn */
	}
	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcustomerIdFromHeader
 *
 * Purpose	: Build Falcon field `customerIdFromHeader`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Customer Identifier
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcustomerIdFromHeader(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	FBFR *fb = NULL;

	fb = F_pres(p_fb, I_CUSTCODE, 0) ? p_fb : p_ctx->adddata_fb;

	if (NULL == fb || SUCCEED != CF_get(fb, I_CUSTCODE, 0, tmpbuf, 0L, FLD_STRING))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get I_CUSTCODE from FB" ));
		ret = FAIL;
	}
	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcustomerAcctNumber
 *
 * Purpose	: Build Falcon field `customerAcctNumber`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Unique identifier for the account associated with the 
 * 		  transaction/record
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcustomerAcctNumber(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	FBFR *fb = NULL;

	fb = F_pres(p_fb, C_ACCNO, 0) ? p_fb : p_ctx->adddata_fb;

	if (NULL == fb || SUCCEED != CF_get(fb, C_ACCNO, 0, tmpbuf, 0L, FLD_STRING))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get C_ACCNO from FB" ));
		ret = FAIL;
	}
	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFexternalTransactionId
 *
 * Purpose	: Build Falcon field `externalTransactionId`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Client-generated unique transaction ID
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFexternalTransactionId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (SUCCEED != CF_get(p_fb, I_TLOGID, 0, tmpbuf, 0L, FLD_STRING))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get I_TLOGID from FB" ));
		ret = FAIL;
	}
	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFpan
 *
 * Purpose	: Build Falcon field `pan`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Primary Account Number (PAN) of the payment instrument
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFpan(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char val_enc[PAN_LEN_MAX];
	char val_clr[PAN_LEN_MAX];

	if (F_pres(p_fb, C_PAN_CLR, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_PAN_CLR, 0, val_clr, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_PAN_CLR from FB" ));
			ret = FAIL;
		}
	}
	else
	{
		if (SUCCEED != CF_get(p_fb, C_PAN, 0, val_enc, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_PAN from FB" ));
			ret = FAIL;
		}

		if(ISPANENC(val_enc)) /* passing in encrypted value */
		{
			if (NULL == decryptPanSize(val_clr, sizeof(val_clr), val_enc))
			{
				DBG_PRINTF((dbg_syserr, "Failed to decrypt PAN"));
				ret = FAIL;
			}
		}
		else /* passing in clear value */
		{
			slstrscpy(val_clr, val_enc);
		}
	}

	memstrscpy(out, val_clr, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFauthPostFlag
 *
 * Purpose	: Build Falcon field `authPostFlag`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Type of transaction:
 * 		  A - Authorization or other payment-card-initiated transaction
 * 		  P - Posting
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFauthPostFlag(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	short *p_fdsaction = NULL;

	p_fdsaction = (short *)F_find(p_fb, I_FDSACTION, 0, NULL);
	if (NULL == p_fdsaction || FDSSEND_REQUEST == *p_fdsaction || FDSSEND_REQNOTIF == *p_fdsaction)
	{
		memcpy(out, "A", len);
	}
	else
	{
		memcpy(out, "P", len);
	}
	p_ctx->authPostFlag = *out;

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcardSeqNum
 *
 * Purpose	: Build Falcon field `cardSeqNum`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: The sequence number for the chip card
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcardSeqNum(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, I_APPLSEQNO, 0))
	{
		if (SUCCEED != CF_get(p_fb, I_APPLSEQNO, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get I_APPLSEQNO from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcardExpireDate
 *
 * Purpose	: Build Falcon field `cardExpireDate`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Expiration date from card, transmitted with transaction data
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcardExpireDate(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, C_DATEEXP, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_DATEEXP, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_DATEEXP from FB" ));
			ret = FAIL;
		}
		else if (0 != strcmp("0000", tmpbuf))
		{
			if ( !is_date_valid(strtol(tmpbuf, NULL, 10)) )
			{
				sprintf(tmpbuf, "%ld", yymm_exp2yyyymmdd(tmpbuf, 0));
			}
			
			memcpy(out, tmpbuf, len);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFexpandedBIN
 *
 * Purpose	: Build Falcon field `expandedBIN`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFexpandedBIN(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (SUCCEED != CF_get(p_fb, C_PAN_CLR, 0, tmpbuf, 0L, FLD_STRING))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get C_PAN_CLR from FB" ));
		ret = FAIL;
	}
	memcpy(out, tmpbuf, 8);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFtokenizationIndicator
 *
 * Purpose	: Build Falcon field `tokenizationIndicator`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Tokenization issue type
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtokenizationIndicator(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	char *p_tmp;

	if (F_pres(p_fb, N_TKN_TYPE, 0))
	{
		if (SUCCEED != CF_get(p_fb, N_TKN_TYPE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get N_TKN_TYPE from FB" ));
			ret = FAIL;
		}

		p_tmp = map_table(tmpbuf, map_tkntype);
		if (NULL != p_tmp)
		{
			memcpy(out, p_tmp, len);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFtokenExpirationDate
 *
 * Purpose	: Build Falcon field `tokenExpirationDate`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Date the token expires
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtokenExpirationDate(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	long yymm;
	long yyyymmdd;

	if (F_pres(p_fb, N_TKN_EXPDATE, 0))
	{
		if ( SUCCEED != CF_get(p_fb, N_TKN_EXPDATE, 0, (char *)&yymm, 0L, FLD_LONG) )
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get N_TKN_EXPDATE from FB" ));
			ret = FAIL;
		}
		else if ( FAIL == (yyyymmdd=yymm_exp2yyyymmdd(NULL, yymm)) )
		{
			ret = FAIL;
		}
		else
		{
			sprintf(tmpbuf, "%ld", yyyymmdd);
			memcpy(out, tmpbuf, len);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcavvResult
 *
 * Purpose	: Build Falcon field `cavvResult`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: The Cardholder Authentication Verification Value result
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcavvResult(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, V_CAVVRSCODE, 0))
	{
		if (SUCCEED != CF_get(p_fb, V_CAVVRSCODE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get V_CAVVRSCODE from FB" ));
			ret = FAIL;
		}
		memcpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFtransactionDate
 *
 * Purpose	: Build Falcon field `transactionDate`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Date of transaction
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtransactionDate(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	local_timestamp(p_ctx->local_timestamp, sizeof(p_ctx->local_timestamp));
	memcpy(out, p_ctx->local_timestamp, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFtransactionTime
 *
 * Purpose	: Build Falcon field `transactionTime`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Time of transaction
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtransactionTime(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	memcpy(out, p_ctx->local_timestamp+8, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFtransactionAmount
 *
 * Purpose	: Build Falcon field `transactionAmount`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Transaction amount
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtransactionAmount(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (SUCCEED != F_get(p_fb, C_AMTTXN, 0, (char *)&p_ctx->transactionAmount, 0L))
	{
		DBG_PRINTF((dbg_syserr, "Failed to get C_AMTTXN from FB"));
		ret = FAIL;
	}
	
	if (SUCCEED == ret)
	{
		sprintf(tmpbuf, "%013.2lf", p_ctx->transactionAmount); /* format to nnnnnnnnnn.nn */
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFtransactionCurrencyCode
 *
 * Purpose	: Build Falcon field `transactionCurrencyCode`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: ISO numeric currency code
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtransactionCurrencyCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	if (SUCCEED != F_get(p_fb, C_CURTXN, 0, p_ctx->transactionCurrencyCode, 0L))
	{
		DBG_PRINTF((dbg_syserr, "Failed to get C_CURTXN from FB" ));
		ret = FAIL;
	}

	if (SUCCEED == ret)
	{
		memstrscpy(out, p_ctx->transactionCurrencyCode, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFtransactionCurrencyConversionRate
 *
 * Purpose	: Build Falcon field `transactionCurrencyConversionRate`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: The multiplicative currency conversion rate that is used 
 * 		  to convert the currency specified in `transactionCurrencyCode` to US dollars.
 * 		  The number of US dollars in the currency specified 
 * 		  in `transactionCurrencyCode`.
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtransactionCurrencyConversionRate(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	long inst_id;
	short txncode;
	double amt;
	double rate = 0.0;
	int rate_ok = FALSE;
	
	char dfltForexRef[20];
	
	strcpy(dfltForexRef, "DFLT");

	/* Fill only if currency is not USD */
	if (0 != strcmp("840", p_ctx->transactionCurrencyCode))
	{
		if (SUCCEED != F_get(p_fb, C_TXNCODE, 0, (char *)&txncode, 0L))
		{
			DBG_PRINTF(( dbg_syswarn, "Failed to get C_TXNCODE from FB" ));
			txncode = FAIL; /* default to DEBIT */
		}
		
		if (SUCCEED != F_get(p_fb, I_INST_ID, 0, (char *)&inst_id, 0L))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get I_INST_ID from FB" ));
			ret = FAIL;
		}
		else
		{
			if (SUCCEED != forex_do_forex(
				inst_id, dfltForexRef,
				p_ctx->transactionAmount, &amt, &rate,
				p_ctx->transactionCurrencyCode, "840",
				txncode,
				NULL, p_fb, M_forex_ref_dflt, M_forex_ref_fmt,
				FOREXREF_ROLE_ISS,
				FALSE, FALSE))
			{
				DBG_PRINTF((dbg_syserr,"Failed to convert %lf "
					"in [%s] to [%s] for Institution "
					"[id=%ld]", p_ctx->transactionAmount, p_ctx->transactionCurrencyCode,
					"840", inst_id));
				/*ret = FAIL;*/
			}
			else
			{
				rate_ok = TRUE;
			}
		}
	}
	else
	{
		rate = 1.0f;
		rate_ok = TRUE;
	}

	if (rate_ok)
	{
		sprintf(tmpbuf, "%013.6lf", rate);	/* format to nnnnnn.nnnnnn */
		memstrscpy(out, tmpbuf, len);
	}
	/* default of out is empty space, thus in case if rate is not found, go empty.. */

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFauthDecisionCode
 *
 * Purpose	: Build Falcon field `authDecisionCode`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Authorization Decision Code
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFauthDecisionCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	char *p_tmp;

	if (F_pres(p_fb, C_ACTIONCODE, 0) && F_pres(p_fb, C_RSPCODE, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_ACTIONCODE, 0, tmpbuf, 0L, FLD_STRING)
		    || SUCCEED != CF_get(p_fb, C_RSPCODE, 0, tmpbuf+1, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_ACTIONCODE/C_RSPCODE from FB" ));
			ret = FAIL;
		}
		else
		{
			p_tmp = map_table(tmpbuf, map_rspcode);
			if (NULL != p_tmp)
			{
				memcpy(out, p_tmp, len);
			}
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFtransactionType
 *
 * Purpose	: Build Falcon field `transactionType`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Transaction type
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtransactionType(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	char *p_tmp;

	if (FBISCBREV(p_fb))
	{
		/* Reversal */
		memcpy(out, "X", len);
	}
	else if (TRUE == fev_evbool(p_fb, &Biscof))
	{
		/* Automated recurring charge */
		memcpy(out, "U", len);
	}
	else if (FBISPREAUTH(p_fb))
	{
		/* Pre-authorization */
		memcpy(out, "P", len);
	}
	else if (FBISMTCCREDIT(p_fb))
	{
		/* Crediting funds to the account */
		memcpy(out, "R", len);
	}
	else if (FBISRCURTXN(p_fb))
	{
		/* Automated recurring charge */
		memcpy(out, "U", len);
	}
	else if (FBISFIN(p_fb) && F_pres(p_fb, C_AUTHLIFE, 0))
	{
		/* Completion of previously pre-authorized transaction */
		memcpy(out, "Z", len);
	}
	else
	{
		sprintf(tmpbuf, "%02hd", p_ctx->txncode);
		p_tmp = map_table(tmpbuf, map_txncode);
		if (NULL != p_tmp)
		{
			memcpy(out, p_tmp, len);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFmcc
 *
 * Purpose	: Build Falcon field `mcc`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Merchant Category Code
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFmcc(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (SUCCEED != F_get(p_fb, C_CRDACPTBUS, 0, (char *)&p_ctx->mcc, 0L))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get C_CRDACPTBUS from FB" ));
		ret = FAIL;
	}
	else
	{
		sprintf(tmpbuf, "%hd", p_ctx->mcc);
	}
	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFmerchantPostalCode
 *
 * Purpose	: Build Falcon field `merchantPostalCode`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Merchant ZIP or postal code
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFmerchantPostalCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, C_CRDACPTLOC_POSTCODE, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_CRDACPTLOC_POSTCODE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_CRDACPTLOC_POSTCODE from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFmerchantCountryCode
 *
 * Purpose	: Build Falcon field `merchantCountryCode`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Merchant ISO numeric country code
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFmerchantCountryCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, C_CRDACPTLOC_COUNTRY, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_CRDACPTLOC_COUNTRY, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_CRDACPTLOC_COUNTRY from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFpinVerifyCode
 *
 * Purpose	: Build Falcon field `pinVerifyCode`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: PIN verification
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFpinVerifyCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	if (TRUE == fev_evbool(p_fb, &Bpinveri))
	{
		/* Invalid */
		memcpy(out, "I", len);
	}
	else if (TRUE == fev_evbool(p_fb, &Bpinverv))
	{
		/* Valid */
		memcpy(out, "V", len);
	}
	else if (TRUE == fev_evbool(p_fb, &Bpinverx))
	{
		/* PIN entered but not verified or verification results unknown */
		memcpy(out, "X", len);
	}
	else if (MCHAM_PIN != p_ctx->poscham)
	{
		/* PIN not entered, not using a card association network */
		memcpy(out, "Y", len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcvvVerifyCode
 *
 * Purpose	: Build Falcon field `cvvVerifyCode`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcvvVerifyCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char cvvres[2] = {VERCHK_UNK, EOS};
	char *p_tmp;

	if (MCDIM_3DSECMRCH == p_ctx->poscdim
	    || MCDIM_3DSEC == p_ctx->poscdim
	    || MCDIM_ESEC == p_ctx->poscdim
	    || MCDIM_ENOSEC == p_ctx->poscdim
	    || MCDIM_3DSECMRCHC == p_ctx->poscdim
	    || MCDIM_3DSECC == p_ctx->poscdim
	    || MCDIM_ESECC == p_ctx->poscdim)
	{
		/* this is ecom */
		if (SUCCEED != CF_get(p_fb, I_CVV2RES, 0, cvvres, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get I_CVV2RES from FB" ));
			ret = FAIL;
		}
	}
	else
	{
		if (F_pres(p_fb, I_CVV3RES, 0))
		{
			if (SUCCEED != CF_get(p_fb, I_CVV3RES, 0, cvvres, 0L, FLD_STRING))
			{
				DBG_PRINTF(( dbg_syserr, "Failed to get I_CVV3RES from FB" ));
				ret = FAIL;
			}
		}

		if (SUCCEED == ret)
		{
			if ( F_pres(p_fb, I_CVV1RES, 0) && (!F_pres(p_fb, I_CVV3RES, 0)
			    || !(VERCHK_BAD == cvvres[0] || VERCHK_OK == cvvres[0] || VERCHK_NET_BAD == cvvres[0])) )
			{
				/* assume track / chip read: */
				if (SUCCEED != CF_get(p_fb, I_CVV1RES, 0, cvvres, 0L, FLD_STRING))
				{
					DBG_PRINTF(( dbg_syserr, "Failed to get I_CVV1RES from FB" ));
					ret = FAIL;
				}
			}
			else
			{
				/* I_CVV3RES is used */
			}
		}
	}

	/* fallback to unknown */
	if (FAIL == ret)
	{
		cvvres[0] = VERCHK_UNK;
		ret = SUCCEED;
	}
	
	p_tmp = map_table(cvvres, map_cvvres);
	if (NULL != p_tmp)
	{
		memcpy(out, p_tmp, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFposEntryMode
 *
 * Purpose	: Build Falcon field `posEntryMode`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: POS entry mode
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFposEntryMode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	char *p_tmp;
	FBFR *fb = NULL;
	char chic, cdim;
	char crdtype;
	short poscc89 = 0;

	fb = F_pres(p_fb, I_CRDSVCCODE, 0) ? p_fb : p_ctx->adddata_fb;

	if ( FAIL == F_get(p_fb, C_POSCHIC, 0, &chic, 0) ||
	     FAIL == F_get(p_fb, C_POSCDIM, 0, &cdim, 0) ||
	     NULL == fb || FAIL == CF_get(fb, I_CRDSVCCODE, 0, &crdtype, 0L, FLD_CHAR))
	{
		DBG_PRINTF((dbg_syserr, "Error reading FB."));
		ret = FAIL;
	}

	if (FBISVISA(p_fb) && 
	    SUCCEED == F_get(p_fb, C_POSCC_89, 0, (char *)&poscc89, 0) && 
	    POSCC_ECOMPUB == poscc89)
	{
		memcpy(out, "E", len);	/* E-commerce */
		p_ctx->posEntryMode = 'E';
	}
	else if (SUCCEED == ret && TRUE == fev_evbool(p_fb, &Biscof))
	{
		memcpy(out, "K", len);	/* Keyed (manual) */
		p_ctx->posEntryMode = 'K';
	}
	/* If fallback: (F or G) */
	else if (SUCCEED != posEntryModeFallback(p_fb, chic, cdim, crdtype, tmpbuf))
	{
		ret = FAIL;
	}
	else if (EOS != tmpbuf[0])
	{
		memcpy(out, tmpbuf, len);
		p_ctx->posEntryMode = tmpbuf[0];
	}
	else /* if fall-back not defined */
	{
		tmpbuf[0] = p_ctx->poscdim;
		tmpbuf[1] = EOS;
		p_tmp = map_table(tmpbuf, map_poscdim);
		if (NULL != p_tmp)
		{
			memcpy(out, p_tmp, len);
			p_ctx->posEntryMode = *p_tmp;
		}
	}
	
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFpostDate
 *
 * Purpose	: Build Falcon field `postDate`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Date posting was processed
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFpostDate(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	
	/* If Posting */
	if ('P' == p_ctx->authPostFlag)
	{
		memcpy(out, p_ctx->local_timestamp, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFidMethod
 *
 * Purpose	: Build Falcon field `idMethod`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: The ID method
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFidMethod(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	if (MCHAM_MSIG == p_ctx->poscham)
	{
		/* signature */
		memcpy(out, "1", len);
	}
	else if (MCHAC_PIN == p_ctx->poschac)
	{
		/* online PIN */
		memcpy(out, "2", len);
	}
	if (MCHAC_PIN != p_ctx->poschac 
	    && (MOE_ONP_UNA == p_ctx->posoe 
	     || MOE_OFP_UNA == p_ctx->posoe 
	     || MOE_ONCH_UNA == p_ctx->posoe))
	{
		/* unattended terminal, no PIN pad */
		memcpy(out, "3", len);
	}
	else if (MCHP_MAIL == p_ctx->poschp 
		 || MCHP_TELE == p_ctx->poschp 
		 || MCHP_EORD == p_ctx->poschp 
		 || MCHAM_EC == p_ctx->poscham 
		 || MCHAM_3DSEC == p_ctx->poscham 
		 || MCHAM_3DSECC == p_ctx->poscham)
	{
		/* mail/telephone/electronic commerce */
		memcpy(out, "4", len);
	}
	else
	{
		/* not specified */
		memcpy(out, "0", len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFexternalScore1
 *
 * Purpose	: Build Falcon field `externalScore1`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: External score for use by another process
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFexternalScore1(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, V_ORACNDCODE, 0))
	{
		if (SUCCEED != CF_get(p_fb, V_ORACNDCODE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get V_ORACNDCODE from FB" ));
			ret = FAIL;
		}
		tmpbuf[2] = EOS; /* leave only score in the field */
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcustomerPresent
 *
 * Purpose	: Build Falcon field `customerPresent`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: External score for use by another process
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcustomerPresent(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	if (MCHP_PRES == p_ctx->poschp || MCHP_PRESSTAND == p_ctx->poschp)
	{
		memcpy(out, "Y", len);
	}
	else
	{
		memcpy(out, "N", len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFatmOwner
 *
 * Purpose	: Build Falcon field `atmOwner`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: ATM owner, if mcc = 6011
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFatmOwner(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (MCC_ATM == p_ctx->mcc)
	{
		if (SUCCEED != CF_get(p_fb, I_AFE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get I_AFE from FB" ));
			ret = FAIL;
		}
		else if (lookupInList(tmpbuf, M_onusafes))
		{
			/* Issuers (financial institutions) own ATM terminal (On-us transaction) */
			memcpy(out, "B", len);
		}
		else if (lookupInList(tmpbuf, M_unionafes))
		{
			/* Other financial institution, credit union or thrift owned terminal */
			memcpy(out, "C", len);
		}
		else
		{
			/* Other owner */
			memcpy(out, "O", len);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFtokenRequestorId
 *
 * Purpose	: Build Falcon field `tokenRequestorId`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Token Requestor ID
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtokenRequestorId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, N_TKN_REQUESTOR, 0))
	{
		if (SUCCEED != CF_get(p_fb, N_TKN_REQUESTOR, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get N_TKN_REQUESTOR from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFmerchantName
 *
 * Purpose	: Build Falcon field `merchantName`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Merchant name (or address). Use ISO Field 43.
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFmerchantName(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, C_CRDACPTLOC_NAME, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_CRDACPTLOC_NAME, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_CRDACPTLOC_NAME from FB" ));
			ret = FAIL;
		}
	}
	else
	{
		if (SUCCEED != CF_get(p_fb, C_CRDACPTLOC_STREET, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_CRDACPTLOC_STREET from FB" ));
			ret = FAIL;
		}
	}
	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFmerchantCity
 *
 * Purpose	: Build Falcon field `merchantCity`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Merchant city. Use ISO Field 43.
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFmerchantCity(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (SUCCEED != CF_get(p_fb, C_CRDACPTLOC_CITY, 0, tmpbuf, 0L, FLD_STRING))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get C_CRDACPTLOC_CITY from FB" ));
		ret = FAIL;
	}
	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFmerchantState
 *
 * Purpose	: Build Falcon field `merchantState`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Merchant state (or country). Use ISO Field 43 or 59.
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFmerchantState(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	short number;
	char *p_tmp;

	if (SUCCEED != CF_get(p_fb, C_ACQCOUNTRY, 0, (char *)&number, 0L, FLD_SHORT))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get C_ACQCOUNTRY from FB" ));
		ret = FAIL;
	}
	sprintf(tmpbuf, "%03hd", number);
	
	p_tmp = ctry_ntoa2(tmpbuf);
	if (NULL != p_tmp)
	{
		memstrscpy(out, p_tmp, len);
	}
	else
	{
		DBG_PRINTF(( dbg_syserr, "Unknown country code [%s]", tmpbuf ));
		ret = FAIL;
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFrealtimeRequest
 *
 * Purpose	: Build Falcon field `realtimeRequest`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Authorization: Real-time-response indicator
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFrealtimeRequest(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	short fdsaction;

	if (SUCCEED != F_get(p_fb, I_FDSACTION, 0, (char *)&fdsaction, 0L))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get I_FDSACTION from FB" ));
		ret = FAIL;
	}
	if (FDSSEND_REQUEST != fdsaction)
	{
		memcpy(out, "N", len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcardAipStatic
 *
 * Purpose	: Build Falcon field `cardAipStatic`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Indicates the ability of a chip card to support Static Data
 * 		  Authentication as part of the Application Interchange Profile
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcardAipStatic(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char ind;

	if (SUCCEED == ret)
	{
		ret = cardAipInd(p_fb, EMV_AIPSDASPP, &ind);
		memcpy(out, &ind, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcardAipDynamic
 *
 * Purpose	: Build Falcon field `cardAipDynamic`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Indicates the ability of a chip card to support Dynamic Data
 * 		  Authentication as part of the Application Interchange Profile
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcardAipDynamic(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char ind;

	if (SUCCEED == ret)
	{
		ret = cardAipInd(p_fb, EMV_AIPDDASPP, &ind);
		memcpy(out, &ind, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcardAipVerify
 *
 * Purpose	: Build Falcon field `cardAipVerify`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Indicates the ability of a chip card to support Cardholder
 * 		  Verification as part of the Application Interchange Profile
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcardAipVerify(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char ind;

	if (SUCCEED == ret)
	{
		ret = cardAipInd(p_fb, EMV_AIPCHVSPP, &ind);
		memcpy(out, &ind, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcardAipRisk
 *
 * Purpose	: Build Falcon field `cardAipRisk`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Indicates the ability of a chip card to perform Terminal Risk
 * 		  Management as part of the Application Interchange Profile
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcardAipRisk(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char ind;

	if (SUCCEED == ret)
	{
		ret = cardAipInd(p_fb, EMV_AIPTRMSPP, &ind);
		memcpy(out, &ind, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcardAipIssuerAuthentication
 *
 * Purpose	: Build Falcon field `cardAipIssuerAuthentication`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Indicates the ability of a chip card to support Issuer
 * 		  Authentication as part of the Application Interchange Profile
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcardAipIssuerAuthentication(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char ind;

	if (SUCCEED == ret)
	{
		ret = cardAipInd(p_fb, EMV_AIPIASPP, &ind);
		memcpy(out, &ind, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcardAipCombined
 *
 * Purpose	: Build Falcon field `cardAipCombined`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Indicates whether a chip card supports combined DDA/AC
 * 		  Generation (CDA) as part of the Application Interchange Profile
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcardAipCombined(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char ind;

	if (SUCCEED == ret)
	{
		ret = cardAipInd(p_fb, EMV_AIPCDA2SPP, &ind);
		memcpy(out, &ind, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcardDailyLimitCode
 *
 * Purpose	: Build Falcon field `cardDailyLimitCode`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: The deprecated cardDailyLimitCode field has been repurposed
 * 		  for use as an authentication indicator
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcardDailyLimitCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	if (FBISEUROPAY(p_fb))
	{
		if (TRUE == fev_evbool(p_fb, &Becomm))
		{
			/* ecommerce / SecureCode */
			memcpy(out, "1", len);
		}
		else if (TRUE == fev_evbool(p_fb, &Bmasterpass))
		{
			/* processed through Masterpass */
			memcpy(out, "2", len);
		}
		else if (TRUE == fev_evbool(p_fb, &Bdsrp))
		{
			/* Digital Secure Remote Payment (DSRP) with UCAF data */
			memcpy(out, "4", len);
		}
		else if ((MCHP_STAND == p_ctx->poschp || MCHP_PRESSTAND == p_ctx->poschp) 
			 && MCHAM_3DSEC == p_ctx->poscham) /* TODO: I_FIRST_RECUR ? */
		{
			/* recurring authentication */
			memcpy(out, "7", len);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFavailableBalance
 *
 * Purpose	: Build Falcon field `availableBalance`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Available balance for accessed account immediately before 
 * 		  transaction
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFavailableBalance(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	double amt;

	if (F_pres(p_fb, C_CURBILL, 0) && F_pres(p_fb, I_CRDOTBBAL, 0))
	{
		if (SUCCEED != F_get(p_fb, I_CRDOTBBAL, 0, (char *)&amt, 0L))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get I_CRDOTBBAL from FB" ));
			ret = FAIL;
		}

		sprintf(tmpbuf, "%013.2lf", amt);	/* format to (-)nnnnnnnnn.nn */
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFatmProcessingCode
 *
 * Purpose	: Build Falcon field `atmProcessingCode`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: For ATM transactions, processing code according to 
 * 		  ISO 8583, field 003
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFatmProcessingCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	short acctype[2] = {0, 0};

	if (FBISATM(p_fb))
	{
		/* Will use default accounts, if missing  */
		F_get(p_fb, C_ACCTYPE, 0, (char *)&acctype[0], 0L);
		F_get(p_fb, C_ACCTYPE, 1, (char *)&acctype[1], 0L);

		/* check for valid types, only as in ISO */

		if (acctype[0]!=ACC_TYPE_DEFAULT
		    && acctype[0]!=ACC_TYPE_SAVINGS
		    && acctype[0]!=ACC_TYPE_CHEQUE
		    && acctype[0]!=ACC_TYPE_CREDIT
		    && acctype[0]!=ACC_TYPE_UNIVERSAL
		    && acctype[0]!=ACC_TYPE_INVESTMENT)
		{
			acctype[0] = ACC_TYPE_DEFAULT;
		}

		if (acctype[1]!=ACC_TYPE_DEFAULT
		    && acctype[1]!=ACC_TYPE_SAVINGS
		    && acctype[1]!=ACC_TYPE_CHEQUE
		    && acctype[1]!=ACC_TYPE_CREDIT
		    && acctype[1]!=ACC_TYPE_UNIVERSAL
		    && acctype[1]!=ACC_TYPE_INVESTMENT)
		{
			acctype[1] = ACC_TYPE_DEFAULT;
		}

		sprintf(tmpbuf, "%02hd%02hd%02hd", p_ctx->txncode, acctype[0], acctype[1]);
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcvv2Present
 *
 * Purpose	: Build Falcon field `cvv2Present`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Presence indicator for Card Identification Number (CIN), 
 * 		  CVC2 or CVV2
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcvv2Present(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	if (FALSE == fev_evbool(p_fb, &Bcvv2pres))
	{
		/* CVV2 not provided */
		memcpy(out, "0", len);
	}
	else if (TRUE == fev_evbool(p_fb, &Bcvv2syserr))
	{
		/* CVV2 present but not legible */
		memcpy(out, "2", len);
	}
	else
	{
		/* CVV2 present */
		memcpy(out, "1", len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcvv2Response
 *
 * Purpose	: Build Falcon field `cvv2Response`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Response to a CVV2 request
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcvv2Response(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	if (TRUE == fev_evbool(p_fb, &Bcvv2match))
	{
		/* CVV2 match */
		memcpy(out, "M", len);
	}
	else if (TRUE == fev_evbool(p_fb, &Bcvv2notmatch))
	{
		/* CVV2 no match */
		memcpy(out, "N", len);
	}
	else if (TRUE == fev_evbool(p_fb, &Bcvv2notperf))
	{
		/* CVV2 not processed */
		memcpy(out, "P", len);
	}
	else if (TRUE == fev_evbool(p_fb, &Bcvv2encerr))
	{
		/* Issuer is not certified or has not provided encryption keys to association */
		memcpy(out, "U", len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFavsResponse
 *
 * Purpose	: Build Falcon field `avsResponse`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Response to an AVS (Address Verification Service) request
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFavsResponse(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	char *p_tmp;

	if (F_pres(p_fb, I_ADDRVERCODE, 0))
	{
		if (SUCCEED != CF_get(p_fb, I_ADDRVERCODE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get I_ADDRVERCODE from FB" ));
			ret = FAIL;
		}
		p_tmp = map_table(tmpbuf, map_avsrsp);
		if (NULL != p_tmp)
		{
			memcpy(out, p_tmp, len);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFtransactionCategory
 *
 * Purpose	: Build Falcon field `transactionCategory`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Method used for the transaction
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtransactionCategory(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	if (TRUE == fev_evbool(p_fb, &Biscof) || FBISRCURTXN(p_fb))
	{
		/* Automatic/recurring */
		memcpy(out, "A", len);
	}
	else if (FBISEC(p_fb))
	{
		/* Internet */
		memcpy(out, "I", len);
	}
	else if (MCHP_MAIL == p_ctx->poschp)
	{
		/* Mail */
		memcpy(out, "M", len);
	}
	else if (MCP_NOTP == p_ctx->poscp && MCHP_PRES == p_ctx->poschp)
	{
		/* Card not present, Cardholder present */
		memcpy(out, "N", len);
	}
	else if (MCP_PRES == p_ctx->poscp)
	{
		/* Card present */
		memcpy(out, "P", len);
	}
	else if (MCHP_TELE == p_ctx->poschp)
	{
		/* Telephone */
		memcpy(out, "T", len);
	}
	else
	{
		/* Other */
		memcpy(out, "O", len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFacquirerId
 *
 * Purpose	: Build Falcon field `acquirerId`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: ID code of the acquiring institution (ISO 8583 field 32)
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFacquirerId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, C_AIID, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_AIID, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_AIID from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFacquirerCountry
 *
 * Purpose	: Build Falcon field `acquirerCountry`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: ISO numeric country code of the acquiring institution for 
 * 		  the merchant or ATM (ISO 8583 field 19)
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFacquirerCountry(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	short number;

	if (F_pres(p_fb, C_ACQCOUNTRY, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_ACQCOUNTRY, 0, (char *)&number, 0L, FLD_SHORT))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get C_ACQCOUNTRY from FB"));
			ret = FAIL;
		}
		sprintf(tmpbuf, "%03hd", number);
		memcpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFterminalId
 *
 * Purpose	: Build Falcon field `terminalId`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: The ID number of the terminal at which the authorization 
 * 		  was initiated
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFterminalId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, C_TERMCODE, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_TERMCODE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get C_TERMCODE from FB"));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFterminalType
 *
 * Purpose	: Build Falcon field `terminalType`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Code that identifies the type of POS terminal
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFterminalType(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	if (FBISMOTO(p_fb))
	{
		/* Internet/telephone */
		memcpy(out, "I", len);
	}
	else if (TRUE == fev_evbool(p_fb, &Bisattend))
	{
		/* Attended terminal */
		memcpy(out, "A", len);
	}
	else if (FBISUNATTEND(p_fb))
	{
		/* Unattended terminal, not specified elsewhere */
		memcpy(out, "U", len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFterminalEntryCapability
 *
 * Purpose	: Build Falcon field `terminalEntryCapability`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Terminal entry capability. Indicates the terminal's ability
 * 		  to read account numbers and expiration dates from cards.
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFterminalEntryCapability(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[2];
	char *p_tmp;

	if (MOE_NOTRM == p_ctx->posoe)
	{
		memcpy(out, "Z", len); /* No terminal used */
	}
	else
	{
		tmpbuf[0] = p_ctx->poschic;
		tmpbuf[1] = EOS;
		p_tmp = map_table(tmpbuf, map_poschic);
		if (NULL != p_tmp)
		{
			memcpy(out, p_tmp, len);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFposConditionCode
 *
 * Purpose	: Build Falcon field `posConditionCode`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: A code identifying transaction conditions at 
 * 		  the point of sale or point of service
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFposConditionCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	if (TRUE == fev_evbool(p_fb, &Biscof))
	{
		/* Mail/telephone order/recurring transaction */
		memcpy(out, "08", len);
	}
	else if (MCHAC_MSUS == p_ctx->poschac)
	{
		/* Merchant suspicious of transaction or card */
		memcpy(out, "03", len);
	}
	else if (MCHP_PRES == p_ctx->poschp && (MOE_OFP_UNA == p_ctx->posoe || MOE_ONCH_UNA == p_ctx->posoe))
	{
		/* Unattended acceptance terminal, customer operated */
		memcpy(out, "02", len);
	}
	else if (FBISEC(p_fb))
	{
		/* E-commerce request through public network */
		memcpy(out, "59", len);
	}
	else if (MCHP_PRES != p_ctx->poschp)
	{
		/* Customer not present */
		memcpy(out, "01", len);
	}
	else if ((MCHP_PRES == p_ctx->poschp && MCP_NOTP == p_ctx->poscp) || MCHP_PRESSTAND == p_ctx->poschp)
	{
		/* Customer present, card not present */
		memcpy(out, "05", len);
	}
	else if (TRUE == fev_evbool(p_fb, &Bcmpladv))
	{
		/* Completion advice */
		memcpy(out, "06", len);
	}
	else if (FBISRCURTXN(p_fb))
	{
		/* Mail/telephone order/recurring transaction */
		memcpy(out, "08", len);
	}
	else if (MCHAM_MSIG == p_ctx->poscham || MCHAM_BIOG == p_ctx->poscham)
	{
		/* Customer identity verified */
		memcpy(out, "10", len);
	}
	else if ('G' == p_ctx->posEntryMode)
	{
		/* Card present, magnetic stripe cannot be read */
		memcpy(out, "71", len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFatmNetworkId
 *
 * Purpose	: Build Falcon field `atmNetworkId`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: ATM network identification
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFatmNetworkId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (MCC_ATM == p_ctx->mcc)
	{
		if (SUCCEED != CF_get(p_fb, I_AFE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get I_AFE from FB" ));
			ret = FAIL;
		}
		else if (lookupInList(tmpbuf, M_onusafes))
		{
			/* Financial institution's ATM */
			memcpy(out, "B", len);
		}
		else if (TRUE == fev_evbool(p_fb, &Bcirrus))
		{
			/* Cirrus */
			memcpy(out, "C", len);
		}
		else if (FBISAMEX(p_fb))
		{
			/* American Express */
			memcpy(out, "G", len);
		}
		else if (FBISEUROPAY(p_fb))
		{
			/* MasterCard/Maestro */
			memcpy(out, "M", len);
		}
		else if (FBISVISA(p_fb))
		{
			/* Visa */
			memcpy(out, "V", len);
		}
		else
		{
			/* Other */
			memcpy(out, "O", len);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFauthExpireDateVerify
 *
 * Purpose	: Build Falcon field `authExpireDateVerify`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFauthExpireDateVerify(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	if (FBISREJ(p_fb) && TRUE == fev_evbool(p_fb, &Brejexpdate))
	{
		/* Invalid */
		memcpy(out, "I", len);
	}
	else if (MCDIM_MAG == p_ctx->poscdim
		 || MCDIM_MAGCVV == p_ctx->poscdim
		 || MCDIM_ICC == p_ctx->poscdim
		 || MCDIM_ICC9 == p_ctx->poscdim
		 || MCDIM_ICCSR == p_ctx->poscdim
		 || MCDIM_CLMAG == p_ctx->poscdim
		 || MCDIM_CLMAG_EMV == p_ctx->poscdim)
	{
		if (!FBISREJ(p_fb))
		{
			/* Valid */
			memcpy(out, "V", len);
		}
		else
		{
			/* Expiration date present but not checked or verification results unknown */
			memcpy(out, "X", len);
		}
	}
	else
	{
		if (F_pres(p_fb, C_DATEEXP, 0))
		{
			/* Expiration date present but not checked or verification results unknown */
			memcpy(out, "X", len);
		}
		else
		{
			/* Expiration date not present in authorization message */
			memcpy(out, "Z", len);	
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFauthResponseCode
 *
 * Purpose	: Build Falcon field `authResponseCode`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFauthResponseCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char actioncode;

	if (F_pres(p_fb, C_ACTIONCODE, 0))
	{
		if (SUCCEED != F_get(p_fb, C_ACTIONCODE, 0, &actioncode, 0L))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get C_ACTIONCODE from FB"));
			ret = FAIL;
		}
		else if (MAC_AUTH_APP == actioncode)
		{
			/* Approve */
			memcpy(out, "A", len);
		}
		else if (FBISREJ(p_fb) && TRUE == fev_evbool(p_fb, &Brejcvv))
		{
			/* CVV/CVC failure */
			memcpy(out, "C", len);
		}
		else if (FBISREJ(p_fb) && TRUE == fev_evbool(p_fb, &Brejexpmismatch))
		{
			/* Expiration date mismatch */
			memcpy(out, "D", len);
		}
		else if (TRUE == fev_evbool(p_fb, &Badencrdexp))
		{
			/* Account closed or Expired card */
			memcpy(out, "E", len);
		}
		else if (TRUE == fev_evbool(p_fb, &Bisfraud))
		{
			/* Suspected fraud or lost/stolen card */
			memcpy(out, "F", len);
		}
		else if (TRUE == fev_evbool(p_fb, &Badeninsuff))
		{
			/* Insufficient funds */
			memcpy(out, "I", len);
		}
		else if (TRUE == fev_evbool(p_fb, &Badenexclim))
		{
			/* Exceeds withdrawal amount limit */
			memcpy(out, "L", len);
		}
		else if (TRUE == fev_evbool(p_fb, &Badenexcfrq))
		{
			/* Exceeds withdrawal frequency limit */
			memcpy(out, "M", len);
		}
		else if (TRUE == fev_evbool(p_fb, &Badennoacty))
		{
			/* No such account (checking, savings, or credit) */
			memcpy(out, "N", len);
		}
		else if (TRUE == fev_evbool(p_fb, &Badenpinreq))
		{
			/* Incorrect PIN */
			memcpy(out, "P", len);
		}
		else if (FBISREJ(p_fb) && TRUE == fev_evbool(p_fb, &Brejbadatc))
		{
			/* ATC out of range for contactless or chip transaction */
			memcpy(out, "R", len);
		}
		else if (FBISPTE(p_fb))
		{
			/* Allowable PIN tries exceeded */
			memcpy(out, "T", len);
		}
		else
		{
			/* Other decline reason */
			memcpy(out, "O", len);
		}
	}
	else
	{
		/* Approve (by default) */
		memcpy(out, "A", len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFauthReversalReason
 *
 * Purpose	: Build Falcon field `authReversalReason`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFauthReversalReason(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	char *p_tmp;

	if (!FBISCBREV(p_fb))
	{
		memcpy(out, "0", len); /* Not a reversal */
	}
	else
	{
		if (SUCCEED != CF_get(p_fb, C_REASONCODE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_REASONCODE from FB" ));
			ret = FAIL;
		}
		p_tmp = map_table(tmpbuf, map_reasoncode);
		if (NULL != p_tmp)
		{
			memcpy(out, p_tmp, len);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFauthCardIssuer
 *
 * Purpose	: Build Falcon field `authCardIssuer`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Card Issuer:
 * 		  B - Card issued by processing financial institution
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFauthCardIssuer(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	memcpy(out, "B", len);
	
	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFterminalVerificationResults
 *
 * Purpose	: Build Falcon field `terminalVerificationResults`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Indicates the application status as registered at the terminal
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFterminalVerificationResults(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, C_TVR, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_TVR, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_TVR from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len); /* TODO: maybe convert 5-byte binary to 10-byte HEX ? */
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcardVerificationResults
 *
 * Purpose	: Build Falcon field `cardVerificationResults`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: The card verification results (CVR) indicate that exception
 * 		  conditions occurred during the current and previous transactions,
 * 		  as seen by the card
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcardVerificationResults(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, C_CVR, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_CVR, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_CVR from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len); /* TODO: maybe convert 5-byte binary to 10-byte HEX ? */
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcryptogramValid
 *
 * Purpose	: Build Falcon field `cryptogramValid`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Indicates whether the authorization request cryptogram 
 * 		  was valid
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcryptogramValid(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	char *p_tmp;

	if (F_pres(p_fb, C_CARC, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_CARC, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_CARC from FB" ));
			ret = FAIL;
		}
		p_tmp = map_table(tmpbuf, map_carc);
		if (NULL != p_tmp)
		{
			memcpy(out, p_tmp, len);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFatcCard
 *
 * Purpose	: Build Falcon field `atcCard`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Application transaction counter for chip cards or 
 * 		  contactless cards
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFatcCard(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	long number;

	if (F_pres(p_fb, C_APPLTXNCT, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_APPLTXNCT, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_APPLTXNCT from FB" ));
			ret = FAIL;
		}
		/* convert hex2decimal */
		sscanf(tmpbuf, "%lx", &number);
		sprintf(tmpbuf, "%ld", number);

		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFtokenAssuranceLevel
 *
 * Purpose	: Build Falcon field `tokenAssuranceLevel`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Provided by the Token Service Provider
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtokenAssuranceLevel(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, N_TKN_ASSUR_LVL, 0))
	{
		if (SUCCEED != CF_get(p_fb, N_TKN_ASSUR_LVL, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get N_TKN_ASSUR_LVL from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcavvKeyIndicator
 *
 * Purpose	: Build Falcon field `cavvKeyIndicator`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: The CAVV (Cardholder Authentication Verification Value) 
 * 		  key indicator
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcavvKeyIndicator(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	short number;

	if (F_pres(p_fb, C_CAVVKEYIND, 0))
	{
		if (SUCCEED != F_get(p_fb, C_CAVVKEYIND, 0, (char *)&number, 0L))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_CAVVKEYIND from FB" ));
			ret = FAIL;
		}
		sprintf(tmpbuf, "%02hd", number);
		memcpy(out, tmpbuf, len);
	}
	else
	{
		memcpy(out, "01", len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFeciIndicator
 *
 * Purpose	: Build Falcon field `eciIndicator`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: The ECI indicator
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFeciIndicator(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	if (!FBISEC(p_fb))
	{
		/* not applicable */
		memcpy(out, "0", 1);
	}
	else if (FBISMOTO(p_fb))
	{
		/* single transaction of mail/phone order */
		memcpy(out, "1", 1);
	}
	else if (MCHP_STAND == p_ctx->poschp || MCHP_PRESSTAND == p_ctx->poschp)
	{
		/* recurring transaction */
		memcpy(out, "2", 1);
	}
	else if (MCHP_INST == p_ctx->poschp)
	{
		/* installment payment */
		memcpy(out, "3", 1);
	}
	else if (MCDIM_3DSEC == p_ctx->poscdim)
	{
		/* secure electronic commerce transaction */
		memcpy(out, "5", 1);
	}
	else if (MCDIM_3DSECMRCH == p_ctx->poscdim)
	{
		/* non-authenticated security transactions at a 3-D Secure 
		 * capable merchant, and merchant attempted to authenticate 
		 * using 3-D Secure */
		memcpy(out, "6", 1);
	}
	else if (MCDIM_ESEC == p_ctx->poscdim)
	{
		/* non-authenticated security transaction */
		memcpy(out, "7", 1);
	}
	else if (MCDIM_ENOSEC == p_ctx->poscdim)
	{
		/* non-secure transaction */
		memcpy(out, "8", 1);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFprocessorAuthReasonCode
 *
 * Purpose	: Build Falcon field `processorAuthReasonCode`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Processor's own code identifying reason for authorization decision
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFprocessorAuthReasonCode(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, C_ACTIONCODE, 0) && F_pres(p_fb, C_RSPCODE, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_ACTIONCODE, 0, tmpbuf, 0L, FLD_STRING)
		    || SUCCEED != CF_get(p_fb, C_RSPCODE, 0, tmpbuf+1, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_ACTIONCODE/C_RSPCODE from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFstandinAdvice
 *
 * Purpose	: Build Falcon field `standinAdvice`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFstandinAdvice(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	
	if (FBISACQ(p_fb) && F_pres(p_fb, V_STIPREASON, 0))
	{
		/* Association advice (stand-in)  */
		memcpy(out, "A", len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFmerchantId
 *
 * Purpose	: Build Falcon field `merchantId`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Merchant ID (Card Acceptor ID). Use ISO Field 42.
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFmerchantId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (SUCCEED != CF_get(p_fb, C_CRDACPTID, 0, tmpbuf, 0L, FLD_STRING))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get C_CRDACPTID from FB" ));
		ret = FAIL;
	}
	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcashbackAmount
 *
 * Purpose	: Build Falcon field `cashbackAmount`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcashbackAmount(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	double amt;

	if (F_pres(p_fb, C_AMTBILLCB, 0))
	{
		if (SUCCEED != F_get(p_fb, C_AMTBILLCB, 0, (char *)&amt, 0L))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_AMTBILLCB from FB" ));
			ret = FAIL;
		}
		sprintf(tmpbuf, "%013.2lf", amt); /* format to nnnnnnnnnn.nn */
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFavsRequest
 *
 * Purpose	: Build Falcon field `avsRequest`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: AVS (Address Verification Service) request indicator
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFavsRequest(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	if ((MFC_AUTH_ACCVER_ONLY == p_ctx->fncode
	     || MTC_AVS == p_ctx->txncode)
	    && 0.0001 > p_ctx->transactionAmount)
	{
		/* AVS only (Must have (transactionType = A, transactionAmount = 0) */
		memcpy(out, "1", len);
	}
	else if (MFC_AUTH_ACCVER_ONLY == p_ctx->fncode
		 || MTC_AVS == p_ctx->txncode
		 || F_pres(p_fb, I_AVSPOSTCODE, 0)
		 || F_pres(p_fb, I_AVSADDR, 0))
	{
		/* AVS and authorization request  */
		memcpy(out, "2", len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcvrOfflinePinVerificationPerformed
 *
 * Purpose	: Build Falcon field `cvrOfflinePinVerificationPerformed`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Offline PIN verification indicator from 
 * 		  Card Verification Results
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcvrOfflinePinVerificationPerformed(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];
	short iccver;

	if ((!F_pres(p_fb, EMV_OPVPERM, 0) || !F_pres(p_fb, EMV_OPVFAIL, 0) || !F_pres(p_fb, EMV_EXCPINCVR, 0))
	    && F_pres(p_fb, C_CVR, 0))
	{
		if (SUCCEED != F_get(p_fb, C_EMVICCVER, 0, (char*)&iccver, 0L))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_EMVICCVER from FB" ));
			ret = FAIL;
		}
		if (SUCCEED == ret)
		{
			ret = emv_getflags(p_fb, EMVSCH_VISA, iccver);
		}
	}

	if (F_pres(p_fb, EMV_OPVPERM, 0))
	{
		if (SUCCEED != CF_get(p_fb, EMV_OPVPERM, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get EMV_OPVPERM from FB" ));
			ret = FAIL;
		}
		memcpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcvrOfflinePinVerificationFailed
 *
 * Purpose	: Build Falcon field `cvrOfflinePinVerificationFailed`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Offline PIN verification failure indicator from 
 * 		  Card Verification Results
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcvrOfflinePinVerificationFailed(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, EMV_OPVFAIL, 0))
	{
		if (SUCCEED != CF_get(p_fb, EMV_OPVFAIL, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get EMV_OPVFAIL from FB" ));
			ret = FAIL;
		}
		memcpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFcvrPinTryLimitExceeded
 *
 * Purpose	: Build Falcon field `cvrPinTryLimitExceeded`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Offline PIN try limit indicator from Card Verification Results
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcvrPinTryLimitExceeded(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, EMV_EXCPINCVR, 0))
	{
		if (SUCCEED != CF_get(p_fb, EMV_EXCPINCVR, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get EMV_EXCPINCVR from FB" ));
			ret = FAIL;
		}
		memcpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFposUnattended
 *
 * Purpose	: Build Falcon field `posUnattended`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Unattended terminal indicator
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFposUnattended(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	if (FBISUNATTEND(p_fb))
	{
		/* Unattended terminal */
		memcpy(out, "1", len);
	}
	else if (TRUE == fev_evbool(p_fb, &Bisattend))
	{
		/* Attended terminal */
		memcpy(out, "0", len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFposOffPremises
 *
 * Purpose	: Build Falcon field `posOffPremises`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Off-premises terminal indicator
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFposOffPremises(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	if (MOE_OFP_ATT == p_ctx->posoe || MOE_OFP_UNA == p_ctx->posoe)
	{
		/* Off-premises terminal */
		memcpy(out, "1", len);
	}
	else if (MOE_ONP_ATT == p_ctx->posoe || MOE_ONP_UNA == p_ctx->posoe)
	{
		/* On-premises terminal */
		memcpy(out, "0", len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFposCardCapture
 *
 * Purpose	: Build Falcon field `posCardCapture`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Terminal card-capture capability indicator
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFposCardCapture(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char poscrc;

	if (F_pres(p_fb, C_POSCRC, 0))
	{
		if (SUCCEED != F_get(p_fb, C_POSCRC, 0, &poscrc, 0L))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_POSCRC from FB" ));
			ret = FAIL;
		}
		else if (MCRC_CAPT == poscrc)
		{
			/* Terminal has card-capture capabilities */
			memcpy(out, "1", len);
		}
		else if (MCRC_NONE == poscrc)
		{
			/* Terminal does not have card-capture capabilities */
			memcpy(out, "0", len);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFauthId
 *
 * Purpose	: Build Falcon field `authId`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Authorization Identification Response. Use ISO Field 38.
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFauthId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, C_APRVLCODE, 0))
	{
		if (SUCCEED != CF_get(p_fb, C_APRVLCODE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get C_APRVLCODE from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*---------------------------------------------------------------------------
 *
 * Function     : posEntryModeFallback  
 *
 * Purpose      :  
 *
 * Parameters   : p_fb - FB used
 * 		  chic - C_POSCHIC
 * 		  cdim - C_POSCDIM
 * 		  crdtype - I_CRDSVCCODE
 * 		  res - result to return; code of POS entry mode (F or G) in Falcon,
 * 		  	if fall-back not defined return EOS
 *                 
 * Returns      : SUCCEED / FAIL
 *
 * Comments     : 
 * 
 *------------------------------------------------------------------------*/
ctxprivate int posEntryModeFallback( FBFR *p_fb, char chic, char cdim, char crdtype, char *res )
{
	int ret = SUCCEED;
const	short *p_net_fallback = NULL;

	*res = EOS;

	if (F_pres(p_fb, I_NET_FALLBACK, 0))
	{
		p_net_fallback = (const short*)F_find(p_fb, I_NET_FALLBACK, 0, NULL);
	}
	if ( ( ISCHIPCRD(crdtype) && ( MCHIC_ICC == chic || MCHIC_CLICC_UNK == chic ||
				       MCHIC_CLICC_ICC == chic || MCHIC_CLICC_NOICC == chic )
	       && (MCHIC_MAG == cdim || MCHIC_MAGCVV == cdim) ) ||
	     ( p_net_fallback && NTF_CHIP2MSR == *p_net_fallback ) )
	{
		DBG_PRINTF((dbg_progdetail, "ICC->MSR fall-back."));
		*res = 'F';
	}
	else if ( ISCHIPCRD(crdtype) && ( MCHIC_ICC == chic || MCHIC_CLICC_UNK == chic ||
					  MCHIC_CLICC_ICC == chic || MCHIC_CLICC_NOICC == chic )
		  && MCHIC_KEY == cdim )
	{
		DBG_PRINTF((dbg_progdetail, "ICC->Key Entry fall-back."));
		*res = 'G';
	}
	else
	{
		if (p_net_fallback)
		{
			DBG_PRINTF((dbg_proginfo,
				"No fall-back defined for C_POSCHIC[%c], C_POSCDIM[%c], "
					"I_NET_FALLBACK[%hd] and crdtype[%c].",
				chic, cdim, *p_net_fallback, crdtype));
		}
		else
		{
			DBG_PRINTF((dbg_proginfo,
				"No fall-back defined for C_POSCHIC[%c], C_POSCDIM[%c] and crdtype[%c].",
				chic, cdim, crdtype));
		}
	}
	
	return ret;
}

/*---------------------------------------------------------------------------
 *
 * Function     : lookupInList  
 *
 * Purpose      : Check string by comma separated list
 *
 * Parameters   : str - String to lookup
 * 		  list - Comma separated list
 *                 
 * Returns      : TRUE / FALSE
 *
 * Comments     : 
 * 
 *------------------------------------------------------------------------*/
ctxprivate ctxbool lookupInList(char *str, char* list)
{
	ctxbool res = FALSE;
	char tmp_list[CTX_FILENAME_MAX+1] = {EOS};
	char *item;
	char tmp[64];

	strscpy(tmp_list, list);
	item = strtok(tmp_list,",");
	while(NULL != item)
	{
		strscpy(tmp, item);
		if (0 == strcmp(str, stp_both(tmp)))
		{
			res = TRUE;
			break;
		}
		
		item = strtok(NULL, ",");
	}

	return res;
}

/*---------------------------------------------------------------------------
 *
 * Function     : cardAipInd  
 *
 * Purpose      :  
 *
 * Parameters   : p_fb - FB used
 * 		  fld - FB field where is Application Interchange Profile flag
 * 		  ind - result to return; AIP indicator for Falcon 
 * 		  	(dependent on fld)
 *                 
 * Returns      : SUCCEED / FAIL
 *
 * Comments     : 
 * 
 *------------------------------------------------------------------------*/
ctxprivate int cardAipInd(FBFR *p_fb, FLDID fld, char *ind)
{
	int ret = SUCCEED;
	short aip;
	
	if (F_pres(p_fb, fld, 0))
	{
		if (SUCCEED != CF_get(p_fb, fld, 0, (char *)&aip, 0L, FLD_SHORT))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get %s from FB", F_name(fld) ));
			ret = FAIL;
		}
		else if (1 == aip)
		{
			*ind = 'Y';
		}
		else
		{
			*ind = 'N';
		}
	}
	else
	{
		*ind = ' ';
	}
	
	return ret;
}

/*---------------------------------------------------------------------------
 *
 * Function     : get_datetimexmit_with_gmtoffset  
 *
 * Purpose      : Get C_DATEXMIT and C_TIMEXMIT from FB and apply TZ correction from `gmtoffset` value.
 *
 * Parameters   : p_fb (in) - FB used
 * 		  p_date (out) - Pointer to the date
 * 		  p_time (out) - Pointer to the time
 * 		  gmtoffset (in) - GMT offset. Format is (-)nn.nn, where the digits to the right of the
 *			      decimal point represent decimal fractions of an hour.
 *                 
 * Returns      : SUCCEED / FAIL
 *
 * Comments     : 
 * 
 *------------------------------------------------------------------------*/
ctxprivate int get_datetimexmit_with_gmtoffset(FBFR *p_fb, long *p_date, long *p_time, double gmtoffset)
{
	int ret = SUCCEED;
	long datexmit = 0;
	long timexmit = 0;
	
	if (NULL == p_date)
	{
		p_date = &datexmit;
	}

	if (NULL == p_time)
	{
		p_time = &timexmit;
	}	

	if (SUCCEED != CF_get(p_fb, C_DATEXMIT, 0, (char *)p_date, 0L, FLD_LONG)
	    || SUCCEED != CF_get(p_fb, C_TIMEXMIT, 0, (char *)p_time, 0L, FLD_LONG))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get C_DATEXMIT/C_TIMEXMIT from FB" ));
		ret = FAIL;
	}
	else
	{
		ret = date_time_plus(p_date, p_time, (long)(gmtoffset * 3600));
	}

	return ret;
}

/*---------------------------------------------------------------------------
 *
 * Function     : timestamp2datetime_with_gmtoffset  
 *
 * Purpose      : Extract date and time from timestamp and apply TZ correction from `gmtoffset` value.
 *
 * Parameters   : timestamp (in) - Timestamp (string)
 * 		  p_date (out) - Pointer to the date
 * 		  p_time (out) - Pointer to the time
 * 		  gmtoffset (in) - GMT offset. Format is (-)nn.nn, where the digits to the right of the
 *			      decimal point represent decimal fractions of an hour.
 *                 
 * Returns      : SUCCEED / FAIL
 *
 * Comments     : 
 * 
 *------------------------------------------------------------------------*/
ctxprivate int timestamp2datetime_with_gmtoffset(char *timestamp, long *p_date, long *p_time, double gmtoffset)
{
	int ret = SUCCEED;
	long datexmit = 0;
	long timexmit = 0;

	if (NULL == p_date)
	{
		p_date = &datexmit;
	}

	if (NULL == p_time)
	{
		p_time = &timexmit;
	}
	
	sscanf(timestamp, "%08ld%06ld", p_date, p_time);

	ret = date_time_plus(p_date, p_time, (long)(gmtoffset * 3600));

	return ret;
}



/*------------------------------------------------------------------------
 *
 * Function	: FFuserData02
 *
 * Purpose	: New Build Falcon field `userData02` for token transactions
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_BINDINGDATE field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData02(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[100];
	char tmpdate[20];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_BINDINGDATE, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_BINDINGDATE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_BINDINGDATE from FB" ));
			ret = FAIL;
		}
		else 
		{
			if (strlen(tmpbuf)>8)
			{
				memset(tmpdate, ' ', sizeof(tmpdate));
				memcpy(tmpdate, tmpbuf, 8);
				tmpdate[10] = 0;
			}
		}
	}

	memstrscpy(out, tmpdate, len);

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: build_data_prov
 *
 * Purpose	: Build outgoing data area for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  p_buf (out) - native data
 * 		  p_len (out) - data length
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int	build_data_prov( FBFR *p_fb, char *p_buf, long *p_len, char subtxncode[])
{
	int	ret = SUCCEED;
	DBTRAN25_Context_t ctx;
	long	len = 0;
	unsigned size = BLOB_BUFSIZE;
	
	Falcon_msglayout_t *p_msglayout;
	
	memset(&ctx, 0, sizeof(ctx));
	
	if (strcmp(subtxncode, "OTP")==0)
	{
		DBG_PRINTF((dbg_syserr, "subtxncode[%s] -> using DBTRAN25_layout_prov_otp", subtxncode));
		
		p_msglayout = DBTRAN25_layout_prov_otp;
	}
	else
	{
		DBG_PRINTF((dbg_syserr, "subtxncode[%s] -> using DBTRAN25_layout_prov", subtxncode));
		
		p_msglayout = DBTRAN25_layout_prov;
	}

	/*
	if (SUCCEED != F_get(p_fb, C_POSCDIM, 0, &ctx.poscdim, 0L)
	    || SUCCEED != F_get(p_fb, C_POSCHP, 0, &ctx.poschp, 0L)
		|| SUCCEED != F_get(p_fb, C_POSCHIC, 0, &ctx.poschic, 0L)
		   || SUCCEED != F_get(p_fb, C_POSCHAM, 0, &ctx.poscham, 0L)
		      || SUCCEED != F_get(p_fb, C_POSCHAC, 0, &ctx.poschac, 0L)
			 || SUCCEED != F_get(p_fb, C_POSOE, 0, &ctx.posoe, 0L)
			    || SUCCEED != F_get(p_fb, C_POSCP, 0, &ctx.poscp, 0L))
	{
		DBG_PRINTF((dbg_syserr, "Failed to get POS code from FB"));
		ret = FAIL;
	}

	if (SUCCEED != F_get(p_fb, C_TXNCODE, 0, (char *)&ctx.txncode, 0L)
	    || SUCCEED != F_get(p_fb, C_FNCODE, 0, (char *)&ctx.fncode, 0L))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get C_TXNCODE/C_FNCODE from FB" ));
		ret = FAIL;
	}
	*/

	if (F_pres(p_fb, CS_FA_ADDDATA, 0))
	{
		if (!(ctx.adddata_fb = (FBFR *)ntp_alloc("FML", NULL, size)))
		{
			DBG_PRINTF((dbg_syserr, "tp_alloc fail %d %s",
				ntp_errno(), ntp_strerror(ntp_errno())));
			ret = FAIL;
		}
		else if (SUCCEED != CF_get(p_fb, CS_FA_ADDDATA, 0,
					   (char *)ctx.adddata_fb, &size, FLD_FML32))
		{
			DBG_PRINTF((dbg_syserr, "Failed to restore sub-FB from CS_FA_ADDDATA"));

			ntp_free((char *)ctx.adddata_fb);
			ctx.adddata_fb = NULL;
			ret = FAIL;
		}
	}

	while (NULL != p_msglayout->fieldname)
	{
		/* DBG_PRINTF((dbg_progdetail, "temporal1 fieldname temp[%s]", p_msglayout->fieldname)); */
		
		if (NULL != p_msglayout->p_fb2rawfn)
		{
			ret |= p_msglayout->p_fb2rawfn(p_fb, p_buf+p_msglayout->pos, p_msglayout->len, &ctx);
		}
		
		len += p_msglayout->len;
		p_msglayout++;
	}

	if (DBG_GETLEV() > dbg_proginfo)
	{
		if (strcmp(subtxncode, "OTP")==0)
			falcon_msg_dump(p_buf, DBTRAN25_layout_prov_otp);
		else
			falcon_msg_dump(p_buf, DBTRAN25_layout_prov);
	}

	if (NULL != p_len)
	{
		*p_len = len;		
	}

	if (NULL != ctx.adddata_fb)
	{
		ntp_free((char *)ctx.adddata_fb);
	}

	return( ret );
}


/*------------------------------------------------------------------------
 *
 * Function	: build_hdr_prov
 *
 * Purpose	: Build Header
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  p_buf (out) - location for build header
 * 		  p_hdrlen (out) - header length
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int build_hdr_prov(FBFR *p_fb, char *p_buf, long *p_hdrlen, char subtxncode[])
{
 	int	ret = SUCCEED;
	char	tmpbuf[16];
	long	hdrlen = 0;
	char 	*ext_hdr;		/* Extended header */
	long	ext_hdr_len = 0;	/* Length of extended-header */
	long	reserved_len = 0;
	
	char	trancode[9+1] = {EOS};
	long	stan;
	long	txmit;
	short	fdsaction;
	
	long	tknlogreqid;
	char	strtknlogreqid[20];
	int 	lentkn = 0;
	int		tknpos = 0;
	char * p_tknlogreqid;
	
	char	strtxmit[20];
	
	ext_hdr = p_buf+FALCON2_HEADER_LEN-1+M_filler_size;

	/* EH_APP_DATA_LEN (position: 1-8) */
	memcpy(p_buf, "00000000", 8);
		
	/* EH_EXT_HDR_LEN (position: 9-12) */
	memcpy(p_buf+8, "0000", 4); /* Zero indicates that no extended header is present (default) */
	if (F_pres(p_fb, D_WALLETPROVIDERID, 0))
	{
		DBG_PRINTF((dbg_progdetail,"header provisioning ..."));
		

		if (SUCCEED != CF_get(p_fb, N_TKN_LOG_REQ_ID, 0, (char *)&tknlogreqid, 0L, FLD_LONG)
		    || SUCCEED != CF_get(p_fb, BPDTKN_TIMELOCAL, 0, (char *)&txmit, 0L, FLD_LONG))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get N_TKN_LOG_REQ_ID/BPDTKN_TIMELOCAL from FB"));
			ret |= FAIL;
		}

		if (SUCCEED == ret)
		{
			p_tknlogreqid = strtknlogreqid;
			memset(strtknlogreqid, 0, sizeof(strtknlogreqid));
			sprintf(strtknlogreqid, "%06ld", tknlogreqid);
			
			lentkn = strlen(strtknlogreqid);
			if (lentkn>6)
			{
				tknpos = lentkn - 6;
				p_tknlogreqid = p_tknlogreqid + tknpos;
			}
			
			strcpy(tmpbuf, p_tknlogreqid);
			
			memset(strtxmit, 0, sizeof(strtxmit));
			sprintf(strtxmit, "%06ld", txmit);
			
			/* sprintf(tmpbuf, "%06ld%06ld", tknlogreqid, txmit); */ 
			
			strcat(tmpbuf, strtxmit);
			DBG_PRINTF((dbg_progdetail, "ext_hdr[%s]", tmpbuf));
			
			ext_hdr_len = strlen(tmpbuf);
			/* EH_EXT_HDR (position: 53-n; n=53+EH_EXT_HDR_LEN) */
			memcpy(ext_hdr, tmpbuf, (size_t)ext_hdr_len);
			
			sprintf(tmpbuf, "%04ld", ext_hdr_len);
			/* EH_EXT_HDR_LEN (position: 9-12) */
			memcpy(p_buf+8, tmpbuf, 4);
		}

		reserved_len = FALCON2_HEADER_RESERVED_1_LEN;
	}

	/* if this is scoring request */
	if (F_pres(p_fb, I_FDSACTION, 0))
	{
		ret |= F_get(p_fb, I_FDSACTION, 0, (char *)&fdsaction, 0L);

		if (FDSSEND_REQUEST == fdsaction)
		{
			strscpy(trancode, TRAN_CODE_PRIORITY_SCORING_REQ);
		}
		else
		{
			strscpy(trancode, TRAN_CODE_SCORING_STANDARD_REQ);
		}
	}
	/* if this is network management request/response */
	else if (SUCCEED != F_get(p_fb, CS_FA_TRAN_CODE, 0, trancode, 0L))
	{
		DBG_PRINTF((dbg_syserr, "Failed to get CS_FA_TRAN_CODE from FB"));
		ret |= FAIL;
	}

	/* EH_TRAN_CODE (position: 13-21) */
	memstrscpy(p_buf+12, trancode, 9);

	/* EH_SOURCE (position: 22-31) */
	memstrscpy(p_buf+21, M_ehsource, 10);
	/* EH_DEST (position: 32-41) */
	memstrscpy(p_buf+31, M_ehdest, 10);

	/* EH_ERROR (position: 42-51) */
	memcpy(p_buf+41, "0000000000", 10);

	/* EH_FILLER (position: by default 52) */
	memset(p_buf+51, ' ', (size_t)M_filler_size);

	hdrlen = FALCON2_HEADER_LEN-1 + M_filler_size + ext_hdr_len + reserved_len;
	if (NULL != p_hdrlen)
	{
		*p_hdrlen = hdrlen;
	}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	: FFexternalTransactionId_prov
 *
 * Purpose	: Build Falcon field `externalTransactionId` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Client-generated unique transaction ID
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFexternalTransactionId_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (SUCCEED != CF_get(p_fb, N_TKN_LOG_REQ_ID, 0, tmpbuf, 0L, FLD_STRING))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get N_TKN_LOG_REQ_ID from FB" ));
		ret = FAIL;
	}
	memstrscpy(out, tmpbuf, len);

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFtransactionType_prov
 *
 * Purpose	: Build Falcon field `transactionType` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Transaction type
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtransactionType_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	
	DBG_PRINTF((dbg_progdetail,"FFtransactionType_prov[%d]", len));
	
	/* Pre-authorization */
	memcpy(out, "P", len);
	
	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFcardExpireDate_prov
 *
 * Purpose	: Build Falcon field `cardExpireDate` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Expiration date BPDTKN_CRDEXPDATE from card 
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFcardExpireDate_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[20];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_CRDEXPDATE, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_CRDEXPDATE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_CRDEXPDATE from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFtokenizationIndicator_prov
 *
 * Purpose	: Build Falcon field `tokenizationIndicator` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Tokenization issue type
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtokenizationIndicator_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	
	memcpy(out, "O", len);

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFtokenRequestorId_prov
 *
 * Purpose	: Build Falcon field `tokenRequestorId` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Token Requestor ID
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtokenRequestorId_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, BPDTKN_TKNRQID, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_TKNRQID, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_TKNRQID from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFuserIndicator04_prov
 *
 * Purpose	: Build Falcon field `userIndicator04` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: userIndicator04
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserIndicator04_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf1[20];
	char tmpbuf2[10];
	
	strcpy(out, "   ");

	if (F_pres(p_fb, BPDTKN_LANGUAGE, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_LANGUAGE, 0, tmpbuf1, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_LANGUAGE from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf1, 3);
	}
	/*
	if (F_pres(p_fb, BPDTKN_MAXCURDEV, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_MAXCURDEV, 0, tmpbuf2, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_LANGUAGE from FB" ));
			ret = FAIL;
		}
		memstrscpy(out+3, tmpbuf2, 2);
	}
	*/
	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFuserData06_prov
 *
 * Purpose	: Build Falcon field `userData06` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: userData06
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData06_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	
	char tmpbuf_tknstortype[20];
	char tmpbuf_reasoncodes[20];
	char tmpbuf_storageid[60];
	char tmpbuf_leveloftrust[20];
	
	char tmpbuf[50];
	char subtxncode[20];

	char * p_buf;
	
	strcpy(tmpbuf, "             ");
	
	char devicetype[5];
	char tknrecom[5];
	
	memset(tmpbuf_tknstortype, 0, sizeof(tmpbuf_tknstortype));
	memset(tmpbuf_reasoncodes, 0, sizeof(tmpbuf_reasoncodes));
	memset(tmpbuf_reasoncodes, 0, sizeof(tmpbuf_storageid));
	memset(tmpbuf_leveloftrust, 0, sizeof(tmpbuf_leveloftrust));
	
	memset(devicetype, 0, sizeof(devicetype));
	memset(tknrecom, 0, sizeof(tknrecom));
	
	memset(subtxncode, 0, sizeof(subtxncode));

	if (F_pres(p_fb, BPDTKN_TOKENSTORATYPE, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_TOKENSTORATYPE, 0, tmpbuf_tknstortype, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_TOKENSTORATYPE from FB" ));
			ret = FAIL;
		}
		else
		{
			if ( (strcmp(tmpbuf_tknstortype, "REALITY")==0) || (strcmp(tmpbuf_tknstortype, "UNKNOWN")==0) )
				strcpy(devicetype, "00");
			else if ( (strcmp(tmpbuf_tknstortype, "SPAY_PHONE")==0) || (strcmp(tmpbuf_tknstortype, "IPHONE")==0) || (strcmp(tmpbuf_tknstortype, "ANDROID_PHONE")==0) 
					|| (strcmp(tmpbuf_tknstortype, "MOBILE_PHONE")==0) )
				strcpy(devicetype, "01");
			else if ( (strcmp(tmpbuf_tknstortype, "SPAY_TABLET")==0) || (strcmp(tmpbuf_tknstortype, "IPAD")==0) || (strcmp(tmpbuf_tknstortype, "ANDROID_TABLET")==0) 
					|| (strcmp(tmpbuf_tknstortype, "TABLET")==0) )
				strcpy(devicetype, "02");
			else if ( (strcmp(tmpbuf_tknstortype, "SPAY_WATCH")==0) || (strcmp(tmpbuf_tknstortype, "IWATCH")==0) || (strcmp(tmpbuf_tknstortype, "ANDROID_WATCH")==0) 
					|| (strcmp(tmpbuf_tknstortype, "WATCH")==0) )
				strcpy(devicetype, "03");
			else if ( (strcmp(tmpbuf_tknstortype, "MOBILE_PHONE_OR_TABLET")==0) || (strcmp(tmpbuf_tknstortype, "HCE")==0) )
				strcpy(devicetype, "04");
			else if ( (strcmp(tmpbuf_tknstortype, "MAC_BOOK")==0) || (strcmp(tmpbuf_tknstortype, "PC")==0) )
				strcpy(devicetype, "05");
			else if ( (strcmp(tmpbuf_tknstortype, "SPAY_TV")==0) || (strcmp(tmpbuf_tknstortype, "HOUSEHOLD")==0) )
				strcpy(devicetype, "06");
			else if ( (strcmp(tmpbuf_tknstortype, "BRACELET")==0) || (strcmp(tmpbuf_tknstortype, "WEARABLE")==0) )
				strcpy(devicetype, "07");
			else if (strcmp(tmpbuf_tknstortype, "AUTOMOBILE")==0)
				strcpy(devicetype, "08");
			else 
				strcpy(devicetype, "  ");
			
			p_buf = tmpbuf;
			memstrscpy(p_buf, devicetype, 2);
		}
	}
	
	if (SUCCEED==ret)
	{
		if (SUCCEED != CF_get(p_fb, N_SUB_TXNCODE, 0, subtxncode, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get N_SUB_TXNCODE from FB" ));
			ret = FAIL;
		}
		else
		{
			DBG_PRINTF(( dbg_progdetail, "subtxncode[%s]", subtxncode ));
			
			if ((strcmp(subtxncode, "TDR")==0) || (strcmp(subtxncode, "TVN3700")==0))
			{
				if (SUCCEED != CF_get(p_fb, D_LEVELOFTRUST, 0, tmpbuf_leveloftrust, 0L, FLD_STRING))
				{
					DBG_PRINTF(( dbg_syserr, "Failed to get D_LEVELOFTRUST from FB" ));
					ret = FAIL;
				}
				else 
				{
					DBG_PRINTF(( dbg_progdetail, "tmpbuf_leveloftrust[%s]", tmpbuf_leveloftrust ));
					
					if (strcmp(tmpbuf_leveloftrust, "green")==0)
					{
						strcpy(tknrecom, "A");
					}
					else if (strcmp(tmpbuf_leveloftrust, "yellow")==0)
					{
						strcpy(tknrecom, "I");
					}
					else if (strcmp(tmpbuf_leveloftrust, "orange")==0)
					{
						strcpy(tknrecom, "D");
					}
					else if (strcmp(tmpbuf_leveloftrust, "red")==0)
					{
						strcpy(tknrecom, " ");
					}
					else 
					{
						strcpy(tknrecom, " ");
					}
					
					p_buf = tmpbuf + 2;
					memstrscpy(p_buf, tknrecom, 1);
				}
			}
		}
	}
	
	if (SUCCEED==ret)
	{
		if (F_pres(p_fb, BPDTKN_STORAGEID, 0))
		{
			if (SUCCEED != CF_get(p_fb, BPDTKN_STORAGEID, 0, tmpbuf_storageid, 0L, FLD_STRING))
			{
				DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_STORAGEID from FB" ));
				ret = FAIL;
			}
			p_buf = tmpbuf + 5;
			memstrscpy(p_buf, tmpbuf_storageid, 8);
		}
	}
	
	memstrscpy(out, tmpbuf, len);

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFuserData07_prov
 *
 * Purpose	: Build Falcon field `userData07` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: userData07
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData07_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	
	char tmpbuf[60];
	char *p;
	
	if (F_pres(p_fb, BPDTKN_STORAGEID, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_STORAGEID, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_STORAGEID from FB" ));
			ret = FAIL;
		}
		else
		{
			if (strlen(tmpbuf)>8)
			{
				p = tmpbuf + 8;
				
				memstrscpy(out, p, len);
			}
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData03_prov
 *
 * Purpose	: Build Falcon field `userData03` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: userData03
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData03_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[50];

	if (F_pres(p_fb, BPDTKN_SOURCEIP, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_SOURCEIP, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_SOURCEIP from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFuserData05_prov
 *
 * Purpose	: Build Falcon field `userData05` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: userData05
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData05_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[50];

	if (F_pres(p_fb, BPDTKN_REASONCODES, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_REASONCODES, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_REASONCODES from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserIndicator07_prov
 *
 * Purpose	: Build Falcon field `userIndicator07` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: userIndicator07
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserIndicator07_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	char capturemethod[20];
	char maxcurdev[10];
	
	char tmpbuf[20];
	char tmpbuf1[10];
	char tmpbuf2[10];
	
	memset(capturemethod, 0, sizeof(capturemethod));
	memset(maxcurdev, 0, sizeof(maxcurdev));
	
	memset(tmpbuf, 0, sizeof(tmpbuf));
	memset(tmpbuf1, 0, sizeof(tmpbuf1));
	memset(tmpbuf2, 0, sizeof(tmpbuf2));

	strcpy(tmpbuf1, "00");

	if (F_pres(p_fb, BPDTKN_MAXCURDEV, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_MAXCURDEV, 0, maxcurdev, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_MAXCURDEV from FB" ));
		}
		else 
		{
			strcpy(tmpbuf1, maxcurdev);
		}
	}

	strcpy(tmpbuf2, "00");
	
	if (F_pres(p_fb, D_CAPTUREMETHOD, 0))
	{
		if (SUCCEED != CF_get(p_fb, D_CAPTUREMETHOD, 0, capturemethod, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get D_CAPTUREMETHOD from FB" ));
		}
		else 
		{
			if (strcmp(capturemethod, "MANUAL")==0)
				strcpy(tmpbuf2, "01");
			else if (strcmp(capturemethod, "ON-FILE")==0)
				strcpy(tmpbuf2, "02");
			else if (strcmp(capturemethod, "BANK_APP")==0)
				strcpy(tmpbuf2, "03");
			else if (strcmp(capturemethod, "TOKEN")==0)
				strcpy(tmpbuf2, "04");
			else if (strcmp(capturemethod, "CHIP_DIP")==0)
				strcpy(tmpbuf2, "05");
			else if (strcmp(capturemethod, "READER_MODE")==0)
				strcpy(tmpbuf2, "06");
		}
	}

	strcpy(tmpbuf, tmpbuf1);
	strcat(tmpbuf, ",");
	strcat(tmpbuf, tmpbuf2);

	memstrscpy(out, tmpbuf, len);

	return ret;

}


/*------------------------------------------------------------------------
 *
 * Function	: FFuserIndicator06_prov
 *
 * Purpose	: Build Falcon field `userIndicator06` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: userIndicator06
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserIndicator06_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	
	char subtxncode[20];
	memset(subtxncode, 0, sizeof(subtxncode));
	
	char tmpbuf[30];
	memset(tmpbuf, 0, sizeof(tmpbuf));
	
	if (SUCCEED != CF_get(p_fb, N_SUB_TXNCODE, 0, subtxncode, 0L, FLD_STRING))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get N_SUB_TXNCODE from FB" ));
		ret = FAIL;
	}
	else
	{
		if ((strcmp(subtxncode, "TDR")==0) || (strcmp(subtxncode, "TVN3700")==0))
		{
			if (SUCCEED != CF_get(p_fb, D_LEVELOFTRUST, 0, tmpbuf, 0L, FLD_STRING))
			{
				DBG_PRINTF(( dbg_syserr, "Failed to get D_LEVELOFTRUST from FB" ));
				ret = FAIL;
			}
			else 
			{
				if (strcmp(tmpbuf, "green")==0)
				{
					memcpy(out, "G", len);
				}
				else if (strcmp(tmpbuf, "yellow")==0)
				{
					memcpy(out, "Y", len);
				}
				else if (strcmp(tmpbuf, "orange")==0)
				{
					memcpy(out, "O", len);
				}
				else if (strcmp(tmpbuf, "red")==0)
				{
					memcpy(out, "R", len);
				}
				else 
				{
					memcpy(out, " ", len);
				}
			}
		}
		else 
		{
			memcpy(out, " ", len);
		}
	}

	return ret;
}



/*------------------------------------------------------------------------
 *
 * Function	: FFuserIndicator02_prov
 *
 * Purpose	: Build Falcon field `userIndicator02` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: userIndicator02
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserIndicator02_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];

	if (F_pres(p_fb, D_DEVICESCORE, 0))
	{
		if (SUCCEED != CF_get(p_fb, D_DEVICESCORE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get D_DEVICESCORE from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFuserIndicator05_prov
 *
 * Purpose	: Build Falcon field `userIndicator05` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: userIndicator05
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserIndicator05_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];

	if (F_pres(p_fb, BPDTKN_WALLETSCORE, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_WALLETSCORE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_WALLETSCORE from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFtransactionAmount_prov
 *
 * Purpose	: Build Falcon field `transactionAmount`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Transaction amount prov - only setting = 0 for provisioning
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtransactionAmount_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (SUCCEED == ret)
	{
		strcpy(tmpbuf, "            0");
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFsegmentId4_prov
 *
 * Purpose	: Build Falcon field `segmentId4`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: segmentId4 - only setting = spaces for provisioning in order to complete the rest of the message
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFsegmentId4_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[30];

	if (SUCCEED == ret)
	{
		strcpy(tmpbuf, "      ");
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}



/*------------------------------------------------------------------------
 *
 * Function	: FFtransactionCurrencyConversionRate_prov
 *
 * Purpose	: Build Falcon field `transactionCurrencyConversionRate`  for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Fixed value '1' in case of provisioning
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtransactionCurrencyConversionRate_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];

	if (SUCCEED == ret)
	{
		strcpy(tmpbuf, "1");
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFmerchantId_prov
 *
 * Purpose	: Build Falcon field `merchantId` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Fixed value '400425000000001' in case of provisioning
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFmerchantId_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[25];

	if (SUCCEED == ret)
	{
		strcpy(tmpbuf, "400425000000001");
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFacquirerCountry_prov
 *
 * Purpose	: Build Falcon field `acquirerCountry` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Fixed value '214' in case of provisioning
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFacquirerCountry_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];

	if (SUCCEED == ret)
	{
		strcpy(tmpbuf, "214");
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFacquirerId_prov
 *
 * Purpose	: Build Falcon field `acquirerId` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Fixed value '423378' in case of provisioning
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFacquirerId_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];

	if (SUCCEED == ret)
	{
		strcpy(tmpbuf, "423378");
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFmcc_prov
 *
 * Purpose	: Build Falcon field `mcc` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Fixed value '6012' in case of provisioning
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFmcc_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];

	if (SUCCEED == ret)
	{
		strcpy(tmpbuf, "6012");
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFtransactionCurrencyCode_prov
 *
 * Purpose	: Build Falcon field `transactionCurrencyCode` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Fixed value '840' in case of provisioning
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtransactionCurrencyCode_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];

	if (SUCCEED == ret)
	{
		strcpy(tmpbuf, "840");
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFmerchantName_prov
 *
 * Purpose	: Build Falcon field `merchantName` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from D_WALLETPROVIDERID field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFmerchantName_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[80];

	if (F_pres(p_fb, D_WALLETPROVIDERID, 0))
	{
		if (SUCCEED != CF_get(p_fb, D_WALLETPROVIDERID, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get D_WALLETPROVIDERID from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFposEntryMode_prov
 *
 * Purpose	: Build Falcon field `posEntryMode` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Fixed value 'E' in case of provisioning
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFposEntryMode_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];

	if (SUCCEED == ret)
	{
		strcpy(tmpbuf, "E");
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFposUnattended_prov
 *
 * Purpose	: Build Falcon field `posUnattended`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Fixed value '1' in case of provisioning
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFposUnattended_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];

	if (SUCCEED == ret)
	{
		strcpy(tmpbuf, "1");
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFexternalScore1_prov
 *
 * Purpose	: Build Falcon field `externalScore1` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Fixed value '0' in case of provisioning
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFexternalScore1_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];

	if (SUCCEED == ret)
	{
		strcpy(tmpbuf, "0");
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFterminalType_prov
 *
 * Purpose	: Build Falcon field `terminalType`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Fixed value ' ' in case of provisioning
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFterminalType_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];

	if (SUCCEED == ret)
	{
		strcpy(tmpbuf, " ");
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFmerchantCountryCode_prov
 *
 * Purpose	: Build Falcon field `merchantCountryCode` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Constant 214
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFmerchantCountryCode_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (SUCCEED == ret)
	{
		strcpy(tmpbuf, "214");
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/* New SendOtp falcon functions */


/*------------------------------------------------------------------------
 *
 * Function	: FFrecordType_prov_otp
 *
 * Purpose	: Build Falcon field `recordType` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - EXT10 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Constant "EXT10"
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFrecordType_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	memcpy(out, "EXT10   ", len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFdataSpecificationVersion_prov_otp
 *
 * Purpose	: Build Falcon field `dataSpecificationVersion` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - EXT10 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Constant "1.0"
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFdataSpecificationVersion_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;

	memcpy(out, "1.0  ", len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFvalidity_prov_otp
 *
 * Purpose	: Build Falcon field `validity` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_PROVATTEMPTONDEV field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFvalidity_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_PROVATTEMPTONDEV, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_PROVATTEMPTONDEV, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_PROVATTEMPTONDEV from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFentityType_prov_otp
 *
 * Purpose	: Build Falcon field `entityType` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from I_CRDSTAT field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFentityType_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];
	FBFR *fb = NULL;

	fb = F_pres(p_fb, I_CRDSTAT, 0) ? p_fb : p_ctx->adddata_fb;

	if (NULL == fb || SUCCEED != CF_get(fb, I_CRDSTAT, 0, tmpbuf, 0L, FLD_STRING))
	{
		DBG_PRINTF(( dbg_syserr, "Failed to get I_CRDSTAT from FB" ));
		ret = FAIL;
	}
	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFextSource_prov_otp
 *
 * Purpose	: Build Falcon field `extSource` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Fixed value 'WALLET OTP DEBITO' in case of provisioning SendOtp
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFextSource_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[30];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	strcpy(tmpbuf, "WALLET OTP DEBITO");
	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFnotificationName_prov_otp
 *
 * Purpose	: Build Falcon field `notificationName` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Fixed value 'SEND OTP REQUEST/RESPONSE' in case of provisioning SendOtp
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFnotificationName_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[30];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));
	
	if (F_pres(p_fb, BPDTKN_OTPRESPONSE, 0))
	{
		strcpy(tmpbuf, "SEND OTP RESPONSE");
		
	}
	else 
	{
		strcpy(tmpbuf, "SEND OTP REQUEST");
	}
	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFnotificationStatus_prov_otp
 *
 * Purpose	: Build Falcon field `notificationStatus` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_OTPRESPONSE field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFnotificationStatus_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[20];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_OTPRESPONSE, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_OTPRESPONSE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_OTPRESPONSE from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFscore1_prov_otp
 *
 * Purpose	: Build Falcon field `score1` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_PHONENUMBERSCORE field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFscore1_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_PHONENUMBERSCORE, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_PHONENUMBERSCORE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_PHONENUMBERSCORE from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFscore2_prov_otp
 *
 * Purpose	: Build Falcon field `score2` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_CARDSCORE field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFscore2_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_CARDSCORE, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_CARDSCORE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_CARDSCORE from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFscore3_prov_otp
 *
 * Purpose	: Build Falcon field `score3` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_SUSPENDCRDSINACC field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFscore3_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_SUSPENDCRDSINACC, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_SUSPENDCRDSINACC, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_SUSPENDCRDSINACC from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData01_prov_otp
 *
 * Purpose	: Build Falcon field `userData01` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_DAYSLASTACCACT field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData01_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_DAYSLASTACCACT, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_DAYSLASTACCACT, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_DAYSLASTACCACT from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFuserData02_prov_otp
 *
 * Purpose	: Build Falcon field `userData02` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_NUMTRANLASTMONTHS field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData02_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_NUMTRANLASTMONTHS, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_NUMTRANLASTMONTHS, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_NUMTRANLASTMONTHS from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData03_prov_otp
 *
 * Purpose	: Build Falcon field `userData03` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_MAXCURDEV field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData03_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_MAXCURDEV, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_MAXCURDEV, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_MAXCURDEV from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData04_prov_otp
 *
 * Purpose	: Build Falcon field `userData04` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_ACTIVETKNSALLDEV field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData04_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_ACTIVETKNSALLDEV, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_ACTIVETKNSALLDEV, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_ACTIVETKNSALLDEV from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData05_prov_otp
 *
 * Purpose	: Build Falcon field `userData05` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_DAYSLASTACCCHG field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData05_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_DAYSLASTACCCHG, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_DAYSLASTACCCHG, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_DAYSLASTACCCHG from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData06_prov_otp
 *
 * Purpose	: Build Falcon field `userData06` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from N_CH_AC_DP_METHOD_ID field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData06_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[50];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, N_CH_AC_DP_METHOD_ID, 0))
	{
		if (SUCCEED != CF_get(p_fb, N_CH_AC_DP_METHOD_ID, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get N_CH_AC_DP_METHOD_ID from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData07_prov_otp
 *
 * Purpose	: Build Falcon field `userData07` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from I_CRDPROD field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData07_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[10];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, I_CRDPROD, 0))
	{
		if (SUCCEED != CF_get(p_fb, I_CRDPROD, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get I_CRDPROD from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData08_prov_otp
 *
 * Purpose	: Build Falcon field `userData08` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from N_OTP_VALUE field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData08_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[20];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, N_OTP_VALUE, 0))
	{
		if (SUCCEED != CF_get(p_fb, N_OTP_VALUE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get N_OTP_VALUE from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData09_prov_otp
 *
 * Purpose	: Build Falcon field `userData09` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_ACCCREATIONDATE field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData09_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[40];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_ACCCREATIONDATE, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_ACCCREATIONDATE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_ACCCREATIONDATE from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData10_prov_otp
 *
 * Purpose	: Build Falcon field `userData10` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_ACCLASTUPDDATE field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData10_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[70];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_ACCLASTUPDDATE, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_ACCLASTUPDDATE, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_ACCLASTUPDDATE from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData12_prov_otp
 *
 * Purpose	: Build Falcon field `userData12` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_ORIGTKNREQID field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData12_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[20];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_ORIGTKNREQID, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_ORIGTKNREQID, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_ORIGTKNREQID from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData14_prov_otp
 *
 * Purpose	: Build Falcon field `userData14` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_SOURCEIP field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData14_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[260];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_SOURCEIP, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_SOURCEIP, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_SOURCEIP from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData15_prov_otp
 *
 * Purpose	: Build Falcon field `userData15` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_TKNRQID field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData15_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[20];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_TKNRQID, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_TKNRQID, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_TKNRQID from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData16_prov_otp
 *
 * Purpose	: Build Falcon field `userData16` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_TONUMMOVIL field in case of provisioning SendOtp
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData16_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[350];
	char methodid[100];
	char * p;
	
	memset(tmpbuf, 0, sizeof(tmpbuf));
	memset(methodid, 0, sizeof(methodid));

	if (F_pres(p_fb, N_CH_AC_DP_METHOD_ID, 0))
	{
		if (SUCCEED != CF_get(p_fb, N_CH_AC_DP_METHOD_ID, 0, methodid, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get N_CH_AC_DP_METHOD_ID from FB" ));
			ret = FAIL;
		}
		else
		{
			DBG_PRINTF(( dbg_progdetail, "N_CH_AC_DP_METHOD_ID[%s]", methodid ));
			
			if (strcmp(methodid, "SMS-1")==0)
			{
				if (!F_pres(p_fb, BPDTKN_TONUMMOVIL, 0) || SUCCEED != CF_get(p_fb, BPDTKN_TONUMMOVIL, 0, (char *)&tmpbuf, 0, FLD_STRING))
				{
					DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_TONUMMOVIL from FB" ));
				}
			}
		}
	}
	memstrscpy(out, tmpbuf, len);

	return ret;
}
	
/*------------------------------------------------------------------------
 *
 * Function	: FFuserData17_prov_otp
 *
 * Purpose	: Build Falcon field `userData17` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_TOEMAIL field in case of provisioning SendOtp
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData17_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[350];
	char methodid[100];
	char * p;
	
	memset(tmpbuf, 0, sizeof(tmpbuf));
	memset(methodid, 0, sizeof(methodid));

	if (F_pres(p_fb, N_CH_AC_DP_METHOD_ID, 0))
	{
		if (SUCCEED != CF_get(p_fb, N_CH_AC_DP_METHOD_ID, 0, methodid, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get N_CH_AC_DP_METHOD_ID from FB" ));
			ret = FAIL;
		}
		else
		{
			DBG_PRINTF(( dbg_progdetail, "N_CH_AC_DP_METHOD_ID[%s]", methodid ));
			
			if (strcmp(methodid, "EMAIL-1")==0)
			{
				if (!F_pres(p_fb, BPDTKN_TOEMAIL, 0) || SUCCEED != CF_get(p_fb, BPDTKN_TOEMAIL, 0, (char *)&tmpbuf, 0, FLD_STRING))
				{
					DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_TOEMAIL from FB" ));
				}
			}
		}
	}
	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData18_prov_otp
 *
 * Purpose	: Build Falcon field `userData18` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_TKNRQMERCHANTID field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData18_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[40];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_TKNRQMERCHANTID, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_TKNRQMERCHANTID, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_TKNRQMERCHANTID from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData27_prov_otp
 *
 * Purpose	: Build Falcon field `userData27` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from D_WALLETPROVIDERID field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData27_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[140];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, D_WALLETPROVIDERID, 0))
	{
		if (SUCCEED != CF_get(p_fb, D_WALLETPROVIDERID, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get D_WALLETPROVIDERID from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData28_prov_otp
 *
 * Purpose	: Build Falcon field `userData28` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_STORAGEID field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData28_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[140];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_STORAGEID, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_STORAGEID, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_STORAGEID from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData29_prov_otp
 *
 * Purpose	: Build Falcon field `userData29` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from N_TKN_REQ_ID field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData29_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[70];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, N_TKN_REQ_ID, 0))
	{
		if (SUCCEED != CF_get(p_fb, N_TKN_REQ_ID, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get N_TKN_REQ_ID from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: FFuserData30_prov_otp
 *
 * Purpose	: Build Falcon field `userData30` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Get value from BPDTKN_CARDHOLDERNAME field
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFuserData30_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[270];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_CARDHOLDERNAME, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_CARDHOLDERNAME, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_CARDHOLDERNAME from FB" ));
			ret = FAIL;
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}



/*------------------------------------------------------------------------
 *
 * Function	: FFtokenId
 *
 * Purpose	: Build Falcon field `tokenId`
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Payment Token
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtokenId(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, BPDTKN_TOKEN, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_TOKEN, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_TOKEN from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}



/*------------------------------------------------------------------------
 *
 * Function	: FFtokenId
 *
 * Purpose	: Build Falcon field `tokenId` for provisioning
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Payment Token
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFtokenId_prov(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[64];

	if (F_pres(p_fb, N_TKN_TOKEN, 0))
	{
		if (SUCCEED != CF_get(p_fb, N_TKN_TOKEN, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get N_TKN_TOKEN from FB" ));
			ret = FAIL;
		}
		memstrscpy(out, tmpbuf, len);
	}

	return ret;
}


/*------------------------------------------------------------------------
 *
 * Function	: FFexternalTransactionId_prov_otp
 *
 * Purpose	: Build Falcon field `externalTransactionId` for provisioning sendOtp
 *
 * Parameters	: p_fb (in) - fielded buffer
 * 		  out (out) - native data
 * 		  len (in) - data length
 * 		  p_ctx (in/out) - DBTRAN25 message context data
 *
 * Returns	: SUCCEED / FAIL
 *
 * Comments	: Client-generated unique transaction ID
 *
 *------------------------------------------------------------------------*/
ctxprivate int FFexternalTransactionId_prov_otp(FBFR *p_fb, char *out, size_t len, DBTRAN25_Context_t *p_ctx)
{
	int ret = SUCCEED;
	char tmpbuf[50];
	
	memset(tmpbuf, 0, sizeof(tmpbuf));

	if (F_pres(p_fb, BPDTKN_OTPRESPONSE, 0))
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_OTP_FAL_SEQ_B, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_OTP_FAL_SEQ_B from FB" ));
			ret = FAIL;
		}
		else
		{
			DBG_PRINTF(( dbg_progdetail, "BPDTKN_OTP_FAL_SEQ_B[%s]", tmpbuf ));
		}
	}
	else
	{
		if (SUCCEED != CF_get(p_fb, BPDTKN_OTP_FAL_SEQ_A, 0, tmpbuf, 0L, FLD_STRING))
		{
			DBG_PRINTF(( dbg_syserr, "Failed to get BPDTKN_OTP_FAL_SEQ_A from FB" ));
			ret = FAIL;
		}
		else
		{
			DBG_PRINTF(( dbg_progdetail, "BPDTKN_OTP_FAL_SEQ_A[%s]", tmpbuf ));
		}
	}

	memstrscpy(out, tmpbuf, len);

	return ret;
}


