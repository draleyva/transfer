/*-----------------------------------------------------------------------
 *
 * File		: fpadsv.c
 *
 * Author	: Ruslans Vasiljevs
 * 
 * Created	: 02/05/2022
 *
 * Purpose	: PAD data collection server
 *
 * Comments	: 
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS.
 *-----------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>

#include <cosvinit.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
ctxpublic char	*srv_module(void) { return "src"; }
ctxpublic char	*srv_name(void) { return "FPADSV"; }
ctxpublic int	fpadsv_init( FILE *fp, char *subsect );
ctxpublic void	fpadsv_uninit();

/*------------------------------------------------------------------------
 *
 * Function	:
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *----------------------------------------------------------------------*/
ctxpublic int  srv_init( FILE *fp, char *subsect )
{
	int ret = SUCCEED;

	srv_dummy();		/* mention this to pull in cosvinit	*/

	ret = fpadsv_init(fp, subsect);

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	:
 *
 * Purpose	:
 *
 * Parameters	:
 *
 * Returns	:
 *
 * Comments	:
 *
 *----------------------------------------------------------------------*/
ctxpublic void  srv_uninit(void)
{
	fpadsv_uninit();
}
