/*-----------------------------------------------------------------------
 * 
 * File		: falcon2ifsm.c
 * 
 * Author	: Ruslans Vasiljevs
 * 
 * Created	: 09/05/2022
 *
 * Purpose	: State machine used by FALCON2 server
 * 
 * Comments	: 
 *
 *-----------------------------------------------------------------------
 * Copyright (c) FIS
 *-----------------------------------------------------------------------*/
/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <poll.h>
#include <unistd.h>
#include <errno.h>

#include <slntp.h>
#include <slnfb.h>
#include <sldbg.h>
#include <slfdbg.h>
#include <slgsm.h>
#include <slstm.h>

#include <cortex.h>
#include <cocrd.fd.h>
#include <coint.fd.h>
#include <cust_prod.fd.h>
#include <cocbf.h>
#include <cocbfdef.h>
#include <comsgtyp.h>
#include <coevent.h>
#include <falcon2cv.h>
#include <falcon2ev.h>
#include <ifevent.h>

#include <gdiinet.h>
#include <gdiev.h>

#include <hoststat.h>
#include <genif.h>
#include <fds.h>

#include <dbfpadrecrh.h>	/* FPADREC_DECISION_CODE_1_BUFFSIZE */

#include <bpd_prod.fd.h>
#include <token.fd.h>

#include <falcon2.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define	BUF_SIZE	2048

#define HOSTNAME_BUFLEN	28
#define HOSTDET_OPTIONS_BUFFSIZE_LOC	65
#define HOSTDET_SUBADDRESS_BUFFSIZE_LOC	17
#define ZERO_TOUTLIM	0

#define POLLERROR(x)    ( POLL_ANYERR & (x) )

/*---------------------------Enums--------------------------------------*/
enum host_states
{
	st_chk_host,
	st_mkrspq,
	st_offline,
	st_msgcnv,
	st_snd_drv,
	st_wait_rsp,
	st_fpadupd,
	st_fpadauth,
	st_return,
	st_error,
	st_tout
};

enum
{
	ev_ok = 0,
	ev_ret,
	ev_err,
	ev_tout,
	ev_faerr,
	ev_signoff,
	ev_prov
};

/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/

ctxprivate void	*M_p_mc;		/* State machine descriptor	*/
ctxprivate char	M_buf[BUF_SIZE];	/* send/receive buffer		*/
ctxprivate int	M_buflen;		/* length of the msg in M_buf	*/
ctxprivate int	M_err;			/* error conditions		*/
ctxprivate char	M_tcp_svc[32];		/* the driver service name	*/
ctxprivate char	M_tcp_host[32];	/* the driver host name	*/
ctxprivate FBFR	*M_p_fb;		/* working fielded buffer	*/
ctxprivate char	M_fifonm[CTX_FILENAME_MAX]; /* name for response FIFO	*/
ctxprivate long	M_rsptime = 0;		/* timeout for the response (in milliseconds)	*/
ctxprivate ctxbool M_updhostst = FALSE;
ctxprivate char	M_hostnm[5] = {EOS};

ctxprivate long M_rsptime_on_seconds = 0; /* timeout for the response (in seconds)	*/
ctxprivate long M_rsptime_off_seconds = 0;

/*---------------------------Prototypes---------------------------------*/

				/* Public functions		*/
ctxpublic int fs_process( FBFR **pp_fb );
ctxpublic int fs_init(char *hostnm, char *srvnm, char *hostname);

				/* State machine functions 	*/
ctxprivate short fs_error( void );
ctxprivate short fs_tout( void );
ctxprivate short fs_fpadauth( void );
ctxprivate short fs_fpadupd( void );
ctxprivate short fs_return( void );
ctxprivate short fs_wait_rsp( void );
ctxprivate short fs_snd_drv( void );
ctxprivate short fs_msgcnv( void );
ctxprivate short fs_mkrspq( void );
ctxprivate short fs_offline( void );
ctxprivate short fs_chk_host( void );

				/* Support functions 		*/
ctxprivate void fs_sigdisp( int sig);
ctxprivate int fs_event( int ev );
ctxprivate int load_db_info(FBFR *p_fb);
ctxprivate int proc_host_touts(void);
ctxprivate int call_service(FBFR **pp_fb, char *svcnm);

ctxprivate short	moveTknField(void);

/*------------------------------------------------------------------------
 *
 * function	:  fs_process
 *
 * purpose	:  entry to the state machine processing the message
 *
 * parameters	:  pp_fb - fielded buffer with all nice goods
 *
 * returns	:  SUCCEED / FAIL
 *
 * comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int	fs_process( FBFR **pp_fb )
{
	ctxprivate ctxbool	first = TRUE;
	ctxprivate		gsm_states st[] =
	{
					/* main state machine		*/
{GST(st_chk_host),	fs_chk_host,	st_error,	NULL},
{GST(st_mkrspq),	fs_mkrspq,	st_error,	NULL},
{GST(st_offline),	fs_offline,	st_error,	NULL},
{GST(st_msgcnv),	fs_msgcnv,	st_error,	NULL},
{GST(st_snd_drv),	fs_snd_drv,	st_error,	NULL},
{GST(st_wait_rsp),	fs_wait_rsp,	st_error,	NULL},
{GST(st_fpadupd),	fs_fpadupd,	st_error,	NULL},
{GST(st_fpadauth),	fs_fpadauth,	st_error,	NULL},
{GST(st_return),	fs_return,	0,		GSM_RETURN},
{GST(st_error),		fs_error,	st_return,	NULL},
{GST(st_tout),		fs_tout,	0,		GSM_RETURN},
	};

	ctxprivate gsm_trans tr[] =
	{
					/* main sm transitions		*/
{st_chk_host,	GEV(ev_ok),	NULL,		st_mkrspq},
{st_chk_host,	GEV(ev_signoff),NULL,		st_offline},
{st_mkrspq,	GEV(ev_ok),	NULL,		st_msgcnv},
{st_offline,	GEV(ev_ok),	NULL,		st_return},
{st_msgcnv,	GEV(ev_ok),	NULL,		st_snd_drv},
{st_snd_drv,	GEV(ev_ok),	NULL,		st_wait_rsp},
{st_snd_drv,	GEV(ev_ret),	NULL,		st_return},
{st_wait_rsp,	GEV(ev_ok),	NULL,		st_fpadupd},
{st_wait_rsp,	GEV(ev_tout),	NULL,		st_tout},
{st_wait_rsp,	GEV(ev_faerr),	NULL,		st_fpadauth},
{st_wait_rsp,	GEV(ev_prov),	NULL,		st_return}, /* new flow provisioning */
{st_fpadauth,	GEV(ev_ok),	NULL,		st_return},
{st_fpadupd,	GEV(ev_ok),	NULL,		st_return},
{FAIL}
	};
	int	ret = SUCCEED;

	M_err = err_allok;
	M_p_fb = *pp_fb;

	load_db_info(*pp_fb);

	M_rsptime_on_seconds = M_rsptime / 1000;
	DBG_PRINTF((dbg_progdetail, "TIMEOUT (miliseconds) set to [%ld]", M_rsptime));
	DBG_PRINTF((dbg_progdetail, "TIMEOUT in seconds -> M_rsptime_on_seconds[%ld] M_rsptime_off_seconds[%ld]", M_rsptime_on_seconds, M_rsptime_off_seconds));
	
	if( first && FAIL != ret )
	{
					/* create state machine		*/
		if( FAIL == ( ret = gsm_new( st, DIM(st)-1, tr, &M_p_mc ) ) )
			fprintf( stderr, "gsm_new failed\n" );
	}

	if( FAIL != ret && first )
		if(DBG_GETLEV() >= dbg_proginfo )
			gsm_debug( M_p_mc, TRUE, "FSM" );

	if( FAIL != ret && first )
		first = FALSE;

	if( FAIL != ret )
		gsm_enter( M_p_mc, st_chk_host );

	*pp_fb = M_p_fb;	/* in case it changed !	*/

	return( M_err == err_allok ? SUCCEED : FAIL );
}

/*------------------------------------------------------------------------
 *
 * Function	:  fs_chk_host
 *
 * Purpose	:  
 *
 * Parameters	:  
 *
 * Returns	:  ev_ok / ev_err
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	fs_chk_host( void )
{
	short	ret = ev_err;
	short	comstate, reqstate, curstate, accok, stmtok;
	int	fn = 0;
	short	rejreas = 0;
	short	fdsaction = FDSSEND_NOTREJ;	/* 4 - FDS rejected notification at upld */

	if (EOS != M_hostnm[0])
	{
		DBG_PRINTF((dbg_progdetail, "Using [%s] hostname from HOSTNAME config parameter", M_hostnm));
		/* Changing I_FDSHOSTNAME from virtual (Load Balance interface hostname)
		 * to the real one which stands behind */
		if (FAIL == CF_chg(M_p_fb, I_FDSHOSTNAME, 0, M_hostnm, 0, FLD_STRING))
		{
			return( ev_err );				/* >>> EARLY RETURN */
		}
	}
	else if (F_pres (M_p_fb, I_HOSTNAME, 0))
	{
		if (FAIL == CF_get( M_p_fb, I_HOSTNAME, 0, M_hostnm, 0, FLD_STRING ))
		{
			return( ev_err );				/* >>> EARLY RETURN */
		}
	}
	else
	{
		DBG_PRINTF((dbg_syserr, "No HOSTNAME!"));
		return( ev_err );					/* >>> EARLY RETURN */
	}

	if( F_pres( M_p_fb, C_FNCODE, 0 ) &&
	   FAIL == ( fn = cbf_get_fncode( M_p_fb ) ) )
		return( ev_err );					/* >>> EARLY RETURN */

	if( SUCCEED == hst_get_hostdet(M_hostnm, &reqstate, &curstate, &comstate,
				       &accok, &stmtok, M_tcp_svc ) )
	{
		if( MFC_NETMGT_SIGN_ON != fn && HRS_OFF_LINE == curstate
		&&  MFC_NETMGT_ECHO != fn )
		{
			ret = ev_signoff;
			DBG_PRINTF((dbg_syserr, "WARNING: issuer signed off, transaction is not rejected"));
		}
		else if( MFC_NETMGT_SIGN_ON != fn && HCS_OFF_LINE == comstate
		&& MFC_NETMGT_ECHO != fn )
		{
			ret = ev_signoff;
			DBG_PRINTF((dbg_syserr, "WARNING: issuer/switch inoperative, transaction is not rejected"));
		}
		else
		{
			M_updhostst = TRUE;
			ret = ev_ok;
		}

		/* Required in FDSUPLDDMN for response verification */
		if (ev_signoff == ret && FBISFDSNOT(M_p_fb))	/* Notification */
		{
			(void)F_chg(M_p_fb, I_FDSACTION, 0, (char *)&fdsaction, 0);
		}
	}
	else
	{
		ret = ev_err;
		DBG_PRINTF((dbg_syserr, "WARNING: system malfunction, transaction is not rejected"));
		rejreas = RJR_IF_HOSTDET;
		(void)F_chg(M_p_fb, I_REJREASON, 0, (char *)&rejreas, 0);

		/* Required in FDSUPLDDMN for response verification */
		if (FBISFDSNOT(M_p_fb))	/* Notification */
		{
			(void)F_chg(M_p_fb, I_FDSACTION, 0, (char *)&fdsaction, 0);
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  fs_mkrspq
 *
 * Purpose	:  Makes response queue, if it's a request/advice excluding
 * 		   networking management/handshake, received from FALCON2SV
 *
 * Parameters	:  
 *
 * Returns	:  ev_ok / ev_err
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	fs_mkrspq( void )
{
	char	*p;
	short	ret = ev_ok;
	long	txmit = 0;
	long	stan;
	
	long	tknlogreqid;
	
	char	strtknlogreqid[20];
	int 	lentkn = 0;
	int		tknpos = 0;
	char * p_tknlogreqid;
	char	strtxmit[20];
	char tmpbuf[40];

	M_fifonm[0] = EOS;

#ifdef TESTMODE
#ifndef TESTMODE_WAITRSP
DBG_PRINTF((dbg_fatal,"TESTMODE! No RSP Q created"));
return ret;
#endif
#endif

	if (!F_pres(M_p_fb, D_WALLETPROVIDERID, 0))
	{
		DBG_PRINTF((dbg_progdetail,"Evaluating CS_FA_TRAN_CODE"));
		
		/* if response or networking management/handshake requests */
		if(F_pres(M_p_fb, CS_FA_TRAN_CODE, 0))
		{
			return ret;
		}
	}
	
	if(F_pres(M_p_fb, D_WALLETPROVIDERID, 0))
	{
		DBG_PRINTF((dbg_progdetail,"Request -> provisioning"));
		
		if (FAIL != CF_get(M_p_fb, N_TKN_LOG_REQ_ID, 0, (char *)&tknlogreqid, (FLDLEN)0, FLD_LONG)
		 && (p = getenv("CTXTMP")) 
		 && FAIL != CF_get(M_p_fb, BPDTKN_TIMELOCAL, 0, (char *)&txmit, (FLDLEN)0, FLD_LONG) )
		{
			memset(tmpbuf, 0, sizeof(tmpbuf));
			
			p_tknlogreqid = strtknlogreqid;
			memset(strtknlogreqid, 0, sizeof(strtknlogreqid));
			sprintf(strtknlogreqid, "%06ld", tknlogreqid);
			
			lentkn = strlen(strtknlogreqid);
			if (lentkn>6)
			{
				tknpos = lentkn - 6;
				p_tknlogreqid = p_tknlogreqid + tknpos;
			}
			
			strcpy(tmpbuf, p_tknlogreqid);
			
			memset(strtxmit, 0, sizeof(strtxmit));
			sprintf(strtxmit, "%06ld", txmit);

			strcat(tmpbuf, strtxmit);
			DBG_PRINTF((dbg_progdetail, "ext_hdr[%s]", tmpbuf));			
			
			/* snprintf(M_fifonm, sizeof(M_fifonm), "%s/falcon2.%06ld%06ld", p, tknlogreqid, txmit); */
			
			snprintf(M_fifonm, sizeof(M_fifonm), "%s/falcon2.", p);
			strcat(M_fifonm, tmpbuf);

			if (FAIL == mkfifo(M_fifonm, 0660))
			{
				DBG_PRINTF((dbg_syserr,
					"Mkfifo %s [%d]", M_fifonm, errno));
				M_fifonm[0] = EOS;
				ret = ev_err;
			}
			else
			{
				DBG_PRINTF((dbg_progdetail,"Creating fifo - provisioning: <%s>", M_fifonm));
			}
		}
		else
		{
			DBG_PRINTF((dbg_syserr, "Error CTXTMP, N_TKN_LOG_REQ_ID or BPDTKN_TIMELOCAL missing"));
			ret = ev_err;
		}
	}
	else 
	{
		DBG_PRINTF((dbg_progdetail,"Request -> transaction"));
		
		if (FAIL != CF_get(M_p_fb, C_STAN, 0, (char *)&stan, (FLDLEN)0, FLD_LONG)
		 && (p = getenv("CTXTMP"))
		 && FAIL != CF_get(M_p_fb, C_TIMEXMIT, 0, (char *)&txmit, (FLDLEN)0, FLD_LONG) )
		{
			snprintf(M_fifonm, sizeof(M_fifonm), "%s/falcon2.%06ld%06ld", p, stan, txmit);

			if (FAIL == mkfifo(M_fifonm, 0660))
			{
				DBG_PRINTF((dbg_syserr,
					"Mkfifo %s [%d]", M_fifonm, errno));
				M_fifonm[0] = EOS;
				ret = ev_err;
			}
			else
			{
				DBG_PRINTF((dbg_progdetail,"Creating fifo: <%s>", M_fifonm));
			}
		}
		else
		{
			DBG_PRINTF((dbg_syserr, "Error CTXTMP, STAN or C_TIMEXMIT missing"));
			ret = ev_err;
		}
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  fs_offline
 *
 * Purpose	:  Call service FPADAUTH then call FDSNTFY service
 * 		   which add transaction to the FDS upload
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	fs_offline( void )
{
	short	ret = ev_ok;

	/* if it's networking management/handshake, received from FALCON2SV */
	if (F_pres(M_p_fb, CS_FA_TRAN_CODE, 0))
	{
		return ret;	/* >>> EARLY RETURN */
	}

	ret = fs_fpadauth();

	/* request notification */
	if (ev_ok == ret && SUCCEED != CF_chg(M_p_fb, CS_FA_FDSNTFY, 0, "1", 0, FLD_STRING))
	{
		DBG_PRINTF((dbg_syserr, "Failed to set CS_FA_FDSNTFY in FB"));
		ret = ev_err;
	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  fs_msgcnv
 *
 * Purpose	:  Converts message FML->native
 *
 * Parameters	:  
 *
 * Returns	:  ev_ok / ev_err
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	fs_msgcnv( void )
{
	short	ret = ev_ok;
	FLDLEN	len;
	short	rejreas = 0;

	M_buflen = 0;

	if( SUCCEED != falcon2cvout( M_p_fb ) )
	{
		M_err = err_msgcnv;
		DBG_PRINTF((dbg_syserr, "WARNING: format error, transaction is not rejected"));
		rejreas = RJR_IF_MSGCVOUT;
		(void)F_chg(M_p_fb, I_REJREASON, 0, (char *)&rejreas, 0);
		ret = ev_err;
	}

	if( ev_ok == ret )
	{
		memset( M_buf, 0, sizeof(M_buf) );
		len = 0;
	}

	if( ev_ok == ret && FAIL == F_get( M_p_fb, I_NATMSG, 0, M_buf, &len ) )
	{
		M_err = err_missfld;
		DBG_PRINTF((dbg_syserr, "WARNING: system malfunction, transaction is not rejected"));
		rejreas = RJR_IF_NONATMSG;
		(void)F_chg(M_p_fb, I_REJREASON, 0, (char *)&rejreas, 0);
		ret = ev_err;
	}

	if( ev_ok == ret )
	{
		M_buflen = len;		
	}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	:  fs_snd_drv
 *
 * Purpose	:  send converted message to driver
 *
 * Parameters	:  
 *
 * Returns	:  ev_ok / ev_err
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	fs_snd_drv( void )
{
	short	ret = ev_ok;
	short	rejreas = 0;
	short	fdsaction = FDSSEND_NOTREJ;	/* 4 - FDS rejected notification at upld */

#ifdef TESTMODE
DBG_PRINTF((dbg_fatal,"TESTMODE! Not really sent outside"));
#else
	if(FAIL == gdinet_snd(M_buf, M_buflen, M_tcp_host, M_tcp_svc, &M_err))
	{
		DBG_PRINTF((dbg_syserr, "WARNING: failed to send to driver, transaction is not rejected"));
		rejreas = RJR_IF_SENDDRV;
		(void)F_chg(M_p_fb, I_REJREASON, 0, (char *)&rejreas, 0);

		/* Required in FDSUPLDDMN for response verification */
		if (FBISFDSNOT(M_p_fb))	/* Notification */
		{
			(void)F_chg(M_p_fb, I_FDSACTION, 0, (char *)&fdsaction, 0);
		}

		M_err = err_putev;
		ret = ev_err;
	}
#endif
	/* if it's networking management/handshake, received from FALCON2SV */
	if (F_pres(M_p_fb, CS_FA_TRAN_CODE, 0))
	{
		if (ev_err == ret)
		{
			cbf_gen_rsp(M_p_fb, MAC_ERROR, MRS_RRSP_MALSYS);
		}
		else
		{
			/* do not wait for network management response */
			ret = ev_ret;		
		}
	}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	:  fs_tout
 *
 * Purpose	:  return.
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	fs_tout( void )
{
	short	ret = ev_ok;
	short	fdsaction;

	DBG_PRINTF((dbg_proginfo, "Timeout occurs"));

	DBG_PRINTF(( dbg_progdetail,"M_err: %d",M_err));

	if (SUCCEED != F_get(M_p_fb, I_FDSACTION, 0, (char *)&fdsaction, 0L))
	{
		DBG_PRINTF((dbg_syserr, "Failed to get I_FDSACTION from FB"));
		ret = ev_err;
	}
	else if (FDSSEND_REQUEST == fdsaction)
	{
		DBG_PRINTF((dbg_proginfo,
			"Timed out on FDS request - "
				"call FPADAUTH to perform authorization against cached PAD database"));

		ret = fs_fpadauth();
	}
	else if (FDSSEND_NOTIFY == fdsaction)
	{
		DBG_PRINTF((dbg_proginfo,
			"Timed out on FDS notification - "
				"rejected"));

		fdsaction = FDSSEND_NOTREJ;
		if (SUCCEED != F_chg(M_p_fb, I_FDSACTION, 0, (char *)&fdsaction, 0))
		{
			DBG_PRINTF((dbg_syserr, "Failed to change I_FDSACTION in FB"));
			ret = ev_err;
		}
	}

	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  fs_fpadauth
 *
 * Purpose	:  Call service FPADAUTH
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	fs_fpadauth( void )
{
	short	ret = ev_ok;

	if (!FBISCBREV(M_p_fb) && SUCCEED != call_service(&M_p_fb, "FPADAUTH"))
	{
		ret = ev_err;
	}

	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  fs_fpadupd
 *
 * Purpose	:  Check response code from Falcon and call service FPADUPD
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	fs_fpadupd( void )
{
	short	ret = ev_ok;
	FLDOCC	occ = 0;
	int i;
	char decision_code[FPADREC_DECISION_CODE_1_BUFFSIZE] = {EOS};
	char act_code;
	char rsp_code[3] = {EOS};
static	char def_act_code = EOS;
static	char def_rsp_code[3] = {EOS};
	char fn;
	int	sz;
	
	char crdstatcodeupd[10];
	memset(crdstatcodeupd, 0, sizeof(crdstatcodeupd));
	
	DBG_PRINTF((dbg_progdetail, "fs_fpadupd..."));

	FBFR *p_fb_copy = NULL;
	FLDID rspflds[]  =
	{
		C_ACTIONCODE,
		C_RSPCODE,
		I_REJREASON,
		I_REJMSG,
		I_REJFILE,
		I_RSPSRC,
		BADFLDID
	};

	if (FBISCBREV(M_p_fb))
	{
		DBG_PRINTF((dbg_proginfo, "Not processing FALCON response for reversal..."));
		return ret;
	}

	sz = F_sizeof(M_p_fb);
	if ( !(p_fb_copy = (FBFR *)ntp_alloc("FML", NULL, sz + 64)) )
	{
		DBG_PRINTF((dbg_syserr, "tp_alloc fail %d %s",
			ntp_errno(), ntp_strerror(ntp_errno())));
		ret = ev_err;
		goto out;
	}
	else
	{
		if (0 > F_cpy(p_fb_copy, M_p_fb))
		{
			DBG_PRINTF((dbg_syserr,"Failed to F_cpy() %d (%s)",
				ntp_tperrno(), ntp_strerror(ntp_tperrno())));
			ret = ev_err;
			goto out;
		}
	}

	if (FBISRSP(p_fb_copy))
	{
		if (SUCCEED != F_projdel(p_fb_copy, rspflds))
		{
			DBG_PRINTF((dbg_syserr,"Failed to F_projdel() %d (%s)",
				ntp_tperrno(), ntp_strerror(ntp_tperrno())));
			ret = ev_err;
			goto out;
		}

		if (SUCCEED != CF_get(p_fb_copy, C_MSGFN, 0, &fn, 0, FLD_CHAR))
		{
			DBG_PRINTF((dbg_syserr,"Failed to get C_MSGFN from FB"));
			ret = ev_err;
			goto out;
		}
		--fn; /* change response to request */
		if (SUCCEED != CF_chg(p_fb_copy, C_MSGFN, 0, &fn, 0, FLD_CHAR))
		{
			DBG_PRINTF((dbg_syserr,"Failed to set C_MSGFN in FB"));
			ret = ev_err;
			goto out;
		}
	}
	
	occ = F_occur(p_fb_copy, CS_FA_DECISION_CODE);
	
	for (i = 0; i < occ; i++)
	{
		if (SUCCEED != F_get(p_fb_copy, CS_FA_DECISION_CODE, i, decision_code, 0L))
		{
			DBG_PRINTF((dbg_syserr, "Failed to get CS_FA_DECISION_CODE[%d] from FB", i));
			ret = ev_err;
			break;
		}

		DBG_PRINTF((dbg_progdetail, "decision_code: [%s]", decision_code));
		
		if (EOS == decision_code[0])
		{
			DBG_PRINTF((dbg_progdetail, "Skipped"));
			continue;
		}
		
		if (NULL != falconcode2rsp(decision_code, &act_code, rsp_code))
		{
			DBG_PRINTF((dbg_progdetail, "action/rspcode: [%c%s]", act_code, rsp_code));
			if (MAC_AUTH_APP != act_code)
			{
				cbf_gen_rsp(M_p_fb, act_code, rsp_code);
				cbf_gen_rsp(p_fb_copy, act_code, rsp_code);
			}
			if (FBISREJ(p_fb_copy))
			{
				break;		
			}
		}
		else
		{
			DBG_PRINTF((dbg_syswarn, "[%s] is not found in CODE2RSP, then search for default (*)", 
				decision_code));

			if (EOS == def_act_code)
			{
				/* Search for default */
				if (NULL == falconcode2rsp("*", &def_act_code, def_rsp_code))
				{
					DBG_PRINTF((dbg_syswarn, "Default action/rspcode code is not found "
						"in CODE2RSP"));
				}
			}

			if (EOS != def_act_code)
			{
				DBG_PRINTF((dbg_progdetail, "Default action/rspcode: [%c%s]", 
					def_act_code, def_rsp_code));
				cbf_gen_rsp(M_p_fb, act_code, rsp_code);
				cbf_gen_rsp(p_fb_copy, def_act_code, def_rsp_code);
			}
		}
	}
	
	if (ev_ok == ret)
	{
		if (SUCCEED != call_service(&p_fb_copy, "FPADUPD"))
		{
			ret = ev_err;
		}
	}
	
	if (F_pres(p_fb_copy, CS_FA_CRDSTATCODEUPD, 0))
	{
		/* DBG_PRINTF((dbg_progdetail, "CS_FA_CRDSTATCODEUPD exist")); */
		
		if (SUCCEED == CF_get(p_fb_copy, CS_FA_CRDSTATCODEUPD, 0, crdstatcodeupd, 0, FLD_STRING))
		{
			DBG_PRINTF((dbg_progdetail,"CS_FA_CRDSTATCODEUPD[%s]", crdstatcodeupd));

			if (SUCCEED != CF_chg(M_p_fb, CS_FA_CRDSTATCODEUPD, 0, crdstatcodeupd, 0, FLD_STRING))
			{
				DBG_PRINTF((dbg_syserr,"Failed to update CS_FA_CRDSTATCODEUPD in M_p_fb"));
				ret = ev_err;
				goto out;
			}
			else 
			{
				DBG_PRINTF((dbg_progdetail,"CS_FA_CRDSTATCODEUPD updated in M_p_fb"));
			}

		}
	}
	
out:

	if (NULL != p_fb_copy)
	{
		ntp_free((char *)p_fb_copy);
	}

	return(ret);
}

/*------------------------------------------------------------------------
 *
 * Function	:  fs_wait_rsp
 *
 * Purpose	:  Wait for response on FIFO, if appropriate
 *
 * Parameters	:  
 *
 * Returns	:  ev_ok  - Response received
 *		   ev_err - Error
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	fs_wait_rsp( void )
{
	FBFR	*p_tmp_fb = NULL;
	
	int fd;
	int	nb;
	int	sz;
	short	ret = ev_ok;
	short	outbtchtype = OB_ONLHOSTBTCH;
	char 	fa_error_code[4+1] = {EOS};
	char	szbuf[128];

	char	trancode[9+1] = {EOS};
	
	int ret2 = 0;

#ifdef TESTMODE
#ifndef TESTMODE_WAITRSP
DBG_PRINTF((dbg_fatal,"TESTMODE! Not really waiting response"));
return ret;
#endif
#endif
	if (!M_fifonm[0])
	{
		return ret;
	}

	DBG_PRINTF(( dbg_progdetail, "fs_wait_rsp 3" ));
	
	/* alarm(rtc_get_timer_val_bzwbk(M_p_fb, M_rsptime_on_seconds, M_rsptime_off_seconds));	*/
	alarm(M_rsptime_on_seconds);
	
	/* NOTE: open on a pipe with RDONLY waits until there	*/
	/* is a writer on the other end - how convenient !	*/
	fd = open(M_fifonm, O_RDONLY);
	alarm(0);
	if (FAIL == fd)
	{
		DBG_PRINTF((dbg_syserr, "Open fifo timeout %s",
				strerror(errno)));
		ret = ev_tout;
	}
	else
	{
		sz = (int)F_sizeof(M_p_fb);
		if (!(p_tmp_fb = (FBFR *)ntp_alloc("FML", NULL, sz+64)))
		{
			DBG_PRINTF((dbg_syserr, "tp_alloc fail %d %s",
				ntp_errno(), ntp_strerror(ntp_errno())));
			ret = ev_err;
		}
		else if (FAIL == (nb = (int)read(fd, (char *)p_tmp_fb, sz+64)))
		{
			DBG_PRINTF((dbg_syserr, "read fail %d", errno));
			ret = ev_err;
		}
		else if (FAIL == F_index(p_tmp_fb, 1))
		{
			DBG_PRINTF((dbg_syserr, "F_index fail %d %s",
				    F_errno(), F_strerror(F_errno())));
			ret = ev_err;
		}
/******* Do *NOT* use extread, it gives truncation problems !!!
		else if (FAIL == F_extread(p_tmp_fb, fp))
		{
			DBG_PRINTF((dbg_syserr, "F_extread fail %d %s",
				F_errno(), F_strerror(F_errno())));
			ret = ev_err;
		}
***/
		else
		{
			DBG_PRINTF((dbg_progdetail,
				"read %d bytes into %d+64", nb, sz));
			
			if (F_pres(M_p_fb, C_MSGCLS, 0) && F_pres(p_tmp_fb, C_MSGCLS, 0))
			{
				/* Use original message class for response if present */
				F_del(p_tmp_fb, C_MSGCLS, 0);
			}

			if(FAIL == F_update(M_p_fb, p_tmp_fb))
			{
				DBG_PRINTF((dbg_syserr,
					"Fupdate %d - %s", F_errno(),
					F_strerror(F_errno()) ));
				ret = ev_err;
			}
			
			if ( ev_err != ret )
			{
				if (SUCCEED != F_get(M_p_fb, CS_FA_TRAN_CODE, 0, trancode, 0L))
				{
					DBG_PRINTF((dbg_syserr,
						"Failed to get CS_FA_TRAN_CODE from FB"));
					ret = ev_err;
				}
				else
				{
					DBG_PRINTF((dbg_progdetail, "trancode[%s]", trancode));
				}
			}

			if ( ev_err != ret )
			{
				if (SUCCEED != F_get(M_p_fb, CS_FA_ERROR_CODE, 0, fa_error_code, 0L))
				{
					DBG_PRINTF((dbg_syserr,
						"Failed to get CS_FA_ERROR_CODE from FB"));
					ret = ev_err;
				}
			}

			/*
			DBG_DUMPFB(dbg_progdetail, "temporal 1 Output FB:", M_p_fb);
			DBG_DUMPFB(dbg_progdetail, "temporal 2 Output FB:", p_tmp_fb);
			*/
			if (!F_pres(M_p_fb, D_WALLETPROVIDERID, 0))
			{
				DBG_PRINTF(( dbg_progdetail, "not provisioning" ));
				
				if ( ev_err != ret 
					 && EOS != fa_error_code[0] 
					 && 0 != strcmp("0", fa_error_code)
					&& 0 != strcmp("00", fa_error_code)
					   && 0 != strcmp("000", fa_error_code)
						  && 0 != strcmp("0000", fa_error_code) )
				{
					long tlogid = 0;
					F_get(M_p_fb, I_TLOGID, 0, (char*)&tlogid, 0L);

					sprintf(szbuf, "Transaction scoring failed with [%s] for tlogid %ld",
						fa_error_code, tlogid);
					ev_call(IFEVTAG_FA2SCORINGERR, szbuf);
					
					ret = ev_faerr; /* to call FPADAUTH */
				}
			}
			else
			{
				ret2 = moveTknField();
			}

			ntp_free((char *)p_tmp_fb);
					
		}
	}

	(void)close(fd);

	unlink(M_fifonm);
	M_fifonm[0] = EOS;

	/* Timeout processing */
	if (ev_tout == ret)
	{
		DBG_PRINTF((dbg_syswarn, "WARNING: response timed out, transaction is not rejected"));
		DBG_PRINTF((dbg_syswarn, "WARNING: leaving as it is in order to prevent duplicate sending to Falcon"));
		fs_event( err_rsptout );

		if (SUCCEED != proc_host_touts() )
		{
			ret = ev_err;
		}
	}
	else if (ev_ok == ret || ev_faerr == ret)
	{
		/* Resetting HOSTDET.consecutive_touts counter in case we get a timely response message */
		DBG_PRINTF((dbg_progdetail, "Resetting [%s] host time-outs", M_hostnm));
		if (SUCCEED != hst_reset_touts(M_hostnm) )
		{
			ret = ev_err;
		}
	}
	else
	{
		/* Unsupported/unknown ret */
	}

	if ((ev_ok == ret || ev_faerr == ret) && FBISRSP(M_p_fb) && FBISNETMGT(M_p_fb))
	{
		short	fn;
		char	hostnm[28];

		if( FAIL == CF_get( M_p_fb, I_IFNETADR, 0, hostnm, 0,
				   FLD_STRING ))
			return( ev_err );

		fn = cbf_get_fncode( M_p_fb );

		if( MFC_NETMGT_SIGN_ON == fn )
		{
			if( FAIL == hst_upd_reqcurstat(hostnm, 1, HRS_ON_LINE))
				ret = ev_err;
		}
		else if( MFC_NETMGT_ECHO == fn && TRUE == M_updhostst )
		{
			if( FAIL == hst_upd_comstat( hostnm, 1,
						    HCS_ON_LINE ) )
/*			if( FAIL == hst_upd_curstat( hostnm, 1,
						    HDBCMD_ENABLE ) )
*/				ret = ev_err;
			M_updhostst = FALSE;
		}
		else if( MFC_NETMGT_SIGN_OFF == fn )
			if( FAIL == hst_upd_reqcurstat(hostnm,1,HRS_OFF_LINE))
				ret = ev_err;
	}

	DBG_PRINTF(( dbg_progdetail, "isrsp: %d  !isnetmgt %d", 
		FBISRSP(M_p_fb), !FBISNETMGT(M_p_fb)));

	DBG_PRINTF(( dbg_progdetail, "iscassh: %d  isaprv: %d  isenq: %d",
		    FBISCASH(M_p_fb), FBISAPRV(M_p_fb),	FBISBENQ(M_p_fb)));

	if (ev_ok == ret && FBISRSP(M_p_fb) )
	{
		if( !F_pres(M_p_fb, I_OUTBTCHTYP, 0 ) &&
		    FAIL == CF_chg(M_p_fb, I_OUTBTCHTYP, 0,
				   (char *)&outbtchtype, 0, FLD_SHORT ) )
		{
			ret = ev_err;		
		}
	}
	
	/*
	DBG_DUMPFB(dbg_progdetail, "temporal 3 Output FB:", M_p_fb);
	DBG_DUMPFB(dbg_progdetail, "temporal 4 Output FB:", p_tmp_fb);
	*/
	if (F_pres(M_p_fb, D_WALLETPROVIDERID, 0))
	{
		DBG_PRINTF(( dbg_progdetail, "provisioning -> ev_prov" ));
		
		ret = ev_prov;
	}

	return( ret );
}


/*--------------------------------------------------------------------------
 *
 * function	: moveTknField
 *
 * purpose	: copy/restore C_TIMEXMIT to BPDTKN_TIMELOCAL and C_STAN to N_TKN_LOG_REQ_ID 
 *
 * parameters	: void
 *
 * returns	: SUCCEED /FAIL
 *
 * comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate short	moveTknField(void)
{
	short ret = SUCCEED;
	
	char timelocal[50];
	memset(timelocal, 0, sizeof(timelocal));
	
	long tknlogreqid = 0;
	
	if (F_pres(M_p_fb, D_WALLETPROVIDERID, 0))
	{
		DBG_PRINTF((dbg_progdetail, "moveTknField provisioning..."));
		
		if (F_pres(M_p_fb, C_TIMEXMIT, 0))
		{
			if (SUCCEED != CF_get(M_p_fb, C_TIMEXMIT, 0, (char *)timelocal, 0, FLD_STRING))
			{
				DBG_PRINTF((dbg_syserr, "can not get C_TIMEXMIT"));
				return FAIL;
			}
			
			if (SUCCEED != F_chg(M_p_fb, BPDTKN_TIMELOCAL, 0, (char *)timelocal, 0 ))
			{
				DBG_PRINTF((dbg_syserr, "can not update BPDTKN_TIMELOCAL [%s]", timelocal));
				return FAIL;
			}
			
			DBG_PRINTF((dbg_progdetail, "BPDTKN_TIMELOCAL updated [%s]", timelocal));
			
			F_del(M_p_fb, C_TIMEXMIT, 0);
			
			DBG_PRINTF((dbg_progdetail, "C_TIMEXMIT deleted"));
		}
		else
		{
			DBG_PRINTF((dbg_progdetail, "C_TIMEXMIT not present"));
		}
		
		if (F_pres(M_p_fb, C_STAN, 0))
		{
			if (SUCCEED != CF_get(M_p_fb, C_STAN, 0, (char *)&tknlogreqid, 0, FLD_LONG))
			{
				DBG_PRINTF((dbg_syserr, "can not get C_STAN"));
				return FAIL;
			}
			/*
			if (SUCCEED != CF_chg(M_p_fb, N_TKN_LOG_REQ_ID, 0, (char *)&tknlogreqid, 0L, FLD_LONG))
			{
				DBG_PRINTF((dbg_syserr, "can not update N_TKN_LOG_REQ_ID [%d]", tknlogreqid));
				return FAIL;
			}
			
			DBG_PRINTF((dbg_progdetail, "N_TKN_LOG_REQ_ID updated [%ld]", tknlogreqid));
			*/
			F_del(M_p_fb, C_STAN, 0);
			
			DBG_PRINTF((dbg_progdetail, "C_STAN deleted"));
		}
		else
		{
			DBG_PRINTF((dbg_progdetail, "C_STAN not present"));
		}
	}
	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	:  fs_return
 *
 * Purpose	:  return to the caller
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	fs_return( void )
{

#ifdef TESTMODE
DBG_PRINTF((dbg_fatal,"TESTMODE! Not really Returning"));
return SUCCEED;
#endif
	DBG_PRINTF(( dbg_progdetail,"M_err: %d",M_err));

	return( M_err == err_allok ? SUCCEED : FAIL );
}

/*------------------------------------------------------------------------
 *
 * Function	:  fs_error
 *
 * Purpose	:  error handling
 *
 * Parameters	:  
 *
 * Returns	:  
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate short	fs_error( void )
{
	short	ret = ev_ok;

				/* prepare NAK msg - needs filling in */

				/* generate event */
	fs_event( M_err );

	if (M_fifonm[0])
	{
		unlink(M_fifonm);	/* just in case			*/
		M_fifonm[0] = EOS;
	}

	return( ret );
}

/*------------------------------------------------------------------------
 *
 * function	: fs_sigdisp
 *
 * purpose	: react on signal (no more hanging)
 *
 * parameters	: sig - signal which caused interrupt
 *
 * returns	: 
 *
 * Comments	:
 *
 *------------------------------------------------------------------------*/
ctxprivate void	fs_sigdisp( int sig)
{

	DBG_PRINTF((dbg_progdetail,
		    "!!!!!!!!!!  Interrupted: %d  !!!!!!!!!!", sig ));

	if( SIGALRM == sig )
	{
		signal( SIGALRM, fs_sigdisp );
		DBG_PRINTF((dbg_progdetail, "Alarm signal"));
	}

	if( SIGTERM == sig || SIGQUIT == sig || SIGINT == sig )
	{
		DBG_PRINTF((dbg_progdetail, "Killed by signal %d - exiting",
			    sig ));
		exit( 1 );
	}
	return;
}

/*--------------------------------------------------------------------------
 *
 * Function	: fs_init
 *
 * purpose	:  create network access point
 *
 * parameters	:  hostnm - network name of the host running driver
 *
 * returns	:  SUCCEED / FAIL
 *
 * comments	:  
 *
 *----------------------------------------------------------------------*/
ctxpublic int	fs_init(char *hostnm, char *srvnm, char *hostname)
{
	int	ret = SUCCEED;

	if( hostnm != NULL )
		strcpy( M_tcp_host, hostnm );
	else
		M_tcp_host[0] = 0;

	if (EOS != hostname[0])
	{
		strcpy(M_hostnm, hostname);
		DBG_PRINTF((dbg_progdetail, "HOSTNAME set to [%s]", M_hostnm));
	}
	
	signal( SIGTERM, fs_sigdisp );
	signal( SIGQUIT, fs_sigdisp );
	signal( SIGINT,  fs_sigdisp );
	signal( SIGALRM, fs_sigdisp );

	{
		int	i;

		for( i = 0; i < 32; i++ )
			signal( i, fs_sigdisp );
	}
	return( ret );
}

/*------------------------------------------------------------------------
 *
 * Function	:  fs_event
 *
 * Purpose	:  Log an error
 *
 * Parameters	:  ev - event type
 *
 * Returns	:  SUCCEED / FAIL
 *
 * Comments	:  
 *
 *----------------------------------------------------------------------*/
ctxprivate int	fs_event( int ev )
{
	int	ret = SUCCEED;
	char	szife[9];

	switch( ev )
	{
		case err_connect:
			ret = ev_call( EVTAG_LANERR, M_tcp_svc );
			break;

		case err_missfld:
		case err_msgcnv:
			ret = ev_call( EVTAG_MSGCONV, M_tcp_svc );
			break;

		case err_getev:
		case err_putev:
		case err_sndmsg:
			ret = ev_call( EVTAG_LOWCOM, M_tcp_svc );
			break;
		case err_rsptout:
			if (SUCCEED == ret) 
			{
				if (SUCCEED != CF_get(M_p_fb, I_IFE,
						 0, szife, 0, FLD_STRING))
				ret = FAIL;
			}

			ret = ev_call( EVTAG_TIMEOUT, szife );
			break;

		default:
			DBG_PRINTF(( dbg_syserr,"Invalid event: %d", ev ));
			ret = FAIL;
			break;
	}

	return ret;
}

/*--------------------------------------------------------------------------
 *
 * Function	: load_db_info
 *
 * Purpose	: Load additional info from database
 *
 * Parameters	: p_fb - fielded buffer
 *
 * Returns	: SUCCEED/FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int load_db_info(FBFR *p_fb)
{
	int	ret = SUCCEED;
	FBFR	*p_tmp_fb = NULL;
	unsigned used_size;

	FLDID	req_flds[]  =
	{
		I_FDSHOSTNAME,
		I_CRDDET_ID,
		C_PAN,
		C_CRDSEQNO,
		I_DBGPANFILE,
		BADFLDID
	};

	if (!(p_tmp_fb = (FBFR *)ntp_alloc("FML", NULL, 0)))
	{
		DBG_PRINTF((dbg_syserr, "tp_alloc fail %d %s",
			ntp_errno(), ntp_strerror(ntp_errno())));
		ret = FAIL;
	}
	else if (SUCCEED != F_projupd(p_tmp_fb, p_fb, req_flds))
	{
		DBG_PRINTF((dbg_syserr, "load_db_info: F_projupd failed, error <%s>",
			F_strerror(F_errno())));
		ret = FAIL;
	}
	else if (SUCCEED != F_chg(p_tmp_fb, I_FDSHOSTNAME, 0, M_hostnm, 0L))
	{
		DBG_PRINTF((dbg_syserr, "Failed to set I_FDSHOSTNAME in local FB"));
		ret = FAIL;
	}
	else if (SUCCEED != call_service(&p_tmp_fb, "FALCON2INFO"))
	{
		ret = FAIL;
	}
	else if (SUCCEED != CF_get(p_tmp_fb, CS_FA_WAITTIME, 0, (char *)&M_rsptime, 0L, FLD_LONG))
	{
		DBG_PRINTF((dbg_syserr, "Failed to get CS_FA_WAITTIME from local FB"));
		ret = FAIL;
	}
	else if (SUCCEED != F_projdel(p_tmp_fb, req_flds))
	{
		ret = FAIL;
	}

	used_size = (unsigned)F_used(p_tmp_fb);
	if (used_size>0)
	{
		if (SUCCEED == ret && SUCCEED != CF_chg(p_fb, CS_FA_ADDDATA, 0,
							(char *) p_tmp_fb, used_size, FLD_FML32))
		{
			DBG_PRINTF((dbg_syserr, "Failed to save FB in CS_FA_ADDDATA"));
			ret = FAIL;
		}
	}

	if (NULL != p_tmp_fb)
	{
		ntp_free((char *)p_tmp_fb);
	}

	return( ret );
}

/*--------------------------------------------------------------------------
 *
 * Function	: proc_host_touts
 *
 * Purpose	: Process consecutive timeouts of host
 *
 * Parameters	: void
 *
 * Returns	: SUCCEED/FAIL
 *
 * Comments	: 
 *
 *------------------------------------------------------------------------*/
ctxprivate int proc_host_touts(void)
{
	int	ret = SUCCEED;
	short	reqstate = 0, curstate = 0;
	long	timeoutcount = 0, timeoutlim = 0;
	short	comstate = 0, accok = 0, stmtok = 0, advrecstate = 0;
	char	options[HOSTDET_OPTIONS_BUFFSIZE_LOC] = {EOS};
	char	netaddr[HOSTDET_SUBADDRESS_BUFFSIZE_LOC] = {EOS};

	if (EOS == M_hostnm[0])
	{
		DBG_PRINTF((dbg_syserr, "Invalid hostname"));
		ret = FAIL;
	}
	/* Getting host details from HOSTDET using HOSTSTAT service */
	else if (SUCCEED != hst_get_hostdet_touts_lim(M_hostnm, &reqstate, &curstate, &comstate, &accok, &stmtok,
						 netaddr, options, &advrecstate, &timeoutcount, &timeoutlim))
	{
		DBG_PRINTF((dbg_syserr, "Could not get Host details with (%s) hostname!", M_hostnm));
		ret = FAIL;
	}
	/* HOSTDET.consecutive_touts_lim is not 0 - means enabled, and HOSTDET.reqstate is not offline */
	else if (HCS_OFF_LINE != reqstate
	      && HCS_OFF_LINE != curstate
	      && ZERO_TOUTLIM != timeoutlim)
	{
		if (SUCCEED != hst_increment_touts(M_hostnm) )
		{
			DBG_PRINTF((dbg_syserr, "Could not increment Host (%s) consecutive_touts", M_hostnm));
			ret = FAIL;
		}
		else
		{
			/* Check if counter exceeds the limit */
			if (++timeoutcount >= timeoutlim)
			{
				DBG_PRINTF((dbg_syswarn, "Max timeouts [%ld] from [%ld] reached - "
						"Setting (%s) host OFF-LINE", timeoutcount, timeoutlim, M_hostnm));

				/* Mark host offline.
				 * The counter will be reset during next successful transaction */
				if (SUCCEED != hst_upd_current_stat(M_hostnm, HCS_OFF_LINE) )
				{
					DBG_PRINTF((dbg_syserr, "Could not update current status "
								"with (%s) host name", M_hostnm));
					ret = FAIL;
				}
			}
		}
	}
	else
	{
		DBG_PRINTF((dbg_syswarn, "Timeout processing skipped for (%s) host name. "
					 "reqstate [%d], curstate [%d] should be ON-LINE and consec_tout_lim [%ld] "
					 "should be > 0", M_hostnm, reqstate, curstate, timeoutlim));

	}

	return ret;
}

/*------------------------------------------------------------------------
 *
 * Function	: call_service
 *
 * Purpose	: Call Tuxedo service
 *
 * Parameters	: p_fb - Fielded buffer that used for service call
 * 		  svcnm	- Service to call
 *
 * Returns	: SUCCEED / FALSE
 *
 *------------------------------------------------------------------------*/
ctxprivate int	call_service(FBFR **pp_fb, char *svcnm)
{
	int	ret = SUCCEED;
	long	rsplen = 0L;

	/*
	 * call service
	 */
	DBG_STAR(("ntp_call : %s", svcnm));
	DBG_FLUSH();

	if (FAIL == ntp_call(svcnm,
			     (char *)*pp_fb,
			     0L,
			     (char **)pp_fb,
			     &rsplen,
			     TPNOTRAN))
	{
		DBG_PRINTF((dbg_syserr, "ERROR: "
			"[%s] tpcall failed %d [%s]", svcnm,
			ntp_errno(),ntp_strerror(ntp_errno())));

		ret = FAIL;
	}

	if (0==strcmp(svcnm, "FALCON2INFO"))
	{
		DBG_DUMPFB(dbg_progdetail, "FALCON2INFO response:", *pp_fb);
	}
	else
	{
		DBG_FBDIFFEND(*pp_fb, DIFF_OPEN);
	}
	
	DBG_STAR_PUTS(("Back to FALCON2IF"));
	DBG_FLUSH();

	return (ret);
}
