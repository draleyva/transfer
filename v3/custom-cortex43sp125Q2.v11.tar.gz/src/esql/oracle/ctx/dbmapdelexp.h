/*-----------------------------------------------------------------------
 *
 * File		: dbmapdelexp.h
 *
 * Author	: Alex Butikov
 *
 * Created	: 06-Dec-2010
 *
 * Purpose	: ESQL routines for dbmapdelexp export
 *
 * Comments	: 
 *
 * Ident	: @(#) $Id: //ps/cortex/latam/bpd/c/bpd-2.0/src/esql/oracle/ctx/dbmapdelexp.h#3 $
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __DBMAPDELEXP_H
#define __DBMAPDELEXP_H
/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
extern int dbmapdelexp_bgnscan(long ctxdate);
extern int dbmapdelexp_nxtscan(CRDDELIVINFO_t *p_crddelivinfo);
extern int dbmapdelexp_endscan(void);

#endif

