/*-----------------------------------------------------------------------
 *
 * File		: fkeycat.h
 *
 * Author	: Perl /
 *
 * Created	: 19 Mar 24  07:33
 *
 * Purpose	: Mapping between messages and #defined used in 4GL scripts
 *
 * Comments	:
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __FKEYCAT_H
#define __FKEYCAT_H
/* #ident "%W%   %E%   %U%" */

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Macros-------------------------------------*/


#define UK_ABORT 1
#define UK_GO 2
#define UK_SCREEN 3
#define UK_PRINT 4
#define UK_FILE 5
#define UK_RSTSEL 6
#define UK_RSTREC 7
#define UK_SEELOG 8
#define UK_SETPARM 9
#define UK_EXECMD 10
#define UK_CRON 11
#define UK_TOTALS 12
#define UK_DTLINP 13
#define UK_PRVSCR 14
#define UK_NXTSCR 15
#define UK_CTXEVENT 19
#define UK_MENUHELP 20
#define UK_SUBMENU 21
#define UK_STORE 22
#define UK_TERM 23
#define UK_TERMA50 24
#define UK_RPTPARM 25
#define UK_RPTSECT 26
#define UK_TXNSUMM 27
#define UK_DONE 28
#define UK_ACCOUNT 29
#define UK_CARDS 30
#define UK_CUSTOMER 31
#define UK_ENCTMK 32
#define UK_SUBMENUMH 33
#define UK_HIST 34
#define UK_TERMSCHEME 35
#define UK_EPOSDTL 37
#define UK_FEMAINT 38
#define UK_BRANCH 39
#define UK_TERMATM 40
#define UK_INVTXN 41
#define UK_INVDET 42
#define UK_PAYDET 43
#define UK_AUTOPAY 44
#define UK_EDIT 45
#define UK_VIEW 46
#define UK_REPLEN 47
#define UK_STATUS 48
#define UK_SEND 49
#define UK_IMPORT 50
#define UK_MONITOR 51
#define UK_CRDTYPE 52
#define UK_ALLBERR 53
#define UK_COPY 54
#define UK_TDEFSCH 55
#define UK_ALLSCH 56
#define UK_PRICE 57
#define UK_CREATE 58
#define UK_MAINT 59
#define UK_CALENDAR 60
#define UK_ACT_SUSP 61
#define UK_ENCKEYCHK 62
#define UK_ADDUPD 63
#define UK_ENCGENPART 64
#define UK_ENCENCPART 65
#define UK_EVACK 66
#define UK_TXNDTL 67
#define UK_ACSGRP 68
#define UK_USR 69
#define UK_USRGRP 70
#define UK_GRPPERM 71
#define UK_EXPERM 72
#define UK_ENCGENKEY 73
#define UK_ENCENCZMK 74
#define UK_CRDACC 75
#define UK_REPEAT 76
#define UK_CLEAR 77
#define UK_PRVSTMT 78
#define UK_NXTSTMT 79
#define UK_STMTSTAT 80
#define UK_STMTENT 81
#define UK_STMTENT4 82
#define UK_OTHERCUR 83
#define UK_CCHIST 84
#define UK_AUTHTXN 85
#define UK_REVERSAL 86
#define UK_NEXTTXN 87
#define UK_INQ 88
#define UK_MANAUTH 89
#define UK_CHGBK 90
#define UK_OTHERCUR4 91
#define UK_REPRINT 92
#define UK_MRCHSTMT 93
#define UK_BATCH 94
#define UK_THISSTMT 95
#define UK_EXPF_VISA 96
#define UK_EXPF_CTX 97
#define UK_HOLDREL 98

#ifdef __cplusplus
}
#endif

#endif
