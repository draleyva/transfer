/*-----------------------------------------------------------------------
 *
 * File		: vmcat.h
 *
 * Author	: Perl /
 *
 * Created	: 19 Mar 24  07:33
 *
 * Purpose	: Mapping between messages and #defined used in 4GL scripts
 *
 * Comments	:
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __VMCAT_H
#define __VMCAT_H
/* #ident "%W%   %E%   %U%" */

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Macros-------------------------------------*/


#define VM_VOID_TXN_NO 1
#define VM_VOID 2
#define VM_FORCE_BATCH_NO 3
#define VM_NO_CHEQUES 4
#define VM_CASH_CHQ_GZ 5
#define VM_BTCH_NOTOPEN 6
#define VM_OK_CLOSE 7
#define VM_MUST_AUTH_FIRST 8
#define VM_OK_OPEN 9
#define VM_SUBMENU_ACCOUNT 10
#define VM_SUBMENU_AUTH 11
#define VM_SUBMENU_DECLINE 12
#define TXN_PURCHASE_DSCR 30
#define TXN_DISBURSEMENT_DSCR 31
#define TXN_MAIL_ORDER_DSCR 32
#define TXN_WIRE_TRANSFER_DSCR 33
#define TXN_QUASI_CASH_DSCR 34
#define TXN_TRAV_CHEQUE_DSCR 35
#define INC_ATM_BTCH_OK 40
#define INC_ATM_BTCH_FAIL 41
#define INC_ATM_BTCH_DONE 42
#define INC_ATM_BTCH_RUN_AGAIN_OK 43
#define NO_CACCUR_REC 45

#ifdef __cplusplus
}
#endif

#endif
