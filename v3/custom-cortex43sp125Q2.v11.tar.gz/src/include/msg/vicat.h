/*-----------------------------------------------------------------------
 *
 * File		: vicat.h
 *
 * Author	: Perl /
 *
 * Created	: 19 Mar 24  07:33
 *
 * Purpose	: Mapping between messages and #defined used in 4GL scripts
 *
 * Comments	:
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __VICAT_H
#define __VICAT_H
/* #ident "%W%   %E%   %U%" */

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Macros-------------------------------------*/


#define VI_INTERCHG 1
#define VI_TXNCODE 2
#define VI_AMOUNT 3
#define VI_INVALID_RRN 4
#define VI_CREATE_BTCH 5
#define VI_INVALID_PD 6
#define VI_INVALID_PE 7
#define VI_INVALID_PC 8
#define VI_INVALID_TC 13
#define VI_INVALID_CR 14
#define VI_INVALID_RQ 15
#define VI_INVALID_FE 16
#define VI_SRC_ACQ 17
#define VI_SRC_ISS 18
#define VI_SAME_OGF_AGAIN 19
#define VI_NATIONAL 20
#define VI_INTERNAT 21
#define VI_OK_INCOMING 22
#define VI_OK_OUTGOING 23
#define VI_REPRESENTS_OK 24
#define VI_CHARGEBACKS_OK 25
#define VI_NO_DEBIT_ACCNO 28
#define VI_ARN_START_27 41
#define VI_ARN_BAD_AIID 42
#define VI_ARN_CHECKDIG 43
#define VI_PROVINCE_RQD 44
#define VI_PROVINCE_NO 45
#define VI_USAGE_123 46
#define VI_ATMACC_CASH 47
#define VI_BAD_REIMB 48
#define VI_BAD_SETFLAG 49
#define VIB2L_BASE	50
#define VIB2L_NO_ERROR 50
#define VIB2L_TLOG_WRITE 51
#define VIB2L_VLOG_WRITE 52
#define VIB2L_TCR0LEN 53
#define VIB2L_TCR1LEN 54
#define VIB2L_TCR2LEN 55
#define VIB2L_TCR3LEN 56
#define VIB2L_TCR4LEN 57
#define VIB2L_TCR5LEN 58
#define VIB2L_TCR6LEN 59
#define VIB2L_TXNCODE 60
#define VIB2L_ADDDLEN 61
#define VIB2L_TLOG_READ 62
#define VIB2L_TLOG_DUP 63
#define VIB2L_NONLOCAL 64
#define VISEN_MSGVISA 65
#define VISEN_VISAOK 66
#define VISEN_ERRVISA 67
#define VIL2B_BASE	100
#define VIL2B_NO_ERROR 100
#define VIL2B_TLOG_READ 101
#define VIL2B_FIN_MTC 102
#define VIL2B_REV_MOR 103
#define VIL2B_FIN_MFC 104
#define VIL2B_REV_ISS_MCLORG 105
#define VIL2B_CB_MTC 106
#define VIL2B_CBRV_MTC 107
#define VIL2B_CB_MFC 108
#define VIL2B_RV_MTC 109
#define VIL2B_FEE_MFN 110
#define VIL2B_ADMIN_MFN 111
#define VIL2B_MCL 112
#define VIL2B_ADDDLEN 113
#define VIL2B_ARNLEN 114
#define VIL2B_VLOG_READ 115
#define VIL2B_TCR0_LEN 116
#define VIL2B_TCR1_LEN 117
#define VIL2B_NO_USPROV 118
#define VILFERPT_TAG 150
#define VIITDRPT_TAG 151
#define CCRNWRPT_TAG 152
#define CCFOLRPT_TAG 153
#define CCAPPRPT_TAG 154
#define VISTMRPT_TAG 155
#define CCPBLRPT_TAG 156
#define CCNRWRPT_TAG 157
#define CCDUXRPT_TAG 158
#define CCBVLRPT_TAG 159
#define CCEDRRPT_TAG 160
#define CCLBLRPT_TAG 161
#define CCRAPRPT_TAG 162
#define CCHTXRPT_TAG 163
#define CCCLXRPT_TAG 164
#define CCBALRPT_TAG 165
#define CCNCARPT_TAG 166
#define CCABSRPT_TAG 167
#define CCAPYRPT_TAG 168
#define CCVOORPT_TAG 169
#define	CACCHQDSC_BASE 170
#define CACCHQDSC_0 170
#define CACCHQDSC_1 171
#define CACCHQDSC_9 179
#define CCBOURPT_TAG 180
#define CCPCURPT_TAG 181
#define VIOTDRPT_TAG 182
#define CCODURPT_TAG 183
#define CCDBTRPT_TAG 184
#define CCDDRRPT_TAG 185
#define CCOLIRPT_TAG 186
#define CCINCRPT_TAG 187
#define CCPSMRPT_TAG 188
#define VIEODRPT_TAG 189
#define VIOIDRPT_TAG 190
#define CCCYBRPT_TAG 191
#define CCOVIRPT_TAG 192
#define CCODPRPT_TAG 193
#define CCSTDRPT_TAG 194
#define CCPCMRPT_TAG 195
#define VILFIRPT_TAG 196
#define CCCBZRPT_TAG 197
#define VIDOCRPT_TAG 198
#define CCCHBRPT_TAG 199
#define CCE_COMM_OVER_LIM 200
#define CCE_COMM_FINANCE 201
#define CCE_COMM_REDEEM 202
#define CCE_COMM_OVER_DUE 203
#define CCE_COMM_INTL_SVC 204
#define CCE_COMM_REDEEMABLE 205
#define CCE_COMM_LIFEINS 206
#define CCISFRPT_TAG 220
#define VI_DATE_MMDD 300
#define VI_FEE_NEEDCTRY 301
#define VI_BILLPAY_CTRY 302
#define VI_PAN_DIID 303
#define VI_BAD_FRAUDTYP 304
#define VI_BAD_PROVINCE 305
#define VI_ARN_START_7 306
#define VI_DSTBIN_NOU 307
#define VI_SRCBIN_ONUS 308
#define VI_PAN_ONUS 309
#define VI_ARN_DATERNG 310
#define VI_PAN_NOTONUS 311
#define VI_ARN_ONUS 312
#define VI_ARN_NOTONUS 313
#define VI_NO_CTRY 315
#define VI_DSPREF 360
#define VI_OK_EOY 371
#define VI_EOY_PASS1 372
#define VI_EOY_PASS2 373
#define VI_EOY_AFTER_CYCLE 374
#define VI_ACS_STARTOGF 381
#define VI_ACS_ENDOGF 382
#define VI_ACS_STARTITF 383
#define VI_ACS_ENDITF 384
#define VI_ACS_STARTEOD 385
#define VI_ACS_ENDEOD 386
#define VI_ACS_STARTCYC 387
#define VI_ACS_ENDCYC 388
#define VI_SAME_EOD_AGAIN 389
#define VI_OK_INACT 394
#define VI_INACT_PASS1 395
#define VI_INACT_PASS2 396
#define VI_ACS_STARTINACT 397
#define VI_ACS_ENDINACT 398
#define	VICLT_ERR_BASE 400
#define VICLT_ERR_READMSG 401
#define VICLT_ERR_MSGCNV 402
#define VICLT_ERR_CHK_MSG 403
#define VICLT_ERR_SND_CTX 404
#define VICLT_ERR_SND_3XX 405
#define VICLT_ERR_PROC_600 406
#define VICLT_ERR_SND_8XX 407
#define VICLT_ERR_CHK_3XX 408
#define VICLT_ERR_3XX_OPN 409
#define VICLT_ERR_SYSTEM 410
#define EXPF_CRD_INVALID 420
#define VI_BLIST_DAY 421
#define VI_BLIST_ALREADY 422
#define VI_BLIST_NEXIST 423
#define VI_DISPUTE_NOW 424
#define VI_TXN_PROCD 425
#define VI_SAME_DAC_AGAIN 427
#define VI_OK_DAC 428
#define VI_ACS_STARTDAC 429
#define VI_ACS_ENDDAC 430
#define VI_LIFE_INS 431
#define VI_OK_MONTH 432
#define VI_MONTH_PASS1 433
#define VI_MONTH_PASS2 434
#define VI_ACS_STARTMON 436
#define VI_ACS_ENDMON 437
#define VI_REPRESENTS 438
#define VI_CHARGEBACKS 439
#define VISARSP_BASE	800
#define	VITC_BASE	900
#define VISA_0312_ERR_BASE 10000

#ifdef __cplusplus
}
#endif

#endif
