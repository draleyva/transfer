/*-----------------------------------------------------------------------
 *
 * File		: ibcat.h
 *
 * Author	: Perl /
 *
 * Created	: 19 Mar 24  07:33
 *
 * Purpose	: Mapping between messages and #defined used in 4GL scripts
 *
 * Comments	:
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __IBCAT_H
#define __IBCAT_H
/* #ident "%W%   %E%   %U%" */

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Macros-------------------------------------*/


#define RCPT_ATM_OFF		10
#define	MINISTMT_BASE		40
#define	RCPT_LOGONLY_OFF	50	/* add to lang bse fr logonly 0	*/
#define	RCPT_TCODE_OFF		100	/* add to lang base for tcode 0	*/
#define	RCPT_LANG_OFF		200	/* multiply by lang for base	*/
#define RECEIPT_TOP 1
#define RECEIPT_BOTTOM 2
#define ACC_SEL_SCRFMT 3
#define SPN_MINISTMT_ATM 41
#define SPN_MINISTMT_CHQ 42
#define SPN_MINISTMT_CASH 43
#define SPN_MINISTMT_XFER 44
#define SPN_MINISTMT_SO 45
#define SPN_LOG_0 50
#define SPN_LOG_1 51
#define SPN_LOG_2 52
#define PRINT_TOT_HDR 70
#define PRINT_TOT_DNOM 71
#define PRINT_TOT_LOAD 72
#define PRINT_TOT_DISP 73
#define PRINT_TOT_REM 74
#define PRINT_TOT_BUF1 75
#define PRINT_TOT_BUF2 76
#define PRINT_TOT_BUF3 77
#define PRINT_TOT_BUF4 78
#define PRINT_TOT_PBUF1 79
#define PRINT_TOT_PBUF2 80
#define PRINT_TOT_PBUF3 81
#define PRINT_TOT_PBUF4 82
#define RECEIPT_PARTIAL 83
#define RECEIPT_ZERO 84
#define RECEIPT_REJECTED 85
#define RECEIPT_CAPTURED 86
#define PPD_LINE 87
#define RC_NOT_KNOWN 88
#define SPN_01 101
#define SPN_21 121
#define SPN_24 124
#define SPN_31 131
#define SPN_38 138
#define SPN_40 140
#define SPN_90 190

#ifdef __cplusplus
}
#endif

#endif
