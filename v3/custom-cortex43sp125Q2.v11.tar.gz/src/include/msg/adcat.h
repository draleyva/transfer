/*-----------------------------------------------------------------------
 *
 * File		: adcat.h
 *
 * Author	: Perl /
 *
 * Created	: 19 Mar 24  07:33
 *
 * Purpose	: Mapping between messages and #defined used in 4GL scripts
 *
 * Comments	:
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __ADCAT_H
#define __ADCAT_H
/* #ident "%W%   %E%   %U%" */

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Macros-------------------------------------*/


#define JOB_STATUS_ERR 1
#define FORM_DESCR 2
#define SYSTEM_DESCR 3
#define SUSPEND_DESCR 4
#define ACTIVE_DESCR 5
#define JOB_TYPE_ERR 6
#define CRONTAB_ERR 7
#define INPUT_FORM_ERR 8
#define MISSING_FILE 9
#define MISSING_TASKID 10
#define CRON_HEADER 11
#define CRON_PROMPT 12
#define JOB_FORM 13
#define JOB_SYSTEM 14
#define JOB_ACTIVE 15
#define JOB_SUSPEND 16
#define CRON_MINUTE 17
#define CRON_HOUR 18
#define CRON_DAY_OF_WEEK 19
#define CRON_DAY_OF_MONTH 20
#define CRON_MONTH 21
#define MSC_TYPES 22
#define MSC_TYPERR 23
#define MSC_ONFILE 24
#define MSC_RECORD 25
#define MSC_INVAL_MASK 26
#define CLEARING_DBERR 27
#define CLR_ULOG_UPTO 28
#define CUST_RPT_HDR 29
#define OK_TO_CRON 30
#define SET_JOB_PARMS 31
#define MUST_SET_JOBPARMS 32
#define INV_RPTSRC 33
#define INV_RPTSEL 34
#define ACSRPT_TAG 35
#define ACSLOG_PRINT 36
#define ACSLOG_SCREEN 37
#define ACSLOG_FILE 38
#define DELETE_GRPPERM 39
#define CRON_DUP_NAME 50
#define USRGRP_OPT 51
#define MENU_OPT 52
#define USRRSTR_OPT 53
#define BTCHJOB_ON_FILE 54
#define ACSFORM_NOT_FILE 55
#define GRPPRM_OPT 56
#define CRON_TRAILER 98
#define	AD_SHELL_BASE	99
#define MSG_CTX_USAGE 99
#define MSG_CTX_RUNNING 100
#define MSG_CTX_NO_CLNTS 101
#define MSG_CTX_KILLING 102
#define MSG_CTX_NOT_DEAD 103
#define MSG_CTX_ALRD_RUN 104
#define MSG_CTX_NOT_EXE 105
#define MSG_CTX_STARTING 106
#define MSG_CTX_UNKNOWN 107
#define MSG_CTX_ERR_START 109
#define MSG_CTX_START_PROC 110
#define MSG_CTX_CANNOT_RUN 111
#define MSG_CTXMON_HDR 112
#define MSG_IRSMAIL_ERR_OPEN 113
#define MSG_RUNIRS_LOGON 114
#define MSG_RUNIRS_RPTPATT 115
#define MSG_RUNIRS_SECPATT 116
#define MSG_RUNIRS_RUNPATT 117
#define MSG_RUNIRS_USAGE 118
#define MSG_STARTD_PROC_EXIT 119
#define MSG_STARTD_PROC_INT 120
#define MSG_STARTD_WAITING 121
#define MSG_STARTD_EFORK 122
#define MSG_STARTD_USAGE 123
#define MSG_TUX_USAGE 124
#define MSG_TUX_STDOUT 125
#define MSG_TUX_OPEN 126
#define MSG_TUX_RUN_CMD 127
#define MSG_TUX_INPATT 128
#define MSG_TUX_ERRPATT 129
#define MSG_TUX_START 130
#define MSG_TUX_STOP 131
#define MSG_ZAPLOG_LOGON 132
#define MSG_ZAPLOG_UDMSG 133
#define MSG_ZAPLOG_USAGE 134
#define MSG_LDMSC_USAGE 135
#define MSG_LDMSC_FILE_READ 136
#define MSG_LDMSC_FILE_OPEN 137
#define MSG_LDMSC_U_UNIQNR 138
#define MSG_LDMSC_EXE_SQL 139
#define MSG_SAVEPARAMS_USAGE 140
#define MSG_SAVEPARAMS_ERR_OPEN 141
#define MSG_CLRTMPF_USAGE 145
#define MSG_CLRTMPF_EENV 146
#define MSG_STARTD_PROC_STOP 147
#define MSG_RUNIRS_SAVING 149
#define TOO_MANY_PROMPTS 150
#define TOO_MANY_SECTIONS 151
#define DELETE_DBLOG 152
#define STOP_CORTEX 153
#define BACKUP_DB 154
#define MSG_ARCHLOG_LOGON 155
#define MSG_ARCHLOG_UDMSG 156
#define MSG_ARCHLOG_USAGE 157
#define ERR_TUXADMIN 160

#ifdef __cplusplus
}
#endif

#endif
