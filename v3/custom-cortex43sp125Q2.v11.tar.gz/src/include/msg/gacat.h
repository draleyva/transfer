/*-----------------------------------------------------------------------
 *
 * File		: gacat.h
 *
 * Author	: Perl /
 *
 * Created	: 19 Mar 24  07:33
 *
 * Purpose	: Mapping between messages and #defined used in 4GL scripts
 *
 * Comments	:
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __GACAT_H
#define __GACAT_H
/* #ident "%W%   %E%   %U%" */

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Macros-------------------------------------*/


#define BRNTERM_DEL_FAIL 5
#define TERMSCH_DEL_FAIL 6
#define TERMINAL_DEL_FAIL 8
#define INSERT_TERM_FAIL 9
#define DELETE_TERM_FAIL 10
#define TERM_ON_FILE 11
#define TERMID_8_DIG 12
#define TERMID_NUMERIC 13
#define MUST_8_DIGITS 14
#define TERM_NOT_FILE 15
#define TERMCODE_IN_USE 17
#define INVALID_TERMTYP 18
#define LIVE_FLAG 19
#define TEST_FLAG 20
#define TERMDCC_NUMERIC 21
#define CHOOSE_TDEF_FIRST 22

#ifdef __cplusplus
}
#endif

#endif
