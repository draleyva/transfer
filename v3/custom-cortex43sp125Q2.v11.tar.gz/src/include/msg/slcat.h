/*-----------------------------------------------------------------------
 *
 * File		: slcat.h
 *
 * Author	: Perl /
 *
 * Created	: 19 Mar 24  07:33
 *
 * Purpose	: Mapping between messages and #defined used in 4GL scripts
 *
 * Comments	:
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __SLCAT_H
#define __SLCAT_H
/* #ident "%W%   %E%   %U%" */

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Macros-------------------------------------*/


#define DSCR_LOGON 1
#define DSCR_NO 3
#define DSCR_YES 4
#define UPD_BEFORE_RET 5
#define NO_RECS 6
#define DUP_ERR 7
#define NULL_ERR 8
#define MIS_LANG 9
#define ENV_ERR 10
#define ADD_FAILED 11
#define UPDATE_FAILED 12
#define DELETE_FAILED 13
#define YES_CHAR 14
#define NO_CHAR 15
#define INV_DATE 16
#define STAT_ERR 17
#define AMGR_EXE_ERR 18
#define OPERATION_FAIL 19
#define ADD_REC_FAIL 20
#define FLD_VALID_FAIL 21
#define GREATER_THAN_0 22
#define MUST_BE_NUM 23
#define WARN_LINKED 24
#define DEFAULT_NO 25
#define DIGITS_ONLY 26
#define DEFAULT_YES 27
#define UNKNOWN_STR 28
#define LOSE_MODS 29
#define MAX_STRLEN 30
#define PLS_SAVE_FIRST 31
#define YES_OR_NO 32
#define FIND_FAILED 33
#define TIME_RANGE_6DIG 34
#define QUIT_STR 35
#define TIME_RANGE_4DIG 36
#define NOT_NEGATIVE 37
#define MATCH_REGEX 38
#define IN_PROGRESS 39
#define OPERATION_FAILED 40
#define NO_SUCH_FILE 41
#define OP_SUCCEED 42
#define OP_FAIL 43
#define OP_UNKNOWN 44
#define SP_AND_SP 45
#define VAL_0_15 46
#define ERR_FIND_ACT 47
#define WAIT_FOR_COMP 48
#define REALLY_DELETE_NO 49
#define REALLY_DELETE_YES 50
#define TO_STR 51
#define NOT_YET_CODED 52
#define NOT_MATCH 53
#define FIND_REC_FIRST 54
#define CHARS_ALLOWED 55
#define OP_FAILED_GEN 56
#define FLD_BOOL_VALID_FAIL 57
#define FILE_OPEN_FAIL 58
#define FILE_READ_FILED 59
#define FILE_CLOSE_FAILED 60
#define WARNING_ERRORS 61
#define OPERATION_OK 62
#define LAST_RECORD 63
#define FIRST_RECORD 64
#define FIELD_CONFIRM 65
#define ROLL_BACK_WORK 66
#define TOO_MANY_FOUND 67
#define PERCENT_0_99 68
#define INVALID_SIC 69
#define NOT_APPLICABLE 70
#define NUM_ORDER 71
#define ALPHA_ORDER 72
#define ERRORS_STR 73
#define PRINT_IN_PROG 74
#define WORKING 75
#define REC_PROCESSED 76
#define DSCR_G_EVENT 77
#define DSCR_G_MAIL 78
#define PRMT_EVENT 79
#define MSG_NO_EVENTS 80
#define MUST_BE_8_ALFANUM 81
#define ADDED 82
#define	SSCODES_BASE	300
#define U_SS_UDERB 187
#define U_SS_UDE 188
#define U_SS_RDONLY 189
#define U_SS_DB2A 190
#define U_SS_COLSPEC 192
#define U_SS_SLOGFUL 193
#define U_SS_LOGOFF 194
#define U_SS_DEADLCK 195
#define U_SS_NETER 196
#define U_SS_DBRES 197
#define U_SS_DDMLFL 199
#define U_SS_OVRFLW 200
#define U_SS_DBINT 201
#define U_SS_UNVIEW 202
#define U_SS_DBMOD 203
#define U_SS_RFLD 204
#define U_SS_NOLOG 205
#define U_SS_DBCLS 206
#define U_SS_VRSION 207
#define U_SS_NOAT 208
#define U_SS_SHMV 209
#define U_SS_NOSHM 210
#define U_SS_LMINT 211
#define U_SS_NODEM 213
#define U_SS_HKERR 214
#define U_SS_BTERR 215
#define U_SS_BTOPN 216
#define U_SS_FLCL 217
#define U_SS_TXIL 218
#define U_SS_NTLCK 220
#define U_SS_NONUL 221
#define U_SS_NOCMB 222
#define U_SS_ILTST 223
#define U_SS_NOVAL 224
#define U_SS_NODF 226
#define U_SS_NODB 229
#define U_SS_ILLA 230
#define U_SS_PART 231
#define U_SS_BDNAM 239
#define U_SS_NORID 240
#define U_SS_NOTID 241
#define U_SS_EOSCN 242
#define U_SS_CONV 243
#define U_SS_FUNIP 244
#define U_SS_CMBF 245
#define U_SS_DBLEN 246
#define U_SS_DBTYP 247
#define U_SS_BDSEL 248
#define U_SS_NIMP 250
#define U_SS_BDSCN 251
#define U_SS_S2U 252
#define U_SS_UDFDB 253
#define U_SS_USSER 254
#define U_SS_LMOUT 255
#define U_SS_SMLCK 256
#define U_SS_NOLCK 257
#define U_SS_SMDEL 260
#define U_SS_SMUP 261
#define U_SS_NODEL 262
#define U_SS_NOUP 263
#define U_SS_NOREC 265
#define U_SS_FLSK 271
#define U_SS_FLACS 272
#define U_SS_NOFIL 273
#define U_SS_DIRT 274
#define U_SS_NOMEM 275
#define U_SS_ADDNA 276
#define U_SS_DELNA 277
#define U_SS_UPDNA 278
#define U_SS_FINNA 279
#define U_SS_SYSER 280
#define U_SS_WRACS 281
#define U_SS_STFUL 282
#define U_SS_RMEM 284
#define U_SS_REF 285
#define U_SS_RDACS 286
#define U_SS_NOTUP 288
#define U_SS_NOREF 289
#define U_SS_MXSCN 291
#define U_SS_INTS 292
#define U_SS_KEYRQ 293
#define U_SS_FLOPN 294
#define U_SS_FLCR 295
#define U_SS_DUPK 296
#define U_SS_DUPBT 297
#define U_SS_BDDOM 298
#define U_SS_AFLST 299
#define U_SS_NORM 300
#define U_SS_BDENV 301
#define U_SS_NOCRF 302
#define U_SS_DFCNV 303
#define U_SS_FINAC 304
#define U_SS_NOCUR 305
#define U_SS_NOENV 306
#define U_SS_PROMO 307
#define	SL_SHELL_BASE	400
#define ERR_CTXSYS 400
#define ERR_CTXUSR 401
#define ERR_CTXBIN 402
#define ERR_CTXTMP 403
#define ERR_CTXLANG 404
#define ERR_NULLCH 405
#define DFLT_YES 406
#define DFLT_NO 407
#define ERR_CTXMSG 408
#define TUX_SVCERR_BASE	450
#define TUX_SVC_TPEABORT 451
#define TUX_SVC_TPEBADDESC 452
#define TUX_SVC_TPEBLOCK 453
#define TUX_SVC_TPEINVAL 454
#define TUX_SVC_TPELIMIT 455
#define TUX_SVC_TPENOENT 456
#define TUX_SVC_TPEOS 457
#define TUX_SVC_TPEPERM 458
#define TUX_SVC_TPEPROTO 459
#define TUX_SVC_TPESVCERR 460
#define TUX_SVC_TPESVCFAIL 461
#define TUX_SVC_TPESYSTEM 462
#define TUX_SVC_TPETIME 463
#define TUX_SVC_TPETRAN 464
#define TUX_SVC_TPGOTSIG 465
#define TUX_SVC_TPERMERR 466
#define TUX_SVC_TPEITYPE 467
#define TUX_SVC_TPEOTYPE 468
#define TUX_SVC_TPERELEASE 469
#define TUX_SVC_TPEHAZARD 470
#define TUX_SVC_TPEHEURISTIC 471
#define TUX_SVC_TPEEVENT 472
#define TUX_SVC_TPEMATCH 473
#define TUX_EVENT_BASE	500
#define TUX_EVENT_DISCONIMM 500
#define TUX_EVENT_SVCERR 501
#define TUX_EVENT_SVCFAIL 502
#define TUX_EVENT_SVCSUCC 503
#define TUX_EVENT_DISCON 504
#define TUX_EVENT_SENDONLY 505
#define	DOWSTR_BASE	1000
#define DOWSTR_SUN 1000
#define DOWSTR_MON 1001
#define DOWSTR_TUE 1002
#define DOWSTR_WED 1003
#define DOWSTR_THU 1004
#define DOWSTR_FRI 1005
#define DOWSTR_SAT 1006

#ifdef __cplusplus
}
#endif

#endif
