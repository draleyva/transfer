/*-----------------------------------------------------------------------
 *
 * File		: aacat.h
 *
 * Author	: Perl /
 *
 * Created	: 19 Mar 24  07:33
 *
 * Purpose	: Mapping between messages and #defined used in 4GL scripts
 *
 * Comments	:
 *
 *-----------------------------------------------------------------------
 * Copyright (c) Nomad Software Ltd.
 *-----------------------------------------------------------------------*/
#ifndef __AACAT_H
#define __AACAT_H
/* #ident "%W%   %E%   %U%" */

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Macros-------------------------------------*/


#define UPDATE_ATM_FAIL 1
#define ATM_NEXT_FORM 2
#define OK_DEL_ATM 3
#define NEXT_ATM_ONLY 4
#define BRNTERM_DEL_FAIL 5
#define TERMSCH_DEL_FAIL 6
#define TERMATM_DEL_FAIL 7
#define TERMINAL_DEL_FAIL 8
#define INSERT_TERM_FAIL 9
#define DELETE_TERM_FAIL 10
#define TERM_ON_FILE 11
#define TERMID_8_DIG 12
#define TERMID_NUMERIC 13
#define MUST_8_DIGITS 14
#define TERM_NOT_FILE 15
#define CHOOSE_TERM_FIRST 16
#define TERMCODE_IN_USE 17
#define INVALID_TERMTYP 18
#define LIVE_FLAG 19
#define TEST_FLAG 20
#define TERMDCC_NUMERIC 21
#define OPEN_ONE 22
#define OPEN_ALL 23
#define CLOSE_ONE 24
#define CLOSE_ALL 25
#define CLEAR_STAT 26
#define FIND_ALLOPEN 27
#define FIND_ALLCLOSED 28
#define FIND_ALLGOOD 29
#define FIND_ALLBAD 30
#define FIND_ALLONLINE 31
#define FIND_ALLOFFLINE 32
#define RESET_SELSET_OK 33
#define ATM_RESETTING 34
#define ATM_DENOMS 35
#define SUPV_ON_FILE 36
#define SUPV_NOT_FILE 37
#define SUPVCRD_ON_FILE 38
#define SUPVCRD_NOT_FILE 39
#define HEXDIGITS_ONLY 40
#define NO_QUOTES 41
#define RCPT_LINE_CHANGED 42
#define WELC_LINE_CHANGED 43
#define CNF_ON_FILE 44
#define CNF_NOT_FILE 45
#define CNFID_ON_FILE 46
#define CNFID_NOT_FILE 47
#define DP_2_OR_3 48
#define RNG_0_255 49
#define RNG_1_255 50
#define OPEN_OR_CLOSED 51
#define YN_OR_SPACE 52
#define NO_SUCH_CNF 53
#define ENTRY_ON_FILE 54
#define TRACK_123 55
#define STIDX_07 56
#define MASK_09F 57
#define IDX_SEF 58
#define DIR_FB 59
#define PIN_4_16 60
#define PINBLK_AD 61
#define ENCTYP_08 62
#define PINPAD_0207 63
#define LOCPIN_ADNV 64
#define HEX_16 65
#define PAN_LEN_BETWEEN 66
#define VISA_PAN_13_16 67
#define PINCHK_LE_MAX 68
#define ATACODE_2_4 69
#define ATAFID_0_4 70
#define FIID_6 71
#define VIEW_SCR 72
#define EDIT_SCR 73
#define LOAD_CNF 74
#define CHOOSE_ATM_FIRST 75
#define LANG_0_7 76
#define SCREEN_ON_FILE 77
#define SCREEN_NOT_FILE 78
#define STATE_ON_FILE 79
#define STATE_NOT_FILE 80
#define TABLE_ON_FILE 81
#define TABLE_NOT_FILE 82
#define SCR_IMP_FAILED 83
#define COPY_CNF_FAILED 84
#define INVALID_VALUES 85
#define TERMCODE_NOT_EXIST 86
#define		DVC_STAT_BASE	100
#define DVC_UNSET_ST 100
#define DVC_ABSENT_ST 101
#define DVC_PRESENT_ST 102
#define DVC_PROBLEM_ST 103
#define DVC_FATAL_ST 104
#define DVC_LOW_ST 105
#define DVC_OUT_ST 106
#define DVC_OVER_ST 107
#define		CASS_STAT_BASE	110
#define CASS_NODENOM_ST 110
#define CASS_ABSENT_ST 111
#define CASS_NOFEED_ST 112
#define CASS_NORMAL_ST 113
#define CASS_LOW_ST 114
#define CASS_SHUF_ST 115
#define CASS_EMPTY_ST 116
#define		SVC_STAT_BASE	120
#define STATE_CLOSED_ST 120
#define STATE_OPEN_ST 121
#define STATE_SUPPLY_ST 122
#define STATE_MAINT_ST 123
#define		DVC_NAME_BASE	130
#define DVC_JRNL_STAT 130
#define DVC_RCPT_STAT 131
#define DVC_SECDEP_STAT 132
#define DVC_CONFID_STAT 133
#define DVC_CRDWR_STAT 134
#define DVC_CRDRD_STAT 135
#define DVC_DSP_STAT 136
#define DVC_WDRD_STAT 137
#define DVC_DPS_STAT 138
#define DVC_HWCFG_STAT 139
#define DVC_RSV_STAT 140
#define DVC_CST_STAT 141
#define DVC_DCTP_STAT 142
#define DVC_PSBK_STAT 143
#define DVC_STMT_STAT 144
#define DVC_CMRA_STAT 145
#define DVC_VGRD_STAT 146
#define DVC_COIN_STAT 147
#define DVC_ALRM_STAT 148
#define DVC_SUPV_STAT 149
#define DVC_POWR_STAT 150
#define DVC_HCM_STAT 151
#define DVC_TRAP_STAT 152
#define DVC_SUPPLY_STAT 153
#define DVC_SENSOR_STAT 154
#define DVC_IDM_STAT 155
#define DVC_DSP911_STAT 160
#define DVC_NCRCFG_STAT 162
#define DVC_NCRSUP_STAT 163
#define DVC_NCRFIT_STAT 164
#define DVC_NCRTAL_STAT 165
#define DVC_NCRLOG_STAT 166
#define DVC_NCRTOD_STAT 167
#define DVC_TOD_STAT 168
#define DVC_ENC_STAT 169
#define DVC_DISK_STAT 170
#define DVC_EDC_STAT 171
#define LEVEL_BRN 190
#define LEVEL_TERM 191
#define ATMRPLN_TAG 200
#define TXNATM_TAG 201
#define CAPTCRD_TAG 202
#define SUSPTXN_TAG 203
#define ATMDPT_TAG 205
#define ACQTXN_TAG 206
#define STATES_TAG 207
#define ATMRPLN_ADD 250
#define ATMRPLN_FULL 251
#define SCREEN_NUMBER 300
#define GOOD_READ_NEXT 301
#define ERROR_SCREEN 302
#define READ_COND_1 303
#define READ_COND_2 304
#define READ_COND_3 305
#define DELAY_CARD_RTN 306
#define NO_FIT_NEXT 307
#define TIMEOUT_NEXT 308
#define CANCEL_NEXT 309
#define GOOD_PIN_NEXT 310
#define MAX_BAD_PIN_NEXT 311
#define NO_LOCAL_PIN 312
#define PIN_RETRY_COUNT 313
#define NEXT_STATE 314
#define CLEAR_MASK 315
#define A_PRESET_MASK 316
#define B_PRESET_MASK 317
#define C_PRESET_MASK 318
#define D_PRESET_MASK 319
#define KEY_A_NEXT 320
#define KEY_B_NEXT 321
#define KEY_C_NEXT 322
#define KEY_D_NEXT 323
#define OP_KEY_BUF_LOC 324
#define CURR_DISP_SCR 325
#define WHOLE_DOLL_NEXT 326
#define NON_WHOLE_NEXT 327
#define BUFF_DISP_PARM 328
#define RPLY_TOUT_STATE 329
#define SEND_TRACK_2 330
#define SEND_TRACK_13 331
#define SEND_OPKEY_BUF 332
#define SEND_AMOUNT_BUF 333
#define SEND_PIN_BUF 334
#define SEND_BC_BUF 335
#define FORM_DLV_SCREEN 336
#define NO_FORM_SCREEN 337
#define CARD_RETAIN_SCR 338
#define IDX0_NEXT_STATE 339
#define IDX1_NEXT_STATE 340
#define IDX2_NEXT_STATE 341
#define IDX3_NEXT_STATE 342
#define IDX4_NEXT_STATE 343
#define IDX5_NEXT_STATE 344
#define IDX6_NEXT_STATE 345
#define IDX7_NEXT_STATE 346
#define GOOD_WRITE_STATE 347
#define BAD_WRITE_STATE 348
#define NO_WRITE_STATE 349
#define PICTURE_TYPE 350
#define OPERATION_CODE 351
#define OK_NEXT_STATE 352
#define FAULT_NEXT_STATE 353
#define DIGITS_12_11 354
#define DIGITS_10_9 355
#define DIGITS_8_7 356
#define DIGITS_6_5 357
#define DIGITS_4_3 358
#define DIGITS_2_1 359
#define BAD_READ_STATE 360
#define READ_CONDITION 361
#define MATCH_NEXT_STATE 362
#define NO_MATCH_NEXT_STATE 363
#define INDIRECT_STATE 364
#define BUFFER_ID 365
#define DELIMITER_OFF 366
#define CHARS_1_2 367
#define CHARS_3_4 368
#define CHARS_5_6 369
#define CHECK_ACCEPT_SCR 370
#define HAND_DELAY_SCR 371
#define HAND_DELAY_TIME 372
#define MICR_FAULT_STATE 373
#define MEDIA_FAULT_STATE 374
#define HANDLING_STATE 375
#define OVER_MICR_DIT 376
#define ENABLE_DIS 377
#define SOURCE_BUF_ID 378
#define DEST_BUF_ID 379
#define KEY_F_NEXT 380
#define KEY_G_NEXT 381
#define KEY_H_NEXT 382
#define KEY_I_NEXT 383
#define KEY_J_NEXT 384
#define KEY_K_NEXT 385
#define KEY_L_NEXT 386
#define KEY_M_NEXT 387
#define CLEAR_SENSOR_NEXT 388
#define BLOCK_SENSOR_NEXT 389
#define LANGUAGE_BANK 390
#define POSITIVE_NEXT 391
#define NEGATIVE_NEXT 392
#define BUFFER_1_ID 393
#define BUFFER_2_ID 394
#define RESULT_BUF_ID 395
#define OPERATION_TO_DO 396
#define NO_SUCH_STATE_TYPE 397
#define MUST_BE_3_DIG 398
#define KEYEXP_REGEX 399
#define DEVICES_CLEARED 400
#define EXT_STATE 450
#define BUF_ID 451
#define ACTIVE_KEY_MASK 452
#define BUF_POSITIONS 453
#define MULTI_LANG_EXT_STATE 454
#define DEPENDENT_ON_PREV_STATE 455
#define GET_SUP 480
#define	KMFLD_BASE	500
#define KMFLD_1 501
#define KMFLD_2 502
#define KMFLD_3 503
#define KMFLD_4 504
#define KMFLD_5 505
#define KMFLD_6 506
#define KMFLD_7 507
#define KMFLD_8 508

#ifdef __cplusplus
}
#endif

#endif
