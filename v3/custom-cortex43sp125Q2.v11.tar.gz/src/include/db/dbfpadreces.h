/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	FPADREC access routines for managing database access (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __DBFPADRECES_H
#define __DBFPADRECES_H

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	extern	long	FPADRECid;
	extern	long	FPADRECcrddet_id;
	extern	char	FPADRECdatecreated[11];
	extern	long	FPADRECtimecreated;
	extern	char	FPADRECdateupdated[11];
	extern	long	FPADRECtimeupdated;
	extern	char	FPADRECactioncode[2];
	extern	char	FPADRECrspcode[3];
	extern	short	FPADRECcrdacptbus;
	extern	char	FPADRECcrdacptloc_postcode[11];
	extern	char	FPADRECdecision_code_1[33];
	extern	char	FPADRECdecision_code_2[33];
	extern	char	FPADRECdecision_code_3[33];
	extern	char	FPADRECdecision_code_4[33];
	extern	char	FPADRECdecision_code_5[33];
	extern	char	FPADRECdecision_code_6[33];
	extern	char	FPADRECdecision_code_7[33];
	extern	char	FPADRECdecision_code_8[33];
	extern	char	FPADRECdecision_code_9[33];
	extern	char	FPADRECdecision_code_10[33];

	extern	long	FPADREC_HASHcrddet_id;
	extern	long	FPADREC_PKid;
EXEC SQL END DECLARE SECTION;
/** @endcond */

/*---------------------------Macros-------------------------------------*/
#define FPADREC_HV \
:FPADRECid,\
:FPADRECcrddet_id,\
:FPADRECdatecreated,\
:FPADRECtimecreated,\
:FPADRECdateupdated,\
:FPADRECtimeupdated,\
:FPADRECactioncode,\
:FPADRECrspcode,\
:FPADRECcrdacptbus,\
:FPADRECcrdacptloc_postcode,\
:FPADRECdecision_code_1,\
:FPADRECdecision_code_2,\
:FPADRECdecision_code_3,\
:FPADRECdecision_code_4,\
:FPADRECdecision_code_5,\
:FPADRECdecision_code_6,\
:FPADRECdecision_code_7,\
:FPADRECdecision_code_8,\
:FPADRECdecision_code_9,\
:FPADRECdecision_code_10

#define FPADREC_COL \
fpadrec.id,\
fpadrec.crddet_id,\
fpadrec.datecreated,\
fpadrec.timecreated,\
fpadrec.dateupdated,\
fpadrec.timeupdated,\
fpadrec.actioncode,\
fpadrec.rspcode,\
fpadrec.crdacptbus,\
fpadrec.crdacptloc_postcode,\
fpadrec.decision_code_1,\
fpadrec.decision_code_2,\
fpadrec.decision_code_3,\
fpadrec.decision_code_4,\
fpadrec.decision_code_5,\
fpadrec.decision_code_6,\
fpadrec.decision_code_7,\
fpadrec.decision_code_8,\
fpadrec.decision_code_9,\
fpadrec.decision_code_10

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_FPADREC_t
	{
		long	id;
		long	crddet_id;
		char	datecreated[11];
		long	timecreated;
		char	dateupdated[11];
		long	timeupdated;
		char	actioncode[2];
		char	rspcode[3];
		short	crdacptbus;
		char	crdacptloc_postcode[11];
		char	decision_code_1[33];
		char	decision_code_2[33];
		char	decision_code_3[33];
		char	decision_code_4[33];
		char	decision_code_5[33];
		char	decision_code_6[33];
		char	decision_code_7[33];
		char	decision_code_8[33];
		char	decision_code_9[33];
		char	decision_code_10[33];
	} HOST_FPADREC_t;

	typedef struct HOST_FPADREC_IND_t
	{
		short	id_ind;
		short	crddet_id_ind;
		short	datecreated_ind;
		short	timecreated_ind;
		short	dateupdated_ind;
		short	timeupdated_ind;
		short	actioncode_ind;
		short	rspcode_ind;
		short	crdacptbus_ind;
		short	crdacptloc_postcode_ind;
		short	decision_code_1_ind;
		short	decision_code_2_ind;
		short	decision_code_3_ind;
		short	decision_code_4_ind;
		short	decision_code_5_ind;
		short	decision_code_6_ind;
		short	decision_code_7_ind;
		short	decision_code_8_ind;
		short	decision_code_9_ind;
		short	decision_code_10_ind;
	} HOST_FPADREC_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
#define FPADRECdump(p_FPADREC)					FPADRECdump_IND(p_FPADREC, NULL)
#define FPADRECdumplev(p_FPADREC, dbglev)			FPADRECdumplev_IND(p_FPADREC, NULL, dbglev)

extern	int	FPADRECadd_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND);
extern	int	FPADRECupdate_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND);
extern	int	FPADRECdelete(FPADREC_t *p_FPADREC);
extern	void	FPADRECdump_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND);
extern	void	FPADRECdumplev_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, int dbglev);

extern	int	FPADREChv2cs(FPADREC_t *p_FPADREC);
extern	void	FPADRECcs2hv(FPADREC_t *p_FPADREC);
extern	int	FPADREChs2cs(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_IND, HOST_FPADREC_t *hsData, HOST_FPADREC_IND_t *hsInd);

extern	void	FPADRECcs2hsINS(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_IND, HOST_FPADREC_t *hsData, HOST_FPADREC_IND_t *hsInd);
extern	void	FPADRECcs2hs(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_IND, HOST_FPADREC_t *hsData, HOST_FPADREC_IND_t *hsInd);
extern	void	FPADREC_HASHdumplev(FPADREC_HASH_t *p_FPADREC_HASH, int dbglev);
extern	char	*FPADREC_HASHkey2str(char *out, FPADREC_HASH_t *p_FPADREC_HASH);

extern	int	FPADRECgetbyFPADREC_HASH_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_HASH_t *p_FPADREC_HASH);
extern	int	FPADRECgetbyFPADREC_HASH4upd_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_HASH_t *p_FPADREC_HASH);
extern	int	FPADRECupdbyFPADREC_HASH_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_HASH_t *p_FPADREC_HASH);
extern	int	FPADRECupdallbyFPADREC_HASH_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_HASH_t *p_FPADREC_HASH);
extern	int	FPADRECdelbyFPADREC_HASH( FPADREC_HASH_t *p_FPADREC_HASH);

extern	void	FPADREC_PKdumplev(FPADREC_PK_t *p_FPADREC_PK, int dbglev);
extern	char	*FPADREC_PKkey2str(char *out, FPADREC_PK_t *p_FPADREC_PK);

extern	int	FPADRECgetbyFPADREC_PK_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_PK_t *p_FPADREC_PK);
extern	int	FPADRECgetbyFPADREC_PK4upd_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_PK_t *p_FPADREC_PK);
extern	int	FPADRECupdbyFPADREC_PK_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_PK_t *p_FPADREC_PK);
extern	int	FPADRECupdallbyFPADREC_PK_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_PK_t *p_FPADREC_PK);
extern	int	FPADRECdelbyFPADREC_PK( FPADREC_PK_t *p_FPADREC_PK);

extern	void	FPADRECinitDflt(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND);

#ifdef __cplusplus
}
#endif

#endif
