/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CRDDELIVINFO buffer size defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBCRDDELIVINFOBSD_H
#define __DBCRDDELIVINFOBSD_H


#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define CRDDELIVINFO_PERSON_NAME_BUFFSIZE 101
#define CRDDELIVINFO_DOC_NO_BUFFSIZE 51
#define CRDDELIVINFO_USR_NAME_BUFFSIZE 16
#define CRDDELIVINFO_USR_TERM_BUFFSIZE 51
#define CRDDELIVINFO_DELIV_DATE_BUFFSIZE 11
#define CRDDELIVINFO_DELIV_TYPE_BUFFSIZE 2

#ifdef __cplusplus
}
#endif

#endif
