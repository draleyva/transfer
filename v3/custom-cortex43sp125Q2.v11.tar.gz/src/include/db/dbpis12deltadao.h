/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	PIS12_DELTA DAO structure definitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBPIS12DELTADAO_H
#define __DBPIS12DELTADAO_H

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table PIS12_DELTA
 */
typedef struct
{
	long	id;
	char	workflow[17];
	char	recordtype[9];
	char	dataspecificationversion[6];
	char	clientidfromheader[17];
	long	crddet_id;
	long	token_id;
	short	pis12_type;
	long	recordcreationdate;
	long	recordcreationtime;
	long	recordcreationmilliseconds;
	long	gmtoffset;
	char	customeridfromheader[21];
	char	customeracctnumber[41];
	char	externaltransactionid[33];
	char	pan[20];
	char	type[2];
	char	subtype[3];
	char	category[2];
	char	association[2];
	long	panopendate;
	long	membersincedate;
	char	issuingcountry[4];
	char	cardholdercity[41];
	char	cardholderstateprovince[6];
	char	cardholderpostalcode[11];
	char	cardholdercountrycode[4];
	short	numberofpaymentids;
	char	paymentinstrumentid[31];
	char	status[3];
	long	statusdate;
	short	pinlength;
	long	pinsetdate;
	char	pintype[2];
	char	activeindicator[2];
	char	nameoninstrument[41];
	long	expirationdate;
	long	lastissuedate;
	char	plasticissuetype[2];
	char	incentive[2];
	char	currencycode[4];
	double	currencyconversionrate;
	double	creditlimit;
	double	overdraftlimit;
	double	dailyposlimit;
	double	dailycashlimit;
	char	cashbacklimitmode[2];
	char	mediatype[2];
	char	aipstatic[2];
	char	aipdynamic[2];
	char	aipverify[2];
	char	aiprisk[2];
	char	aipissuerauthentication[2];
	char	aipcombined[2];
	char	chipspecification[2];
	char	chipspecversion[4];
	short	offlinelowerlimit;
	short	offlineupperlimit;
	char	userindicator01[2];
	char	userindicator02[2];
	char	usercode1[4];
	char	usercode2[4];
	char	userdata01[7];
	char	userdata02[7];
	char	userdata03[11];
	char	userdata04[11];
	char	userdata05[16];
	char	userdata06[21];
	char	userdata07[41];
} PIS12_DELTA_t;

#ifdef __cplusplus
/**
 * Structure for C++ interfacing of table PIS12_DELTA
 */
struct CppClassPIS12_DELTA_t : public PIS12_DELTA_t
{
	CppClassPIS12_DELTA_t (
		long _id = 0,
		const char * _workflow = "",
		const char * _recordtype = "",
		const char * _dataspecificationversion = "",
		const char * _clientidfromheader = "",
		long _crddet_id = 0,
		long _token_id = 0,
		short _pis12_type = 0,
		long _recordcreationdate = 0,
		long _recordcreationtime = 0,
		long _recordcreationmilliseconds = 0,
		long _gmtoffset = 0,
		const char * _customeridfromheader = "",
		const char * _customeracctnumber = "",
		const char * _externaltransactionid = "",
		const char * _pan = "",
		const char * _type = "",
		const char * _subtype = "",
		const char * _category = "",
		const char * _association = "",
		long _panopendate = 0,
		long _membersincedate = 0,
		const char * _issuingcountry = "",
		const char * _cardholdercity = "",
		const char * _cardholderstateprovince = "",
		const char * _cardholderpostalcode = "",
		const char * _cardholdercountrycode = "",
		short _numberofpaymentids = 0,
		const char * _paymentinstrumentid = "",
		const char * _status = "",
		long _statusdate = 0,
		short _pinlength = 0,
		long _pinsetdate = 0,
		const char * _pintype = "",
		const char * _activeindicator = "",
		const char * _nameoninstrument = "",
		long _expirationdate = 0,
		long _lastissuedate = 0,
		const char * _plasticissuetype = "",
		const char * _incentive = "",
		const char * _currencycode = "",
		double _currencyconversionrate = 0,
		double _creditlimit = 0,
		double _overdraftlimit = 0,
		double _dailyposlimit = 0,
		double _dailycashlimit = 0,
		const char * _cashbacklimitmode = "",
		const char * _mediatype = "",
		const char * _aipstatic = "",
		const char * _aipdynamic = "",
		const char * _aipverify = "",
		const char * _aiprisk = "",
		const char * _aipissuerauthentication = "",
		const char * _aipcombined = "",
		const char * _chipspecification = "",
		const char * _chipspecversion = "",
		short _offlinelowerlimit = 0,
		short _offlineupperlimit = 0,
		const char * _userindicator01 = "",
		const char * _userindicator02 = "",
		const char * _usercode1 = "",
		const char * _usercode2 = "",
		const char * _userdata01 = "",
		const char * _userdata02 = "",
		const char * _userdata03 = "",
		const char * _userdata04 = "",
		const char * _userdata05 = "",
		const char * _userdata06 = "",
		const char * _userdata07 = ""
		)
	{
		id = _id;
		slstrcpy_sen(workflow, _workflow);
		slstrcpy_sen(recordtype, _recordtype);
		slstrcpy_sen(dataspecificationversion, _dataspecificationversion);
		slstrcpy_sen(clientidfromheader, _clientidfromheader);
		crddet_id = _crddet_id;
		token_id = _token_id;
		pis12_type = _pis12_type;
		recordcreationdate = _recordcreationdate;
		recordcreationtime = _recordcreationtime;
		recordcreationmilliseconds = _recordcreationmilliseconds;
		gmtoffset = _gmtoffset;
		slstrcpy_sen(customeridfromheader, _customeridfromheader);
		slstrcpy_sen(customeracctnumber, _customeracctnumber);
		slstrcpy_sen(externaltransactionid, _externaltransactionid);
		slstrcpy_sen(pan, _pan);
		slstrcpy_sen(type, _type);
		slstrcpy_sen(subtype, _subtype);
		slstrcpy_sen(category, _category);
		slstrcpy_sen(association, _association);
		panopendate = _panopendate;
		membersincedate = _membersincedate;
		slstrcpy_sen(issuingcountry, _issuingcountry);
		slstrcpy_sen(cardholdercity, _cardholdercity);
		slstrcpy_sen(cardholderstateprovince, _cardholderstateprovince);
		slstrcpy_sen(cardholderpostalcode, _cardholderpostalcode);
		slstrcpy_sen(cardholdercountrycode, _cardholdercountrycode);
		numberofpaymentids = _numberofpaymentids;
		slstrcpy_sen(paymentinstrumentid, _paymentinstrumentid);
		slstrcpy_sen(status, _status);
		statusdate = _statusdate;
		pinlength = _pinlength;
		pinsetdate = _pinsetdate;
		slstrcpy_sen(pintype, _pintype);
		slstrcpy_sen(activeindicator, _activeindicator);
		slstrcpy_sen(nameoninstrument, _nameoninstrument);
		expirationdate = _expirationdate;
		lastissuedate = _lastissuedate;
		slstrcpy_sen(plasticissuetype, _plasticissuetype);
		slstrcpy_sen(incentive, _incentive);
		slstrcpy_sen(currencycode, _currencycode);
		currencyconversionrate = _currencyconversionrate;
		creditlimit = _creditlimit;
		overdraftlimit = _overdraftlimit;
		dailyposlimit = _dailyposlimit;
		dailycashlimit = _dailycashlimit;
		slstrcpy_sen(cashbacklimitmode, _cashbacklimitmode);
		slstrcpy_sen(mediatype, _mediatype);
		slstrcpy_sen(aipstatic, _aipstatic);
		slstrcpy_sen(aipdynamic, _aipdynamic);
		slstrcpy_sen(aipverify, _aipverify);
		slstrcpy_sen(aiprisk, _aiprisk);
		slstrcpy_sen(aipissuerauthentication, _aipissuerauthentication);
		slstrcpy_sen(aipcombined, _aipcombined);
		slstrcpy_sen(chipspecification, _chipspecification);
		slstrcpy_sen(chipspecversion, _chipspecversion);
		offlinelowerlimit = _offlinelowerlimit;
		offlineupperlimit = _offlineupperlimit;
		slstrcpy_sen(userindicator01, _userindicator01);
		slstrcpy_sen(userindicator02, _userindicator02);
		slstrcpy_sen(usercode1, _usercode1);
		slstrcpy_sen(usercode2, _usercode2);
		slstrcpy_sen(userdata01, _userdata01);
		slstrcpy_sen(userdata02, _userdata02);
		slstrcpy_sen(userdata03, _userdata03);
		slstrcpy_sen(userdata04, _userdata04);
		slstrcpy_sen(userdata05, _userdata05);
		slstrcpy_sen(userdata06, _userdata06);
		slstrcpy_sen(userdata07, _userdata07);
	}
};
#endif /*__cplusplus*/
/**
 * Structure of indicators for table  PIS12_DELTA 
 */
typedef struct
{
	short	id;
	short	workflow;
	short	recordtype;
	short	dataspecificationversion;
	short	clientidfromheader;
	short	crddet_id;
	short	token_id;
	short	pis12_type;
	short	recordcreationdate;
	short	recordcreationtime;
	short	recordcreationmilliseconds;
	short	gmtoffset;
	short	customeridfromheader;
	short	customeracctnumber;
	short	externaltransactionid;
	short	pan;
	short	type;
	short	subtype;
	short	category;
	short	association;
	short	panopendate;
	short	membersincedate;
	short	issuingcountry;
	short	cardholdercity;
	short	cardholderstateprovince;
	short	cardholderpostalcode;
	short	cardholdercountrycode;
	short	numberofpaymentids;
	short	paymentinstrumentid;
	short	status;
	short	statusdate;
	short	pinlength;
	short	pinsetdate;
	short	pintype;
	short	activeindicator;
	short	nameoninstrument;
	short	expirationdate;
	short	lastissuedate;
	short	plasticissuetype;
	short	incentive;
	short	currencycode;
	short	currencyconversionrate;
	short	creditlimit;
	short	overdraftlimit;
	short	dailyposlimit;
	short	dailycashlimit;
	short	cashbacklimitmode;
	short	mediatype;
	short	aipstatic;
	short	aipdynamic;
	short	aipverify;
	short	aiprisk;
	short	aipissuerauthentication;
	short	aipcombined;
	short	chipspecification;
	short	chipspecversion;
	short	offlinelowerlimit;
	short	offlineupperlimit;
	short	userindicator01;
	short	userindicator02;
	short	usercode1;
	short	usercode2;
	short	userdata01;
	short	userdata02;
	short	userdata03;
	short	userdata04;
	short	userdata05;
	short	userdata06;
	short	userdata07;
} PIS12_DELTA_IND_t;

/**
 * Structure to retrieve PIS12_DELTA by Primary Key PK_PIS12_DELTA
 */
typedef struct
{
	long	id;
} PIS12_DELTA_PK_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/

#endif
