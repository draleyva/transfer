/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CRDPINMIGR DAO structure definitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBCRDPINMIGRDAO_H
#define __DBCRDPINMIGRDAO_H

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table CRDPINMIGR
 */
typedef struct
{
	long	id;
	char	pan_new[20];
	long	crddet_id;
	char	pan_old[20];
	char	expdate[5];
	char	pin_offset[5];
} CRDPINMIGR_t;

#ifdef __cplusplus
/**
 * Structure for C++ interfacing of table CRDPINMIGR
 */
struct CppClassCRDPINMIGR_t : public CRDPINMIGR_t
{
	CppClassCRDPINMIGR_t (
		long _id = 0,
		const char * _pan_new = "",
		long _crddet_id = 0,
		const char * _pan_old = "",
		const char * _expdate = "",
		const char * _pin_offset = ""
		)
	{
		id = _id;
		slstrcpy_sen(pan_new, _pan_new);
		crddet_id = _crddet_id;
		slstrcpy_sen(pan_old, _pan_old);
		slstrcpy_sen(expdate, _expdate);
		slstrcpy_sen(pin_offset, _pin_offset);
	}
};
#endif /*__cplusplus*/
/**
 * Structure of indicators for table  CRDPINMIGR 
 */
typedef struct
{
	short	id;
	short	pan_new;
	short	crddet_id;
	short	pan_old;
	short	expdate;
	short	pin_offset;
} CRDPINMIGR_IND_t;

/**
 * Structure to retrieve CRDPINMIGR by Primary Key PK_CRDPINMIGR
 */
typedef struct
{
	long	id;
} CRDPINMIGR_PK_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/

#endif
