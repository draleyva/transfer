/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	NMON_LOG access routines for managing database access (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __DBNMONLOGES_H
#define __DBNMONLOGES_H

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	extern	long	NMON_LOGid;
	extern	char	NMON_LOGtstamp[21];
	extern	char	NMON_LOGtablename[33];
	extern	char	NMON_LOGkeydata[65];
	extern	char	NMON_LOGhint[2];
	extern	char	NMON_LOGnmoncode[5];
	extern	char	NMON_LOGnewvalue1[65];
	extern	char	NMON_LOGoldvalue1[65];
	extern	char	NMON_LOGnewvalue2[65];
	extern	char	NMON_LOGoldvalue2[65];
	extern	char	NMON_LOGnewvalue3[65];
	extern	char	NMON_LOGoldvalue3[65];
	extern	char	NMON_LOGnewvalue4[65];
	extern	char	NMON_LOGoldvalue4[65];
	extern	char	NMON_LOGnewvalue5[65];
	extern	char	NMON_LOGoldvalue5[65];
	extern	char	NMON_LOGnewvalue6[65];
	extern	char	NMON_LOGoldvalue6[65];
	extern	char	NMON_LOGnewvalue7[65];
	extern	char	NMON_LOGoldvalue7[65];

	extern	long	NMON_LOG_PKid;
	extern	char	NMON_LOG_HASHtstamp[21];
EXEC SQL END DECLARE SECTION;
/** @endcond */

/*---------------------------Macros-------------------------------------*/
#define NMON_LOG_HV \
:NMON_LOGid,\
:NMON_LOGtstamp,\
:NMON_LOGtablename,\
:NMON_LOGkeydata,\
:NMON_LOGhint,\
:NMON_LOGnmoncode,\
:NMON_LOGnewvalue1,\
:NMON_LOGoldvalue1,\
:NMON_LOGnewvalue2,\
:NMON_LOGoldvalue2,\
:NMON_LOGnewvalue3,\
:NMON_LOGoldvalue3,\
:NMON_LOGnewvalue4,\
:NMON_LOGoldvalue4,\
:NMON_LOGnewvalue5,\
:NMON_LOGoldvalue5,\
:NMON_LOGnewvalue6,\
:NMON_LOGoldvalue6,\
:NMON_LOGnewvalue7,\
:NMON_LOGoldvalue7

#define NMON_LOG_COL \
nmon_log.id,\
nmon_log.tstamp,\
nmon_log.tablename,\
nmon_log.keydata,\
nmon_log.hint,\
nmon_log.nmoncode,\
nmon_log.newvalue1,\
nmon_log.oldvalue1,\
nmon_log.newvalue2,\
nmon_log.oldvalue2,\
nmon_log.newvalue3,\
nmon_log.oldvalue3,\
nmon_log.newvalue4,\
nmon_log.oldvalue4,\
nmon_log.newvalue5,\
nmon_log.oldvalue5,\
nmon_log.newvalue6,\
nmon_log.oldvalue6,\
nmon_log.newvalue7,\
nmon_log.oldvalue7

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_NMON_LOG_t
	{
		long	id;
		char	tstamp[21];
		char	tablename[33];
		char	keydata[65];
		char	hint[2];
		char	nmoncode[5];
		char	newvalue1[65];
		char	oldvalue1[65];
		char	newvalue2[65];
		char	oldvalue2[65];
		char	newvalue3[65];
		char	oldvalue3[65];
		char	newvalue4[65];
		char	oldvalue4[65];
		char	newvalue5[65];
		char	oldvalue5[65];
		char	newvalue6[65];
		char	oldvalue6[65];
		char	newvalue7[65];
		char	oldvalue7[65];
	} HOST_NMON_LOG_t;

	typedef struct HOST_NMON_LOG_IND_t
	{
		short	id_ind;
		short	tstamp_ind;
		short	tablename_ind;
		short	keydata_ind;
		short	hint_ind;
		short	nmoncode_ind;
		short	newvalue1_ind;
		short	oldvalue1_ind;
		short	newvalue2_ind;
		short	oldvalue2_ind;
		short	newvalue3_ind;
		short	oldvalue3_ind;
		short	newvalue4_ind;
		short	oldvalue4_ind;
		short	newvalue5_ind;
		short	oldvalue5_ind;
		short	newvalue6_ind;
		short	oldvalue6_ind;
		short	newvalue7_ind;
		short	oldvalue7_ind;
	} HOST_NMON_LOG_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
#define NMON_LOGdump(p_NMON_LOG)				NMON_LOGdump_IND(p_NMON_LOG, NULL)
#define NMON_LOGdumplev(p_NMON_LOG, dbglev)			NMON_LOGdumplev_IND(p_NMON_LOG, NULL, dbglev)

extern	int	NMON_LOGadd_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND);
extern	int	NMON_LOGupdate_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND);
extern	int	NMON_LOGdelete(NMON_LOG_t *p_NMON_LOG);
extern	void	NMON_LOGdump_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND);
extern	void	NMON_LOGdumplev_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, int dbglev);

extern	int	NMON_LOGhv2cs(NMON_LOG_t *p_NMON_LOG);
extern	void	NMON_LOGcs2hv(NMON_LOG_t *p_NMON_LOG);
extern	int	NMON_LOGhs2cs(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_IND, HOST_NMON_LOG_t *hsData, HOST_NMON_LOG_IND_t *hsInd);

extern	void	NMON_LOGcs2hsINS(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_IND, HOST_NMON_LOG_t *hsData, HOST_NMON_LOG_IND_t *hsInd);
extern	void	NMON_LOGcs2hs(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_IND, HOST_NMON_LOG_t *hsData, HOST_NMON_LOG_IND_t *hsInd);
extern	void	NMON_LOG_PKdumplev(NMON_LOG_PK_t *p_NMON_LOG_PK, int dbglev);
extern	char	*NMON_LOG_PKkey2str(char *out, NMON_LOG_PK_t *p_NMON_LOG_PK);

extern	int	NMON_LOGgetbyNMON_LOG_PK_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_PK_t *p_NMON_LOG_PK);
extern	int	NMON_LOGgetbyNMON_LOG_PK4upd_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_PK_t *p_NMON_LOG_PK);
extern	int	NMON_LOGupdbyNMON_LOG_PK_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_PK_t *p_NMON_LOG_PK);
extern	int	NMON_LOGupdallbyNMON_LOG_PK_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_PK_t *p_NMON_LOG_PK);
extern	int	NMON_LOGdelbyNMON_LOG_PK( NMON_LOG_PK_t *p_NMON_LOG_PK);

extern	void	NMON_LOG_HASHdumplev(NMON_LOG_HASH_t *p_NMON_LOG_HASH, int dbglev);
extern	char	*NMON_LOG_HASHkey2str(char *out, NMON_LOG_HASH_t *p_NMON_LOG_HASH);

extern	int	NMON_LOGgetbyNMON_LOG_HASH_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_HASH_t *p_NMON_LOG_HASH);
extern	int	NMON_LOGgetbyNMON_LOG_HASH4upd_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_HASH_t *p_NMON_LOG_HASH);
extern	int	NMON_LOGupdbyNMON_LOG_HASH_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_HASH_t *p_NMON_LOG_HASH);
extern	int	NMON_LOGupdallbyNMON_LOG_HASH_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_HASH_t *p_NMON_LOG_HASH);
extern	int	NMON_LOGdelbyNMON_LOG_HASH( NMON_LOG_HASH_t *p_NMON_LOG_HASH);

extern	void	NMON_LOGinitDflt(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND);

#ifdef __cplusplus
}
#endif

#endif
