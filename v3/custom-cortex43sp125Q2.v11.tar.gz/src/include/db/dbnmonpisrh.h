/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	NMON_PIS type defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBNMONPISRH_H
#define __DBNMONPISRH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
#include <dbnmonpisbsd.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define NMON_PIS_PK_PREP2 \
	NMON_PIS_PKid = p_NMON_PIS_PK->id;\

#define NMON_PIS_PK_PREP1 \
	nmon_pis.id = :v1 
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
#include <dbnmonpisdao.h>
/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif
#define NMON_PISadd(pdata)					NMON_PISadd_IND(pdata, NULL)
#define NMON_PISupdate(pdata)					NMON_PISupdate_IND(pdata, NULL)
#define NMON_PISgetbyNMON_PIS_PK(pdata, phash)			NMON_PISgetbyNMON_PIS_PK_IND(pdata, NULL, phash)
#define NMON_PISgetbyNMON_PIS_PK4upd(pdata, phash)		NMON_PISgetbyNMON_PIS_PK4upd_IND(pdata, NULL, phash)
#define NMON_PISupdbyNMON_PIS_PK(pdata, phash)			NMON_PISupdbyNMON_PIS_PK_IND(pdata, NULL, phash)
#define NMON_PISupdallbyNMON_PIS_PK(pdata, phash)		NMON_PISupdallbyNMON_PIS_PK_IND(pdata, NULL, phash)
#define NMON_PISdump(p_NMON_PIS)				NMON_PISdump_IND(p_NMON_PIS, NULL)
#define NMON_PISdumplev(p_NMON_PIS, dbglev)			NMON_PISdumplev_IND(p_NMON_PIS, NULL, dbglev)

extern	int	NMON_PISadd_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND);
extern	int	NMON_PISupdate_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND);
extern	int	NMON_PISdelete(NMON_PIS_t *p_NMON_PIS);

extern	void	NMON_PISdump_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND);
extern	void	NMON_PISdumplev_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND, int dbglev);

extern	char	*NMON_PIS_PKkey2str(char *out, NMON_PIS_PK_t *p_NMON_PIS_PK);

extern	int	NMON_PISgetbyNMON_PIS_PK_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND, NMON_PIS_PK_t *p_NMON_PIS_PK);
extern	int	NMON_PISgetbyNMON_PIS_PK4upd_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND, NMON_PIS_PK_t *p_NMON_PIS_PK);
extern	int	NMON_PISupdbyNMON_PIS_PK_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND, NMON_PIS_PK_t *p_NMON_PIS_PK);
extern	int	NMON_PISupdallbyNMON_PIS_PK_IND(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND, NMON_PIS_PK_t *p_NMON_PIS_PK);
extern	int	NMON_PISdelbyNMON_PIS_PK( NMON_PIS_PK_t *p_NMON_PIS_PK);
extern	void	NMON_PISinitDflt(NMON_PIS_t *p_NMON_PIS, NMON_PIS_IND_t *p_NMON_PIS_IND);

#ifdef __cplusplus
}
#endif

#endif
