/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	PIS12_LOG access routines for managing database access (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __DBPIS12LOGES_H
#define __DBPIS12LOGES_H

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	extern	long	PIS12_LOGid;
	extern	char	PIS12_LOGtstamp[21];
	extern	char	PIS12_LOGtablename[33];
	extern	char	PIS12_LOGkeydata[65];
	extern	char	PIS12_LOGhint[2];
	extern	char	PIS12_LOGindicator1[33];
	extern	char	PIS12_LOGindicator2[2];
	extern	char	PIS12_LOGindicator3[2];

	extern	long	PIS12_LOG_PKid;
	extern	char	PIS12_LOG_HASHtstamp[21];
EXEC SQL END DECLARE SECTION;
/** @endcond */

/*---------------------------Macros-------------------------------------*/
#define PIS12_LOG_HV \
:PIS12_LOGid,\
:PIS12_LOGtstamp,\
:PIS12_LOGtablename,\
:PIS12_LOGkeydata,\
:PIS12_LOGhint,\
:PIS12_LOGindicator1,\
:PIS12_LOGindicator2,\
:PIS12_LOGindicator3

#define PIS12_LOG_COL \
pis12_log.id,\
pis12_log.tstamp,\
pis12_log.tablename,\
pis12_log.keydata,\
pis12_log.hint,\
pis12_log.indicator1,\
pis12_log.indicator2,\
pis12_log.indicator3

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_PIS12_LOG_t
	{
		long	id;
		char	tstamp[21];
		char	tablename[33];
		char	keydata[65];
		char	hint[2];
		char	indicator1[33];
		char	indicator2[2];
		char	indicator3[2];
	} HOST_PIS12_LOG_t;

	typedef struct HOST_PIS12_LOG_IND_t
	{
		short	id_ind;
		short	tstamp_ind;
		short	tablename_ind;
		short	keydata_ind;
		short	hint_ind;
		short	indicator1_ind;
		short	indicator2_ind;
		short	indicator3_ind;
	} HOST_PIS12_LOG_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
#define PIS12_LOGdump(p_PIS12_LOG)				PIS12_LOGdump_IND(p_PIS12_LOG, NULL)
#define PIS12_LOGdumplev(p_PIS12_LOG, dbglev)			PIS12_LOGdumplev_IND(p_PIS12_LOG, NULL, dbglev)

extern	int	PIS12_LOGadd_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND);
extern	int	PIS12_LOGupdate_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND);
extern	int	PIS12_LOGdelete(PIS12_LOG_t *p_PIS12_LOG);
extern	void	PIS12_LOGdump_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND);
extern	void	PIS12_LOGdumplev_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, int dbglev);

extern	int	PIS12_LOGhv2cs(PIS12_LOG_t *p_PIS12_LOG);
extern	void	PIS12_LOGcs2hv(PIS12_LOG_t *p_PIS12_LOG);
extern	int	PIS12_LOGhs2cs(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_IND, HOST_PIS12_LOG_t *hsData, HOST_PIS12_LOG_IND_t *hsInd);

extern	void	PIS12_LOGcs2hsINS(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_IND, HOST_PIS12_LOG_t *hsData, HOST_PIS12_LOG_IND_t *hsInd);
extern	void	PIS12_LOGcs2hs(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_IND, HOST_PIS12_LOG_t *hsData, HOST_PIS12_LOG_IND_t *hsInd);
extern	void	PIS12_LOG_PKdumplev(PIS12_LOG_PK_t *p_PIS12_LOG_PK, int dbglev);
extern	char	*PIS12_LOG_PKkey2str(char *out, PIS12_LOG_PK_t *p_PIS12_LOG_PK);

extern	int	PIS12_LOGgetbyPIS12_LOG_PK_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_PK_t *p_PIS12_LOG_PK);
extern	int	PIS12_LOGgetbyPIS12_LOG_PK4upd_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_PK_t *p_PIS12_LOG_PK);
extern	int	PIS12_LOGupdbyPIS12_LOG_PK_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_PK_t *p_PIS12_LOG_PK);
extern	int	PIS12_LOGupdallbyPIS12_LOG_PK_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_PK_t *p_PIS12_LOG_PK);
extern	int	PIS12_LOGdelbyPIS12_LOG_PK( PIS12_LOG_PK_t *p_PIS12_LOG_PK);

extern	void	PIS12_LOG_HASHdumplev(PIS12_LOG_HASH_t *p_PIS12_LOG_HASH, int dbglev);
extern	char	*PIS12_LOG_HASHkey2str(char *out, PIS12_LOG_HASH_t *p_PIS12_LOG_HASH);

extern	int	PIS12_LOGgetbyPIS12_LOG_HASH_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_HASH_t *p_PIS12_LOG_HASH);
extern	int	PIS12_LOGgetbyPIS12_LOG_HASH4upd_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_HASH_t *p_PIS12_LOG_HASH);
extern	int	PIS12_LOGupdbyPIS12_LOG_HASH_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_HASH_t *p_PIS12_LOG_HASH);
extern	int	PIS12_LOGupdallbyPIS12_LOG_HASH_IND(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND, PIS12_LOG_HASH_t *p_PIS12_LOG_HASH);
extern	int	PIS12_LOGdelbyPIS12_LOG_HASH( PIS12_LOG_HASH_t *p_PIS12_LOG_HASH);

extern	void	PIS12_LOGinitDflt(PIS12_LOG_t *p_PIS12_LOG, PIS12_LOG_IND_t *p_PIS12_LOG_IND);

#ifdef __cplusplus
}
#endif

#endif
