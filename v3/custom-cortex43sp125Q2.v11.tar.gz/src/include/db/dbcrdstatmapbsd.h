/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CRDSTATMAP buffer size defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBCRDSTATMAPBSD_H
#define __DBCRDSTATMAPBSD_H


#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define CRDSTATMAP_CTX_STATCODE_BUFFSIZE 3
#define CRDSTATMAP_EXT_STATCODE_BUFFSIZE 6
#define CRDSTATMAP_DESCR_BUFFSIZE 31

#ifdef __cplusplus
}
#endif

#endif
