/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CRDPINMIGR access routines for managing database access (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __DBCRDPINMIGRES_H
#define __DBCRDPINMIGRES_H

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	extern	long	CRDPINMIGRid;
	extern	char	CRDPINMIGRpan_new[20];
	extern	long	CRDPINMIGRcrddet_id;
	extern	char	CRDPINMIGRpan_old[20];
	extern	char	CRDPINMIGRexpdate[5];
	extern	char	CRDPINMIGRpin_offset[5];

	extern	long	CRDPINMIGR_PKid;
EXEC SQL END DECLARE SECTION;
/** @endcond */

/*---------------------------Macros-------------------------------------*/
#define CRDPINMIGR_HV \
:CRDPINMIGRid,\
:CRDPINMIGRpan_new,\
:CRDPINMIGRcrddet_id,\
:CRDPINMIGRpan_old,\
:CRDPINMIGRexpdate,\
:CRDPINMIGRpin_offset

#define CRDPINMIGR_COL \
crdpinmigr.id,\
crdpinmigr.pan_new,\
crdpinmigr.crddet_id,\
crdpinmigr.pan_old,\
crdpinmigr.expdate,\
crdpinmigr.pin_offset

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_CRDPINMIGR_t
	{
		long	id;
		char	pan_new[20];
		long	crddet_id;
		char	pan_old[20];
		char	expdate[5];
		char	pin_offset[5];
	} HOST_CRDPINMIGR_t;

	typedef struct HOST_CRDPINMIGR_IND_t
	{
		short	id_ind;
		short	pan_new_ind;
		short	crddet_id_ind;
		short	pan_old_ind;
		short	expdate_ind;
		short	pin_offset_ind;
	} HOST_CRDPINMIGR_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
#define CRDPINMIGRdump(p_CRDPINMIGR)				CRDPINMIGRdump_IND(p_CRDPINMIGR, NULL)
#define CRDPINMIGRdumplev(p_CRDPINMIGR, dbglev)			CRDPINMIGRdumplev_IND(p_CRDPINMIGR, NULL, dbglev)

extern	int	CRDPINMIGRadd_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND);
extern	int	CRDPINMIGRupdate_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND);
extern	int	CRDPINMIGRdelete(CRDPINMIGR_t *p_CRDPINMIGR);
extern	void	CRDPINMIGRdump_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND);
extern	void	CRDPINMIGRdumplev_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND, int dbglev);

extern	int	CRDPINMIGRhv2cs(CRDPINMIGR_t *p_CRDPINMIGR);
extern	void	CRDPINMIGRcs2hv(CRDPINMIGR_t *p_CRDPINMIGR);
extern	int	CRDPINMIGRhs2cs(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_IND, HOST_CRDPINMIGR_t *hsData, HOST_CRDPINMIGR_IND_t *hsInd);

extern	void	CRDPINMIGRcs2hsINS(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_IND, HOST_CRDPINMIGR_t *hsData, HOST_CRDPINMIGR_IND_t *hsInd);
extern	void	CRDPINMIGRcs2hs(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_IND, HOST_CRDPINMIGR_t *hsData, HOST_CRDPINMIGR_IND_t *hsInd);
extern	void	CRDPINMIGR_PKdumplev(CRDPINMIGR_PK_t *p_CRDPINMIGR_PK, int dbglev);
extern	char	*CRDPINMIGR_PKkey2str(char *out, CRDPINMIGR_PK_t *p_CRDPINMIGR_PK);

extern	int	CRDPINMIGRgetbyCRDPINMIGR_PK_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND, CRDPINMIGR_PK_t *p_CRDPINMIGR_PK);
extern	int	CRDPINMIGRgetbyCRDPINMIGR_PK4upd_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND, CRDPINMIGR_PK_t *p_CRDPINMIGR_PK);
extern	int	CRDPINMIGRupdbyCRDPINMIGR_PK_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND, CRDPINMIGR_PK_t *p_CRDPINMIGR_PK);
extern	int	CRDPINMIGRupdallbyCRDPINMIGR_PK_IND(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND, CRDPINMIGR_PK_t *p_CRDPINMIGR_PK);
extern	int	CRDPINMIGRdelbyCRDPINMIGR_PK( CRDPINMIGR_PK_t *p_CRDPINMIGR_PK);

extern	void	CRDPINMIGRinitDflt(CRDPINMIGR_t *p_CRDPINMIGR, CRDPINMIGR_IND_t *p_CRDPINMIGR_IND);

#ifdef __cplusplus
}
#endif

#endif
