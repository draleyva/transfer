/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CRDDELIVINFO access routines for managing database access (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __DBCRDDELIVINFOES_H
#define __DBCRDDELIVINFOES_H

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	extern	long	CRDDELIVINFOid;
	extern	long	CRDDELIVINFOcrddet_id;
	extern	short	CRDDELIVINFOperson_type;
	extern	char	CRDDELIVINFOperson_name[101];
	extern	char	CRDDELIVINFOdoc_no[51];
	extern	short	CRDDELIVINFOdoc_type;
	extern	char	CRDDELIVINFOusr_name[16];
	extern	char	CRDDELIVINFOusr_term[51];
	extern	char	CRDDELIVINFOdeliv_date[11];
	extern	long	CRDDELIVINFOdeliv_time;
	extern	char	CRDDELIVINFOdeliv_type[2];
	extern	long	CRDDELIVINFOdeliv_branch_id;

	extern	long	FK_CRDDELIVINFO_ID_CRDDETcrddet_id;
	extern	long	CRDDELIVINFO_PKid;
EXEC SQL END DECLARE SECTION;
/** @endcond */

/*---------------------------Macros-------------------------------------*/
#define CRDDELIVINFO_HV \
:CRDDELIVINFOid,\
:CRDDELIVINFOcrddet_id,\
:CRDDELIVINFOperson_type,\
:CRDDELIVINFOperson_name,\
:CRDDELIVINFOdoc_no,\
:CRDDELIVINFOdoc_type,\
:CRDDELIVINFOusr_name,\
:CRDDELIVINFOusr_term,\
:CRDDELIVINFOdeliv_date,\
:CRDDELIVINFOdeliv_time,\
:CRDDELIVINFOdeliv_type,\
:CRDDELIVINFOdeliv_branch_id

#define CRDDELIVINFO_COL \
crddelivinfo.id,\
crddelivinfo.crddet_id,\
crddelivinfo.person_type,\
crddelivinfo.person_name,\
crddelivinfo.doc_no,\
crddelivinfo.doc_type,\
crddelivinfo.usr_name,\
crddelivinfo.usr_term,\
crddelivinfo.deliv_date,\
crddelivinfo.deliv_time,\
crddelivinfo.deliv_type,\
crddelivinfo.deliv_branch_id

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_CRDDELIVINFO_t
	{
		long	id;
		long	crddet_id;
		short	person_type;
		char	person_name[101];
		char	doc_no[51];
		short	doc_type;
		char	usr_name[16];
		char	usr_term[51];
		char	deliv_date[11];
		long	deliv_time;
		char	deliv_type[2];
		long	deliv_branch_id;
	} HOST_CRDDELIVINFO_t;

	typedef struct HOST_CRDDELIVINFO_IND_t
	{
		short	id_ind;
		short	crddet_id_ind;
		short	person_type_ind;
		short	person_name_ind;
		short	doc_no_ind;
		short	doc_type_ind;
		short	usr_name_ind;
		short	usr_term_ind;
		short	deliv_date_ind;
		short	deliv_time_ind;
		short	deliv_type_ind;
		short	deliv_branch_id_ind;
	} HOST_CRDDELIVINFO_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
#define CRDDELIVINFOdump(p_CRDDELIVINFO)			CRDDELIVINFOdump_IND(p_CRDDELIVINFO, NULL)
#define CRDDELIVINFOdumplev(p_CRDDELIVINFO, dbglev)		CRDDELIVINFOdumplev_IND(p_CRDDELIVINFO, NULL, dbglev)

extern	int	CRDDELIVINFOadd_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND);
extern	int	CRDDELIVINFOupdate_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND);
extern	int	CRDDELIVINFOdelete(CRDDELIVINFO_t *p_CRDDELIVINFO);
extern	void	CRDDELIVINFOdump_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND);
extern	void	CRDDELIVINFOdumplev_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, int dbglev);

extern	int	CRDDELIVINFOhv2cs(CRDDELIVINFO_t *p_CRDDELIVINFO);
extern	void	CRDDELIVINFOcs2hv(CRDDELIVINFO_t *p_CRDDELIVINFO);
extern	int	CRDDELIVINFOhs2cs(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_IND, HOST_CRDDELIVINFO_t *hsData, HOST_CRDDELIVINFO_IND_t *hsInd);

extern	void	CRDDELIVINFOcs2hsINS(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_IND, HOST_CRDDELIVINFO_t *hsData, HOST_CRDDELIVINFO_IND_t *hsInd);
extern	void	CRDDELIVINFOcs2hs(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_IND, HOST_CRDDELIVINFO_t *hsData, HOST_CRDDELIVINFO_IND_t *hsInd);
extern	void	FK_CRDDELIVINFO_ID_CRDDETdumplev(FK_CRDDELIVINFO_ID_CRDDET_t *p_FK_CRDDELIVINFO_ID_CRDDET, int dbglev);
extern	char	*FK_CRDDELIVINFO_ID_CRDDETkey2str(char *out, FK_CRDDELIVINFO_ID_CRDDET_t *p_FK_CRDDELIVINFO_ID_CRDDET);

extern	int	CRDDELIVINFOgetbyFK_CRDDELIVINFO_ID_CRDDET_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, FK_CRDDELIVINFO_ID_CRDDET_t *p_FK_CRDDELIVINFO_ID_CRDDET);
extern	int	CRDDELIVINFOgetbyFK_CRDDELIVINFO_ID_CRDDET4upd_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, FK_CRDDELIVINFO_ID_CRDDET_t *p_FK_CRDDELIVINFO_ID_CRDDET);
extern	int	CRDDELIVINFOupdbyFK_CRDDELIVINFO_ID_CRDDET_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, FK_CRDDELIVINFO_ID_CRDDET_t *p_FK_CRDDELIVINFO_ID_CRDDET);
extern	int	CRDDELIVINFOupdallbyFK_CRDDELIVINFO_ID_CRDDET_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, FK_CRDDELIVINFO_ID_CRDDET_t *p_FK_CRDDELIVINFO_ID_CRDDET);
extern	int	CRDDELIVINFOdelbyFK_CRDDELIVINFO_ID_CRDDET( FK_CRDDELIVINFO_ID_CRDDET_t *p_FK_CRDDELIVINFO_ID_CRDDET);

extern	void	CRDDELIVINFO_PKdumplev(CRDDELIVINFO_PK_t *p_CRDDELIVINFO_PK, int dbglev);
extern	char	*CRDDELIVINFO_PKkey2str(char *out, CRDDELIVINFO_PK_t *p_CRDDELIVINFO_PK);

extern	int	CRDDELIVINFOgetbyCRDDELIVINFO_PK_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, CRDDELIVINFO_PK_t *p_CRDDELIVINFO_PK);
extern	int	CRDDELIVINFOgetbyCRDDELIVINFO_PK4upd_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, CRDDELIVINFO_PK_t *p_CRDDELIVINFO_PK);
extern	int	CRDDELIVINFOupdbyCRDDELIVINFO_PK_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, CRDDELIVINFO_PK_t *p_CRDDELIVINFO_PK);
extern	int	CRDDELIVINFOupdallbyCRDDELIVINFO_PK_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, CRDDELIVINFO_PK_t *p_CRDDELIVINFO_PK);
extern	int	CRDDELIVINFOdelbyCRDDELIVINFO_PK( CRDDELIVINFO_PK_t *p_CRDDELIVINFO_PK);

extern	void	CRDDELIVINFOinitDflt(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND);

#ifdef __cplusplus
}
#endif

#endif
