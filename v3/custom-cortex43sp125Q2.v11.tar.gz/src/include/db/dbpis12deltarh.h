/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	PIS12_DELTA type defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBPIS12DELTARH_H
#define __DBPIS12DELTARH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
#include <dbpis12deltabsd.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define PIS12_DELTA_PK_PREP2 \
	PIS12_DELTA_PKid = p_PIS12_DELTA_PK->id;\

#define PIS12_DELTA_PK_PREP1 \
	pis12_delta.id = :v1 
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
#include <dbpis12deltadao.h>
/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif
#define PIS12_DELTAadd(pdata)					PIS12_DELTAadd_IND(pdata, NULL)
#define PIS12_DELTAupdate(pdata)				PIS12_DELTAupdate_IND(pdata, NULL)
#define PIS12_DELTAgetbyPIS12_DELTA_PK(pdata, phash)		PIS12_DELTAgetbyPIS12_DELTA_PK_IND(pdata, NULL, phash)
#define PIS12_DELTAgetbyPIS12_DELTA_PK4upd(pdata, phash)	PIS12_DELTAgetbyPIS12_DELTA_PK4upd_IND(pdata, NULL, phash)
#define PIS12_DELTAupdbyPIS12_DELTA_PK(pdata, phash)		PIS12_DELTAupdbyPIS12_DELTA_PK_IND(pdata, NULL, phash)
#define PIS12_DELTAupdallbyPIS12_DELTA_PK(pdata, phash)		PIS12_DELTAupdallbyPIS12_DELTA_PK_IND(pdata, NULL, phash)
#define PIS12_DELTAdump(p_PIS12_DELTA)				PIS12_DELTAdump_IND(p_PIS12_DELTA, NULL)
#define PIS12_DELTAdumplev(p_PIS12_DELTA, dbglev)		PIS12_DELTAdumplev_IND(p_PIS12_DELTA, NULL, dbglev)

extern	int	PIS12_DELTAadd_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND);
extern	int	PIS12_DELTAupdate_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND);
extern	int	PIS12_DELTAdelete(PIS12_DELTA_t *p_PIS12_DELTA);

extern	void	PIS12_DELTAdump_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND);
extern	void	PIS12_DELTAdumplev_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND, int dbglev);

extern	char	*PIS12_DELTA_PKkey2str(char *out, PIS12_DELTA_PK_t *p_PIS12_DELTA_PK);

extern	int	PIS12_DELTAgetbyPIS12_DELTA_PK_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND, PIS12_DELTA_PK_t *p_PIS12_DELTA_PK);
extern	int	PIS12_DELTAgetbyPIS12_DELTA_PK4upd_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND, PIS12_DELTA_PK_t *p_PIS12_DELTA_PK);
extern	int	PIS12_DELTAupdbyPIS12_DELTA_PK_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND, PIS12_DELTA_PK_t *p_PIS12_DELTA_PK);
extern	int	PIS12_DELTAupdallbyPIS12_DELTA_PK_IND(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND, PIS12_DELTA_PK_t *p_PIS12_DELTA_PK);
extern	int	PIS12_DELTAdelbyPIS12_DELTA_PK( PIS12_DELTA_PK_t *p_PIS12_DELTA_PK);
extern	void	PIS12_DELTAinitDflt(PIS12_DELTA_t *p_PIS12_DELTA, PIS12_DELTA_IND_t *p_PIS12_DELTA_IND);

#ifdef __cplusplus
}
#endif

#endif
