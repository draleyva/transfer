/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CRDDELIVINFO type defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBCRDDELIVINFORH_H
#define __DBCRDDELIVINFORH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
#include <dbcrddelivinfobsd.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define FK_CRDDELIVINFO_ID_CRDDET_PREP2 \
	FK_CRDDELIVINFO_ID_CRDDETcrddet_id = p_FK_CRDDELIVINFO_ID_CRDDET->crddet_id;\

#define FK_CRDDELIVINFO_ID_CRDDET_PREP1 \
	crddelivinfo.crddet_id = :v1 
#define CRDDELIVINFO_PK_PREP2 \
	CRDDELIVINFO_PKid = p_CRDDELIVINFO_PK->id;\

#define CRDDELIVINFO_PK_PREP1 \
	crddelivinfo.id = :v2 
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
#include <dbcrddelivinfodao.h>
/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif
#define CRDDELIVINFOadd(pdata)					CRDDELIVINFOadd_IND(pdata, NULL)
#define CRDDELIVINFOupdate(pdata)				CRDDELIVINFOupdate_IND(pdata, NULL)
#define CRDDELIVINFOgetbyFK_CRDDELIVINFO_ID_CRDDET(pdata, phash)	CRDDELIVINFOgetbyFK_CRDDELIVINFO_ID_CRDDET_IND(pdata, NULL, phash)
#define CRDDELIVINFOgetbyFK_CRDDELIVINFO_ID_CRDDET4upd(pdata, phash)	CRDDELIVINFOgetbyFK_CRDDELIVINFO_ID_CRDDET4upd_IND(pdata, NULL, phash)
#define CRDDELIVINFOupdbyFK_CRDDELIVINFO_ID_CRDDET(pdata, phash)	CRDDELIVINFOupdbyFK_CRDDELIVINFO_ID_CRDDET_IND(pdata, NULL, phash)
#define CRDDELIVINFOupdallbyFK_CRDDELIVINFO_ID_CRDDET(pdata, phash)	CRDDELIVINFOupdallbyFK_CRDDELIVINFO_ID_CRDDET_IND(pdata, NULL, phash)
#define CRDDELIVINFOgetbyCRDDELIVINFO_PK(pdata, phash)		CRDDELIVINFOgetbyCRDDELIVINFO_PK_IND(pdata, NULL, phash)
#define CRDDELIVINFOgetbyCRDDELIVINFO_PK4upd(pdata, phash)	CRDDELIVINFOgetbyCRDDELIVINFO_PK4upd_IND(pdata, NULL, phash)
#define CRDDELIVINFOupdbyCRDDELIVINFO_PK(pdata, phash)		CRDDELIVINFOupdbyCRDDELIVINFO_PK_IND(pdata, NULL, phash)
#define CRDDELIVINFOupdallbyCRDDELIVINFO_PK(pdata, phash)	CRDDELIVINFOupdallbyCRDDELIVINFO_PK_IND(pdata, NULL, phash)
#define CRDDELIVINFOdump(p_CRDDELIVINFO)			CRDDELIVINFOdump_IND(p_CRDDELIVINFO, NULL)
#define CRDDELIVINFOdumplev(p_CRDDELIVINFO, dbglev)		CRDDELIVINFOdumplev_IND(p_CRDDELIVINFO, NULL, dbglev)

extern	int	CRDDELIVINFOadd_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND);
extern	int	CRDDELIVINFOupdate_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND);
extern	int	CRDDELIVINFOdelete(CRDDELIVINFO_t *p_CRDDELIVINFO);

extern	void	CRDDELIVINFOdump_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND);
extern	void	CRDDELIVINFOdumplev_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, int dbglev);

extern	char	*FK_CRDDELIVINFO_ID_CRDDETkey2str(char *out, FK_CRDDELIVINFO_ID_CRDDET_t *p_FK_CRDDELIVINFO_ID_CRDDET);

extern	int	CRDDELIVINFOgetbyFK_CRDDELIVINFO_ID_CRDDET_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, FK_CRDDELIVINFO_ID_CRDDET_t *p_FK_CRDDELIVINFO_ID_CRDDET);
extern	int	CRDDELIVINFOgetbyFK_CRDDELIVINFO_ID_CRDDET4upd_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, FK_CRDDELIVINFO_ID_CRDDET_t *p_FK_CRDDELIVINFO_ID_CRDDET);
extern	int	CRDDELIVINFOupdbyFK_CRDDELIVINFO_ID_CRDDET_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, FK_CRDDELIVINFO_ID_CRDDET_t *p_FK_CRDDELIVINFO_ID_CRDDET);
extern	int	CRDDELIVINFOupdallbyFK_CRDDELIVINFO_ID_CRDDET_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, FK_CRDDELIVINFO_ID_CRDDET_t *p_FK_CRDDELIVINFO_ID_CRDDET);
extern	int	CRDDELIVINFOdelbyFK_CRDDELIVINFO_ID_CRDDET( FK_CRDDELIVINFO_ID_CRDDET_t *p_FK_CRDDELIVINFO_ID_CRDDET);
extern	void	CRDDELIVINFOinitDflt(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND);

extern	char	*CRDDELIVINFO_PKkey2str(char *out, CRDDELIVINFO_PK_t *p_CRDDELIVINFO_PK);

extern	int	CRDDELIVINFOgetbyCRDDELIVINFO_PK_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, CRDDELIVINFO_PK_t *p_CRDDELIVINFO_PK);
extern	int	CRDDELIVINFOgetbyCRDDELIVINFO_PK4upd_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, CRDDELIVINFO_PK_t *p_CRDDELIVINFO_PK);
extern	int	CRDDELIVINFOupdbyCRDDELIVINFO_PK_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, CRDDELIVINFO_PK_t *p_CRDDELIVINFO_PK);
extern	int	CRDDELIVINFOupdallbyCRDDELIVINFO_PK_IND(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND, CRDDELIVINFO_PK_t *p_CRDDELIVINFO_PK);
extern	int	CRDDELIVINFOdelbyCRDDELIVINFO_PK( CRDDELIVINFO_PK_t *p_CRDDELIVINFO_PK);
extern	void	CRDDELIVINFOinitDflt(CRDDELIVINFO_t *p_CRDDELIVINFO, CRDDELIVINFO_IND_t *p_CRDDELIVINFO_IND);

#ifdef __cplusplus
}
#endif

#endif
