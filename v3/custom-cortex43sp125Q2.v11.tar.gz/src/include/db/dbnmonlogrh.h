/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	NMON_LOG type defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBNMONLOGRH_H
#define __DBNMONLOGRH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
#include <dbnmonlogbsd.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define NMON_LOG_PK_PREP2 \
	NMON_LOG_PKid = p_NMON_LOG_PK->id;\

#define NMON_LOG_PK_PREP1 \
	nmon_log.id = :v1 
#define NMON_LOG_HASH_PREP2 \
	strscpy(NMON_LOG_HASHtstamp, p_NMON_LOG_HASH->tstamp);stp_right(NMON_LOG_HASHtstamp);\

#define NMON_LOG_HASH_PREP1 \
	nmon_log.tstamp = :v2 
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
#include <dbnmonlogdao.h>
/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif
#define NMON_LOGadd(pdata)					NMON_LOGadd_IND(pdata, NULL)
#define NMON_LOGupdate(pdata)					NMON_LOGupdate_IND(pdata, NULL)
#define NMON_LOGgetbyNMON_LOG_PK(pdata, phash)			NMON_LOGgetbyNMON_LOG_PK_IND(pdata, NULL, phash)
#define NMON_LOGgetbyNMON_LOG_PK4upd(pdata, phash)		NMON_LOGgetbyNMON_LOG_PK4upd_IND(pdata, NULL, phash)
#define NMON_LOGupdbyNMON_LOG_PK(pdata, phash)			NMON_LOGupdbyNMON_LOG_PK_IND(pdata, NULL, phash)
#define NMON_LOGupdallbyNMON_LOG_PK(pdata, phash)		NMON_LOGupdallbyNMON_LOG_PK_IND(pdata, NULL, phash)
#define NMON_LOGgetbyNMON_LOG_HASH(pdata, phash)		NMON_LOGgetbyNMON_LOG_HASH_IND(pdata, NULL, phash)
#define NMON_LOGgetbyNMON_LOG_HASH4upd(pdata, phash)		NMON_LOGgetbyNMON_LOG_HASH4upd_IND(pdata, NULL, phash)
#define NMON_LOGupdbyNMON_LOG_HASH(pdata, phash)		NMON_LOGupdbyNMON_LOG_HASH_IND(pdata, NULL, phash)
#define NMON_LOGupdallbyNMON_LOG_HASH(pdata, phash)		NMON_LOGupdallbyNMON_LOG_HASH_IND(pdata, NULL, phash)
#define NMON_LOGdump(p_NMON_LOG)				NMON_LOGdump_IND(p_NMON_LOG, NULL)
#define NMON_LOGdumplev(p_NMON_LOG, dbglev)			NMON_LOGdumplev_IND(p_NMON_LOG, NULL, dbglev)

extern	int	NMON_LOGadd_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND);
extern	int	NMON_LOGupdate_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND);
extern	int	NMON_LOGdelete(NMON_LOG_t *p_NMON_LOG);

extern	void	NMON_LOGdump_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND);
extern	void	NMON_LOGdumplev_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, int dbglev);

extern	char	*NMON_LOG_PKkey2str(char *out, NMON_LOG_PK_t *p_NMON_LOG_PK);

extern	int	NMON_LOGgetbyNMON_LOG_PK_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_PK_t *p_NMON_LOG_PK);
extern	int	NMON_LOGgetbyNMON_LOG_PK4upd_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_PK_t *p_NMON_LOG_PK);
extern	int	NMON_LOGupdbyNMON_LOG_PK_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_PK_t *p_NMON_LOG_PK);
extern	int	NMON_LOGupdallbyNMON_LOG_PK_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_PK_t *p_NMON_LOG_PK);
extern	int	NMON_LOGdelbyNMON_LOG_PK( NMON_LOG_PK_t *p_NMON_LOG_PK);
extern	void	NMON_LOGinitDflt(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND);

extern	char	*NMON_LOG_HASHkey2str(char *out, NMON_LOG_HASH_t *p_NMON_LOG_HASH);

extern	int	NMON_LOGgetbyNMON_LOG_HASH_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_HASH_t *p_NMON_LOG_HASH);
extern	int	NMON_LOGgetbyNMON_LOG_HASH4upd_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_HASH_t *p_NMON_LOG_HASH);
extern	int	NMON_LOGupdbyNMON_LOG_HASH_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_HASH_t *p_NMON_LOG_HASH);
extern	int	NMON_LOGupdallbyNMON_LOG_HASH_IND(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND, NMON_LOG_HASH_t *p_NMON_LOG_HASH);
extern	int	NMON_LOGdelbyNMON_LOG_HASH( NMON_LOG_HASH_t *p_NMON_LOG_HASH);
extern	void	NMON_LOGinitDflt(NMON_LOG_t *p_NMON_LOG, NMON_LOG_IND_t *p_NMON_LOG_IND);

#ifdef __cplusplus
}
#endif

#endif
