/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	FPADREC type defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBFPADRECRH_H
#define __DBFPADRECRH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
#include <dbfpadrecbsd.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define FPADREC_HASH_PREP2 \
	FPADREC_HASHcrddet_id = p_FPADREC_HASH->crddet_id;\

#define FPADREC_HASH_PREP1 \
	fpadrec.crddet_id = :v1 
#define FPADREC_PK_PREP2 \
	FPADREC_PKid = p_FPADREC_PK->id;\

#define FPADREC_PK_PREP1 \
	fpadrec.id = :v2 
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
#include <dbfpadrecdao.h>
/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif
#define FPADRECadd(pdata)					FPADRECadd_IND(pdata, NULL)
#define FPADRECupdate(pdata)					FPADRECupdate_IND(pdata, NULL)
#define FPADRECgetbyFPADREC_HASH(pdata, phash)			FPADRECgetbyFPADREC_HASH_IND(pdata, NULL, phash)
#define FPADRECgetbyFPADREC_HASH4upd(pdata, phash)		FPADRECgetbyFPADREC_HASH4upd_IND(pdata, NULL, phash)
#define FPADRECupdbyFPADREC_HASH(pdata, phash)			FPADRECupdbyFPADREC_HASH_IND(pdata, NULL, phash)
#define FPADRECupdallbyFPADREC_HASH(pdata, phash)		FPADRECupdallbyFPADREC_HASH_IND(pdata, NULL, phash)
#define FPADRECgetbyFPADREC_PK(pdata, phash)			FPADRECgetbyFPADREC_PK_IND(pdata, NULL, phash)
#define FPADRECgetbyFPADREC_PK4upd(pdata, phash)		FPADRECgetbyFPADREC_PK4upd_IND(pdata, NULL, phash)
#define FPADRECupdbyFPADREC_PK(pdata, phash)			FPADRECupdbyFPADREC_PK_IND(pdata, NULL, phash)
#define FPADRECupdallbyFPADREC_PK(pdata, phash)			FPADRECupdallbyFPADREC_PK_IND(pdata, NULL, phash)
#define FPADRECdump(p_FPADREC)					FPADRECdump_IND(p_FPADREC, NULL)
#define FPADRECdumplev(p_FPADREC, dbglev)			FPADRECdumplev_IND(p_FPADREC, NULL, dbglev)

extern	int	FPADRECadd_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND);
extern	int	FPADRECupdate_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND);
extern	int	FPADRECdelete(FPADREC_t *p_FPADREC);

extern	void	FPADRECdump_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND);
extern	void	FPADRECdumplev_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, int dbglev);

extern	char	*FPADREC_HASHkey2str(char *out, FPADREC_HASH_t *p_FPADREC_HASH);

extern	int	FPADRECgetbyFPADREC_HASH_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_HASH_t *p_FPADREC_HASH);
extern	int	FPADRECgetbyFPADREC_HASH4upd_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_HASH_t *p_FPADREC_HASH);
extern	int	FPADRECupdbyFPADREC_HASH_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_HASH_t *p_FPADREC_HASH);
extern	int	FPADRECupdallbyFPADREC_HASH_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_HASH_t *p_FPADREC_HASH);
extern	int	FPADRECdelbyFPADREC_HASH( FPADREC_HASH_t *p_FPADREC_HASH);
extern	void	FPADRECinitDflt(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND);

extern	char	*FPADREC_PKkey2str(char *out, FPADREC_PK_t *p_FPADREC_PK);

extern	int	FPADRECgetbyFPADREC_PK_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_PK_t *p_FPADREC_PK);
extern	int	FPADRECgetbyFPADREC_PK4upd_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_PK_t *p_FPADREC_PK);
extern	int	FPADRECupdbyFPADREC_PK_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_PK_t *p_FPADREC_PK);
extern	int	FPADRECupdallbyFPADREC_PK_IND(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND, FPADREC_PK_t *p_FPADREC_PK);
extern	int	FPADRECdelbyFPADREC_PK( FPADREC_PK_t *p_FPADREC_PK);
extern	void	FPADRECinitDflt(FPADREC_t *p_FPADREC, FPADREC_IND_t *p_FPADREC_IND);

#ifdef __cplusplus
}
#endif

#endif
