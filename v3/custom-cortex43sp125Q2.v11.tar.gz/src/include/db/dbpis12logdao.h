/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	PIS12_LOG DAO structure definitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBPIS12LOGDAO_H
#define __DBPIS12LOGDAO_H

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table PIS12_LOG
 */
typedef struct
{
	long	id;
	char	tstamp[21];
	char	tablename[33];
	char	keydata[65];
	char	hint[2];
	char	indicator1[33];
	char	indicator2[2];
	char	indicator3[2];
} PIS12_LOG_t;

#ifdef __cplusplus
/**
 * Structure for C++ interfacing of table PIS12_LOG
 */
struct CppClassPIS12_LOG_t : public PIS12_LOG_t
{
	CppClassPIS12_LOG_t (
		long _id = 0,
		const char * _tstamp = "",
		const char * _tablename = "",
		const char * _keydata = "",
		const char * _hint = "",
		const char * _indicator1 = "",
		const char * _indicator2 = "",
		const char * _indicator3 = ""
		)
	{
		id = _id;
		slstrcpy_sen(tstamp, _tstamp);
		slstrcpy_sen(tablename, _tablename);
		slstrcpy_sen(keydata, _keydata);
		slstrcpy_sen(hint, _hint);
		slstrcpy_sen(indicator1, _indicator1);
		slstrcpy_sen(indicator2, _indicator2);
		slstrcpy_sen(indicator3, _indicator3);
	}
};
#endif /*__cplusplus*/
/**
 * Structure of indicators for table  PIS12_LOG 
 */
typedef struct
{
	short	id;
	short	tstamp;
	short	tablename;
	short	keydata;
	short	hint;
	short	indicator1;
	short	indicator2;
	short	indicator3;
} PIS12_LOG_IND_t;

/**
 * Structure to retrieve PIS12_LOG by Primary Key PK_PIS12_LOG
 */
typedef struct
{
	long	id;
} PIS12_LOG_PK_t;

/**
 * Structure to retrieve PIS12_LOG by Primary Key HASH_PIS12_LOG
 */
typedef struct
{
	char	tstamp[21];
} PIS12_LOG_HASH_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/

#endif
