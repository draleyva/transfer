/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CRDSTATMAP access routines for managing database access (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __DBCRDSTATMAPES_H
#define __DBCRDSTATMAPES_H

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	extern	char	CRDSTATMAPctx_statcode[3];
	extern	char	CRDSTATMAPext_statcode[6];
	extern	char	CRDSTATMAPdescr[31];

	extern	char	CRDSTATMAP_PKext_statcode[6];
EXEC SQL END DECLARE SECTION;
/** @endcond */

/*---------------------------Macros-------------------------------------*/
#define CRDSTATMAP_HV \
:CRDSTATMAPctx_statcode,\
:CRDSTATMAPext_statcode,\
:CRDSTATMAPdescr

#define CRDSTATMAP_COL \
crdstatmap.ctx_statcode,\
crdstatmap.ext_statcode,\
crdstatmap.descr

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_CRDSTATMAP_t
	{
		char	ctx_statcode[3];
		char	ext_statcode[6];
		char	descr[31];
	} HOST_CRDSTATMAP_t;

	typedef struct HOST_CRDSTATMAP_IND_t
	{
		short	ctx_statcode_ind;
		short	ext_statcode_ind;
		short	descr_ind;
	} HOST_CRDSTATMAP_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
#define CRDSTATMAPdump(p_CRDSTATMAP)				CRDSTATMAPdump_IND(p_CRDSTATMAP, NULL)
#define CRDSTATMAPdumplev(p_CRDSTATMAP, dbglev)			CRDSTATMAPdumplev_IND(p_CRDSTATMAP, NULL, dbglev)

extern	int	CRDSTATMAPadd_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND);
extern	int	CRDSTATMAPupdate_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND);
extern	int	CRDSTATMAPdelete(CRDSTATMAP_t *p_CRDSTATMAP);
extern	void	CRDSTATMAPdump_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND);
extern	void	CRDSTATMAPdumplev_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND, int dbglev);

extern	int	CRDSTATMAPhv2cs(CRDSTATMAP_t *p_CRDSTATMAP);
extern	void	CRDSTATMAPcs2hv(CRDSTATMAP_t *p_CRDSTATMAP);
extern	int	CRDSTATMAPhs2cs(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_IND, HOST_CRDSTATMAP_t *hsData, HOST_CRDSTATMAP_IND_t *hsInd);

extern	void	CRDSTATMAPcs2hsINS(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_IND, HOST_CRDSTATMAP_t *hsData, HOST_CRDSTATMAP_IND_t *hsInd);
extern	void	CRDSTATMAPcs2hs(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_IND, HOST_CRDSTATMAP_t *hsData, HOST_CRDSTATMAP_IND_t *hsInd);
extern	void	CRDSTATMAP_PKdumplev(CRDSTATMAP_PK_t *p_CRDSTATMAP_PK, int dbglev);
extern	char	*CRDSTATMAP_PKkey2str(char *out, CRDSTATMAP_PK_t *p_CRDSTATMAP_PK);

extern	int	CRDSTATMAPgetbyCRDSTATMAP_PK_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND, CRDSTATMAP_PK_t *p_CRDSTATMAP_PK);
extern	int	CRDSTATMAPgetbyCRDSTATMAP_PK4upd_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND, CRDSTATMAP_PK_t *p_CRDSTATMAP_PK);
extern	int	CRDSTATMAPupdbyCRDSTATMAP_PK_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND, CRDSTATMAP_PK_t *p_CRDSTATMAP_PK);
extern	int	CRDSTATMAPupdallbyCRDSTATMAP_PK_IND(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND, CRDSTATMAP_PK_t *p_CRDSTATMAP_PK);
extern	int	CRDSTATMAPdelbyCRDSTATMAP_PK( CRDSTATMAP_PK_t *p_CRDSTATMAP_PK);

extern	void	CRDSTATMAPinitDflt(CRDSTATMAP_t *p_CRDSTATMAP, CRDSTATMAP_IND_t *p_CRDSTATMAP_IND);

#ifdef __cplusplus
}
#endif

#endif
