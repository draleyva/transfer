/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CUSTDET_X type defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBCUST_XRH_H
#define __DBCUST_XRH_H

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
#include <sqloratypes.h>
#include <infidxmap.h>
#include <dbcust_xbsd.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define CUSTDET_X_PK_PREP2 \
	CUSTDET_X_PKid = p_CUSTDET_X_PK->id;\

#define CUSTDET_X_PK_PREP1 \
	custdet_x.id = :v1 
#define FK_CUSTDET_X_ID_CUSTDET_PREP2 \
	FK_CUSTDET_X_ID_CUSTDETcustdet_id = p_FK_CUSTDET_X_ID_CUSTDET->custdet_id;\

#define FK_CUSTDET_X_ID_CUSTDET_PREP1 \
	custdet_x.custdet_id = :v2 
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
#include <dbcust_xdao.h>
/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif
#define CUSTDET_Xadd(pdata)					CUSTDET_Xadd_IND(pdata, NULL)
#define CUSTDET_Xupdate(pdata)					CUSTDET_Xupdate_IND(pdata, NULL)
#define CUSTDET_XgetbyCUSTDET_X_PK(pdata, phash)		CUSTDET_XgetbyCUSTDET_X_PK_IND(pdata, NULL, phash)
#define CUSTDET_XgetbyCUSTDET_X_PK4upd(pdata, phash)		CUSTDET_XgetbyCUSTDET_X_PK4upd_IND(pdata, NULL, phash)
#define CUSTDET_XupdbyCUSTDET_X_PK(pdata, phash)		CUSTDET_XupdbyCUSTDET_X_PK_IND(pdata, NULL, phash)
#define CUSTDET_XupdallbyCUSTDET_X_PK(pdata, phash)		CUSTDET_XupdallbyCUSTDET_X_PK_IND(pdata, NULL, phash)
#define CUSTDET_XgetbyFK_CUSTDET_X_ID_CUSTDET(pdata, phash)	CUSTDET_XgetbyFK_CUSTDET_X_ID_CUSTDET_IND(pdata, NULL, phash)
#define CUSTDET_XgetbyFK_CUSTDET_X_ID_CUSTDET4upd(pdata, phash)	CUSTDET_XgetbyFK_CUSTDET_X_ID_CUSTDET4upd_IND(pdata, NULL, phash)
#define CUSTDET_XupdbyFK_CUSTDET_X_ID_CUSTDET(pdata, phash)	CUSTDET_XupdbyFK_CUSTDET_X_ID_CUSTDET_IND(pdata, NULL, phash)
#define CUSTDET_XupdallbyFK_CUSTDET_X_ID_CUSTDET(pdata, phash)	CUSTDET_XupdallbyFK_CUSTDET_X_ID_CUSTDET_IND(pdata, NULL, phash)
#define CUSTDET_Xdump(p_CUSTDET_X)				CUSTDET_Xdump_IND(p_CUSTDET_X, NULL)
#define CUSTDET_Xdumplev(p_CUSTDET_X, dbglev)			CUSTDET_Xdumplev_IND(p_CUSTDET_X, NULL, dbglev)

extern	int	CUSTDET_Xadd_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND);
extern	int	CUSTDET_Xupdate_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND);
extern	int	CUSTDET_Xdelete(CUSTDET_X_t *p_CUSTDET_X);

extern	void	CUSTDET_Xdump_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND);
extern	void	CUSTDET_Xdumplev_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, int dbglev);

extern	char	*CUSTDET_X_PKkey2str(char *out, CUSTDET_X_PK_t *p_CUSTDET_X_PK);

extern	int	CUSTDET_XgetbyCUSTDET_X_PK_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, CUSTDET_X_PK_t *p_CUSTDET_X_PK);
extern	int	CUSTDET_XgetbyCUSTDET_X_PK4upd_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, CUSTDET_X_PK_t *p_CUSTDET_X_PK);
extern	int	CUSTDET_XupdbyCUSTDET_X_PK_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, CUSTDET_X_PK_t *p_CUSTDET_X_PK);
extern	int	CUSTDET_XupdallbyCUSTDET_X_PK_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, CUSTDET_X_PK_t *p_CUSTDET_X_PK);
extern	int	CUSTDET_XdelbyCUSTDET_X_PK( CUSTDET_X_PK_t *p_CUSTDET_X_PK);
extern	void	CUSTDET_XinitDflt(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND);

extern	char	*FK_CUSTDET_X_ID_CUSTDETkey2str(char *out, FK_CUSTDET_X_ID_CUSTDET_t *p_FK_CUSTDET_X_ID_CUSTDET);

extern	int	CUSTDET_XgetbyFK_CUSTDET_X_ID_CUSTDET_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, FK_CUSTDET_X_ID_CUSTDET_t *p_FK_CUSTDET_X_ID_CUSTDET);
extern	int	CUSTDET_XgetbyFK_CUSTDET_X_ID_CUSTDET4upd_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, FK_CUSTDET_X_ID_CUSTDET_t *p_FK_CUSTDET_X_ID_CUSTDET);
extern	int	CUSTDET_XupdbyFK_CUSTDET_X_ID_CUSTDET_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, FK_CUSTDET_X_ID_CUSTDET_t *p_FK_CUSTDET_X_ID_CUSTDET);
extern	int	CUSTDET_XupdallbyFK_CUSTDET_X_ID_CUSTDET_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, FK_CUSTDET_X_ID_CUSTDET_t *p_FK_CUSTDET_X_ID_CUSTDET);
extern	int	CUSTDET_XdelbyFK_CUSTDET_X_ID_CUSTDET( FK_CUSTDET_X_ID_CUSTDET_t *p_FK_CUSTDET_X_ID_CUSTDET);
extern	void	CUSTDET_XinitDflt(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND);

#ifdef __cplusplus
}
#endif

#endif
