/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CUSTDET_X access routines for managing database access (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/
#ifndef __DBCUST_XES_H
#define __DBCUST_XES_H

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-------------------------------------*/
#include <portable.h>
#include <sqlca.h>
#include <oci.h>
/*---------------------------Externs------------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	extern	long	CUSTDET_Xid;
	extern	long	CUSTDET_Xcustdet_id;
	extern	char	CUSTDET_Xusrdata1[33];
	extern	char	CUSTDET_Xusrdata2[33];
	extern	char	CUSTDET_Xusrdata3[33];
	extern	char	CUSTDET_Xusrdata4[33];
	extern	char	CUSTDET_Xusrdata5[33];
	extern	char	CUSTDET_Xusrdata6[33];

	extern	long	CUSTDET_X_PKid;
	extern	long	FK_CUSTDET_X_ID_CUSTDETcustdet_id;
EXEC SQL END DECLARE SECTION;
/** @endcond */

/*---------------------------Macros-------------------------------------*/
#define CUSTDET_X_HV \
:CUSTDET_Xid,\
:CUSTDET_Xcustdet_id,\
:CUSTDET_Xusrdata1,\
:CUSTDET_Xusrdata2,\
:CUSTDET_Xusrdata3,\
:CUSTDET_Xusrdata4,\
:CUSTDET_Xusrdata5,\
:CUSTDET_Xusrdata6

#define CUSTDET_X_COL \
custdet_x.id,\
custdet_x.custdet_id,\
custdet_x.usrdata1,\
custdet_x.usrdata2,\
custdet_x.usrdata3,\
custdet_x.usrdata4,\
custdet_x.usrdata5,\
custdet_x.usrdata6

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/** @cond NEVER_SHOW */
EXEC SQL BEGIN DECLARE SECTION;
	typedef struct HOST_CUSTDET_X_t
	{
		long	id;
		long	custdet_id;
		char	usrdata1[33];
		char	usrdata2[33];
		char	usrdata3[33];
		char	usrdata4[33];
		char	usrdata5[33];
		char	usrdata6[33];
	} HOST_CUSTDET_X_t;

	typedef struct HOST_CUSTDET_X_IND_t
	{
		short	id_ind;
		short	custdet_id_ind;
		short	usrdata1_ind;
		short	usrdata2_ind;
		short	usrdata3_ind;
		short	usrdata4_ind;
		short	usrdata5_ind;
		short	usrdata6_ind;
	} HOST_CUSTDET_X_IND_t;
EXEC SQL END DECLARE SECTION;
/** @endcond */
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
#define CUSTDET_Xdump(p_CUSTDET_X)				CUSTDET_Xdump_IND(p_CUSTDET_X, NULL)
#define CUSTDET_Xdumplev(p_CUSTDET_X, dbglev)			CUSTDET_Xdumplev_IND(p_CUSTDET_X, NULL, dbglev)

extern	int	CUSTDET_Xadd_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND);
extern	int	CUSTDET_Xupdate_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND);
extern	int	CUSTDET_Xdelete(CUSTDET_X_t *p_CUSTDET_X);
extern	void	CUSTDET_Xdump_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND);
extern	void	CUSTDET_Xdumplev_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, int dbglev);

extern	int	CUSTDET_Xhv2cs(CUSTDET_X_t *p_CUSTDET_X);
extern	void	CUSTDET_Xcs2hv(CUSTDET_X_t *p_CUSTDET_X);
extern	int	CUSTDET_Xhs2cs(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_IND, HOST_CUSTDET_X_t *hsData, HOST_CUSTDET_X_IND_t *hsInd);

extern	void	CUSTDET_Xcs2hsINS(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_IND, HOST_CUSTDET_X_t *hsData, HOST_CUSTDET_X_IND_t *hsInd);
extern	void	CUSTDET_Xcs2hs(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_IND, HOST_CUSTDET_X_t *hsData, HOST_CUSTDET_X_IND_t *hsInd);
extern	void	CUSTDET_X_PKdumplev(CUSTDET_X_PK_t *p_CUSTDET_X_PK, int dbglev);
extern	char	*CUSTDET_X_PKkey2str(char *out, CUSTDET_X_PK_t *p_CUSTDET_X_PK);

extern	int	CUSTDET_XgetbyCUSTDET_X_PK_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, CUSTDET_X_PK_t *p_CUSTDET_X_PK);
extern	int	CUSTDET_XgetbyCUSTDET_X_PK4upd_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, CUSTDET_X_PK_t *p_CUSTDET_X_PK);
extern	int	CUSTDET_XupdbyCUSTDET_X_PK_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, CUSTDET_X_PK_t *p_CUSTDET_X_PK);
extern	int	CUSTDET_XupdallbyCUSTDET_X_PK_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, CUSTDET_X_PK_t *p_CUSTDET_X_PK);
extern	int	CUSTDET_XdelbyCUSTDET_X_PK( CUSTDET_X_PK_t *p_CUSTDET_X_PK);

extern	void	FK_CUSTDET_X_ID_CUSTDETdumplev(FK_CUSTDET_X_ID_CUSTDET_t *p_FK_CUSTDET_X_ID_CUSTDET, int dbglev);
extern	char	*FK_CUSTDET_X_ID_CUSTDETkey2str(char *out, FK_CUSTDET_X_ID_CUSTDET_t *p_FK_CUSTDET_X_ID_CUSTDET);

extern	int	CUSTDET_XgetbyFK_CUSTDET_X_ID_CUSTDET_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, FK_CUSTDET_X_ID_CUSTDET_t *p_FK_CUSTDET_X_ID_CUSTDET);
extern	int	CUSTDET_XgetbyFK_CUSTDET_X_ID_CUSTDET4upd_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, FK_CUSTDET_X_ID_CUSTDET_t *p_FK_CUSTDET_X_ID_CUSTDET);
extern	int	CUSTDET_XupdbyFK_CUSTDET_X_ID_CUSTDET_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, FK_CUSTDET_X_ID_CUSTDET_t *p_FK_CUSTDET_X_ID_CUSTDET);
extern	int	CUSTDET_XupdallbyFK_CUSTDET_X_ID_CUSTDET_IND(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND, FK_CUSTDET_X_ID_CUSTDET_t *p_FK_CUSTDET_X_ID_CUSTDET);
extern	int	CUSTDET_XdelbyFK_CUSTDET_X_ID_CUSTDET( FK_CUSTDET_X_ID_CUSTDET_t *p_FK_CUSTDET_X_ID_CUSTDET);

extern	void	CUSTDET_XinitDflt(CUSTDET_X_t *p_CUSTDET_X, CUSTDET_X_IND_t *p_CUSTDET_X_IND);

#ifdef __cplusplus
}
#endif

#endif
