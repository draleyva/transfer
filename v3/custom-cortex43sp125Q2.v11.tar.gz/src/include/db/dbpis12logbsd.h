/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	PIS12_LOG buffer size defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBPIS12LOGBSD_H
#define __DBPIS12LOGBSD_H


#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define PIS12_LOG_TSTAMP_BUFFSIZE 21
#define PIS12_LOG_TABLENAME_BUFFSIZE 33
#define PIS12_LOG_KEYDATA_BUFFSIZE 65
#define PIS12_LOG_HINT_BUFFSIZE 2
#define PIS12_LOG_INDICATOR1_BUFFSIZE 33
#define PIS12_LOG_INDICATOR2_BUFFSIZE 2
#define PIS12_LOG_INDICATOR3_BUFFSIZE 2

#ifdef __cplusplus
}
#endif

#endif
