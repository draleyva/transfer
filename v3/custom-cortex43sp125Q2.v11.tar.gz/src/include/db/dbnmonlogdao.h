/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	NMON_LOG DAO structure definitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBNMONLOGDAO_H
#define __DBNMONLOGDAO_H

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table NMON_LOG
 */
typedef struct
{
	long	id;
	char	tstamp[21];
	char	tablename[33];
	char	keydata[65];
	char	hint[2];
	char	nmoncode[5];
	char	newvalue1[65];
	char	oldvalue1[65];
	char	newvalue2[65];
	char	oldvalue2[65];
	char	newvalue3[65];
	char	oldvalue3[65];
	char	newvalue4[65];
	char	oldvalue4[65];
	char	newvalue5[65];
	char	oldvalue5[65];
	char	newvalue6[65];
	char	oldvalue6[65];
	char	newvalue7[65];
	char	oldvalue7[65];
} NMON_LOG_t;

#ifdef __cplusplus
/**
 * Structure for C++ interfacing of table NMON_LOG
 */
struct CppClassNMON_LOG_t : public NMON_LOG_t
{
	CppClassNMON_LOG_t (
		long _id = 0,
		const char * _tstamp = "",
		const char * _tablename = "",
		const char * _keydata = "",
		const char * _hint = "",
		const char * _nmoncode = "",
		const char * _newvalue1 = "",
		const char * _oldvalue1 = "",
		const char * _newvalue2 = "",
		const char * _oldvalue2 = "",
		const char * _newvalue3 = "",
		const char * _oldvalue3 = "",
		const char * _newvalue4 = "",
		const char * _oldvalue4 = "",
		const char * _newvalue5 = "",
		const char * _oldvalue5 = "",
		const char * _newvalue6 = "",
		const char * _oldvalue6 = "",
		const char * _newvalue7 = "",
		const char * _oldvalue7 = ""
		)
	{
		id = _id;
		slstrcpy_sen(tstamp, _tstamp);
		slstrcpy_sen(tablename, _tablename);
		slstrcpy_sen(keydata, _keydata);
		slstrcpy_sen(hint, _hint);
		slstrcpy_sen(nmoncode, _nmoncode);
		slstrcpy_sen(newvalue1, _newvalue1);
		slstrcpy_sen(oldvalue1, _oldvalue1);
		slstrcpy_sen(newvalue2, _newvalue2);
		slstrcpy_sen(oldvalue2, _oldvalue2);
		slstrcpy_sen(newvalue3, _newvalue3);
		slstrcpy_sen(oldvalue3, _oldvalue3);
		slstrcpy_sen(newvalue4, _newvalue4);
		slstrcpy_sen(oldvalue4, _oldvalue4);
		slstrcpy_sen(newvalue5, _newvalue5);
		slstrcpy_sen(oldvalue5, _oldvalue5);
		slstrcpy_sen(newvalue6, _newvalue6);
		slstrcpy_sen(oldvalue6, _oldvalue6);
		slstrcpy_sen(newvalue7, _newvalue7);
		slstrcpy_sen(oldvalue7, _oldvalue7);
	}
};
#endif /*__cplusplus*/
/**
 * Structure of indicators for table  NMON_LOG 
 */
typedef struct
{
	short	id;
	short	tstamp;
	short	tablename;
	short	keydata;
	short	hint;
	short	nmoncode;
	short	newvalue1;
	short	oldvalue1;
	short	newvalue2;
	short	oldvalue2;
	short	newvalue3;
	short	oldvalue3;
	short	newvalue4;
	short	oldvalue4;
	short	newvalue5;
	short	oldvalue5;
	short	newvalue6;
	short	oldvalue6;
	short	newvalue7;
	short	oldvalue7;
} NMON_LOG_IND_t;

/**
 * Structure to retrieve NMON_LOG by Primary Key PK_NMON_LOG
 */
typedef struct
{
	long	id;
} NMON_LOG_PK_t;

/**
 * Structure to retrieve NMON_LOG by Primary Key HASH_NMON_LOG
 */
typedef struct
{
	char	tstamp[21];
} NMON_LOG_HASH_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/

#endif
