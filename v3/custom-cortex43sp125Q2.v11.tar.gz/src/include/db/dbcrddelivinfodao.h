/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CRDDELIVINFO DAO structure definitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBCRDDELIVINFODAO_H
#define __DBCRDDELIVINFODAO_H

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums----------------------------------------*/
/*---------------------------Typedefs-------------------------------------*/
/**
 * Structure defining table CRDDELIVINFO
 */
typedef struct
{
	long	id;
	long	crddet_id;
	short	person_type;
	char	person_name[101];
	char	doc_no[51];
	short	doc_type;
	char	usr_name[16];
	char	usr_term[51];
	long	deliv_date;
	long	deliv_time;
	char	deliv_type[2];
	long	deliv_branch_id;
} CRDDELIVINFO_t;

#ifdef __cplusplus
/**
 * Structure for C++ interfacing of table CRDDELIVINFO
 */
struct CppClassCRDDELIVINFO_t : public CRDDELIVINFO_t
{
	CppClassCRDDELIVINFO_t (
		long _id = 0,
		long _crddet_id = 0,
		short _person_type = 0,
		const char * _person_name = "",
		const char * _doc_no = "",
		short _doc_type = 0,
		const char * _usr_name = "",
		const char * _usr_term = "",
		long _deliv_date = 0,
		long _deliv_time = 0,
		const char * _deliv_type = "",
		long _deliv_branch_id = 0
		)
	{
		id = _id;
		crddet_id = _crddet_id;
		person_type = _person_type;
		slstrcpy_sen(person_name, _person_name);
		slstrcpy_sen(doc_no, _doc_no);
		doc_type = _doc_type;
		slstrcpy_sen(usr_name, _usr_name);
		slstrcpy_sen(usr_term, _usr_term);
		deliv_date = _deliv_date;
		deliv_time = _deliv_time;
		slstrcpy_sen(deliv_type, _deliv_type);
		deliv_branch_id = _deliv_branch_id;
	}
};
#endif /*__cplusplus*/
/**
 * Structure of indicators for table  CRDDELIVINFO 
 */
typedef struct
{
	short	id;
	short	crddet_id;
	short	person_type;
	short	person_name;
	short	doc_no;
	short	doc_type;
	short	usr_name;
	short	usr_term;
	short	deliv_date;
	short	deliv_time;
	short	deliv_type;
	short	deliv_branch_id;
} CRDDELIVINFO_IND_t;

/**
 * Structure to retrieve CRDDELIVINFO by Primary Key FK_CRDDELIVINFO_ID_CRDDET
 */
typedef struct
{
	long	crddet_id;
} FK_CRDDELIVINFO_ID_CRDDET_t;

/**
 * Structure to retrieve CRDDELIVINFO by Primary Key PK_CRDDELIVINFO
 */
typedef struct
{
	long	id;
} CRDDELIVINFO_PK_t;

/*---------------------------Globals--------------------------------------*/
/*---------------------------Statics--------------------------------------*/
/*---------------------------Prototypes-----------------------------------*/

#endif
