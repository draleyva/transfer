/*-----------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	CRDPINMIGR buffer size defininitions (ORACLE)
 *
 * @author	Graeme Thomas / Perl (wresqlora)
 *
 * @date	19 Mar 2024
 *
 * $Id$
 *
 * @copyright	FIS Global
 */
/*-----------------------------------------------------------------------*/
#ifndef __DBCRDPINMIGRBSD_H
#define __DBCRDPINMIGRBSD_H


#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------Includes-----------------------------------*/
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
#define CRDPINMIGR_PAN_NEW_BUFFSIZE 20
#define CRDPINMIGR_PAN_OLD_BUFFSIZE 20
#define CRDPINMIGR_EXPDATE_BUFFSIZE 5
#define CRDPINMIGR_PIN_OFFSET_BUFFSIZE 5

#ifdef __cplusplus
}
#endif

#endif
