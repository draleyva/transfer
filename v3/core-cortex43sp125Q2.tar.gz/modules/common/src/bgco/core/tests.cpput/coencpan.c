/*---------------------------------------------------------------------------*/
/**
 * @file	
 * 
 * @author	Dimitris Fourkiotis
 *
 * @brief	Unit tests for coenc library, conecpan object, encryption enabled
 * 		variants
 *
 * @remark	As DOENCPAN uses a static variable, encryption and non-encryption
 * 		tests must be run as separate binaries. Do not mix the cases.
 *
 * @date	20 Mar 2020
 * 
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/coencpan.c#3 $
 *
 * @copyright	FIS Global
 */
/*---------------------------------------------------------------------------*/
/** @cond INTERNAL */
/*------------------------------Includes-------------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sldbg.h>
#include <sltpmock.h>
#include <slntp.h>

#include <coencpan.h>

#include <CppUTest/TestHarness_c.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>

#include <atmi.h>
/*------------------------------Externs--------------------------------------*/
/*------------------------------Inlines--------------------------------------*/
/*------------------------------Macros---------------------------------------*/
/** Maximum PAN buffer size */
#define MAX_PAN_SIZE	19+1
/*------------------------------Enums----------------------------------------*/
/*------------------------------Typedefs-------------------------------------*/
/*------------------------------Globals--------------------------------------*/
/*------------------------------Statics--------------------------------------*/
/*------------------------------Prototypes-----------------------------------*/

/*------------------------------------------------------------------------*/
/**
 * @brief	Setup function for tests in the common_coenc_coencpan group
 *
 * @param[in]	common_coenc_coencpan Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_coenc_coencpan)
{
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);

	CHECK_EQUAL_C_INT(SUCCEED, setenv("CTXENCPAN", "TRUE", 1));
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_coenc_coencpan group
 *
 * @param[in]	common_coenc_coencpan Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_coenc_coencpan)
{
	CHECK_EQUAL_C_INT(SUCCEED, unsetenv("CTXENCPAN"));
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan encryption with an encrypted pan.
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_encryptPanSize_encPan Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_encryptPanSize_encPan)
{
#if IS_EXT_PANSVC()
	const char *clr_pan= "We62100000000000ec";
#else
	const char *clr_pan = "D16FCC1A194711D822D";
#endif
	char enc_pan_buf[MAX_PAN_SIZE] = {EOS};
	char *enc_pan = NULL;

	enc_pan = encryptPanSize(clr_pan, enc_pan_buf, sizeof(enc_pan_buf));
	CHECK_C(NULL != enc_pan);
	CHECK_EQUAL_C_STRING(enc_pan, clr_pan);
	CHECK_EQUAL_C_STRING(enc_pan_buf, clr_pan);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan encryption.
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_encryptPanSize Test description
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_encryptPanSize)
{
	const char *clr_pan = "541333000200106";
	char enc_pan_buf[MAX_PAN_SIZE] = {EOS};
	char *enc_pan = NULL;

	CHECK_EQUAL_C_INT(SUCCEED, setenv("CTX_TP_MOCK_TPCALL_FML32_SCRIPT",
					   "./mock_test_coencpan_encryptPanSize.py",
					   1));
	enc_pan = encryptPanSize(clr_pan, enc_pan_buf, sizeof(enc_pan_buf));
	CHECK_C(NULL != enc_pan);
#if IS_EXT_PANSVC()
	CHECK_EQUAL_C_STRING("We62100000000000ec", enc_pan_buf);
#else
	CHECK_EQUAL_C_STRING("D65B7F93F9076E63293", enc_pan_buf);
#endif
	CHECK_EQUAL_C_STRING(enc_pan_buf, enc_pan);

	CHECK_EQUAL_C_INT(SUCCEED, unsetenv("CTX_TP_MOCK_TPCALL_SCRIPT"));
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan encryption, service failure.
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_encryptPanSize_tpesvcfail Test description
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_encryptPanSize_tpesvcfail)
{
	const char *clr_pan = "541333000200106";
	char enc_pan_buf[MAX_PAN_SIZE] = {EOS};
	char *enc_pan = NULL;

	CHECK_EQUAL_C_INT(SUCCEED, setenv("CTX_TP_MOCK_TPCALL_FML32_SCRIPT",
					   "./mock_test_coencpan_encryptPanSize_tpesvcfail.py",
					   1));
	set_mock_tperrno(TPESVCFAIL);
	enc_pan = encryptPanSize(clr_pan, enc_pan_buf, sizeof(enc_pan_buf));
	CHECK_C(NULL == enc_pan);
	CHECK_EQUAL_C_STRING("", enc_pan_buf);

	CHECK_EQUAL_C_INT(SUCCEED, unsetenv("CTX_TP_MOCK_TPCALL_SCRIPT"));
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan encryption and verify overflow behaviour.
 *
 * @param[in]	common_coenc_noenc_coencpan Test group
 * @param[in]	test_coencpan_encryptPan_ovrflw Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_encryptPanSize_encPan_ovrflw)
{
#if IS_EXT_PANSVC()
	const char *clr_pan= "We62100000000000ecfff";
#else
	const char *clr_pan = "D17FCC1A194711D822F";
#endif
	char *enc_pan = NULL;
	char short_enc_pan_buf[MAX_PAN_SIZE-5] = {EOS};

	enc_pan = encryptPanSize(clr_pan, short_enc_pan_buf, sizeof(short_enc_pan_buf));
	CHECK_C(NULL == enc_pan);
	CHECK_EQUAL_C_CHAR(EOS, *short_enc_pan_buf);
	if ( IS_CTXPROF_ALLOWED(CTXPROF_COREDUMP) )
	{
		CHECK_C(-1 != system("rm core_*"));
	}

}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan encryption for a long pan.
 *
 * @param[in]	common_coenc_noenc_coencpan Test group
 * @param[in]	test_coencpan_encryptPanSize_longEncPan Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_encryptPanSize_longEncPan)
{
#if IS_EXT_PANSVC()
	const char *clr_pan= "We62100000000000ecfff";
#else
	const char *clr_pan = "D16FCC1A194711D822FFFF";
#endif
	char *enc_pan = NULL;
	char enc_pan_buf[MAX_PAN_SIZE] = {EOS};

	enc_pan = encryptPanSize(clr_pan, enc_pan_buf, sizeof(enc_pan_buf));
	CHECK_C(NULL == enc_pan);
	CHECK_EQUAL_C_CHAR(EOS, *enc_pan_buf);
	if ( IS_CTXPROF_ALLOWED(CTXPROF_COREDUMP) )
	{
		CHECK_C(-1 != system("rm core_*"));
	}

}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan encryption (static return).
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_encryptPan_encPan Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_encryptPan_encPan)
{
#if IS_EXT_PANSVC()
	char *clr_pan = "We62100000000000ec";
#else
	char *clr_pan = "D16FCC1A194711D822F";
#endif
	char *enc_pan = NULL;
	char enc_pan_buf[MAX_PAN_SIZE] = {EOS};

	enc_pan = encryptPan(clr_pan, enc_pan_buf);
	CHECK_C(NULL != enc_pan);
	CHECK_EQUAL_C_STRING(enc_pan, clr_pan);
	CHECK_EQUAL_C_CHAR(EOS, *enc_pan_buf);

}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan encryption (static return), for a pan longer than
 * 		(MAX_PAN_SIZE-1)
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_encryptPan_longEncPan Test description
 *
 * @remarks	The flow is different compared to passing a clear pan and no
 * 		encryption: for encryption enabled, we will fail, as we try to
 * 		copy the results in an intermediate buffer.
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_encryptPan_longEncPan)
{
#if IS_EXT_PANSVC()
	const char *long_clr_pan= "We62100000000000ecfff";
#else
	char *long_clr_pan = "D16FCC1A194711D822FFFF";
#endif
	char *enc_pan = NULL;
	char enc_pan_buf[MAX_PAN_SIZE] = {EOS};

	enc_pan = encryptPan(long_clr_pan, enc_pan_buf);
	CHECK_C(NULL == enc_pan);
	CHECK_EQUAL_C_CHAR(EOS, *enc_pan_buf);
	if ( IS_CTXPROF_ALLOWED(CTXPROF_COREDUMP) )
	{
		CHECK_C(-1 != system("rm core_*"));
	}
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Check caching of encrypted pans.
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_encryptPan_cachePan Test description
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_encryptPan_cachePan)
{

#if IS_EXT_PANSVC()
	const char *clr_pan= "We62100000000000ec";
#else
	char *clr_pan = "D58FCC1A194711D822F";
#endif
	char *enc_pan = NULL;
	char enc_pan_buf[MAX_PAN_SIZE] = {EOS};

	enc_pan = encryptPanSize(clr_pan, enc_pan_buf, sizeof(enc_pan_buf));
	CHECK_C(NULL != enc_pan);
	CHECK_EQUAL_C_STRING(enc_pan, clr_pan);
	CHECK_EQUAL_C_STRING(enc_pan, enc_pan_buf);

	/* now take the Pan from cache */
	enc_pan = encryptPanSize(clr_pan, enc_pan_buf, sizeof(enc_pan_buf));
	CHECK_C(NULL != enc_pan);
	CHECK_EQUAL_C_STRING(enc_pan, clr_pan);
	CHECK_EQUAL_C_STRING(enc_pan, enc_pan_buf);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan decryption with a clear pan.
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_decryptPanSize_clrPan Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_decryptPanSize_clrPan)
{
	const char *enc_pan = "5413330002001064";
	char clr_pan_buf[MAX_PAN_SIZE] = {EOS};
	char *clr_pan = NULL;

	clr_pan = decryptPanSize(clr_pan_buf, sizeof(clr_pan_buf), enc_pan);
	CHECK_C(NULL != clr_pan);
	CHECK_EQUAL_C_STRING(clr_pan, enc_pan);
	CHECK_EQUAL_C_STRING(clr_pan_buf, clr_pan);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan decryption and verify overflow behaviour
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_decryptPanSize_clrPan_ovrflw Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_decryptPanSize_clrPan_ovrflw)
{
	const char *enc_pan = "5413330009091064";
	char short_clr_pan_buf[MAX_PAN_SIZE-5] = {EOS};
	char *clr_pan = NULL;

	clr_pan = decryptPanSize(short_clr_pan_buf, sizeof(short_clr_pan_buf), enc_pan);
	CHECK_C(NULL == clr_pan);
	CHECK_EQUAL_C_CHAR(EOS, *short_clr_pan_buf);
	if ( IS_CTXPROF_ALLOWED(CTXPROF_COREDUMP) )
	{
		CHECK_C(-1 != system("rm core_*"));
	}
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan decryption and verify overflow behaviour
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_decryptPanSize_longClrPan Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_decryptPanSize_longClrPan)
{
	const char *enc_pan = "541333000909106499999";
	char clr_pan_buf[MAX_PAN_SIZE] = {EOS};
	char *clr_pan = NULL;

	clr_pan = decryptPanSize(clr_pan_buf, sizeof(clr_pan_buf), enc_pan);
	CHECK_C(NULL == clr_pan);
	CHECK_EQUAL_C_CHAR(EOS, *clr_pan_buf);
	if ( IS_CTXPROF_ALLOWED(CTXPROF_COREDUMP) )
	{
		CHECK_C(-1 != system("rm core_*"));
	}
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan decryption with a clear pan (static return).
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_decryptPan_clrPan Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_decryptPan_clrPan)
{
	char *enc_pan = "5413330002001064";
	char clr_pan_buf[MAX_PAN_SIZE] = {EOS};
	char *clr_pan = NULL;

	clr_pan = decryptPan(clr_pan_buf, enc_pan);
	CHECK_C(NULL != clr_pan);
	CHECK_EQUAL_C_STRING(clr_pan, enc_pan);
	CHECK_EQUAL_C_CHAR(EOS, *clr_pan_buf);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan decryption (static return), for a pan longer than
 * 		(MAX_PAN_SIZE-1)
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_decryptPan_longClrPan Test description
 *
 * @remarks	The flow is different compared to passing a clear pan and no
 * 		encryption: for encryption enabled, we will fail, as we try to
 * 		copy the results in an intermediate buffer.
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_decryptPan_longClrPan)
{
	char *long_enc_pan = "541333000909106499999";
	char *clr_pan = NULL;
	char clr_pan_buf[MAX_PAN_SIZE] = {EOS};

	clr_pan = decryptPan(clr_pan_buf, long_enc_pan);
	CHECK_C(NULL == clr_pan);
	CHECK_EQUAL_C_CHAR(EOS, *clr_pan_buf);
	if ( IS_CTXPROF_ALLOWED(CTXPROF_COREDUMP) )
	{
		CHECK_C(-1 != system("rm core_*"));
	}
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan translation.
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_translatePan_clrPan Test description
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_translatePan_clrPan)
{
	char *old_enc_pan = "5413330002001064";
	char *another_old_enc_pan = "5413330002001063";
	char new_enc_pan_buf[MAX_PAN_SIZE] = {EOS};
	char *ret_new_enc_pan = NULL;

	ret_new_enc_pan = translatePan(old_enc_pan, NULL);
	CHECK_C(NULL != ret_new_enc_pan);
	CHECK_EQUAL_C_STRING(old_enc_pan, ret_new_enc_pan);
	CHECK_EQUAL_C_CHAR(EOS, *new_enc_pan_buf);

	/* this validates taking the pan from cache */
	ret_new_enc_pan = translatePan(old_enc_pan, new_enc_pan_buf);
	CHECK_EQUAL_C_STRING(old_enc_pan, ret_new_enc_pan);
	CHECK_EQUAL_C_STRING(ret_new_enc_pan, new_enc_pan_buf);

	/* this validates copying the new pan in the buffer */
	ret_new_enc_pan = translatePan(another_old_enc_pan, new_enc_pan_buf);
	CHECK_EQUAL_C_STRING(another_old_enc_pan, ret_new_enc_pan);
	CHECK_EQUAL_C_STRING(ret_new_enc_pan, new_enc_pan_buf);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Request pan translation.
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_translatePan_longClrPan Test description
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_translatePan_longClrPan)
{
	char *long_old_enc_pan = "541333000200106499999";
	char new_enc_pan_buf[MAX_PAN_SIZE] = {EOS};
	char *ret_new_enc_pan = NULL;

	ret_new_enc_pan = translatePan(long_old_enc_pan, new_enc_pan_buf);
	CHECK_C(NULL == ret_new_enc_pan);
	CHECK_EQUAL_C_CHAR(EOS, *new_enc_pan_buf);
	if ( IS_CTXPROF_ALLOWED(CTXPROF_COREDUMP) )
	{
		CHECK_C(-1 != system("rm core_*"));
	}
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Check if pan encryption is enabled.
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_doencpan Test description
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_doencpan)
{
	CHECK_C(TRUE == doencpan());
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Generate display pan.
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_gen_pan_display Test description
 *
 * @remarks	This functions is only covered in these tests (encryption version).
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_gen_pan_display)
{
	char *clr_pan = "5413330002001064";
	char display_pan_buf[MAX_PAN_SIZE] = {EOS};
	char *display_pan = NULL;

	display_pan = gen_pan_display(clr_pan, display_pan_buf,
				      sizeof(display_pan_buf));
	CHECK_C(NULL != display_pan);
	CHECK_EQUAL_C_STRING(display_pan, "541333_1064");
	CHECK_EQUAL_C_STRING(display_pan, display_pan_buf);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Generate display pan, 3 digits pan
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_gen_pan_display_pan3Digits Test description
 *
 * @remarks	This functions is only covered in these tests (encryption version).
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_gen_pan_display_pan3Digits)
{
	char *clr_pan = "541";
	char display_pan_buf[MAX_PAN_SIZE] = {EOS};
	char *display_pan = NULL;

	display_pan = gen_pan_display(clr_pan, display_pan_buf,
				      sizeof(display_pan_buf));
	CHECK_C(NULL != display_pan);
	CHECK_EQUAL_C_STRING(display_pan, "541");
	CHECK_EQUAL_C_STRING(display_pan, display_pan_buf);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Generate display pan, 9 digits pan
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_gen_pan_display_pan9Digits Test description
 *
 * @remarks	This functions is only covered in these tests (encryption version).
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_gen_pan_display_pan9Digits)
{
	char *clr_pan = "541333999";
	char display_pan_buf[MAX_PAN_SIZE] = {EOS};
	char *display_pan = NULL;

	display_pan = gen_pan_display(clr_pan, display_pan_buf,
				      sizeof(display_pan_buf));
	CHECK_C(NULL != display_pan);
	CHECK_EQUAL_C_STRING(display_pan, "541333");
	CHECK_EQUAL_C_STRING(display_pan, display_pan_buf);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Generate display pan, 10 digits pan
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_gen_pan_display_pan10Digits Test description
 *
 * @remarks	This functions is only covered in these tests (encryption version).
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_gen_pan_display_pan10Digits)
{
	char *clr_pan = "5413339991";
	char display_pan_buf[MAX_PAN_SIZE] = {EOS};
	char *display_pan = NULL;

	display_pan = gen_pan_display(clr_pan, display_pan_buf,
				      sizeof(display_pan_buf));
	CHECK_C(NULL != display_pan);
	CHECK_EQUAL_C_STRING(display_pan, "541333_9991");
	CHECK_EQUAL_C_STRING(display_pan, display_pan_buf);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Generate display pan, overflow
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_gen_pan_display_ovrflw Test description
 *
 * @remarks	This functions is only covered in these tests (encryption version).
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_gen_pan_display_ovrflw)
{
	char *clr_pan = "5413330002001064";
	char short_display_pan_buf[4+1] = {EOS};
	char *display_pan = NULL;

	display_pan = gen_pan_display(clr_pan, short_display_pan_buf,
				      sizeof(short_display_pan_buf));
	CHECK_C(NULL != display_pan);
	CHECK_EQUAL_C_STRING(display_pan, "");
	CHECK_EQUAL_C_STRING(display_pan, short_display_pan_buf);
	if ( IS_CTXPROF_ALLOWED(CTXPROF_COREDUMP) )
	{
		CHECK_C(-1 != system("rm core_*"));
	}
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Generate display pan, for two different pans, using the same
 * 		destination buffer.
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_gen_pan_display_mltpl Test description
 *
 * @remarks	This functions is only covered in these tests (encryption version).
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_gen_pan_display_mltpl)
{
	char *clr_pan_first = "5413330002001064",
		*clr_pan_second = "2315780015902102";
	char display_pan_buf[MAX_PAN_SIZE] = {EOS};
	char *display_pan = NULL;

	display_pan = gen_pan_display(clr_pan_first, display_pan_buf,
				      sizeof(display_pan_buf));
	CHECK_C(NULL != display_pan);
	CHECK_EQUAL_C_STRING(display_pan, "541333_1064");
	CHECK_EQUAL_C_STRING(display_pan, display_pan_buf);
	
	display_pan = gen_pan_display(clr_pan_second, display_pan_buf,
				      sizeof(display_pan_buf));
	CHECK_C(NULL != display_pan);
	CHECK_EQUAL_C_STRING(display_pan, "231578_2102");
	CHECK_EQUAL_C_STRING(display_pan, display_pan_buf);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Check if it is clear pan or not
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_is_clear_pan Test description
 *
 * @remarks	This functions is only covered in these tests (encryption version).
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_is_clear_pan)
{
	char *clr_pan = "5413330002001064";
#if IS_EXT_PANSVC()
	char *enc_pan= "We62100000000000ec";
#else
	char *enc_pan = "D16FCC1A194711D822F";
#endif

	CHECK_C(TRUE == is_clear_pan(clr_pan));
	CHECK_C(FALSE == is_clear_pan(enc_pan));
	CHECK_C(FALSE  == is_clear_pan(""));
	CHECK_C(FALSE == is_clear_pan("54133300020010649999"));

}

/*------------------------------------------------------------------------*/
/**
 * @brief	Check if it is encrypted pan or not
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_is_clear_pan Test description
 *
 * @remarks	This functions is only covered in these tests (encryption version).
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_is_encrypted_pan)
{
	char *clr_pan = "5413330002001064";
#if IS_EXT_PANSVC()
	char *enc_pan= "We62100000000000ec";
	char *wrong_char_pan= "le62100000000000ec";
#else
	char *enc_pan = "D16FCC1A194711D822F";
	char *wrong_char_pan = "K16FCC1A194711D822FLLLLLL";
#endif

	CHECK_C(FALSE == is_encrypted_pan(clr_pan));
	CHECK_C(FALSE == is_encrypted_pan(wrong_char_pan));
	CHECK_C(TRUE == is_encrypted_pan(enc_pan));
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Check if it is encrypted pan or not using provided solution
 *
 * @param[in]	common_coenc_coencpan Test group
 * @param[in]	test_coencpan_is_encrypted_pan_solution Test description
 *
 * @remarks	This functions is only covered in these tests (encryption version).
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coencpan, test_coencpan_is_encrypted_pan_solution)
{
	char *clr_pan = "5413330002001064";

	char *enc_pan_xt = "We62100000000000ec";
	char *wrong_char_pan_xt = "le62100000000000ec";

	char *enc_pan_hsm = "D16FCC1A194711D822F";
	char *wrong_char_pan_hsm = "K16FCC1A194711D822FLLLLLL";

	/* External PAN Solution */
	CHECK_EQUAL_C_INT(FALSE, is_encrypted_pan_solution(clr_pan, TRUE));
	CHECK_EQUAL_C_INT(FALSE, is_encrypted_pan_solution(wrong_char_pan_xt, TRUE));
	CHECK_EQUAL_C_INT(TRUE, is_encrypted_pan_solution(enc_pan_xt, TRUE));
	
	/* Internal PAN Solution - HSM */
	CHECK_EQUAL_C_INT(FALSE, is_encrypted_pan_solution(clr_pan, FALSE));
	CHECK_EQUAL_C_INT(FALSE, is_encrypted_pan_solution(wrong_char_pan_hsm, FALSE));
	CHECK_EQUAL_C_INT(TRUE, is_encrypted_pan_solution(enc_pan_hsm, FALSE));	
}

/** @endcond */

