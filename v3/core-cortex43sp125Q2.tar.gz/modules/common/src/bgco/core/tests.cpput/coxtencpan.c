/*---------------------------------------------------------------------------*/
/**
 * @file	
 * 
 * @author	Dimitris Fourkiotis
 *
 * @brief	Unit tests for coenc library, coxtencpan object.
 *
 * @date	10 Nov 2021
 * 
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/coxtencpan.c#1 $
 *
 * @copyright	FIS Global
 */
/*---------------------------------------------------------------------------*/
/** @cond INTERNAL */
/*------------------------------Includes-------------------------------------*/
#include <portable.h>
#include <stdio.h>

#include <sldbg.h>
#include <sltpmock.h>
#include <slntp.h>

#include <coxtencpan.h>

#include <CppUTest/TestHarness_c.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>

#include <atmi.h>
/*------------------------------Externs--------------------------------------*/
/*------------------------------Inlines--------------------------------------*/
/*------------------------------Macros---------------------------------------*/
/** Maximum PAN buffer size */
#define PAN_SIZE	19
/*------------------------------Enums----------------------------------------*/
/*------------------------------Typedefs-------------------------------------*/
/*------------------------------Globals--------------------------------------*/
/*------------------------------Statics--------------------------------------*/
/*------------------------------Prototypes-----------------------------------*/

/*------------------------------------------------------------------------*/
/**
 * @brief	Setup function for tests in the common_coenc_coxtencpan group
 *
 * @param[in]	common_coenc_coxtencpan Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_coenc_coxtencpan)
{
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_coenc_coxtencpan group
 *
 * @param[in]	common_coenc_coxtencpan Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_coenc_coxtencpan)
{
	;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Verify if a PAN is FIS Token or not
 *
 * @param[in]	common_coenc_coxtencpan Test group
 * @param[in]	test_xtencpan_is_xtencrypted_pan Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coxtencpan, test_xtencpan_is_xtencrypted_pan)
{
	const char *token = "J5186150500787021a";
	const char *wrong_token = "A5186150500787021a";
	/* more than 18 digits, but we don't check length */
	const char *undetected_token = "J51861505007870212222a";
	const char *ctxpan = "D16FCC1A194711D822D";

	CHECK_EQUAL_C_BOOL(TRUE, is_xtencrypted_pan(token));
	CHECK_EQUAL_C_BOOL(FALSE, is_xtencrypted_pan(ctxpan));
	CHECK_EQUAL_C_BOOL(FALSE, is_xtencrypted_pan(wrong_token));
	CHECK_EQUAL_C_BOOL(FALSE, is_xtencrypted_pan(NULL));
	CHECK_EQUAL_C_BOOL(FALSE, is_xtencrypted_pan(""));
	CHECK_EQUAL_C_BOOL(TRUE, is_xtencrypted_pan(undetected_token));
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test for FIS Token de-tokenisation, including negative cases.
 *
 * @param[in]	common_coenc_coxtencpan Test group
 * @param[in]	test_xtencpan_is_xtencrypted_pan Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coxtencpan, test_xtencpan_xt_decryptPanSize)
{
	const char *token = "J5186150500787021a";
	char clrpan[PAN_SIZE+1] = {EOS};
	char *p_clrpan = NULL;

	CHECK_EQUAL_C_INT(SUCCEED, setenv("CTX_TP_MOCK_TPCALL_FML32_SCRIPT",
					   "./mock_test_coxtencpan.py",
					   TRUE));

	p_clrpan = xt_decryptPanSize(clrpan, sizeof(clrpan), token);
	CHECK_C(NULL != p_clrpan);
	CHECK_EQUAL_C_STRING("5186150500787021", clrpan);
	CHECK_EQUAL_C_STRING(clrpan, p_clrpan);

	p_clrpan = NULL;
	/* make sure we have not touched clear pan */
	strcpy(clrpan, "X");
	p_clrpan = xt_decryptPanSize(NULL, 0UL, token);
	CHECK_C(NULL != p_clrpan);
	CHECK_EQUAL_C_STRING("X", clrpan);
	CHECK_EQUAL_C_STRING("5186150500787021", p_clrpan);

	/* below are negative cases */
	/* smaller output buffer */
	p_clrpan = xt_decryptPanSize(clrpan, 10UL, token);
	CHECK_C(NULL == p_clrpan);
	CHECK_EQUAL_C_STRING("", clrpan);

	p_clrpan = "RESET_POINTER";
	/* returned field from service too long */
	CHECK_EQUAL_C_INT(SUCCEED, setenv("CTX_TP_MOCK_TPCALL_FML32_SCRIPT",
					   "./mock_test_coxtencpan_overflow.py",
					   TRUE));
	p_clrpan = xt_decryptPanSize(clrpan, sizeof(clrpan), token);
	CHECK_C(NULL == p_clrpan);
	CHECK_EQUAL_C_STRING("", clrpan);

	p_clrpan = "RESET_POINTER";
	/* service failed */
	CHECK_EQUAL_C_INT(SUCCEED, setenv("CTX_TP_MOCK_TPCALL_FML32_SCRIPT",
					   "./mock_test_coencpan_encryptPanSize_tpesvcfail.py",
					   TRUE));
	set_mock_tperrno(TPESVCFAIL);
	p_clrpan = xt_decryptPanSize(clrpan, sizeof(clrpan), token);
	CHECK_C(NULL == p_clrpan);
	CHECK_EQUAL_C_STRING("", clrpan);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test for FIS Token tokenisation, including negative cases.
 *
 * @param[in]	common_coenc_coxtencpan Test group
 * @param[in]	test_xtencpan_is_xtencrypted_pan Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_coenc_coxtencpan, test_xtencpan_xt_encryptPanSize)
{
	const char *clrpan = "5186150500787021";
	char token[PAN_SIZE+1] = {EOS};
	char *p_token = NULL;

	CHECK_EQUAL_C_INT(SUCCEED, setenv("CTX_TP_MOCK_TPCALL_FML32_SCRIPT",
					   "./mock_test_coxtencpan.py",
					   TRUE));

	p_token = xt_encryptPanSize(token, sizeof(token), clrpan);
	CHECK_C(NULL != p_token);
	CHECK_EQUAL_C_STRING("J5186150500787021a", token);
	CHECK_EQUAL_C_STRING(token, p_token);

	p_token = NULL;
	/* make sure we have not touched token */
	strcpy(token, "X");
	p_token = xt_encryptPanSize(NULL, 0UL, clrpan);
	CHECK_C(NULL != p_token);
	CHECK_EQUAL_C_STRING("X", token);
	CHECK_EQUAL_C_STRING("J5186150500787021a", p_token);

	/* below are negative cases */
	/* smaller output buffer */
	p_token = xt_encryptPanSize(token, 10UL, clrpan);
	CHECK_C(NULL == p_token);
	CHECK_EQUAL_C_STRING("", token);

	p_token = "RESET_POINTER";
	/* returned field from service too long */
	CHECK_EQUAL_C_INT(SUCCEED, setenv("CTX_TP_MOCK_TPCALL_FML32_SCRIPT",
					   "./mock_test_coxtencpan_overflow.py",
					   TRUE));
	p_token = xt_encryptPanSize(token, sizeof(token), clrpan);
	CHECK_C(NULL == p_token);
	CHECK_EQUAL_C_STRING("", token);

	p_token = "RESET_POINTER";
	/* service failed */
	CHECK_EQUAL_C_INT(SUCCEED, setenv("CTX_TP_MOCK_TPCALL_FML32_SCRIPT",
					   "./mock_test_coencpan_encryptPanSize_tpesvcfail.py",
					   TRUE));
	set_mock_tperrno(TPESVCFAIL);
	p_token = xt_encryptPanSize(token, sizeof(token), clrpan);
	CHECK_C(NULL == p_token);
	CHECK_EQUAL_C_STRING("", token);
}