/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Unit tests for core library, cobranch object
 *
 * @remarks	Memory leaks should be tested on Linux with valgrind i.e.
 *		valgrind --leak-check=yes ./test/test_stdlib
 *
 * @author	Jason Veneracion
 *
 * @date	27 March 2020
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/cobranch.c#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include <sldbg.h>
#include <slstring.h>
#include <slcpputest.h>
#include <dberr.h>
#include <cobranch.h>

#include <cacheBranch.h>

#include <CppUTest/TestHarness_c.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>

/*---------------------------Externs------------------------------------*/
extern void dump_branch_id_cache(void);
extern void dump_brncode_cache(void);
/*---------------------------Macros-------------------------------------*/
/** @cond INTERNAL */
#define	CACHE_DIR	"./cache"	/**< global cache directory */
#define	CACHE_NAME	"branch"	/**< name of cache and cache directory */
#define	CACHE_PATH	CACHE_DIR "/" CACHE_NAME	/**< cache full dir name */
#define MY_TEST_PRNT(x)	ret = get_branch_id_cache(&x, brncode, instcode);\
			brncode[0] = EOS;
			
#define MY_TEST_PRNT2(x)	ret = get_brncode_cache(x, brncode);\
			brncode[0] = EOS;
/** @endcond */
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
ctxprivate cache_t	*M_branchId   = NULL;	/**< branchId cache handler */
ctxprivate cache_t	*M_branchCode = NULL;	/**< branchCode cache handler */

ctxprivate cache_branch_handler_list_t	M_array_of_handlers[cache_branch_end_marker] =
{
	{.db_id = cache_branch_branchId,   .pp_cache = &M_branchId },
	{.db_id = cache_branch_branchCode, .pp_cache = &M_branchCode },
};
/*---------------------------Prototypes---------------------------------*/
ctxprivate int do_branch(char *branchinput, size_t branchinputsize, char *instcode, size_t instcodesize);
ctxprivate int do_branch2 (char *branchinput, size_t branchinputsize);
/*---------------------------Functions------------------------------------*/
/** @cond INTERNAL */

/*------------------------------------------------------------------------*/
/**
 * @brief	Setup function for tests in the common_core_cocbranch group
 *
 * @param[in]	common_core_cocbranch Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_core_cocbranch)
{
	int	ret = 0;
	
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);

	ret = makedir(CACHE_DIR);
	fprintf(stderr, "mkdir: %s  returned: %d, %s\n", CACHE_DIR, ret, strerror(errno));
	CHECK_C(0 == ret);	
	
	ret = makedir(CACHE_PATH);
	fprintf(stderr, "mkdir: %s  returned: %d, %s\n", CACHE_PATH, ret, strerror(errno));
	CHECK_C(0 == ret);
	
	if ( SUCCEED == ret )
	{
		ret = setup_cache_branch_handlers(FALSE, cache_usage_controller, M_array_of_handlers);
		CHECK_C(SUCCEED==ret);
	}

	DELETE_CACHE(&M_branchId);
	DELETE_CACHE(&M_branchCode);
	
	if ( SUCCEED == ret )
	{
		ret = BRANCHgetby_cache_setup_usage_mode(cache_usage_reader);
		CHECK_C(SUCCEED==ret);
	}
	
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_core_cocbranch group
 *
 * @param[in]	common_core_cocbranch Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_core_cocbranch)
{
	int	ret = 0;
	
	BRANCHgetby_cache_delete();

	ret = rmrf(CACHE_PATH);
	CHECK_C(0 == ret);
	
	ret = rmrf(CACHE_DIR);
	CHECK_C(0 == ret);

}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test get branch id and store in cche
 *
 * @param[in]	common_core_cocbranch Test group
 * @param[in]	test_get_branch_id_cache Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_cocbranch, test_get_branch_id_cache)
{
	int ret = FAIL;
	ctxprivate	char	branchinput[1024] = "IAB1BR01";
	ctxprivate char	instcode[20] = "IAB1";
	
	ret = do_branch(branchinput, sizeof(branchinput), instcode, sizeof(instcode));
	
	CHECK_C(SUCCEED == ret);
}


/*------------------------------------------------------------------------*/
/**
 * @brief	Test get branch id and store in cche
 *
 * @param[in]	common_core_cocbranch Test group
 * @param[in]	test_get_branch_id_cache Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_cocbranch, test_get_get_brncode_cache)
{
	int ret = FAIL;
	ctxprivate	char	branchinput[1024] = "1";
	
	ret = do_branch2(branchinput, sizeof(branchinput));
	
	CHECK_C(SUCCEED == ret);
}

/*------------------------------------------------------------------------*/
/** @cond INTERNAL */
/**
 * @brief	get branch
 *
 * @param[in]	branchinput Branch
 * @param[in]	branchinputsize Branch buffer size
 * @param[in]	instcode Inst
 * @param[in]	instcodesize Inst code size
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
ctxprivate int do_branch(char *branchinput, size_t branchinputsize, char *instcode, size_t instcodesize)
{
	long branch_id1 = 0;
	int 	ret = SUCCEED; 
	char	brncode[9];
	char 	*ptrbrn = branchinput; 

	while (*ptrbrn != EOS && SUCCEED == ret) 
	{
		sscanf(ptrbrn, "%s", brncode);
		ptrbrn += (strlen(brncode) + 1); 

		MY_TEST_PRNT(branch_id1);
		branch_id1 = 0;

		dump_branch_id_cache();
		
		CHECK_C(SUCCEED == ret);
	}
	free_branch_id_cache();	
	
	return ret; 
}
/** @endcond */



/*------------------------------------------------------------------------*/
/** @cond INTERNAL */
/**
 * @brief	get branch
 *
 * @param[in]	branchinput Branch
 * @param[in]	branchinputsize Branch buffer size
 * @param[in]	instcode Inst
 * @param[in]	instcodesize Inst code size
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
ctxprivate int do_branch2 (char *branchinput, size_t branchinputsize)
{
	long branch_id1 = 0;
	int 	ret = SUCCEED; 
	char	brncode[5];
	char 	*ptrbrnid = branchinput; 
	char longnum[11];

	while (*ptrbrnid != EOS && SUCCEED == ret) 
	{		
		sscanf(ptrbrnid, "%ld", &branch_id1);
		slsprintf_se(longnum, slsafe_sizeof(longnum), "%ld", branch_id1);
		ptrbrnid += (strlen(longnum) + 1); 
				
		MY_TEST_PRNT2(branch_id1);
		branch_id1 = 0;
		
		dump_brncode_cache();

		CHECK_C(SUCCEED == ret);
	}
	free_brncode_cache();
	
	return ret; 
}
/** @endcond */

