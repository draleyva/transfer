/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Unit tests for core library, cochannel object
 *
 * @remarks	Memory leaks should be tested on Linux with valgrind i.e.
 *		valgrind --leak-check=yes ./test/test_stdlib
 *
 * @author	Jason Veneracion
 *
 * @date	31 March 2020
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/cochannel.c#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <slntp.h>
#include <slnfb.h>
#include <sldbg.h>
#include <slfdbg.h>
#include <slstring.h>
#include <dberr.h>
#include <cochannel.h>

#include <coint.fd.h>
#include <cocrd.fd.h>

#include <CppUTest/TestHarness_c.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
/*---------------------------Functions------------------------------------*/
/** @cond INTERNAL */

/*------------------------------------------------------------------------*/
/**
 * @brief	Setup function for tests in the common_core_cochannel group
 *
 * @param[in]	common_core_cochannel Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_core_cochannel)
{
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_core_cochannel group
 *
 * @param[in]	common_core_cochannel Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_core_cochannel)
{
     ;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test cochannel
 *
 * @param[in]	common_core_cochannel Test group
 * @param[in]	test_cochannel_test1 Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_cochannel, test_cochannel_test1)
{
	int	ret = SUCCEED; 
	ctxprivate	char	channel[5] = "TEST";
	ctxprivate char 	channel_read[5] = ""; 
	ctxprivate	ctxbool	override=FALSE;

	FBFR *p_fb = (FBFR *)ntp_alloc("FML", NULL, 4096);
	if (NULL == p_fb)
	{
		ret=FAIL;
	}
	CHECK_C(SUCCEED == ret); 
	
	if (SUCCEED == ret 
	    && SUCCEED!=F_chg(p_fb, I_CHANNEL, 0, channel, 0))
	{
		ret=FAIL;
	}
	
	CHECK_C(SUCCEED == ret);
	
	if (SUCCEED == ret)
	{
		override = FALSE;
		ret = channel_set(p_fb, override);
	}
	CHECK_C(SUCCEED == ret);
	if (SUCCEED == ret)
	{
		CF_get(p_fb, I_CHANNEL, 0, (char *)&channel_read, 0, FLD_STRING); 
		CHECK_C(0 == strcmp(channel, channel_read));
	}

	if (SUCCEED == ret)
	{
		override = TRUE;
		CF_chg(p_fb, C_CRDACPTBUS, 0, "6011", 0, FLD_STRING);

		ret = channel_set(p_fb, override);
	}
	CHECK_C(SUCCEED == ret);
	if (SUCCEED == ret)
	{
		CF_get(p_fb, I_CHANNEL, 0, (char *)&channel_read, 0, FLD_STRING); 
		CHECK_C(0 == strcmp("ATM", channel_read));
	}
	
	ntp_free((char *)p_fb);
	
}

