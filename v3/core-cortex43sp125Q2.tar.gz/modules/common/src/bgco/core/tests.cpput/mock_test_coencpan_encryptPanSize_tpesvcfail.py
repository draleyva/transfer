#!/usr/bin/env python3

import sys

while True:
    input = sys.stdin.readline()
   
    if input == "\n":
        break
     # echo back 
    print("+{}".format(input.strip(("\n"))))
   
print("")
