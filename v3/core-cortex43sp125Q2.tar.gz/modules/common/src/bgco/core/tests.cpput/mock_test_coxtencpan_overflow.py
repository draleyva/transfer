#!/usr/bin/env python3

import sys
import os

aa_tuxFlds = {} # a dictionary with all the fields present in request

while True:
    input = sys.stdin.readline()
    
    if input == "\n":
        break

    input = input.strip("\n")

    fields = input.split("\t")

    aa_tuxFlds[fields[0]] = fields[1]

# encrypt
if "86" == aa_tuxFlds.get("K_FUNCODE"):
    print("+C_PAN\tJ5186150500787022222222222221a")
# decrypt
elif "87" == aa_tuxFlds.get("K_FUNCODE"):
    print("+C_PAN_CLR\t518615050078700000000000021")

#mark termination of the fielded buffer
print("")
