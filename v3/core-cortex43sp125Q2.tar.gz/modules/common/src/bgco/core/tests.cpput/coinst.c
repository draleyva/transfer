/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Unit tests for core library, coinst object
 *
 * @remarks	Memory leaks should be tested on Linux with valgrind i.e.
 *		valgrind --leak-check=yes ./test/test_stdlib
 *
 * @author	Jason Veneracion
 *
 * @date	31 March 2020
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/coinst.c#3 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include <sldbg.h>
#include <slstring.h>
#include <slcpputest.h>
#include <sldtm.h>
#include <dberr.h>
#include <coinst.h>
#include <cobranch.h>

#include <cacheInst.h>
#include <cacheBranch.h>

#include <dbinstrh.h>

#include <CppUTest/TestHarness_c.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>
/*---------------------------Externs------------------------------------*/
extern void dump_inst_id_cache(void);
extern void dump_instcode_cache(void); 
/*---------------------------Macros-------------------------------------*/
/** @cond INTERNAL */
#define	CACHE_DIR	"./cache"	/**< global cache directory */
#define MY_TEST_PRNT(x)	ret = get_instcode_cache(x, instcode);\
			DBG_PRINTF((dbg_syserr, "ret:%d instcode: <%s>",\
					ret, instcode)); \
			instcode[0] = EOS;
#define MY_TEST_PRNT2(x) ret = get_inst_id_cache(&inst_id, x);\
			DBG_PRINTF((dbg_syserr, "ret:%d inst_id: <%ld>",\
					ret, inst_id)); \
			inst_id = 0;
/** @endcond */
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/**
 * Directory names for database caches used by tests. All directories are located under CACHE_DIR
 */
char *M_cache_dir[] = {
        "inst",
        "branch"
};

ctxprivate cache_t	*M_instId   = NULL;	/**< instId cache handler */
ctxprivate cache_t	*M_instCode = NULL;	/**< instCode cache handler */
ctxprivate cache_t      *M_branchId   = NULL;   /**< branchId cache handler */
ctxprivate cache_t      *M_branchCode = NULL;   /**< branchCode cache handler */

ctxprivate cache_inst_handler_list_t	M_array_of_handlers[cache_inst_end_marker] =
{
	{.db_id = cache_inst_instId,   .pp_cache = &M_instId },
	{.db_id = cache_inst_instCode, .pp_cache = &M_instCode },
};

cache_branch_handler_list_t M_branch_handlers[cache_branch_end_marker] =
{
        {.db_id = cache_branch_branchId,   .pp_cache = &M_branchId },
        {.db_id = cache_branch_branchCode, .pp_cache = &M_branchCode },
};

/*---------------------------Prototypes---------------------------------*/
/*---------------------------Functions------------------------------------*/
/** @cond INTERNAL */

/*------------------------------------------------------------------------*/
/**
 * @brief	Setup function for tests in the common_core_coinst group
 *
 * @param[in]	common_core_coinst Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_core_coinst)
{
	int	ret = 0;
	size_t	i;
	char	path[32];
	
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);
	
	ret = makedir(CACHE_DIR);
	for (i = 0; (i < sizeof(M_cache_dir) / sizeof(char*)) && (0 == ret); i++)
	{
		slsprintf_se(path, sizeof(path), "%s/%s", CACHE_DIR, M_cache_dir[i]);
		ret = makedir(path);
		if (0 != ret)
		{
			DBG_PRINTF((dbg_syserr, "mkdir failed: \'%s\'", strerror(errno)));
		}
		CHECK_C(0 == ret);
	}
	
	if ( SUCCEED == ret )
	{
		ret = setup_cache_inst_handlers(FALSE, cache_usage_controller, M_array_of_handlers);
		CHECK_C(SUCCEED==ret);
	}

	DELETE_CACHE(&M_instId);
	DELETE_CACHE(&M_instCode);
	
	if ( SUCCEED == ret )
	{
		ret = INSTgetby_cache_setup_usage_mode(cache_usage_reader);
		CHECK_C(SUCCEED==ret);
	}

	if ( SUCCEED == ret )
	{
		ret = setup_cache_branch_handlers(FALSE, cache_usage_controller, M_branch_handlers);
		CHECK_EQUAL_C_INT(SUCCEED, ret);
	}

	DELETE_CACHE(&M_branchId);
	DELETE_CACHE(&M_branchCode);

	if ( SUCCEED == ret )
	{
		ret = BRANCHgetby_cache_setup_usage_mode(cache_usage_reader);
		CHECK_EQUAL_C_INT(SUCCEED, ret);
	}
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_core_coinst group
 *
 * @param[in]	common_core_coinst Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_core_coinst)
{
	int	ret = 0;
	size_t  i;
	char    path[32];
	
	INSTgetby_cache_delete();
	BRANCHgetby_cache_delete();

	for (i = 0; (i < sizeof(M_cache_dir) / sizeof(char*)) && (0 == ret); i++)
	{
		slsprintf_se(path, sizeof(path), "%s/%s", CACHE_DIR, M_cache_dir[i]);
		ret = rmrf(path);
		if (0 != ret)
		{
			DBG_PRINTF((dbg_syserr, "rmrf failed: \'%s\'", strerror(errno)));
		}
		CHECK_EQUAL_C_INT(SUCCEED, ret);
	}
	ret = rmrf(CACHE_DIR);
	CHECK_EQUAL_C_INT(SUCCEED, ret);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test get instcode cache
 *
 * @param[in]	common_core_coinst Test group
 * @param[in]	test_get_instcode_cache Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_coinst, test_get_instcode_cache)
{
	int ret = FAIL;
	long inst_id1 = 1, inst_id2 = 2;
	char instcode[5] = {0};

	DBG_PRINTF((dbg_syserr, "inst_id1: %ld, inst_id2: %ld",
					inst_id1, inst_id2));

	MY_TEST_PRNT(inst_id1);
	CHECK_C(SUCCEED == ret);
	
	MY_TEST_PRNT(inst_id1);
	CHECK_C(SUCCEED == ret);
	
	MY_TEST_PRNT(inst_id2);
	CHECK_C(SUCCEED == ret);

	dump_instcode_cache();

	free_instcode_cache();

	MY_TEST_PRNT(inst_id2);
	CHECK_C(SUCCEED == ret);

	MY_TEST_PRNT(inst_id1);
	CHECK_C(SUCCEED == ret);

	MY_TEST_PRNT(inst_id1);
	CHECK_C(SUCCEED == ret);
	
}


/*------------------------------------------------------------------------*/
/**
 * @brief	Test get instcode
 *
 * @param[in]	common_core_coinst Test group
 * @param[in]	test_get_instcode_cache Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_coinst, test_get_inst_id_cache)
{
	int ret = FAIL;
	long inst_id = 0;
	char instcode1[5] = "VISA";
	char instcode2[5] = "MCRD";

	DBG_PRINTF((dbg_syserr, "instcode1: %s, instcode2: %s",
			instcode1, instcode2));

	MY_TEST_PRNT2(instcode1);
	CHECK_C(SUCCEED == ret);
	
	MY_TEST_PRNT2(instcode1);
	CHECK_C(SUCCEED == ret);
	
	MY_TEST_PRNT2(instcode2);
	CHECK_C(SUCCEED == ret);

	dump_inst_id_cache();

	free_instcode_cache();

	MY_TEST_PRNT2(instcode2);
	CHECK_C(SUCCEED == ret);

	MY_TEST_PRNT2(instcode1);
	CHECK_C(SUCCEED == ret);

	MY_TEST_PRNT2(instcode1);
	CHECK_C(SUCCEED == ret);
	
	free_inst_id_cache();
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test get institution time zone offset
 *
 * @param[in]	common_core_coinst Test group
 * @param[in]	test_get_inst_tz_offset Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_coinst, test_get_inst_tz_offset)
{
	long inst_id = 0;
	char instcode_VISA[5] = "VISA";
	char instcode_MCRD[5] = "MCRD";
	char instcode_PLUS[5] = "PLUS";
	char instcode_AMEX[5] = "AMEX";

	// default_time_zone='+01:00' for VISA
	get_inst_id_cache(&inst_id, instcode_VISA);
	CHECK_EQUAL_C_LONG(3600, get_inst_tz_offset(inst_id));

	// default_time_zone='-02:30' for MCRD
	get_inst_id_cache(&inst_id, instcode_MCRD);
	CHECK_EQUAL_C_LONG(-(2*3600+30*60), get_inst_tz_offset(inst_id));

	// default_time_zone='Z' for PLUS
	get_inst_id_cache(&inst_id, instcode_PLUS);
	CHECK_EQUAL_C_LONG(0, get_inst_tz_offset(inst_id));

	// default_time_zone='+10:00 ABC' for AMEX
	get_inst_id_cache(&inst_id, instcode_AMEX);
	CHECK_EQUAL_C_LONG(10*3600, get_inst_tz_offset(inst_id));

	// Case when Institution record does not exist.
	// It is expected that it will be processor's local time zone.
	// Set local time zone to UTC.
	setenv("TZ", "STD0", 1);
   	tzset();
	CHECK_EQUAL_C_LONG(0, get_inst_tz_offset(0));
}

/*------------------------------------------------------------------------*/
/**
 * @brief       Test tenant_tz_date_time function
 *
 * @param[in]   common_core_coinst Test group
 * @param[in]   test_tenant_tz_date_time Test description
 *
 *
 * @return      void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_coinst, test_tenant_tz_date_time)
{
	char instcode_VISA[5] = "VISA";
	char valid_from[15];
	long inst_id = 0;
	long date_before, time_before;
	long date_after, time_after;
	long date_fn, time_fn;

	get_inst_id_cache(&inst_id, instcode_VISA);
	CHECK_EQUAL_C_INT(SUCCEED, tenant_local_date_time(inst_id, &date_before, &time_before));

	// Retrieving  date/time from tenant_tz_date_time function based on inst_id
	CHECK_EQUAL_C_INT(SUCCEED, tenant_tz_date_time(inst_id, valid_from, sizeof(valid_from)));
	sscanf(valid_from, "%08ld%06ld", &date_fn,&time_fn);

	CHECK_EQUAL_C_INT(SUCCEED, tenant_local_date_time(inst_id, &date_after, &time_after));

	// Compare if date/time value from tested function in range.
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_before, time_before, date_fn, time_fn));
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_fn, time_fn, date_after, time_after));

	// Negative cases
	CHECK_EQUAL_C_INT(FAIL, tenant_tz_date_time(inst_id, NULL, sizeof(valid_from)));
	CHECK_EQUAL_C_INT(FAIL, tenant_tz_date_time(inst_id, valid_from, 0));
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test tenant_local_date_time function
 *
 * @param[in]	common_core_coinst Test group
 * @param[in]	test_tenant_local_date_time Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_coinst, test_tenant_local_date_time)
{
	long inst_id = 0;
	char instcode_VISA[5] = "VISA";
	long date, time;
	long date_before, time_before;
	long date_after, time_after;

	// default_time_zone='+01:00' for VISA
	get_inst_id_cache(&inst_id, instcode_VISA);

	// UTC date&time before call to the tested function
	utc_dateAndTime(&date_before, &time_before);
	// Calling the tested function
	CHECK_EQUAL_C_INT(SUCCEED, tenant_local_date_time(inst_id, &date, &time));
	// UTC date&time after call to the tested function
	utc_dateAndTime(&date_after, &time_after);
	// Offset the UTC time to tenant's local time zone.
	ndate_ntime_add(&date_before, &time_before, 3600);
	ndate_ntime_add(&date_after, &time_after, 3600);
	// Compare if result from tested function in range.
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_before, time_before, date, time));
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date, time, date_after, time_after));

	// Negative cases
	CHECK_EQUAL_C_INT(FAIL, tenant_local_date_time(inst_id, NULL, &time));
	CHECK_EQUAL_C_INT(FAIL, tenant_local_date_time(inst_id, &date, NULL));
	CHECK_EQUAL_C_INT(FAIL, tenant_local_date_time(inst_id, NULL, NULL));
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test tenant_local_date function
 *
 * @param[in]	common_core_coinst Test group
 * @param[in]	test_tenant_local_date Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_coinst, test_tenant_local_date)
{
	long inst_id = 0;
	char instcode_AMEX[5] = "AMEX";
	long date;
	long date_before, time_before;
	long date_after, time_after;

	// default_time_zone='+10:00 ABC' for AMEX
	get_inst_id_cache(&inst_id, instcode_AMEX);

	// UTC date&time before call to the tested function
	utc_dateAndTime(&date_before, &time_before);
	// Calling the tested function
	date = tenant_local_date(inst_id);
	// UTC date&time after call to the tested function
	utc_dateAndTime(&date_after, &time_after);
	// Offset the UTC time to tenant's local time zone.
	ndate_ntime_add(&date_before, &time_before, 10*3600);
	ndate_ntime_add(&date_after, &time_after, 10*3600);
	// Compare if result from tested function in range.
	CHECK_C(date_before<=date);
	CHECK_C(date_after>=date);

	// Case when Institution record does not exist.
	// It is expected that it will be processor's local date.
	date_before = local_date();
	date = tenant_local_date(0);
	date_after = local_date();
	CHECK_C(date_before<=date);
	CHECK_C(date_after>=date);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test when_created_to_tenant_local_date and setIssuerTZ4when_created
 * 		functions
 *
 * @param[in]	common_core_coinst Test group
 * @param[in]	test_when_created_to_tenant_local_date Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_coinst, test_when_created_to_tenant_local_date)
{
	long inst_id = 0;
	char instcode_MCRD[5] = "MCRD";
	long date, time;

	// default_time_zone='-02:30' for MCRD
	get_inst_id_cache(&inst_id, instcode_MCRD);

	// when_created format is either YYYYMMDDhhmmssuuu or YYYYMMDDhhmmss

	// Cases for UTC time stamp in when_created
	setIssuerTZ4when_created(FALSE);
	CHECK_EQUAL_C_INT(SUCCEED, when_created_to_tenant_local_date(inst_id, "20220913141718311", &date));
	CHECK_EQUAL_C_LONG(20220913, date);
	CHECK_EQUAL_C_INT(SUCCEED, when_created_to_tenant_local_date(inst_id, "20220913021718311", &date));
	CHECK_EQUAL_C_LONG(20220912, date);
	CHECK_EQUAL_C_INT(SUCCEED, when_created_to_tenant_local_date(inst_id, "20220101022900000", &date));
	CHECK_EQUAL_C_LONG(20211231, date);
	CHECK_EQUAL_C_INT(SUCCEED, when_created_to_tenant_local_date(inst_id, "20220101023100000", &date));
	CHECK_EQUAL_C_LONG(20220101, date);
	CHECK_EQUAL_C_INT(SUCCEED, when_created_to_tenant_local_date(inst_id, "20220913141718", &date));
	CHECK_EQUAL_C_LONG(20220913, date);
	CHECK_EQUAL_C_INT(SUCCEED, when_created_to_tenant_local_date(inst_id, "20220101022900", &date));
	CHECK_EQUAL_C_LONG(20211231, date);

	// Cases for Tenant's time zone time stamp in when_created
	setIssuerTZ4when_created(TRUE);
	CHECK_EQUAL_C_INT(SUCCEED, when_created_to_tenant_local_date(inst_id, "20220913141718311", &date));
	CHECK_EQUAL_C_LONG(20220913, date);
	CHECK_EQUAL_C_INT(SUCCEED, when_created_to_tenant_local_date(inst_id, "20220913021718311", &date));
	CHECK_EQUAL_C_LONG(20220913, date);
	CHECK_EQUAL_C_INT(SUCCEED, when_created_to_tenant_local_date(inst_id, "20220101022900000", &date));
	CHECK_EQUAL_C_LONG(20220101, date);
	CHECK_EQUAL_C_INT(SUCCEED, when_created_to_tenant_local_date(inst_id, "20220101023100000", &date));
	CHECK_EQUAL_C_LONG(20220101, date);
	CHECK_EQUAL_C_INT(SUCCEED, when_created_to_tenant_local_date(inst_id, "20220913141718", &date));
	CHECK_EQUAL_C_LONG(20220913, date);
	CHECK_EQUAL_C_INT(SUCCEED, when_created_to_tenant_local_date(inst_id, "20220101022900", &date));
	CHECK_EQUAL_C_LONG(20220101, date);

	// Negative case 
	CHECK_EQUAL_C_INT(FAIL, when_created_to_tenant_local_date(inst_id, NULL, &date));
	CHECK_EQUAL_C_INT(FAIL, when_created_to_tenant_local_date(inst_id, "20220913141718311", NULL));
	CHECK_EQUAL_C_INT(FAIL, when_created_to_tenant_local_date(inst_id, NULL, NULL));
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test tenant_to_processor_local_date_time function
 *
 * @param[in]	common_core_coinst Test group
 * @param[in]	test_tenant_to_processor_local_date_time Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_coinst, test_tenant_to_processor_local_date_time)
{
	long inst_id = 0;
	char instcode_VISA[5] = "VISA";
	long date, time;

	// default_time_zone='+01:00' for VISA
	get_inst_id_cache(&inst_id, instcode_VISA);

	// Change local time zone. Notice that offset has opposite sign than in ISO 8601
	// So difference is -6h between tenant's time zone and local time zone
	setenv("TZ", "STD5", 1);
   	tzset();

	CHECK_EQUAL_C_INT(SUCCEED, 
		tenant_to_processor_local_date_time(inst_id, 20220916, 103410, 
		&date, &time));
	CHECK_EQUAL_C_LONG(20220916, date);
	// Time 6h less;
	CHECK_EQUAL_C_LONG(43410, time);

	CHECK_EQUAL_C_INT(SUCCEED, 
		tenant_to_processor_local_date_time(inst_id, 20220916, 11600, 
		&date, &time));
	// One day before
	CHECK_EQUAL_C_LONG(20220915, date);
	CHECK_EQUAL_C_LONG(191600, time);

	// Case when Institution record does not exist.
	// It is expected that tenant's time zone will be same as local (processor's) time zone.
	CHECK_EQUAL_C_INT(SUCCEED, 
		tenant_to_processor_local_date_time(0, 20220916, 11600, 
		&date, &time));
	CHECK_EQUAL_C_LONG(20220916, date);
	CHECK_EQUAL_C_LONG(11600, time);

	// Negative cases
	CHECK_EQUAL_C_INT(FAIL, 
		tenant_to_processor_local_date_time(inst_id, 20220916, 103410, 
		NULL, &time));
	CHECK_EQUAL_C_INT(FAIL, 
		tenant_to_processor_local_date_time(inst_id, 20220916, 103410, 
		&date, NULL));
	CHECK_EQUAL_C_INT(FAIL, 
		tenant_to_processor_local_date_time(inst_id, 20220916, 103410, 
		NULL, NULL));
}

/*------------------------------------------------------------------------*/
/**
 * @brief       Test dbget_instid_by_branchid function
 *
 * @param[in]   common_core_coinst Test group
 * @param[in]   test_dbget_instid_by_branchid Test description
 *
 *
 * @return      void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_coinst, test_dbget_instid_by_branchid)
{
	long inst_id    = 0;
	long branch_id  = 0;
	char *instcode  = "IAB1";
	char *brncode   = "IAB1BR01";
        INST_HASH_t     inst_test_hash;
        INST_t          inst;
        INST_IND_t      inst_test_ind;
        BRANCH_HASH_t   branch_test_hash;
        BRANCH_t        branch;
        BRANCH_IND_t    branch_test_ind;

	slmemfillv(inst_test_hash,   0);
	slmemfillv(inst,             0);
	slmemfillv(inst_test_ind,    0);
	slmemfillv(branch_test_hash, 0);
	slmemfillv(branch,           0);
	slmemfillv(branch_test_ind,  0);

	strncpy(inst_test_hash.instcode, instcode, sizeof(inst_test_hash.instcode));

	/* To get inst record for a given instcode */
	CHECK_EQUAL_C_INT(SUCCEED, INSTgetbyINST_HASH_IND(&inst, &inst_test_ind, &inst_test_hash));
	branch_test_hash.inst_id = inst.id;

	strncpy(branch_test_hash.brncode, brncode, sizeof(branch_test_hash.brncode));
 
	/* To get branch record for a given inst id */
	CHECK_EQUAL_C_INT(SUCCEED, BRANCHgetbyBRANCH_HASH_IND(&branch, &branch_test_ind, &branch_test_hash));
	branch_id = branch.id;

	/* To get inst id for a given branch id */
	CHECK_EQUAL_C_INT(SUCCEED, dbget_instid_by_branchid(&inst_id, branch_id));
	CHECK_EQUAL_C_LONG(inst.id, inst_id);

	CHECK_EQUAL_C_INT(FAIL, dbget_instid_by_branchid(&inst_id, 0));
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Test tenant_or_gmt_timestamp function
 *
 * @param[in]	common_core_coinst Test group
 * @param[in]	test_tenant_or_gmt_timestamp Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_coinst, test_tenant_or_gmt_timestamp)
{
	long inst_id = 0;
	char instcode_VISA[5] = "VISA";
	long date, time;
	long date_wronginst, time_wronginst;
	long date_gmt, time_gmt, date_gmt2, time_gmt2;
	long date_tenant, time_tenant;
	long date_before, time_before;
	long date_after, time_after;

	char timestamp_default[UTCTIMESTAMPLEN+1];
	char timestamp_gmt[UTCTIMESTAMPLEN+1];
	char timestamp_tenant[UTCTIMESTAMPLEN+1];
	char *p_timestamp_ret;

	// default_time_zone='+01:00' for VISA
	get_inst_id_cache(&inst_id, instcode_VISA);

	// UTC date&time before call to the tested function
	utc_dateAndTime(&date_before, &time_before);

	// Calling tenant_or_gmt_timestamp function
	// with M_IssuerTZ4when_created uninitialized
	p_timestamp_ret = tenant_or_gmt_timestamp(inst_id, timestamp_default, sizeof(timestamp_default));
	CHECK_EQUAL_C_POINTER(timestamp_default, p_timestamp_ret);
	CHECK_EQUAL_C_INT(SUCCEED, utc_timestamp2date_time(p_timestamp_ret, &date, &time, NULL));

	// UTC date&time after call to tenant_or_gmt_timestamp function
	utc_dateAndTime(&date_after, &time_after);

	// Check if result of tenant_or_gmt_timestamp function is in GMT range.
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_before, time_before, date, time));
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date, time, date_after, time_after));


	// Calling tenant_or_gmt_timestamp function
	// with M_IssuerTZ4when_created set to TRUE
	setIssuerTZ4when_created(TRUE);

	// UTC date&time before call to the tested function
	utc_dateAndTime(&date_before, &time_before);

	p_timestamp_ret = tenant_or_gmt_timestamp(inst_id, timestamp_tenant, sizeof(timestamp_tenant));
	CHECK_EQUAL_C_POINTER(timestamp_tenant, p_timestamp_ret);
	CHECK_EQUAL_C_INT(SUCCEED, utc_timestamp2date_time(p_timestamp_ret, &date_tenant, &time_tenant, NULL));

	p_timestamp_ret = tenant_or_gmt_timestamp(0, NULL, 0);
	CHECK_C(NULL != p_timestamp_ret);
	CHECK_EQUAL_C_INT(SUCCEED, utc_timestamp2date_time(p_timestamp_ret, &date_wronginst, &time_wronginst, NULL));

	// UTC date&time after call to tenant_or_gmt_timestamp function
	utc_dateAndTime(&date_after, &time_after);

	// Check if result of tenant_or_gmt_timestamp function with invalid INST.ID is in local time zone.
	// Convert it to UTC value and compare with UTC range.
	long local_offset = get_local_tz_offset();
	ndate_ntime_add(&date_wronginst, &time_wronginst, -local_offset);
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_before, time_before, date_wronginst, time_wronginst));
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_wronginst, time_wronginst, date_after, time_after));

	// Offset the UTC time to tenant's local time zone.
	ndate_ntime_add(&date_before, &time_before, 3600);
	ndate_ntime_add(&date_after, &time_after, 3600);

	// Check if result of tenant_or_gmt_timestamp function is in Tenant's timezone range.
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_before, time_before, date_tenant, time_tenant));
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_tenant, time_tenant, date_after, time_after));


	// Calling tenant_or_gmt_timestamp function
	// with M_IssuerTZ4when_created set to FALSE
	setIssuerTZ4when_created(FALSE);

	// UTC date&time before call to the tested function
	utc_dateAndTime(&date_before, &time_before);

	p_timestamp_ret = tenant_or_gmt_timestamp(inst_id, timestamp_gmt, sizeof(timestamp_gmt));
	CHECK_EQUAL_C_POINTER(timestamp_gmt, p_timestamp_ret);
	CHECK_EQUAL_C_INT(SUCCEED, utc_timestamp2date_time(p_timestamp_ret, &date_gmt, &time_gmt, NULL));

	p_timestamp_ret = tenant_or_gmt_timestamp(inst_id, NULL, 0);
	CHECK_C(NULL != p_timestamp_ret);
	CHECK_C(timestamp_gmt != p_timestamp_ret);
	CHECK_C(timestamp_tenant != p_timestamp_ret);
	CHECK_EQUAL_C_INT(SUCCEED, utc_timestamp2date_time(p_timestamp_ret, &date_gmt2, &time_gmt2, NULL));

	// UTC date&time after call to tenant_or_gmt_timestamp function
	utc_dateAndTime(&date_after, &time_after);

	// Check if result of tenant_or_gmt_timestamp function is in GMT range.
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_before, time_before, date_gmt, time_gmt));
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_gmt, time_gmt, date_after, time_after));
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_before, time_before, date_gmt2, time_gmt2));
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_gmt2, time_gmt2, date_after, time_after));
}
/*------------------------------------------------------------------------*/
/**
 * @brief	Test test_tenant_timestamp function
 *
 * @param[in]	common_core_coinst Test group
 * @param[in]	test_tenant_timestamp Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_coinst, test_tenant_timestamp)
{
	long inst_id = 0;
	char instcode_VISA[5] = "VISA";
	long date_tenant, time_tenant;
	long date_before, time_before;
	long date_after, time_after;

	char timestamp_tenant[UTCTIMESTAMPLEN+1];
	char *p_timestamp_ret;
	
	// default_time_zone='+01:00' for VISA
	get_inst_id_cache(&inst_id, instcode_VISA);

	// UTC date&time before call to the tested function
 	utc_dateAndTime(&date_before, &time_before);

	p_timestamp_ret = tenant_timestamp(inst_id, timestamp_tenant, sizeof(timestamp_tenant));
	CHECK_EQUAL_C_POINTER(timestamp_tenant, p_timestamp_ret);
	CHECK_EQUAL_C_INT(SUCCEED, utc_timestamp2date_time(p_timestamp_ret, &date_tenant, &time_tenant, NULL));
	
	// UTC date&time after call to tenant_timestamp function
	utc_dateAndTime(&date_after, &time_after);

	// Offset the UTC time to tenant's local time zone.
	ndate_ntime_add(&date_before, &time_before, 3600);
	ndate_ntime_add(&date_after, &time_after, 3600);

	// Check if result of tenant_timestamp function is in Tenant's timezone range.
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_before, time_before, date_tenant, time_tenant));
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_tenant, time_tenant, date_after, time_after));
	
	// UTC date&time before call to the tested function
	utc_dateAndTime(&date_before, &time_before);

	p_timestamp_ret = tenant_timestamp(inst_id, NULL, 0);
	CHECK_C(NULL != p_timestamp_ret);
	CHECK_C(timestamp_tenant != p_timestamp_ret);
	CHECK_EQUAL_C_INT(SUCCEED, utc_timestamp2date_time(p_timestamp_ret, &date_tenant, &time_tenant, NULL));
	
	// UTC date&time after call to tenant_timestamp function
	utc_dateAndTime(&date_after, &time_after);
	
	// Offset the UTC time to tenant's local time zone.
	ndate_ntime_add(&date_before, &time_before, 3600);
	ndate_ntime_add(&date_after, &time_after, 3600);
	
	// Check if result of tenant_timestamp function is in Tenant's timezone range.
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_before, time_before, date_tenant, time_tenant));
	CHECK_EQUAL_C_INT(TRUE, date_time_less_eq(date_tenant, time_tenant, date_after, time_after));
}
