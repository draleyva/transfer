/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Unit tests for core library
 *
 * @author	Dimitris Fourkiotis
 *
 * @date	17 Feb 2020
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/test_core.cpp#3 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

#include <CppUTest/TestHarness_c.h>
#include <CppUTest/CommandLineTestRunner.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>
/*---------------------------Externs------------------------------------*/
extern "C"
{
	extern int sql_close(void);
	extern int sql_abort(void);
	extern int sql_open(char *dbname);
}
/*---------------------------Macros-------------------------------------*/
#define MAX_PATH_LEN 512

/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
/*---------------------------Functions----------------------------------*/
/** @cond INTERNAL */

/*---------------------------< cocrdacptloc >---------------------------*/

TEST_GROUP_C_WRAPPER(common_core_cocrdacptloc)
{
    TEST_GROUP_C_SETUP_WRAPPER(common_core_cocrdacptloc);
    TEST_GROUP_C_TEARDOWN_WRAPPER(common_core_cocrdacptloc);
};
TEST_C_WRAPPER(common_core_cocrdacptloc, test_cocrdacptloc_set_withinrange)
TEST_C_WRAPPER(common_core_cocrdacptloc, test_cocrdacptloc_set_nocity)
TEST_C_WRAPPER(common_core_cocrdacptloc, test_cocrdacptloc_set_partial)
TEST_C_WRAPPER(common_core_cocrdacptloc, test_cocrdacptloc_split)

/*---------------------------< cobranch >---------------------------*/

TEST_GROUP_C_WRAPPER(common_core_cocbranch)
{
    TEST_GROUP_C_SETUP_WRAPPER(common_core_cocbranch);
    TEST_GROUP_C_TEARDOWN_WRAPPER(common_core_cocbranch);
};
TEST_C_WRAPPER(common_core_cocbranch, test_get_branch_id_cache)
TEST_C_WRAPPER(common_core_cocbranch, test_get_get_brncode_cache)

/*---------------------------< coinst >---------------------------*/

TEST_GROUP_C_WRAPPER(common_core_coinst)
{
    TEST_GROUP_C_SETUP_WRAPPER(common_core_coinst);
    TEST_GROUP_C_TEARDOWN_WRAPPER(common_core_coinst);
};
TEST_C_WRAPPER(common_core_coinst, test_get_instcode_cache)
TEST_C_WRAPPER(common_core_coinst, test_get_inst_id_cache)
TEST_C_WRAPPER(common_core_coinst, test_get_inst_tz_offset)
TEST_C_WRAPPER(common_core_coinst, test_tenant_local_date_time)
TEST_C_WRAPPER(common_core_coinst, test_tenant_local_date)
TEST_C_WRAPPER(common_core_coinst, test_when_created_to_tenant_local_date)
TEST_C_WRAPPER(common_core_coinst, test_tenant_to_processor_local_date_time)
TEST_C_WRAPPER(common_core_coinst, test_tenant_tz_date_time)
TEST_C_WRAPPER(common_core_coinst, test_dbget_instid_by_branchid)
TEST_C_WRAPPER(common_core_coinst, test_tenant_or_gmt_timestamp)
TEST_C_WRAPPER(common_core_coinst, test_tenant_timestamp)

/*---------------------------< dbfblog >---------------------------*/
TEST_GROUP_C_WRAPPER(common_core_dbfblog)
{
    TEST_GROUP_C_SETUP_WRAPPER(common_core_dbfblog);
    TEST_GROUP_C_TEARDOWN_WRAPPER(common_core_dbfblog);
};
TEST_C_WRAPPER(common_core_dbfblog, test_dbfblog_lgorg2fb_test)
TEST_C_WRAPPER(common_core_dbfblog, test_dbfblog_fb2lg_test)
TEST_C_WRAPPER(common_core_dbfblog, test_dbfblog_vcps_log2fb_test)
TEST_C_WRAPPER(common_core_dbfblog, test_dbfblog_alg_fb2lg_test)
TEST_C_WRAPPER(common_core_dbfblog, test_dbfblog_set_tradedamtcur_test)
TEST_C_WRAPPER(common_core_dbfblog, test_dbfblog_set_curtxnfee_test)
TEST_C_WRAPPER(common_core_dbfblog, test_dbfblog_set_curprocfee_test)
TEST_C_WRAPPER(common_core_dbfblog, test_dbfblog_set_curtxnorg_test)
TEST_C_WRAPPER(common_core_dbfblog, test_dbfblog_set_curtax_test)
TEST_C_WRAPPER(common_core_dbfblog, test_dbfblog_set_curcom_test)

/*---------------------------< cotxn >---------------------------*/
TEST_GROUP_C_WRAPPER(common_core_cotxn)
{
    TEST_GROUP_C_SETUP_WRAPPER(common_core_cotxn);
    TEST_GROUP_C_TEARDOWN_WRAPPER(common_core_cotxn);
};
TEST_C_WRAPPER(common_core_cotxn, test_cotxn_txn_creation_test)
TEST_C_WRAPPER(common_core_cotxn, test_cotxn_txn_retrieval_test)
TEST_C_WRAPPER(common_core_cotxn, test_cotxn_txn_reversal_test)
TEST_C_WRAPPER(common_core_cotxn, test_cotxn_txn_set_test)
TEST_C_WRAPPER(common_core_cotxn, test_cotxn_txn_alog_test)
TEST_C_WRAPPER(common_core_cotxn, test_cotxn_txn_updalogrsp_test)
TEST_C_WRAPPER(common_core_cotxn, test_cotxn_txn_misc_test)
TEST_C_WRAPPER(common_core_cotxn, test_cotxn_get_ld_unld_sign)


/*---------------------------< cocbf >---------------------------*/

TEST_GROUP_C_WRAPPER(common_core_cocbf)
{
    TEST_GROUP_C_SETUP_WRAPPER(common_core_cocbf);
    TEST_GROUP_C_TEARDOWN_WRAPPER(common_core_cocbf);
};
TEST_C_WRAPPER(common_core_cocbf, test_cocbf_test1)
TEST_C_WRAPPER(common_core_cocbf, test_cocbf_set_failure_ext)

/*---------------------------< cocchrfr >---------------------------*/

TEST_GROUP_C_WRAPPER(common_core_cocchrfr)
{
    TEST_GROUP_C_SETUP_WRAPPER(common_core_cocchrfr);
    TEST_GROUP_C_TEARDOWN_WRAPPER(common_core_cocchrfr);
};
TEST_C_WRAPPER(common_core_cocchrfr, test_cocchrfr_test1)

/*---------------------------< cochannel >---------------------------*/

TEST_GROUP_C_WRAPPER(common_core_cochannel)
{
    TEST_GROUP_C_SETUP_WRAPPER(common_core_cochannel);
    TEST_GROUP_C_TEARDOWN_WRAPPER(common_core_cochannel);
};
TEST_C_WRAPPER(common_core_cochannel, test_cochannel_test1)

/*---------------------------< coencnm >---------------------------*/

TEST_GROUP_C_WRAPPER(common_core_coencnm)
{
    TEST_GROUP_C_SETUP_WRAPPER(common_core_coencnm);
    TEST_GROUP_C_TEARDOWN_WRAPPER(common_core_coencnm);
};
TEST_C_WRAPPER(common_core_coencnm, test_coencnm_test1)


/*---------------------------< comsc >---------------------------*/

TEST_GROUP_C_WRAPPER(common_core_comsc)
{
    TEST_GROUP_C_SETUP_WRAPPER(common_core_comsc);
    TEST_GROUP_C_TEARDOWN_WRAPPER(common_core_comsc);
};
TEST_C_WRAPPER(common_core_comsc, test_comsc_get_msc_numeric_str)
TEST_C_WRAPPER(common_core_comsc, test_comsc_get_msc_string)
TEST_C_WRAPPER(common_core_comsc, test_comsc_get_msc_string_ovrflw)
TEST_C_WRAPPER(common_core_comsc, test_comsc_get_msc_numeric_short)
TEST_C_WRAPPER(common_core_comsc, test_comsc_get_msc_numeric_long)
TEST_C_WRAPPER(common_core_comsc, test_comsc_get_msc_numeric_date)
TEST_C_WRAPPER(common_core_comsc, test_comsc_get_msc_numeric_double)
/*TEST_C_WRAPPER(common_core_comsc, test_comsc_get_msc_string_lock)*/

/*---------------------------< coproc >---------------------------*/

TEST_GROUP_C_WRAPPER(common_core_coproc)
{
    TEST_GROUP_C_SETUP_WRAPPER(common_core_coproc);
    TEST_GROUP_C_TEARDOWN_WRAPPER(common_core_coproc);
};
TEST_C_WRAPPER(common_core_coproc, test_coproc_test1)


/*---------------------------< cosvcnm >---------------------------*/

TEST_GROUP_C_WRAPPER(common_core_cosvcnm)
{
    TEST_GROUP_C_SETUP_WRAPPER(common_core_cosvcnm);
    TEST_GROUP_C_TEARDOWN_WRAPPER(common_core_cosvcnm);
};
TEST_C_WRAPPER(common_core_cosvcnm, test_cosvcnm_test1)


/*---------------------------< cotraded >---------------------------*/

TEST_GROUP_C_WRAPPER(common_core_cotraded)
{
    TEST_GROUP_C_SETUP_WRAPPER(common_core_cotraded);
    TEST_GROUP_C_TEARDOWN_WRAPPER(common_core_cotraded);
};
TEST_C_WRAPPER(common_core_cotraded, test_cotraded_test1)


/** @endcond */

/*---------------------------< crdseqno >---------------------------*/

TEST_GROUP_C_WRAPPER(common_core_crdseqno)
{
    TEST_GROUP_C_SETUP_WRAPPER(common_core_crdseqno);
    TEST_GROUP_C_TEARDOWN_WRAPPER(common_core_crdseqno);
};
TEST_C_WRAPPER(common_core_crdseqno, get_crdseqno_fb)


/*------------------------------------------------------------------------*/
/**
 * @brief	Test runner
 *
 * @param[in]	argc - Number of command line parameters
 * @param[in]	argv - Array with command line parameters
 *
 * @retval	SUCCEED
 * @retval	FAIL
 */
/*------------------------------------------------------------------------*/
int main(int argc, char **argv)
{
	int ret = 0;
static char pwd[MAX_PATH_LEN];
static char ctxcfg[2*MAX_PATH_LEN];

	getcwd(pwd, MAX_PATH_LEN);
	strcpy(ctxcfg, "CTXCFG=");
	strcat(ctxcfg, pwd);
	strcat(ctxcfg, "/ctxcfg");

	if (0 != putenv(ctxcfg))
	{
		fprintf(stderr, "Could not set up CTXCFG� %s\n", strerror(errno));
		return 1;
	}
	fprintf(stderr, "CTXCFG: <%s>\n", getenv("CTXCFG"));

	ret = sql_open(NULL);

	if ( 0 == ret )
	{
		ret = RUN_ALL_TESTS(argc, argv);
	}

	sql_abort();
	sql_close();
	return ret;
}
/** @endcond */

