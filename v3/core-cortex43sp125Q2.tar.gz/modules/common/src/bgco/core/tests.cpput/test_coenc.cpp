/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Unit tests for coenc library
 *
 * @author	Dimitris Fourkiotis
 *
 * @date	30 Mar 2020
 *
 * @remark	This file contains tests that assume encryption IS enabled. As
 * 		DOENCPAN macro is using a static global, enc/non-enc tests must
 * 		be executed as separate binaries
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/test_coenc.cpp#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <CppUTest/TestHarness_c.h>
#include <CppUTest/CommandLineTestRunner.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>

extern "C"
{
#undef FAIL /* workaround for collision with UtestMacros.h efinition */
#include <sldbg.h>
}
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
/*---------------------------Functions----------------------------------*/
/** @cond INTERNAL */

/*---------------------------< coencpan >---------------------------*/
TEST_GROUP_C_WRAPPER(common_coenc_coencpan)
{
	TEST_GROUP_C_SETUP_WRAPPER(common_coenc_coencpan);
	TEST_GROUP_C_TEARDOWN_WRAPPER(common_coenc_coencpan);
};
/* Encrypt cases */
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_encryptPanSize)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_encryptPanSize_tpesvcfail)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_encryptPanSize_encPan)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_encryptPanSize_encPan_ovrflw)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_encryptPanSize_longEncPan)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_encryptPan_encPan)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_encryptPan_longEncPan)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_encryptPan_cachePan)
/* Decrypt cases */
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_decryptPanSize_clrPan)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_decryptPanSize_clrPan_ovrflw)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_decryptPanSize_longClrPan)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_decryptPan_clrPan)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_decryptPan_longClrPan)
/* Translate pan cases */
#if !IS_EXT_PANSVC()
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_translatePan_clrPan)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_translatePan_longClrPan)
#endif
/* Generate display pan cases */
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_gen_pan_display)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_gen_pan_display_pan3Digits)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_gen_pan_display_pan9Digits)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_gen_pan_display_pan10Digits)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_gen_pan_display_ovrflw)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_gen_pan_display_mltpl)
/* Other helping functions */
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_doencpan)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_is_clear_pan)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_is_encrypted_pan)
TEST_C_WRAPPER(common_coenc_coencpan, test_coencpan_is_encrypted_pan_solution)

/*---------------------------< coencpanfb >---------------------------*/
TEST_GROUP_C_WRAPPER(common_coenc_coencpanfb)
{
	TEST_GROUP_C_SETUP_WRAPPER(common_coenc_coencpanfb);
	TEST_GROUP_C_TEARDOWN_WRAPPER(common_coenc_coencpanfb);
};

TEST_C_WRAPPER(common_coenc_coencpanfb, test_coencpanfb_encryptPanFb_encPan)
TEST_C_WRAPPER(common_coenc_coencpanfb, test_coencpanfb_encryptPanFb_longEncPan)
TEST_C_WRAPPER(common_coenc_coencpanfb, test_coencpanfb_decryptPanFb_clrPan)
TEST_C_WRAPPER(common_coenc_coencpanfb, test_coencpanfb_set_pan_suffix_notpres)
TEST_C_WRAPPER(common_coenc_coencpanfb, test_coencpanfb_set_pan_suffix_panpres)
TEST_C_WRAPPER(common_coenc_coencpanfb, test_coencpanfb_set_pan_suffix_sufpres)

/*---------------------------< coxtencpan >---------------------------*/
TEST_GROUP_C_WRAPPER(common_coenc_coxtencpan)
{
	TEST_GROUP_C_SETUP_WRAPPER(common_coenc_coxtencpan);
	TEST_GROUP_C_TEARDOWN_WRAPPER(common_coenc_coxtencpan);
};

TEST_C_WRAPPER(common_coenc_coxtencpan, test_xtencpan_is_xtencrypted_pan)
TEST_C_WRAPPER(common_coenc_coxtencpan, test_xtencpan_xt_decryptPanSize)
TEST_C_WRAPPER(common_coenc_coxtencpan, test_xtencpan_xt_encryptPanSize)

/*------------------------------------------------------------------------*/
/**
 * @brief	Test runner
 *
 * @param[in]	argc - Number of command line parameters
 * @param[in]	argv - Array with command line parameters
 *
 * @retval	SUCCEED
 * @retval	FAIL
 */
/*------------------------------------------------------------------------*/
int main(int argc, char **argv)
{
    return RUN_ALL_TESTS(argc, argv);
}
/** @endcond */

