/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Unit tests for core library, crdseqno object
 *
 * @remarks
 *
 * @author	Alberto Gomez Rueda
 *
 * @date	15 Nov 2021
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/crdseqno.c#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <slnfb.h>
#include <slntp.h>
#include <sldbg.h>
#include <slstring.h>
#include <slamt.h>
#include <dberr.h>

#include <cocrd.fd.h>
#include <coint.fd.h>

#include <crdseqno.h>

#include <CppUTest/TestHarness_c.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
/*---------------------------Functions------------------------------------*/
/** @cond INTERNAL */

/*------------------------------------------------------------------------*/
/**
 * @brief	Setup function for tests in the common_core_crdseqno group
 *
 * @param[in]	common_core_crdseqno Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_core_crdseqno)
{
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_core_crdseqno group
 *
 * @param[in]	common_core_crdseqno Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_core_crdseqno)
{
     ;
}


/*------------------------------------------------------------------------*/
/**
 * @brief	Test crdseqno
 *
 * @param[in]	common_core_crdseqno Test group
 * @param[in]	get_crdseqno_fb Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_crdseqno, get_crdseqno_fb)
{
	short emvcrdseqno = 4;
	short applseqno = 3;
	short crdseqno = 2;
	short outcrdseqno = FAIL;
	short ret = 0;
	FBFR *p_fb = (FBFR *)ntp_alloc("FML", NULL, 4096);
	
	if (NULL != p_fb)	
	{
		ret = CF_chg(p_fb, C_EMVCRDSEQNO, 0, (char *)&emvcrdseqno, 0, FLD_SHORT);
		CHECK_C(SUCCEED == ret);
		ret = CF_chg(p_fb, I_APPLSEQNO, 0, (char *)&applseqno, 0, FLD_SHORT);
		CHECK_C(SUCCEED == ret);
		ret = CF_chg(p_fb, C_CRDSEQNO, 0, (char *)&crdseqno, 0, FLD_SHORT);
		CHECK_C(SUCCEED == ret);
	}

	/* check calls with single field set in mask */

	/* Get card seqno. from C_EMVCRDSEQNO */
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, EMVSEQNO_FLDMSK, 5);
	CHECK_C(SUCCEED == ret);
	CHECK_C(4 == outcrdseqno);

	/* Get card seqno. from I_APPLSEQNO */
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, APPSEQNO_FLDMSK, 5);
	CHECK_C(SUCCEED == ret);
	CHECK_C(3 == outcrdseqno);

	/* Get card seqno. from C_CRDSEQNO */
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, CTXSEQNO_FLDMSK, 5);
	CHECK_C(SUCCEED == ret);
	CHECK_C(2 == outcrdseqno);


	/* remove all fields */
	ret = F_del(p_fb, C_EMVCRDSEQNO, 0);
	CHECK_C(SUCCEED == ret);
	ret = F_del(p_fb, I_APPLSEQNO, 0);
	CHECK_C(SUCCEED == ret);
	ret = F_del(p_fb, C_CRDSEQNO, 0);
	CHECK_C(SUCCEED == ret);


	/* check whether default is allowed for specific field */

	/* Get card seqno. from C_EMVCRDSEQNO */
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, EMVSEQNO_FLDMSK, 5);
	CHECK_C(FAIL == ret);
	CHECK_C(FAIL == outcrdseqno);

	/* Get card seqno. from I_APPLSEQNO */
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, APPSEQNO_FLDMSK, 5);
	CHECK_C(FAIL == ret);
	CHECK_C(FAIL == outcrdseqno);

	/* Get card seqno. from C_CRDSEQNO */
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, CTXSEQNO_FLDMSK, 5);
	CHECK_C(SUCCEED == ret);
	CHECK_C(5 == outcrdseqno);


	/* set all fields back */
	ret = CF_chg(p_fb, C_EMVCRDSEQNO, 0, (char *)&emvcrdseqno, 0, FLD_SHORT);
	CHECK_C(SUCCEED == ret);
	ret = CF_chg(p_fb, I_APPLSEQNO, 0, (char *)&applseqno, 0, FLD_SHORT);
	CHECK_C(SUCCEED == ret);
	ret = CF_chg(p_fb, C_CRDSEQNO, 0, (char *)&crdseqno, 0, FLD_SHORT);
	CHECK_C(SUCCEED == ret);


	/* all fields in FB, but by priority only I_APPLSEQNO fill be taken */
	CHECK_C(SUCCEED == ret);
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, 
				(APPSEQNO_FLDMSK | CTXSEQNO_FLDMSK), 5);
	CHECK_C(SUCCEED == ret);
	CHECK_C(3 == outcrdseqno);

	/* get field by priority, it should be C_EMVCRDSEQNO */
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, 
				(EMVSEQNO_FLDMSK | APPSEQNO_FLDMSK | CTXSEQNO_FLDMSK), 5);
	CHECK_C(SUCCEED == ret);
	CHECK_C(4 == outcrdseqno);

	/* remove C_EMVCRDSEQNO */
	ret = F_del(p_fb, C_EMVCRDSEQNO, 0);
	CHECK_C(SUCCEED == ret);
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, 
				(EMVSEQNO_FLDMSK | APPSEQNO_FLDMSK | CTXSEQNO_FLDMSK), 5);
	CHECK_C(SUCCEED == ret);
	CHECK_C(3 == outcrdseqno);

	/* remove I_APPLSEQNO */
	ret = F_del(p_fb, I_APPLSEQNO, 0);
	CHECK_C(SUCCEED == ret);
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, 
				(EMVSEQNO_FLDMSK | APPSEQNO_FLDMSK | CTXSEQNO_FLDMSK), 5);
	CHECK_C(SUCCEED == ret);
	CHECK_C(2 == outcrdseqno);

	/* remove C_CRDSEQNO */
	ret = F_del(p_fb, C_CRDSEQNO, 0);
	CHECK_C(SUCCEED == ret);
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, 
				(EMVSEQNO_FLDMSK | APPSEQNO_FLDMSK | CTXSEQNO_FLDMSK), 5);
	CHECK_C(SUCCEED == ret);
	CHECK_C(5 == outcrdseqno);

	/* default is not allowed */
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, 
				(EMVSEQNO_FLDMSK | APPSEQNO_FLDMSK), 5);
	CHECK_C(FAIL == ret);
	CHECK_C(FAIL == outcrdseqno);

	/* fail not loading the fields */
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, 
				(EMVSEQNO_FLDMSK | APPSEQNO_FLDMSK | CTXSEQNO_FLDMSK), FAIL);
	CHECK_C(FAIL == ret);
	CHECK_C(FAIL == outcrdseqno);

	/* negative number in default */
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, 
				(EMVSEQNO_FLDMSK | APPSEQNO_FLDMSK | CTXSEQNO_FLDMSK), -123);
	CHECK_C(FAIL == ret);
	CHECK_C(FAIL == outcrdseqno);

	/* Call function with bit mask that does not have valid fields */
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, 16, 5);
	CHECK_C(FAIL == ret);
	CHECK_C(FAIL == outcrdseqno);

	/* Call the seqno. function using invalid outcrdseqno */
	ret = get_crdseqno_fb(p_fb, NULL, 
				(EMVSEQNO_FLDMSK | APPSEQNO_FLDMSK | CTXSEQNO_FLDMSK), 0);
	CHECK_C(FAIL == ret);

	if(NULL != p_fb)
	{
		ntp_free((char *)p_fb);
		p_fb = NULL;
	}

	/* Call the seqno. function using invalid FB */
	ret = get_crdseqno_fb(p_fb, &outcrdseqno, CTXSEQNO_FLDMSK, 0);
	CHECK_C(FAIL == ret);
	CHECK_C(FAIL == outcrdseqno);

}

