/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Unit tests for core library, cocrdacptloc object
 *
 * @remarks	Memory leaks should be tested on Linux with valgrind i.e.
 *		valgrind --leak-check=yes ./test/test_stdlib
 *
 * @author	Dimitris Fourkiotis
 *
 * @date	17 Feb 2020
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/cocrdacptloc.c#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sldbg.h>
#include <slhexdecode.h>

#include <cocrdacptloc.h>

#include <CppUTest/TestHarness_c.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
/*---------------------------Functions------------------------------------*/
/** @cond INTERNAL */

/*------------------------------------------------------------------------*/
/**
 * @brief	Setup function for tests in the common_core_cocrdacptloc group
 *
 * @param[in]	common_core_cocrdacptloc Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_core_cocrdacptloc)
{
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_core_cocrdacptloc group
 *
 * @param[in]	common_core_cocrdacptloc Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_core_cocrdacptloc)
{
     ;
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Check setting crdacptloc structure when all elements fit within
 * 		the available range
 *
 * @param[in]	common_core_cocrdacptloc Test group
 * @param[in]	test_cocrdacptloc_set_withinrange Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_cocrdacptloc, test_cocrdacptloc_set_withinrange)
{
	int ret = FAIL;
	char *merchant = "Gltd Electronics";
	char *address_line1 = "Smithfield Square";
	char *address_line2 = "24 Park Road";
	char *address_line3 = "Haringay";
	char *city = "London";
	char *postcode = "N8 0HG";
	char *country = "826";
	char *street_sep = " ";
	crdacptloc_t ploc;

	ret =  crdacptloc_set(&ploc, merchant, address_line1, address_line2,
			      address_line3, city, postcode, "", country,
			      street_sep, NULL, CASE_NO_CHANGE, CASE_NO_CHANGE,
			      0);

	CHECK_EQUAL_C_INT(SUCCEED, ret);
	CHECK_EQUAL_C_INT(0, strcmp(ploc.name, merchant));
	CHECK_C(CRDACPTLOC_NAME_MAX >= strlen(ploc.name));
	CHECK_EQUAL_C_INT(0, strcmp(ploc.street, "Smithfield Square 24 Park Road Haringay"));
	CHECK_C(CRDACPTLOC_CITY_MAX >= strlen(ploc.street));
	CHECK_EQUAL_C_INT(0, strcmp(ploc.postcode, postcode));
	CHECK_EQUAL_C_INT(0, strcmp(ploc.ctryn3, country));
	CHECK_EQUAL_C_INT(0, strcmp(ploc.city, city));
	CHECK_EQUAL_C_CHAR(EOS, *(ploc.region));
	CHECK_EQUAL_C_STRING("Gltd Electronics~Smithfield Square 24 Pa~London~N8 0HG       826", ploc.full_loc);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Check setting crdacptloc structure when merchant name doesn't
 * 		allow for city to be present
 *
 * @param[in]	common_core_cocrdacptloc Test group
 * @param[in]	test_cocrdacptloc_set_nocity Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_cocrdacptloc, test_cocrdacptloc_set_nocity)
{
	int ret = FAIL;
	char *merchant = "Merchant:A Long Electronics Merchant                            Too Long";
	char *address_line1 = "Smithfield Square";
	char *address_line2 = "24 Park Road";
	char *address_line3 = "Haringay";
	char *city = "London";
	char *postcode = "N8 0HG";
	char *country = "826";
	char *street_sep = " ";
	crdacptloc_t ploc;

	ret =  crdacptloc_set(&ploc, merchant, address_line1, address_line2,
			      address_line3, city, postcode, "", country,
			      street_sep, NULL, CASE_NO_CHANGE, CASE_NO_CHANGE,
			      0);

	CHECK_EQUAL_C_INT(SUCCEED, ret);
	CHECK_EQUAL_C_INT(0, strcmp(ploc.name, merchant));
	CHECK_C(CRDACPTLOC_NAME_MAX >= strlen(ploc.name));
	CHECK_EQUAL_C_INT(0, strcmp(ploc.street, "Smithfield Square 24 Park Road Haringay"));
	CHECK_C(CRDACPTLOC_CITY_MAX >= strlen(ploc.street));
	CHECK_EQUAL_C_INT(0, strcmp(ploc.postcode, postcode));
	CHECK_EQUAL_C_INT(0, strcmp(ploc.ctryn3, country));
	CHECK_EQUAL_C_INT(0, strcmp(ploc.city, city));
	CHECK_EQUAL_C_CHAR(EOS, *(ploc.region));
	CHECK_EQUAL_C_STRING("Merchant:A Long Electronics Merchant   ~~London~N8 0HG       826", ploc.full_loc);

}

/*------------------------------------------------------------------------*/
/**
 * @brief	Check setting crdacptloc structure when merchant name only
 * 		allow for city to be present partially
 *
 * @param[in]	common_core_cocrdacptloc Test group
 * @param[in]	test_cocrdacptloc_set_partial Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_cocrdacptloc, test_cocrdacptloc_set_partial)
{
	int ret = FAIL;
	char *merchant = "Gltd Electronics  Intermdiate";
	char *address_line1 = "Smithfield Square";
	char *address_line2 = "24 Park Road";
	char *address_line3 = "Haringay";
	char *city = "London";
	char *postcode = "N8 0HG";
	char *country = "826";
	char *street_sep = " ";
	crdacptloc_t ploc;

	ret =  crdacptloc_set(&ploc, merchant, address_line1, address_line2,
			      address_line3, city, postcode, "", country,
			      street_sep, NULL, CASE_NO_CHANGE, CASE_NO_CHANGE,
			      0);

	CHECK_EQUAL_C_INT(SUCCEED, ret);
	CHECK_EQUAL_C_INT(0, strcmp(ploc.name, merchant));
	CHECK_C(CRDACPTLOC_NAME_MAX >= strlen(ploc.name));
	CHECK_EQUAL_C_INT(0, strcmp(ploc.street, "Smithfield Square 24 Park Road Haringay"));
	CHECK_C(CRDACPTLOC_CITY_MAX >= strlen(ploc.street));
	CHECK_EQUAL_C_INT(0, strcmp(ploc.postcode, postcode));
	CHECK_EQUAL_C_INT(0, strcmp(ploc.ctryn3, country));
	CHECK_EQUAL_C_INT(0, strcmp(ploc.city, city));
	CHECK_EQUAL_C_CHAR(EOS, *(ploc.region));
	CHECK_EQUAL_C_STRING("Gltd Electronics  Intermdiate~Smithfield~London~N8 0HG       826", ploc.full_loc);
}



/*------------------------------------------------------------------------*/
/**
 * @brief	Check crdacptloc splitting
 *
 * @param[in]	common_core_cocrdacptloc Test group
 * @param[in]	test_cocrdacptloc_set_partial Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_cocrdacptloc, test_cocrdacptloc_split)
{
	int ret = SUCCEED; 
	crdacptloc_t loc;
	char	in_crdacptloc[256]="FIS~41-43 Clarendon Rd~Watford~WD17 1TB  HerGBR";
	
	memset(&loc, 'A', sizeof(loc));
	ret=crdacptloc_split(&loc, in_crdacptloc);
	CHECK_C(SUCCEED == ret);
	CHECK_EQUAL_C_STRING("FIS", loc.name);
	CHECK_EQUAL_C_STRING("41-43 Clarendon Rd", loc.street);
	CHECK_EQUAL_C_STRING("Watford", loc.city);
	CHECK_EQUAL_C_STRING("WD17 1TB", loc.postcode);
	CHECK_EQUAL_C_STRING("Her", loc.region);
	CHECK_EQUAL_C_STRING("GBR", loc.ctryn3);
	CHECK_EQUAL_C_STRING(loc.full_loc, in_crdacptloc);
	
}

/** @endcond */
