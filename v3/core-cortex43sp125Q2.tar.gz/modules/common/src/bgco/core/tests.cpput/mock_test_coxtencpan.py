#!/usr/bin/env python3

import sys
import os

aa_tuxFlds = {} # a dictionary with all the fields present in request

while True:
    input = sys.stdin.readline()
    
    if input == "\n":
        break

    input = input.strip("\n")

    fields = input.split("\t")

    aa_tuxFlds[fields[0]] = fields[1]

# encrypt
if "86" == aa_tuxFlds.get("K_FUNCODE"):
    print("+C_PAN\tJ5186150500787021a")
# decrypt
elif "87" == aa_tuxFlds.get("K_FUNCODE"):
    print("+C_PAN_CLR\t5186150500787021")

#mark termination of the fielded buffer
print("")
