/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	Unit tests for core library, cotraded object
 *
 * @remarks	Memory leaks should be tested on Linux with valgrind i.e.
 *		valgrind --leak-check=yes ./test/test_stdlib
 *
 * @author	Jason Veneracion
 *
 * @date	03 April 2020
 *
 * $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/core/tests.cpput/cotraded.c#1 $
 *
 * @copyright	FIS Global
 */
/*------------------------------------------------------------------------*/

/*---------------------------Includes-----------------------------------*/
#include <portable.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <slnfb.h>
#include <slntp.h>
#include <sldbg.h>
#include <slstring.h>
#include <slamt.h>
#include <dberr.h>
#include <cotraded.h>

#include <cocrd.fd.h>

#include <CppUTest/TestHarness_c.h>
#include <CppUTest/MemoryLeakDetectorMallocMacros.h>

/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/
/*---------------------------Functions------------------------------------*/
/** @cond INTERNAL */

/*------------------------------------------------------------------------*/
/**
 * @brief	Setup function for tests in the common_core_cotraded group
 *
 * @param[in]	common_core_cotraded Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_SETUP(common_core_cotraded)
{
	DBG_SETLEV(dbg_fatal);
	DBG_SETBUF(1);
}

/*------------------------------------------------------------------------*/
/**
 * @brief	Teardown function for tests in the common_core_cotraded group
 *
 * @param[in]	common_core_cotraded Test group
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_GROUP_C_TEARDOWN(common_core_cotraded)
{
     ;
}


/*------------------------------------------------------------------------*/
/**
 * @brief	Test cotraded
 *
 * @param[in]	common_core_cotraded Test group
 * @param[in]	test_cotraded_test1 Test description
 *
 *
 * @return	void
 */
/*------------------------------------------------------------------------*/
TEST_C(common_core_cotraded, test_cotraded_test1)
{
	double revamt, revamt_traded = 995.6;
	double amttxn =63.23, amt_traded = 342.5;
	int dps=2;
	char curtxn[3+1] = "";
	char fbcur[3+1] = "840";
	int is_guess=999;

	FBFR *p_fb = (FBFR *)ntp_alloc("FML", NULL, 4096);
	
	if (NULL != p_fb)	
	{
		F_chg(p_fb, C_CURTXN, 0, fbcur, 0);
	}

	revamt = co_traded2revamt(&is_guess, revamt_traded, amt_traded, amttxn,
				dps, NULL, p_fb);

	DBG_PRINTF((dbg_always,"revamt=%f is_guess=%d", revamt, is_guess));
	CHECK_C(slamt_cmp(revamt, 183.8, SLAMT_CMP_EQ));
	CHECK_C(FALSE == is_guess);
	
	revamt = co_traded2revamt(&is_guess, revamt_traded, amt_traded, amttxn,
				FAIL, curtxn, p_fb);

	DBG_PRINTF((dbg_always,"revamt=%f is_guess=%d", revamt, is_guess));
	CHECK_C(slamt_cmp(revamt, 183.8, SLAMT_CMP_EQ));
	CHECK_C(TRUE == is_guess);
	CHECK_C(0 == strcmp(curtxn, fbcur));

	revamt = co_traded2revamt(&is_guess, revamt_traded, amt_traded, amttxn,
				dps, curtxn, p_fb);

	DBG_PRINTF((dbg_always,"revamt=%f is_guess=%d", revamt, is_guess));
	CHECK_C(slamt_cmp(revamt, 183.8, SLAMT_CMP_EQ));
	CHECK_C(FALSE == is_guess);
	CHECK_C(0 == strcmp(curtxn, fbcur));

	revamt = co_traded2revamt(&is_guess, revamt_traded, amt_traded, amttxn,
				FAIL, curtxn, NULL);

	DBG_PRINTF((dbg_always,"revamt=%f is_guess=%d", revamt, is_guess));
	CHECK_C(slamt_cmp(revamt, 183.8, SLAMT_CMP_EQ));
	CHECK_C(TRUE == is_guess);
	
	ntp_free((char *)p_fb);
}




