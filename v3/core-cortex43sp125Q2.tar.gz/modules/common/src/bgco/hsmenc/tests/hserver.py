#!/usr/bin/env python3

## @package hserver
#
#  @author  Wieslaw Grygo
#
#  @date    20 Nov 2018
#
#  @brief   HSM server for testing HSM client.
#
#  $Id: //prod/cortex/c/modules/common/common-6.4/src/bgco/hsmenc/tests/hserver.py#4 $
#
#  @copyright FIS Global
#

import socket
import struct
import errno
import string
import ssl

from optparse import OptionParser

##
# @brief    Process one connection
# 
# @param    [in] conn connection
# @param    [in] map Map requests to responses
#
# @return   None
#
def process(conn, map):
        buf = ''
        size = 0
        last = 0
        read = 2
        while read:
            data = conn.recv(4096)
            if len(data)==0:
                break
            buf += data
            while last+read <= len(buf):
                # are we waiting for size
                if read == 2:
                    # get size
                    #safe
                    #(size,) = struct.unpack_from('!H',buf,last)
                    #fast
                    size = ord(buf[last+1]) + (ord(buf[last])<<8)
                    
                    # get size
                    if size:
                        read += size
                        continue
                
                # store value
                req = buf[last+2:last+read]
                print("received message:", repr(req))
                if req in map:
                    res = map[req]
                    res = struct.pack('!H', len(res)) + res
                    conn.sendall( res )
                else:
                    print("Unknown request")
                    conn.close()
                    read = 0
                    break

                # read next
                last += read
                read = 2;

##
# @brief    Main function
# 
# @return   None
#
def main():
    # Parser of commandline parameters
    parser = OptionParser(add_help_option=False)

    parser.add_option("-?", "--help", action="help")

    parser.add_option("-s", dest="service",
        help="Service to connect")
    parser.add_option("-S", type="float", dest="slow", default=0.1,
        help="Wait time after each block is send.")
    parser.add_option("-h", dest="hostname", default='0.0.0.0',
        metavar="HOST", help="Address of host")
    
    parser.add_option("-p", dest="show", default=False, action="store_true",
        help="Print result.")

    parser.add_option("-X", dest="ssl", default=False, action="store_true",
        help="Use SSL.")
    
    parser.add_option("--CAfile", dest="CAfile", default=None,
        metavar="file", help="File with CA certificates for SSL")

    parser.add_option("--cert", dest="cert", default=None,
        metavar="file", help="File with client certificate for SSL")

    parser.add_option("--key", dest="key", default=None,
        metavar="file", help="File with key for client certificate")

    (options, args) = parser.parse_args()

    if not options.service:
        parser.error("Option -s is rquired! Use -? or --help to see usage information.")
        
    
    #print 'Arguments', args
    map = {}
    for a in args:
        print("Arg", a)
        (key, val) = a.split(':',2)
        map[key.decode('string_escape')] = val.decode('string_escape')
    
    # resolve address and use first value
    addresses = socket.getaddrinfo(options.hostname, options.service, socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP, socket.AI_PASSIVE)
    (family, socktype, proto, canonname, sockaddr) = addresses[0]
    
    # listen
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(sockaddr)
    sock.listen(5)
    if options.ssl:
        sock = ssl.wrap_socket(sock,
            certfile=options.cert,
            keyfile=options.key,
            ca_certs=options.CAfile,
            cert_reqs=ssl.CERT_REQUIRED)
    
    # process connections
    while True:
        print('Wait for connection')
        conn, addr = sock.accept()
        print('Accepted connection from', addr)
        process(conn, map);

main()
