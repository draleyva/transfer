/*------------------------------------------------------------------------*/
/**
 * @file
 *
 * @brief	  Currency Lookup
 *
 * @author	  Marcin Odrzywolski
 *
 * @date	  23 Apr 2021
 *
 * $Id$
 *
 * @copyright    FIS Global
 */
/*------------------------------------------------------------------------*/


#pragma once

#if __cplusplus < 201703L 
	#error "Header requires C++17"
	#include <stophere>
#endif


/*---------------------------Includes-----------------------------------*/
#include <portable.h>

#include <sldbg.h>
#include <slnfb.h>
#include <slntp.h>
#include <slcfp.h>

#include <coint.fd.h>
#include <cocrd.fd.h>
#include <enc.fd.h>

#include <stdint.h>
#include <string>
#include <deque>
#include <memory>
#include <map>
#include <iostream>
#include <DbWrappers.hh>
#include <MetaProg.hh>

#include <dbcurrrh.h>
#include <dbcurrency_scan.h>
/*---------------------------Externs------------------------------------*/
/*---------------------------Macros-------------------------------------*/
/*---------------------------Enums--------------------------------------*/
/*---------------------------Typedefs-----------------------------------*/
/*---------------------------Globals------------------------------------*/
/*---------------------------Statics------------------------------------*/
/*---------------------------Prototypes---------------------------------*/


namespace ctxcc
{

	/*------------------------------------------------------------------------*/
	/**
	 * @brief	Currency lookup cache
	 *
	 */
	/*------------------------------------------------------------------------*/
	class CurrencyLookup
	{
	public:
		/*------------------------------------------------------------------------*/
		/**
		 * @brief	Currency lookup cache entry
		 *
		 */
		/*------------------------------------------------------------------------*/
		struct CacheEntry
		{
			/*------------------------------------------------------------------------*/
			/**
			 * @brief	Conversion operator
			 *
			 * @param[in]	rec DataBase record
			 *
			 * @return	this
			 */
			/*------------------------------------------------------------------------*/
			CacheEntry& operator = (const std::tuple<CURRENCY_t, CURRENCY_IND_t> &rec)
			{
				mAlphacode = std::get<0>(rec).alphacode;
				mCurrcode = std::get<0>(rec).currcode;
				mDecpoints = std::get<0>(rec).dec_places;

				return *this;
			}

			/*------------------------------------------------------------------------*/
			/**
			 * @brief	operator<< for ostream printing
			 *
			 * @param[in]	out stream for printing
			 * @param[in]	d map entry
			 *
			 * @return out
			 */
			/*------------------------------------------------------------------------*/
			friend std::ostream& operator<< (std::ostream &out, const std::pair<std::string, CacheEntry> &d)
			{
				out 	<< "(alpha=" << d.second.mAlphacode
					<< " num=" << d.second.mCurrcode
					<< " dec=" << d.second.mDecpoints << ")" << std::endl;

				return out;
			}

			std::string	mAlphacode; /**< Alpha code */
			std::string	mCurrcode; /**< Numeric code */
			uint16_t	mDecpoints{0}; /** Number of decimal points */
		};

		/*------------------------------------------------------------------------*/
		/**
		 * @brief	Displays content of cache
		 *
		 */
		/*------------------------------------------------------------------------*/
		void display()
		{
			print_container(std::cerr, mCurrency_Alpha2Num, std::string(""));
		}

		/*------------------------------------------------------------------------*/
		/**
		 * @brief       Translates currcode to aplha
		 *
		 * @param[in]  num currcode
		 *
		 * @return alphacode
		 */
		/*------------------------------------------------------------------------*/
		std::string n2a(uint32_t num)
		{
			fetchIfNeeded();

			if(std::find(mCurrency_Banned.begin(), mCurrency_Banned.end(), num) != mCurrency_Banned.end())
				return std::string("!!!");

			decltype(mCurrency_Num2Alpha)::iterator entry = mCurrency_Num2Alpha.find(num);

			if(entry == mCurrency_Num2Alpha.end())
				return std::string("---");
			else
				return entry->second.mAlphacode; 
		}

		/*------------------------------------------------------------------------*/
		/**
		 * @brief       Translates alpha to currcode
		 *
		 * @param[in]  alpha alphacode
		 *
		 * @return currcode
		 */
		/*------------------------------------------------------------------------*/
		uint32_t a2n(const std::string &alpha)
		{
			fetchIfNeeded();

			decltype(mCurrency_Alpha2Num)::iterator entry = mCurrency_Alpha2Num.find(alpha);

			if(entry == mCurrency_Alpha2Num.end())
				return 0;
			else
				return stoi(entry->second.mCurrcode);
		}

		/*------------------------------------------------------------------------*/
		/**
		 * @brief       Fetches data into cache only if cache is empty
		 *
		 */
		/*------------------------------------------------------------------------*/
		void fetchIfNeeded()
		{
			if(mCurrency_Alpha2Num.empty())
				fetch();
		}

		/*------------------------------------------------------------------------*/
		/**
		 * @brief       Fetches data into cache
		 *
		 */
		/*------------------------------------------------------------------------*/
		void fetch()
		{
			typename ctxcc::dbacl::QueryFullScan<CacheEntry, std::tuple<CURRENCY_t, CURRENCY_IND_t>, dbCURRENCY_scan, dbCURRENCY_get_next, dbCURRENCY_close_scan> scanCurrency;

			for (auto r : scanCurrency)
			{
				mCurrency_Alpha2Num.emplace(r.mAlphacode, r);
				mCurrency_Num2Alpha.emplace(stoi(r.mCurrcode), r);
			}
		}

		/*------------------------------------------------------------------------*/
		/**
		 * @brief       Gets underlaying cache container
		 *
		 * @return cache container
		 */
		/*------------------------------------------------------------------------*/
		const std::map<std::string/*alpha*/, CacheEntry>& getAll()
		{
			return mCurrency_Alpha2Num;
		}
	protected:
		std::array<uint32_t,2>				mCurrency_Banned={123, 999}; /**< Banned currcodes */
		std::map<std::string/*alpha*/, CacheEntry>	mCurrency_Alpha2Num;	/**< alpha -> num translation lookup map */
		std::map<uint32_t/*currcode*/, CacheEntry>	mCurrency_Num2Alpha;	/**< num -> alpha translation lookup map */
	};
}

