/* run_all.sql
   Master driver for 43sp1 migration.
   You can run individual parts (run_01.sql, run_02.sql) or everything via this script.
*/
@@include/env.sql
@@include/params.sql

host mkdir -p &&LOG_DIR

prompt ======== RUN PART 1 ========
@@run_01.sql

prompt ======== RUN PART 2 ========
@@run_02.sql

prompt All parts completed.
