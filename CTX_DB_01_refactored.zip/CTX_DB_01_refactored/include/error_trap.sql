/* error_trap.sql
   Helper to show a banner on errors (WHENEVER ... EXIT is set in env.sql).
*/
prompt If you see this after an abrupt exit, check the generated SPOOL log for the failing statement.
