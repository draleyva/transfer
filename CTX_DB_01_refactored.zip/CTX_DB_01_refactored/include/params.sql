/* params.sql
   Centralized parameters. You can pass values on the command line,
   e.g.: sqlplus user/pass@db @run_all.sql LOG_DIR=logs SCHEMA=APP
   If not provided, ACCEPT will interactively prompt with defaults.
*/
column _ts new_value LOGSTAMP noprint
select to_char(sysdate,'YYYYMMDD_HH24MISS') as _ts from dual;

define PROJECT = CTXDB_Migracion_43sp1
define BASE_DIR = .
define LOG_DIR  = logs
define SCHEMA   = CTXAPP

-- Allow overrides passed in externally
define PROJECT = "&&PROJECT"
define BASE_DIR = "&&BASE_DIR"
define LOG_DIR = "&&LOG_DIR"
define SCHEMA = "&&SCHEMA"

prompt Using PROJECT=&&PROJECT BASE_DIR=&&BASE_DIR LOG_DIR=&&LOG_DIR SCHEMA=&&SCHEMA
