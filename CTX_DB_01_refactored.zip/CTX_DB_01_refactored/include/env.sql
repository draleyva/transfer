/* env.sql
   Common SQL*Plus environment settings (idempotent).
   - Echo commands and show errors when they happen.
   - Stop on errors (returning the Oracle error code to the OS).
*/
set echo on
set verify off
set define on
set termout on
set serveroutput on
set feedback on
set timing on
whenever oserror exit 1
whenever sqlerror exit sql.sqlcode rollback
