/* prompt_run.sql
   Usage: @@include/prompt_run.sql <relative_path_to_sql>
   Prints a friendly message and executes the given script.
*/
define _FILE="&1"
prompt === Running &&_FILE ===
@&&_FILE
