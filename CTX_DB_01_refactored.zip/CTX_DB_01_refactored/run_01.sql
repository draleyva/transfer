/* run_01.sql
           Consolidated driver. Generated on 2025-09-29 12:07:07.
           This script relies on include/env.sql, include/params.sql, and include/prompt_run.sql.
           It replaces the previous split of *_prompt.sql and *.sql so there is a single source of truth.
        */
        @@include/env.sql
        @@include/params.sql

        -- Create logs directory if missing (platform dependent, best-effort)
        host mkdir -p &&LOG_DIR

        spool &&LOG_DIR/CTX_DB_01_&&LOGSTAMP..log
        prompt Starting run_01.sql at &&LOGSTAMP

        @@include/prompt_run.sql ./CTX_DB_01/db_43/access/u.310.d_tb_usrinst_extend_usr.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/access/u.311.d_tb_usrperm_extend_usr.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/access/u.312.d_tb_activity_extend_usr.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/access/u.313.d_tb_pwdhist_extend_usr.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/access/u.314.d_tb_usr_extend_usr.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.286.setting_maxvalue_and_cycle_flag_for_sequences.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.287.d_tb_balimp_billcycdates.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.289.d_tb_upload.requestid.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.290.d_tb_aprvlcode_extend_usr.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.291.d_tb_aprvlhist_extend_usr.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.292.d_tb_authover_extend_usr.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.293.d_tb_authoverlog_extend_usr.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.294.d_tb_crdauthover_extend_usr.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.295.d_tb_crdlimover_extend_usr.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.296.p_sp_addbalslog_add.drop.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.785._data_.numdescr.reasoncodes.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.795.d_tb_disputes.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.796.e_cs_disputes.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.797.h_ky_disputes.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.798.t_tr_disputes_change.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.799.p_sp_write_disputes.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.800.t_tr_tlog_change.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/auth/u.801.t_tr_tlog_insert.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/commfunc/u.216.d_tb_threshold_percent_limit.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/commfunc/u.217.d_tb_threshold_set_limit_code.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/commfunc/u.218.p_sp_write_threshold_hist_ext.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/commfunc/u.219.p_sp_write_threshold_set_hist_ext.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/commfunc/u.220.t_tr_threshold_delete_ext.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/commfunc/u.221.t_tr_threshold_change_ext.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/commfunc/u.222.t_tr_threshold_insert_ext.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/commfunc/u.223.t_tr_threshold_set_delete_ext.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/commfunc/u.224.t_tr_threshold_set_change_ext.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/commfunc/u.225.t_tr_threshold_set_insert_ext.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/commfunc/u.227.setting_maxvalue_and_cycle_flag_for_sequences.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/common/u.783.d_tb_qinfo.qdata_type.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/common/u.784._data_strdescr.credit_limit.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/common/u.792.setting_maxvalue_and_cycle_flag_for_sequences.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/common/u.793.p_sp_raise_exception.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/common/u.794._data_.eventcat.di.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.536.d_tb_acctype_acclogging_migration_step1_add_new_columns.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.537.d_tb_acctype_acclogging_migration_step2_copy.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.538.d_tb_acctype_acclogging_migration_step3_remove_old_column.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.539.d_tb_accdet_di.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.540.t_tr_accdet_change.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.541.d_tb_acctype_di.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.542.t_tr_acctype_change.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.543.d_tb_accitems_shdwauthov.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.544.d_tb_accdet_billcycdates.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.545.d_tb_accdet_x_nickname.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.546._data_.accstatus.pending_activation.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.547.d_tb_accitems_chrglnk_extend_pk.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.548.d_tb_accitems_extend_pk.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.549.t_tr_acctype_change.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.550.d_tb_accbalslog_change.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.551.p_sp_accbalslog_enabled.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.552.p_sp_accbalslog_write.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.553.p_sp_accbalslog_eod.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.554.t_tr_accdet_change.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.555.t_tr_accdet_insert.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.556._data_.housekeep.accbalslog.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.557.t_tr_accitems_insert.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.558.d_tb_custdet_extend_custcode.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/crdbase/u.559.setting_maxvalue_and_cycle_flag_for_sequences.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/des/u.147.setting_maxvalue_and_cycle_flag_for_sequences.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/fds/u.017.setting_maxvalue_and_cycle_flag_for_sequences.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/feebase/u.145.d_tb_chargelog_extend_pk.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/feebase/u.146.setting_maxvalue_and_cycle_flag_for_sequences.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/integra/u.013.setting_maxvalue_and_cycle_flag_for_sequences.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/issuer/u.037._data_.eventcat.genpreprocrdsvc.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/issuer/u.038.d_tb_crdbtch_extend_usr.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/issuer/u.039.d_tb_crdrplace_extend_usr.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/issuer/u.040.crdbtch_add_batch_info.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/issuer/u.041.setting_maxvalue_and_cycle_flag_for_sequences.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/party/u.075.setting_maxvalue_and_cycle_flag_for_sequences.sql
@@include/prompt_run.sql ./CTX_DB_01/db_43/visa/u.258.setting_maxvalue_and_cycle_flag_for_sequences.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/common/u.803._data_.strdescr.accsel.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/common/u.813._data_.qinfo.crdautoactq.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/common/u.814._data_.numdescr.txnstats.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/common/u.815._data_.numdescr.dfctyp.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/common/u.818._data_.msc.crdpack.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/common/u.821.d_tb_issuerapp.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.562.d_tb_crdformat.var_pin.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.563.d_tb_pregenpin.pin_len.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.565.d_tb_crdpin.pinblk.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.566.d_tb_pregenpin.pinblk.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.567.d_tb_wallet.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.568.d_tb_walletitem.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.569.d_tb_crdproduct_wallet_id.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.570.e_cs_wallet.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.571.e_cs_walletitem.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.572.h_ky_wallet.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.573.h_ky_walletitem.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.574.h_ky_crdproduct_wallet_id.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.575.t_tr_wallet_change.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.576.t_tr_walletitem_change.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.577.t_tr_wallet_insert.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.578.t_tr_walletitem_insert.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.579.d_tb_crddet_add_additionaltype.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.581._data_numdescr.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.582._data_numdescr.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.583.p_sp_auto_activate.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.584.t_tr_crddet_change.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.585.d_tb_crdacc_walletitem_id.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.586.d_tb_accdet_lastloaddate.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.587.d_tb_accitems_itemid.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.588.h_ky_crdacc_walletitem_id.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.589._data_numdescr.loadsrc.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.590._data_numdescr.txntype.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.591.h_ky_accitems.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.592.d_tb_emvconf_upi.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.593.e_cs_emvconf_upi.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.594.t_tr_emvconf_upi_change.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.595.t_tr_emvconf_upi_insert.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.596.l_vw_emvconfupi.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.597._data_.emvcrptver_UPI.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.598.l_vw_emv_profile_conf_vw.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/crdbase/u.599._data_.scheme_UPI.sql
@@include/prompt_run.sql ./CTX_DB_01/db_44/issuer/u.042.d_tb_additionals_add_type.sql

        prompt Committing...
        commit;

        spool off
        prompt Completed run_01.sql.
        @@include/error_trap.sql
