# CTX_DB_01 Refactor (SQL*Plus)

**Date:** 2025-09-29

This refactor reduces duplication and makes it easier to maintain and re-run the migration scripts for *43sp1*.
The previous structure contained both `CTXDB_Migracion_43sp1_0X.sql` and `CTXDB_Migracion_43sp1_0X_prompt.sql` with near-identical lists of `@` calls.
That led to repetitive edits and drift (e.g., typos like `promp` and truncated filenames).

## What changed

1. **Single source of truth for each part**
   - New drivers: `run_01.sql` and `run_02.sql` (under this folder) consolidate *prompt + execute* for every child script.
   - The helper `include/prompt_run.sql` prints a friendly banner and runs the target file, eliminating the need to maintain separate `_prompt` scripts.

2. **Centralized environment and parameters**
   - `include/env.sql` defines consistent SQL*Plus settings and *fails fast* on errors using `WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK`.
   - `include/params.sql` centralizes overridable variables: `PROJECT`, `BASE_DIR`, `LOG_DIR`, and `SCHEMA`. You can override them on the command line:
     ```
     sqlplus user/pass@db @run_all.sql LOG_DIR=./logs SCHEMA=CTXAPP
     ```

3. **Standardized logging (SPOOL) with timestamps**
   - `column ... new_value` captures a timestamp into `&&LOGSTAMP`.
   - Each part spools to `logs/CTX_DB_0X_<timestamp>.log`.
   - A best‑effort `host mkdir -p &&LOG_DIR` ensures the log directory exists on Unix-like systems.

4. **Top-level master script**
   - `run_all.sql` orchestrates `run_01.sql` and `run_02.sql`, so you can execute the whole migration in one go.

5. **Error messaging**
   - `include/error_trap.sql` shows a banner to check the spool log if a failure occurs. The actual exit-on-error is governed by `env.sql`.

## How to run

- Everything:
  ```
  sqlplus user/pass@service @run_all.sql LOG_DIR=./logs SCHEMA=CTXAPP
  ```

- Part 1 only:
  ```
  sqlplus user/pass@service @run_01.sql LOG_DIR=./logs SCHEMA=CTXAPP
  ```

- Part 2 only:
  ```
  sqlplus user/pass@service @run_02.sql LOG_DIR=./logs SCHEMA=CTXAPP
  ```

## Notes and recommendations

- **Relative paths**: The refactor keeps original relative `@./CTX_DB_xx/...` paths. If you later decide to relocate folders, you can introduce additional `DEFINE` variables (e.g., `DEFINE CTX_DB_01=./CTX_DB_01`) and replace the hard‑coded prefixes with `&&CTX_DB_01` for better portability.
- **Idempotency**: If some DDL statements are not idempotent, consider guarding them with existence checks (e.g., querying `user_tables`, `user_triggers`, etc.) or converting to `CREATE OR REPLACE` where safe.
- **Transactional boundaries**: The drivers include a final `COMMIT;`. If finer control is needed, add intermediate commits or `SAVEPOINT`s around risky groups.
- **Validation**: After execution, review the `logs/*.log` files and consider adding a post‑migration validation script that checks for expected objects and data (counts, constraints, invalid objects).

## Files added

- `run_all.sql` — master orchestrator.
- `run_01.sql` — consolidated part 1 (replaces both `CTXDB_Migracion_43sp1_01.sql` and `_prompt.sql`).
- `run_02.sql` — consolidated part 2 (replaces both `CTXDB_Migracion_43sp1_02.sql` and `_prompt.sql`).
- `include/env.sql` — consistent SQL*Plus settings and error handling.
- `include/params.sql` — centralized parameters (overridable).
- `include/prompt_run.sql` — prints banner and executes a child script.
- `include/error_trap.sql` — simple guidance after failure.

## Known cleanups

- Fixed duplicated maintenance between prompt and non‑prompt scripts by using `prompt_run.sql`.
- Standardized `SPOOL` names and timestamps.
- Ensured **fail-fast** behavior on SQL and OS errors.
- Preserved original execution order from the provided migration scripts.

---

*Generated for maintainability and ease of future edits. Modify only the drivers to add/remove child scripts; no need to touch multiple parallel files anymore.*
